# CONFIG CONDITION:

- mtu of member must be less than or equal to parent interface