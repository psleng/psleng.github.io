import re
import shlex


FIELD_PATTERN = re.compile(r"^([A-Za-z][A-Za-z0-9_-]*):(.*)$")


def read_ssh_definition(content):

    result = {"multi": False, "type": None, "help": None, "values": []}
    value_help = []

    for raw_line in content.splitlines():
        match = FIELD_PATTERN.match(raw_line.strip())
        if not match:
            continue

        field, raw_value = match.groups()
        value = raw_value.strip()
        if field == "multi":
            result["multi"] = True
        elif field == "type":
            result["type"] = value or None
        elif field == "help":
            result["help"] = value or None
        elif field == "val_help":
            option, separator, description = value.partition(";")
            option = option.strip()
            if separator and option:
                value_help.append({
                    "value": option,
                    "description": description.strip(),
                })
        elif field == "allowed":
            result["values"] = _parse_allowed(value)

    if value_help:
        allowed = set(result["values"])
        result["values"] = [
            item for item in value_help if not allowed or item["value"] in allowed
        ]
    if not result["values"]:
        raise ValueError("definition does not contain a supported allowed value list")
    return result


def _parse_allowed(value):
    try:
        words = shlex.split(value)
    except ValueError as exc:
        raise ValueError(f"invalid allowed expression: {exc}") from exc

    if words and words[0] == "echo":
        words = words[1:]
    if len(words) == 1:
        words = words[0].split()

    # Preserve the order from VyOS.
    return list(dict.fromkeys(word for word in words if word))
