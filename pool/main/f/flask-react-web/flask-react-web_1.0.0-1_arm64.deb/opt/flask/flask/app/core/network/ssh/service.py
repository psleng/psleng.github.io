import pprint
from uuid import uuid4

from flask import session

from app.core.api.http.cmd.command import SHOW_SSH_CONFIG
from app.core.api.http.http_request import Action
from app.core.network.ssh.command_ssh import SSHCommand
from app.core.network.ssh.models import SSHConfig
from app.core.utils.process_config import (
    merge_dicts_delete,
    merge_dicts_set,
)
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


VERIFY_SERVICE = 'service_ssh'
SSH_FINGERPRINTS_QUERY = 'ShowFingerprintsSsh'
SSH_DYNAMIC_PROTECTION_QUERY = 'ShowDynamicProtectionSsh'


def _with_pki_for_verification(provider, config):
    verification_config = dict(config) if isinstance(config, dict) else {}
    verification_config['pki'] = provider.verify_service.call_get_config('pki')
    return verification_config


def _extract_monitor_result(response, query_name):
    payload = response.json()
    query = (payload.get('data') or {}).get(query_name) or {}
    if not query.get('success'):
        errors = query.get('errors') or payload.get('errors') or f'{query_name} failed'
        raise RuntimeError(str(errors))
    return (query.get('data') or {}).get('result')


def fetch_ssh_fingerprints(provider, data=None):
    ascii_enabled = bool((data or {}).get('ascii', False))
    response = provider.graphql_service.send_request(
        function_name=SSH_FINGERPRINTS_QUERY,
        data={'ascii': 'true' if ascii_enabled else 'false'},
        verify=False,
    )
    result = _extract_monitor_result(response, SSH_FINGERPRINTS_QUERY)
    return result if isinstance(result, list) else []


def fetch_ssh_dynamic_protection(provider, data=None):
    del data
    response = provider.graphql_service.send_request(
        function_name=SSH_DYNAMIC_PROTECTION_QUERY,
        data={},
        verify=False,
    )
    return _extract_monitor_result(response, SSH_DYNAMIC_PROTECTION_QUERY)


def update_ssh(provider, data):
    logger.info('Update SSH:')
    logger.info(data)

    username = session['username']
    enabled = bool(data.get('enabled'))
    new_config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}
    created_fields = diff.get('created') or {}
    deleted_fields = dict(diff.get('deleted') or {})

    current_trusted_user_ca = current_config.get(
        'trusted-user-ca',
        current_config.get('trusted_user_ca'),
    )
    trusted_user_ca_removed = (
        current_trusted_user_ca not in (None, '')
        and not {'trusted-user-ca', 'trusted_user_ca'} & new_config.keys()
    )
    if trusted_user_ca_removed:
        deleted_fields['trusted-user-ca'] = current_trusted_user_ca

    if not enabled:
        return _delete_ssh(provider, username)

    set_command = SSHCommand(operator='set', resource='service')
    set_commands = set_command.generate_commands(
        data=created_fields,
        current_config=current_config,
        new_config=new_config,
    )
    
    delete_command = SSHCommand(operator='delete', resource='service')
    delete_commands = delete_command.generate_commands(
        data=deleted_fields,
        current_config=current_config,
        new_config=new_config,
    )
    
    verify_result = _verify_merged_config(
        provider,
        created_fields,
        deleted_fields,
    )
    commands = list(dict.fromkeys(delete_commands + set_commands))

    if not commands and not current_config:
        enable_command = SSHCommand(operator='set', resource='service')
        commands = enable_command.generate_enable_service_command()

    if _verification_failed(verify_result):
        return [{
            'success': False,
            'error': str(verify_result),
            'cmd': commands,
        }]

    SSHConfig.refresh(new_config)
    _emit_notification(username, 'Success: Update SSH', 'SSH is successfully updated')

    if not commands:
        return []

    response = provider.http_service.send_request(
        action=Action.CONFIGURE,
        data=commands,
        verify=False,
    ).json()
    return [{
        'cmd': commands,
        'success': response.get('success'),
        'error': response.get('error'),
    }]


def _delete_ssh(provider, username):
    delete_command = SSHCommand(operator='delete', resource='service')
    commands = delete_command.generate_delete_service_command()

    response = provider.http_service.send_request(
        action=Action.CONFIGURE,
        data=commands,
        verify=False,
    ).json()

    if not response.get('success'):
        return [{
            'success': False,
            'error': response.get('error'),
            'cmd': commands,
        }]

    SSHConfig.truncate()
    _emit_notification(
        username,
        'Success: Delete SSH',
        'SSH configuration deleted successfully',
    )
    return [{
        'cmd': commands,
        'success': True,
        'error': response.get('error'),
    }]


def _verify_merged_config(provider, created_fields, deleted_fields):
    raw_config = provider.verify_service.call_get_config(VERIFY_SERVICE) or {}
    
    for label, value in (
        ('raw_config', raw_config),
        ('deleted_fields', deleted_fields),
        ('created_fields', created_fields),
    ):
        if not isinstance(value, dict):
            raise TypeError(
                f'SSH update expected {label} to be a dict, '
                f'got {type(value).__name__}: {value!r}'
            )

    config_after_deletes = merge_dicts_delete(
        raw_config,
        deleted_fields,
        clean_empty=False,
    )

    if {'trusted-user-ca', 'trusted_user_ca'} & deleted_fields.keys():
        config_after_deletes.pop('trusted-user-ca', None)
        config_after_deletes.pop('trusted_user_ca', None)
    
    merged_config = merge_dicts_set(config_after_deletes, created_fields)

    if not merged_config:
        return None
    verify_config = _with_pki_for_verification(provider, merged_config)
    return provider.verify_service.call_verify(VERIFY_SERVICE, verify_config)


def _verification_failed(verify_result):
    return verify_result not in (None, '', {}, 'None', 'null')


def _emit_notification(username, title, content):
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': title,
            'content': content,
        },
    )


def verify_ssh(provider, data):
    verify_config = _with_pki_for_verification(provider, data)
    verify_result = provider.verify_service.call_verify(VERIFY_SERVICE, verify_config)
    logger.debug('SSH verify result:\n%s', pprint.pformat(verify_result))
    return verify_result


def fetch_ssh_config(provider, data=None):
    del data
    response = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_SSH_CONFIG,
        verify=False,
    )
    return response.json().get('data') or {}
