import os
import json
import shlex
import pprint
from typing import Dict, Any, List, Union, Optional, Tuple
from copy import deepcopy
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

edge_keys = [
    'log', 'disable', 'exclude', 'authoritative', 'interleave', 'noselect', 'nts', 'pool', 'ptp', 'persistent_tunnel', 'use_lzo_compression', 'reject_unconfigured_clients', 'administrative', 'ignore_hosts_file',
    'disable_arp_filter', 'disable_forwarding', 'enable_proxy_arp', 'enable_arp_accept', 'enable_arp_announce', 'enable_arp_ignore', 'enable_directed_broadcast', 'proxy_arp_pvlan',
    'autoconf', 'no_default_link_local', 'rapid_commit', 'parameters_only', 'managed_flag', 'no_send_advert', 'no_send_interval', 'other_config_flag', 'decrement_lifetime', 'deprecate_prefix',
    'no_autonomous_flag', 'no_on_link_flag', 'no_remove_route', 'disable_uniqreqids', 
    'virtual_ip', 'disable-mobike', 'ikev2-reauth', 'compression', 'disable_rekey', 'disable_route_autoinstall', 'force_udp_encapsulation', 'disable_accounting', 'flex_vpn', 'preserve_fqdn',
    'disable_source_nat', 'enable_local_traffic', 'flush_connections', 'sticky_connections', 'per_packet_balancing',
    'enable_http_redirect', 'exclude_vrrp_interface', 'rfc3768_compability', 'no_preempt',
    'isolate_stations', 'disable_broadcast_ssid', 'enable_bf_protection', 'center_channel_freq', 
    'antenna_pattern_fixed', 'ldpc', 'stationary_ap',
    'mtu_ignore', 'no_summary', 'no_advertise', 'opaque_lsa', 'rfc1583_compatibility', 'detail', 'always', 'shortcut',
    'normal', 'nssa', 'stub', 'passive', 'graceful_restart',
    'connected', 'kernel', 'static', 'rip', 'bgp', 'isis', 'nhrp', 'babel',
    'default', 'auto_check', 'revoke', 'system_install', 'password_protected'
]

def is_edge_key(part, all_parts):
    if part in edge_keys:
        return True
    else:
        if part == "mtu":
            return all_parts[0] == "dhcp_options"
        return False

def try_convert_to_number(value: str) -> Union[int, float, str]:
    try:
        if '.' in value:
            return float(value)
        return int(value)
    except ValueError:
        return value

def get_template_def(templates: Dict[str, Any], path_parts: List[str]) -> Dict[str, Any]:
    current = templates
    for part in path_parts:
        if part in current:
            current = current[part]
        elif "node.tag" in current:
            current = current["node.tag"]
            continue
            # if part in current:
            #     current = current[part]
            # else:
            #     return {}
        else:
            # if len(path_parts) == 1:
            #     raise Exception("invalid command format")
            return {}
    return current

def load_templates(templates_path: str) -> Dict[str, Any]:
    try:
        with open(templates_path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, PermissionError):
        raise Exception("Cannot read templates file")
    except json.JSONDecodeError:
        raise Exception("Invalid templates file format")

def generate_dict_config(command: str, templates_path: str = None, tag_object: bool = False) -> Dict[str, Any]:
    if templates_path is None:
        templates_path = os.path.join(os.path.dirname(__file__), 'templates.json')
    
    templates = load_templates(templates_path)
    
    parts = command.split()
    if parts[0] in ['set', 'delete']:
        parts = parts[1:]
    
    if len(parts) < 2:
        return {}
    
    result = {}
    current_dict = result
    path = []
    
    if len(parts) >= 2:
        last_part = normalize_key(parts[-1])
        if is_edge_key(last_part, parts):
            for i, part in enumerate(parts):
                path.append(part)
                normalized_part = normalize_key(part)
                
                if i == len(parts) - 1:  # Last part is the edge key
                    current_dict[normalized_part] = {}
                else:
                    if normalized_part not in current_dict:
                        current_dict[normalized_part] = {}
                    current_dict = current_dict[normalized_part]
            return result
    
    for i, part in enumerate(parts[:-1]):
        path.append(part)
        template_def = get_template_def(templates, path)
        
        is_tag = "node.tag" in template_def and not tag_object
        
        normalized_part = normalize_key(part)
        if i == len(parts) - 2:  # Last key before value
            value = parts[-1]
            if template_def.get("node.def") == "tag:":
                # For tag: type fields, create a dict with the value as key
                if normalized_part not in current_dict:
                    current_dict[normalized_part] = {}
                current_dict[normalized_part][value] = {}
            elif is_tag or template_def.get("node.def") == "multi":
                current_dict[normalized_part] = [value]
            elif is_edge_key(normalized_part, parts) or (tag_object and template_def.get("node.def") == "tag:"):
                current_dict[normalized_part] = {}
            elif is_edge_key(value, parts):
                if normalized_part not in current_dict:
                    current_dict[normalized_part] = {}
                current_dict[normalized_part][value] = {}
            else:
                current_dict[normalized_part] = value
        else:
            if normalized_part not in current_dict:
                current_dict[normalized_part] = {}
            current_dict = current_dict[normalized_part]
    
    return result

def process_commands(commands: List[str], tag_object: bool = False) -> Dict[str, Any]:
    """
    Process a list of commands and return a dictionary representation of the configuration.
    Ie.
        Format of the configuration is based on the templates file templates.json
        Which was generated by recursively reading the folder structure /opt/vyatta/share/vyatta-cfg/templates/
        Read more: folder_reader.py
        
    Args:
        commands (List[str]): A list of commands to process.
    Returns:
        Dict[str, Any]: A dictionary representation of the configuration.
    """
    print("Command List:", commands)

    final_dict = {}
    templates_path = os.path.join(os.path.dirname(__file__), 'templates.json')
    
    templates = load_templates(templates_path)
    
    for command in commands:
        command_dict = generate_dict_config(command, templates_path, tag_object)
        # print("Command Dict:", command_dict)
        final_dict = merge_dicts_set(final_dict, command_dict, templates_path)
        # print("Final Dict:", final_dict)

    return final_dict

def normalize_key(key: str) -> str:
    return key.replace('-', '_')

def denormalize_key(key: str) -> str:
    return key.replace('_', '-')

def normalize_config(config, *, hyphenated=False, stringify_numbers=False):
    if isinstance(config, dict):
        key_function = denormalize_key if hyphenated else normalize_key
        return {
            key_function(key): normalize_config(
                value, hyphenated=hyphenated, stringify_numbers=stringify_numbers,
            )
            for key, value in config.items()
        }
    if isinstance(config, list):
        return [normalize_config(
            value, hyphenated=hyphenated, stringify_numbers=stringify_numbers,
        ) for value in config]
    if stringify_numbers and isinstance(config, (int, float)) and not isinstance(config, bool):
        return str(config)
    return config


def merge_dicts_set(dict1: Dict[str, Any], dict2: Dict[str, Any], templates_path: str = None,
    *, replace_lists: bool = False, base_path: Optional[List[str]] = None
) -> Dict[str, Any]:

    if templates_path is None:
        templates_path = os.path.join(os.path.dirname(__file__), 'templates.json')
    
    templates = load_templates(templates_path)
    
    def merge_with_template(d1: Dict[str, Any], d2: Dict[str, Any], path: List[str] = None) -> None:
        if path is None:
            path = []
            
        for key, value in d2.items():
            normalized_key = normalize_key(key)
            current_path = path + [denormalize_key(key)]
            template = get_template_def(templates, current_path)
            # if get_template_def(templates, path + ["node.def"]) != {} and template == {}:
            #     print("Take node.def")
            #     current_path = path + ["node.def"]
            #     template = get_template_def(templates, path + ["node.def"])
            if get_template_def(templates, path + ["node.tag"]) != {} and template == {}:
                current_path = path + ["node.tag"]
                template = get_template_def(templates, path + ["node.tag"])
            # Find if there's a matching normalized key in d1
            existing_key = None
            if normalized_key in d1:
                existing_key = normalized_key
            elif key in d1:
                existing_key = key
            elif key.replace('_', '-') in d1:
                existing_key = key.replace('_', '-')
            elif key.replace('-', '_') in d1:
                existing_key = key.replace('-', '_')
            
            if existing_key is not None:
                if isinstance(d1[existing_key], dict) and isinstance(value, dict):
                    merge_with_template(d1[existing_key], value, current_path)
                elif replace_lists:
                    d1[existing_key] = deepcopy(value)
                else:
                    # print("current config")
                    # print("d1", d1)
                    # print("d2", d2)
                    # print(template.get("node.def")) 
                    # print("Template:", template)
                    # print("Existing Key:", existing_key)
                    # print("Value:", value)
                    # print("Current Path:", current_path)

                    # Handle both multi-value fields and node.tag fields
                    if template.get("node.def") == "multi":
                        # Convert both values to lists if they aren't already
                        d1_val = d1[existing_key] if isinstance(d1[existing_key], list) else [d1[existing_key]]
                        d2_val = value if isinstance(value, list) else [value]
                        
                        # Merge lists and remove duplicates while preserving order
                        merged = d1_val.copy()
                        for item in d2_val:
                            if item not in merged:
                                merged.append(item)
                        d1[existing_key] = merged
                    else:
                        if "node.tag" in template or template.get("node.def") == "tag:":
                            if isinstance(d1[existing_key], dict) and isinstance(value, dict):
                                merge_with_template(d1[existing_key], value, current_path)
                            else:
                                d1_val = d1[existing_key] if isinstance(d1[existing_key], list) else [d1[existing_key]]
                                d2_val = value if isinstance(value, list) else [value]
                                
                                # Merge lists and remove duplicates while preserving order
                                merged = d1_val.copy()
                                for item in d2_val:
                                    if item not in merged:
                                        merged.append(item)
                                d1[existing_key] = merged
                        else:
                            d1[existing_key] = value
            else:
                if template.get("node.def") == "multi":
                    d1[normalized_key] = value if isinstance(value, list) else [value]
                else:
                    d1[normalized_key] = value
    
    result = deepcopy(dict1)
    merge_with_template(result, dict2, base_path)
    return result


def merge_dicts_delete(dict1: Dict[str, Any], dict2: Dict[str, Any], 
    clean_empty: bool = True, aggressive: bool = False, 
    templates_path: str = None,
    *, remove_values: bool = False, base_path: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
        Args:
        - dict1 (Dict[str, Any]): The current config dictionary.
        - dict2 (Dict[str, Any]): The set/delete config dictionary.
        - clean_empty (bool, optional): Default to True, can be set to False for certain pages.
            If True, in the final step, the algorithm will go through the config and clean up empty dicts and empty lists
            If False, the algorithm will not clean up empty dicts and empty lists
        - aggressive (bool, optional): Default to False, can be set to True for certain pages.
            If True, the algorithm will delete entire dict at certain level, can be multiple levels (includes: keys and values) if dict1/sub-dict1 is the same as dict2
            If False, the algorithm will only delete values, and keep the key, so there will be empty dicts in dict1.
        - templates_path (str, optional): Path to the templates.json file in the current folder. Defaults to None.
        - remove_values (bool, optional): Remove requested leaves and prune parents
            emptied by those deletions. An empty dict requests deletion of that
            leaf; numeric and string values compare by their CLI representation.
            Use clean_empty=False to preserve unrelated valueless flags.
        - base_path (List[str], optional): Template path for a config subtree.
        
        Returns:
        - Dict[str, Any]: The merged dictionary.
        
        How it works:
        1. If key in dict2 is not in dict1, do nothing
        2. If key in dict2 and also in dict1:
        - if value in dict2 is "all" and value in dict1 is a dict, delete the entire dict
        - if value in dict2 is not "all" and value in dict1 is a single value, delete the dict if value exists
        - if value in dict2 is not "all" and value in dict1 is a list (multi), delete the value if it exists
        3. Cleaning empty dict or empty list
        - if value in the final dict is an empty dict or empty list, delete the key

    """
    if templates_path is None:
        templates_path = os.path.join(os.path.dirname(__file__), 'templates.json')
    
    templates = load_templates(templates_path)

    
    # for those empty dicts that have the edge keys, DO NOT clean them up
    def clean_empty_values(d):
        if not isinstance(d, (dict, list)):
            return d
        if isinstance(d, list):
            return [v for v in (clean_empty_values(v) for v in d) if v]
        return {k: v for k, v in ((k, clean_empty_values(v) if k not in edge_keys else v) for k, v in d.items())
                if v or v == 0 or v is False or k in edge_keys}

    def merge_with_template(d1: Dict[str, Any], d2: Dict[str, Any], path: List[str] = None) -> None:
        if path is None:
            path = []
            
        for key, value in d2.items():
            normalized_key = normalize_key(key)
            current_path = path + [denormalize_key(key)]
            template = get_template_def(templates, current_path)
            
            # Find if there's a matching normalized key in d1
            existing_key = None
            if normalized_key in d1:
                existing_key = normalized_key
            elif key in d1:
                existing_key = key
            elif key.replace('_', '-') in d1:
                existing_key = key.replace('_', '-')
            elif key.replace('-', '_') in d1:
                existing_key = key.replace('-', '_')
            
            if existing_key is not None:
                if remove_values:
                    # Remove only the requested data. Preserve unchanged empty
                    # dictionaries, which represent valueless VyOS flags.
                    current = d1[existing_key]
                    if isinstance(value, dict) and value and isinstance(current, dict):
                        merge_with_template(current, value, current_path)
                        if not current:
                            del d1[existing_key]
                    elif isinstance(value, list):
                        values = current if isinstance(current, list) else [current]
                        removed_values = {str(item) for item in value}
                        remaining = [item for item in values if str(item) not in removed_values]
                        if remaining:
                            d1[existing_key] = remaining if isinstance(current, list) else remaining[0]
                        else:
                            del d1[existing_key]
                    elif value == {} or str(current) == str(value):
                        del d1[existing_key]
                elif value == 'all':
                    # If value is 'all', delete the entire dict at this level
                    d1[existing_key] = {}
                elif aggressive and (d1[existing_key] == value or value == {}):
                    # If value is the same, delete the entire dict at this level
                    del d1[existing_key]
                elif isinstance(d1[existing_key], dict):
                    if isinstance(value, dict):
                        merge_with_template(d1[existing_key], value, current_path)
                else:
                    if template.get("node.def") == "multi":
                        # For multi-value fields, remove specific values
                        if isinstance(d1[existing_key], list):
                            d2_val = value if isinstance(value, list) else [value]
                            d1[existing_key] = [x for x in d1[existing_key] if x not in d2_val]
                    else:
                        # For single values, delete if they match
                        if d1[existing_key] == value:
                            d1[existing_key] = {}
    
    result = deepcopy(dict1)
    merge_with_template(result, dict2, base_path)
    return clean_empty_values(result) if clean_empty else result


if __name__ == "__main__":
    config_path = "/opt/vyatta/share/vyatta-cfg/templates"
    service = "service_dns_forwarding"
    test_commands = [
        "set service dns forwarding allow-from 0.0.0.0/0",
        "set service dns forwarding cache-size 10000",
        "set service dns forwarding listen-address 192.168.1.1",
        "set service dns forwarding listen-address 192.168.1.2"
    ]

    test_commands_2 = [
        "service dns forwarding allow-from 0.0.0.0/0",
        "service dns forwarding allow-from ::1/128",
        "service dns forwarding cache-size 10000",
        "service dns forwarding listen-address 192.168.1.1",
        "service dns forwarding listen-address 192.168.1.2",
        "service dns forwarding domain example.com name-server 8.8.8.8",
        "service dns forwarding domain example.com name-server 8.8.4.4"
    ]

    invalid_commands = [
        "invalid command format"
    ]

    d1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0', '::/0'], 'cache_size': '120000000', 'config_dir': '/run/pdns-recursor', 'config_file': '/run/pdns-recursor/recursor.conf', 'dnssec': 'process-no-validate', 'domain': {'google.com': {'name_server': {'8.8.8.8': {'port': '53'}}}}, 'listen_address': ['127.0.0.2'], 'name_server': {'1.1.1.1': {'port': '53'}}, 'negative_ttl': '3600', 'port': '53', 'serve_stale_extension': '0', 'source_address': ['0.0.0.0', '::'], 'timeout': '1500'}}}}
    d2 = {'service': {'dns': {'forwarding': {'allow-from': ['0.0.0.0/0'], 'cache-size': 10000, 'listen-address': ['192.168.1.1', '192.168.1.2']}}}}
    expected_result = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0', '::/0'], 'cache_size': '10000', 'config_dir': '/run/pdns-recursor', 'config_file': '/run/pdns-recursor/recursor.conf', 'dnssec': 'process-no-validate', 'domain': {'google.com': {'name_server': {'8.8.8.8': {'port': '53'}}}}, 'listen_address': ['127.0.0.2', '192.168.1.1', '192.168.1.2'], 'name_server': {'1.1.1.1': {'port': '53'}}, 'negative_ttl': '3600', 'port': '53', 'serve_stale_extension': '0', 'source_address': ['0.0.0.0', '::'], 'timeout': '1500'}}}}
    unexpected_result = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0', '::/0'], 'cache_size': 10000, 'config_dir': '/run/pdns-recursor', 'config_file': '/run/pdns-recursor/recursor.conf', 'dnssec': 'process-no-validate', 'domain': {'google.com': {'name_server': {'8.8.8.8': {'port': '53'}}}}, 'listen_address': ['192.168.1.1', '192.168.1.2'], 'name_server': {'1.1.1.1': {'port': '53'}}, 'negative_ttl': '3600', 'port': '53', 'serve_stale_extension': '0', 'source_address': ['0.0.0.0', '::'], 'timeout': '1500'}}}}
    
    expected_new_config = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0'], 'cache_size': 10000, 'listen_address': ['192.168.1.1', '192.168.1.2']}}}}

    delete_dict1 = {'service': {'dns': {'forwarding': {'cache_size': '10000', 'allow_from': ['0.0.0.0/0', '::/0'], 'listen_address': ['127.0.0.1']}}}}
    delete_dict2 = {'service': {'dns': {'forwarding': {'cache_size': '10000'}}}}

    expected_delete_dict = {'service': {'dns': {'forwarding': {}}}}

    m1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0', '::1/128'], 'cache_size': 10000,
                                                'listen_address': ['192.168.1.1', '192.168.1.2'],
                                                'domain': {'example.com': {'name_server': '8.8.8.8'}}}}}}
    m2 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0', '::1/128'], 'cache_size': 10000,
                                                'listen_address': ['192.168.1.1', '192.168.1.2'],
                                                'domain': {'example.com': {'name_server': '8.8.4.4'}}}}}}

    dict1 = {'service': {'dns': {'forwarding': {'listen_address': ['127.0.0.1', '192.168.1.1']}}}}
    dict2 = {'service': {'dns': {'forwarding': {'listen_address': ['127.0.0.1']}}}}

    # dict1 = {'service': {'dns': {'forwarding': {'cache_size': '10000', 'listen_address': ['127.0.0.1']}}}}
    # dict2 = {'service': {'dns': {'forwarding': 'all'}}}

    expcted_result = {'service': {'dns': {'forwarding': {}}}}

    try:
        # Test process config
        # new_config = process_commands(test_commands_2)
        # print("\nNew Config:")
        # print(new_config)
        # verify = call_verify(service, new_config['service']['dns']['forwarding'])
        # print("Verify", verify)

        # Test merge config
        # merged_conf = merge_dicts_set(m1, m2)
        # print("Merged config")
        # print(merged_conf)

        # Test delete config
        # delete_dict = merge_dicts_delete(delete_dict1, delete_dict2)
        # print("\nDelete Dict:")
        # print(delete_dict)

        # verify = call_verify(service, delete_dict['service']['dns']['forwarding'])
        # verify = call_verify(service, {"config_file": {}, "config_dir": {}})
        # print(verify)

        # print("\nCurrent Config")
        # curr_config = call_get_config(service)
        # current_config = {"service": {"dns": {"forwarding": curr_config}}}
        # print(current_config)
        # print("\nMerged Config")
        # merged_config = merge_dicts_set(current_config, new_config)
        # print(merged_config)
        # print("\nVerify Config")
        # verify = call_verify(service, merged_config['service']['dns']['forwarding'])
        # print(verify)

        # delete_dict = merge_dicts_delete(delete_dict1, delete_dict2)
        # print("\nDelete Dict:")
        # print(delete_dict)

        # verify = call_verify(service, delete_dict['service']['dns']['forwarding'])
        # print("Verify", verify)

        # c1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0'], 'cache_size': '10000', 'config_dir': '/run/pdns-recursor', 'config_file': '/run/pdns-recursor/recursor.conf', 'dnssec': 'process-no-validate', 'listen_address': ['8.8.8.8'], 'negative_ttl': '3600', 'port': '53', 'serve_stale_extension': '0', 'source_address': ['0.0.0.0', '::'], 'timeout': '1500'}}}}
        # c2 = {'service': {'dns': {'forwarding': {'cache_size': 11000}}}}

        # merged_c = merge_dicts_set(c1, c2)
        # print(merged_c)

        # c3 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0'], 'listen_address': ['8.8.8.8'], 'source_address': ['0.0.0.0', '::'], 'timeout': '1500', 'serve_stale_extension': '0', 'negative_ttl': '3600', 'port': '53', 'dnssec': 'process-no-validate', 'cache_size': '10000', 'config_file': '/run/pdns-recursor/recursor.conf', 'config_dir': '/run/pdns-recursor'}}}}
        # c4 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0'], 'cache_size': '10000', 'config_dir': '/run/pdns-recursor', 'config_file': '/run/pdns-recursor/recursor.conf', 'dnssec': 'process-no-validate', 'listen_address': ['8.8.8.8'], 'negative_ttl': '3600', 'port': '53', 'serve_stale_extension': '0', 'source_address': ['0.0.0.0', '::'], 'timeout': '1500'}}}}
        # c5 = {'service': {'dns': {'forwarding': {'listen_address': ['8.8.8.8']}}}}

        # merged_c3 = merge_dicts_delete(c3, c5)
        # merged_c4 = merge_dicts_delete(c4, c5)

        # print(merged_c3)
        # print(merged_c4)

        # Modify the process_commands function, currently it is returning the wrong output
        
        # print("Test process list commands")
        # cmd_list = [
        #     'service dns dynamic name ddns1 host-name 8.8.4.4', 
        #     'service dns dynamic name ddns1 password admin', 
        #     'service dns dynamic name ddns1 protocol dyndns2', 
        #     'service dns dynamic name ddns1 server http://example.com', 
        #     'service dns dynamic name ddns1 username admin',
        #     'service dns dynamic name ddns1 ip-version ipv4'
        # ]
        # new_config = process_commands(cmd_list)
        # current_wrong_output = {'service': {'dns': {'dynamic': {'name': {'ddns1': {'ip_version': 'ipv4'}}}}}}
        # print(new_config)

        # print("Test merge delete dicts")
        # c6 = {'service': {'dns': {'forwarding': 'all'}}}
        # c7 = { 'service': { 'dns': { 'forwarding': { 'allow_from': ['0.0.0.0/0'],
        #                                 'cache_size': '10000',
        #                                 'config_dir': '/run/pdns-recursor',
        #                                 'config_file': '/run/pdns-recursor/recursor.conf',
        #                                 'dnssec': 'process-no-validate',
        #                                 'listen_address': [ '8.8.8.8',
        #                                                     '6.6.6.6',
        #                                                     '2.2.2.2',
        #                                                     '3.3.3.3',
        #                                                     '7.7.7.7',
        #                                                     '1.1.1.1'],
        #                                 'negative_ttl': '3600',
        #                                 'port': '53',
        #                                 'serve_stale_extension': '0',
        #                                 'source_address': ['0.0.0.0', '::'],
        #                                 'timeout': '1500'}}}}
        # merged_c6_7 = merge_dicts_delete(c7, c6)
        # # print(merged_c6_7)

        # new_conf = {'firewall': {'ipv4': {'prerouting': {'raw': {'default-action': 'accept', 'rule': {'5': {'action': 'ACCEPT', 'protocol': 'tcp', 'source': {'address': '10.10.10.200', 'address-mask': '255.255.255.0'}, 'destination': {'address': '10.0.0.200', 'address-mask': '255.255.255.0'}, 'inbound-interface': {'name': 'eth1'}}}}}, 'output': {'raw': {'default-action': 'accept', 'rule': {'20': {'action': 'DROP', 'protocol': 'tcp', 'source': {'address': '192.168.0.1', 'address-mask': '255.255.255.0'}, 'destination': {'port': '25'}}}}}}, 'ipv6': {'prerouting': {'raw': {'default-action': 'accept', 'rule': {'10': {'action': 'ACCEPT', 'protocol': 'tcp', 'source': {'address': '2001:db8::1', 'port': '80'}, 'destination': {'address': '2001:db8::2', 'port': '8080'}, 'inbound-interface': {'name': 'eth1'}}}}}}}}
        # curr_conf = {'firewall': {'ipv4': {'output': {'raw': {'default-action': 'accept', 'rule': {'20': {'action': 'drop', 'destination': {'port': '25'}, 'protocol': 'tcp', 'source': {'address': '192.168.0.1', 'address-mask': '255.255.255.0'}}}}}}, 'ipv6': {'prerouting': {'raw': {'default-action': 'drop', 'rule': {'10': {'action': 'accept', 'destination': {'address': '2001:db8::2', 'port': '8080'}, 'inbound-interface': {'name': 'eth1'}, 'log': {}, 'protocol': 'tcp', 'source': {'address': '2001:db8::1', 'port': '80'}}}}}}}}

        # merged_c8_9 = merge_dicts_set(curr_conf, new_conf)
        # print(merged_c8_9)
        
        # new_del_conf = {'firewall': { 
        #     'ipv4': { 'output': { 'raw': { 'rule': { '20': { 'action': 'drop'}}}}},
        #     'ipv6': { 'prerouting': { 'raw': { 'default-action': 'drop',
        #                                           'rule': { '10': { 'action': 'accept',
        #                                                             'log': { }}}}}}}}

        # merged_c10_11 = merge_dicts_delete(merged_c8_9, new_del_conf)
        # print(merged_c10_11)

        # Check the merge_dicts_delete in the process_config.py file, and figure out why:
        # the output does not include the 'server' key. For example below:

        ntp_dict = { 'allow_client': { 'address': [ '127.0.0.0/8',
                                 '169.254.0.0/16',
                                 '10.0.0.0/8',
                                 '172.16.0.0/12',
                                 '192.168.0.0/16',
                                 '::1/128',
                                 'fe80::/10',
                                 'fc00::/7']},
                    'config_file': '/run/chrony/chrony.conf',
                    'interface': 'br2',
                    'leap_second': 'ignore',
                    'listen_address': ['2.2.2.2'],
                    'ptp': {'port': '319'},
                    'server': { '1.1.1.1': {'interleave': {}, 'pool': {}},
                                '2.2.2.2': { 'interleave': {},
                                            'noselect': {},
                                            'nts': {},
                                            'pool': {},
                                            'ptp': {}},
                                'ca.poll.ntp.org': {},
                                'time1.vyos.net': {},
                                'time2.vyos.net': {},
                                'time3.vyos.net': {}},
                    'user': '_chrony'}
        empty_dict = {}

        m = merge_dicts_delete(ntp_dict, empty_dict)
        print(pprint.pprint(m, indent=4))


    except Exception as e:
        print(f"Error: {str(e)}")
