from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship

class DHCPv6PDInterface(db.Model):
    __tablename__ = 'vyos_config_dhcpv6_pd_interface'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    pd_id = Column(Integer, ForeignKey('vyos_config_dhcpv6_pd.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    address = Column(Integer, nullable=True)
    sla_id = Column(Integer, nullable=True)
    sla_length = Column(Integer, nullable=True)
    
    def serialize(self):
        return {
            'id': self.id,
            'interface_name': self.interface_name,
            'address': self.address,
            'sla_id': self.sla_id,
            'sla_length': self.sla_length
        }


class DHCPv6PrefixDelegation(db.Model):
    __tablename__ = 'vyos_config_dhcpv6_pd'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    dhcpv6_config_id = Column(Integer, ForeignKey('vyos_config_dhcpv6_option.id'), nullable=False)
    instance_id = Column(String(10), nullable=False)
    length = Column(Integer, nullable=True)
    
    interfaces = relationship('DHCPv6PDInterface', backref='prefix_delegation', cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'id': self.id,
            'instance_id': self.instance_id,
            'length': self.length,
            'interfaces': {intf.interface_name: {
                'address': intf.address,
                'sla-id': intf.sla_id,
                'sla-length': intf.sla_length
            } for intf in self.interfaces}
        }

class DHCPv4OptionConfig(db.Model):
    __tablename__ = 'vyos_config_dhcpv4_option'

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_type = Column(String(50), nullable=False)
    interface_name = Column(String(50), nullable=False)
    vlan_id = Column(String(10), nullable=True)
    
    client_id = Column(String(100), nullable=True)
    default_route_distance = Column(Integer, nullable=True)
    host_name = Column(String(255), nullable=True)
    mtu = Column(Boolean, default=False)
    no_default_route = Column(Boolean, default=False)
    user_class = Column(String(100), nullable=True)
    vendor_class_id = Column(String(100), nullable=True)

    @classmethod
    def truncate(cls):
        try:
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error truncating DHCPv4OptionConfig: {e}")

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            for intf_name, intf_config in config.items():
                if 'dhcp-options' in intf_config:
                    cls._create_from_config('ethernet', intf_name, None, intf_config['dhcp-options'])
                
                if 'vif' in intf_config:
                    for vlan_id, vlan_config in intf_config['vif'].items():
                        if 'dhcp-options' in vlan_config:
                            cls._create_from_config('ethernet', intf_name, vlan_id, vlan_config['dhcp-options'])
            
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing DHCPv4OptionConfig: {e}")
            raise e

    @classmethod
    def _create_from_config(cls, intf_type, intf_name, vlan_id, dhcp_config):
        new_config = cls(
            interface_type=intf_type,
            interface_name=intf_name,
            vlan_id=vlan_id,
            client_id=dhcp_config.get('client-id'),
            default_route_distance=int(dhcp_config['default-route-distance']) if 'default-route-distance' in dhcp_config else None,
            host_name=dhcp_config.get('host-name'),
            mtu='mtu' in dhcp_config,
            no_default_route='no-default-route' in dhcp_config,
            user_class=dhcp_config.get('user-class'),
            vendor_class_id=dhcp_config.get('vendor-class-id')
        )
        db.session.add(new_config)

    def serialize(self):
        return {
            'id': self.id,
            'interface_type': self.interface_type,
            'interface_name': self.interface_name,
            'vlan_id': self.vlan_id,
            'client_id': self.client_id,
            'default_route_distance': self.default_route_distance,
            'host_name': self.host_name,
            'mtu': self.mtu,
            'no_default_route': self.no_default_route,
            'user_class': self.user_class,
            'vendor_class_id': self.vendor_class_id
        }
    
    def to_vyos_format(self):
        
        result = {}
        
        if self.client_id:
            result['client-id'] = self.client_id
        if self.default_route_distance:
            result['default-route-distance'] = str(self.default_route_distance)
        if self.host_name:
            result['host-name'] = self.host_name
        if self.mtu:
            result['mtu'] = {}
        if self.no_default_route:
            result['no-default-route'] = {}
        if self.user_class:
            result['user-class'] = self.user_class
        if self.vendor_class_id:
            result['vendor-class-id'] = self.vendor_class_id
        
        return result


class DHCPv6OptionConfig(db.Model):
    __tablename__ = 'vyos_config_dhcpv6_option'

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_type = Column(String(50), nullable=False)
    interface_name = Column(String(50), nullable=False)
    vlan_id = Column(String(10), nullable=True)
    
    duid = Column(String(100), nullable=True)
    no_release = Column(Boolean, default=False)
    parameters_only = Column(Boolean, default=False)
    rapid_commit = Column(Boolean, default=False)
    temporary = Column(Boolean, default=False)
    
    prefix_delegations = relationship('DHCPv6PrefixDelegation', backref='dhcpv6_config', cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        try:
            db.session.query(DHCPv6PDInterface).delete()
            db.session.query(DHCPv6PrefixDelegation).delete()
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error truncating DHCPv6OptionConfig: {e}")

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            for intf_name, intf_config in config.items():
                if 'dhcpv6-options' in intf_config:
                    cls._create_from_config('ethernet', intf_name, None, intf_config['dhcpv6-options'])
                
                if 'vif' in intf_config:
                    for vlan_id, vlan_config in intf_config['vif'].items():
                        if 'dhcpv6-options' in vlan_config:
                            cls._create_from_config('ethernet', intf_name, vlan_id, vlan_config['dhcpv6-options'])
            
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing DHCPv6OptionConfig: {e}")
            raise e

    @classmethod
    def _create_from_config(cls, intf_type, intf_name, vlan_id, dhcpv6_config):
        new_config = cls(
            interface_type=intf_type,
            interface_name=intf_name,
            vlan_id=vlan_id,
            duid=dhcpv6_config.get('duid'),
            no_release='no-release' in dhcpv6_config,
            parameters_only='parameters-only' in dhcpv6_config,
            rapid_commit='rapid-commit' in dhcpv6_config,
            temporary='temporary' in dhcpv6_config
        )
        db.session.add(new_config)
        db.session.flush()  
        
        if 'pd' in dhcpv6_config:
            for instance_id, pd_config in dhcpv6_config['pd'].items():
                pd_entry = DHCPv6PrefixDelegation(
                    dhcpv6_config_id=new_config.id,
                    instance_id=instance_id,
                    length=int(pd_config['length']) if 'length' in pd_config else None
                )
                db.session.add(pd_entry)
                db.session.flush()
                
                if 'interface' in pd_config:
                    for intf_name, intf_config in pd_config['interface'].items():
                        pd_intf = DHCPv6PDInterface(
                            pd_id=pd_entry.id,
                            interface_name=intf_name,
                            address=int(intf_config['address']) if 'address' in intf_config else None,
                            sla_id=int(intf_config['sla-id']) if 'sla-id' in intf_config else None,
                            sla_length=int(intf_config['sla-length']) if 'sla-length' in intf_config else None
                        )
                        db.session.add(pd_intf)

    def serialize(self):
        return {
            'id': self.id,
            'interface_type': self.interface_type,
            'interface_name': self.interface_name,
            'vlan_id': self.vlan_id,
            'duid': self.duid,
            'no_release': self.no_release,
            'parameters_only': self.parameters_only,
            'rapid_commit': self.rapid_commit,
            'temporary': self.temporary,
            'prefix_delegations': [pd.serialize() for pd in self.prefix_delegations]
        }
    
    def to_vyos_format(self):
        
        result = {}
        
        if self.duid:
            result['duid'] = self.duid
        if self.no_release:
            result['no-release'] = {}
        if self.parameters_only:
            result['parameters-only'] = {}
        if self.rapid_commit:
            result['rapid-commit'] = {}
        if self.temporary:
            result['temporary'] = {}
        
        if self.prefix_delegations:
            result['pd'] = {}
            for pd in self.prefix_delegations:
                pd_data = {}
                if pd.length:
                    pd_data['length'] = str(pd.length)
                if pd.interfaces:
                    pd_data['interface'] = {}
                    for intf in pd.interfaces:
                        intf_data = {}
                        if intf.address is not None:
                            intf_data['address'] = str(intf.address)
                        if intf.sla_id is not None:
                            intf_data['sla-id'] = str(intf.sla_id)
                        if intf.sla_length is not None:
                            intf_data['sla-length'] = str(intf.sla_length)
                        if intf_data:
                            pd_data['interface'][intf.interface_name] = intf_data
                result['pd'][pd.instance_id] = pd_data
        
        return result
