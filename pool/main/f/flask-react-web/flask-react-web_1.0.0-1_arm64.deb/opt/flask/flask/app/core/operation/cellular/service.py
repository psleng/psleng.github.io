import pprint
from uuid import uuid4

from flask import session

from app.core.api.http.http_request import Action
from app.core.models import InterfaceConfig
from app.core.operation.cellular.command_wwan import WWANCommand
from app.core.operation.cellular.models import WWANInterfaceConfig
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager


def fetch_wwan_config(provider, data=None):
    wwan_ifaces = WWANInterfaceConfig.query.all()
    return [iface.serialize() for iface in wwan_ifaces]


def _generate_wwan_commands(current_config, new_config, diff, name):
    set_cmd = WWANCommand(operator='set', resource='interfaces')
    set_cmds = set_cmd.generate_commands(
        {name: diff.get('created') or {}},
        {name: current_config},
        {name: new_config}
    )

    delete_cmd = WWANCommand(operator='delete', resource='interfaces')
    delete_cmds = delete_cmd.generate_commands(
        {name: diff.get('deleted') or {}},
        {name: current_config},
        {name: new_config}
    )

    return {
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }


def update_wwan_by_name(provider, data):
    print("Update WWAN by name:")
    print(pprint.pformat(data, indent=2, width=80))

    username = session['username']
    name = data.get('name')
    current_config = data.get('current') or {}
    new_config = data.get('new') or {}
    diff = data.get('diff') or {}

    command_data = _generate_wwan_commands(current_config, new_config, diff, name)
    set_cmds = command_data.get('set_cmds') or []
    delete_cmds = command_data.get('delete_cmds') or []
    cmds = list(set(delete_cmds)) + list(set(set_cmds))

    raw_current_config = provider.verify_service.query_interface_config("cellular", name) or current_config or {}
    merged_del_config = merge_dicts_delete(raw_current_config, diff.get('deleted') or {}, clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, diff.get('created') or {})

    print("Merged WWAN config:")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify_config = dict(merged_config)
        verify_config['ifname'] = name
        verify = provider.verify_service.query_interface_verify("cellular", name, verify_config)

    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": verify, "cmd": cmds}]

    InterfaceConfig.upsert({
        'wwan': {
            name: merged_config
        }
    })
    WWANInterfaceConfig.upsert_many({name: merged_config})

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update WWAN",
            "content": "WWAN interface is successfully updated"
        }
    )

    result = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=4))
    if cmds:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        result.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    return result
