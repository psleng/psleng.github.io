from typing import Any, Dict


def _value(config: Any, *keys: str, default: Any = '') -> Any:
    if not isinstance(config, dict):
        return default
    for key in keys:
        if key in config:
            return config.get(key)
    return default


def _flag_enabled(config: Any, *keys: str) -> bool:
    if not isinstance(config, dict):
        return False
    for key in keys:
        if key in config:
            return config.get(key) is not False and config.get(key) is not None
    return False


def empty_email_frontend() -> Dict[str, Any]:
    return {'activeProfile': '', 'profiles': [], 'recipients': []}


def serialize_email_config(config: Any) -> Dict[str, Any]:
    result = empty_email_frontend()
    if not isinstance(config, dict):
        return result

    result['activeProfile'] = str(_value(config, 'active-profile', 'active_profile') or '')
    profiles = config.get('profile') or {}
    if isinstance(profiles, dict):
        for profile_name, profile_data in profiles.items():
            profile = profile_data if isinstance(profile_data, dict) else {}
            oauth2 = profile.get('oauth2') if isinstance(profile.get('oauth2'), dict) else {}
            raw_port = _value(profile, 'port', default=None)
            try:
                port = int(raw_port) if raw_port not in (None, '') else ''
            except (TypeError, ValueError):
                port = ''
            result['profiles'].append({
                'name': str(profile_name),
                'authentication': str(_value(profile, 'authentication', default='password') or 'password'),
                'caFile': str(_value(profile, 'ca-file', 'ca_file') or ''),
                'fromEmail': str(_value(profile, 'from-email', 'from_email') or ''),
                'noValidateCert': _flag_enabled(profile, 'no-validate-cert', 'no_validate_cert'),
                'oauth2': {
                    'clientId': str(_value(oauth2, 'client-id', 'client_id') or ''),
                    'clientSecret': str(_value(oauth2, 'client-secret', 'client_secret') or ''),
                    'refreshToken': str(_value(oauth2, 'refresh-token', 'refresh_token') or ''),
                    'scope': str(_value(oauth2, 'scope') or ''),
                    'tokenUrl': str(_value(oauth2, 'token-url', 'token_url') or ''),
                },
                'password': str(_value(profile, 'password') or ''),
                'port': port,
                'security': str(_value(profile, 'security', default='starttls') or 'starttls'),
                'smtpHost': str(_value(profile, 'smtp-host', 'smtp_host') or ''),
                'username': str(_value(profile, 'username') or ''),
            })

    recipients = config.get('recipient') or {}
    if isinstance(recipients, dict):
        for recipient_name, recipient_data in recipients.items():
            recipient = recipient_data if isinstance(recipient_data, dict) else {}
            result['recipients'].append({
                'name': str(recipient_name),
                'email': str(_value(recipient, 'email') or ''),
                'enabled': _flag_enabled(recipient, 'enable'),
                'subject': str(_value(recipient, 'subject') or ''),
            })
    return result


def _text(value: Any) -> str:
    return str(value or '').strip()


def _secret(value: Any) -> str:
    return str(value or '')


def _parse_oauth2_to_vyos_config(data: Any) -> Dict[str, Any]:
    if not isinstance(data, dict):
        return {}

    oauth2_config: Dict[str, Any] = {}
    for frontend_key, vyos_key in (
        ('clientId', 'client-id'),
        ('refreshToken', 'refresh-token'),
        ('scope', 'scope'),
        ('tokenUrl', 'token-url'),
    ):
        value = _text(data.get(frontend_key))
        if value:
            oauth2_config[vyos_key] = value

    client_secret = _secret(data.get('clientSecret'))
    if client_secret:
        oauth2_config['client-secret'] = client_secret
    return oauth2_config


def _parse_profiles_to_vyos_config(data: Dict[str, Any]) -> Dict[str, Any]:
    profiles_config: Dict[str, Any] = {}
    profiles = data.get('profiles') or []
    if not isinstance(profiles, list):
        return profiles_config

    for profile in profiles:
        if not isinstance(profile, dict):
            continue

        name = _text(profile.get('name'))
        if not name:
            continue

        authentication = _text(profile.get('authentication')) or 'password'
        security = _text(profile.get('security')) or 'starttls'
        port = profile.get('port')
        profile_config: Dict[str, Any] = {
            'authentication': authentication,
            'security': security,
        }
        if port not in (None, ''):
            profile_config['port'] = str(port)

        for frontend_key, vyos_key in (
            ('caFile', 'ca-file'),
            ('fromEmail', 'from-email'),
            ('smtpHost', 'smtp-host'),
            ('username', 'username'),
        ):
            value = _text(profile.get(frontend_key))
            if value:
                profile_config[vyos_key] = value

        password = _secret(profile.get('password'))
        if password:
            profile_config['password'] = password
        if profile.get('noValidateCert') is True:
            profile_config['no-validate-cert'] = {}

        oauth2_config = _parse_oauth2_to_vyos_config(profile.get('oauth2'))
        if oauth2_config:
            profile_config['oauth2'] = oauth2_config

        profiles_config[name] = profile_config

    return profiles_config


def _parse_recipients_to_vyos_config(data: Dict[str, Any]) -> Dict[str, Any]:
    recipients_config: Dict[str, Any] = {}
    recipients = data.get('recipients') or []
    if not isinstance(recipients, list):
        return recipients_config

    for recipient in recipients:
        if not isinstance(recipient, dict):
            continue

        name = _text(recipient.get('name'))
        if not name:
            continue

        recipient_config: Dict[str, Any] = {}
        email = _text(recipient.get('email'))
        subject = _text(recipient.get('subject'))
        if email:
            recipient_config['email'] = email
        if recipient.get('enabled') is True:
            recipient_config['enable'] = {}
        if subject:
            recipient_config['subject'] = subject
        recipients_config[name] = recipient_config

    return recipients_config


def parse_to_vyos_config(data: Dict[str, Any]) -> Dict[str, Any]:
    vyos_config: Dict[str, Any] = {}

    active_profile = _text(data.get('activeProfile'))
    if active_profile:
        vyos_config['active-profile'] = active_profile

    profiles = _parse_profiles_to_vyos_config(data)
    if profiles:
        vyos_config['profile'] = profiles

    recipients = _parse_recipients_to_vyos_config(data)
    if recipients:
        vyos_config['recipient'] = recipients

    return vyos_config


def parse_to_vyos_config_verify(data: Dict[str, Any]) -> Dict[str, Any]:
    profiles: Dict[str, Any] = {}
    frontend_profiles = data.get('profiles') or []
    if isinstance(frontend_profiles, list):
        for raw_profile in frontend_profiles:
            if not isinstance(raw_profile, dict):
                continue

            name = _text(raw_profile.get('name'))
            if not name:
                continue

            raw_oauth2 = raw_profile.get('oauth2')
            oauth2 = raw_oauth2 if isinstance(raw_oauth2, dict) else {}
            profiles[name] = {
                'smtp_host': _text(raw_profile.get('smtpHost')),
                'port': str(raw_profile.get('port') or 587),
                'authentication': _text(raw_profile.get('authentication')) or 'password',
                'username': _text(raw_profile.get('username')),
                'password': _secret(raw_profile.get('password')),
                'security': _text(raw_profile.get('security')) or 'starttls',
                'validate_cert': raw_profile.get('noValidateCert') is not True,
                'ca_file': _text(raw_profile.get('caFile')) or None,
                'from_email': _text(raw_profile.get('fromEmail')),
                'oauth2': {
                    'token_url': _text(oauth2.get('tokenUrl')),
                    'client_id': _text(oauth2.get('clientId')),
                    'client_secret': _secret(oauth2.get('clientSecret')),
                    'refresh_token': _text(oauth2.get('refreshToken')),
                    'scope': _text(oauth2.get('scope')),
                },
            }

    recipients: Dict[str, Any] = {}
    frontend_recipients = data.get('recipients') or []
    if isinstance(frontend_recipients, list):
        for raw_recipient in frontend_recipients:
            if not isinstance(raw_recipient, dict):
                continue
            name = _text(raw_recipient.get('name'))
            if name:
                recipients[name] = {
                    'email': _text(raw_recipient.get('email')),
                    'subject': _text(raw_recipient.get('subject')),
                    'enabled': raw_recipient.get('enabled') is True,
                }

    return {
        'active_profile': _text(data.get('activeProfile')),
        'profiles': profiles,
        'recipients': recipients,
    }


def parse_vyos_config_to_verify(data: Dict[str, Any]) -> Dict[str, Any]:
    return parse_to_vyos_config_verify(serialize_email_config(data))


def parse_to_email_config(data: Dict[str, Any]) -> Dict[str, Any]:
    return parse_to_vyos_config(data)
