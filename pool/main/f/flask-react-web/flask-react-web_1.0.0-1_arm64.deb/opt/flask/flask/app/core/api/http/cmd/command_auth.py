import json

from app.core.api.http.cmd.command import Command
from app.log.logger import logger

def format_fullname(description: str) -> str:
    return description.replace(' ', '_')


class AuthCommand(Command):

    """
        Command class for Authentication command
        Support the following VyOS Commands:

        Set/delete system login user <user-name> full-name <full-name> 
        Set/delete system login user <user-name> disable 
        Set/delete system login user <user_name> operator group <group_name>
        set system login user <name-name> authentication plaintext-password <password> 

    """
    
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource='system')
            self.attributes = {}
            self.cmds = []
            self.vyos_cmds = []
            
        except Exception as e:
            print(f"Error initializing DHCP command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        return json.dumps({"op": self.operator, "path": list(path_elements)}, separators=(',', ':'))

    def generate(self, *args):
        if args:
            last_arg = args[-1]
            if last_arg != "all":
                self.cmds.append(self._build_command(*args))
            else:
                self.cmds.append(self._build_command(*args[:-1]))
            self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _role_to_operator_group(self, role):
        if not role:
            return None
        role_str = str(role).strip().lower()
        if role_str == 'operator':
            return 'default'
        if role_str == 'operator+':
            return 'super-operator'
        return None

    def _process_user(self, username, user_data):
        if 'expiry-time' in user_data:
            # User Linux Command instead
            return
        if 'authentication' in user_data:
            if 'plaintext-password' in user_data['authentication']:
                self.generate('system', 'login', 'user', username, 'authentication', 'plaintext-password', user_data['authentication']['plaintext-password'])
        if 'disable' in user_data and (user_data['disable'] is True or user_data['disable'] == {}):
            self.generate('system', 'login', 'user', username, 'disable')
        if 'type' in user_data:
            operator_group = self._role_to_operator_group(user_data.get('type'))
            if operator_group:
                self.generate('system', 'login', 'user', username, 'operator', 'group', operator_group)
        if 'full-name' in user_data:
                self.generate('system', 'login', 'user', username, 'full-name', format_fullname(user_data['full-name']))   
                
    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            if 'login' not in data:
                return []
            if 'user' not in data['login']:
                return []
            for username, user_data in data['login']['user'].items():
                self._process_user(username, user_data)
                if self.operator == 'delete':
                    deleted_role = user_data.get('type')
                    deleted_operator_group = self._role_to_operator_group(deleted_role)
                    if deleted_operator_group:
                        self.generate('system', 'login', 'user', username, 'operator', 'group', deleted_operator_group)

                if self.operator == 'delete' and new_config and 'login' in new_config and \
                    'user' in new_config['login'] and username not in new_config['login']['user']:
                    self.generate('system', 'login', 'user', username, 'all')   
            return self.cmds
            
        except Exception as e:
            logger.debug("Exception generating Auth Command:")
            logger.debug(str(e))
            return []


if __name__ == "__main__":
    test_auth = {
        "login": {
            "user": {
                "test_user": {
                    "authentication": {
                        "plaintext-password": "testing123"
                    },
                    "type": "administrator",
                    "disable": {},
                    "full-name": "TestName"
                }
            }
        } 
    }
    cmd_auth = AuthCommand(operation="set", resource="system")
    commands = cmd_auth.generate_commands(test_auth)
    print("Auth commands:")
    for cmd in commands:
        print(cmd)
