import pytest

test_verify_success_1 = pytest.param(
    (
        {
            "dns": {
                "forwarding": {
                    "allow-from": ["0.0.0.0/0"],
                    "dhcp": ["eth0", "br1"],
                    "domain": {
                        "dns.example.com": {
                            "name-server": ["10.0.0.1", "203.0.113.0"]
                        }
                    },
                    "listen-address": ["192.168.100.1", "192.168.1.1"]
                }
            }
        }
    ),
    id="test_verify_success_dns_1"
)

test_verify_success = [
    test_verify_success_1,
]

test_verify_failed_1 = pytest.param(
    (
        {
            "dns": {
                "forwarding": {
                    "domain": {
                        "dns.example.com": {
                            "name-server": ["999.999.999.999"]
                        }
                    }
                }
            }
        }
    ),
    id="test_verify_failed_1"
)

test_verify_failed = [
    test_verify_failed_1,
]
