from uuid import uuid4
from logging import getLogger, DEBUG
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_PKI
import pprint
from flask import session
from app.core.api.http.http_request import Action
from app.socket.socket_manager import socket_manager
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.core.system.keycert.command_keycert import KeyCertCommand

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def request_body(data):
    return {
        "key": str(uuid4()),
        "key_type": data.key_type,
        "key_bit": data.key_bit,
        "country_code": data.country_code,
        "state": data.state,
        "locality": data.locality,
        "org_name": data.org_name,
        "com_name": data.com_name,
        "valid_days": data.valid_days,
        "passphrase": data.passphrase,
        "name": str(uuid4()),
        "install": False,
        "file": False,
        "encrypt_key": True
    }

def generate_pki_ca(provider, data):

    key = provider.graphql_service.send_mutation_request(
        function_name='GeneratePkiCa', 
        mutation_name='GeneratePkiCaPkiMutation', 
        input_name='GeneratePkiCaPkiMutationInput', 
        data=request_body(data), 
        verify=False
    ) 
    return key.json()['data']


def generate_pki_certificate(provider, data):
    
    body = request_body(data)   
    body['subject_alt_names'] = getattr(data, 'subject_alt_names', None) or None 
    if hasattr(data, 'self_signed'):
        body["self_sign"] = data.self_signed
    
    if hasattr(data, 'ca_name') and data.ca_name and data.ca_name.strip():
        body["ca_name"] = data.ca_name.strip()
    else:
        body["ca_name"] = ""
    
    if hasattr(data, 'passphrase') and data.passphrase and data.passphrase.strip() != "":
        body['encrypt_key'] = True
    elif hasattr(data, 'passphrase') and (not data.passphrase or data.passphrase.strip() == ""):
        body['encrypt_key'] = False

    key = provider.graphql_service.send_mutation_request(
        function_name='GeneratePkiCert', 
        mutation_name='GeneratePkiCertificatePkiMutation', 
        input_name='GeneratePkiCertificatePkiMutationInput', 
        data=body, 
        verify=False
    ) 
    return key.json()['data']


def generate_pki_crl(provider, data):
    ca_name = getattr(data, 'ca_name', None)
    if ca_name is None or str(ca_name).strip() == "":
        return Exception("CRL generation failed: 'ca_name' is required")

    body = {
        "ca_name": str(ca_name).strip(),
        "install": False,
        "file": False,
    }

    key = provider.graphql_service.send_mutation_request(
        function_name='GeneratePkiCrl', 
        mutation_name='GeneratePkiCrlPkiMutation', 
        input_name='GeneratePkiCrlPkiMutationInput', 
        data=body, 
        verify=False
    ) 

    res = key.json()
    print(f"CRL generation response: {res}")

    if isinstance(res, dict) and res.get('errors'):
        return Exception(res.get('errors'))

    data_block = res.get('data') if isinstance(res, dict) else None
    if data_block is None:
        return Exception(f"CRL generation failed: GraphQL returned null data. Response: {res}")

    return data_block


def generate_pki_dh(provider, data):
    body = {
        "key": str(uuid4()),
        "key_bit": data.key_bit,
        "name": str(uuid4()),
        "install": False,
        "file": False
    }
    
    logger.debug(f"DH generation request body: {body}")
    
    key = provider.graphql_service.send_mutation_request(
        function_name='GeneratePkiDh', 
        mutation_name='GeneratePkiDhPkiMutation', 
        input_name='GeneratePkiDhPkiMutationInput', 
        data=body, 
        verify=False
    )
    
    logger.debug(f"DH generation response: {key.json()}")
    return key.json()['data']


def generate_pki_key_pair(provider, data):
    passphrase = ""
    if hasattr(data, 'passphrase') and data.passphrase is not None:
        passphrase = str(data.passphrase)

    body = {
        "key_type": data.key_type,
        "key_bit": data.key_bit,
        "name": str(getattr(data, 'name', '') or uuid4()),
        "install": bool(getattr(data, 'install', False)),
        "file": bool(getattr(data, 'file', False)),
        "passphrase": passphrase,
        "encrypt_key": bool(getattr(data, 'encrypt_key', False)),
    }

    key = provider.graphql_service.send_mutation_request(
        function_name='GeneratePkiKeyPair', 
        mutation_name='GeneratePkiKeyPairPkiMutation', 
        input_name='GeneratePkiKeyPairPkiMutationInput', 
        data=body, 
        verify=False
    ) 
    res = key.json()
    print(f"Key Pair generation response: {res}")

    if isinstance(res, dict) and res.get('errors'):
        return Exception(res.get('errors'))

    data_block = res.get('data') if isinstance(res, dict) else None
    if data_block is None:
        return Exception(f"Key Pair generation failed: GraphQL returned null data. Response: {res}")

    return data_block

def _extract_pki_query_result(response_json, query_name):
    query_data = response_json.get('data', {}).get(query_name, {})
    return {
        'success': bool(query_data.get('success')),
        'errors': query_data.get('errors'),
        'result': query_data.get('data', {}).get('result', []),
    }


def fetch_keycert_authorities_monitor(provider, data=None):
    response = provider.graphql_service.send_request(
        function_name='ShowAuthorityPkiQuery',
        data={},
        verify=False
    )

    authority = _extract_pki_query_result(response.json(), 'ShowAuthorityPkiQuery')
    result = authority.get('result')

    return {
        'authorities': result if isinstance(result, list) else [],
        'success': authority.get('success'),
        'errors': authority.get('errors'),
    }


def fetch_keycert_certificates_monitor(provider, data=None):
    response = provider.graphql_service.send_request(
        function_name='ShowCertificatePkiQuery',
        data={},
        verify=False
    )

    certificate = _extract_pki_query_result(response.json(), 'ShowCertificatePkiQuery')
    certificate_result = certificate.get('result')

    return {
        'certificates': certificate_result if isinstance(certificate_result, list) else [],
        'success': certificate.get('success'),
        'errors': certificate.get('errors'),
    }


def update_keycert(provider, data):
    username = session['username']
    diff = data.get('diff')
    current_pki = data.get('current')
    new_pki = data.get('new')

    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    print("Current raw config: ")
    print(pprint.pformat(current_pki, indent=2, width=80))

    print("New raw config: ")
    print(pprint.pformat(new_pki, indent=2, width=80))

    print("Diff raw config: ")
    print(pprint.pformat(diff, indent=2, width=80))
    r = []
    ## Generate set commands
    set_cmds = []
    keycert_set_cmd = KeyCertCommand(operator='set', resource='pki')
    set_cmds = keycert_set_cmd.generate_commands(diff['created'], current_pki, new_pki)
    sc = keycert_set_cmd.get_commands()
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    ## Generate delete commands
    delete_cmds = []
    keycert_del_cmd = KeyCertCommand(operator='delete', resource='pki')
    delete_cmds = keycert_del_cmd.generate_commands(diff['deleted'], current_pki, new_pki)
    dc = keycert_del_cmd.get_commands()
    new_del_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    ## Validate commands
    service = "pki"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current vyos config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('pki', {}))
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    # Update DB

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update KeyCert",
                "content": "KeyCert is successfully updated"
            }
    )

    excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r


def verify_keycert(provider, data):
    
    print("Verify KeyCert data:", data)
    service = "pki"
    verify = provider.verify_service.call_verify(service, data)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify


def fetch_keycert(provider, data):
     
    logger.debug("Fetching keycert config...")
    keycert_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_PKI, verify=False)
    data = keycert_response.json()['data']
    return data
