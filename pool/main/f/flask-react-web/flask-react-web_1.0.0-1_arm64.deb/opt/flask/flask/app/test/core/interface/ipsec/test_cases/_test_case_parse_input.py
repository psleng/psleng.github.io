import pytest
import json

test_case_valid = [
    pytest.param(
        {
            "valid_json": json.dumps({
                "type": "ipsec",
                "general": {
                    "siteToSite": {
                        "peers": [
                            {
                                "name": "peer-1",
                                "description": "Test peer",
                                "enabled": True,
                                "authentication": {
                                    "mode": "pre-shared-secret",
                                    "localId": "local-id",
                                    "remoteId": "remote-id"
                                },
                                "ikeGroup": "ike-group-1",
                                "localAddress": "192.168.1.1",
                                "remoteAddress": ["192.168.2.1"],
                                "tunnels": [
                                    {
                                        "id": "1",
                                        "enabled": True,
                                        "espGroup": "esp-group-1",
                                        "local": {
                                            "prefix": ["10.0.0.0/24"]
                                        },
                                        "remote": {
                                            "prefix": ["10.0.1.0/24"]
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                },
                "security": {
                    "presharedKeys": [
                        {
                            "name": "psk-1",
                            "id": "test-id",
                            "secret": "test-secret",
                            "secretType": "plaintext"
                        }
                    ],
                    "ikeGroups": [
                        {
                            "name": "ike-group-1",
                            "proposals": []
                        }
                    ],
                    "espGroups": [
                        {
                            "name": "esp-group-1",
                            "proposals": []
                        }
                    ]
                }
            })
        },
        id="valid_ipsec_json_1"
    ),
    pytest.param(
        {
            "valid_json": json.dumps({
                "type": "ipsec",
                "general": {
                    "remoteAccess": {
                        "connections": [
                            {
                                "name": "conn-1",
                                "enabled": True,
                                "ikeGroup": "ike-grp-1",
                                "espGroup": "esp-grp-1",
                                "localAddress": "any",
                                "pools": ["pool-1"],
                                "authentication": {
                                    "clientMode": "eap-mschapv2",
                                    "serverMode": "pre-shared-secret",
                                    "preSharedSecret": "secret"
                                }
                            }
                        ],
                        "pools": [
                            {
                                "name": "pool-1",
                                "prefix": "10.0.0.0/24",
                                "nameServers": ["8.8.8.8"]
                            }
                        ]
                    }
                },
                "security": {
                    "ikeGroups": [
                        {
                            "name": "ike-grp-1",
                            "proposals": []
                        }
                    ],
                    "espGroups": [
                        {
                            "name": "esp-grp-1",
                            "proposals": []
                        }
                    ]
                }
            })
        },
        id="valid_ipsec_remote_access_json"
    ),
    pytest.param(
        {
            "valid_json": json.dumps({
                "type": "ipsec",
                "security": {
                    "ikeGroups": [
                        {
                            "name": "ike-grp-1",
                            "keyExchange": "ikev2",
                            "lifetime": 28800,
                            "proposals": [
                                {
                                    "proposal": 1,
                                    "dhGroup": 14,
                                    "encryption": "aes256",
                                    "hash": "sha256"
                                }
                            ],
                            "advanced": {
                                "disableMobike": True,
                                "ikev2Reauth": True
                            }
                        }
                    ],
                    "espGroups": [
                        {
                            "name": "esp-grp-1",
                            "lifetime": 3600,
                            "mode": "tunnel",
                            "pfs": "dh-group14",
                            "proposals": [
                                {
                                    "proposal": 1,
                                    "encryption": "aes256",
                                    "hash": "sha256"
                                }
                            ]
                        }
                    ]
                }
            })
        },
        id="valid_ipsec_security_groups_json"
    )
]

test_case_invalid = [
    pytest.param(
        {
            "invalid_json": json.dumps({
                "type": "ipsec",
                "general": {
                    "siteToSite": {
                        "peers": [
                            {
                                "name": None  # Invalid: name cannot be None
                            }
                        ]
                    }
                }
            })
        },
        id="invalid_ipsec_json_1"
    )
]

test_case_minimal = [
    pytest.param(
        {
            "minimal_json": json.dumps({
                "type": "ipsec"
            })
        },
        id="minimal_ipsec_json_1"
    )
]

test_case_comparison = [
    pytest.param(
        {
            "new_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            }
                        }
                    }
                }
            },
            "current_config": {},
            "expected_diff": {
                "created": {
                    "site-to-site": {
                        "peer": {
                            "peer-1": {
                                "authentication": {
                                    "mode": "pre-shared-secret"
                                }
                            }
                        }
                    }
                },
                "deleted": {}
            }
        },
        id="ipsec_comparison_1"
    ),
    pytest.param(
        {
            "new_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "ike-group": "ike-grp-1",
                            "esp-group": "esp-grp-1"
                        }
                    }
                }
            },
            "current_config": {},
            "expected_diff": {
                "created": {
                    "remote-access": {
                        "connection": {
                            "conn-1": {
                                "ike-group": "ike-grp-1",
                                "esp-group": "esp-grp-1"
                            }
                        }
                    }
                },
                "deleted": {}
            }
        },
        id="ipsec_comparison_remote_access"
    ),
    pytest.param(
        {
            "new_config": {
                "ike-group": {
                    "ike-grp-2": {
                        "key-exchange": "ikev2"
                    }
                }
            },
            "current_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "key-exchange": "ikev1"
                    }
                }
            },
            "expected_diff": {
                "created": {
                    "ike-group": {
                        "ike-grp-2": {
                            "key-exchange": "ikev2"
                        }
                    }
                },
                "deleted": {
                    "ike-group": {
                        "ike-grp-1": {
                            "key-exchange": "ikev1"
                        }
                    }
                }
            }
        },
        id="ipsec_comparison_ike_groups"
    )
]
