import json

from app.core.api.http.cmd.command import Command


class SerialCommand(Command):

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'service'),
        )
        self.attributes = {'service': {'serial': {}}}
        self.cmds = []
        self.vyos_cmds = []
        for key, value in kwargs.items():
            if key in self.attributes:
                self.attributes[key] = value

    def _build_command(self, *path_elements):
        return json.dumps({'op': self.operator, 'path': list(path_elements)})

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _extract_serial_config(self, data):
        if not isinstance(data, dict):
            return {}
        service = data.get('service')
        if isinstance(service, dict):
            return service.get('serial') or {}
        if isinstance(data.get('serial'), dict):
            return data['serial']
        return data

    def _generate_value(self, base_path, config, key):
        value = config.get(key)
        if value is not None and not isinstance(value, dict) and str(value) != '':
            if self.operator == 'delete':
                self.generate(*base_path, key)
            else:
                self.generate(*base_path, key, str(value))

    def _generate_leaf(self, base_path, config, key):
        if key in config and (self.operator == 'delete' or config[key] is not False):
            self.generate(*base_path, key)

    def _generate_multi(self, base_path, config, key):
        values = config[key] if isinstance(config[key], list) else [config[key]]
        for value in values:
            self.generate(*base_path, key, str(value))

    def _generate_nested_config(self, base_path, config, new_config=None):
        if not isinstance(config, dict) or not config:
            self.generate(*base_path)
            return
        for key, value in config.items():
            path = [*base_path, str(key)]
            if self.operator == 'delete' and new_config is not None and key not in new_config:
                self.generate(*path)
            elif isinstance(value, dict):
                child = new_config.get(key, {}) if isinstance(new_config, dict) else None
                self._generate_nested_config(path, value, child)
            elif isinstance(value, list):
                self._generate_multi(base_path, config, key)
            else:
                self._generate_value(base_path, config, key)

    def _process_global_parameters_config(self, config, new_config):
        self._generate_nested_config(['service', 'serial', 'global-parameters'], config, new_config)

    def _process_port_config(self, base_path, config, new_config):
        if config == 'all' or not isinstance(config, dict) or not config:
            self.generate(*base_path)
            return
        for key in ('description', 'profile', 'speed', 'data-bits', 'parity', 'stop-bits'):
            if key in config:
                self._generate_value(base_path, config, key)
        for key in ('disable', 'discard-chars-rxd-with-errors'):
            if key in config:
                self._generate_leaf(base_path, config, key)
        for key in (
            'protocol', 'login', 'modbus-gateway', 'nine-bits', 'ppp', 'remote-printer',
            'serial-tunnel', 'slip', 'ssh', 'tcp', 'telnet', 'trueport', 'udp',
            'virtual-modem', 'packet-forwarding',
        ):
            if key not in config:
                continue
            path = [*base_path, key]
            if self.operator == 'delete' and key not in new_config:
                self.generate(*path)
            else:
                self._generate_nested_config(path, config[key], new_config.get(key))

    def _process_device_config(self, devices, new_devices):
        for name, config in devices.items():
            base_path = ['service', 'serial', 'device', str(name)]
            if self.operator == 'delete' and name not in new_devices:
                self.generate(*base_path)
            else:
                self._process_port_config(base_path, config, new_devices.get(name, {}))

    def _process_profile_config(self, profiles, new_profiles):
        base_path = ['service', 'serial', 'profile', 'tty-profile']
        if self.operator == 'delete' and 'tty-profile' not in new_profiles:
            self.generate(*base_path)
            return
        for name, config in profiles.get('tty-profile', {}).items():
            path = [*base_path, str(name)]
            remaining = new_profiles.get('tty-profile', {})
            if self.operator == 'delete' and name not in remaining:
                self.generate(*path)
            else:
                self._process_port_config(path, config, remaining.get(name, {}))

    def generate_commands(self, data=None, current_config=None, new_config=None):
        self.cmds = []
        self.vyos_cmds = []
        if not data:
            return []
        serial_config = self._extract_serial_config(data)
        new_serial_config = self._extract_serial_config(new_config)
        self.attributes['service']['serial'] = serial_config
        for key in ('global-parameters', 'device', 'profile'):
            if key not in serial_config:
                continue
            if self.operator == 'delete' and key not in new_serial_config:
                self.generate('service', 'serial', key)
            elif key == 'global-parameters':
                self._process_global_parameters_config(serial_config[key], new_serial_config.get(key))
            elif key == 'device':
                self._process_device_config(serial_config[key], new_serial_config.get(key, {}))
            else:
                self._process_profile_config(serial_config[key], new_serial_config.get(key, {}))
        return self.cmds
