import json
from uuid import uuid4

from flask import session
from requests import HTTPError

from app.core.api.http.http_request import Action
from app.core.operation.serial.command_serial import SerialCommand
from app.core.operation.serial.models import SerialConfig
from app.core.operation.serial.parser import parse_serial_config_to_form, parse_serial_verify_config
from app.core.operation.serial.ppp import plan_ppp_interfaces
from app.core.operation.serial.slip import plan_slip_interfaces
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager


def fetch_serial_config(provider, data=None):
    serial_config = SerialConfig.query.first()
    return serial_config.serialize() if serial_config else parse_serial_config_to_form({})


def _generate_serial_commands(current_config, new_config, diff, ppp_interfaces=None, slip_interfaces=None, slip_values=None, ppp_values=None):
    set_cmd = SerialCommand(operator='set', resource='service')
    set_cmds = set_cmd.generate_commands(
        diff.get('created') or {}, current_config, new_config,
    )

    delete_cmd = SerialCommand(operator='delete', resource='service')
    delete_cmds = delete_cmd.generate_commands(
        diff.get('deleted') or {}, current_config, new_config,
    )

    ppp = plan_ppp_interfaces(current_config, new_config, ppp_interfaces or {}, ppp_values)
    slip = plan_slip_interfaces(current_config, new_config, slip_interfaces or {}, slip_values)
    return {
        'set_cmds': ppp['set_cmds'] + slip['set_cmds'] + set_cmds,
        'delete_cmds': delete_cmds + ppp['delete_cmds'] + slip['delete_cmds'],
        'ppp_interfaces': ppp['config'],
        'slip_interfaces': slip['config'],
    }


def _configure_error_details(response):
    try:
        payload = response.json()
    except ValueError:
        return response.text.strip()
    if isinstance(payload, dict):
        for key in ('error', 'message', 'detail', 'errors'):
            detail = payload.get(key)
            if isinstance(detail, str) and detail.strip():
                return detail.strip()
            if isinstance(detail, (dict, list)) and detail:
                return json.dumps(detail, ensure_ascii=False)
    if isinstance(payload, str):
        return payload.strip()
    return json.dumps(payload, ensure_ascii=False) if payload is not None else ''


def update_serial_config(provider, data):
    username = session['username']
    current_config = data.get('current') or {}
    new_config = data.get('new') or {}
    diff = data.get('diff') or {}

    command_data = _generate_serial_commands(
        current_config, new_config, diff, data.get('ppp_interfaces'),
        data.get('slip_interfaces'), data.get('slip_values'), data.get('ppp_values'),
    )
    set_cmds = command_data.get('set_cmds') or []
    delete_cmds = command_data.get('delete_cmds') or []
    cmds = list(dict.fromkeys(delete_cmds)) + list(dict.fromkeys(set_cmds))
    if not cmds:
        return []

    merged_del_config = merge_dicts_delete(
        current_config, diff.get('deleted') or {},
        clean_empty=False, remove_values=True, preserve_keys=True,
    )
    merged_config = merge_dicts_set(
        merged_del_config, new_config, replace_lists=True, preserve_keys=True,
    )

    verify_config = parse_serial_verify_config(
        merged_config, ppp_interfaces=command_data['ppp_interfaces'],
        slip_interfaces=command_data['slip_interfaces'],
    )
    verify = provider.verify_service.call_verify('serial', verify_config)
    if str(verify) not in ('None', '') and verify != {}:
        return [{'success': False, 'error': verify, 'cmd': cmds}]

    result = []
    response = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False)
    try:
        response.raise_for_status()
    except HTTPError as error:
        details = _configure_error_details(response) or 'The router returned no error details.'
        raise RuntimeError(f'VyOS serial configuration failed (HTTP {response.status_code}): {details}') from error
    res = response.json()
    result.append({'cmd': cmds, 'success': res['success'], 'error': res.get('error')})
    if not res['success']:
        return result

    result[-1]['slip_interfaces'] = command_data['slip_interfaces']
    result[-1]['ppp_interfaces'] = command_data['ppp_interfaces']
    SerialConfig.refresh(merged_config)
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update Serial',
            'content': 'Serial configuration is successfully updated',
        },
    )
    return result
