import json
import pprint
from uuid import uuid4

from flask import session
import requests

from app.core.api.http.http_request import Action
from app.core.operation.software_management.command_software_management import SoftwareManagementCommand
from app.core.operation.software_management.models import SoftwareUpdateCheckConfig
from app.core.api.manager import api_manager
from app.core.utils.process_config import process_commands
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


SHOW_UPDATE_CHECK = json.dumps({
    "op": "showConfig",
    "path": ["system", "update-check"],
})


def get_system_update_status(provider=None, data=None):
    if provider is None:
        provider = getattr(getattr(api_manager, "manager", None), "provider", None)
    if provider is None or getattr(provider, "graphql_service", None) is None:
        raise ValueError("Software update GraphQL service is unavailable")

    try:
        response = provider.graphql_service.send_request(
            function_name="ShowUpdateSystem",
            data=None,
            verify=False,
        )
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise ValueError(f"Unable to check for software updates: {exc}") from exc

    graphql_errors = payload.get("errors")
    operation = (payload.get("data") or {}).get("ShowUpdateSystem") or {}
    operation_errors = operation.get("errors") or graphql_errors

    if operation.get("success") is not True:
        message = _format_update_check_errors(operation_errors)
        raise ValueError(message or "Software update check failed")

    result = (operation.get("data") or {}).get("result")

    if not isinstance(result, dict):
        raise ValueError("Software update check returned an invalid result")

    if result.get("error") is True:
        raise ValueError(
            _format_update_check_errors(result.get("errors") or result.get("message"))
            or "Software update check failed"
        )

    return {
        "success": True,
        "update_available": result.get("update_available") is True,
        "local_version": result.get("local_version"),
        "remote_version": result.get("remote_version"),
        "url": result.get("url"),
    }


def _format_update_check_errors(errors):
    if not errors:
        return ""
    if isinstance(errors, (list, tuple)):
        return ", ".join(str(error) for error in errors)
    return str(errors)


def get_available_software_update():
    config = SoftwareUpdateCheckConfig.query.order_by(
        SoftwareUpdateCheckConfig.id.desc()
    ).first()
    feed_url = (config.url if config else "") or ""
    if not feed_url:
        raise ValueError("Software update-check URL is not configured")

    try:
        response = requests.get(feed_url, timeout=15)
        response.raise_for_status()
        images = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise ValueError(f"Unable to retrieve software image information: {exc}") from exc

    if not isinstance(images, list) or not images:
        raise ValueError("Software update feed must contain at least one image")

    valid_images = [
        image for image in images
        if isinstance(image, dict) and isinstance(image.get("url"), str)
    ]
    if not valid_images:
        raise ValueError("Software update feed does not contain a valid image URL")

    image = max(valid_images, key=lambda item: str(item.get("timestamp") or ""))
    image_url = image["url"].strip()
    if not image_url.startswith(("http://", "https://")) or not image_url.lower().endswith(".iso"):
        raise ValueError("Software update feed contains an invalid ISO image URL")

    return {
        "success": True,
        "image": {
            "url": image_url,
            "version": image.get("version"),
            "timestamp": image.get("timestamp"),
        },
    }
def fetch_update_check(provider, data=None):
    response = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_UPDATE_CHECK,
        verify=False,
    )
    if getattr(response, "status_code", 200) == 400:
        return {}

    payload = response.json()
    if payload.get("success") is not True:
        raise RuntimeError(payload.get("error") or "Failed to load update-check settings")
    return payload.get("data") or {}


def update_update_check(provider, data):
    logger.info("Update software update-check:")
    logger.info(data)

    config = data.get("new") or {}
    current_config = data.get("current") or {}
    diff = data.get("diff") or {"created": {}, "deleted": {}}

    print("Current config:")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config:")
    print(pprint.pformat(config, indent=2, width=80))

    set_command = SoftwareManagementCommand(operator="set")
    set_commands = set_command.generate_commands(diff.get("created") or {})
    set_config = process_commands(set_command.get_commands())

    print("New set configs:")
    print(pprint.pformat(set_config, indent=2, width=80))

    delete_command = SoftwareManagementCommand(operator="delete")
    delete_commands = delete_command.generate_commands(diff.get("deleted") or {})
    delete_config = process_commands(delete_command.get_commands())

    print("New delete configs:")
    print(pprint.pformat(delete_config, indent=2, width=80))

    commands = delete_commands + set_commands
    if not commands:
        SoftwareUpdateCheckConfig.refresh(config)
        return []

    response = provider.http_service.send_request(
        action=Action.CONFIGURE,
        data=commands,
        verify=False,
    ).json()
    result = [{
        "cmd": commands,
        "success": response.get("success", False),
        "error": response.get("error"),
    }]

    if response.get("success") is True:
        SoftwareUpdateCheckConfig.refresh(config)
        username = session.get("username")
        if username:
            socket_manager.emit_to_user(
                username,
                event="notification",
                data={
                    "id": str(uuid4()),
                    "type": "ignore",
                    "title": "Success: Update Software Management",
                    "content": "Software update-check configuration was successfully updated",
                },
            )

    return result
