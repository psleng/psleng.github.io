from copy import deepcopy
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_INTERFACE_VALUES, SHOW_INTERFACE_CONFIGS
from app.core.operation.interface import is_deletable_interface, load_interfaces_json_v3
from app.core.api.http.cmd.command_interface import InterfaceCommand
from app.event.models import AsyncJob
from uuid import uuid4
from logging import getLogger, INFO
from flask import session
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set, normalize_config
from app.core.operation.parser import parse_interface_config
from app.socket.socket_manager import socket_manager
from app.core.operation.ethernet.command_ethernet import EthernetCommand
from app.core.operation.wifi.command_wifi import WifiInterfaceCommand
from app.core.operation.bridge.command_bridge import BridgeCommand
from app.core.operation.wifi.parser import parse_wifi
from app.core.operation.wifi.models import WiFiInterfaceConfig
from app.core.network.dhcp.models import DHCPPool
from app.core.models import Interface
from app.core.api.http.cmd.command_system import SystemCommand
import json
import pprint
from app.core.models import System
from app.core.operation.cellular.parser import parse_cellular_op_info
from app.core.operation.openvpn.command_openvpn import OpenvpnCommand
from app.core.operation.wireguard.command_wireguard import WireguardCommand
from app.core.operation.ethernet.models import EthernetInterfaceConfig
from app.core.operation.wireguard.parser import parse_wireguard_monitor_info
from app.core.operation.openvpn.parser import parse_openvpn_monitor_info
from app.core.operation.openvpn.service import update_openvpn_by_name
from app.core.operation.wireguard.service import update_wireguard_by_name
from app.core.operation.ipsec.service import update_ipsec
from app.core.operation.vlan.service import update_vlan
from app.core.operation.bridge.service import update_bridge_by_name
from app.core.operation.cellular.service import update_wwan_by_name
from app.core.api.http.cmd.compare import compare_configs
from app.core.models import InterfaceConfig
from app.db.database import db

logger = getLogger(__name__)
logger.setLevel(INFO)

def create_interface_address(self, data):
    print(data)

def fetch_interface_config(provider, data=None):
    res = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_CONFIGS, verify=False)
    return res


def fetch_interface(provider, data=None):
    interface_conf = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_CONFIGS, verify=False)
    interface_op = provider.http_service.send_request(action=Action.SHOW, data=SHOW_INTERFACE_VALUES, verify=False)
    interfaces = load_interfaces_json_v3(interface_op.json()['data'], interface_conf.json()['data'])
    
    return interfaces

def fetch_interface_gql(provider, data=None):
    
    interface_op = provider.graphql_service.send_request(function_name='ShowInterfaces', data=None, verify=False) 
    # print("Interface Operation: ")
    # print(pprint.pformat(interface_op.json()['data'], indent=2, width=80)) 
    return interface_op.json()['data']

def _create_interface(provider, data):
    cmd_data = {
        "operator": "set",
        "resource": "interfaces",
        "intf_type": data.get('intf_type'),
        "name": data.get('name'),
        "description": data.get('desc'),
        "address": data.get('address')
    }

    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address'), desc=cmd_data.get('description')
    )

    cmds = intf_c.generate_commands()
    res = []
    for cmd in cmds:
        
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })

        AsyncJob.create({
            "job_id": str(uuid4()),
            "params": cmd,
            "result": success
        })
    
    return res


def create_interface(provider, data):
    try:
        pass
    except Exception as e:
        return jsonify({'error': str(e)}), 400


def update_interface(provider, data):
    cmd_data = {
        "operator": "set",
        "resource": "interfaces",
        "intf_type": data.get('intf_type'),
        "name": data.get('name'),
        "description": data.get('desc'),
        "address": data.get('address')
    }
    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address'), desc=cmd_data.get('description')
    )
    cmds = intf_c.generate_commands()
    res = []
    for cmd in cmds:
        res.append({
            "cmd": cmd,
            "success": provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        })

    return res

def verify_and_generate_commands_ethernet(provider, current_config, new_config, name, diff):
    
    set_cmds = []
    iface_set_cmd = EthernetCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, new_config)
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = EthernetCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "ethernet"
    curr_config = provider.verify_service.query_interface_config(service, name)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}).get('ethernet', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}).get('ethernet', {}))    
    
    verify = None
    if merged_config:
        verify = provider.verify_service.query_interface_verify(
            service, 
            name, 
            merged_config
        )
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    return {
        "verify": verify,
        "merged_config": merged_config,
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }

def update_ethernet_by_name(provider, data):
    print("Update interface by name: ")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    intf_type = data.get('intf_type')
    name = data.get('name')
    all_bridges = data.get('all_bridges')

    print("New config: ")
    print(pprint.pformat(new_config, indent=2, width=80))

    r = []
    _data_ethernet = verify_and_generate_commands_ethernet(provider, current_config, new_config, name, diff)
    verify = _data_ethernet.get('verify')
    merged_config = _data_ethernet.get('merged_config')
    set_cmds = _data_ethernet.get('set_cmds')
    delete_cmds = _data_ethernet.get('delete_cmds')
    
    
    if str(verify) != "None" and str(verify) != "" and verify != {}:
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    parse_interface_conf = parse_interface_config({"interfaces": merged_config})
    print("Parsed interface config to update:")
    print(pprint.pformat(parse_interface_conf, indent=2, width=80))

    # Update DB
    # TODO: Need to consider.
    InterfaceConfig.upsert(
        {
            'ethernet': {
                name: new_config
            }
        }
    )

    EthernetInterfaceConfig.refresh(
        merged_config
    )

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Interface",
                "content": "Interface is successfully updated"
            }
    )
    
    current_bridge = None
    new_bridge = new_config.get('bridge', {}).get('interface', None)
    print("All bridges: ")
    print(all_bridges)
    # Find current bridge interface is it exists
    for bridge_name, bridge_config in all_bridges.items():
        if 'member' in bridge_config and 'interface' in bridge_config['member'] and name in bridge_config['member']['interface']:
            current_bridge = bridge_name
            break
    if current_bridge and current_bridge != new_bridge:
        # remove the current bridge interface
        delete_cmds.append(f'{{"op":"delete", "path": ["interfaces","bridge","{current_bridge}","member","interface","{name}"]}}')

    # if is bridge mode, remove the address field of the interface
    bridge_mode = False
    if 'bridge' in new_config and 'interface' in new_config['bridge']:
        _bridge_interface = new_config['bridge']['interface']
        if _bridge_interface:
            bridge_mode = True


    if bridge_mode:
        # remove all of the address fields
        delete_cmds.append(f'{{"op":"delete", "path": ["interfaces","{intf_type}","{name}","address"]}}')
        # set bridge member
        set_cmds.append(f'{{"op":"set", "path": ["interfaces","bridge","{new_bridge}","member","interface","{name}"]}}')

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_and_generate_commands_system_wireless(current_config, new_config, diff):
    """
        Verify and generate commands for system wireless
    """
    new_conf = deepcopy(current_config or {})
    new_wireless = (new_config or {}).get('wireless') or {}
    country_code = new_wireless.get('country_code')
    if country_code:
        wireless_config = new_conf.get('wireless') or {}
        wireless_config['country_code'] = country_code
        new_conf['wireless'] = wireless_config
    
    set_cmds = []
    current_country = ((current_config or {}).get('wireless') or {}).get('country_code')
    changed_wireless = new_conf.get('wireless') if country_code and country_code != current_country else None
    iface_set_cmd = SystemCommand(operator='set', resource='system', wireless=changed_wireless)
    set_cmds = iface_set_cmd.generate_commands(diff['created'], current_config, new_conf)
    sc = iface_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    return {
        "merged_config": new_conf,
        "set_cmds": set_cmds,
        "delete_cmds": []
    }


def verify_and_generate_commands_bridge(provider, current_config, new_config):
    """
        When updating wireless, only change bridge address if verification is passed
    """
    print("New bridge params: ")
    print(new_config)
    new_conf = deepcopy(current_config)
    if (
        new_conf
        and new_conf.get('br1', None)
        and new_conf.get('br1', {}).get('address', {})
        and isinstance(new_config, dict)
    ):
        new_bridge_address = new_config.get('br1', {}).get('address', None)
        if new_bridge_address and isinstance(new_bridge_address, list):
            new_conf['br1']['address'] = new_config['br1']['address'][0]
        elif new_bridge_address and isinstance(new_bridge_address, str):
            new_conf['br1']['address'] = new_conf['br1']['address']

    # Dict representation of the bridge interface with only address to delete
    del_conf = {}
    if current_config and current_config.get('br1', None) and current_config.get('br1', {}).get('address', {}):
        del_conf['br1'] = {'address': current_config['br1']['address']}
    
    print("Current bridge")
    print(current_config)

    print("New bridge")
    print(new_conf)

    print("Del bridge")
    print(del_conf)

    diff_bridge = compare_configs(
        {"br1": new_conf.get("br1", {})},
        {"br1": current_config.get("br1", {})}
    )

    print("Diff bridge: ")
    print(diff_bridge)

    set_cmds = []
    iface_set_cmd = BridgeCommand(operator='set', resource='interfaces')
    
    set_cmds = iface_set_cmd.generate_commands(
        # new_conf,
        diff_bridge["created"], 
        {"interfaces": {"bridge": current_config}}, 
        {"interfaces": {"bridge": new_conf}}
    )

    sc = iface_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = BridgeCommand(operator='delete', resource='interfaces')
    delete_cmds = iface_delete_cmd.generate_commands(
        # del_conf,
        diff_bridge["deleted"], 
        {"interfaces": {"bridge": del_conf}}, 
        {"interfaces": {"bridge": new_conf}}
    )

    dc = iface_delete_cmd.get_commands()
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    service = "bridge"
    verify = None
    if new_conf and new_conf.get('br1', None):
        verify = provider.verify_service.query_interface_verify(service, 'br1', new_conf['br1'])

    return {
        "verify": verify,
        "merged_config": new_conf,
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }

def verify_and_generate_commands_wireless(provider, current_config, new_config, diff, country_code=None):
    current_wireless = normalize_config(
        (current_config or {}).get('wireless') or {}, hyphenated=True, stringify_numbers=True,
    )
    merged_config = normalize_config(new_config or {}, hyphenated=True, stringify_numbers=True)
    diff = compare_configs(
        {'interfaces': {'wireless': merged_config}},
        {'interfaces': {'wireless': current_wireless}},
    )

    # Generate fixed settings only when they are missing or have changed.
    iface_set_fixed_cmd = WifiInterfaceCommand(operator='set', resource='interfaces')
    set_fixed_cmds = iface_set_fixed_cmd.generate_commands(
        {'fixed_configs': diff['created']}, current_config, merged_config,
    )
    iface_set_cmd = WifiInterfaceCommand(operator='set', resource='interfaces')
    set_cmds = iface_set_cmd.generate_commands(diff['created'], current_config, merged_config)
    iface_delete_cmd = WifiInterfaceCommand(operator='delete', resource='interfaces')
    delete_cmds = iface_delete_cmd.generate_commands(diff['deleted'], current_config, merged_config)

    service = "wireless"
    wireless_ifaces = ['wlan0', 'wlan1', 'wlan2', 'wlan3']
    errors = []
    for wiface in wireless_ifaces:
        raw_config = provider.verify_service.query_interface_config(service, wiface)
        base_path = ['interfaces', 'wireless', wiface]
        verify_config = merge_dicts_delete(
            raw_config or {},
            diff['deleted'].get('interfaces', {}).get('wireless', {}).get(wiface, {}),
            clean_empty=False, remove_values=True, base_path=base_path,
        )
        verify_config = merge_dicts_set(
            verify_config,
            diff['created'].get('interfaces', {}).get('wireless', {}).get(wiface, {}),
            base_path=base_path,
        )
        
        if country_code:
            verify_config['country_code'] = country_code
        result = provider.verify_service.query_interface_verify(service, wiface, verify_config)
        if result not in (None, '', 'None', {}):
            errors.append(f'{wiface}: {result}')

    return {
        "verify": '\n'.join(errors) or None,
        "merged_config": merged_config,
        "set_cmds": list(dict.fromkeys(set_fixed_cmds + set_cmds)),
        "delete_cmds": list(dict.fromkeys(delete_cmds)),
    }


def update_wireless(provider, data):
    
    from app.core.network.dhcp.service import (
        verify_and_generate_commands as verify_and_generate_commands_dhcp
    )

    print("Update interface by name: ")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    current_config = data.get('current')
    new_config = data.get('new')
    intf_type = data.get('intf_type')
    new_dhcp = data.get('new_dhcp')
    current_dhcp = data.get('current_dhcp')
    diff_dhcp = data.get('diff_dhcp')
    current_bridge = data.get('current_bridge')
    new_bridge = data.get('new_bridge')
    current_system_wireless = data.get('current_system_wireless')
    new_system_wireless = data.get('new_system_wireless')
    diff_system_wireless = data.get('diff_system_wireless')

    r = []
    #==== Verify and generate commands each service ==== #

    # Verify and Update System Wireless
    print("Verify and update system wireless")
    print("Current system wireless: ")
    print(pprint.pformat(current_system_wireless, indent=2, width=80))
    print("New system wireless: ")
    print(pprint.pformat(new_system_wireless, indent=2, width=80))
    print("Diff system wireless: ")
    print(pprint.pformat(diff_system_wireless, indent=2, width=80))
    _data_system_wireless = verify_and_generate_commands_system_wireless(current_system_wireless, new_system_wireless, diff_system_wireless)
    verify_system_wireless = _data_system_wireless.get('verify')
    merged_config_system_wireless = _data_system_wireless.get('merged_config')
    set_cmds_system_wireless = _data_system_wireless.get('set_cmds')
    delete_cmds_system_wireless = _data_system_wireless.get('delete_cmds')
    
    # Verify and Update Bridge
    print("Verify and update bridge")
    _data_bridge = verify_and_generate_commands_bridge(provider, current_bridge, new_bridge)
    verify_bridge = _data_bridge.get('verify')
    merged_config_bridge = _data_bridge.get('merged_config')
    set_cmds_bridge = _data_bridge.get('set_cmds')
    delete_cmds_bridge = _data_bridge.get('delete_cmds')
    print("Parsed bridge config to update: ")
    print(pprint.pformat(merged_config_bridge, indent=2, width=80))

    if str(verify_bridge) != "None":
        
        print("Bridge Validation Error: ")
        print(pprint.pformat(verify_bridge, indent=2, width=80))
        # print("Type of Bridge Error: ", type(verify_bridge))
        # return Exception(verify_bridge)

    # Verify and Update DHCP
    print("Verify and update DHCP")
    _data_dhcp = verify_and_generate_commands_dhcp(provider, current_dhcp, new_dhcp, diff_dhcp)
    verify_dhcp = _data_dhcp.get('verify')
    merged_config_dhcp = _data_dhcp.get('merged_config')
    set_cmds_dhcp = _data_dhcp.get('set_cmds')
    delete_cmds_dhcp = _data_dhcp.get('delete_cmds')
    # print("Parsed dhcp config to update:")
    # print(pprint.pformat(merged_config_dhcp, indent=2, width=80))

    if str(verify_dhcp) != "None" and str(verify_dhcp) != "":
        print("DHCP Validation Error: ")
        print(pprint.pformat(verify_dhcp, indent=2, width=80))
        # print("Type of DHCP Error: ", type(verify_dhcp))
        return Exception(verify_dhcp)

    # Verify and Update Wireless
    print("Verify and update wireless")
    _data_wireless = verify_and_generate_commands_wireless(
        provider, current_config, new_config, diff,
        country_code=new_system_wireless.get('wireless', {}).get('country_code'),
    )
    verify_wireless = _data_wireless.get('verify')
    merged_config_wireless = _data_wireless.get('merged_config')
    set_cmds_wireless = _data_wireless.get('set_cmds')
    delete_cmds_wireless = _data_wireless.get('delete_cmds')
    
    if str(verify_wireless) != "None":
        print("Validation Error: ")
        print(pprint.pformat(verify_wireless, indent=2, width=80))
        # print("Type of Error: ", type(verify_wireless))
        return Exception(verify_wireless)
    
    parse_interface_conf = parse_wifi({"wireless": merged_config_wireless}, merged_config_bridge)
    print("Parsed interface config to update:")
    print(pprint.pformat(parse_interface_conf, indent=2, width=80))


    #==== Update DB after verifications ==== #

    # Update WiFi DB
    WiFiInterfaceConfig.refresh(None, parse_interface_conf, "full")
    # Update DHCP DB
    DHCPPool.update_pool_by_name("default-dhcp-pool", merged_config_dhcp)
    # Update Bridge DB
    Interface.create_ipv4("br1", merged_config_bridge.get('br1', {}).get('address', '/'))
    # Update System Wireless Country Code DB
    System.set_wireless_country_code(country_code=new_system_wireless.get('wireless', {}).get('country_code', None))


    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Wireless",
                "content": "Wireless is successfully updated"
            }
    )
    
    excecuted_cmds = list(set(delete_cmds_wireless)) + list(set(delete_cmds_dhcp)) + list(set(delete_cmds_bridge)) + \
                            list(dict.fromkeys(set_cmds_wireless)) + list(set(set_cmds_dhcp)) + list(set(set_cmds_bridge)) + \
                                list(set(set_cmds_system_wireless))


    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_interface_by_name(provider, data):

    intf_type = data.get('intf_type')

    if intf_type == 'wireless':
        return update_wireless(provider, data)
    elif intf_type == 'ethernet':
        return update_ethernet_by_name(provider, data)
    elif intf_type == 'openvpn':
        return update_openvpn_by_name(provider, data)
    elif intf_type == 'wireguard':
        return update_wireguard_by_name(provider, data)
    elif intf_type == 'vlan':
        return update_vlan(provider, data)
    elif intf_type == 'bridge':
        return update_bridge_by_name(provider, data)
    elif intf_type == 'ipsec':
        return update_ipsec(provider, data)
    elif intf_type == 'wwan':
        return update_wwan_by_name(provider, data)
    elif intf_type == 'iptunnels':
        from app.core.operation.iptunnels.service import update_iptunnel_by_name
        return update_iptunnel_by_name(provider, data)


def delete_interface(provider, req_data):
    print('DELETE INTERFACE FUNCTION')
    username = session['username']
    cmds = []
    interface_names_to_delete = []
    for data in req_data:        
        if is_deletable_interface(data.intf_type) == False:
            print("Interface is not deletable")
            logger.info("Interface is not deletable")
            continue
        cmd_data = {
            "operator": "delete",
            "resource": "interfaces",
            "intf_type": data.intf_type,
            "name": data.name
        }

        intf_c = InterfaceCommand(
            operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
            name=cmd_data.get('name')
        )
        cmds.append(intf_c.generate_commands())
        interface_names_to_delete.append(data.name)

    res = []
    deleted_names = []
    for name, cmd in zip(interface_names_to_delete, cmds):
        result = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()
        res.append({
            "cmd": cmd,
            "success": result['success'],
            "error": result.get('error')
        })
        if result['success'] is True:
            deleted_names.append(name)

    if deleted_names:
        InterfaceConfig.query.filter(InterfaceConfig.interface.in_(deleted_names)).delete(synchronize_session=False)
        db.session.commit()

    if not res or any(result['success'] is not True for result in res):
        return res

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Delete Interface",
            "content": "Interface is successfully deleted"
        }
    )

    return res


def delete_interface_address(provider, data):
    res = []
    cmd_data = {
        "operator": "delete",
        "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.address
    }

    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address')
    )

    cmds = intf_c.generate_commands()

    for cmd in cmds:
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })
    
    return res

def update_interface_address(provider, data):
    res = []
    cmd_data_1 = { "operator": "set", "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.new_address
    }

    cmd_data_2 = { "operator": "delete", "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.current_address
    }

    intf_c_1 = InterfaceCommand(
        operator=cmd_data_1.get('operator'), resource=cmd_data_1.get('resource'), intf_type=cmd_data_1.get('intf_type'),
        name=cmd_data_1.get('name'), address=cmd_data_1.get('address')
    )
    
    intf_c_2 = InterfaceCommand(
        operator=cmd_data_2.get('operator'), resource=cmd_data_2.get('resource'), intf_type=cmd_data_2.get('intf_type'),
        name=cmd_data_2.get('name'), address=cmd_data_2.get('address')
    )

    cmds = intf_c_1.generate_commands() + intf_c_2.generate_commands()
    res = []
    for cmd in cmds:
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })
    

def fetch_wifi_info(provider, data=None):
    
    # interface_op = graphql_req.send_request(function_name='ShowInfoInterfacesWireless', data=None, verify=False) 
    interface_op = provider.graphql_service.send_request(function_name='ShowChannelWirelessQuery', data=None, verify=False) 
    return interface_op.json()['data']


def fetch_wifi_station(provider, data=None):
    intf_name = data.get('intf_name', None)
    if not intf_name:
        return []
    interface_op = provider.graphql_service.send_str_request(function_name='ShowStationsWirelessQuery', data=f'intf_name: "{intf_name}"', verify=False) 
    return interface_op.json()['data']


def fetch_wifi_scan(provider, data=None):
    intf_name = data.get('intf_name', None)
    if not intf_name:
        return []
    interface_op = provider.graphql_service.send_str_request(function_name='ShowScanWirelessQuery', data=f'intf_name: "{intf_name}"', verify=False) 
    return interface_op.json()['data']


def fetch_cellular_info(provider, data=None):
    request_data = data or {}
    intf_name = request_data.get('intf_name', 'wwan0')

    def query_wwan(keyword):
        req = provider.graphql_service.send_request(
            function_name='ShowWwanIgosWwanQuery',
            data=f'interface: {json.dumps(intf_name)}, keyword: {json.dumps(keyword)}',
            verify=False,
        )
        response = req.json()
        operation = (response.get('data') or {}).get('ShowWwanIgosWwanQuery') or {}
        if not operation.get('success'):
            errors = operation.get('errors') or response.get('errors') or [
                f'Unable to read WWAN interface {keyword}'
            ]
            if not isinstance(errors, list):
                errors = [errors]
            raise ValueError('; '.join(str(error) for error in errors))
        result = (operation.get('data') or {}).get('result')
        if not isinstance(result, dict):
            raise ValueError(f'Invalid WWAN interface {keyword} response')
        return result

    modem_detail = query_wwan('detail')
    status = query_wwan('status')
    detail = {**modem_detail, **status, 'interface': intf_name, 'status': status}

    if request_data.get('detail'):
        return detail

    return parse_cellular_op_info({
        'ShowWwanIgosWwanQuery': {'data': {'result': detail}},
    })


def fetch_wireguard_info(provider, data=None):
    req = provider.graphql_service.send_request(function_name='ShowWireguardInterfacesWireguardQuery', data=None, verify=False) 
    wireguard_info = parse_wireguard_monitor_info(req.json()['data'])
    return wireguard_info


def reset_wireguard_interface(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    if not intf_name:
        return []
    payload = {
        "op": "reset",
        "path": ["wireguard", "interface", intf_name]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()


def reset_wireguard_peer(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    peer_name = (data or {}).get('peer_name', None)
    if not intf_name or not peer_name:
        return []
    payload = {
        "op": "reset",
        "path": ["wireguard", "interface", intf_name, "peer", peer_name]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()


def fetch_openvpn_info(provider, data=None):

    req = provider.graphql_service.send_request(function_name='ShowOpenvpn', data={"mode": data}, verify=False) 
    openvpn_info = parse_openvpn_monitor_info(req.json())
    return openvpn_info

def reset_openvpn_interface(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    if not intf_name:
        return []
    payload = {
        "op": "reset",
        "path": ["openvpn", "interface", intf_name]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()

def reset_openvpn_client(provider, data=None):
    client_name = (data or {}).get('client_name', None)
    if not client_name:
        return []
    payload = {
        "op": "reset",
        "path": ["openvpn", "client", client_name]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()

def dhcp_server_lease(provider, data=None):
    address = (data or {}).get('address', None)
    family = (data or {}).get('family', None)
    vrf = (data or {}).get('vrf', "")

    if not address or not family:
        return []
    payload = {
        "family": family,
        "vrf": vrf,
        "address": address
    }
    req = provider.graphql_service.send_mutation_request(
        function_name='ClearDhcpServerLeaseDhcp', 
        mutation_name='ClearDhcpServerLeaseDhcp',
        input_name='ClearDhcpServerLeaseDhcpInput',
        data=payload, 
        verify=False
    )
    return req.json()


def show_dhcp_client_leases(provider, data=None):
    family = (data or {}).get('family', None)
    intf_name = (data or {}).get('interface', None)
    if family not in ['inet', 'inet6']:
        return []

    payload = {
        'family': family,
    }
    if intf_name:
        payload['interface'] = f'"{intf_name}"'

    req = provider.graphql_service.send_request(
        function_name='ShowClientLeasesDhcp',
        data=payload,
        verify=False,
    )
    return req.json()


def renew_dhcp_client_lease(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    family = (data or {}).get('family', None)
    if not intf_name or not family:
        return []

    payload = {
        "family": family,
        "interface": intf_name,
    }
    req = provider.graphql_service.send_mutation_request(
        function_name='RenewClientLeaseDhcp',
        mutation_name='RenewClientLeaseDhcp',
        input_name='RenewClientLeaseDhcpInput',
        data=payload,
        verify=False,
    )
    return req.json()


def release_dhcp_client_lease(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    family = (data or {}).get('family', None)
    if not intf_name or not family:
        return []

    payload = {
        "family": family,
        "interface": intf_name,
    }
    req = provider.graphql_service.send_mutation_request(
        function_name='ReleaseClientLeaseDhcp',
        mutation_name='ReleaseClientLeaseDhcp',
        input_name='ReleaseClientLeaseDhcpInput',
        data=payload,
        verify=False,
    )
    return req.json()


def counter_interface(provider, data=None):
    intf_name = (data or {}).get('intf_name', None)
    if not intf_name:
        return []
    req = provider.graphql_service.send_mutation_request(
        function_name='ClearCountersInterfaces', 
        mutation_name='ClearCountersInterfaces',
        input_name='ClearCountersInterfacesInput',
        data={"intf_name": intf_name}, 
        verify=False
    )
    return req.json()
