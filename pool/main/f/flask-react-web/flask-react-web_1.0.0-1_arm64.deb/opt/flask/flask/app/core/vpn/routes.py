from app.core.vpn import vyos_vpn_bp
from flask import jsonify

from app.auth.utils import login_required, permission_required
from logging import getLogger, DEBUG
from flask import request
from app.core.vpn.pptp.models import UpdatePPTPDTO, PPTPConfig
from app.core.vpn.sstp.models import UpdateSSTPDTO, SSTPConfig
from app.core.vpn.l2tp.models import UpdateL2TPDTO, L2TPConfig
from app.core.api.http.http_request import Action
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.http.cmd.compare import compare_configs
from app.core.vpn.pptp.parsers import parse_to_vyos_config as parse_pptp_to_vyos_config
from app.core.vpn.sstp.parsers import parse_to_vyos_config as parse_sstp_to_vyos_config
from app.core.vpn.l2tp.parsers import parse_to_vyos_config as parse_l2tp_to_vyos_config
from app.core.operation.ipsec.parser import _parse_with_vti_addresses, parse_to_ipsec_config, parse_current_ipsec_interface_config
from app.core.operation.ipsec.models import IPsecConfig, UpdateIPsecInterfaceDTO, CreateIPsecInterfaceDTO
from app.core.operation.utils import read_ike_dh_group, read_ike_encryption, read_ike_hash, read_ike_pseudo_random_function, read_esp_encryption, read_esp_hash, read_esp_pfs, router_pause_scheduler
from pydantic import ValidationError
from app.core.utils.validate.pydantic_error_format import format_pydantic_error
import pprint
from app.core.utils.decorator.route_decorator import Pipeline
admin_vpn = Pipeline.admin(vyos_vpn_bp)

logger = getLogger(__name__)
logger.setLevel(DEBUG)

@vyos_vpn_bp.route('/pptp', methods=['GET'])
@login_required
def get_pptp():
    try:
        pptp_config = PPTPConfig.query.first()
        if pptp_config:
            return jsonify(pptp_config.serialize()), 200
        else:
            return jsonify({}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400
    

@admin_vpn.route('/pptp', methods=['PUT'])
def update_pptp():
    try:
        json_data = request.get_json()
        if json_data is None:
            return jsonify({'error': 'No JSON data provided'}), 400

        if json_data == {}:
            data = {}
        else:
            data = UpdatePPTPDTO.model_validate(json_data).model_dump()
        
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.PPTP)
        
        new_config = parse_pptp_to_vyos_config(data)
        diff_config = compare_configs(new_config, current_config)
        
        pptp = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.PPTP, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        return jsonify(pptp), 200

    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Error updating PPTP: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@admin_vpn.route('/pptp/monitor/sessions', methods=['GET'])
def monitor_pptp_sessions():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.PPTP_SESSIONS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@admin_vpn.route('/pptp/monitor/statistics', methods=['GET'])
def monitor_pptp_statistics():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.PPTP_STATISTICS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_vpn_bp.route('/sstp', methods=['GET'])
@login_required
def get_sstp():
    try:
        sstp_config = SSTPConfig.query.first()
        if sstp_config:
            return jsonify(sstp_config.serialize()), 200
        else:
            return jsonify({}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400
    

@admin_vpn.route('/sstp', methods=['PUT'])
def update_sstp():
    try:
        json_data = request.get_json()
        if json_data is None:
            return jsonify({'error': 'No JSON data provided'}), 400

        if json_data == {}:
            data = {}
        else:
            data = UpdateSSTPDTO.model_validate(json_data).model_dump()
        
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SSTP)
        
        new_config = parse_sstp_to_vyos_config(data)
        diff_config = compare_configs(new_config, current_config)
        
        sstp = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.SSTP, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        return jsonify(sstp), 200

    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Error updating SSTP: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
    
@admin_vpn.route('/sstp/monitor/sessions', methods=['GET'])
def monitor_sstp_sessions():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.SSTP_SESSIONS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@admin_vpn.route('/sstp/monitor/statistics', methods=['GET'])
def monitor_sstp_statistics():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.SSTP_STATISTICS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_vpn_bp.route('/l2tp', methods=['GET'])
@login_required
def get_l2tp():
    try:
        l2tp_config = L2TPConfig.query.first()
        if l2tp_config:
            return jsonify(l2tp_config.serialize()), 200
        else:
            return jsonify({}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400
    

@admin_vpn.route('/l2tp', methods=['PUT'])
def update_l2tp():
    try:
        json_data = request.get_json()
        if json_data is None:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        if json_data == {}:
            data = {}
        else:
            data = UpdateL2TPDTO.model_validate(json_data).model_dump()
        
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.L2TP)
        
        new_config = parse_l2tp_to_vyos_config(data)
        diff_config = compare_configs(new_config, current_config)
        
        l2tp = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.L2TP, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        return jsonify(l2tp), 200

    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Error updating L2TP: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500  

@admin_vpn.route('/l2tp/monitor/sessions', methods=['GET']) 
def monitor_l2tp_sessions():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.L2TP_SESSIONS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@admin_vpn.route('/l2tp/monitor/statistics', methods=['GET'])
def monitor_l2tp_statistics():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.L2TP_STATISTICS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@admin_vpn.route('/ipsec', methods=['PUT'])
def update_ipsec_interface():
    try:
        data = UpdateIPsecInterfaceDTO.model_validate_json(request.data)
        new_config = parse_to_ipsec_config(data.model_dump())
        logger.debug("New ipsec config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_ipsec_interface_config(os_config)
        logger.debug("Current ipsec config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_IPSEC,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "ipsec",
                "diff": diff
            }
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_vpn_bp.route('/ipsec', methods=['GET'])
@login_required
def show_ipsec_interfaces_config():
    try:
        from app.core.models import InterfaceConfig
        ipsec_config = IPsecConfig.get_current_config()
        vti_interfaces = InterfaceConfig.query.filter_by(interface_type='vti').all()
        vti_data = {}
        for vti in vti_interfaces:
            addresses = [addr.ip_address for addr in vti.ip_addresses if addr.ip_address]
            vti_data[vti.interface] = {'address': addresses[0] if addresses else None} if addresses else {}
        ipsec_config = _parse_with_vti_addresses(ipsec_config, {'interfaces': {'vti': vti_data}})
        constants = {
            "ike_dh_group": read_ike_dh_group(),
            "ike_encryption": read_ike_encryption(),
            "ike_hash": read_ike_hash(),
            "ike_pseudo_random_function": read_ike_pseudo_random_function(),
            "esp_encryption": read_esp_encryption(),
            "esp_hash": read_esp_hash(),
            "esp_pfs": read_esp_pfs()
        }

        if ipsec_config:
            return jsonify({
                "ipsec_config": ipsec_config,
                "constants": constants
            }), 200
        return jsonify({}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/connections', methods=['GET'])
@login_required
def monitor_ipsec_connections():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_CONNECTIONS)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/sadetail', methods=['GET'])
@login_required
def monitor_ipsec_sadetail():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_SA_DETAIL)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/restart', methods=['POST'])
@login_required
def restart_ipsec_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/reset/remote-access-all', methods=['POST'])
@login_required
def reset_ipsec_remote_access_all_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_RESET_REMOTE_ACCESS_ALL, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/reset/site-to-site-all', methods=['POST'])
@login_required
def reset_ipsec_site_to_site_all_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_RESET_SITE_TO_SITE_ALL, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_vpn_bp.route('/ipsec/monitor/reset/site-to-site/peer/<peer_name>', methods=['POST'])
@login_required
def reset_ipsec_site_to_site_peer_monitor(peer_name):
    try:
        payload = request.get_json(silent=True) or {}
        payload['peer_name'] = peer_name
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.IPSEC_RESET_SITE_TO_SITE_PEER, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400
