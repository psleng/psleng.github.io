from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Literal
from ipaddress import ip_address

class CreateKeyCertDTO(BaseModel):
    pki_key_type: str
    com_name: str
    country_code: str
    key_bit: int
    key_type: str
    locality: str
    org_name: str
    passphrase: str
    state: str
    valid_days: int
    self_signed: Optional[bool] = False
    ca_name: Optional[str] = ""
    name: Optional[str] = ""
    install: Optional[bool] = False
    file: Optional[bool] = False
    encrypt_key: Optional[bool] = False
    subject_alt_names: Optional[str] = ""

class KeyItem(BaseModel):
    name: str
    private_key: Optional[str] = ""
    public_key: Optional[str] = ""
    version: Optional[str] = ""

class CertificateItem(BaseModel):
    name: str
    certificate: str
    private_key: Optional[str] = ""

class CACertificateItem(CertificateItem):
    crl: List[str] = Field(default_factory=list)
    description: str = ""
    revoke: bool = False
    system_install: bool = False

class ACMEConfig(BaseModel):
    domain_name: str
    email: str
    listen_address: str = ""
    rsa_key_size: Literal[2048, 3072, 4096] = 2048
    url: str = ""

    @field_validator('domain_name', 'email')
    @classmethod
    def require_value(cls, value):
        value = value.strip()
        if not value:
            raise ValueError('This field is required for ACME')
        return value

    @field_validator('listen_address')
    @classmethod
    def validate_listen_address(cls, value):
        value = value.strip()
        if value:
            ip_address(value)
        return value

class ManagedCertificateItem(CertificateItem):
    certificate: str = ""
    description: str = ""
    revoke: bool = False
    acme: Optional[ACMEConfig] = None

class DHItem(BaseModel):
    name: str
    parameters: str

class KeysData(BaseModel):
    key_pair: List[KeyItem] = []
    openvpn: List[KeyItem] = []
    ssh: List[KeyItem] = []
    wireguard: List[KeyItem] = []
    dh: List[DHItem] = []

class CertificatesData(BaseModel):
    ca: List[CACertificateItem] = []
    certificate: List[ManagedCertificateItem] = []
    crl: List[CertificateItem] = []

class UpdateKeyCertDTO(BaseModel):
    keys: KeysData
    certificates: CertificatesData


class VerifyKeyCertDTO(BaseModel):
    keys: KeysData
    certificates: CertificatesData
