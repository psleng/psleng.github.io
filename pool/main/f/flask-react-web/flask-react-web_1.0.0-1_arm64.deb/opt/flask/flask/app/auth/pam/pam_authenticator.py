
import sys
import getpass
import os

from pam.__internals import PAM_SUCCESS, PAM_PROMPT_ECHO_OFF, PAM_PROMPT_ECHO_ON, PAM_ERROR_MSG
from pam.__internals import PAM_TEXT_INFO, PAM_SYSTEM_ERR, PAM_TTY, PAM_XDISPLAY, PAM_REINITIALIZE_CRED
from pam.__internals import PamAuthenticator, PamMessage, PamResponse, PamHandle, PamConv, conv_func, my_conv

from ctypes import c_char_p, c_int, c_size_t, c_void_p
from ctypes import py_object  
from ctypes import sizeof, cast, byref
from ctypes import memmove
from ctypes import POINTER

import logging

logger = logging.getLogger(__name__)


def normalize_authentication_failure_reason(reason, otp_submitted):
    if otp_submitted and 'Authentication failure' in reason:
        return 'OTP is incorrect'
    return reason


def public_authentication_failure(reason):
    if reason == 'Authentication failure':
        return 'Invalid username or password.', 'invalid_credentials'
    if reason == 'OTP is incorrect':
        return reason, 'invalid_otp'
    return reason or 'Authentication failed.', 'authentication_failed'


def send_socket_otp(request_message, *, otp_store, otp_store_request_id, socket_manager):

    event = otp_store.request_otp(otp_store_request_id, cooperative=True)
    try:
        socket_manager.emit_to_guest(
            ssid=otp_store_request_id,
            event='clientRequest',
            data={
                'action': 'login-mfa-password',
                'ssid': otp_store_request_id,
                'data': request_message,
            },
        )
        logger.debug('Waiting for OTP from client.')

        if not event.wait(timeout=60):
            logger.debug('OTP submission timed out.')
            return None
        otp = otp_store.get_otp(otp_store_request_id, event=event)
        if not otp:
            logger.debug('Failed to retrieve submitted OTP.')
            return None
        logger.debug('OTP received.')
        return otp
    finally:
        otp_store.cancel_otp_request(otp_store_request_id, event=event)


def interactive_conv(
        n_messages, messages, p_response, libc, msg_list: list, password: bytes, encoding: str,
        otp_callback=None, conversation_state=None):
    if conversation_state is None:
        conversation_state = {"password_sent": False, "otp_submitted": False}
    logger.debug(f"[DEBUG] interactive_conv called with {n_messages} messages")

    calloc = libc.calloc
    calloc.restype = c_void_p
    calloc.argtypes = [c_size_t, c_size_t]

    cpassword = c_char_p(password)

    addr = calloc(n_messages, sizeof(PamResponse))
    response = cast(addr, POINTER(PamResponse))
    p_response[0] = response

    for i in range(n_messages):
        message = messages[i].contents.msg
        if sys.version_info >= (3,):
            message = message.decode(encoding)

        msg_list.append(message)
        logger.debug(f"[DEBUG] Message {i}: style={messages[i].contents.msg_style}, content='{message}'")

        if messages[i].contents.msg_style == PAM_PROMPT_ECHO_OFF:
            if not conversation_state['password_sent']:
                # Password
                conversation_state['password_sent'] = True
                dst = calloc(len(password) + 1, sizeof(c_char_p))
                memmove(dst, cpassword, len(password))
                response[i].resp = dst
                logger.debug(f"[DEBUG] Responding to password prompt with provided password")
            else:
                # OTP - interactively prompt
                logger.debug(f"[DEBUG] Interactive prompt: {message}")
                if otp_callback:
                    otp_input = otp_callback(message)
                    if otp_input:
                        conversation_state['otp_submitted'] = True
                        otp_bytes = otp_input.encode(encoding)
                        dst = calloc(len(otp_bytes) + 1, sizeof(c_char_p))
                        memmove(dst, c_char_p(otp_bytes), len(otp_bytes))
                        response[i].resp = dst
                        logger.debug(f"[DEBUG] User provided OTP for prompt")
                    else:
                        response[i].resp = None
                        logger.debug(f"[DEBUG] No OTP provided for prompt")
                else:
                    user_input = getpass.getpass(f"{message}: ")
                    if user_input:
                        user_input_bytes = user_input.encode(encoding)
                        dst = calloc(len(user_input_bytes) + 1, sizeof(c_char_p))
                        memmove(dst, c_char_p(user_input_bytes), len(user_input_bytes))
                        response[i].resp = dst
                        logger.debug(f"[DEBUG] User provided input for prompt")
                    else:
                        response[i].resp = None
                        logger.debug(f"[DEBUG] No input provided for prompt")
            response[i].resp_retcode = 0

        elif messages[i].contents.msg_style == PAM_PROMPT_ECHO_ON:
            # Username or Challenge
            logger.debug(f"[DEBUG] Echo-on prompt: {message}")
            if otp_callback:
                otp_input = otp_callback(message)
                if otp_input:
                    conversation_state['otp_submitted'] = True
                    otp_bytes = otp_input.encode(encoding)
                    dst = calloc(len(otp_bytes) + 1, sizeof(c_char_p))
                    memmove(dst, c_char_p(otp_bytes), len(otp_bytes))
                    response[i].resp = dst
                    logger.debug(f"[DEBUG] User provided OTP for echo-on prompt")
                else:
                    response[i].resp = None
                    logger.debug(f"[DEBUG] No OTP provided for echo-on prompt")
            else:
                user_input = input(f"{message}: ")
                if user_input:
                    user_input_bytes = user_input.encode(encoding)
                    dst = calloc(len(user_input_bytes) + 1, sizeof(c_char_p))
                    memmove(dst, c_char_p(user_input_bytes), len(user_input_bytes))
                    response[i].resp = dst
                    logger.debug(f"[DEBUG] User provided input for echo-on prompt")
                else:
                    response[i].resp = None
                    logger.debug(f"[DEBUG] No input provided for echo-on prompt")
            response[i].resp_retcode = 0

        elif messages[i].contents.msg_style == PAM_ERROR_MSG:
            logger.debug(f"[ERROR] PAM Error: {message}")
            response[i].resp = None
            response[i].resp_retcode = 0

        elif messages[i].contents.msg_style == PAM_TEXT_INFO:
            logger.debug(f"[INFO] PAM Info: {message}")
            response[i].resp = None
            response[i].resp_retcode = 0

    logger.debug(f"[DEBUG] interactive_conv returning PAM_SUCCESS")
    return PAM_SUCCESS

class ExtendPamAuthenticator(PamAuthenticator):
    """Extended PAM Authenticator with OTP/Interactive support and privilege level access
    
    This class extends the base PamAuthenticator to provide:
    - OTP (One-Time Password) support
    - Interactive authentication prompts
    - Privilege level access from environment variables
    """

    def __init__(self):
        super().__init__()
        self.libc = self.libc
        self.calloc = self.calloc
        self.calloc.restype = c_void_p
        self.calloc.argtypes = [c_size_t, c_size_t]
    
    def authenticate(self, username, password, service='login', otp=None, interactive=False, **kwargs):
 
        logger.debug(f"[DEBUG] ExtendPamAuthenticator.authenticate called")
        logger.debug(f"[DEBUG] Parameters: username='{username}', service='{service}', otp={'***' if otp else None}, interactive={interactive}")
        
        if otp:
            combined_password = f"{password}{otp}"
            logger.debug(f"[DEBUG] Combined password with OTP")
        else:
            combined_password = password
        
        encoding = kwargs.get('encoding', 'utf-8')
        call_end = kwargs.get('call_end', True)
        resetcreds = kwargs.get('resetcreds', True)
        print_failure_messages = kwargs.get('print_failure_messages', False)
        otp_callback = kwargs.get('otp_callback')
        conversation_state = {
            'password_sent': False,
            'otp_submitted': False,
        }
        env = kwargs.get('env', None)
        
        @conv_func
        def __conv(n_messages, messages, p_response, app_data):
            pyob = cast(app_data, py_object).value

            msg_list = pyob.get('msgs')
            password = pyob.get('password')
            otp = pyob.get('otp')
            encoding = pyob.get('encoding')

            interactive_mode = pyob.get('interactive', False)
            logger.debug(f"[DEBUG] __conv called with {n_messages} messages, OTP: {otp is not None}, Interactive: {interactive_mode}")

            if interactive_mode:
                # Use interactive conversation function
                logger.debug(f"[DEBUG] Using interactive conversation function")
                return interactive_conv(
                    n_messages,
                    messages,
                    p_response,
                    self.libc,
                    msg_list,
                    password,
                    encoding,
                    otp_callback,
                    conversation_state,
                )
            else:
                # Use standard conversation function
                logger.debug(f"[DEBUG] Using standard conversation function")
                return my_conv(n_messages, messages, p_response, self.libc, msg_list, password, encoding)

        if isinstance(username, str):
            username = username.encode(encoding)
        if isinstance(combined_password, str):
            combined_password = combined_password.encode(encoding)
        if isinstance(service, str):
            service = service.encode(encoding)
        if otp is not None and isinstance(otp, str):
            otp = otp.encode(encoding)

        # Validate for null bytes
        validation_items = [username, combined_password, service]
        validation_names = ['username', 'password', 'service']
        
        if otp is not None:
            validation_items.append(otp)
            validation_names.append('otp')
            
        for item, name in zip(validation_items, validation_names):
            if b'\x00' in item:
                self.code = PAM_SYSTEM_ERR
                self.reason = f'{name} may not contain NUL bytes'
                raise ValueError(self.reason)

        logger.debug(f"[DEBUG] Starting PAM authentication for user: {username}")
        logger.debug(f"[DEBUG] Service: {service}")
        logger.debug(f"[DEBUG] OTP provided: {otp is not None}")
        logger.debug(f"[DEBUG] Interactive mode: {interactive}")
        
        app_data = {'msgs': self.messages, 'password': combined_password, 'otp': otp, 'interactive': interactive, 'encoding': encoding}
        conv = PamConv(__conv, c_void_p.from_buffer(py_object(app_data)))

        self.handle = PamHandle()
        logger.debug(f"[DEBUG] Calling pam_start...")
        retval = self.pam_start(service, username, byref(conv),
                                byref(self.handle))

        logger.debug(f"[DEBUG] pam_start returned: {retval}")
        if retval != PAM_SUCCESS:
            self.code = retval
            self.reason = ("pam_start() failed: %s" %
                           self.pam_strerror(self.handle, retval))
            logger.debug(f"[DEBUG] pam_start failed: {self.reason}")
            return False

        ctty = os.environ.get('DISPLAY')
        if not ctty and os.isatty(0):
            ctty = os.ttyname(0)

        if ctty:
            ctty_p = c_char_p(ctty.encode(encoding))
            retval = self.pam_set_item(self.handle, PAM_TTY, ctty_p)
            retval = self.pam_set_item(self.handle, PAM_XDISPLAY, ctty_p)

        if env:
            if not isinstance(env, dict):
                raise TypeError('"env" must be a dict')

            for key, value in env.items():
                if isinstance(key, bytes) and b'\x00' in key:
                    raise ValueError('"env{}" key cannot contain NULLs')
                if isinstance(value, bytes) and b'\x00' in value:
                    raise ValueError('"env{}" value cannot contain NULLs')

                name_value = "{}={}".format(key, value)
                retval = self.putenv(name_value, encoding)

        logger.debug(f"[DEBUG] Calling pam_authenticate...")
        auth_success = self.pam_authenticate(self.handle, 0)
        logger.debug(f"[DEBUG] pam_authenticate returned: {auth_success}")

        if auth_success == PAM_SUCCESS:
            logger.debug(f"[DEBUG] Calling pam_acct_mgmt...")
            auth_success = self.pam_acct_mgmt(self.handle, 0)
            logger.debug(f"[DEBUG] pam_acct_mgmt returned: {auth_success}")

        if auth_success == PAM_SUCCESS and resetcreds:
            logger.debug(f"[DEBUG] Calling pam_setcred...")
            auth_success = self.pam_setcred(self.handle, PAM_REINITIALIZE_CRED)
            logger.debug(f"[DEBUG] pam_setcred returned: {auth_success}")

        self.code = auth_success
        self.reason = self.pam_strerror(self.handle, auth_success)

        if sys.version_info >= (3,):
            self.reason = self.reason.decode(encoding)

        if auth_success != PAM_SUCCESS:
            self.reason = normalize_authentication_failure_reason(
                self.reason,
                bool(otp) or conversation_state['otp_submitted'],
            )

        # Extract environment variables
        if auth_success == PAM_SUCCESS:
            logger.debug(f"[DEBUG] Authentication successful, checking for privilege level...")
            try:
                privilege_info = self.get_privilege_from_environment(encoding)
                if privilege_info:
                    logger.debug(f"[DEBUG] PRIVILEGE INFO: {privilege_info}")
                    self.privilege_info = privilege_info
                else:
                    logger.debug(f"[DEBUG] No privilege level found in environment")
                    self.privilege_info = None
            except Exception as priv_e:
                logger.debug(f"[DEBUG] Error getting privilege level: {priv_e}")
                self.privilege_info = None

        if call_end and hasattr(self, 'pam_end'):
            self.pam_end(self.handle, auth_success)
            self.handle = None

        if print_failure_messages and self.code != PAM_SUCCESS:
            logger.debug(f"Failure: {self.reason}")

        logger.debug(f"[DEBUG] Authentication result: {auth_success == PAM_SUCCESS}")
        return auth_success == PAM_SUCCESS
    
    def get_privilege_from_environment(self, encoding='utf-8'):

        logger.debug(f"[DEBUG] get_privilege_from_environment called")
        
        try:
            if not self.handle:
                logger.debug(f"[DEBUG] No PAM handle available")
                return None
            
            privlvl_str = self.getenv("RADIUS_PRIVLVL", encoding)
            privileged_str = self.getenv("RADIUS_PRIVILEGED", encoding)
            
            logger.debug(f"[DEBUG] RADIUS_PRIVLVL from env: {privlvl_str}")
            logger.debug(f"[DEBUG] RADIUS_PRIVILEGED from env: {privileged_str}")
            
            if privlvl_str is not None:
                try:
                    privilege_level = int(privlvl_str)
                    privileged = privileged_str if privileged_str else 'no'
                    
                    privilege_info = {
                        'privilege_level': privilege_level,
                        'privileged': privileged
                    }
                    
                    logger.debug(f"[DEBUG] Successfully parsed privilege info from environment: {privilege_info}")
                    return privilege_info
                    
                except ValueError as e:
                    logger.debug(f"[DEBUG] Error parsing privilege level '{privlvl_str}': {e}")
                    return None
            else:
                logger.debug(f"[DEBUG] RADIUS_PRIVLVL not found in PAM environment")
                return None
                
        except Exception as e:
            logger.debug(f"[DEBUG] Exception in get_privilege_from_environment: {e}")
            return None
    
    def get_privilege_level(self):
        if hasattr(self, 'privilege_info') and self.privilege_info:
            return self.privilege_info.get('privilege_level')
        return None
    
    def is_privileged(self):
        if hasattr(self, 'privilege_info') and self.privilege_info:
            privileged_status = self.privilege_info.get('privileged', 'no')
            return privileged_status.lower() == 'yes'
        return False
    
    def get_privilege_info(self):
        return getattr(self, 'privilege_info', None)


def test_interactive_auth():

    auth = ExtendPamAuthenticator()
    
    username = input("Username: ")
    password = getpass.getpass("Password: ")
    
    try:
        result = auth.authenticate(username, password, service='login', interactive=True, call_end=True)
        
        print(f"\nAuthentication result: {result}")
        print(f"PAM code: {auth.code}")
        print(f"PAM reason: {auth.reason}")
        
        if auth.messages:
            print(f"\nPAM conversation messages:")
            for i, msg in enumerate(auth.messages, 1):
                print(f"  {i}: {msg}")
        
        if result:
            privilege_level = auth.get_privilege_level()
            is_privileged = auth.is_privileged()
            privilege_info = auth.get_privilege_info()
            
            print(f"  - Privilege level: {privilege_level}")
            print(f"  - Is privileged: {is_privileged}")
            print(f"  - Full privilege info: {privilege_info}")
        else:
            print("FAILED: Interactive Authentication failed")
            
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    test_interactive_auth()