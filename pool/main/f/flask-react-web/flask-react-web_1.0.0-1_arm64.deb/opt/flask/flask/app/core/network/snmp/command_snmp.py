from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return value is not None and str(value).strip() not in ['', 'None']

def format_description(description: str) -> str:
    return description.replace(' ', '_')

class SNMPCommand(Command):
    """Command class for SNMP service commands
    
    - set/delete service snmp contact <text>
    - set/delete service snmp description <text>
    - set/delete service snmp location <text>
    - set/delete service snmp oid-enable {ip-forward | ip-route-table | ip-net-to-media-table | ip-net-to-physical-phys-address}
    - set/delete service snmp protocol {udp | tcp}
    - set/delete service snmp smux-peer <oid-in-text>
    - set/delete service snmp trap-source {x.x.x.x | h:h:h:h:h:h:h}
    - set/delete service snmp community <community-name>
    - set/delete service snmp community <community-name> authorization {ro | rw}
    - set/delete service snmp community <community-name> client {x.x.x.x | h:h:h:h:h:h:h}
    - set/delete service snmp community <community-name> network {x.x.x.x/n | h:h:h:h:h:h:h/m}
    - set/delete service snmp listen-address {x.x.x.x | h:h:h:h:h:h:h}
    - set/delete service snmp listen-address {x.x.x.x | h:h:h:h:h:h:h} port <1-65535>
    - set/delete service snmp mib interface <interface-type-prefix>
    - set/delete service snmp mib interface-max <1-4294967295>
    - set/delete service snmp trap-target {x.x.x.x | h:h:h:h:h:h:h}
    - set/delete service snmp trap-target {x.x.x.x | h:h:h:h:h:h:h} community <text>
    - set/delete service snmp trap-target {x.x.x.x | h:h:h:h:h:h:h} port <1-65535>
    
    - set/delete service snmp v3 engineid <text-in-hex>
    - set/delete service snmp v3 group <grp-name>
    - set/delete service snmp v3 group <grp-name> mode {ro | rw}
    - set/delete service snmp v3 group <grp-name> seclevel {noauth | auth | priv}
    - set/delete service snmp v3 group <grp-name> view <view-name>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h}
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} protocol {udp | tcp}
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} type {inform | trap}
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} user <user-name>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} port <1-65535>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} auth encrypted-password <text-in-hex>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} auth plaintext-password <text>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} auth type {md5 | sha}
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} privacy encrypted-password <text>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} privacy plaintext-password <text>
    - set/delete service snmp v3 trap-target {x.x.x.x | h:h:h:h:h:h:h} privacy type {aes | des}
    - set/delete service snmp v3 user <user-name>
    - set/delete service snmp v3 user <user-name> group <group-name>
    - set/delete service snmp v3 user <user-name> mode {ro | rw}
    - set/delete service snmp v3 user <user-name> auth encrypted-password <hex-text>
    - set/delete service snmp v3 user <user-name> auth plaintext-password <text>
    - set/delete service snmp v3 user <user-name> auth type {md5 | sha}
    - set/delete service snmp v3 user <user-name> privacy
    - set/delete service snmp v3 user <user-name> privacy encrypted-password <text-in-hex>
    - set/delete service snmp v3 user <user-name> privacy plaintext-password <text>
    - set/delete service snmp v3 user <user-name> privacy type {des | aes}
    - set/delete service snmp v3 view <view-name> oid <oid-text>
    - set/delete service snmp v3 view <view-name> oid <oid-text> exclude <text>
    - set/delete service snmp v3 view <view-name> oid <oid-text> mask <text>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'snmp'))
            self.attributes = {
                'service': {
                    'snmp': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing SNMP cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.attributes['service']['snmp'] = data
            
            if 'contact' in data and is_str_not_empty(data['contact']):
                self.generate('service', 'snmp', 'contact', data['contact'])
            
            if 'description' in data and is_str_not_empty(data['description']):
                self.generate('service', 'snmp', 'description', format_description(data['description']))
            
            if 'location' in data and is_str_not_empty(data['location']):
                self.generate('service', 'snmp', 'location', data['location'])
            
            if 'oid-enable' in data:
                if isinstance(data['oid-enable'], list):
                    for oid in data['oid-enable']:
                        if is_str_not_empty(oid):
                            self.generate('service', 'snmp', 'oid-enable', oid)
                elif is_str_not_empty(data['oid-enable']):
                    self.generate('service', 'snmp', 'oid-enable', data['oid-enable'])
            
            if 'protocol' in data and is_str_not_empty(data['protocol']):
                if not (self.operator == 'delete' and isinstance(new_config, dict) and 'protocol' not in new_config):
                    self.generate('service', 'snmp', 'protocol', data['protocol'])
            
            if 'smux-peer' in data:
                if isinstance(data['smux-peer'], list):
                    for peer in data['smux-peer']:
                        if is_str_not_empty(peer):
                            self.generate('service', 'snmp', 'smux-peer', peer)
                elif is_str_not_empty(data['smux-peer']):
                    self.generate('service', 'snmp', 'smux-peer', data['smux-peer'])
            
            if 'trap-source' in data and is_str_not_empty(data['trap-source']):
                self.generate('service', 'snmp', 'trap-source', data['trap-source'])
            
            if 'community' in data:
                self._process_community_config(data['community'], current_config, new_config)
            
            if 'listen-address' in data:
                self._process_listen_address_config(data['listen-address'], current_config, new_config)
            
            if 'mib' in data:
                self._process_mib_config(data['mib'], current_config, new_config)
            
            if 'trap-target' in data:
                self._process_trap_target_config(data['trap-target'], current_config, new_config)
            
            if 'v3' in data:
                self._process_v3_config(data['v3'], current_config, new_config)
            
            print(f"Generated SNMP commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating SNMP commands: {e}")
            return []
    
    def _process_community_config(self, community_config, current_config, new_config):
        for community_name, community_data in community_config.items():
            if not isinstance(community_data, dict):
                community_data = {}

            base_path = ['service', 'snmp', 'community', community_name]

            if self.operator == 'delete' and community_name not in new_config.get('community', {}):
                self.generate(*base_path)
                continue

            if self.operator == 'set':
                self.generate(*base_path)
            
            if 'authorization' in community_data and is_str_not_empty(community_data['authorization']):
                self.generate(*base_path, 'authorization', community_data['authorization'])
            
            if 'client' in community_data:
                if isinstance(community_data['client'], list):
                    for client in community_data['client']:
                        if is_str_not_empty(client):
                            self.generate(*base_path, 'client', client)
                elif is_str_not_empty(community_data['client']):
                    self.generate(*base_path, 'client', community_data['client'])
            
            if 'network' in community_data:
                if isinstance(community_data['network'], list):
                    for network in community_data['network']:
                        if is_str_not_empty(network):
                            self.generate(*base_path, 'network', network)
                elif is_str_not_empty(community_data['network']):
                    self.generate(*base_path, 'network', community_data['network'])
    
    def _process_listen_address_config(self, listen_address_config, current_config, new_config):
        for address, address_data in listen_address_config.items():
            if not isinstance(address_data, dict):
                address_data = {}

            base_path = ['service', 'snmp', 'listen-address', address]
            
            if self.operator == 'delete' and address not in new_config.get('listen-address', {}):
                self.generate(*base_path)
                continue

            if self.operator == 'set':
                self.generate(*base_path)
            
            if 'port' in address_data and is_str_not_empty(address_data['port']):
                new_address_data = new_config.get('listen-address', {}).get(address, {}) if isinstance(new_config, dict) else None
                if self.operator == 'delete' and isinstance(new_address_data, dict) and 'port' not in new_address_data:
                    continue
                self.generate(*base_path, 'port', str(address_data['port']))
    
    def _process_mib_config(self, mib_config, current_config, new_config):
        base_path = ['service', 'snmp', 'mib']
        
        if 'interface' in mib_config:
            if isinstance(mib_config['interface'], list):
                for interface in mib_config['interface']:
                    if is_str_not_empty(interface):
                        self.generate(*base_path, 'interface', interface)
            elif is_str_not_empty(mib_config['interface']):
                self.generate(*base_path, 'interface', mib_config['interface'])
        
        if 'interface-max' in mib_config and is_str_not_empty(mib_config['interface-max']):
            self.generate(*base_path, 'interface-max', str(mib_config['interface-max']))
    
    def _process_trap_target_config(self, trap_target_config, current_config, new_config):
        for target_address, target_data in trap_target_config.items():
            base_path = ['service', 'snmp', 'trap-target', target_address]
            if self.operator == 'delete' and target_address not in new_config.get('trap-target', {}):
                self.generate(*base_path)
                continue
            if 'community' in target_data and is_str_not_empty(target_data['community']):
                self.generate(*base_path, 'community', target_data['community'])
            
            if 'port' in target_data and is_str_not_empty(target_data['port']):
                self.generate(*base_path, 'port', str(target_data['port']))
    
    def _process_v3_config(self, v3_config, current_config, new_config):
        base_path = ['service', 'snmp', 'v3']
        
        if 'engineid' in v3_config and is_str_not_empty(v3_config['engineid']):
            self.generate(*base_path, 'engineid', v3_config['engineid'])
        
        if 'group' in v3_config:
            self._process_v3_group_config(v3_config['group'], current_config, new_config)
        
        if 'trap-target' in v3_config:
            self._process_v3_trap_target_config(v3_config['trap-target'], current_config, new_config)
        
        if 'user' in v3_config:
            self._process_v3_user_config(v3_config['user'], current_config, new_config)
        
        if 'view' in v3_config:
            self._process_v3_view_config(v3_config['view'], current_config, new_config)
    
    def _process_v3_group_config(self, group_config, current_config, new_config):
        for group_name, group_data in group_config.items():
            base_path = ['service', 'snmp', 'v3', 'group', group_name]
            
            if self.operator == 'delete' and group_name not in new_config.get('v3', {}).get('group', {}):
                self.generate(*base_path)
                continue
            
            if 'mode' in group_data and is_str_not_empty(group_data['mode']):
                self.generate(*base_path, 'mode', group_data['mode'])
            
            if 'seclevel' in group_data and is_str_not_empty(group_data['seclevel']):
                self.generate(*base_path, 'seclevel', group_data['seclevel'])
            
            if 'view' in group_data and is_str_not_empty(group_data['view']):
                self.generate(*base_path, 'view', group_data['view'])
    
    def _process_v3_trap_target_config(self, trap_target_config, current_config, new_config):
        for target_address, target_data in trap_target_config.items():
            base_path = ['service', 'snmp', 'v3', 'trap-target', target_address]
            
            if self.operator == 'delete' and target_address not in new_config.get('v3', {}).get('trap-target', {}):
                self.generate(*base_path)
                continue
            if 'protocol' in target_data and is_str_not_empty(target_data['protocol']):
                self.generate(*base_path, 'protocol', target_data['protocol'])
            
            if 'type' in target_data and is_str_not_empty(target_data['type']):
                self.generate(*base_path, 'type', target_data['type'])
            
            if 'user' in target_data and is_str_not_empty(target_data['user']):
                self.generate(*base_path, 'user', target_data['user'])
            
            if 'port' in target_data and is_str_not_empty(target_data['port']):
                self.generate(*base_path, 'port', str(target_data['port']))
            
            if 'auth' in target_data:
                auth_path = base_path + ['auth']
                
                if 'encrypted-password' in target_data['auth'] and is_str_not_empty(target_data['auth']['encrypted-password']):
                    self.generate(*auth_path, 'encrypted-password', target_data['auth']['encrypted-password'])
                
                if 'plaintext-password' in target_data['auth'] and is_str_not_empty(target_data['auth']['plaintext-password']):
                    self.generate(*auth_path, 'plaintext-password', target_data['auth']['plaintext-password'])
                
                if 'type' in target_data['auth'] and is_str_not_empty(target_data['auth']['type']):
                    self.generate(*auth_path, 'type', target_data['auth']['type'])
            
            if 'privacy' in target_data:
                privacy_path = base_path + ['privacy']
                
                if 'encrypted-password' in target_data['privacy'] and is_str_not_empty(target_data['privacy']['encrypted-password']):
                    self.generate(*privacy_path, 'encrypted-password', target_data['privacy']['encrypted-password'])
                
                if 'plaintext-password' in target_data['privacy'] and is_str_not_empty(target_data['privacy']['plaintext-password']):
                    self.generate(*privacy_path, 'plaintext-password', target_data['privacy']['plaintext-password'])
                
                if 'type' in target_data['privacy'] and is_str_not_empty(target_data['privacy']['type']):
                    self.generate(*privacy_path, 'type', target_data['privacy']['type'])
    
    def _process_v3_user_config(self, user_config, current_config, new_config):
        for user_name, user_data in user_config.items():
            base_path = ['service', 'snmp', 'v3', 'user', user_name]
            
            if self.operator == 'delete' and user_name not in new_config.get('v3', {}).get('user', {}):
                self.generate(*base_path)
                continue
            
            if 'group' in user_data:
                if isinstance(user_data['group'], list):
                    for group in user_data['group']:
                        if is_str_not_empty(group):
                            self.generate(*base_path, 'group', group)
                elif is_str_not_empty(user_data['group']):
                    self.generate(*base_path, 'group', user_data['group'])
            
            if 'mode' in user_data and is_str_not_empty(user_data['mode']):
                self.generate(*base_path, 'mode', user_data['mode'])
            
            if 'auth' in user_data:
                auth_path = base_path + ['auth']
                
                if 'encrypted-password' in user_data['auth'] and is_str_not_empty(user_data['auth']['encrypted-password']):
                    self.generate(*auth_path, 'encrypted-password', user_data['auth']['encrypted-password'])
                
                if 'plaintext-password' in user_data['auth'] and is_str_not_empty(user_data['auth']['plaintext-password']):
                    self.generate(*auth_path, 'plaintext-password', user_data['auth']['plaintext-password'])
                
                if 'type' in user_data['auth'] and is_str_not_empty(user_data['auth']['type']):
                    self.generate(*auth_path, 'type', user_data['auth']['type'])
            
            if 'privacy' in user_data:
                privacy_path = base_path + ['privacy']
                
                if isinstance(user_data['privacy'], dict):
                    if 'encrypted-password' in user_data['privacy'] and is_str_not_empty(user_data['privacy']['encrypted-password']):
                        self.generate(*privacy_path, 'encrypted-password', user_data['privacy']['encrypted-password'])
                    
                    if 'plaintext-password' in user_data['privacy'] and is_str_not_empty(user_data['privacy']['plaintext-password']):
                        self.generate(*privacy_path, 'plaintext-password', user_data['privacy']['plaintext-password'])
                    
                    if 'type' in user_data['privacy'] and is_str_not_empty(user_data['privacy']['type']):
                        self.generate(*privacy_path, 'type', user_data['privacy']['type'])
                else:
                    self.generate(*privacy_path)
    
    def _process_v3_view_config(self, view_config, current_config, new_config):
        for view_name, view_data in view_config.items():
            base_path = ['service', 'snmp', 'v3', 'view', view_name]
            
            if self.operator == 'delete' and view_name not in new_config.get('v3', {}).get('view', {}):
                self.generate(*base_path)
                continue
            
            if 'oid' in view_data:
                for oid, oid_data in view_data['oid'].items():
                    oid_path = base_path + ['oid', oid]
                    
                    if self.operator == 'delete' and oid not in new_config.get('v3', {}).get('view', {}).get('oid', {}):
                        self.generate(*oid_path)
                        continue
                    
                    # Generate base OID command if no exclude/mask, or if oid_data is empty
                    has_exclude = 'exclude' in oid_data and is_str_not_empty(oid_data['exclude'])
                    has_mask = 'mask' in oid_data and is_str_not_empty(oid_data['mask'])
                    
                    if has_exclude:
                        self.generate(*oid_path, 'exclude', oid_data['exclude'])
                    
                    if has_mask:
                        self.generate(*oid_path, 'mask', oid_data['mask'])
                    
                    # If no exclude or mask, generate base OID command
                    if not has_exclude and not has_mask:
                        self.generate(*oid_path)


if __name__ == "__main__":
    pass
