import threading
from queue import Queue
from typing import Any, Dict, Optional
from uuid import uuid4
from datetime import datetime


class VyosTaskQueue:
    def __init__(self):
        self._task_queue: "Queue[Dict[str, Any]]" = Queue()
        self._finished_queue: "Queue[Dict[str, Any]]" = Queue()
        self._tasks: Dict[str, Dict[str, Any]] = {}

        self._worker_lock = threading.Lock()
        self._worker_started = False

        self._consumer_lock = threading.Lock()
        self._consumer_started = False

    def ensure_worker_started(self) -> None:
        if self._worker_started:
            return

        with self._worker_lock:
            if self._worker_started:
                return

            def worker_loop() -> None:
                while True:
                    task = self._task_queue.get()
                    try:
                        task_id = task.get('task_id')
                        if task_id in self._tasks:
                            self._tasks[task_id]['state'] = 'running'
                            self._tasks[task_id]['started_at'] = datetime.utcnow().isoformat() + 'Z'

                        http = task.get('http')
                        action = task.get('action')
                        data = task.get('data')
                        verify = task.get('verify', False)
                        user_token = task.get('user_token')

                        result = None
                        error = None
                        try:
                            response = http._send_request_direct(action=action, data=data, verify=verify)
                            try:
                                result = response.json()
                            except Exception:
                                result = {'status_code': getattr(response, 'status_code', None)}
                            status_code = getattr(response, 'status_code', None)
                            if status_code is not None and status_code >= 400:
                                error = result
                        except Exception as e:
                            error = str(e)

                        if task_id in self._tasks:
                            self._tasks[task_id]['state'] = 'failed' if error else 'success'
                            self._tasks[task_id]['result'] = result
                            self._tasks[task_id]['error'] = error

                        self._finished_queue.put({
                            'task_id': task_id,
                            'user_token': user_token,
                            'action': getattr(action, 'name', str(action)),
                            'request_data': task.get('request_data'),
                            'data': data,
                            'result': result,
                            'error': error,
                            'finished_at': datetime.utcnow().isoformat() + 'Z',
                        })
                    finally:
                        self._task_queue.task_done()

            thread = threading.Thread(target=worker_loop, daemon=True)
            thread.start()
            self._worker_started = True

    def get_finished_queue(self) -> Queue:
        self.ensure_worker_started()
        return self._finished_queue

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        return self._tasks.get(task_id)

    def get_all_tasks(self) -> Dict[str, Any]:
        """Return a snapshot"""
        self.ensure_worker_started()

        tasks = list(self._tasks.values())

        finished_tasks = []
        active_tasks = []
        for t in tasks:
            state = (t.get('state') or '').lower()
            if state in ['success', 'failed']:
                finished_tasks.append(t)
            else:
                active_tasks.append(t)

        with self._task_queue.mutex:
            raw_queued_items = list(self._task_queue.queue)

        queued_items = []
        for item in raw_queued_items:
            try:
                action = item.get('action')
                queued_items.append({
                    'task_id': item.get('task_id'),
                    'action': getattr(action, 'name', str(action)).lower() if action is not None else None,
                    'user_token': item.get('user_token'),
                    'state': 'queued',
                })
            except Exception:
                queued_items.append({'task_id': item.get('task_id'), 'state': 'queued'})

        with self._finished_queue.mutex:
            finished_items = list(self._finished_queue.queue)

        return {
            'tasks': tasks,
            'active_tasks': active_tasks,
            'finished_queue': finished_tasks,
            'queued': queued_items,
            'counts': {
                'tasks': len(tasks),
                'active_tasks': len(active_tasks),
                'finished_tasks': len(finished_tasks),
                'queued': len(queued_items),
                'finished_queue': len(finished_items),
            }
        }

    def enqueue_vyos_task(self, *, http, action, data, verify: bool, user_token: Optional[str]) -> str:
        self.ensure_worker_started()

        task_id = str(uuid4())

        try:
            request_data = data
            if not isinstance(request_data, (str, int, float, bool, list, dict, type(None))):
                request_data = str(request_data)
        except Exception:
            request_data = None

        self._tasks[task_id] = {
            'task_id': task_id,
            'state': 'queued',
            'action': getattr(action, 'name', str(action)).lower(),
            'user_token': user_token,
            'request_data': request_data,
            'queued_at': datetime.utcnow().isoformat() + 'Z',
            'started_at': None,
            'finished_at': None,
            'result': None,
            'error': None,
        }

        self._task_queue.put({
            'task_id': task_id,
            'http': http,
            'action': action,
            'data': data,
            'request_data': request_data,
            'verify': verify,
            'user_token': user_token,
        })

        return task_id

    def _start_vyos_finished_task_consumer(self, *, socket_manager, logger) -> None:
        if self._consumer_started:
            return

        with self._consumer_lock:
            if self._consumer_started:
                return

            def consumer_loop() -> None:
                finished_q = self.get_finished_queue()
                while True:
                    try:
                        finished = finished_q.get()
                        try:
                            user_token = finished.get('user_token')
                            task_id = finished.get('task_id')
                            action = finished.get('action')
                            error = finished.get('error')
                            result = finished.get('result', {})
                            result_success = result.get('success', None)
                            result_data = result.get('data', "")
                            result_error = result.get('error', "")

                            print("Task finished: ") 
                            print(finished)

                            if user_token:
                                if error:
                                    task_content = "FAILED: {}. Error: {}".format(task_id, error)
                                else:
                                    if result_success is False:
                                        task_content = "FAILED: {}. Error: {} {}".format(task_id, result_data, result_error)
                                    else:
                                        task_content = "SUCCESS {}".format(task_id)
                                
                                socket_manager.emit_to_user(
                                    user_token=user_token,
                                    event='notification',
                                    data={
                                        'id': str(uuid4()),
                                        'type': 'success',
                                        'title': 'Task Finished',
                                        'content': task_content,
                                        'task_id': task_id,
                                        'action': action,
                                        'result': finished.get('result'),
                                        'error': error,
                                    }
                                )
                        finally:
                            finished_q.task_done()
                    except Exception as e:
                        logger.error('Finished task consumer error')
                        logger.error(str(e))
                        threading.Event().wait(0.2)

            thread = threading.Thread(target=consumer_loop, daemon=True)
            thread.start()
            self._consumer_started = True


vyos_task_queue = VyosTaskQueue()
