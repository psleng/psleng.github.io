def _has_value(value):
    return value is not None and str(value).strip() != ''


def _parse_interfaces_to_vyos_config(data):
    interfaces = {}
    for intf in data.get('interfaces', []):
        if not intf.get('name'):
            continue
        
        intf_config = {}
        
        split_horizon = intf.get('splitHorizon', 'enabled')
        if split_horizon == 'enabled':
            intf_config['split-horizon'] = {}
        elif split_horizon == 'disabled':
            intf_config['split-horizon'] = {'disable': {}}
        elif split_horizon == 'poison-reverse':
            intf_config['split-horizon'] = {'poison-reverse': {}}
        
        interfaces[intf['name']] = intf_config
    
    return interfaces


def _parse_redistribution_to_vyos_config(data):
    redistribution = {}
    redist = data.get('redistribution', {})
    
    for protocol in ['connected', 'kernel', 'ospfv3', 'static']:
        if redist.get(protocol, {}).get('enabled'):
            proto_config = {}
            if _has_value(redist[protocol].get('metric')):
                proto_config['metric'] = redist[protocol]['metric']
            redistribution[protocol] = proto_config if proto_config else {}
    
    return redistribution


def _parse_advanced_to_vyos_config(data):
    config = {}
    advanced = data.get('advanced', {})
    
    if advanced.get('defaultInformationOriginate'):
        config['default-information'] = {'originate': {}}
    
    if _has_value(advanced.get('defaultMetric')):
        config['default-metric'] = advanced['defaultMetric']
    
    if _has_value(advanced.get('routeMap')):
        config['route-map'] = advanced['routeMap']
    
    timers = {}
    if _has_value(advanced.get('timersGarbageCollection')):
        timers['garbage-collection'] = advanced['timersGarbageCollection']
    if _has_value(advanced.get('timersTimeout')):
        timers['timeout'] = advanced['timersTimeout']
    if _has_value(advanced.get('timersUpdate')):
        timers['update'] = advanced['timersUpdate']
    
    if timers:
        config['timers'] = timers
    
    return config


def parse_to_vyos_config(data):
    """Convert RIPng DTO to VyOS configuration format"""
    config = {}
    advanced_input = data.get('advanced', {})
    
    aggregate_addresses_input = data.get('aggregateAddresses')
    if not aggregate_addresses_input:
        aggregate_addresses_input = advanced_input.get('aggregateAddresses')

    if aggregate_addresses_input:
        aggregate_addresses = [addr for addr in aggregate_addresses_input]
        if len(aggregate_addresses) == 1:
            config['aggregate-address'] = aggregate_addresses[0]
        else:
            config['aggregate-address'] = aggregate_addresses
    
    if data.get('networks'):
        networks = [network for network in data['networks']]
        if len(networks) == 1:
            config['network'] = networks[0]
        else:
            config['network'] = networks
    
    passive_interfaces_input = data.get('passiveInterfaces')
    if not passive_interfaces_input:
        passive_interfaces_input = advanced_input.get('passiveInterfaces')

    if passive_interfaces_input:
        config['passive-interface'] = [intf for intf in passive_interfaces_input]
    
    if data.get('routes'):
        routes = [route for route in data['routes']]
        if len(routes) == 1:
            config['route'] = routes[0]
        else:
            config['route'] = routes
    
    interfaces = _parse_interfaces_to_vyos_config(data)
    if interfaces:
        config['interface'] = interfaces
    
    redistribution = _parse_redistribution_to_vyos_config(data)
    if redistribution:
        config['redistribute'] = redistribution
    
    advanced_config = _parse_advanced_to_vyos_config(data)
    config.update(advanced_config)
    
    return config


def parse_to_vyos_config_verify(data):
    """Convert RIPng verify DTO to VyOS configuration format"""
    return parse_to_vyos_config(data)
