
from typing import Any

from app.core.api.http.cmd.command import Command


def _is_str_not_empty(value: Any) -> bool:
    return value is not None and str(value) not in ['', 'None']


def _truthy_flag(value: Any) -> bool:
    return value not in [False, None, 'disable', 'false', 'False', 0]


class HTTPSCommand(Command):
    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not isinstance(data, dict):
            return []

        base = ['service', 'https']

        if data:
            self._generate_allow_clients(data, base)
            self._generate_enable_http_redirect(data, base)
            self._generate_listen_addresses(data, base)
            self._generate_port(data, base, new_config)
            self._generate_request_body_size_limit(data, base)
            self._generate_tls_versions(data, base)
            self._generate_api(data, base, current_config, new_config)
        self._generate_certificates(data, base, current_config, new_config)

        return self.cmds

    def _generate_allow_clients(self, data: dict, base: list):
        allow_clients = data.get('allow_clients')
        if allow_clients:
            for item in allow_clients:
                if not isinstance(item, dict):
                    continue
                addr = item.get('address')
                if not _is_str_not_empty(str(addr).strip()):
                    continue
                self.generate(*base, 'allow-client', 'address', str(addr))
            return

        allow_client_block = data.get('allow-client')
        if not isinstance(allow_client_block, dict):
            return

        addrs = allow_client_block.get('address')
        if isinstance(addrs, list):
            for addr in addrs:
                if not _is_str_not_empty(str(addr).strip()):
                    continue
                self.generate(*base, 'allow-client', 'address', str(addr))
        elif _is_str_not_empty(str(addrs).strip()):
            self.generate(*base, 'allow-client', 'address', str(addrs))

    def _generate_enable_http_redirect(self, data: dict, base: list):
        if 'enable_http_redirect' in data or 'enable-http-redirect' in data:
            self.generate(*base, 'enable-http-redirect')

    def _generate_listen_addresses(self, data: dict, base: list):
        listen_addresses = data.get('listen_addresses')
        if listen_addresses:
            for addr in listen_addresses:
                if not _is_str_not_empty(str(addr).strip()):
                    continue
                self.generate(*base, 'listen-address', str(addr))
            return

        la = data.get('listen-address')
        if isinstance(la, list):
            for addr in la:
                if not _is_str_not_empty(str(addr).strip()):
                    continue
                self.generate(*base, 'listen-address', str(addr))
        elif _is_str_not_empty(str(la).strip()):
            self.generate(*base, 'listen-address', str(la))

    def _generate_port(self, data: dict, base: list, new_config: dict = None):
        port = data.get('port')
        if (port is None or str(port).strip() == '') and self.operator == 'set':
            return
        else:
            self.generate(*base, 'port', str(port))

    def _generate_request_body_size_limit(self, data: dict, base: list):
        rbs = data.get('request_body_size_limit')
        if rbs is None:
            rbs = data.get('request-body-size-limit')
        if rbs is None:
            return

        if self.operator == 'delete':
            self.generate(*base, 'request-body-size-limit')
        else:
            self.generate(*base, 'request-body-size-limit', str(rbs))

    def _generate_tls_versions(self, data: dict, base: list):
        tls_versions = data.get('tls_versions')
        if tls_versions is None:
            tls_versions = data.get('tls-version')
        if not tls_versions:
            return

        for v in tls_versions:
            if not _is_str_not_empty(str(v).strip()):
                continue
            self.generate(*base, 'tls-version', str(v))

    def _generate_api(self, data: dict, base: list, current_config: dict, new_config: dict):
        api = data.get('api')
        if not isinstance(api, dict):
            return

        self._generate_api_graphql(api, base)
        self._generate_api_keys(api, base, current_config, new_config)
        self._generate_api_rest(api, base)

    def _generate_api_graphql(self, api: dict, base: list):
        graphql = api.get('graphql')
        api_graphql_path = [*base, 'api', 'graphql']
        if not isinstance(graphql, dict):
            return

        auth = graphql.get('authentication')
        if not isinstance(auth, dict):
            return

        expiration = auth.get('expiration')
        if expiration is not None and str(expiration).strip() != '':
            if self.operator == 'delete':
                self.generate(*api_graphql_path, 'authentication', 'expiration')
            else:
                self.generate(*api_graphql_path, 'authentication', 'expiration', str(expiration).strip())

        secret_length = auth.get('secret_length')
        if secret_length is None:
            secret_length = auth.get('secret-length')
        if secret_length is not None and str(secret_length).strip() != '':
            if self.operator == 'delete':
                self.generate(*api_graphql_path, 'authentication', 'secret-length')
            else:
                self.generate(*api_graphql_path, 'authentication', 'secret-length', str(secret_length).strip())

        if _is_str_not_empty(str(auth.get('type')).strip()):
            if self.operator == 'delete':
                self.generate(*api_graphql_path, 'authentication', 'type')
            else:
                self.generate(*api_graphql_path, 'authentication', 'type', str(auth.get('type')))

    def _generate_api_keys(self, api: dict, base: list, current_config: dict, new_config: dict):
        keys = api.get('keys')
        api_key_path = [*base, 'api', 'keys']
        if isinstance(keys, list) and keys:
            for k in keys:
                if not isinstance(k, dict):
                    continue
                key_id = k.get('id')
                if not _is_str_not_empty(str(key_id).strip()):
                    continue
                if self.operator == 'delete':
                    if key_id not in new_config.get('api', {}).get('keys', {}).get('id', {}):
                        self.generate(*api_key_path, 'id', str(key_id))
                        continue
                    if _is_str_not_empty(str(k.get('key')).strip()):
                        self.generate(*api_key_path, 'id', str(key_id), 'key')
                else:
                    if _is_str_not_empty(str(k.get('key')).strip()):
                        self.generate(*api_key_path, 'id', str(key_id), 'key', str(k.get('key')))
                    else:
                        self.generate(*api_key_path, 'id', str(key_id))
            return

        if not isinstance(keys, dict):
            return

        ids = keys.get('id')
        if not isinstance(ids, dict):
            return

        for key_id, key_cfg in ids.items():
            if not _is_str_not_empty(str(key_id).strip()):
                continue
            key_val = None
            if isinstance(key_cfg, dict):
                key_val = key_cfg.get('key')
            if self.operator == 'delete':
                if key_id not in new_config.get('api', {}).get('keys', {}).get('id', {}):
                    self.generate(*api_key_path, 'id', str(key_id))
                    continue
                if _is_str_not_empty(str(key_val).strip()):
                    self.generate(*api_key_path, 'id', str(key_id), 'key', str(key_val))
                
            else:
                if _is_str_not_empty(str(key_val).strip()):
                    self.generate(*api_key_path, 'id', str(key_id), 'key', str(key_val))
                else:
                    self.generate(*api_key_path, 'id', str(key_id))

    def _generate_api_rest(self, api: dict, base: list):
        api_rest_path = [*base, 'api', 'rest']
        if 'rest' in api and self.operator == 'set':
            self.generate(*api_rest_path)

        rest = api.get('rest')
        if isinstance(rest, dict):
            if 'debug' in rest or 'rest_debug' in api:
                self.generate(*api_rest_path, 'debug')
            if 'strict' in rest or 'rest_strict' in api:
                self.generate(*api_rest_path, 'strict')

    def _generate_certificates(self, data: dict, base: list, current_config: dict, new_config: dict):
        cert_path = [*base, 'certificates']
        if (
            self.operator == 'delete'
            and isinstance(current_config, dict)
            and 'certificates' in current_config
            and isinstance(new_config, dict)
            and not any((new_config.get('certificates') or {}).get(key)
                        for key in ('ca-certificate', 'certificate', 'dh-params'))
        ):
            self.generate(*cert_path)
            return

        ca_cert = data.get('ca_certificate')
        if ca_cert is None and isinstance(data.get('certificates'), dict):
            ca_cert = data.get('certificates', {}).get('ca-certificate')
        if ca_cert is not None:
            if self.operator == 'delete':
                self.generate(*cert_path, 'ca-certificate')
            else:
                self.generate(*cert_path, 'ca-certificate', str(ca_cert))

        cert = data.get('certificate')
        if cert is None and isinstance(data.get('certificates'), dict):
            cert = data.get('certificates', {}).get('certificate')
        if cert is not None:
            if self.operator == 'delete':
                self.generate(*cert_path, 'certificate')
            else:
                self.generate(*cert_path, 'certificate', str(cert))

        dhp = data.get('dh_params')
        if dhp is None and isinstance(data.get('certificates'), dict):
            dhp = data.get('certificates', {}).get('dh-params')
        if dhp is not None:
            if self.operator == 'delete':
                self.generate(*cert_path, 'dh-params')
            else:
                self.generate(*cert_path, 'dh-params', str(dhp))
