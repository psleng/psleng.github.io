def parseInt(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None

def is_positive_number(value):
    parsed = parseInt(value)
    return parsed is not None and parsed > 0

def normalize_group_name(name):
    if isinstance(name, str):
        return name.replace('-', '_')
    return name

def _normalize_ikev2_reauth_value(value):
    if value is None or value == "":
        return None

    if value is True:
        return "yes"
    if value is False:
        return "no"

    if isinstance(value, str):
        v = value.strip().lower()
        if v in {"yes", "no", "inherit"}:
            return v

    return None

def _as_list(value):
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [v for v in value if v not in (None, "")]
    if isinstance(value, dict):
        return list(value.keys())
    return [value]

def _first_interface_address(value):
    addresses = _as_list(value)
    return addresses[0] if addresses else None

def _get_vti_addresses(os_config):
    vti_config = os_config.get('interfaces', {}).get('vti', {}) if isinstance(os_config, dict) else {}
    if not isinstance(vti_config, dict):
        return {}

    return {
        name: _first_interface_address(config.get('address') if isinstance(config, dict) else None)
        for name, config in vti_config.items()
    }

def _parse_with_vti_addresses(ipsec_config, os_config):
    if not isinstance(ipsec_config, dict):
        return ipsec_config

    vti_addresses = _get_vti_addresses(os_config)
    if not vti_addresses:
        return ipsec_config

    peers = ipsec_config.get('site-to-site', {}).get('peer', {})
    if isinstance(peers, dict):
        for peer_config in peers.values():
            if not isinstance(peer_config, dict):
                continue
            vti_value = peer_config.get('vti')
            vti_bind = vti_value.get('bind') if isinstance(vti_value, dict) else vti_value
            if vti_bind in vti_addresses and vti_addresses[vti_bind]:
                if not isinstance(peer_config.get('vti'), dict):
                    peer_config['vti'] = {'bind': vti_bind}
                peer_config['vti']['address'] = vti_addresses[vti_bind]

    connections = ipsec_config.get('remote-access', {}).get('connection', {})
    if isinstance(connections, dict):
        for conn_config in connections.values():
            if not isinstance(conn_config, dict):
                continue
            vti_bind = conn_config.get('bind')
            if vti_bind in vti_addresses and vti_addresses[vti_bind]:
                conn_config['vti-address'] = vti_addresses[vti_bind]

    return ipsec_config

def parse_to_ipsec_config(data):

    config = {}
    
    security = data.get('security') or {}

    if security:
        preshared_keys = security.get('presharedKeys') or []
        if preshared_keys:
            config['authentication'] = {'psk': {}}
            for psk in preshared_keys:
                psk_config = {}
                if psk.get('id'):
                    ids = _as_list(psk['id'])
                    psk_config['id'] = ids[0] if len(ids) == 1 else ids
                if psk.get('dhcpInterface'):
                    dhcp_interfaces = _as_list(psk['dhcpInterface'])
                    psk_config['dhcp-interface'] = (
                        dhcp_interfaces[0] if len(dhcp_interfaces) == 1 else dhcp_interfaces
                    )
                if psk.get('secret'):
                    psk_config['secret'] = psk['secret']
                if psk.get('secretType'):
                    psk_config['secret-type'] = psk['secretType']
                config['authentication']['psk'][psk['name']] = psk_config
    
    if 'espGroups' in security:
        if security['espGroups']:
            config['esp-group'] = {}
            for esp_group in security['espGroups']:
                group_config = {}
                
                if esp_group.get('compression'):
                    group_config['compression'] = {}
                if esp_group.get('disableRekey'):
                    group_config['disable-rekey'] = {}
                if is_positive_number(esp_group.get('lifeBytes')):
                    group_config['life-bytes'] = str(esp_group['lifeBytes'])
                if is_positive_number(esp_group.get('lifePackets')):
                    group_config['life-packets'] = str(esp_group['lifePackets'])
                if is_positive_number(esp_group.get('lifetime')):
                    group_config['lifetime'] = str(esp_group['lifetime'])
                if esp_group.get('mode'):
                    group_config['mode'] = esp_group['mode']
                if esp_group.get('pfs'):
                    group_config['pfs'] = esp_group['pfs']
                
                if esp_group.get('proposals') and len(esp_group['proposals']) > 0:
                    group_config['proposal'] = {}
                    for i, proposal in enumerate(esp_group['proposals'], 1):
                        prop_config = {}
                        if proposal.get('encryption'):
                            prop_config['encryption'] = proposal['encryption']
                        if proposal.get('hash'):
                            prop_config['hash'] = proposal['hash']
                        
                        prop_num = proposal.get('proposal') or proposal.get('number') or str(i)
                        group_config['proposal'][prop_num] = prop_config
                
                config['esp-group'][normalize_group_name(esp_group['name'])] = group_config
    
    if 'ikeGroups' in security:
        if security['ikeGroups']:
            config['ike-group'] = {}
            for ike_group in security['ikeGroups']:
                group_config = {}
                
                if ike_group.get('keyExchange'):
                    group_config['key-exchange'] = ike_group['keyExchange']
                
                if ike_group.get('lifetime') and parseInt(ike_group['lifetime']) and parseInt(ike_group['lifetime']) > 0:
                    group_config['lifetime'] = str(ike_group['lifetime'])
                
                if ike_group.get('mode'):
                    group_config['mode'] = ike_group['mode']
                
                if ike_group.get('closeAction') and ike_group['closeAction'] != 'none':
                    group_config['close-action'] = ike_group['closeAction']
                
                if 'advanced' in ike_group:
                    advanced = ike_group['advanced']
                    
                    if advanced.get('closeAction') and advanced['closeAction'] != 'none':
                        group_config['close-action'] = advanced['closeAction']
                    
                    if advanced.get('disableMobike'):
                        group_config['disable-mobike'] = {}
                    
                    if advanced.get('ikev2Reauth'):
                        group_config['ikev2-reauth'] = {}
                    
                    if advanced.get('keyExchange'):
                        group_config['key-exchange'] = advanced['keyExchange']
                    
                    if advanced.get('lifetime') and parseInt(advanced['lifetime']) and parseInt(advanced['lifetime']) > 0:
                        group_config['lifetime'] = str(advanced['lifetime'])
                    
                    if advanced.get('mode'):
                        group_config['mode'] = advanced['mode']
                    
                    if 'deadPeerDetection' in advanced:
                        dpd = advanced['deadPeerDetection']
                        if dpd.get('action'):
                            group_config['dead-peer-detection'] = {'action': dpd['action']}
                        if dpd.get('interval') and parseInt(dpd['interval']) and parseInt(dpd['interval']) > 0:
                            if 'dead-peer-detection' not in group_config:
                                group_config['dead-peer-detection'] = {}
                            group_config['dead-peer-detection']['interval'] = str(dpd['interval'])
                        if dpd.get('timeout') and parseInt(dpd['timeout']) and parseInt(dpd['timeout']) > 0:
                            if 'dead-peer-detection' not in group_config:
                                group_config['dead-peer-detection'] = {}
                            group_config['dead-peer-detection']['timeout'] = str(dpd['timeout'])
                
                if ike_group.get('proposals') and len(ike_group['proposals']) > 0:
                    group_config['proposal'] = {}
                    for i, proposal in enumerate(ike_group['proposals'], 1):
                        prop_config = {}
                        if proposal.get('dhGroup'):
                            prop_config['dh-group'] = proposal['dhGroup']
                        if proposal.get('encryption'):
                            prop_config['encryption'] = proposal['encryption']
                        if proposal.get('hash'):
                            prop_config['hash'] = proposal['hash']
                        if proposal.get('prf'):
                            prop_config['prf'] = proposal['prf']
                        
                        prop_num = proposal.get('proposal') or proposal.get('number') or str(i)
                        group_config['proposal'][prop_num] = prop_config
                
                config['ike-group'][normalize_group_name(ike_group['name'])] = group_config
    
    if data.get('interface'):
        if isinstance(data['interface'], list):
            config['interface'] = data['interface']
        else:
            config['interface'] = [data['interface']]
    
    if data.get('disableUniqreqids'):
        config['disable-uniqreqids'] = {}
    
    if 'general' in data:
        options_config = {}
        
        # Process options if present
        if 'options' in data['general']:
            options = data['general']['options']
            
            if options.get('disableRouteAutoinstall'):
                options_config['disable-route-autoinstall'] = {}
            
            # Note: interface is set globally at root level, not in options
            # if options.get('interface'):
            #     options_config['interface'] = options['interface']
            
            if options.get('flexvpn'):
                options_config['flexvpn'] = {}
            
            if options.get('virtualIp'):
                options_config['virtual-ip'] = {}
        
        retrans = None
        if 'retransmission' in data['general']:
            retrans = data['general']['retransmission']
        elif 'options' in data['general'] and isinstance(data['general']['options'], dict) and 'retransmission' in data['general']['options']:
            retrans = data['general']['options']['retransmission']

        if retrans is not None:
            if retrans.get('attempt') or retrans.get('base') or retrans.get('timeout'):
                retrans_config = {}
                if retrans.get('attempt') and str(retrans.get('attempt')).strip():
                    attempt_val = parseInt(retrans['attempt'])
                    if attempt_val is not None and attempt_val > 0:
                        retrans_config['attempt'] = str(retrans['attempt'])
                if retrans.get('base') and str(retrans.get('base')).strip():
                    try:
                        base_val = float(retrans['base'])
                        if base_val > 0:
                            retrans_config['base'] = str(retrans['base'])
                    except (ValueError, TypeError):
                        pass
                if retrans.get('timeout') and str(retrans.get('timeout')).strip():
                    timeout_val = parseInt(retrans['timeout'])
                    if timeout_val is not None and timeout_val > 0:
                        retrans_config['timeout'] = str(retrans['timeout'])

                if retrans_config:
                    options_config['retransmission'] = retrans_config
        
        if options_config:
            config['options'] = options_config
    
    if 'general' in data and 'remoteAccess' in data['general']:
        remote_access = data['general']['remoteAccess']
        ra_config = {}
        
        if remote_access.get('connections'):
            ra_config['connection'] = {}
            for conn in remote_access['connections']:
                conn_config = {}
                
                if conn.get('description'):
                    conn_config['description'] = conn['description']
                
                if not conn.get('enabled', True):
                    conn_config['disable'] = {}
                
                if conn.get('bind'):
                    conn_config['bind'] = conn['bind']

                if conn.get('vtiAddress'):
                    conn_config['vti-address'] = conn['vtiAddress']
                
                if conn.get('dhcpInterface'):
                    conn_config['dhcp-interface'] = conn['dhcpInterface']
                
                if conn.get('ikeGroup'):
                    conn_config['ike-group'] = normalize_group_name(conn['ikeGroup'])
                
                if conn.get('espGroup'):
                    conn_config['esp-group'] = normalize_group_name(conn['espGroup'])
                
                if conn.get('localAddress'):
                    conn_config['local-address'] = conn['localAddress']
                
                if conn.get('replayWindow') and parseInt(conn['replayWindow']) and parseInt(conn['replayWindow']) > 0:
                    conn_config['replay-window'] = str(conn['replayWindow'])
                
                if conn.get('timeout') and parseInt(conn['timeout']) and parseInt(conn['timeout']) > 0:
                    conn_config['timeout'] = str(conn['timeout'])
                
                if conn.get('unique') and conn['unique'] != 'never':
                    conn_config['unique'] = conn['unique']
                
                if 'local' in conn:
                    local = conn['local']
                    if local.get('port'):
                        conn_config['local'] = {'port': str(local['port'])}
                    if local.get('prefix'):
                        if 'local' not in conn_config:
                            conn_config['local'] = {}
                        prefix = local['prefix']
                        conn_config['local']['prefix'] = prefix[0] if isinstance(prefix, list) and len(prefix) == 1 else prefix
                    if local.get('address'):
                        if 'local' not in conn_config:
                            conn_config['local'] = {}
                        conn_config['local-address'] = local['address']
                
                if conn.get('pool'):
                    conn_config['pool'] = conn['pool']
                elif 'pools' in conn:
                    pools = conn['pools']
                    if pools.get('name'):
                        conn_config['pool'] = pools['name']
                    if pools.get('dhcp'):
                        conn_config['pool'] = pools['dhcp']
                    if pools.get('radius'):
                        conn_config['pool'] = pools['radius']
                
                if 'authentication' in conn:
                    auth = conn['authentication']
                    auth_config = {}
                    
                    if auth.get('clientMode'):
                        auth_config['client-mode'] = auth['clientMode']
                    
                    if auth.get('eapId'):
                        auth_config['eap-id'] = auth['eapId']
                    
                    if auth.get('localId'):
                        auth_config['local-id'] = auth['localId']

                    if auth.get('preSharedSecret'):
                        auth_config['pre-shared-secret'] = auth['preSharedSecret']

                    if auth.get('serverMode'):
                        auth_config['server-mode'] = auth['serverMode']

                    if auth.get('localUsers'):
                        auth_config['local-users'] = {}
                        for user in auth['localUsers']:
                            user_config = {}
                            if not user.get('enabled', True):
                                user_config['disable'] = {}
                            if user.get('password'):
                                user_config['password'] = user['password']
                            auth_config['local-users'][user['username']] = user_config

                    x509_config = {}
                    if 'x509' in auth:
                        x509 = auth['x509']
                        if x509.get('caCertificate'):
                            ca_cert = x509['caCertificate']
                            x509_config['ca-certificate'] = ca_cert[0] if isinstance(ca_cert, list) and len(ca_cert) == 1 else ca_cert
                        if x509.get('certificate'):
                            x509_config['certificate'] = x509['certificate']
                        if x509.get('passphrase'):
                            x509_config['passphrase'] = x509['passphrase']
                    if x509_config:
                        auth_config['x509'] = x509_config
                
                if auth_config:
                    conn_config['authentication'] = auth_config
                
                ra_config['connection'][conn['name']] = conn_config
        
        if 'dhcp' in remote_access:
            dhcp = remote_access['dhcp']
            dhcp_config = {}
            if dhcp.get('interface'):
                dhcp_config['interface'] = dhcp['interface']
            if dhcp.get('server'):
                dhcp_config['server'] = dhcp['server']
            if dhcp_config:
                ra_config['dhcp'] = dhcp_config
        
        if remote_access.get('pools'):
            ra_config['pool'] = {}
            for pool in remote_access['pools']:
                pool_config = {}
                if pool.get('exclude'):
                    pool_config['exclude'] = pool['exclude']
                if pool.get('nameServer'):
                    name_server = pool['nameServer']
                    pool_config['name-server'] = name_server[0] if isinstance(name_server, list) and len(name_server) == 1 else name_server
                if pool.get('prefix'):
                    pool_config['prefix'] = pool['prefix']
                if 'range' in pool:
                    range_config = {}
                    if pool['range'].get('start'):
                        range_config['start'] = pool['range']['start']
                    if pool['range'].get('stop'):
                        range_config['stop'] = pool['range']['stop']
                    if range_config:
                        pool_config['range'] = range_config
                ra_config['pool'][pool['name']] = pool_config
        
        if 'radius' in remote_access:
            radius = remote_access['radius']
            radius_config = {}
            
            if radius.get('nasIdentifier'):
                radius_config['nas-identifier'] = radius['nasIdentifier']
            
            if radius.get('timeout'):
                radius_config['timeout'] = str(radius['timeout'])
            
            if radius.get('servers'):
                radius_config['server'] = {}
                for server in radius['servers']:
                    server_config = {}
                    if not server.get('enabled', True):
                        server_config['disable'] = {}
                    if server.get('disableAccounting'):
                        server_config['disable-accounting'] = {}
                    if server.get('port'):
                        server_config['port'] = str(server['port'])
                    if server.get('key'):
                        server_config['key'] = server['key']
                    radius_config['server'][server['address']] = server_config
            
            if radius_config:
                ra_config['radius'] = radius_config
        
        if ra_config:
            config['remote-access'] = ra_config
    
    if 'general' in data and 'siteToSite' in data['general']:
        site_to_site = data['general']['siteToSite']
        
        if site_to_site.get('peers'):
            config['site-to-site'] = {'peer': {}}
            
            for peer in site_to_site['peers']:
                peer_config = {}
                
                if peer.get('description'):
                    peer_config['description'] = peer['description']
                
                if not peer.get('enabled', True):
                    peer_config['disable'] = {}
                
                if peer.get('connectionType'):
                    peer_config['connection-type'] = peer['connectionType']
                
                if peer.get('defaultEspGroup'):
                    peer_config['default-esp-group'] = normalize_group_name(peer['defaultEspGroup'])
                
                if peer.get('dhcpInterface'):
                    peer_config['dhcp-interface'] = peer['dhcpInterface']
                
                if peer.get('forceUdpEncapsulation'):
                    peer_config['force-udp-encapsulation'] = {}
                
                if peer.get('ikeGroup'):
                    peer_config['ike-group'] = normalize_group_name(peer['ikeGroup'])
                
                ikev2_reauth = _normalize_ikev2_reauth_value(peer.get('ikev2Reauth'))
                if ikev2_reauth is not None:
                    peer_config['ikev2-reauth'] = ikev2_reauth
                
                if peer.get('localAddress'):
                    peer_config['local-address'] = peer['localAddress']
                
                if peer.get('remoteAddress'):
                    remote_addr = peer['remoteAddress']
                    # Always keep remote-address as a list for consistent comparison
                    peer_config['remote-address'] = remote_addr if isinstance(remote_addr, list) else [remote_addr]
                
                if peer.get('replayWindow') and parseInt(peer['replayWindow']) and parseInt(peer['replayWindow']) > 0:
                    peer_config['replay-window'] = str(peer['replayWindow'])
                
                if peer.get('virtualAddress'):
                    virtual_addr = peer['virtualAddress']
                    peer_config['virtual-address'] = virtual_addr if isinstance(virtual_addr, list) else [virtual_addr]
                
                vti_config = {}
                if peer.get('vti'):
                    vti_config['bind'] = peer['vti']
                if peer.get('vtiAddress'):
                    vti_config['address'] = peer['vtiAddress']
                if peer.get('espGroup'):
                    vti_config['esp-group'] = normalize_group_name(peer['espGroup'])
                for side, field in (('local', 'trafficSelectorLocalPrefix'), ('remote', 'trafficSelectorRemotePrefix')):
                    prefixes = _as_list(peer.get(field))
                    if prefixes:
                        vti_config.setdefault('traffic-selector', {})[side] = {'prefix': prefixes}
                if vti_config:
                    peer_config['vti'] = vti_config

                if 'authentication' in peer:
                    auth = peer['authentication']
                    auth_config = {}
                    if auth.get('localId'):
                        auth_config['local-id'] = auth['localId']
                    
                    if auth.get('mode'):
                        auth_config['mode'] = auth['mode']
                    
                    if auth.get('remoteId'):
                        auth_config['remote-id'] = auth['remoteId']
                    
                    if auth.get('useX509Id'):
                        auth_config['use-x509-id'] = {}
                    
                    if 'rsa' in auth:
                        rsa = auth['rsa']
                        rsa_config = {}
                        if rsa.get('localKey'):
                            rsa_config['local-key'] = rsa['localKey']
                        if rsa.get('remoteKey'):
                            rsa_config['remote-key'] = rsa['remoteKey']
                        if rsa_config:
                            auth_config['rsa'] = rsa_config
                    
                    if 'x509' in auth:
                        x509 = auth['x509']
                        x509_config = {}
                        if x509.get('caCertificate'):
                            ca_cert = x509['caCertificate']
                            x509_config['ca-certificate'] = ca_cert[0] if isinstance(ca_cert, list) and len(ca_cert) == 1 else ca_cert
                        if x509.get('certificate'):
                            x509_config['certificate'] = x509['certificate']
                        if x509_config:
                            auth_config['x509'] = x509_config
                    
                    if auth_config:
                        peer_config['authentication'] = auth_config
                
                if peer.get('tunnels'):
                    peer_config['tunnel'] = {}
                    for i, tunnel in enumerate(peer['tunnels'], 1):
                        if not tunnel.get('enabled', True):
                            continue
                        
                        tunnel_config = {}
                        
                        if tunnel.get('espGroup'):
                            tunnel_config['esp-group'] = normalize_group_name(tunnel['espGroup'])
                        
                        if 'local' in tunnel:
                            local = tunnel['local']
                            local_config = {}
                            if local.get('prefix'):
                                prefix = local['prefix']
                                local_config['prefix'] = prefix[0] if isinstance(prefix, list) and len(prefix) == 1 else prefix
                            if local.get('port'):
                                local_config['port'] = str(local['port'])
                            if local_config:
                                tunnel_config['local'] = local_config
                        
                        if 'remote' in tunnel:
                            remote = tunnel['remote']
                            remote_config = {}
                            if remote.get('prefix'):
                                prefix = remote['prefix']
                                remote_config['prefix'] = prefix[0] if isinstance(prefix, list) and len(prefix) == 1 else prefix
                            if remote.get('port'):
                                remote_config['port'] = str(remote['port'])
                            if remote_config:
                                tunnel_config['remote'] = remote_config
                        
                        priority = tunnel.get('priority')
                        if priority in (None, '') and 'local' in tunnel:
                            priority = tunnel['local'].get('priority')
                        if priority:
                            tunnel_config['priority'] = str(priority)
                        protocol = tunnel.get('protocol')
                        if protocol is None:
                            protocol = tunnel.get('local', {}).get('protocol')
                        if protocol:
                            tunnel_config['protocol'] = protocol
                        
                        tunnel_num = tunnel.get('id', str(i))
                        peer_config['tunnel'][tunnel_num] = tunnel_config
                
                config['site-to-site']['peer'][peer['name']] = peer_config
    
    return config

def _normalize_peer_vti_config(peer):
    
    value = peer.get('vti')
    vti = {'bind': value} if isinstance(value, str) else (value or {})
    esp_group = peer.pop('esp-group', None)
    if esp_group:
        vti.setdefault('esp-group', esp_group)
    selectors = peer.pop('traffic-selector', {})
    if selectors:
        nested = vti.setdefault('traffic-selector', {})
        for side, selector in selectors.items():
            nested.setdefault(side, selector)
    for selector in vti.get('traffic-selector', {}).values():
        if 'prefix' in selector:
            selector['prefix'] = _as_list(selector['prefix'])
    if vti:
        peer['vti'] = vti


def parse_current_ipsec_interface_config(config: dict):
    if 'vpn' not in config:
        return {}
    if 'ipsec' not in config.get('vpn', {}):
        return {}
    
    ipsec_config = config['vpn']['ipsec']
    _parse_with_vti_addresses(ipsec_config, config)

    psk_config = ipsec_config.get('authentication', {}).get('psk')
    if isinstance(psk_config, dict):
        for psk_name, psk_data in psk_config.items():
            if not isinstance(psk_data, dict):
                continue
            if 'id' in psk_data:
                psk_data['id'] = _as_list(psk_data['id'])
            if 'dhcp-interface' in psk_data:
                psk_data['dhcp-interface'] = _as_list(psk_data['dhcp-interface'])
    
    if 'site-to-site' in ipsec_config and 'peer' in ipsec_config['site-to-site']:
        for peer_name, peer_config in ipsec_config['site-to-site']['peer'].items():
            _normalize_peer_vti_config(peer_config)
            if 'remote-address' in peer_config:
                remote_addr = peer_config['remote-address']
                if isinstance(remote_addr, dict):
                    peer_config['remote-address'] = list(remote_addr.keys())
                elif not isinstance(remote_addr, list):
                    peer_config['remote-address'] = [remote_addr]

            if 'virtual-address' in peer_config:
                virtual_addr = peer_config['virtual-address']
                if isinstance(virtual_addr, dict):
                    peer_config['virtual-address'] = list(virtual_addr.keys())
                elif not isinstance(virtual_addr, list):
                    peer_config['virtual-address'] = [virtual_addr]
    
    return ipsec_config

def parse_ipsec_monitor_info(data: dict):
    pass
