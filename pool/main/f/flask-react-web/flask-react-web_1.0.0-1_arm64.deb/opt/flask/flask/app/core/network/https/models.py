
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean
from pydantic import BaseModel
from typing import List, Optional


class HTTPSAllowClientDTO(BaseModel):
    address: Optional[str] = None


class HTTPSApiGraphqlAuthDTO(BaseModel):
    expiration: Optional[int] = None
    secret_length: Optional[int] = None
    type: Optional[str] = None


class HTTPSApiGraphqlDTO(BaseModel):
    authentication: Optional[HTTPSApiGraphqlAuthDTO] = None


class HTTPSApiKeyDTO(BaseModel):
    id: Optional[str] = None
    key: Optional[str] = None


class HTTPSApiDTO(BaseModel):
    graphql: Optional[HTTPSApiGraphqlDTO] = None
    keys: Optional[List[HTTPSApiKeyDTO]] = None
    rest: Optional[bool] = None
    rest_debug: Optional[bool] = None
    rest_strict: Optional[bool] = None


class HTTPSDTO(BaseModel):
    allow_clients: Optional[List[HTTPSAllowClientDTO]] = None
    enable_http_redirect: Optional[bool] = None
    listen_addresses: Optional[List[str]] = None
    port: Optional[int] = None
    request_body_size_limit: Optional[int] = None
    tls_versions: Optional[List[str]] = None
    api: Optional[HTTPSApiDTO] = None
    ca_certificate: Optional[str] = None
    certificate: Optional[str] = None
    dh_params: Optional[str] = None


class HTTPSConfig(db.Model):
    __tablename__ = "vyos_https_config"

    id = Column(Integer, primary_key=True)
    enable_http_redirect = Column(Boolean, nullable=True)
    port = Column(Integer, nullable=True)
    request_body_size_limit = Column(Integer, nullable=True)

    api_rest = Column(Boolean, nullable=True)
    api_rest_debug = Column(Boolean, nullable=True)
    api_rest_strict = Column(Boolean, nullable=True)

    api_graphql_auth_expiration = Column(Integer, nullable=True)
    api_graphql_auth_secret_length = Column(Integer, nullable=True)
    api_graphql_auth_type = Column(String(32), nullable=True)

    ca_certificate = Column(String(255), nullable=True)
    certificate = Column(String(255), nullable=True)
    dh_params = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        payload = data or {}

        def _to_int(v):
            if v is None:
                return None
            try:
                return int(v)
            except Exception:
                return None

        def _to_str(v):
            if v is None:
                return None
            s = str(v)
            return s

        def _as_bool_marker(obj, key: str):
            if not isinstance(obj, dict):
                return None
            if key in obj:
                return True
            return None

        enable_http_redirect = None
        if isinstance(payload, dict):
            if 'enable_http_redirect' in payload:
                enable_http_redirect = bool(payload.get('enable_http_redirect'))
            else:
                enable_http_redirect = _as_bool_marker(payload, 'enable-http-redirect')

        port = _to_int(payload.get('port'))
        request_body_size_limit = _to_int(payload.get('request_body_size_limit'))
        if request_body_size_limit is None:
            request_body_size_limit = _to_int(payload.get('request-body-size-limit'))

        ca_certificate = payload.get('ca_certificate')
        certificate = payload.get('certificate')
        dh_params = payload.get('dh_params')

        certs = payload.get('certificates')
        if isinstance(certs, dict):
            if ca_certificate is None and certs.get('ca-certificate') is not None:
                ca_certificate = _to_str(certs.get('ca-certificate'))
            if certificate is None and certs.get('certificate') is not None:
                certificate = _to_str(certs.get('certificate'))
            if dh_params is None and certs.get('dh-params') is not None:
                dh_params = _to_str(certs.get('dh-params'))

        if dh_params is None and payload.get('dh-params') is not None:
            dh_params = _to_str(payload.get('dh-params'))

        tls_versions = payload.get('tls_versions')
        if tls_versions is None:
            tls_versions = payload.get('tls-version')
        tls_versions_list = []
        if isinstance(tls_versions, list):
            tls_versions_list = [str(v).strip() for v in tls_versions if v is not None and str(v).strip() != '']
        elif tls_versions is not None:
            v = str(tls_versions).strip()
            if v:
                tls_versions_list = [v]

        allow_clients = payload.get('allow_clients')
        if allow_clients is None:
            allow_clients = payload.get('allow-client')
        allow_clients_list = []
        if isinstance(allow_clients, list):
            for item in allow_clients:
                if isinstance(item, dict):
                    addr = item.get('address')
                    if addr is None:
                        addr = item.get('addr')
                    if addr is None:
                        continue
                    v = str(addr).strip()
                    if v:
                        allow_clients_list.append(v)
                else:
                    v = str(item).strip()
                    if v:
                        allow_clients_list.append(v)
        elif isinstance(allow_clients, dict):
            if 'address' in allow_clients:
                addrs = allow_clients.get('address')
                if isinstance(addrs, list):
                    for addr in addrs:
                        if addr is None:
                            continue
                        v = str(addr).strip()
                        if v:
                            allow_clients_list.append(v)
                elif isinstance(addrs, dict):
                    allow_clients_list = [
                        str(k).strip()
                        for k in addrs.keys()
                        if k is not None and str(k).strip() != ''
                    ]
                elif addrs is not None:
                    v = str(addrs).strip()
                    if v:
                        allow_clients_list.append(v)
            else:
                allow_clients_list = [
                    str(k).strip()
                    for k in allow_clients.keys()
                    if k is not None and str(k).strip() != ''
                ]

        listen_addresses = payload.get('listen_addresses')
        if listen_addresses is None:
            listen_addresses = payload.get('listen-address')
        listen_addresses_list = []
        if isinstance(listen_addresses, list):
            listen_addresses_list = [str(a).strip() for a in listen_addresses if a is not None and str(a).strip() != '']
        elif isinstance(listen_addresses, dict):
            listen_addresses_list = [str(k).strip() for k in listen_addresses.keys() if k is not None and str(k).strip() != '']

        api = payload.get('api')
        api_cfg = api if isinstance(api, dict) else {}

        api_rest = None
        api_rest_debug = None
        api_rest_strict = None
        rest_val = api_cfg.get('rest')
        if isinstance(rest_val, dict):
            api_rest = True
            api_rest_debug = 'debug' in rest_val
            api_rest_strict = 'strict' in rest_val
        elif rest_val is not None:
            api_rest = bool(rest_val)
            api_rest_debug = bool(api_cfg.get('rest_debug')) if 'rest_debug' in api_cfg else None
            api_rest_strict = bool(api_cfg.get('rest_strict')) if 'rest_strict' in api_cfg else None
        else:
            if 'rest_debug' in api_cfg:
                api_rest_debug = bool(api_cfg.get('rest_debug'))
            if 'rest_strict' in api_cfg:
                api_rest_strict = bool(api_cfg.get('rest_strict'))
            if 'rest' in api_cfg:
                api_rest = bool(api_cfg.get('rest'))

        graphql = api_cfg.get('graphql')
        graphql_cfg = graphql if isinstance(graphql, dict) else {}
        auth = graphql_cfg.get('authentication')
        auth_cfg = auth if isinstance(auth, dict) else {}

        api_graphql_auth_expiration = _to_int(auth_cfg.get('expiration'))
        api_graphql_auth_secret_length = _to_int(auth_cfg.get('secret_length'))
        if api_graphql_auth_secret_length is None:
            api_graphql_auth_secret_length = _to_int(auth_cfg.get('secret-length'))
        api_graphql_auth_type = _to_str(auth_cfg.get('type'))

        keys = api_cfg.get('keys')
        keys_list = []
        if isinstance(keys, list):
            for k in keys:
                if not isinstance(k, dict):
                    continue
                key_id = k.get('id')
                if key_id is None or str(key_id).strip() == '':
                    continue
                keys_list.append({'id': str(key_id), 'key': k.get('key')})
        elif isinstance(keys, dict):
            ids = keys.get('id')
            if isinstance(ids, dict):
                for key_id, obj in ids.items():
                    if key_id is None or str(key_id).strip() == '':
                        continue
                    key_val = None
                    if isinstance(obj, dict):
                        key_val = obj.get('key')
                    keys_list.append({'id': str(key_id), 'key': key_val})

        cls.truncate()
        cfg = cls()

        cfg.enable_http_redirect = enable_http_redirect
        cfg.port = port
        cfg.request_body_size_limit = request_body_size_limit

        cfg.api_rest = api_rest
        cfg.api_rest_debug = api_rest_debug
        cfg.api_rest_strict = api_rest_strict

        cfg.api_graphql_auth_expiration = api_graphql_auth_expiration
        cfg.api_graphql_auth_secret_length = api_graphql_auth_secret_length
        cfg.api_graphql_auth_type = api_graphql_auth_type

        cfg.ca_certificate = _to_str(ca_certificate)
        cfg.certificate = _to_str(certificate)
        cfg.dh_params = _to_str(dh_params)

        db.session.add(cfg)
        db.session.commit()

        HTTPSAllowClient.refresh(allow_clients_list)
        HTTPSListenAddress.refresh(listen_addresses_list)
        HTTPSTlsVersion.refresh(tls_versions_list)
        HTTPSApiKey.refresh(keys_list)

    def serialize(self):
        return {
            'enable_http_redirect': self.enable_http_redirect,
            'port': self.port,
            'request_body_size_limit': self.request_body_size_limit,
            'api': {
                'rest': self.api_rest,
                'rest_debug': self.api_rest_debug,
                'rest_strict': self.api_rest_strict,
                'graphql': {
                    'authentication': {
                        'expiration': self.api_graphql_auth_expiration,
                        'secret_length': self.api_graphql_auth_secret_length,
                        'type': self.api_graphql_auth_type,
                    }
                }
            },
            'ca_certificate': self.ca_certificate,
            'certificate': self.certificate,
            'dh_params': self.dh_params,
        }


class HTTPSAllowClient(db.Model):
    __tablename__ = "vyos_https_allow_client"

    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=False)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, addresses: list[str]):
        cls.truncate()
        for addr in addresses or []:
            if addr is None:
                continue
            v = str(addr).strip()
            if not v:
                continue
            if v.lower() == 'address':
                continue
            db.session.add(cls(address=v))
        db.session.commit()

    def serialize(self):
        return {'address': self.address}


class HTTPSListenAddress(db.Model):
    __tablename__ = "vyos_https_listen_address"

    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=False)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, addresses: list[str]):
        cls.truncate()
        for addr in addresses or []:
            if addr is None:
                continue
            v = str(addr).strip()
            if not v:
                continue
            db.session.add(cls(address=v))
        db.session.commit()

    def serialize(self):
        return {'address': self.address}


class HTTPSTlsVersion(db.Model):
    __tablename__ = "vyos_https_tls_version"

    id = Column(Integer, primary_key=True)
    version = Column(String(16), nullable=False)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, versions: list[str]):
        cls.truncate()
        for ver in versions or []:
            if ver is None:
                continue
            v = str(ver).strip()
            if not v:
                continue
            db.session.add(cls(version=v))
        db.session.commit()

    def serialize(self):
        return {'version': self.version}


class HTTPSApiKey(db.Model):
    __tablename__ = "vyos_https_api_key"

    id = Column(Integer, primary_key=True)
    key_id = Column(String(255), nullable=False)
    key_value = Column(String(2048), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, keys: list[dict]):
        cls.truncate()
        for k in keys or []:
            key_id = (k or {}).get('id')
            if not key_id:
                continue
            db.session.add(cls(key_id=str(key_id), key_value=(k or {}).get('key')))
        db.session.commit()

    def serialize(self):
        return {'id': self.key_id, 'key': self.key_value}
