from pydantic import BaseModel
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
import json

from pydantic import BaseModel, RootModel, field_validator, Field, ConfigDict
from typing import Optional, List, DefaultDict, Dict, Any, Union


def _normalize_optional_scalar(value):
    if value is None:
        return None

    if isinstance(value, str):
        value = value.strip()
        return value if value else None

    return value


def _normalize_optional_string_list(value):
    if value is None:
        return None

    if isinstance(value, str):
        value = value.strip()
        return value if value else None

    if isinstance(value, list):
        normalized = []
        for item in value:
            if isinstance(item, list):
                nested = _normalize_optional_string_list(item)
                if isinstance(nested, list):
                    normalized.extend(nested)
                elif nested is not None:
                    normalized.append(nested)
                continue

            item = _normalize_optional_scalar(item)
            if item is not None:
                normalized.append(item)

        if not normalized:
            return None

        return normalized

    return value

class SNMPConfig(db.Model):
    __tablename__ = 'vyos_config_snmp'

    id = Column(Integer, primary_key=True)
    
    contact = Column(String(255))
    description = Column(String(255))
    location = Column(String(255))
    oid_enable = Column(String(100))
    protocol = Column(String(50))
    smux_peer = Column(String(255))
    trap_source = Column(String(100))
    v3_engineid = Column(String(100))
    
    communities = relationship("SNMPCommunity", back_populates="snmp_config", cascade="all, delete-orphan")
    listen_addresses = relationship("SNMPListenAddress", back_populates="snmp_config", cascade="all, delete-orphan")
    mib_interfaces = relationship("SNMPMibInterface", back_populates="snmp_config", cascade="all, delete-orphan")
    trap_targets = relationship("SNMPTrapTarget", back_populates="snmp_config", cascade="all, delete-orphan")
    v3_groups = relationship("SNMPv3Group", back_populates="snmp_config", cascade="all, delete-orphan")
    v3_users = relationship("SNMPv3User", back_populates="snmp_config", cascade="all, delete-orphan")
    v3_views = relationship("SNMPv3View", back_populates="snmp_config", cascade="all, delete-orphan")
    v3_trap_targets = relationship("SNMPv3TrapTarget", back_populates="snmp_config", cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_snmp_community_client',
            'vyos_config_snmp_community_network',
            'vyos_config_snmp_community',
            'vyos_config_snmp_listen_address',
            'vyos_config_snmp_mib_interface',
            'vyos_config_snmp_trap_target',
            'vyos_config_snmp_v3_view_oid',
            'vyos_config_snmp_v3_view',
            'vyos_config_snmp_v3_user_group',
            'vyos_config_snmp_v3_user',
            'vyos_config_snmp_v3_group',
            'vyos_config_snmp_v3_trap_target',
            'vyos_config_snmp'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            snmp_config = cls()
            
            snmp_config.contact = config.get('contact')
            snmp_config.description = config.get('description')
            snmp_config.location = config.get('location')
            snmp_config.oid_enable = config.get('oid-enable')
            snmp_config.protocol = config.get('protocol')
            snmp_config.smux_peer = config.get('smux-peer')
            snmp_config.trap_source = config.get('trap-source')
            snmp_config.v3_engineid = config.get('v3', {}).get('engineid')
            
            db.session.add(snmp_config)
            db.session.flush()
            
            if 'community' in config:
                for comm_name, comm_data in config['community'].items():
                    community = SNMPCommunity(
                        snmp_config_id=snmp_config.id,
                        name=comm_name,
                        authorization=comm_data.get('authorization')
                    )
                    db.session.add(community)
                    db.session.flush()
                    
                    if 'client' in comm_data:
                        clients = comm_data['client'] if isinstance(comm_data['client'], list) else [comm_data['client']]
                        for client_ip in clients:
                            client = SNMPCommunityClient(
                                community_id=community.id,
                                client_ip=client_ip
                            )
                            db.session.add(client)
                    
                    if 'network' in comm_data:
                        networks = comm_data['network'] if isinstance(comm_data['network'], list) else [comm_data['network']]
                        for network in networks:
                            network_entry = SNMPCommunityNetwork(
                                community_id=community.id,
                                network=network
                            )
                            db.session.add(network_entry)
            
            if 'listen-address' in config:
                for address, addr_data in config['listen-address'].items():
                    listen_addr = SNMPListenAddress(
                        snmp_config_id=snmp_config.id,
                        address=address,
                        port=addr_data.get('port')
                    )
                    db.session.add(listen_addr)
            
            if 'mib' in config:
                mib_data = config['mib']
                if 'interface' in mib_data:
                    interfaces = mib_data['interface'] if isinstance(mib_data['interface'], list) else [mib_data['interface']]
                    for intf in interfaces:
                        mib_intf = SNMPMibInterface(
                            snmp_config_id=snmp_config.id,
                            interface=intf,
                            interface_max=mib_data.get('interface-max')
                        )
                        db.session.add(mib_intf)
            
            if 'trap-target' in config:
                for target_ip, target_data in config['trap-target'].items():
                    trap_target = SNMPTrapTarget(
                        snmp_config_id=snmp_config.id,
                        address=target_ip,
                        community=target_data.get('community'),
                        port=target_data.get('port')
                    )
                    db.session.add(trap_target)
            
            if 'v3' in config:
                v3_config = config['v3']
                
                if 'group' in v3_config:
                    for group_name, group_data in v3_config['group'].items():
                        v3_group = SNMPv3Group(
                            snmp_config_id=snmp_config.id,
                            name=group_name,
                            mode=group_data.get('mode'),
                            seclevel=group_data.get('seclevel'),
                            view=group_data.get('view')
                        )
                        db.session.add(v3_group)
                
                if 'user' in v3_config:
                    for user_name, user_data in v3_config['user'].items():
                        v3_user = SNMPv3User(
                            snmp_config_id=snmp_config.id,
                            username=user_name,
                            mode=user_data.get('mode'),
                            auth_type=user_data.get('auth', {}).get('type'),
                            auth_encrypted_password=user_data.get('auth', {}).get('encrypted-password'),
                            auth_plaintext_password=user_data.get('auth', {}).get('plaintext-password'),
                            privacy_type=user_data.get('privacy', {}).get('type'),
                            privacy_encrypted_password=user_data.get('privacy', {}).get('encrypted-password'),
                            privacy_plaintext_password=user_data.get('privacy', {}).get('plaintext-password')
                        )
                        db.session.add(v3_user)
                        db.session.flush()
                        
                        group_data = user_data.get('group')
                        if group_data:
                            groups = group_data if isinstance(group_data, list) else [group_data]
                            for group_name in groups:
                                user_group = SNMPv3UserGroup(
                                    user_id=v3_user.id,
                                    group_name=group_name
                                )
                                db.session.add(user_group)
                
                if 'view' in v3_config:
                    for view_name, view_data in v3_config['view'].items():
                        v3_view = SNMPv3View(
                            snmp_config_id=snmp_config.id,
                            name=view_name
                        )
                        db.session.add(v3_view)
                        db.session.flush()
                        
                        if 'oid' in view_data:
                            for oid_num, oid_data in view_data['oid'].items():
                                view_oid = SNMPv3ViewOid(
                                    view_id=v3_view.id,
                                    oid=oid_num,
                                    exclude=oid_data.get('exclude') if isinstance(oid_data, dict) else None,
                                    mask=oid_data.get('mask') if isinstance(oid_data, dict) else None
                                )
                                db.session.add(view_oid)
                
                if 'trap-target' in v3_config:
                    for target_ip, target_data in v3_config['trap-target'].items():
                        v3_trap = SNMPv3TrapTarget(
                            snmp_config_id=snmp_config.id,
                            address=target_ip,
                            port=target_data.get('port'),
                            protocol=target_data.get('protocol'),
                            type=target_data.get('type'),
                            user=target_data.get('user'),
                            auth_type=target_data.get('auth', {}).get('type'),
                            auth_encrypted_password=target_data.get('auth', {}).get('encrypted-password'),
                            auth_plaintext_password=target_data.get('auth', {}).get('plaintext-password'),
                            privacy_type=target_data.get('privacy', {}).get('type'),
                            privacy_encrypted_password=target_data.get('privacy', {}).get('encrypted-password'),
                            privacy_plaintext_password=target_data.get('privacy', {}).get('plaintext-password')
                        )
                        db.session.add(v3_trap)
            
            db.session.commit()
            print("SNMP configuration refreshed successfully")
            
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing SNMP configuration: {str(e)}")
            raise

    def serialize(self):
        """Serialize SNMP configuration to dictionary"""
        config = {}
        
        if self.contact:
            config['contact'] = self.contact
        if self.description:
            config['description'] = self.description
        if self.location:
            config['location'] = self.location
        if self.oid_enable:
            config['oid-enable'] = self.oid_enable
        if self.protocol:
            config['protocol'] = self.protocol
        if self.smux_peer:
            config['smux-peer'] = self.smux_peer
        if self.trap_source:
            config['trap-source'] = self.trap_source
        if self.v3_engineid:
            config['v3'] = {'engineid': self.v3_engineid}
        
        if self.communities:
            config['community'] = {}
            for comm in self.communities:
                config['community'][comm.name] = comm.serialize()
        
        if self.listen_addresses:
            config['listen-address'] = {}
            for addr in self.listen_addresses:
                config['listen-address'][addr.address] = {'port': addr.port} if addr.port else {}
        
        if self.mib_interfaces:
            config['mib'] = {
                'interface': [m.interface for m in self.mib_interfaces]
            }
            if self.mib_interfaces[0].interface_max:
                config['mib']['interface-max'] = self.mib_interfaces[0].interface_max
        
        if self.trap_targets:
            config['trap-target'] = {}
            for target in self.trap_targets:
                config['trap-target'][target.address] = target.serialize()
        
        if self.v3_groups or self.v3_users or self.v3_views or self.v3_trap_targets:
            if 'v3' not in config:
                config['v3'] = {}
            
            if self.v3_groups:
                config['v3']['group'] = {}
                for group in self.v3_groups:
                    config['v3']['group'][group.name] = group.serialize()
            
            if self.v3_users:
                config['v3']['user'] = {}
                for user in self.v3_users:
                    config['v3']['user'][user.username] = user.serialize()
            
            if self.v3_views:
                config['v3']['view'] = {}
                for view in self.v3_views:
                    config['v3']['view'][view.name] = view.serialize()
            
            if self.v3_trap_targets:
                config['v3']['trap-target'] = {}
                for trap in self.v3_trap_targets:
                    config['v3']['trap-target'][trap.address] = trap.serialize()
        
        return config


class SNMPCommunity(db.Model):
    __tablename__ = 'vyos_config_snmp_community'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    authorization = Column(String(10))  # ro, rw
    
    snmp_config = relationship("SNMPConfig", back_populates="communities")
    clients = relationship("SNMPCommunityClient", back_populates="community", cascade="all, delete-orphan")
    networks = relationship("SNMPCommunityNetwork", back_populates="community", cascade="all, delete-orphan")
    
    def serialize(self):
        data = {}
        if self.authorization:
            data['authorization'] = self.authorization
        if self.networks:
            data['network'] = [n.network for n in self.networks]
        if self.clients:
            data['client'] = [c.client_ip for c in self.clients]
        return data


class SNMPCommunityClient(db.Model):
    __tablename__ = 'vyos_config_snmp_community_client'
    
    id = Column(Integer, primary_key=True)
    community_id = Column(Integer, ForeignKey('vyos_config_snmp_community.id'), nullable=False)
    client_ip = Column(String(100), nullable=False)
    
    community = relationship("SNMPCommunity", back_populates="clients")


class SNMPCommunityNetwork(db.Model):
    __tablename__ = 'vyos_config_snmp_community_network'
    
    id = Column(Integer, primary_key=True)
    community_id = Column(Integer, ForeignKey('vyos_config_snmp_community.id'), nullable=False)
    network = Column(String(100), nullable=False)
    
    community = relationship("SNMPCommunity", back_populates="networks")


class SNMPListenAddress(db.Model):
    __tablename__ = 'vyos_config_snmp_listen_address'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    address = Column(String(100), nullable=False)
    port = Column(String(10))
    
    snmp_config = relationship("SNMPConfig", back_populates="listen_addresses")


class SNMPMibInterface(db.Model):
    __tablename__ = 'vyos_config_snmp_mib_interface'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    interface = Column(String(50), nullable=False)
    interface_max = Column(String(10))
    
    snmp_config = relationship("SNMPConfig", back_populates="mib_interfaces")


class SNMPTrapTarget(db.Model):
    __tablename__ = 'vyos_config_snmp_trap_target'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    address = Column(String(100), nullable=False)
    community = Column(String(100))
    port = Column(String(10))
    
    snmp_config = relationship("SNMPConfig", back_populates="trap_targets")
    
    def serialize(self):
        data = {}
        if self.community:
            data['community'] = self.community
        if self.port:
            data['port'] = self.port
        return data


class SNMPv3Group(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_group'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    mode = Column(String(10))  # ro, rw
    seclevel = Column(String(20))  # noauth, auth, priv
    view = Column(String(100))
    
    snmp_config = relationship("SNMPConfig", back_populates="v3_groups")
    
    def serialize(self):
        data = {}
        if self.mode:
            data['mode'] = self.mode
        if self.seclevel:
            data['seclevel'] = self.seclevel
        if self.view:
            data['view'] = self.view
        return data


class SNMPv3UserGroup(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_user_group'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('vyos_config_snmp_v3_user.id'), nullable=False)
    group_name = Column(String(100), nullable=False)
    
    user = relationship("SNMPv3User", back_populates="user_groups")


class SNMPv3User(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_user'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    username = Column(String(100), nullable=False)
    mode = Column(String(10))  # ro, rw
    auth_type = Column(String(20))  # md5, sha
    auth_encrypted_password = Column(Text)
    auth_plaintext_password = Column(Text)
    privacy_type = Column(String(20))  # des, aes
    privacy_encrypted_password = Column(Text)
    privacy_plaintext_password = Column(Text)
    
    snmp_config = relationship("SNMPConfig", back_populates="v3_users")
    user_groups = relationship("SNMPv3UserGroup", back_populates="user", cascade="all, delete-orphan")
    
    def serialize(self):
        data = {}
        if self.user_groups:
            data['group'] = [ug.group_name for ug in self.user_groups]
        if self.mode:
            data['mode'] = self.mode
        
        if self.auth_type or self.auth_encrypted_password or self.auth_plaintext_password:
            data['auth'] = {}
            if self.auth_type:
                data['auth']['type'] = self.auth_type
            if self.auth_encrypted_password:
                data['auth']['encrypted-password'] = self.auth_encrypted_password
            if self.auth_plaintext_password:
                data['auth']['plaintext-password'] = self.auth_plaintext_password
        
        if self.privacy_type or self.privacy_encrypted_password or self.privacy_plaintext_password:
            data['privacy'] = {}
            if self.privacy_type:
                data['privacy']['type'] = self.privacy_type
            if self.privacy_encrypted_password:
                data['privacy']['encrypted-password'] = self.privacy_encrypted_password
            if self.privacy_plaintext_password:
                data['privacy']['plaintext-password'] = self.privacy_plaintext_password
        
        return data


class SNMPv3View(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_view'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    
    snmp_config = relationship("SNMPConfig", back_populates="v3_views")
    oids = relationship("SNMPv3ViewOid", back_populates="view", cascade="all, delete-orphan")
    
    def serialize(self):
        data = {}
        if self.oids:
            data['oid'] = {}
            for oid in self.oids:
                oid_data = {}
                if oid.exclude:
                    oid_data['exclude'] = oid.exclude
                if oid.mask:
                    oid_data['mask'] = oid.mask
                data['oid'][oid.oid] = oid_data if oid_data else {}
        return data


class SNMPv3ViewOid(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_view_oid'
    
    id = Column(Integer, primary_key=True)
    view_id = Column(Integer, ForeignKey('vyos_config_snmp_v3_view.id'), nullable=False)
    oid = Column(String(100), nullable=False)
    exclude = Column(String(100))
    mask = Column(String(100))
    
    view = relationship("SNMPv3View", back_populates="oids")


class SNMPv3TrapTarget(db.Model):
    __tablename__ = 'vyos_config_snmp_v3_trap_target'
    
    id = Column(Integer, primary_key=True)
    snmp_config_id = Column(Integer, ForeignKey('vyos_config_snmp.id'), nullable=False)
    address = Column(String(100), nullable=False)
    port = Column(String(10))
    protocol = Column(String(20))  # tcp, udp
    type = Column(String(20))  # inform, trap
    user = Column(String(100))
    auth_type = Column(String(20))
    auth_encrypted_password = Column(Text)
    auth_plaintext_password = Column(Text)
    privacy_type = Column(String(20))
    privacy_encrypted_password = Column(Text)
    privacy_plaintext_password = Column(Text)
    
    snmp_config = relationship("SNMPConfig", back_populates="v3_trap_targets")
    
    def serialize(self):
        data = {}
        if self.port:
            data['port'] = self.port
        if self.protocol:
            data['protocol'] = self.protocol
        if self.type:
            data['type'] = self.type
        if self.user:
            data['user'] = self.user
        
        if self.auth_type or self.auth_encrypted_password or self.auth_plaintext_password:
            data['auth'] = {}
            if self.auth_type:
                data['auth']['type'] = self.auth_type
            if self.auth_encrypted_password:
                data['auth']['encrypted-password'] = self.auth_encrypted_password
            if self.auth_plaintext_password:
                data['auth']['plaintext-password'] = self.auth_plaintext_password
        
        if self.privacy_type or self.privacy_encrypted_password or self.privacy_plaintext_password:
            data['privacy'] = {}
            if self.privacy_type:
                data['privacy']['type'] = self.privacy_type
            if self.privacy_encrypted_password:
                data['privacy']['encrypted-password'] = self.privacy_encrypted_password
            if self.privacy_plaintext_password:
                data['privacy']['plaintext-password'] = self.privacy_plaintext_password
        
        return data


class CommunityDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    authorization: Optional[str] = None
    client: Optional[Union[str, List[str]]] = None
    network: Optional[Union[str, List[str]]] = None

    @field_validator('authorization', mode='before')
    @classmethod
    def normalize_authorization(cls, v):
        return _normalize_optional_scalar(v)

    @field_validator('client', 'network', mode='before')
    @classmethod
    def normalize_string_lists(cls, v):
        return _normalize_optional_string_list(v)


class ListenAddressDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    port: Optional[str] = None

    @field_validator('port', mode='before')
    @classmethod
    def normalize_port(cls, v):
        return _normalize_optional_scalar(v)


class MibDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    interface: Optional[Union[str, List[str]]] = None
    interface_max: Optional[str] = Field(None, alias='interface-max')

    @field_validator('interface', mode='before')
    @classmethod
    def normalize_interface(cls, v):
        return _normalize_optional_string_list(v)

    @field_validator('interface_max', mode='before')
    @classmethod
    def normalize_interface_max(cls, v):
        return _normalize_optional_scalar(v)


class TrapTargetDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    community: Optional[str] = None
    port: Optional[str] = None

    @field_validator('community', 'port', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3GroupDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    mode: Optional[str] = None
    seclevel: Optional[str] = None
    view: Optional[str] = None

    @field_validator('mode', 'seclevel', 'view', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3AuthDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    type: Optional[str] = None
    encrypted_password: Optional[str] = Field(None, alias='encrypted-password')
    plaintext_password: Optional[str] = Field(None, alias='plaintext-password')

    @field_validator('type', 'encrypted_password', 'plaintext_password', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3PrivacyDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    type: Optional[str] = None
    encrypted_password: Optional[str] = Field(None, alias='encrypted-password')
    plaintext_password: Optional[str] = Field(None, alias='plaintext-password')

    @field_validator('type', 'encrypted_password', 'plaintext_password', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3UserDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    group: Optional[Union[str, List[str]]] = None
    mode: Optional[str] = None
    auth: Optional[V3AuthDTO] = None
    privacy: Optional[V3PrivacyDTO] = None

    @field_validator('group', mode='before')
    @classmethod
    def normalize_group(cls, v):
        if v is None:
            return None

        if isinstance(v, str):
            v = v.strip()
            return v if v else None

        def _flatten(value):
            if isinstance(value, list):
                out = []
                for item in value:
                    out.extend(_flatten(item))
                return out
            return [value]

        flat = _flatten(v)
        flat = [str(item).strip() for item in flat if item is not None and str(item).strip()]
        if not flat:
            return None

        return flat[0] if len(flat) == 1 else flat


class V3ViewOidDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    exclude: Optional[str] = None
    mask: Optional[str] = None

    @field_validator('exclude', 'mask', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3ViewDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    oid: Optional[Dict[str, Union[Dict, V3ViewOidDTO]]] = None


class V3TrapTargetDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    protocol: Optional[str] = None
    type: Optional[str] = None
    user: Optional[str] = None
    port: Optional[str] = None
    auth: Optional[V3AuthDTO] = None
    privacy: Optional[V3PrivacyDTO] = None

    @field_validator('protocol', 'type', 'user', 'port', mode='before')
    @classmethod
    def normalize_fields(cls, v):
        return _normalize_optional_scalar(v)


class V3ConfigDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    engineid: Optional[str] = None
    group: Optional[Dict[str, V3GroupDTO]] = None
    user: Optional[Dict[str, V3UserDTO]] = None
    view: Optional[Dict[str, V3ViewDTO]] = None
    trap_target: Optional[Dict[str, V3TrapTargetDTO]] = Field(None, alias='trap-target')


class UpdateSNMPDTO(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    
    contact: Optional[str] = None
    description: Optional[str] = None
    location: Optional[str] = None
    oid_enable: Optional[Union[str, List[str]]] = Field(None, alias='oid-enable')
    protocol: Optional[str] = None
    smux_peer: Optional[Union[str, List[str]]] = Field(None, alias='smux-peer')
    trap_source: Optional[str] = Field(None, alias='trap-source')
    community: Optional[Dict[str, CommunityDTO]] = None
    listen_address: Optional[Dict[str, ListenAddressDTO]] = Field(None, alias='listen-address')
    mib: Optional[MibDTO] = None
    trap_target: Optional[Dict[str, TrapTargetDTO]] = Field(None, alias='trap-target')
    v3: Optional[V3ConfigDTO] = None

    @field_validator('contact', 'description', 'location', 'protocol', 'trap_source', mode='before')
    @classmethod
    def normalize_scalar_fields(cls, v):
        return _normalize_optional_scalar(v)

    @field_validator('oid_enable', 'smux_peer', mode='before')
    @classmethod
    def normalize_list_or_scalar_fields(cls, v):
        return _normalize_optional_string_list(v)


class MonitorSNMPDTO(BaseModel):

    target: str
