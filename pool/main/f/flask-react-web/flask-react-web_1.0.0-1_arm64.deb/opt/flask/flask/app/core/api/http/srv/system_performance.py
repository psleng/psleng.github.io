from app.core.api.http.http_request import Action
from app.core.operation.system_performance import load_system_memory_json, load_system_memory_linux
from logging import getLogger, INFO
from app.core.operation.system_performance import load_system_cpu_json
from app.core.api.http.cmd.command import SHOW_RAM_TOTAL_LINUX, SHOW_SYSTEMS_MEMORY, SHOW_RAM_USED_LINUX, SHOW_SYSTEMS_UPTIME
import os
import subprocess
from app.core.utils.check_os import is_linux
from app.core.models import Storage
from app.db.database import db

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_storage(provider):
    try:
        response = provider.graphql_service.send_request(
            function_name='ShowStorage',
            data=None,
            verify=False
        )
        payload = response.json()
        result = (
            payload
            .get('data', {})
            .get('ShowStorage', {})
            .get('data', {})
            .get('result')
        )

        if not isinstance(result, dict):
            return None

        return {
            "filesystem": result.get("filesystem", ""),
            "size": int(result.get("size") or 0),
            "used": int(result.get("used") or 0),
            "avail": int(result.get("avail") or 0),
            "use_percentage": str(result.get("use_percentage") or "")
        }
    except Exception as e:
        logger.warning(f"Error fetching storage usage: {str(e)}")
        return None

def get_cached_storage():
    cached_storage = Storage.latest()
    return cached_storage.serialize() if cached_storage else None

def refresh_cached_storage(provider):
    storage = fetch_storage(provider)
    if not isinstance(storage, dict):
        return None

    Storage.refresh(storage)
    db.session.expire_all()
    return get_cached_storage()

def fetch_ram(provider, params):
    if not is_linux():
        data = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_MEMORY, verify=False)
        memory = load_system_memory_json(data.json()['data'])
    else:
        try:
            # Get total memory
            total_mem_proc = subprocess.Popen(
                SHOW_RAM_TOTAL_LINUX.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            total_mem_output, total_mem_error = total_mem_proc.communicate()
            
            if total_mem_error:
                print(f"Error getting total memory: {total_mem_error.decode()}")
                return None
            
            # Get used memory
            used_mem_proc = subprocess.Popen(
                SHOW_RAM_USED_LINUX.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            used_mem_output, used_mem_error = used_mem_proc.communicate()
            
            if used_mem_error:
                print(f"Error getting used memory: {used_mem_error.decode()}")
                return None
                
            memory = load_system_memory_linux(total_mem_output, used_mem_output)
            
        except Exception as e:
            print(f"Error executing Linux memory commands: {str(e)}")
            return None

    if isinstance(memory, dict):
        memory["storage"] = refresh_cached_storage(provider) or get_cached_storage()

    return memory

def fetch_cpu(provider, params):
    
    res = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_UPTIME, verify=False)
    perf = load_system_cpu_json(res.json()['data'])
    return perf
