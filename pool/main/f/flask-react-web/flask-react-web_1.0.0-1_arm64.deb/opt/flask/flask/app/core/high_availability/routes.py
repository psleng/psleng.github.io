from app.core.high_availability import vyos_ha_bp
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from flask import jsonify, request
from app.core.api.http.cmd.compare import compare_configs
from app.core.high_availability.vrrp.parsers import parse_to_vyos_config, parse_to_vyos_config_verify
from app.core.high_availability.vrrp.models import UpdateVRRPDTO, VRRPConfig, VerifyVRRPDTO, MonitorVRRPDTO
from app.core.high_availability.wan_load_balancing.models import (
    UpdateWanLoadBalancingDTO,
    VerifyWanLoadBalancingDTO,
    WanLoadBalancingConfig,
)
from app.core.high_availability.wan_load_balancing.parsers import parse_to_vyos_config as parse_wan_load_balancing_config
from app.core.utils.decorator.route_decorator import Pipeline
from app.auth.utils import login_required

admin_ha = Pipeline.admin(vyos_ha_bp)


@vyos_ha_bp.route('/vrrp', methods=['GET'])
@login_required
def get_vrrp():
    print("Fetching VRRP configuration")
    try:
        vrrp_config = VRRPConfig.query.all()
        vrrp = [item.serialize() for item in vrrp_config]
        return jsonify(vrrp), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400

@admin_ha.route('/vrrp', methods=['PUT'])
def update_vrrp():
    try:
        print("Data received for update:", request.data)
        data = UpdateVRRPDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.VRRP)
        print("data model dump:", data.model_dump())
        new_config = parse_to_vyos_config(data.model_dump())
        diff_config = compare_configs(new_config, current_config)
        print("new_config:", new_config)
        vrrp = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.VRRP, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )

        return jsonify(vrrp), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400
    
@admin_ha.route('/vrrp/verify', methods=['POST'])
def verify_vrrp():
    try:
        data = VerifyVRRPDTO.model_validate_json(request.data)
        print("Data is",data)
        verify_config = parse_to_vyos_config_verify(data.model_dump())
        #print("Verify config is",verify_config)
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.VRRP, data=verify_config)
        return jsonify(verify), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400
    
@admin_ha.route('/vrrp/monitor', methods=['POST'])
def monitor_vrrp():
    try:
        data = MonitorVRRPDTO.model_validate_json(request.data)
        
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.VRRP, data=data)

        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_ha_bp.route('/wan-load-balancing', methods=['GET'])
@login_required
def get_wan_load_balancing():
    try:
        config = WanLoadBalancingConfig.query.order_by(WanLoadBalancingConfig.id.desc()).first()
        return jsonify([config.serialize()] if config else []), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_ha.route('/wan-load-balancing', methods=['PUT'])
def update_wan_load_balancing():
    try:
        data = UpdateWanLoadBalancingDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.WAN_LOAD_BALANCING)
        new_config = parse_wan_load_balancing_config(data.model_dump())
        diff_config = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.WAN_LOAD_BALANCING,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config,
            },
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_ha.route('/wan-load-balancing/verify', methods=['POST'])
def verify_wan_load_balancing():
    try:
        data = VerifyWanLoadBalancingDTO.model_validate_json(request.data)
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.WAN_LOAD_BALANCING, data=data.model_dump())
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_ha.route('/wan-load-balancing/monitor/summary', methods=['GET'])
def monitor_wan_load_balancing_summary():
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.WAN_LOAD_BALANCING_MONITOR,
            data={"target": "summary"},
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@admin_ha.route('/wan-load-balancing/monitor/connections', methods=['GET'])
def monitor_wan_load_balancing_connections():
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.WAN_LOAD_BALANCING_MONITOR,
            data={"target": "connections"},
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400
