import re
from typing import Dict, Any, List, Optional

def parse_tunnel_name(tunnel_name: str) -> Dict[str, Any]:
    """Parse tunnel name to extract interface type and number"""
    if not tunnel_name:
        return {}
    
    # Match patterns like tun0, gre1, sit2, etc.
    match = re.match(r'^(tun|gre|sit|ipip)(\d+)$', tunnel_name.lower())
    if match:
        return {
            'prefix': match.group(1),
            'number': int(match.group(2)),
            'full_name': tunnel_name
        }
    return {'full_name': tunnel_name}

def validate_tunnel_config(config: Dict[str, Any]) -> List[str]:
    """Validate tunnel configuration and return list of errors"""
    errors = []
    
    if not config.get('tunnel_name'):
        errors.append("Tunnel name is required")
    
    if not config.get('tunnel_type'):
        errors.append("Tunnel type is required")
    elif config['tunnel_type'] not in ['gre', 'ipip', 'sit', 'vti']:
        errors.append("Invalid tunnel type. Must be one of: gre, ipip, sit, vti")
    
    # Validate addresses
    source_addr = config.get('source_address')
    remote_addr = config.get('remote_address')
    
    if source_addr and not _is_valid_ip(source_addr):
        errors.append("Invalid source address format")
    
    if remote_addr and not _is_valid_ip(remote_addr):
        errors.append("Invalid remote address format")
    
    # Validate TTL
    ttl = config.get('ttl')
    if ttl is not None:
        try:
            ttl_val = int(ttl)
            if ttl_val < 0 or ttl_val > 255:
                errors.append("TTL must be between 0 and 255")
        except (ValueError, TypeError):
            errors.append("TTL must be a valid integer")
    
    # Validate MTU
    mtu = config.get('mtu')
    if mtu is not None:
        try:
            mtu_val = int(mtu)
            if mtu_val < 68 or mtu_val > 16000:
                errors.append("MTU must be between 68 and 16000")
        except (ValueError, TypeError):
            errors.append("MTU must be a valid integer")
    
    # Validate TOS
    tos = config.get('tos')
    if tos is not None:
        try:
            tos_val = int(tos)
            if tos_val < 0 or tos_val > 99:
                errors.append("TOS must be between 0 and 99")
        except (ValueError, TypeError):
            errors.append("TOS must be a valid integer")
    
    # Validate IP addresses
    ipv4_addrs = config.get('ipv4_addresses', [])
    ipv6_addrs = config.get('ipv6_addresses', [])
    
    for addr in ipv4_addrs:
        if not _is_valid_ipv4_cidr(addr):
            errors.append(f"Invalid IPv4 address format: {addr}")
    
    for addr in ipv6_addrs:
        if not _is_valid_ipv6_cidr(addr):
            errors.append(f"Invalid IPv6 address format: {addr}")
    
    return errors

def _is_valid_ip(ip_addr: str) -> bool:
    """Check if IP address is valid (IPv4 or IPv6)"""
    return _is_valid_ipv4(ip_addr) or _is_valid_ipv6(ip_addr)

def _is_valid_ipv4(ip_addr: str) -> bool:
    """Validate IPv4 address"""
    try:
        import ipaddress
        ipaddress.IPv4Address(ip_addr)
        return True
    except ipaddress.AddressValueError:
        return False

def _is_valid_ipv6(ip_addr: str) -> bool:
    """Validate IPv6 address"""
    try:
        import ipaddress
        ipaddress.IPv6Address(ip_addr)
        return True
    except ipaddress.AddressValueError:
        return False

def _is_valid_ipv4_cidr(cidr: str) -> bool:
    """Validate IPv4 CIDR notation"""
    try:
        import ipaddress
        ipaddress.IPv4Network(cidr, strict=False)
        return True
    except ipaddress.AddressValueError:
        return False

def _is_valid_ipv6_cidr(cidr: str) -> bool:
    """Validate IPv6 CIDR notation"""
    try:
        import ipaddress
        ipaddress.IPv6Network(cidr, strict=False)
        return True
    except ipaddress.AddressValueError:
        return False

def normalize_tunnel_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize tunnel configuration for processing"""
    normalized = config.copy()
    
    # Ensure tunnel type is lowercase
    if 'tunnel_type' in normalized:
        normalized['tunnel_type'] = normalized['tunnel_type'].lower()
    
    # Normalize boolean values
    for bool_field in ['disable', 'multicast', 'gre_checksum']:
        if bool_field in normalized:
            normalized[bool_field] = bool(normalized[bool_field])
    
    # Ensure lists for addresses
    for addr_field in ['ipv4_addresses', 'ipv6_addresses']:
        if addr_field not in normalized:
            normalized[addr_field] = []
        elif not isinstance(normalized[addr_field], list):
            normalized[addr_field] = [normalized[addr_field]] if normalized[addr_field] else []
    
    return normalized

def get_highest_tunnel_number(tunnel_type: str, existing_tunnels: List[Dict]) -> int:
    """Get the highest tunnel number for a given type"""
    highest = -1
    pattern = f"^{tunnel_type}(\\d+)$"
    
    for tunnel in existing_tunnels:
        tunnel_name = tunnel.get('tunnel_name', '')
        match = re.match(pattern, tunnel_name, re.IGNORECASE)
        if match:
            num = int(match.group(1))
            if num > highest:
                highest = num
    
    return highest

def suggest_tunnel_name(tunnel_type: str, existing_tunnels: List[Dict]) -> str:
    """Suggest next available tunnel name"""
    highest = get_highest_tunnel_number(tunnel_type, existing_tunnels)
    return f"{tunnel_type}{highest + 1}"

def parse_vyos_tunnel_config(vyos_config: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Parse VyOS tunnel configuration into our format"""
    tunnels = []
    
    # VyOS uses interfaces/tunnel/<name> structure
    interfaces = vyos_config.get('interfaces', {})
    tunnel_configs = interfaces.get('tunnel', {})
    
    for tunnel_name, tunnel_config in tunnel_configs.items():
        tunnel_data = {
            'tunnel_name': tunnel_name,
            'description': tunnel_config.get('description', ''),
            'disable': 'disable' in tunnel_config,
            'source_address': tunnel_config.get('source-address', ''),
            'remote_address': tunnel_config.get('remote', ''),
            'ttl': tunnel_config.get('ttl'),
            'tos': tunnel_config.get('tos'),
            'mtu': tunnel_config.get('mtu'),
            'multicast': 'enable-multicast' in tunnel_config,
            'disable_link_detect': 'disable-link-detect' in tunnel_config,
        }
        
        # Parse IP General Options
        ip_config = tunnel_config.get('ip', {})
        if ip_config:
            tunnel_data['ip_arp_cache_timeout'] = int(ip_config.get('arp-cache-timeout', 30)) if 'arp-cache-timeout' in ip_config else None
            tunnel_data['ip_adjust_mss'] = ip_config.get('adjust-mss', '')
            tunnel_data['ip_enable_arp_accept'] = 'enable-arp-accept' in ip_config
            tunnel_data['ip_enable_arp_announce'] = 'enable-arp-announce' in ip_config
            tunnel_data['ip_disable_arp_filter'] = 'disable-arp-filter' in ip_config
            tunnel_data['ip_enable_arp_ignore'] = 'enable-arp-ignore' in ip_config
            tunnel_data['ip_enable_directed_broadcast'] = 'enable-directed-broadcast' in ip_config
            tunnel_data['ip_disable_forwarding'] = 'disable-forwarding' in ip_config
            tunnel_data['ip_enable_proxy_arp'] = 'enable-proxy-arp' in ip_config
            tunnel_data['ip_enable_proxy_arp_pvlan'] = 'proxy-arp-pvlan' in ip_config
        
        # Determine tunnel type from encapsulation
        encapsulation = tunnel_config.get('encapsulation', '')
        if encapsulation in ['gre', 'ipip', 'sit']:
            tunnel_data['tunnel_type'] = encapsulation
        else:
            # Try to infer from tunnel name
            parsed_name = parse_tunnel_name(tunnel_name)
            tunnel_data['tunnel_type'] = parsed_name.get('prefix', 'gre')
        
        # Handle GRE specific parameters
        if tunnel_data['tunnel_type'] == 'gre':
            params = tunnel_config.get('parameters', {}).get('ip', {})
            tunnel_data['gre_key'] = params.get('key', '')
            tunnel_data['gre_checksum'] = 'checksum' in params
        
        # Handle SIT specific parameters
        elif tunnel_data['tunnel_type'] == 'sit':
            tunnel_data['sit_6rd_prefix'] = tunnel_config.get('6rd-prefix', '')
            tunnel_data['sit_6rd_relay_prefix'] = tunnel_config.get('6rd-relay-prefix', '')
        
        # Parse IP addresses
        addresses = tunnel_config.get('address', [])
        if not isinstance(addresses, list):
            addresses = [addresses] if addresses else []
        
        ipv4_addrs = []
        ipv6_addrs = []
        
        for addr in addresses:
            if ':' in str(addr):
                ipv6_addrs.append(addr)
            else:
                ipv4_addrs.append(addr)
        
        tunnel_data['ipv4_addresses'] = ipv4_addrs
        tunnel_data['ipv6_addresses'] = ipv6_addrs
        
        tunnels.append(tunnel_data)
    
    return tunnels


def parse_to_iptunnel_config(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert frontend data format to VyOS tunnel configuration format"""
    tunnel_type = data.get('tunnel_type', 'gre')
    tunnel_name = data.get('tunnel_name', '')
    
    if not tunnel_name:
        raise ValueError("Tunnel name is required")
    
    # Build the tunnel configuration
    tunnel_config = {}
    
    # Basic parameters
    if data.get('description'):
        tunnel_config['description'] = data['description']
    
    if data.get('disable', False):
        tunnel_config['disable'] = {}
    
    # Source and remote addresses
    if data.get('source_address'):
        tunnel_config['source-address'] = data['source_address']
    
    if data.get('remote_address'):
        tunnel_config['remote'] = data['remote_address']
    
    # Encapsulation type
    tunnel_config['encapsulation'] = tunnel_type
    
    # Optional numeric parameters
    if data.get('ttl') is not None:
        tunnel_config['ttl'] = data['ttl']
    
    if data.get('tos'):
        tunnel_config['tos'] = data['tos']
    
    if data.get('mtu') is not None:
        tunnel_config['mtu'] = data['mtu']
    
    if data.get('multicast', False):
        tunnel_config['enable-multicast'] = {}
    
    if data.get('disable_link_detect', False):
        tunnel_config['disable-link-detect'] = {}
    
    # IP General Options
    has_ip_options = any([
        data.get('ip_arp_cache_timeout') is not None,
        data.get('ip_adjust_mss'),
        data.get('ip_enable_arp_accept', False),
        data.get('ip_enable_arp_announce', False),
        data.get('ip_disable_arp_filter', False),
        data.get('ip_enable_arp_ignore', False),
        data.get('ip_enable_directed_broadcast', False),
        data.get('ip_disable_forwarding', False),
        data.get('ip_enable_proxy_arp', False),
        data.get('ip_enable_proxy_arp_pvlan', False),
        data.get('ip_source_validation')
    ])
    
    if has_ip_options:
        tunnel_config['ip'] = {}
        
        # Numeric option
        if data.get('ip_arp_cache_timeout') is not None:
            tunnel_config['ip']['arp-cache-timeout'] = str(data['ip_arp_cache_timeout'])
        
        # String option (can be clamp-mss-to-pmtu or numeric value)
        if data.get('ip_adjust_mss'):
            tunnel_config['ip']['adjust-mss'] = data['ip_adjust_mss']
        
        # Flag options
        if data.get('ip_enable_arp_accept', False):
            tunnel_config['ip']['enable-arp-accept'] = {}
        
        if data.get('ip_enable_arp_announce', False):
            tunnel_config['ip']['enable-arp-announce'] = {}
        
        if data.get('ip_disable_arp_filter', False):
            tunnel_config['ip']['disable-arp-filter'] = {}
        
        if data.get('ip_enable_arp_ignore', False):
            tunnel_config['ip']['enable-arp-ignore'] = {}
        
        if data.get('ip_enable_directed_broadcast', False):
            tunnel_config['ip']['enable-directed-broadcast'] = {}
        
        if data.get('ip_disable_forwarding', False):
            tunnel_config['ip']['disable-forwarding'] = {}
        
        if data.get('ip_enable_proxy_arp', False):
            tunnel_config['ip']['enable-proxy-arp'] = {}
        
        if data.get('ip_enable_proxy_arp_pvlan', False):
            tunnel_config['ip']['proxy-arp-pvlan'] = {}
        
        # Source validation (value-based)
        if data.get('ip_source_validation'):
            tunnel_config['ip']['source-validation'] = data['ip_source_validation']
    
    # Tunnel type specific parameters
    if tunnel_type == 'gre':
        if data.get('gre_key'):
            if 'parameters' not in tunnel_config:
                tunnel_config['parameters'] = {}
            if 'ip' not in tunnel_config['parameters']:
                tunnel_config['parameters']['ip'] = {}
            tunnel_config['parameters']['ip']['key'] = data['gre_key']
        
        if data.get('gre_checksum', False):
            if 'parameters' not in tunnel_config:
                tunnel_config['parameters'] = {}
            if 'ip' not in tunnel_config['parameters']:
                tunnel_config['parameters']['ip'] = {}
            tunnel_config['parameters']['ip']['checksum'] = {}
    
    elif tunnel_type == 'sit':
        if data.get('sit_6rd_prefix'):
            tunnel_config['6rd-prefix'] = data['sit_6rd_prefix']
        if data.get('sit_6rd_relay_prefix'):
            tunnel_config['6rd-relay-prefix'] = data['sit_6rd_relay_prefix']
    
    elif tunnel_type == 'erspan':
        if data.get('erspan_direction'):
            if 'parameters' not in tunnel_config:
                tunnel_config['parameters'] = {}
            if 'erspan' not in tunnel_config['parameters']:
                tunnel_config['parameters']['erspan'] = {}
            tunnel_config['parameters']['erspan']['direction'] = data['erspan_direction']
    
    # IP addresses
    addresses = []
    if data.get('ipv4_addresses'):
        addresses.extend(data['ipv4_addresses'])
    if data.get('ipv6_addresses'):
        addresses.extend(data['ipv6_addresses'])
    
    if addresses:
        tunnel_config['address'] = addresses
    
    # IPv6 options
    has_ipv6_options = any([
        data.get('ipv6_eui64_prefix'),
        data.get('ipv6_accept_dad') is not None,
        data.get('ipv6_dup_addr_detect_transmits') is not None,
        data.get('ipv6_base_reachable_time') is not None,
        data.get('ipv6_address_autoconf', False),
        data.get('ipv6_adjust_mss'),
        data.get('ipv6_disable_forwarding', False),
        data.get('ipv6_source_validation'),
        data.get('ipv6_no_default_link_local', False)
    ])
    
    if has_ipv6_options:
        tunnel_config['ipv6'] = {}
        
        # IPv6 address options
        if data.get('ipv6_eui64_prefix') or data.get('ipv6_address_autoconf', False) or data.get('ipv6_no_default_link_local', False):
            tunnel_config['ipv6']['address'] = {}
            
            if data.get('ipv6_eui64_prefix'):
                tunnel_config['ipv6']['address']['eui64'] = data['ipv6_eui64_prefix']
            
            if data.get('ipv6_address_autoconf', False):
                tunnel_config['ipv6']['address']['autoconf'] = {}
            
            if data.get('ipv6_no_default_link_local', False):
                tunnel_config['ipv6']['address']['no-default-link-local'] = {}
        
        # Accept DAD (directly under ipv6)
        if data.get('ipv6_accept_dad') is not None:
            tunnel_config['ipv6']['accept-dad'] = str(data['ipv6_accept_dad'])
        
        # DAD transmits (directly under ipv6)
        if data.get('ipv6_dup_addr_detect_transmits') is not None:
            tunnel_config['ipv6']['dup-addr-detect-transmits'] = str(data['ipv6_dup_addr_detect_transmits'])
        
        # Base reachable time (directly under ipv6)
        if data.get('ipv6_base_reachable_time') is not None:
            tunnel_config['ipv6']['base-reachable-time'] = str(data['ipv6_base_reachable_time'])
        
        # Adjust MSS (directly under ipv6)
        if data.get('ipv6_adjust_mss'):
            tunnel_config['ipv6']['adjust-mss'] = data['ipv6_adjust_mss']
        
        # Disable forwarding (flag - directly under ipv6)
        if data.get('ipv6_disable_forwarding', False):
            tunnel_config['ipv6']['disable-forwarding'] = {}
        
        # Source validation (directly under ipv6)
        if data.get('ipv6_source_validation'):
            tunnel_config['ipv6']['source-validation'] = data['ipv6_source_validation']
    
    # Return in VyOS interfaces format
    return {
        'interfaces': {
            'tunnel': {
                tunnel_name: tunnel_config
            }
        }
    }


def parse_current_iptunnel_interface_config(os_config: Any) -> Dict[str, Any]:
    """Parse current tunnel configuration from OS config"""
    if hasattr(os_config, 'json'):
        os_data = os_config.json()
    else:
        os_data = os_config
    
    if isinstance(os_data, dict) and 'data' in os_data:
        config_data = os_data['data']
    else:
        config_data = os_data
    
    interfaces = config_data.get('interfaces', {})
    tunnel_config = interfaces.get('tunnel', {})
    
    # Clean up empty address dicts in IPv6 config
    for tunnel_name, tunnel_data in tunnel_config.items():
        if 'ipv6' in tunnel_data and isinstance(tunnel_data['ipv6'], dict):
            if 'address' in tunnel_data['ipv6'] and not tunnel_data['ipv6']['address']:
                # Remove empty address dict
                del tunnel_data['ipv6']['address']
    
    return {
        'interfaces': {
            'tunnel': tunnel_config
        }
    }