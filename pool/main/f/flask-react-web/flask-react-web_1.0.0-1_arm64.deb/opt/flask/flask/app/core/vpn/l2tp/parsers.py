def parse_to_vyos_config(data):

    if not data:
        return None
    
    result = {'remote-access': {}}
    remote_access = result['remote-access']
    
    connection = data.get('connection', {})
    security = data.get('security', {})
    
    general = connection.get('general', {})
    if general:
        if general.get('description'):
            remote_access['description'] = general['description']
        if general.get('defaultIPPool'):
            remote_access['default-pool'] = general['defaultIPPool']
        if general.get('defaultIPv6Pool'):
            remote_access['default-ipv6-pool'] = general['defaultIPv6Pool']
        if general.get('gatewayAddress'):
            remote_access['gateway-address'] = general['gatewayAddress']
        if general.get('outsideAddress'):
            remote_access['outside-address'] = general['outsideAddress']
    
    advanced = connection.get('advanced', {})
    if advanced:
        if advanced.get('MTU'):
            remote_access['mtu'] = str(advanced['MTU'])
        
        if advanced.get('nameServers'):
            name_servers = advanced['nameServers']
            if isinstance(name_servers, list) and len(name_servers) > 0:
                remote_access['name-server'] = name_servers
        
        if advanced.get('log') is not None:
            remote_access['log'] = {'level': str(advanced['log'])}
        
        if advanced.get('WINS'):
            wins_servers = advanced['WINS']
            if isinstance(wins_servers, list) and len(wins_servers) > 0:
                remote_access['wins-server'] = wins_servers
        
        ppp = advanced.get('PPP', {})
        if ppp:
            ppp_options = {}
            
            if ppp.get('controlProtocol'):
                ppp_options['disable-ccp'] = {}
            
            if ppp.get('interfaceCaching') is not None and ppp.get('interfaceCaching') > 0:
                ppp_options['interface-cache'] = str(ppp['interfaceCaching'])
            
            if ppp.get('IPv4Negotiation'):
                ppp_options['ipv4'] = ppp['IPv4Negotiation']
            
            if ppp.get('IPv6Negotiation'):
                ppp_options['ipv6'] = ppp['IPv6Negotiation']
            
            if ppp.get('acceptPeerInterfaceID'):
                ppp_options['ipv6-accept-peer-interface-id'] = {}
            
            if ppp.get('IPv6InterfaceID'):
                ppp_options['ipv6-interface-id'] = ppp['IPv6InterfaceID']
            
            if ppp.get('IPv6PeerInterface'):
                ppp_options['ipv6-peer-interface-id'] = ppp['IPv6PeerInterface']
            
            if ppp.get('LCPEchoFailure') is not None and ppp.get('LCPEchoFailure') > 0:
                ppp_options['lcp-echo-failure'] = str(ppp['LCPEchoFailure'])
            
            if ppp.get('LCPEchoInterval') is not None and ppp.get('LCPEchoInterval') > 0:
                ppp_options['lcp-echo-interval'] = str(ppp['LCPEchoInterval'])
            
            if ppp.get('LCPEchoTimeout') is not None and ppp.get('LCPEchoTimeout') > 0:
                ppp_options['lcp-echo-timeout'] = str(ppp['LCPEchoTimeout'])
            
            if ppp.get('minMTU') is not None and ppp.get('minMTU') >= 68:
                ppp_options['min-mtu'] = str(ppp['minMTU'])
            
            if ppp.get('MPPE'):
                ppp_options['mppe'] = ppp['MPPE']
            
            if ppp.get('MRU') is not None and ppp.get('MRU') >= 68:
                ppp_options['mru'] = str(ppp['MRU'])
            
            if ppp_options:
                remote_access['ppp-options'] = ppp_options
    
    # IPSec Settings
    ipsec_settings = connection.get('ipsecSettings', {})
    if ipsec_settings:
        ipsec_config = {}
        
        if ipsec_settings.get('espGroup'):
            ipsec_config['esp-group'] = ipsec_settings['espGroup']
        
        if ipsec_settings.get('ikeGroup'):
            ipsec_config['ike-group'] = ipsec_settings['ikeGroup']
        
        if ipsec_settings.get('lifetime') is not None and ipsec_settings.get('lifetime') > 0:
            ipsec_config['lifetime'] = str(ipsec_settings['lifetime'])
        
        auth = ipsec_settings.get('authentication', {})
        if auth:
            auth_config = {}
            
            if auth.get('mode'):
                auth_config['mode'] = auth['mode']
            
            if auth.get('preSharedSecret'):
                auth_config['pre-shared-secret'] = auth['preSharedSecret']
            
            # Handle nested x509 structure
            x509 = auth.get('x509', {})
            if x509 and (x509.get('caCertificate') or x509.get('certificate') or x509.get('passphrase')):
                x509_config = {}
                if x509.get('caCertificate'):
                    x509_config['ca-certificate'] = x509['caCertificate']
                if x509.get('certificate'):
                    x509_config['certificate'] = x509['certificate']
                if x509.get('passphrase'):
                    x509_config['passphrase'] = x509['passphrase']
                if x509_config:
                    auth_config['x509'] = x509_config
            
            if auth_config:
                ipsec_config['authentication'] = auth_config
        
        if ipsec_config:
            remote_access['ipsec-settings'] = ipsec_config
    
    # LNS Settings
    lns = connection.get('lns', {})
    if lns:
        lns_config = {}
        if lns.get('hostName'):
            lns_config['host-name'] = lns['hostName']
        if lns.get('sharedSecret'):
            lns_config['shared-secret'] = lns['sharedSecret']
        if lns_config:
            remote_access['lns'] = lns_config
    
    client_ip_pools = connection.get('clientIPPools', {}).get('pools', [])
    if client_ip_pools:
        remote_access['client-ip-pool'] = {}
        for pool in client_ip_pools:
            pool_name = pool.get('name')
            subnet = pool.get('subnet', '')
            if pool_name and subnet:
                remote_access['client-ip-pool'][pool_name] = {'range': subnet}
    
    client_ipv6_pools = connection.get('clientIPv6Pools', {}).get('IPv6Pools', [])
    if client_ipv6_pools:
        remote_access['client-ipv6-pool'] = {}
        for pool in client_ipv6_pools:
            pool_name = pool.get('name')
            if pool_name:
                prefix = pool.get('prefix', '')
                if prefix:
                    remote_access['client-ipv6-pool'][pool_name] = {
                        'prefix': {prefix: {}}
                    }
    
    authentication = {}
    
    if security.get('mode'):
        authentication['mode'] = security['mode']
    
    if security.get('protocol'):
        protocols = security['protocol']
        if isinstance(protocols, list) and len(protocols) > 0:
            authentication['protocols'] = protocols
    
    local_users = security.get('localUsers', {}).get('users', [])
    if local_users:
        authentication['local-users'] = {'username': {}}
        for user in local_users:
            username = user.get('name') or user.get('username')
            if username:
                user_config = {}
                
                if user.get('password'):
                    user_config['password'] = user['password']
                
                if user.get('staticIP'):
                    user_config['static-ip'] = user['staticIP']
                
                is_disabled = user.get('disabled', False)
                is_enabled = user.get('enabled', True)
                if is_disabled or not is_enabled:
                    user_config['disable'] = {}
                
                authentication['local-users']['username'][username] = user_config
    
    radius_config = security.get('radius', {})
    if radius_config:
        radius = {}
        
        radius_options = radius_config.get('options', {})
        if radius_options:
            if radius_options.get('sourceAddress'):
                radius['source-address'] = radius_options['sourceAddress']
            
            if radius_options.get('NASIdentifier'):
                radius['nas-identifier'] = radius_options['NASIdentifier']
            
            if radius_options.get('NASIPAddress'):
                radius['nas-ip-address'] = radius_options['NASIPAddress']
            
            timeout = radius_options.get('timeout')
            if timeout is not None and timeout != '' and timeout > 0:
                radius['timeout'] = str(timeout)
            
            max_try = radius_options.get('maxTry')
            if max_try is not None and max_try != '' and max_try > 0:
                radius['max-try'] = str(max_try)
        
        radius_servers = radius_config.get('servers', [])
        if radius_servers:
            radius['server'] = {}
            for server in radius_servers:
                address = server.get('address')
                if address:
                    server_config = {}
                    
                    if server.get('port') is not None and server.get('port') > 0:
                        server_config['port'] = str(server['port'])
                    
                    key = server.get('key') or server.get('secret')
                    if key:
                        server_config['key'] = key
                    
                    if server.get('priority') is not None and server.get('priority') > 0:
                        server_config['priority'] = str(server['priority'])
                    
                    is_disabled = server.get('disabled', False)
                    is_enabled = server.get('enabled', True)
                    if is_disabled or not is_enabled:
                        server_config['disable'] = {}
                    
                    if server.get('accountingPort') is not None and server.get('accountingPort') > 0:
                        server_config['acct-port'] = str(server['accountingPort'])
                    
                    if server.get('failTimePenalty') is not None and server.get('failTimePenalty') > 0:
                        server_config['fail-time'] = str(server['failTimePenalty'])
                    
                    if server.get('disableAccounting'):
                        server_config['disable-accounting'] = {}
                    
                    if server.get('backup'):
                        server_config['backup'] = {}
                    
                    radius['server'][address] = server_config
        
        if radius:
            authentication['radius'] = radius
    
    if authentication:
        remote_access['authentication'] = authentication
    
    return result
