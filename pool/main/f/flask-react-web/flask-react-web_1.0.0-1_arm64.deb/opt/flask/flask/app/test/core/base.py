"""
Base class for testing configuration update functions.
This class defines test methods but doesn't run them directly.
Subclasses should inherit from this class and specify test parameters.

Using __test__ = False prevents pytest from collecting tests in this class
"""

import pytest
import inspect
from app.core.utils.process_config import merge_dicts_set, merge_dicts_delete
from copy import deepcopy
from app.core.api.http.cmd.compare import compare_configs
from app.core.utils.process_config import process_commands
from pydantic import ValidationError
from app.test.conftest import test_service_provider
from app.core.api.http.http_request import Action
import json

def parametrize_test(param_name, param_values):
    """
    Decorator that applies pytest.mark.parametrize to test methods in a class.
    Base class to define the test methods without triggering them,
    derived classes can use the methods with specific test parameters.
    
    Args:
        param_name: Name of the parameter to pass to the test function
        param_values: List of values to use for parametrization
    """
    def decorator(cls):
        # Find all test methods in the class then:
        # Apply the parametrize decorator to each test method
        for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
            if name.startswith('test_'):
                setattr(cls, name, pytest.mark.parametrize(param_name, param_values)(method))
        return cls
    return decorator


class TestParseInput:
    __test__ = False

    def test_model_validate_json_valid(self, test_data, dto_model):
        dto = dto_model.model_validate_json(test_data['valid_json'])

        assert isinstance(dto, dto_model)

    def test_model_validate_json_invalid(self, test_data, dto_model):
        with pytest.raises(ValidationError):
            dto_model.model_validate_json(test_data['invalid_json'])

    def test_model_validate_minimal_json(self, test_data, dto_model):
        dto = dto_model.model_validate_json(test_data['minimal_json'])

        assert isinstance(dto, dto_model)

    def test_compare_configs_additions(self, test_data):
        diff = compare_configs(test_data['new_config'], test_data['current_config'])
        
        assert "created" in diff
        assert "deleted" in diff

        print("Diff data: ")
        print(diff)
        
        assert diff == test_data['expected_diff']


class TestGenerateConfig:
    __test__ = False
    
    def test_command_custom_initialization(self, cmd_class):
        cmd = cmd_class(operator='delete', resource='custom_resource')
        assert cmd.operator == 'delete'
        assert cmd.resource == 'custom_resource'

    def test_command_initialization(self, cmd, cmd_class, resource):
        assert cmd.operator == 'set'
        assert cmd.cmds == []
        assert cmd.vyos_cmds == []

    def test_generate_commands_set(self, cmd_set, test_data):
        config, commands = test_data
        cmd_set.generate_commands(config)
        generated_commands = cmd_set.get_commands()
        print("generated commands: ")
        print(generated_commands)
        for cmd in commands:
            assert cmd in generated_commands

    def test_generate_commands_delete(self, cmd_delete, test_data):
        config, commands = test_data
        cmd_delete.generate_commands(config)
        generated_commands = cmd_delete.get_commands()
        print("generated commands: ")
        print(generated_commands)
        for cmd in commands:
            assert cmd in generated_commands
    
    def test_process_commands(self, test_data):
        commands, dict_config = test_data
        config = process_commands(commands)
        assert config == dict_config

    def test_get_commands_empty(self, cmd_class):
        cmd = cmd_class()
        commands = cmd.get_commands()
        assert commands == []


class TestProcessConfig:
    __test__ = False
    
    def test_merge_dicts_set(self, test_data):
        current_config = deepcopy(test_data["current_config"])
        set_config = deepcopy(test_data["set_config"])
        merged_config = merge_dicts_set(current_config, set_config)
        print("merged config: ")
        print(merged_config)
        
        assert merged_config == test_data["expected_config"]

    def test_merge_dicts_delete(self, test_data, aggressive):
        current_config = deepcopy(test_data["current_config"])
        delete_config = deepcopy(test_data["delete_config"])
        merged_config = merge_dicts_delete(current_config, delete_config, clean_empty=False, aggressive=aggressive)
        print("merged config: ")
        print(merged_config)
        print("expected config: ")
        print(test_data["expected_config"])
        assert merged_config == test_data["expected_config"]
    
    def test_merge_dicts_set_delete(self, test_data, aggressive):
        current_config = deepcopy(test_data["current_config"])
        delete_config = deepcopy(test_data["delete_config"])
        set_config = deepcopy(test_data["set_config"])

        merged_del_config = merge_dicts_delete(current_config, delete_config, aggressive=aggressive)
        merged_config = merge_dicts_set(merged_del_config, set_config)
        print("merged del config:")
        print(merged_del_config)
        print("merged config:")
        print(merged_config)
        assert merged_config == test_data["expected_config"]


class TestVerify:
    __test__ = False

    @pytest.fixture
    def success_verification(self):
        return ['None', '']


    def test_verify_current_config(self, test_service_provider, success_verification, service, test_get_current_config):
        verification = test_service_provider.verify_service.call_verify(service=service, config=test_get_current_config)        
        assert verification in success_verification

    def test_verify_failed(self, test_service_provider, success_verification, service, test_data):
        verification = test_service_provider.verify_service.call_verify(service=service, config=test_data)
        print("Test verify result: ")
        print(verification)
        assert verification not in success_verification
    

    def test_verify_success(self, test_service_provider, success_verification, service, test_data):
        verification = test_service_provider.verify_service.call_verify(service=service, config=test_data)
        print("Test verify result: ")
        print(verification)
        assert verification in success_verification


class TestFinal:

    __test__ = False

    @pytest.fixture
    def success_verification(self):
        return ['None', '']

    def send_to_vyos(self, test_service_provider, set_cmds, delete_cmds):
        
        results = []
        
        if set_cmds:
            res = test_service_provider.http_service.send_request(
                action=Action.CONFIGURE, 
                data=set_cmds, 
                verify=False
            ).json()
            results.append({
                "cmd": set_cmds, 
                "success": res['success'], 
                "error": res.get('error', None)
            })
            assert res['success'] is True, f"SET commands failed: {res.get('error', 'Unknown error')}"
        
        if delete_cmds:
            res = test_service_provider.http_service.send_request(
                action=Action.CONFIGURE, 
                data=delete_cmds, 
                verify=False
            ).json()
            results.append({
                "cmd": delete_cmds, 
                "success": res['success'], 
                "error": res.get('error', None)
            })
            assert res['success'] is True, f"DELETE commands failed: {res.get('error', 'Unknown error')}"
        
        return results

    def _update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data, send_to_vyos_enabled=False):
        # Test parse frontend json config to config, then test compare config
        current_config = test_data['parsed_input']['current_config']
        validated_config = dto_model.model_validate_json(json.dumps(test_data['parsed_input']['json_input']))

        data = validated_config.model_dump(exclude_none=True)
        assert data == test_data['parsed_input']['validated_input']
        new_config = parser(data)
        assert new_config == test_data['parsed_input']['parsed_input']
        
        diff = compare_configs(new_config, current_config)
        assert 'created' in diff
        assert 'deleted' in diff
        assert diff['created'] == test_data['parsed_input']['diff_created']
        assert diff['deleted'] == test_data['parsed_input']['diff_deleted']
        
        # Test command
        cmd_set.generate_commands(new_config, current_config)
        cmd_delete.generate_commands(new_config, current_config)
        set_cmds = cmd_set.get_commands()
        assert set_cmds == test_data['generate_config']['set_cmds']
        delete_cmds = cmd_delete.get_commands()
        assert delete_cmds == test_data['generate_config']['delete_cmds']

        if send_to_vyos_enabled:
            vyos_results = self.send_to_vyos(test_service_provider, set_cmds, delete_cmds)
            print("VyOS command results:")
            for result in vyos_results:
                print(f"  Success: {result['success']}, Error: {result['error']}")

        set_config = process_commands(set_cmds)
        assert set_config == test_data['generate_config']['processed_set_config']

        delete_config = process_commands(delete_cmds)
        assert delete_config == test_data['generate_config']['processed_delete_config']
        

        # Test update: merge set, and merge delete 
        sample_curr_config = test_data['process_config']['curr_config']
        merged_del_config = merge_dicts_delete({"service": {"ntp": sample_curr_config}}, delete_config, clean_empty=False)
        merged_config = merge_dicts_set(merged_del_config, set_config)

        assert merged_del_config == test_data['process_config']['merged_del']
        assert merged_config == test_data['process_config']['merged_set']

        # Test verify
        verify = test_service_provider.verify_service.call_verify("ntp", merged_config['service']['ntp'])
        verify_result = test_data['verify']['verify_result']

        if verify_result:
            assert verify in success_verification
        else:
            assert verify not in success_verification
