SCALAR_FIELDS = {
    'client_keepalive_interval': 'client-keepalive-interval',
    'loglevel': 'loglevel',
}

LIST_FIELDS = {
    'listen_addresses': 'listen-address',
    'ciphers': 'cipher',
    'hostkey_algorithms': 'hostkey-algorithm',
    'key_exchanges': 'key-exchange',
    'macs': 'mac',
    'ports': 'port',
    'pubkey_accepted_algorithms': 'pubkey-accepted-algorithm',
}

FLAG_FIELDS = {
    'disable_host_validation': 'disable-host-validation',
    'disable_password_authentication': 'disable-password-authentication',
}


def parse_to_ssh_config(data: dict) -> dict:
    """Convert the SSH page DTO into the structure expected by VyOS."""
    if not data.get('enabled'):
        return {}

    config = {}

    for source, target in SCALAR_FIELDS.items():
        value = data.get(source)
        if value not in (None, ''):
            config[target] = (
                str(value) if source == 'client_keepalive_interval' else value
            )

    trusted_user_ca = data.get('trusted_user_ca')
    if isinstance(trusted_user_ca, str):
        trusted_user_ca = trusted_user_ca.strip()
    if trusted_user_ca:
        config['trusted-user-ca'] = trusted_user_ca

    for source, target in LIST_FIELDS.items():
        values = data.get(source) or []
        if values:
            config[target] = (
                [str(value) for value in values]
                if source == 'ports'
                else values
            )

    for source, target in FLAG_FIELDS.items():
        if data.get(source):
            config[target] = {}

    rekey_data = data.get('rekey') or {}
    if rekey_data.get('enabled'):
        rekey = {
            key: str(value)
            for key, value in rekey_data.items()
            if key != 'enabled' and value not in (None, '')
        }
        if rekey:
            config['rekey'] = rekey

    access_config = _parse_access_control(data.get('access_control') or {})
    if access_config:
        config['access-control'] = access_config

    protection_config = _parse_dynamic_protection(data.get('dynamic_protection') or {})
    if protection_config is not None:
        config['dynamic-protection'] = protection_config

    return config


def _parse_access_control(access_control: dict) -> dict:
    config = {}

    if access_control.get('allow_users'):
        config['allow'] = {'user': access_control['allow_users']}

    if access_control.get('deny_users'):
        config['deny'] = {'user': access_control['deny_users']}

    return config


def _parse_dynamic_protection(protection: dict) -> dict | None:
    if not protection.get('enabled'):
        return None

    config = {}
    if protection.get('enabled'):
        if protection.get('allow_from'):
            config['allow-from'] = protection['allow_from']

        fields = (
            ('block_time', 'block-time'),
            ('detect_time', 'detect-time'),
            ('threshold', 'threshold'),
        )
        for source, target in fields:
            value = protection.get(source)
            if value not in (None, ''):
                config[target] = str(value)

    return config
