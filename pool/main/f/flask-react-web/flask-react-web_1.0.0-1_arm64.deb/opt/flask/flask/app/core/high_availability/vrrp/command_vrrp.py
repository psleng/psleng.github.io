from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']

class VRRPCommand(Command):
    """Command class for OSPF commands
    - set/delete high-availability vrrp group <group-name> description <text>
    - set/delete high-availability vrrp group <group-name> disable  
    - set/delete high-availability vrrp group <group-name> address {IPv4[/n] | IPv6[/m]} 
    - set/delete high-availability vrrp group <group-name> interface <intf-name> 
    - set/delete high-availability vrrp group <group-name> vrid <1-255> 
    - set/delete high-availability vrrp group <group-name> advertise-interval <1-255> 
    - set/delete high-availability vrrp group <group-name> authentication password <text> 
    - set/delete high-availability vrrp group <group-name> excluded-address {IPv4[/n] | IPv6[/m] } 
    - set/delete high-availability vrrp group <group-name> no-preempt 
    - set/delete high-availability vrrp group <group-name> peer-address {IPv4 | IPv6} 
    - set/delete high-availability vrrp group <group-name> preempt-delay <0-1000> 
    - set/delete high-availability vrrp group <group-name> priority 
    - set/delete high-availability vrrp group <group-name> rfc3768-compatibility  
    - set/delete high-availability vrrp group <group-name> garp interval <0.000-1000> 
    - set/delete high-availability vrrp group <group-name> garp master-delay <1-1000> 
    - set/delete high-availability vrrp group <group-name> garp master-refresh {0 |<1-255> } 
    - set/delete high-availability vrrp group <group-name> garp master-refresh-repeat <1-255> 
    - set/delete high-availability vrrp group <group-name> garp master-repeat <1-255> 
    - set/delete high-availability vrrp group <group-name> health-check failure-count <1-10> 
    - set/delete high-availability vrrp group <group-name> health-check interval  <1-3600> 
    - set/delete high-availability vrrp group <group-name> health-check ping {IPv4 | IPv6} 
    - set/delete high-availability vrrp group <group-name> track exclude-vrrp-interface 
    - set/delete high-availability vrrp group <group-name> track interface <intf-name> 
    - set/delete high-availability vrrp sync-group <sgroup-name> member <vrrp-group-name> 
    - Set/delete high-availability vrrp global-parameters startup-delay <1-600> 
    - Set/delete high-availability vrrp global-parameters version {2 | 3} 
    - Set/delete high-availability vrrp snmp 
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'vrrp'))
            self.attributes = {
                'high-availability': {
                    'vrrp': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing VRRP cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    
    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            print("data is:", data)
            self.attributes['high-availability']['vrrp'] = data


            if 'global-parameters' in data:
                self._process_global_parameters(data['global-parameters'])

            # Process sync-group AFTER you've passed membership info to group processing,
            # or ensure sync-group processing does NOT emit deletions prematurely.

            if 'sync-group' in data:
                self._process_sync_group_config(data, new_config)  # Ensure this doesn't delete early
            if 'group' in data:
                self._process_group_config(data, new_config)

            if 'snmp' in data:
                base_path = ['high-availability', 'vrrp']
                self.generate(*base_path, 'snmp')

            print(f"Generated VRRP commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating VRRP commands: {e}")
            return []

    
    
    def _process_group_config(self, data, new_config):
        
        if not isinstance(data, dict):
                return

        current_groups = data.get('group') or {}
        new_groups = new_config.get('group') or {}

        for name in current_groups:

            if self.operator == 'delete' and name not in new_groups:
                self.generate('high-availability', 'vrrp', 'group', name)
                continue

            config = data['group'][name]
            base_path = ['high-availability', 'vrrp', 'group', name]

            if 'description' in config and is_str_not_empty(config['description']):
                self.generate(*base_path, 'description', config['description'])

            if config.get('disable') == {}:
                self.generate(*base_path, 'disable')

            for addr in (config.get('address') or {}):
                self.generate(*base_path, 'address', addr)

            if 'interface' in config and is_str_not_empty(config['interface']):
                self.generate(*base_path, 'interface', config['interface'])

            if 'vrid' in config and is_str_not_empty(str(config['vrid'])):
                self.generate(*base_path, 'vrid', str(config['vrid']))

            if 'advertise-interval' in config and is_str_not_empty(str(config['advertise-interval'])):
                self.generate(*base_path, 'advertise-interval', str(config['advertise-interval']))

            if 'authentication' in config:
                auth_config = config['authentication']
                if self.operator == 'delete':
                    self.generate(*base_path, 'authentication')
                else:
                    if 'password' in auth_config and is_str_not_empty(auth_config['password']):
                        self.generate(*base_path, 'authentication', 'password', auth_config['password'])
                        self.generate(*base_path, 'authentication', 'type', 'plaintext-password')

            for addr in (config.get('excluded-address') or {}):
                self.generate(*base_path, 'excluded-address', addr)

            if config.get('no-preempt') == {}:
                self.generate(*base_path, 'no-preempt')

            if 'peer-address' in config and is_str_not_empty(config['peer-address']):
                self.generate(*base_path, 'peer-address', config['peer-address'])

            if 'preempt-delay' in config and is_str_not_empty(str(config['preempt-delay'])):
                self.generate(*base_path, 'preempt-delay', str(config['preempt-delay']))

            if 'priority' in config and is_str_not_empty(str(config['priority'])):
                self.generate(*base_path, 'priority', str(config['priority']))

            if config.get('rfc3768-compatibility') == {}:
                self.generate(*base_path, 'rfc3768-compatibility')

            if 'garp' in config:
                self._process_garp(config, name)
                
            if 'health-check' in config:
                hc = config.get('health-check') or {}
                ping = hc.get('ping')
                if self.operator == 'delete':
                       self.generate(*base_path, 'health-check')
                else:
                    if isinstance(ping, str) and is_str_not_empty(ping):
                        self._process_health_check(config, 'group', name)

            if 'track' in config:
                new_track = new_config.get('group', {}).get(name, {}).get('track', {})
                track_config = config.get('track') or {}
    
                if self.operator == 'delete' and new_track == {}:
                    self.generate(*base_path, 'track')
                else:
                    if isinstance(track_config, dict):
                        
                        # normalize interface field to list
                        iface_raw = track_config.get('interface')
                        if isinstance(iface_raw, str):
                            iface_raw = [iface_raw] if iface_raw.strip() else []
                        elif not isinstance(iface_raw, list):
                            iface_raw = []

                        # emit
                        for intr in iface_raw:
                            if isinstance(intr, str) and is_str_not_empty(intr):
                                self.generate(*base_path, 'track', 'interface', intr)

                        curr_excl = track_config.get('exclude-vrrp-interface')
                        new_excl = None
                        if isinstance(new_config, dict):
                            new_excl = new_config.get('group', {}).get(name, {}).get('track', {}).get('exclude-vrrp-interface')

                        if curr_excl == {} and new_excl is None:
                            path = ','.join(f'"{element}"' for element in (*base_path, 'track', 'exclude-vrrp-interface'))
                            self.cmds.append(f'{{"op":"delete", "path": [{path}]}}')
                            self.vyos_cmds.append(' '.join(map(str, (*base_path, 'track', 'exclude-vrrp-interface'))))
                 
                        elif new_excl == {}:
                            self.generate(*base_path, 'track', 'exclude-vrrp-interface')

    def _process_sync_group_config(self, data, new_config):
        if not isinstance(data, dict):
                return
        
        current_sync = data.get('sync-group') or {}
        new_sync = new_config.get('sync-group') or {}

        for name in current_sync:
            if self.operator == 'delete' and name not in new_sync:
                self.generate('high-availability', 'vrrp', 'sync-group', name)
                continue

            config = data['sync-group'][name]
            base_path = ['high-availability', 'vrrp', 'sync-group', name]
        
      
            for member_name in (config.get('member') or []):
                if is_str_not_empty(member_name):
                    self.generate(*base_path, 'member', member_name)

            if 'description' in config and is_str_not_empty(config['description']):
                self.generate(*base_path, 'description', config['description'])

            if 'health-check' in config:
                hc = config.get('health-check') or {}
                ping = hc.get('ping')
                if self.operator == 'delete':
                        self.generate(*base_path, 'health-check')
                else:
                    if isinstance(ping, str) and is_str_not_empty(ping):
                        self._process_health_check(config, 'sync-group', name)
    
    def _process_global_parameters(self, data):
        if isinstance(data, dict):   
            base_path = ['high-availability', 'vrrp', 'global-parameters']
            
            if 'startup-delay' in data and is_str_not_empty(str(data['startup-delay'])):
                self.generate(*base_path, 'startup-delay', str(data['startup-delay']))

            if 'version' in data and is_str_not_empty(str(data['version'])):
                self.generate(*base_path, 'version', str(data['version']))

            if 'garp' in data:
                self._process_garp(data, "global-parameters")
    
    def _process_garp(self, data, name):
        if isinstance(data, dict):
            if name == 'global-parameters':
                base_path = ['high-availability', 'vrrp', 'global-parameters', 'garp']

            else:
                base_path = ['high-availability', 'vrrp', 'group', name, 'garp']

            garp_config = data.get('garp') or {}
            if 'interval' in garp_config and is_str_not_empty(str(garp_config.get('interval'))):
                self.generate(*base_path, 'interval', str(garp_config.get('interval')))
            if 'master-delay' in garp_config and is_str_not_empty(str(garp_config.get('master-delay'))):
                self.generate(*base_path, 'master-delay', str(garp_config.get('master-delay')))
            if 'master-refresh' in garp_config and is_str_not_empty(str(garp_config.get('master-refresh'))):
                self.generate(*base_path, 'master-refresh', str(garp_config.get('master-refresh')))
            if 'master-refresh-repeat' in garp_config and is_str_not_empty(str(garp_config.get('master-refresh-repeat'))):
                self.generate(*base_path, 'master-refresh-repeat', str(garp_config.get('master-refresh-repeat')))
            if 'master-repeat' in garp_config and is_str_not_empty(str(garp_config.get('master-repeat'))):
                self.generate(*base_path, 'master-repeat', str(garp_config.get('master-repeat')))

    def _process_health_check(self, data, type, name):
        if isinstance(data, dict):
            base_path = ['high-availability', 'vrrp', type, name, 'health-check']
            health_config = data['health-check']
            if 'failure-count' in health_config and is_str_not_empty(str(health_config['failure-count'])):
                self.generate(*base_path, 'failure-count', str(health_config['failure-count']))
            if 'interval' in health_config and is_str_not_empty(str(health_config['interval'])):
                self.generate(*base_path, 'interval', str(health_config['interval']))
            if 'ping' in health_config and is_str_not_empty(health_config['ping']):
                self.generate(*base_path, 'ping', health_config['ping'])

