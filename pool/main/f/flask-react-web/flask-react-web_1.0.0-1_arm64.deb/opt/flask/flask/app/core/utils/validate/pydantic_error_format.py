
def format_pydantic_error(error):
    from pydantic import ValidationError
    
    if not isinstance(error, ValidationError):
        return str(error)
    
    errors = error.errors()
    formatted_errors = []
    
    for err in errors:
        field_path = ' → '.join(str(loc) for loc in err['loc'])
        
        msg = err['msg']
        
        error_type = err['type']
        
        if error_type == 'string_type':
            formatted_errors.append(f"Field '{field_path}': Expected a string value, but received {err.get('input', 'invalid input')}")
        elif error_type == 'missing':
            formatted_errors.append(f"Field '{field_path}': This field is required")
        elif error_type == 'value_error':
            formatted_errors.append(f"Field '{field_path}': {msg}")
        else:
            formatted_errors.append(f"Field '{field_path}': {msg}")
    
    return '\n'.join(formatted_errors)
