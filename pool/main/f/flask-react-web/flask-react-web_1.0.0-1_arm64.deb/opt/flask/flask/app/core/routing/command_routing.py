from typing import List, Dict, Any, Optional
from app.core.api.http.cmd.command import Command
import pprint

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

class RoutingCommand(Command):
    """
    Command class for General Routing
    Support the following VyOS commands:
    - set/delete protocols static route <subnet/length> next-hop <ip-addr> distance <distance>
    - set/delete protocols static route <subnet/length> next-hop <ip-addr> interface <intf-name>
    - set/delete protocols static route <subnet/length> next-hop <ip-addr> distance <distance>
    - set/delete protocols static route <subnet/length> interface <intf-name> distance <distance>
    - set/delete protocols static route <subnet/length> dhcp-interface <intf-name> 
    - set/delete protocols static route <subnet/length> blackhole distance <distance>
    - set/delete protocols static route <subnet/length> reject distance <distance>

    - set/delete protocols static route6 <subnet/length> next-hop <ipv6-addr> distance <distance>
    - set/delete protocols static route6 <subnet/length> next-hop <ipv6-addr> interface <intf-name>
    - set/delete protocols static route6 <subnet/length> next-hop <ipv6-addr> distance <distance>
    - set/delete protocols static route6 <subnet/length> interface <intf-name> distance <distance>
    - set/delete protocols static route6 <subnet/length> blackhole distance <distance>
    - set/delete protocols static route6 <subnet/length> reject distance <distance>
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
            self.attributes = {
                'ipv4': {
                    'routes': []
                },
                'ipv6': {
                    'routes': []
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Routing cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a cmd string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        if args:
            last_arg = args[-1]
            if last_arg != "all":
                self.cmds.append(self._build_command(*args))
            else:
                self.cmds.append(self._build_command(*args[:-1]))
            self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        """Return the list of raw commands"""
        return self.vyos_cmds

    def _process_nested_routes(self, routes_data: Dict[str, Any], current_config=None, new_config=None):
        """Process routes in the new nested format
        
        Format example:
        {
            '0.0.0.0/0': {
                'blackhole': {'distance': '100'},
                'dhcp-interface': ['eth2', 'br1'],
                'interface': {
                    'br1': {'distance': '120'},
                    'eth2': {'distance': '50'}
                },
                'next-hop': {
                    '10.10.0.1': {},
                    '8.8.8.8': {
                        'distance': '200',
                        'interface': 'eth2'
                    }
                }
            },
            '255.255.255.0/24': {'blackhole': {'distance': '1'}}
        }
        """
        cmd_prefix = ['protocols', 'static']
        route_cmd = 'route' if self.resource == 'ipv4' else 'route6'
        cmd_prefix.append(route_cmd)
        
        for subnet, route_options in routes_data.items():
            subnet_cmd_prefix = cmd_prefix + [subnet]
            
            if 'blackhole' in route_options:
                blackhole_options = route_options['blackhole']
                if self.operator == 'set':
                    if blackhole_options and 'distance' in blackhole_options and is_str_not_empty(blackhole_options['distance']):
                        self.generate(*subnet_cmd_prefix, 'blackhole', 'distance', blackhole_options['distance'])
                    else:
                        self.generate(*subnet_cmd_prefix, 'blackhole')
                else:
                    self.generate(*subnet_cmd_prefix, 'blackhole')
            
            if 'reject' in route_options:
                reject_options = route_options['reject']
                if self.operator == 'set':
                    if reject_options and 'distance' in reject_options and is_str_not_empty(reject_options['distance']):
                        self.generate(*subnet_cmd_prefix, 'reject', 'distance', reject_options['distance'])
                    else:
                        self.generate(*subnet_cmd_prefix, 'reject')
                else:
                    self.generate(*subnet_cmd_prefix, 'reject')
            
            if 'dhcp-interface' in route_options:
                dhcp_interfaces = route_options['dhcp-interface']
                if isinstance(dhcp_interfaces, list):
                    for interface in dhcp_interfaces:
                        self.generate(*subnet_cmd_prefix, 'dhcp-interface', interface)
                else:
                    self.generate(*subnet_cmd_prefix, 'dhcp-interface', dhcp_interfaces)
            
            if 'interface' in route_options:
                interfaces = route_options['interface']
                if self.operator == 'set':
                    for interface, interface_options in interfaces.items():
                        if interface_options and 'distance' in interface_options and is_str_not_empty(interface_options['distance']):
                            self.generate(*subnet_cmd_prefix, 'interface', interface, 'distance', interface_options['distance'])
                        else:
                            self.generate(*subnet_cmd_prefix, 'interface', interface)
                else:
                    for interface, interface_options in interfaces.items():
                        self.generate(*subnet_cmd_prefix, 'interface', interface)
            
            if 'next-hop' in route_options:
                next_hops = route_options['next-hop']
                if self.operator == 'set':
                    for next_hop, next_hop_options in next_hops.items():
                        if not next_hop_options:
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop)
                        elif 'interface' in next_hop_options and 'distance' in next_hop_options and is_str_not_empty(next_hop_options['distance']):
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop, 'interface', next_hop_options['interface'])
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop, 'distance', next_hop_options['distance'])
                        elif 'interface' in next_hop_options:
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop, 'interface', next_hop_options['interface'])
                        elif 'distance' in next_hop_options and is_str_not_empty(next_hop_options['distance']):
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop, 'distance', next_hop_options['distance'])
                        else:
                            self.generate(*subnet_cmd_prefix, 'next-hop', next_hop)
                else:
                    for next_hop, next_hop_options in next_hops.items():
                        self.generate(*subnet_cmd_prefix, 'next-hop', next_hop)

            # Clean up empty routes:
            # If deleted dict is equal to the current dict, then delete the entire subnet
            if self.operator == 'delete':
                if route_options == current_config[subnet]:
                    self.generate(*subnet_cmd_prefix, 'all')

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """
        Generate VyOS commands for routing configuration
        
        Input format (new nested structure):
        {
            '0.0.0.0/0': {
                'blackhole': {'distance': '100'},
                'dhcp-interface': ['eth2', 'br1'],
                'interface': {
                    'br1': {'distance': '120'},
                    'eth2': {'distance': '50'}
                },
                'next-hop': {
                    '10.10.0.1': {},
                    '8.8.8.8': {
                        'distance': '200',
                        'interface': 'eth2'
                    }
                }
            },
            '255.255.255.0/24': {'blackhole': {'distance': '1'}}
        }
        
        """
        try:
            if not data:
                return []
                
            self._process_nested_routes(data, current_config, new_config)                
            return self.cmds

        except Exception as e:
            print(f"Error generating routing commands: {e}")
            return []


if __name__ == "__main__":
    new_test_data = {
        '0.0.0.0/0': {
            'blackhole': {'distance': '100'},
            'dhcp-interface': ['eth2', 'br1'],
            'interface': {
                'br1': {'distance': '120'},
                'eth2': {'distance': '50'}
            },
            'next-hop': {
                '10.10.0.1': {},
                '8.8.8.8': {
                    'distance': '200',
                    'interface': 'eth2'
                }
            }
        },
        '255.255.255.0/24': {'blackhole': {'distance': '1'}}
    }
    cmd = RoutingCommand(operator='set', resource='ipv4')
    cmd.generate_commands(new_test_data, None, None)
