from app.core.models import Interface
from app.core.operation.wifi.models import WiFiInterfaceConfig
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig
from app.core.operation.wireguard.models import WireguardInterfaceConfig
from app.core.operation.ethernet.models import EthernetInterfaceConfig
from app.core.operation.bridge.models import BridgeInterfaceConfig
from app.config import global_config
from celery import shared_task
from time import sleep
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.log.logger import logger
from datetime import datetime, timedelta
import pprint

def fetch_interface_opr(app_context):
    try:
        logger.debug("[TASK] Fetch Interfaces")
        refresh_db_interface_operation(app_context=app_context)
    except Exception as e:
        logger.error('Error fetch interface', str(e))


def refresh_db_interface_operation(app_context=None):
    try:
        interfaces = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE)
        interfaces_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
        
        # logger.debug("Interface Graphql data: ")
        # logger.debug(interfaces)
        
        # Check the result of GraphQL API:
        # - If failed, don't update table and add a scheduled task "fetch_interfaces_operation_5s" to retry within 5 seconds
        # - If success, update table and remove the scheduled task        
        retry_job_id = 'fetch_interfaces_operation_5s'
        if isinstance(interfaces, Exception) or \
            'ShowInterfaces' not in interfaces or 'data' not in interfaces['ShowInterfaces'] or \
                'result' not in interfaces['ShowInterfaces']['data'] or \
                    len(interfaces['ShowInterfaces']['data']['result']) == 0:
            logger.debug("GraphQL API returned empty or invalid interface data, scheduling retry in 5 seconds")
            
            scheduler = global_config.app_scheduler
            
            if scheduler and scheduler.get_job(id=retry_job_id) is None:
                run_time = datetime.now() + timedelta(seconds=5)
                
                scheduler.add_job(
                    id=retry_job_id,
                    func=fetch_interface_opr,
                    args=[app_context],
                    trigger="date",
                    run_date=run_time,
                    misfire_grace_time=10,
                    coalesce=True,
                    max_instances=1
                )
                logger.debug(f"Scheduled retry job '{retry_job_id}' to run at {run_time}")
            
            return None
        
        # Valid data received - remove retry job if it exists
        scheduler = global_config.app_scheduler
        if scheduler and scheduler.get_job(id=retry_job_id) is not None:
            scheduler.remove_job(retry_job_id)
            logger.debug(f"Removed retry job '{retry_job_id}' as valid data was received")
        
        if app_context is not None:
            with app_context:
                Interface.refresh(interfaces, interfaces_config)
                WiFiInterfaceConfig.refresh(interfaces, interfaces_config, "api")
                if interfaces_config.json()['data'].get('ethernet', None):
                    EthernetInterfaceConfig.refresh(
                        interfaces_config.json()['data']['ethernet'],
                        app_context,
                        interfaces_config.json()['data'].get('bridge', {})
                    )
                BridgeInterfaceConfig.refresh(
                    interfaces_config.json()['data'].get('bridge', {}),
                    app_context
                )
                if interfaces_config.json()['data'].get('openvpn', None):
                    OpenVPNInterfaceConfig.refresh(interfaces_config.json()['data']['openvpn'])
                if interfaces_config.json()['data'].get('wireguard', None):
                    WireguardInterfaceConfig.refresh(interfaces_config.json()['data']['wireguard'])
        else:
            Interface.refresh(interfaces, interfaces_config)
            WiFiInterfaceConfig.refresh(interfaces, interfaces_config, "api")
            if interfaces_config.json()['data'].get('ethernet', None):
                EthernetInterfaceConfig.refresh(
                    interfaces_config.json()['data']['ethernet'],
                    bridge_config=interfaces_config.json()['data'].get('bridge', {})
                )
            BridgeInterfaceConfig.refresh(
                interfaces_config.json()['data'].get('bridge', {})
            )
            if interfaces_config.json()['data'].get('openvpn', None):
                OpenVPNInterfaceConfig.refresh(interfaces_config.json()['data']['openvpn'])
            if interfaces_config.json()['data'].get('wireguard', None):
                WireguardInterfaceConfig.refresh(interfaces_config.json()['data']['wireguard'])
        return interfaces
    except Exception as e:
        logger.error("Exception", str(e))
        return []
    

@shared_task(ignore_result=False)
def long_running_task():
    logger.debug('Task started')
    try:
        sleep(10)
        logger.debug('Task completed')
        return 'Task completed'
    except Exception as e:
        logger.debug(f"Task failed: {e}")
        return str(e)
