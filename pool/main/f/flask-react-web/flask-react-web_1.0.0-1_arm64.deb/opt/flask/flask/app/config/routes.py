from flask import Blueprint, jsonify, current_app
from .models import Page, SubPage, Feature, SubPageFeature
from . import config_bp

@config_bp.route('/pages', methods=['GET'])
def get_pages():
    pages = Page.query.all()
    pages_data = []

    sub_page_features = SubPageFeature.query.all()
    features_by_sub_page = {}
    for feature in sub_page_features:
        features_by_sub_page.setdefault(feature.sub_page_id, []).append({
            'id': feature.feature_id,
            'name': feature.feature_name,
            'enabled': feature.enabled
        })

    for page in pages:
        page_info = {
            'page_id': page.page_id,
            'page_name': page.page_name,
            'page_url': page.page_url,
            'enabled': page.enabled,
            'sub_pages': [
                {
                    'id': sub_page.sub_page_id,
                    'name': sub_page.sub_page_name,
                    'url': sub_page.sub_page_url,
                    'enabled': sub_page.enabled,
                    'features': features_by_sub_page.get(sub_page.sub_page_id, [])
                } for sub_page in page.sub_pages
            ]
        }
        pages_data.append(page_info)
    
    return jsonify(pages_data)

@config_bp.route('/features', methods=['GET'])
def get_features():
    features = Feature.query.all()
    features_data = [
        {
            'feature_id': feature.feature_id,
            'feature_name': feature.feature_name,
            'enabled': feature.enabled
        } for feature in features
    ]
    
    return jsonify(features_data)

@config_bp.route('/scheduler/state', methods=['GET'])
def get_scheduler_state():
    scheduler_wrapper = (current_app.extensions or {}).get('app_scheduler')
    if scheduler_wrapper is None:
        return jsonify({'error': 'scheduler_not_initialized'}), 503

    scheduler = getattr(scheduler_wrapper, 'scheduler', scheduler_wrapper)

    jobs_out = []
    try:
        jobs = scheduler.get_jobs() if scheduler is not None else []
        for j in jobs:
            trigger = getattr(j, 'trigger', None)
            interval = getattr(trigger, 'interval', None)
            interval_s = int(interval.total_seconds()) if interval is not None else None
            next_run_time = getattr(j, 'next_run_time', None)
            jobs_out.append(
                {
                    'id': getattr(j, 'id', None),
                    'name': getattr(j, 'name', None),
                    'trigger': str(trigger) if trigger is not None else None,
                    'interval_s': interval_s,
                    'next_run_time': next_run_time.isoformat() if next_run_time is not None else None,
                }
            )
    except Exception as e:
        return jsonify({'error': 'failed_to_read_scheduler_state', 'detail': str(e)}), 500

    return jsonify({'jobs': jobs_out, 'count': len(jobs_out)})