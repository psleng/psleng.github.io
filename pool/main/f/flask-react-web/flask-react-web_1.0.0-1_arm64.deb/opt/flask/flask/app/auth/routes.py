from . import auth_bp
from flask import jsonify, request, session, Response, current_app, redirect
from functools import partial, wraps
from .models import User, TempUserExpiryTime
from .utils import login_required
from .web_sessions import start_web_session, revoke_web_session, list_web_sessions, clear_web_session
import pam
import math
import os
import pexpect
import paramiko
from app.core.utils.check_os import is_linux
from app.socket.socket_manager import socket_manager
from app.auth.pam.otp_store import otp_store
from app.auth.pam.pam_authenticator import (
    public_authentication_failure,
    send_socket_otp,
)
from app.log.logger import logger
from datetime import datetime, timedelta, timezone
import pytz
from app.db.database import db
from app.core.operation.models import UserManagement
from app.auth.pam.executor import (
    PamAuthenticationBusyError,
    PamAuthenticationTimeoutError,
    run_pam_authentication,
)

tzone_str = "America/Toronto"
tzone = pytz.timezone(tzone_str)

from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET


def authenticate_db(username, password):
    logger.debug(f"Attempting to authenticate user: {username}")
    user = User.query.filter_by(email=username).first()
    if user and user.check_password(password):
        logger.debug(f"User '{username}' found and password verified.")
        expiry_time = TempUserExpiryTime.get_user_expiry(username)
        if expiry_time:
            logger.debug(
                f"Found custom expiry time for user '{username}': {expiry_time}"
            )
            now = datetime.now(tzone)

            if expiry_time.tzinfo is None:
                expiry_time = tzone.localize(expiry_time)

            if expiry_time > now:
                session.permanent = True
                session["user_id"] = user.id
                session["username"] = user.email
                session["expires_at"] = expiry_time.isoformat()
                # current_app.permanent_session_lifetime = expiry_time - now
                logger.debug(
                    f"Session for '{username}' created with custom expiry: {session['expires_at']}"
                )
                return True
            else:
                logger.debug(f"Custom expiry time for user '{username}' has passed.")
                return False
        else:
            logger.debug(
                f"No custom expiry time found for user '{username}'. Setting default 8-hour session."
            )
            session.permanent = True
            session["user_id"] = user.id
            session["username"] = user.email
            expires_at = datetime.now(tzone) + timedelta(hours=8)
            session["expires_at"] = expires_at.isoformat()
            # current_app.permanent_session_lifetime = timedelta(hours=8)
            logger.debug(
                f"Session for '{username}' created with default expiry: {session['expires_at']}"
            )
            return True
    else:
        logger.debug(
            f"Authentication failed for user: {username}. User not found or password incorrect."
        )
    return False


def authenticate_ssh(username, password):
    pam_authenticator = pam.pam()

    if pam_authenticator.authenticate(username=username, password=password):
        session["user_id"] = "ssh_" + username
        session["username"] = username
        return True
    return False


def is_user_in_group(username, groupname):
    """Checks if a user is a member of a specific group.

    Args:
        username (str): The username to check.
        groupname (str): The group name to check for membership.

    Returns:
        bool: True if the user is a member of the group, False otherwise.
    """
    import pwd
    import grp

    try:
        gid = pwd.getpwnam(username).pw_gid
        group_id_list = os.getgrouplist(username, gid)
        user_groups = [grp.getgrgid(g).gr_name for g in group_id_list]
        return groupname in user_groups
    except KeyError:
        return False


def check_permission(username):
    # Check if the user is not in the 'vyattacfg' group
    if not is_user_in_group(username, "vyattacfg"):
        session["permission"] = "operator"
        db_permission = UserManagement.get_user_permission(username)
        if db_permission:
            session["permission"] = db_permission
    else:
        session["permission"] = "administrator"


def get_server_auth_methods(username):
    """Check available authentication methods for a user on the local SSH server."""
    transport = None
    try:
        transport = paramiko.Transport(("localhost", 22))
        transport.start_client()
        return transport.get_banner(), transport.auth_handler.get_allowed_auths(
            username
        )
    except paramiko.SSHException as e:
        logger.error(f"SSH connection error when checking auth methods: {e}")
        return None, []
    finally:
        if transport:
            transport.close()


def login_mfa_paramiko(username, password, request_id):
    logger.debug(f"Starting MFA login for user: {username}")
    client = None
    try:
        if not all([username, password]):
            logger.debug("Username or password not provided.")
            return jsonify({"message": "Username and password are required."}), 400

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Use a custom handler for interactive authentication
        def auth_handler(title, instructions, prompt_list):
            resp = []
            for pr in prompt_list:
                prompt = pr[0].strip()
                if "password" in prompt.lower():
                    resp.append(password)
                elif "otp" in prompt.lower():
                    logger.debug("OTP prompt received. Requesting OTP from client.")
                    socket_manager.emit_to_guest(
                        ssid=request_id,
                        event="clientRequest",
                        data={
                            "action": "login-mfa-password",
                            "ssid": request_id,
                            "data": prompt,
                        },
                    )

                    event = otp_store.request_otp(request_id)
                    logger.debug("Waiting for OTP from client.")
                    is_otp_received = event.wait(timeout=60.0)

                    if not is_otp_received:
                        logger.debug("OTP submission timed out.")
                        raise Exception("OTP submission timed out.")

                    otp = otp_store.get_otp(request_id)
                    if not otp:
                        logger.debug("Failed to retrieve submitted OTP.")
                        raise Exception("Failed to retrieve submitted OTP.")

                    logger.debug("OTP received. Sending OTP to process.")
                    resp.append(otp)
                else:
                    resp.append("")
            return tuple(resp)

        try:
            # If no MFA is required, let users pass
            client.connect(
                "localhost",
                username=username,
                password=password,
                auth_timeout=15,
                allow_agent=False,
                look_for_keys=False,
            )
            logger.debug("Password authentication successful. No MFA required.")

        except paramiko.AuthenticationException:
            logger.debug("Password auth failed. Trying keyboard-interactive for MFA.")
            # If password auth fails, it might be because MFA is needed.
            # transport object for the interactive auth.
            try:
                transport = paramiko.Transport(("localhost", 22))
                transport.start_client()
                transport.auth_interactive(username, auth_handler)

                # If successful, create a client from the transport
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client._transport = transport
            except paramiko.AuthenticationException as e:
                logger.debug(f"Interactive authentication failed: {e}")
                return jsonify({"message": "Invalid credentials or OTP."}), 401
            except Exception as e:
                logger.error(
                    f"An error occurred during interactive authentication: {e}"
                )
                return jsonify({"message": str(e)}), 500

        except Exception as e:
            logger.error(f"An unexpected error occurred during connection: {e}")
            return (
                jsonify({"message": "An unexpected error occurred.", "error": str(e)}),
                500,
            )

        if client.get_transport() and client.get_transport().is_authenticated():
            logger.debug("Authentication successful.")
            check_permission(username)
            session["user_id"] = f"ssh_{username}"
            session["username"] = username
            return jsonify({"message": "Login successful."}), 200
        else:
            logger.debug("Authentication failed.")
            return jsonify({"message": "Invalid username or password."}), 401

    except paramiko.AuthenticationException:
        logger.debug("Authentication failed.")
        return jsonify({"message": "Invalid username or password."}), 401
    except Exception as e:
        logger.debug(f"An unexpected error occurred in login_mfa_paramiko: {e}")
        return (
            jsonify(
                {
                    "message": "An unexpected error occurred during the login process.",
                    "error": str(e),
                }
            ),
            500,
        )
    finally:
        if client:
            client.close()


def login_pam(username, password, request_id):
    log_context = f"user={username!r}, request_id={request_id!r}"
    logger.debug(
        f"[login_pam] Entered PAM login ({log_context}, "
        f"password_provided={bool(password)})"
    )

    def check_permission_pam(privilege_level):
        operator_plus_privlvl_threshold = 5
        admin_privlvl_threshold = 10
        logger.debug(
            f"[login_pam] Mapping PAM privilege to application permission "
            f"({log_context}, privilege_level={privilege_level}, "
            f"operator_plus_threshold={operator_plus_privlvl_threshold}, "
            f"admin_threshold={admin_privlvl_threshold})"
        )

        if privilege_level >= admin_privlvl_threshold:
            session["permission"] = "administrator"
            logger.debug(
                f"[login_pam] Selected administrator permission ({log_context})"
            )
        elif privilege_level >= operator_plus_privlvl_threshold:
            session["permission"] = "operator+"
            logger.debug(
                f"[login_pam] Selected operator+ permission ({log_context})"
            )
        else:
            session["permission"] = "operator"
            logger.debug(
                f"[login_pam] Selected operator permission ({log_context})"
            )

    try:
        logger.debug(f"[login_pam] Reading PAM executor configuration ({log_context})")
        timeout_seconds = current_app.config.get(
            "PAM_AUTH_TIMEOUT_SECONDS",
            os.environ.get("PAM_AUTH_TIMEOUT_SECONDS", 90),
        )
        max_workers = current_app.config.get(
            "PAM_AUTH_MAX_PROCESSES",
            os.environ.get(
                "PAM_AUTH_MAX_PROCESSES",
                current_app.config.get(
                    "PAM_AUTH_MAX_THREADS",
                    os.environ.get("PAM_AUTH_MAX_THREADS", 100),
                ),
            ),
        )
        logger.debug(
            f"[login_pam] PAM executor configuration resolved ({log_context}, "
            f"timeout_seconds={timeout_seconds!r}, max_processes={max_workers!r})"
        )
        logger.debug(
            f"[login_pam] Creating OTP callback and starting isolated PAM "
            f"authentication ({log_context})"
        )

        def trace_pam_executor(message):
            logger.debug(f"[run_pam_authentication] {message}")

        result = run_pam_authentication(
            username,
            password,
            request_id,
            partial(
                send_socket_otp,
                otp_store=otp_store,
                otp_store_request_id=request_id,
                socket_manager=socket_manager,
            ),
            timeout_seconds=timeout_seconds,
            max_workers=max_workers,
            trace_callback=trace_pam_executor,
        )
        logger.debug(
            f"[login_pam] PAM executor returned ({log_context}, "
            f"result_type={type(result).__name__}, "
            f"result_keys={sorted(result.keys()) if isinstance(result, dict) else 'n/a'})"
        )
        authentication_succeeded = result["success"]
        logger.debug(
            f"[login_pam] Evaluating PAM result ({log_context}, "
            f"success={authentication_succeeded})"
        )
        if authentication_succeeded:
            privilege_level = result.get("privilege_level")

            logger.debug(
                f"[login_pam] PAM authentication succeeded ({log_context}, "
                f"privilege_level={privilege_level!r})"
            )

            session["user_id"] = f"pam_{username}"
            session["username"] = username
            logger.debug(
                f"[login_pam] Initialized authenticated session identity "
                f"({log_context}, user_id={session['user_id']!r})"
            )
            # Set local user to admin if privilege level is not valid
            if not isinstance(privilege_level, int) or int(privilege_level) < 1:
                logger.debug(
                    f"[login_pam] PAM privilege is missing or invalid; starting "
                    f"database permission fallback ({log_context}, "
                    f"privilege_level={privilege_level!r})"
                )
                session["permission"] = "administrator"
                logger.debug(
                    f"[login_pam] Applied administrator fallback before database "
                    f"lookup ({log_context})"
                )
                db_permission = UserManagement.get_user_permission(username)
                logger.debug(
                    f"[login_pam] Database permission lookup completed "
                    f"({log_context}, db_permission={db_permission!r})"
                )
                if db_permission:
                    session["permission"] = db_permission
                    logger.debug(
                        f"[login_pam] Replaced fallback with database permission "
                        f"({log_context}, permission={db_permission!r})"
                    )
                else:
                    logger.debug(
                        f"[login_pam] No database permission found; retaining "
                        f"administrator fallback ({log_context})"
                    )
                logger.debug(
                    f"[login_pam] Permission fallback completed ({log_context}, "
                    f"final_permission={session.get('permission')!r})"
                )
            else:
                logger.debug(
                    f"[login_pam] Using valid PAM privilege for permission mapping "
                    f"({log_context}, privilege_level={privilege_level})"
                )
                check_permission_pam(privilege_level)

            logger.debug(
                f"[login_pam] Returning successful login response ({log_context}, "
                f"permission={session.get('permission')!r}, status=200)"
            )
            return jsonify({"message": "Login successful"}), 200
        else:
            failure_reason, failure_code = public_authentication_failure(
                result.get("reason")
            )
            logger.error(
                f"[login_pam] PAM authentication rejected ({log_context}, "
                f"reason={failure_reason!r}, code={failure_code!r}, status=401)"
            )
            return jsonify({"message": failure_reason, "code": failure_code}), 401

    except PamAuthenticationTimeoutError as e:
        logger.error(
            f"[login_pam] PAM authentication timed out ({log_context}, "
            f"error={e!r}, status=504)"
        )
        return jsonify({"message": "Authentication timed out. Please try again."}), 504
    except PamAuthenticationBusyError as e:
        logger.error(
            f"[login_pam] PAM authentication capacity is unavailable "
            f"({log_context}, error={e!r})"
        )
        retry_after_seconds = max(1, math.ceil(float(timeout_seconds)))
        logger.debug(
            f"[login_pam] Built busy response retry interval ({log_context}, "
            f"retry_after_seconds={retry_after_seconds})"
        )
        response = jsonify(
            {
                "message": (
                    "Authentication service is busy. "
                    f"Try again in {retry_after_seconds} seconds."
                ),
                "code": "authentication_busy",
                "retry_after_seconds": retry_after_seconds,
            }
        )
        response.headers["Retry-After"] = str(retry_after_seconds)
        logger.debug(
            f"[login_pam] Returning busy response ({log_context}, status=503, "
            f"retry_after_seconds={retry_after_seconds})"
        )
        return response, 503
    except Exception as e:
        logger.exception(
            f"[login_pam] PAM authentication failed unexpectedly "
            f"({log_context}, error_type={type(e).__name__})"
        )
        return (
            jsonify(
                {
                    "message": "Authentication service error.",
                    "error_type": type(e).__name__,
                }
            ),
            500,
        )


def login_mfa(username, password, request_id):
    logger.debug(f"Starting MFA login for user: {username}")
    child = None
    try:
        if not all([username, password]):
            logger.debug("Username or password not provided.")
            return jsonify({"message": "Username and password are required."}), 400

        logger.debug(f"Spawning sudo login for {username}")
        child = pexpect.spawn(f"sudo login {username}", timeout=20, encoding="utf-8")

        logger.debug("Expecting password prompt.")
        i = child.expect(["Password:", pexpect.EOF, pexpect.TIMEOUT])
        if i != 0:
            logger.debug(
                f"Failed to get password prompt. Index: {i}, Output: {child.before}"
            )
            return (
                jsonify(
                    {
                        "message": "Failed to get password prompt from server.",
                        "output": child.before,
                    }
                ),
                401,
            )

        logger.debug("Password prompt received. Sending password.")
        child.sendline(password)

        otp_prompt_regex = r".*OTP.*"
        welcome_regex = r".*Welcome to.*"

        logger.debug("Expecting OTP, Welcome message, or failure.")
        i = child.expect(
            [
                otp_prompt_regex,
                "Authentication failure",
                welcome_regex,
                pexpect.EOF,
                pexpect.TIMEOUT,
            ]
        )
        logger.debug(f"Received index: {i}. Output: {child.before}")

        if i == 1:
            logger.debug("Authentication failure after password.")
            return jsonify({"message": "Invalid username or password."}), 401
        if i == 2:
            logger.debug("Welcome message received. Login successful.")
            check_permission(username)
            session["user_id"] = f"ssh_{username}"
            session["username"] = username
            return jsonify({"message": "Login successful."})
        if i == 0:  # OTP prompt
            logger.debug("OTP prompt received. Requesting OTP from client.")
            socket_manager.emit_to_guest(
                ssid=request_id,
                event="clientRequest",
                data={
                    "action": "login-mfa-password",
                    "ssid": request_id,
                    "data": child.before.strip() + child.after.strip(),
                },
            )

            event = otp_store.request_otp(request_id)
            logger.debug("Waiting for OTP from client.")
            is_otp_received = event.wait(timeout=60.0)

            if not is_otp_received:
                logger.debug("OTP submission timed out.")
                child.close()
                return (
                    jsonify(
                        {
                            "message": "OTP submission timed out.",
                            "output": child.before,
                        }
                    ),
                    408,
                )

            otp = otp_store.get_otp(request_id)
            if not otp:
                logger.debug("Failed to retrieve submitted OTP.")
                child.close()
                return (
                    jsonify(
                        {
                            "message": "Failed to retrieve submitted OTP.",
                            "output": child.before,
                        }
                    ),
                    500,
                )

            logger.debug("OTP received. Sending OTP to process.")
            child.sendline(otp)

            child.sendline("whoami")
            whoami_index = child.expect([username, pexpect.EOF, pexpect.TIMEOUT])

            if whoami_index == 0:
                logger.debug(f"whoami command successful. User: {child.before.strip()}")
                session["user_id"] = f"ssh_{username}"
                session["username"] = username
                check_permission(username)
                child.sendline("exit")
                if not child.closed:
                    logger.debug("Closing child process.")
                    child.close()
                return jsonify({"message": "Login successful"}), 200
            else:
                logger.error(
                    f"whoami command failed. Expected {username} but got something else."
                )
                child.close()
                return jsonify({"message": "Login verification failed."}), 401
        else:  # Timeout or other error
            logger.debug("Unexpected response after password.")
            return (
                jsonify(
                    {
                        "message": "Server did not request an OTP.",
                        "output": child.before,
                    }
                ),
                401,
            )

    except Exception as e:
        logger.debug(f"An unexpected error occurred in login_mfa: {e}")
        if child and not child.closed:
            child.close()
        return (
            jsonify(
                {
                    "message": "An unexpected error occurred during the login process.",
                    "error": str(e),
                }
            ),
            500,
        )


# Login Route
@auth_bp.after_request
def track_successful_login(response):
    if response.status_code < 300 and session.get("user_id"):
        if request.endpoint.rsplit(".", 1)[-1] == "login":
            source = "pam" if str(session["user_id"]).startswith("pam_") else "local"
            start_web_session(source)
        elif request.endpoint.rsplit(".", 1)[-1] == "saml_validate":
            start_web_session("saml")
    return response


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"message": "A JSON request body is required."}), 400

    missing_fields = [
        field for field in ("username", "password", "ssid") if field not in data
    ]
    if missing_fields:
        return (
            jsonify(
                {
                    "message": "Missing required login fields.",
                    "fields": missing_fields,
                }
            ),
            400,
        )

    username = data["username"]
    password = data["password"]
    request_id = data["ssid"]

    try:
        if authenticate_db(username, password):
            session["permission"] = "administrator"
            db_permission = UserManagement.get_user_permission(username)
            if db_permission:
                session["permission"] = db_permission
            return jsonify({"message": "Login successful"}), 200
        # elif is_linux() and authenticate_ssh(username, password):
        #     session['username'] = username
        #     check_permission(username)

        #     return jsonify({'message': 'Login successful'}), 200
        elif is_linux():
            if not isinstance(request_id, str) or not request_id.strip():
                logger.warning(
                    f"[login] Rejecting PAM authentication without a socket "
                    f"session ID (user={username!r})"
                )
                return (
                    jsonify(
                        {
                            "message": (
                                "Login session is not ready. "
                                "Please wait for the connection and try again."
                            ),
                            "code": "login_session_not_ready",
                        }
                    ),
                    400,
                )
            request_id = request_id.strip()
            logger.debug(
                f"[login] Releasing database session before PAM authentication "
                f"(user={username!r}, request_id={request_id!r})"
            )
            db.session.remove()
            logger.debug(
                f"[login] Database session released before PAM authentication "
                f"(user={username!r}, request_id={request_id!r})"
            )
            return login_pam(username, password, request_id)
        else:
            return jsonify({"message": "Invalid credentials"}), 401

    except pexpect.exceptions.ExceptionPexpect:
        logger.exception(f"PAM process error while logging in user {username}")
        return (
            jsonify({"message": "Authentication service error."}),
            500,
        )

    except Exception as e:
        logger.exception(f"Unexpected login error for user {username}")
        return (
            jsonify(
                {
                    "message": "Authentication service error.",
                    "error_type": type(e).__name__,
                }
            ),
            500,
        )


def authenticate_pam(username, password, service):
    pam_authenticator = pam.pam()
    return pam_authenticator.authenticate(
        username=username, password=password, service=service
    )


@auth_bp.route("/saml/enabled", methods=["GET"])
def saml_enabled():
    try:
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SAML)

        if isinstance(res, Exception):
            return jsonify({"enabled": False}), 200

        provider_name = res.get("provider", "")
        provider_enabled = bool(provider_name)

        return (
            jsonify({"name": provider_name, "icon": None, "enabled": provider_enabled}),
            200,
        )
    except Exception as e:
        logger.error(f"Error checking SAML config: {str(e)}")
        return jsonify({"enabled": False}), 200


@auth_bp.route("/saml/login", methods=["POST"])
def saml_login():
    """Initiate SAML login. Returns the IdP SSO URL for the frontend to redirect to."""
    try:
        data = request.get_json() or {}
        relay_state = data.get("relay_state", request.url_root.rstrip("/"))
        hostname = data.get("hostname", request.host.split(":")[0])

        res = api_manager.call(
            action=API_ACTION.AUTH,
            target=API_TARGET.SAML,
            data={
                "type": "AUTH",
                "RelayState": relay_state,
                "hostname": hostname,
            },
        )

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400

        session["saml_session_token"] = res.get("session")
        session["saml_secret"] = res.get("secret", "")

        return jsonify({"url": res.get("sso_url")}), 200
    except Exception as e:
        logger.error(f"SAML login error: {str(e)}")
        return jsonify({"error": str(e)}), 500


@auth_bp.route("/saml/validate", methods=["POST"])
def saml_validate():
    """Validate a SAML session after IdP redirect. Creates Flask session on success."""
    token = session.pop("saml_session_token", None)
    secret = session.pop("saml_secret", None)

    if not token or not secret:
        return jsonify({"error": "No pending SAML session"}), 400

    try:
        res = api_manager.call(
            action=API_ACTION.AUTH,
            target=API_TARGET.SAML,
            data={
                "type": "CHECK_AUTH",
                "session": token,
                "secret": secret,
            },
        )

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400

        if res.get("auth_status") == "SUCCESS":
            permission = res.get("auth_level", "")
            user_id = res.get("user_id", "")
            local_name = res.get("local_name", user_id)

            session["user_id"] = local_name.lower()
            level = permission.lower()
            if level == "admin":
                session["permission"] = "administrator"
            elif level == "super_operator":
                session["permission"] = "operator+"
            else:
                session["permission"] = "operator"
            session["username"] = local_name.lower()
            session.permanent = True
            expires_at = datetime.now(tzone) + timedelta(hours=8)
            session["expires_at"] = expires_at.isoformat()

            return jsonify({"success": True, "username": local_name}), 200
        else:
            return (
                jsonify(
                    {"error": "Authentication failed", "status": res.get("auth_status")}
                ),
                401,
            )
    except Exception as e:
        logger.error(f"SAML validate error: {str(e)}")
        return jsonify({"error": str(e)}), 500


# Logout Route
@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    try:
        revoke_web_session(session.get("web_session_id"))
        clear_web_session()
        return jsonify({"message": "Success"}), 200
    except Exception as e:
        return jsonify({"message": "Invalid request"}), 400


@auth_bp.route("/sessions", methods=["GET"])
@login_required
def get_web_sessions():
    return jsonify({"sessions": list_web_sessions()})


@auth_bp.route("/sessions/<session_id>", methods=["DELETE"])
@login_required
def disconnect_web_session(session_id):
    if session.get("permission") != "administrator":
        return jsonify({"message": "Administrator permission required."}), 403
    if session_id == session.get("web_session_id"):
        return jsonify({"message": "You cannot disconnect your current session."}), 403
    if not revoke_web_session(session_id):
        return jsonify({"message": "Session not found."}), 404
    return jsonify({"message": "User disconnected."})


@auth_bp.route("/register", methods=["POST"])
def register():
    try:
        data = request.get_json()
        username = data["username"]
        password = data["password"]

        if User.create_user(username, password):
            return jsonify({"message": "Success"}), 200
        return jsonify({"message": "User already existed"}), 400

    except Exception as e:
        return jsonify({"message": str(e)}), 400


@auth_bp.route("profile", methods=["GET"])
@login_required
def get_profile():
    logger.debug("Attempting to get user profile.")
    try:
        user_name = session["username"]
        permission = session["permission"]
        logger.debug(
            f"Retrieved from session: user='{user_name}', permission='{permission}'"
        )

        res = {"user": user_name, "permission": permission}
        logger.debug(f"Initial response object: {res}")

        user = User.is_exist(session["username"])
        if user:
            logger.debug(f"User '{user_name}' exists in the database.")
            user_expiry_time = TempUserExpiryTime.get_user_expiry(user_name)
            if user_expiry_time:
                logger.debug(
                    f"Found expiry time for user_id '{session['user_id']}': {user_expiry_time}"
                )
                res["expires_at"] = user_expiry_time.isoformat()
                res["timezone"] = tzone_str
            else:
                logger.debug(
                    f"No custom expiry time found for user_id '{session['user_id']}'."
                )
        else:
            logger.debug(f"User '{user_name}' does not exist in the database.")

        logger.debug(f"Final response object: {res}")
        return jsonify(res), 200

    except Exception as e:
        logger.error(f"Error in get_profile: {str(e)}")
        print(str(e))
        return jsonify({"message": "Invalid request", "user": None}), 400
