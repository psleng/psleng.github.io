import json


class SoftwareManagementCommand:
    def __init__(self, operator):
        self.operator = operator
        self.commands = []
        self.vyos_commands = []
        self.enable_update_check = False

    def _add_command(self, path):
        self.commands.append(json.dumps({"op": self.operator, "path": path}))
        self.vyos_commands.append(" ".join([self.operator] + path))

    def generate_commands(self, data):
        if "auto-check" in data:
            self._add_command(["system", "update-check", "auto-check"])

        if "url" in data and self.enable_update_check:
            path = ["system", "update-check", "url"]
            if self.operator == "set":
                path.append(str(data["url"]))
            self._add_command(path)

        return self.commands

    def get_commands(self):
        return self.vyos_commands
