import json


class SoftwareManagementCommand:
    def __init__(self, operator):
        self.operator = operator
        self.commands = []
        self.vyos_commands = []

    def _add_command(self, path):
        self.commands.append(json.dumps({"op": self.operator, "path": path}))
        self.vyos_commands.append(" ".join([self.operator] + path))

    def generate_commands(self, data):
        if "disable" in data:
            self._add_command(["system", "update-check", "disable"])

        if "url" in data:
            path = ["system", "update-check", "url"]
            if self.operator == "set":
                path.append(str(data["url"]))
            self._add_command(path)

        return self.commands

    def get_commands(self):
        return self.vyos_commands
