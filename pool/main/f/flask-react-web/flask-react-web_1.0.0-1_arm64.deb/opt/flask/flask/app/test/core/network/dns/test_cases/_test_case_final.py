import pytest
import json 

test_final_1 = pytest.param(
    (
        {
            "parsed_input": {
                "json_input": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["198.51.100.0"]
                                }
                            }
                        }
                    }
                },
                "validated_input": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["198.51.100.0"]
                                }
                            }
                        }
                    }
                },
                "parsed_input": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["198.51.100.0"]
                                }
                            }
                        }
                    }
                },
                "current_config": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["203.0.113.0"]
                                }
                            }
                        }
                    }
                }
            },
            "diff_added": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0"]
                            }
                        }
                    }
                }
            },
            "diff_deleted": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["203.0.113.0"]
                            }
                        }
                    }
                }
            },
            "generate_config": {
                "set_cmds": [
                    "set service dns forwarding domain dns.example.com name-server 198.51.100.0"
                ],
                "delete_cmds": [
                    "delete service dns forwarding domain dns.example.com name-server 203.0.113.0"
                ]
            },
            "process_config": {
                "curr_config": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["203.0.113.0"]
                                }
                            }
                        }
                    }
                },
                "merged_set": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": ["198.51.100.0"]
                                }
                            }
                        }
                    }
                }
            },
            "verify": {
                "verify_result": True
            }
        }
    ),
    id="test_final_dns_1"
)


test_final = [
    test_final_1,
]
