from app.db.database import db
from sqlalchemy import Column, Integer, String, Text, Boolean, ForeignKey
import json
import logging

logger = logging.getLogger(__name__)


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return list(value.keys())
    return [value]


class SystemLoginOptions(db.Model):
    __tablename__ = "vyos_config_system_login_options"

    id = Column(Integer, primary_key=True)
    auth_type = Column(String(32), nullable=True)
    banner_pre_login = Column(Text, nullable=True)
    banner_post_login = Column(Text, nullable=True)
    max_login_session = Column(String(32), nullable=True)
    timeout = Column(String(32), nullable=True)

    login_config_json = Column(Text, nullable=True)

    def serialize(self):
        res = {}
        if self.login_config_json:
            try:
                res = json.loads(self.login_config_json)
            except Exception:
                res = {}

        if isinstance(res, dict):
            if isinstance(res.get("system"), dict) and isinstance(
                res.get("system", {}).get("login"), dict
            ):
                res = res.get("system", {}).get("login") or {}
            elif isinstance(res.get("login"), dict) and not any(
                k in res
                for k in [
                    "saml",
                    "radius",
                    "tacacs",
                    "user",
                    "banner",
                    "timeout",
                    "max-login-session",
                    "enhanced-policy",
                    "enhanced_policy",
                ]
            ):
                res = res.get("login") or {}

        users = []
        try:
            from app.core.operation.models import UserManagement
            from app.auth.models import User

            os_users = UserManagement.query.all()
            users += [UserManagement.serialize(u) for u in os_users]

            db_users = User.query.all()
            users += [User.serialize(u) for u in db_users]
        except Exception:
            users = []

        other_options = {}
        if isinstance(res, dict):
            if "banner" in res:
                other_options["banner"] = res.get("banner")

            max_sessions = None
            if "max-login-session" in res:
                max_sessions = res.get("max-login-session")
            elif "max-sessions" in res:
                max_sessions = res.get("max-sessions")
            elif "max_sessions" in res:
                max_sessions = res.get("max_sessions")
            if max_sessions is not None:
                other_options["max_sessions"] = max_sessions

            if "timeout" in res:
                other_options["timeout"] = res.get("timeout")

        # Enrich local users with SAML identity fields sourced from the raw
        # vyos login block (UserManagement doesn't persist these).
        raw_users = res.get("user") if isinstance(res, dict) else None
        if isinstance(raw_users, dict):

            def _norm(name):
                return str(name).strip().lower() if name is not None else ""

            auth_map = {}
            for uname, ucfg in raw_users.items():
                if not isinstance(ucfg, dict):
                    continue
                auth = ucfg.get("authentication") or {}
                if not isinstance(auth, dict):
                    continue
                entry = {}
                if "saml" in auth and auth.get("saml") not in (None, ""):
                    entry["saml_id"] = str(auth.get("saml"))
                if "saml-jit" in auth or "saml_jit" in auth:
                    entry["saml_jit"] = True
                public_keys = auth.get("public-keys")
                if isinstance(public_keys, dict):
                    entry["public_keys"] = [
                        {
                            "name": str(key_name),
                            "key": str(key_config.get("key") or "") if isinstance(key_config, dict) else "",
                            "type": str(key_config.get("type") or "") if isinstance(key_config, dict) else "",
                        }
                        for key_name, key_config in public_keys.items()
                    ]
                if entry:
                    auth_map[_norm(uname)] = entry
            for u in users:
                extra = auth_map.get(_norm(u.get("user_name")))
                if extra:
                    u.update(extra)

        return {
            "saml": res.get("saml") if isinstance(res, dict) else None,
            "radius": res.get("radius") if isinstance(res, dict) else None,
            "tacacs": res.get("tacacs") if isinstance(res, dict) else None,
            "local_users": users,
            "other_options": other_options,
        }

    @classmethod
    def get_password_policy(cls):
        from app.core.operation.password_policy import parse_password_policy

        latest = (
            cls.query.filter(cls.login_config_json.isnot(None))
            .filter(cls.login_config_json != "")
            .order_by(cls.id.desc())
            .first()
        )
        config = json.loads(latest.login_config_json) if latest else {}
        return parse_password_policy(config)

    @classmethod
    def _truncate_all(cls):
        from sqlalchemy import text

        tables = [
            RadiusServer.__tablename__,
            RadiusConfig.__tablename__,
            TacacsServer.__tablename__,
            TacacsConfig.__tablename__,
            SamlRoleAttribute.__tablename__,
            SamlRoleUser.__tablename__,
            SamlConfig.__tablename__,
            LocalUserPublicKey.__tablename__,
            LocalUserPrincipal.__tablename__,
            LocalUser.__tablename__,
            cls.__tablename__,
        ]

        for t in tables:
            db.session.execute(text(f"DELETE FROM {t}"))
        db.session.commit()

    @classmethod
    def refresh(cls, login_cfg):
        try:
            cls._truncate_all()

            if not isinstance(login_cfg, dict):
                return

            if isinstance(login_cfg.get("system"), dict) and isinstance(
                login_cfg.get("system", {}).get("login"), dict
            ):
                login_cfg = login_cfg.get("system", {}).get("login") or {}

            logger.debug(
                "SystemLoginOptions.refresh input keys: %s",
                (
                    list(login_cfg.keys())
                    if isinstance(login_cfg, dict)
                    else type(login_cfg)
                ),
            )
            if isinstance(login_cfg, dict):
                logger.debug(
                    "SystemLoginOptions.refresh has radius=%s saml=%s tacacs=%s",
                    "radius" in login_cfg,
                    "saml" in login_cfg,
                    "tacacs" in login_cfg,
                )

            if (
                "login" in login_cfg
                and isinstance(login_cfg.get("login"), dict)
                and not any(
                    k in login_cfg
                    for k in [
                        "saml",
                        "radius",
                        "tacacs",
                        "user",
                        "banner",
                        "timeout",
                        "max-login-session",
                        "enhanced-policy",
                        "enhanced_policy",
                    ]
                )
            ):
                login_cfg = login_cfg.get("login") or {}

            opt = cls()

            if "saml" in login_cfg:
                opt.auth_type = "saml"
            elif "radius" in login_cfg:
                opt.auth_type = "radius"
            elif "tacacs" in login_cfg:
                opt.auth_type = "tacacs"

            banner = login_cfg.get("banner")
            if isinstance(banner, dict):
                opt.banner_pre_login = banner.get("pre-login")
                opt.banner_post_login = banner.get("post-login")
            elif banner is not None:
                opt.banner_pre_login = str(banner)

            if "max-login-session" in login_cfg:
                opt.max_login_session = str(login_cfg.get("max-login-session"))
            if "timeout" in login_cfg:
                opt.timeout = str(login_cfg.get("timeout"))

            opt.login_config_json = json.dumps(login_cfg)

            db.session.add(opt)
            db.session.flush()

            logger.debug(
                "SystemLoginOptions.refresh created options row id=%s auth_type=%s",
                opt.id,
                opt.auth_type,
            )

            # Radius
            radius = login_cfg.get("radius")
            if isinstance(radius, dict):
                r = RadiusConfig()
                r.system_login_options_id = opt.id
                r.security_mode = radius.get("security-mode")
                src = _as_list(radius.get("source-address"))
                r.source_addresses = json.dumps([str(x) for x in src]) if src else None
                db.session.add(r)
                db.session.flush()

                servers = radius.get("server")
                if isinstance(servers, dict):
                    for addr, s_cfg in servers.items():
                        rs = RadiusServer()
                        rs.system_login_options_id = opt.id
                        rs.radius_config_id = r.id
                        rs.address = str(addr)
                        if isinstance(s_cfg, dict):
                            rs.disable = (
                                "disable" in s_cfg or s_cfg.get("disable") is True
                            )
                            rs.key = s_cfg.get("key")
                            if "port" in s_cfg:
                                rs.port = str(s_cfg.get("port"))
                            if "priority" in s_cfg:
                                rs.priority = str(s_cfg.get("priority"))
                            if "timeout" in s_cfg:
                                rs.timeout = str(s_cfg.get("timeout"))
                        db.session.add(rs)

            # Tacacs
            tacacs = login_cfg.get("tacacs")
            if isinstance(tacacs, dict):
                t = TacacsConfig()
                t.system_login_options_id = opt.id
                t.security_mode = tacacs.get("security-mode")
                src = _as_list(tacacs.get("source-address"))
                t.source_addresses = json.dumps([str(x) for x in src]) if src else None
                if "timeout" in tacacs:
                    t.timeout = str(tacacs.get("timeout"))
                db.session.add(t)
                db.session.flush()

                servers = tacacs.get("server")
                if isinstance(servers, dict):
                    for addr, s_cfg in servers.items():
                        ts = TacacsServer()
                        ts.system_login_options_id = opt.id
                        ts.tacacs_config_id = t.id
                        ts.address = str(addr)
                        if isinstance(s_cfg, dict):
                            ts.disable = (
                                "disable" in s_cfg or s_cfg.get("disable") is True
                            )
                            ts.key = s_cfg.get("key")
                            if "port" in s_cfg:
                                ts.port = str(s_cfg.get("port"))
                        db.session.add(ts)

            # SAML
            saml = login_cfg.get("saml")
            if isinstance(saml, dict):
                s = SamlConfig()
                s.system_login_options_id = opt.id
                s.name = saml.get("name")
                s.metadata_url = saml.get("metadata-url")
                s.entity_id = saml.get("entityID") or saml.get("entity-id")
                s.default_sso_level = saml.get("default-sso-level")
                db.session.add(s)
                db.session.flush()

                for role in ["admin", "operator"]:
                    role_cfg = saml.get(role)
                    if not isinstance(role_cfg, dict):
                        continue

                    for kind in ["req", "suff"]:
                        attrs = role_cfg.get(kind)
                        if isinstance(attrs, dict):
                            for attr_name, attr_cfg in attrs.items():
                                if not isinstance(attr_cfg, dict):
                                    continue
                                for v in _as_list(attr_cfg.get("value")):
                                    a = SamlRoleAttribute()
                                    a.system_login_options_id = opt.id
                                    a.saml_config_id = s.id
                                    a.role = role
                                    a.kind = kind
                                    a.attribute = str(attr_name)
                                    a.value = str(v)
                                    db.session.add(a)

                    for u in _as_list(role_cfg.get("user")):
                        su = SamlRoleUser()
                        su.system_login_options_id = opt.id
                        su.saml_config_id = s.id
                        su.role = role
                        su.username = str(u)
                        db.session.add(su)

            # Local users
            users = login_cfg.get("user")
            if isinstance(users, dict):
                for username, u_cfg in users.items():
                    lu = LocalUser()
                    lu.system_login_options_id = opt.id
                    lu.username = str(username)

                    if isinstance(u_cfg, dict):
                        lu.disable = "disable" in u_cfg or u_cfg.get("disable") is True
                        lu.full_name = u_cfg.get("full-name")
                        op = u_cfg.get("operator")
                        if isinstance(op, dict):
                            lu.operator_type = op.get("group")
                            if lu.operator_type is not None:
                                lu.operator_type = str(lu.operator_type)
                            else:
                                lu.operator_type = json.dumps(op)
                        elif op is not None:
                            lu.operator_type = str(op)

                        auth = u_cfg.get("authentication")
                        if isinstance(auth, dict):
                            lu.encrypted_password = auth.get("encrypted-password")
                            lu.plaintext_password = auth.get("plaintext-password")

                            for p in _as_list(auth.get("principal")):
                                pr = LocalUserPrincipal()
                                pr.system_login_options_id = opt.id
                                pr.username = lu.username
                                pr.principal = str(p)
                                db.session.add(pr)

                            pks = auth.get("public-keys")
                            if isinstance(pks, dict):
                                for key_name, pk_cfg in pks.items():
                                    pk = LocalUserPublicKey()
                                    pk.system_login_options_id = opt.id
                                    pk.username = lu.username
                                    pk.key_name = str(key_name)
                                    if isinstance(pk_cfg, dict):
                                        pk.key = pk_cfg.get("key")
                                        pk.type = pk_cfg.get("type")
                                    db.session.add(pk)

                    db.session.add(lu)

            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.exception("SystemLoginOptions.refresh failed: %s", str(e))


class RadiusConfig(db.Model):
    __tablename__ = "vyos_config_system_login_radius"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    security_mode = Column(String(32), nullable=True)
    source_addresses = Column(Text, nullable=True)  # json array


class RadiusServer(db.Model):
    __tablename__ = "vyos_config_system_login_radius_server"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    radius_config_id = Column(
        Integer, ForeignKey("vyos_config_system_login_radius.id"), nullable=False
    )
    address = Column(String(128), nullable=False)
    disable = Column(Boolean, default=False)
    key = Column(Text, nullable=True)
    port = Column(String(16), nullable=True)
    priority = Column(String(16), nullable=True)
    timeout = Column(String(16), nullable=True)


class TacacsConfig(db.Model):
    __tablename__ = "vyos_config_system_login_tacacs"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    security_mode = Column(String(32), nullable=True)
    source_addresses = Column(Text, nullable=True)  # json array
    timeout = Column(String(16), nullable=True)


class TacacsServer(db.Model):
    __tablename__ = "vyos_config_system_login_tacacs_server"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    tacacs_config_id = Column(
        Integer, ForeignKey("vyos_config_system_login_tacacs.id"), nullable=False
    )
    address = Column(String(128), nullable=False)
    disable = Column(Boolean, default=False)
    key = Column(Text, nullable=True)
    port = Column(String(16), nullable=True)


class SamlConfig(db.Model):
    __tablename__ = "vyos_config_system_login_saml"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    name = Column(String(255), nullable=True)
    metadata_url = Column(Text, nullable=True)
    entity_id = Column(Text, nullable=True)
    default_sso_level = Column(String(32), nullable=True)


class SamlRoleAttribute(db.Model):
    __tablename__ = "vyos_config_system_login_saml_role_attribute"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    saml_config_id = Column(
        Integer, ForeignKey("vyos_config_system_login_saml.id"), nullable=False
    )
    role = Column(String(32), nullable=False)  # admin/operator
    kind = Column(String(16), nullable=False)  # req/suff
    attribute = Column(String(255), nullable=False)
    value = Column(Text, nullable=False)


class SamlRoleUser(db.Model):
    __tablename__ = "vyos_config_system_login_saml_role_user"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    saml_config_id = Column(
        Integer, ForeignKey("vyos_config_system_login_saml.id"), nullable=False
    )
    role = Column(String(32), nullable=False)
    username = Column(String(255), nullable=False)


class LocalUser(db.Model):
    __tablename__ = "vyos_config_system_login_user"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    username = Column(String(255), nullable=False)
    disable = Column(Boolean, default=False)
    full_name = Column(Text, nullable=True)
    operator_type = Column(String(32), nullable=True)
    encrypted_password = Column(Text, nullable=True)
    plaintext_password = Column(Text, nullable=True)


class LocalUserPrincipal(db.Model):
    __tablename__ = "vyos_config_system_login_user_principal"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    username = Column(String(255), nullable=False)
    principal = Column(Text, nullable=False)


class LocalUserPublicKey(db.Model):
    __tablename__ = "vyos_config_system_login_user_public_key"

    id = Column(Integer, primary_key=True)
    system_login_options_id = Column(
        Integer, ForeignKey("vyos_config_system_login_options.id"), nullable=False
    )
    username = Column(String(255), nullable=False)
    key_name = Column(String(255), nullable=False)
    key = Column(Text, nullable=True)
    type = Column(String(64), nullable=True)
