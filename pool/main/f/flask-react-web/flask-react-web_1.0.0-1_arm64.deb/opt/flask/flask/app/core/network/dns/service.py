from app.core.api.http.cmd.command import SHOW_DNS, SHOW_NAME_SERVERS, SHOW_DNS_DYNAMIC
from app.core.api.http.http_request import Action
from app.core.network.dns.parser import parse_dns_config, parse_dns_dynamic, parse_dns_servers, parse_dns_forward
from app.core.network.dns.cmd.command_dns import DNSDynamicCommand, DNSForwardingCommand
from app.core.network.dns.cmd.command_nameserver import NameServerCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.core.network.dns.models import DNSNameServer, DNSForwarding, DNSForwardingIP, DNSForwardingHostname, DNSDynamicInterface, DNSDynamicHostGroup
from typing import Dict, Any
from app.socket.socket_manager import socket_manager
from app.log.logger import logger
import pprint
from flask import session
from uuid import uuid4


def build_dns_forwarding_validation_config(new_config):
    if new_config is None:
        return None

    config_data = new_config.model_dump() if hasattr(new_config, 'model_dump') else new_config
    if not config_data:
        return None

    command = DNSForwardingCommand(operator='set', resource='service')
    command.generate_commands(config_data, new_config=config_data)
    processed = process_commands(command.get_validation_commands())
    forwarding = processed.get('service', {}).get('dns', {}).get('forwarding', {})
    if not isinstance(forwarding, dict):
        forwarding = {}

    forwarding['system'] = {}
    return forwarding


def is_dns_forwarding_verification_success(result) -> bool:
    if result is None:
        return True

    lines = [line.strip() for line in str(result).splitlines() if line.strip()]
    remaining_lines = [line for line in lines if not line.startswith('Warning:')]
    return not remaining_lines or remaining_lines == ['None']


def dns_forwarding_state_dict(config) -> dict:
    if config is None:
        return {}
    return config.model_dump() if hasattr(config, 'model_dump') else dict(config)


def dns_config_response_data(response, error_message):
    error = response.get('error')
    if isinstance(error, str) and error.strip() == 'Configuration under specified path is empty':
        return {}
    if response.get('success') is False:
        raise ValueError(error or error_message)
    return response.get('data') or {}


def fetch_dns_config(provider, data=None):
    dns_config = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DNS, verify=False)  
    print("DNS Config: ")
    print(pprint.pformat(dns_config, indent=2, width=80)) 
    config = parse_dns_config(dns_config.json()['data'])
    return config

# DNS SERVER
def fetch_dns_server(provider, data=None):
    response = provider.http_service.send_request(
        action=Action.RETRIEVE, data=SHOW_NAME_SERVERS, verify=False
    ).json()
    nameservers = dns_config_response_data(response, 'Failed to read DNS servers')
    if isinstance(nameservers, dict):
        nameservers = nameservers.get('name-server')
    servers = parse_dns_servers(nameservers)
    print("DNS Servers: ")
    print(pprint.pformat(servers, indent=2, width=80))
    return servers

def delete_dns_server(provider, data):
    try:
        dns_cmd = NameServerCommand(
            operator='delete',
            resource='system',
            name_servers=[{'address': data.ip_address}],
            ip_address_type=data.ip_address_type
        )
        cmds = dns_cmd.generate_commands()
        print("Delete Commands: ")
        print(pprint.pformat(cmds, indent=2, width=80))
        
        if cmds:
            response = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False)
            print("Commands: ")
            print(pprint.pformat(cmds, indent=2, width=80))
            return response.json()
        return None
    except Exception as e:
        print("Error deleting DNS server: ")
        print(pprint.pformat(e, indent=2, width=80))
        return None

def create_dns_server(provider, data):
    try:
        print("Create DNS Server Data: ")
        print(pprint.pformat(data, indent=2, width=80))
        dns_cmd = NameServerCommand(
            operator='set',
            resource='system',
            name_servers=[{'address': data.ip_address}],
            ip_address_type=data.ip_address_type
        )
        cmds = dns_cmd.generate_commands()
        print("Create Commands: ")
        print(pprint.pformat(cmds, indent=2, width=80))
        
        res = []
        if cmds:
            response = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False)
            print("Commands: ")
            print(pprint.pformat(cmds, indent=2, width=80))
            return response.json()
        return None
        
    except Exception as e:
        print("Error creating DNS server: ")
        print(pprint.pformat(e, indent=2, width=80))
        return None


def update_dns_server(provider, data):
    """Apply pending nameserver changes in a single configure request."""
    try:
        current_servers = data.get('current') or []
        new_servers = data.get('new') or []

        if isinstance(current_servers, Exception):
            return current_servers
        if isinstance(new_servers, Exception):
            return new_servers

        current_addresses = {
            server.get('ip_address') or server.get('address')
            for server in current_servers
            if server.get('ip_address') or server.get('address')
        }
        new_addresses = {
            server.get('ip_address') or server.get('address')
            for server in new_servers
            if server.get('ip_address') or server.get('address')
        }

        created = [{'address': address} for address in sorted(new_addresses - current_addresses)]
        deleted = [{'address': address} for address in sorted(current_addresses - new_addresses)]

        set_commands = NameServerCommand(
            operator='set',
            resource='system',
            name_servers=created
        ).generate_commands()
        delete_commands = NameServerCommand(
            operator='delete',
            resource='system',
            name_servers=deleted
        ).generate_commands()
        commands = set_commands + delete_commands

        if not commands:
            return []

        response = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=commands,
            verify=False
        ).json()
        return [{
            'cmd': commands,
            'success': response.get('success', True),
            'error': response.get('error')
        }]
    except Exception as e:
        logger.exception("Error updating DNS servers")
        return Exception(str(e))

# DNS FORWARD
def fetch_dns_forward(provider, data=None):
    dns_config = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DNS, verify=False)   
    config = parse_dns_forward(dns_config.json()['data'])
    print("DNS Forward: ")
    print(pprint.pformat(config, indent=2, width=80))
    return config

def update_dns_forward(provider, data: Dict[str, Any]):
    """
    Update DNS Forwarding configuration
        - Generate set/delete commands
        - Validate dictionary by calling builtin VyOS function
        - Make API call to VyOS
    """
    username = session['username']
    diff = data.get('diff')
    current_dns_forward = data.get('current')
    new_dns_forward = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    r = []
    cmds = []
    ## Generate set commands
    set_cmds = []
    dns_set_cmd = DNSForwardingCommand(operator='set', resource='service')
    set_cmds = dns_set_cmd.generate_commands(diff['created'], current_dns_forward, new_dns_forward)
    sc = dns_set_cmd.get_commands()
    new_set_configs = process_commands(dns_set_cmd.get_validation_commands())

    ## Generate delete commands
    delete_cmds = []
    dns_del_cmd = DNSForwardingCommand(operator='delete', resource='service')
    # If there are no listen addresses, delete all
    if new_dns_forward == {} or new_dns_forward is None:
        diff['deleted'].update({'all': True})
    delete_cmds = dns_del_cmd.generate_commands(diff['deleted'], current_dns_forward, new_dns_forward)
    dc = dns_del_cmd.get_commands()
    new_del_configs = process_commands(dc)

    ## Validate commands
    service = "service_dns_forwarding"
    print("DNS Set Raw Commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    print("DNS Set GeneratedCommands: ")
    print(pprint.pformat(set_cmds, indent=2, width=80))
    print("DNS Delete Raw Commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    print("DNS Delete GeneratedCommands: ")
    print(pprint.pformat(delete_cmds, indent=2, width=80))

    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"service": {"dns": {"forwarding": curr_config}}}

    print("Current Config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New Set Configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    print("New Del Configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))
    
    logger.log("Current Config: %s", pprint.pformat(current_config, indent=2, width=80))
    logger.log("New Set Configs: %s", pprint.pformat(new_set_configs, indent=2, width=80))
    logger.log("New Del Configs: %s", pprint.pformat(new_del_configs, indent=2, width=80))
    
    merged_config = merge_dicts_set(current_config, new_set_configs)
    logger.log("Merged Config: %s", pprint.pformat(merged_config, indent=2, width=80))
    if 'service' in new_del_configs and 'dns' in new_del_configs['service'] and new_del_configs['service']['dns'] == 'forwarding':
        new_del_configs['service']['dns'] = {'forwarding': 'all'}
    
    merged_del_config = merge_dicts_delete(merged_config, new_del_configs)
    
    logger.log("Merged Del Config: %s", pprint.pformat(merged_del_config, indent=2, width=80))
    verify = None
    validation_config = build_dns_forwarding_validation_config(new_dns_forward)
    if validation_config is not None:
        verify = provider.verify_service.call_verify(service, validation_config)
    logger.log("Verify: %s", pprint.pformat(verify, indent=2, width=80))
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    if not is_dns_forwarding_verification_success(verify):
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    print("End of checking")
    print("Username: ", username)

    # update db
    persisted = DNSForwarding.refresh(dns_forwarding_state_dict(new_dns_forward))
    if persisted is False:
        return Exception('Verified DNS forwarding configuration could not be saved to the database')

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update DNS Forwarding",
            "content": "DNS Forwarding is successfully updated"
        }
    )
    excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        if not res.get('success'):
            return Exception(res.get('error') or 'Failed to update DNS forwarding')
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


# DNS DYNAMIC
def fetch_dns_dynamic(provider, data: None):
    dns_config = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DNS_DYNAMIC, verify=False)   
    config = parse_dns_dynamic(dns_config.json()['data'])
    print("DNS Dynamic: ")
    print(pprint.pformat(config, indent=2, width=80))
    return config

def fetch_dns_dynamic_status(provider, data=None):
    response = provider.graphql_service.send_request(function_name='ShowDynamicStatusDns', data=None, verify=False)
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def fetch_dns_forwarding_statistics(provider, data=None):
    response = provider.graphql_service.send_request(function_name='ShowForwardingStatisticsDns', data=None, verify=False)
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def fetch_dns_nameservers(provider, data=None):
    try:
        response = provider.graphql_service.send_request(function_name='ShowDnsNameserversPerleDnsQuery', data=data, verify=False)
        json_resp = response.json()
        return json_resp
    except Exception as e:
        return {"error": str(e)}

def reset_dns_dynamic(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(function_name='ResetDynamicDns', data=data, verify=False)
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def reset_dns_forwarding(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(function_name='ResetForwardingDns', data=data, verify=False)
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def restart_dns_dynamic(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartServiceRestartServiceMutation',
        data={"name": "dns_dynamic"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def restart_dns_forwarding(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartServiceRestartServiceMutation',
        data={"name": "dns_forwarding"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}

def update_dns_dynamic(provider, data):
    try:
        username = session['username']
        diff = data.get('diff')
        current_dns_dynamic = data.get('current')
        new_dns_dynamic = data.get('new')
        print("Diff data: ")
        print(pprint.pformat(diff, indent=2, width=80))
        r = []
        cmds = []
        ## Generate set commands
        set_cmds = []
        dns_set_cmd = DNSDynamicCommand(operator='set', resource='service')
        set_cmds = dns_set_cmd.generate_commands(diff['created'], current_dns_dynamic, new_dns_dynamic)
        sc = dns_set_cmd.get_commands()
        new_set_configs = process_commands(sc)
        
        ## Generate delete commands
        delete_cmds = []
        dns_del_cmd = DNSDynamicCommand(operator='delete', resource='service')
        delete_cmds = dns_del_cmd.generate_commands(diff['deleted'], current_dns_dynamic, new_dns_dynamic)
        dc = dns_del_cmd.get_commands()
        new_del_configs = process_commands(dc)
        
        ## Validate commands
        service = "service_dns_dynamic"

        curr_config = provider.verify_service.call_get_config(service)
        current_config = {"service": {"dns": {"dynamic": curr_config}}}
        
        merged_config = merge_dicts_set(current_config, new_set_configs)
        merged_del_config = merge_dicts_delete(merged_config, new_del_configs)
        
        print("DNS Set Raw Commands: ")
        print(pprint.pformat(sc, indent=2, width=80))
        print("DNS Set GeneratedCommands: ")
        print(pprint.pformat(set_cmds, indent=2, width=80))
        print("DNS Delete Raw Commands: ")
        print(pprint.pformat(dc, indent=2, width=80))
        print("DNS Delete GeneratedCommands: ")
        print(pprint.pformat(delete_cmds, indent=2, width=80))

        print("Current Config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        print("New Set Configs: ")
        print(pprint.pformat(new_set_configs, indent=2, width=80))
        print("New Del Configs: ")
        print(pprint.pformat(new_del_configs, indent=2, width=80))

        print("Merged Config: ")
        print(pprint.pformat(merged_config, indent=2, width=80))
        # print("Merged Del Config: ", merged_del_config)
        print("Verify: ")
        verify = None
        if 'service' in merged_del_config and 'dns' in merged_del_config['service'] and \
            'dynamic' in merged_del_config['service']['dns']:
            verify = provider.verify_service.call_verify(service, merged_del_config['service']['dns']['dynamic'])
        print(pprint.pformat(verify, indent=2, width=80))

        if str(verify) != "None":
            print("Validation Error: ")
            print(pprint.pformat(verify, indent=2, width=80))
            print("Type of Error: ", type(verify))
            return Exception(verify)
        print("End of checking")
        # Update DB after verification
        if 'service' in merged_del_config and 'dns' in merged_del_config['service'] and \
            'dynamic' in merged_del_config['service']['dns']:
            DNSDynamicInterface.refresh(merged_config['service']['dns']['dynamic'])
        # Emit notification
        socket_manager.emit_to_user(
            username, 
            event='notification', 
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update DNS Dynamic",
                "content": "DNS Dynamic is successfully updated"
            }
        )
        excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))

        # Make sure all of commands are unique
        cmds = excecuted_cmds
        print("Commands: ")
        print(pprint.pformat(cmds, indent=2, width=80))


        if len(cmds) > 0:
            res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()['success']
            r.append({"cmd": cmds, "success": res})
        return r
    
    except Exception as e:
        print("Error updating DNS dynamic: ")
        print(pprint.pformat(e, indent=2, width=80))
        return []

def update_dns(provider, data):
    """
    Update both DNS forwarding and dynamic configurations
    """
    try:
        all_delete_cmds = []
        all_set_cmds = []

        # Handle DNS forwarding update
        forwarding_diff = (data.get('forwarding') or {}).get('diff', {})
        if forwarding_diff.get('created') or forwarding_diff.get('deleted'):
            current_dns_forward = data['forwarding']['current']
            new_dns_forward = data['forwarding']['new']
            diff = data['forwarding']['diff']

            # Generate set commands for forwarding
            set_cmds = []
            dns_set_cmd = DNSForwardingCommand(operator='set', resource='service')
            set_cmds = dns_set_cmd.generate_commands(diff['created'], current_dns_forward, new_dns_forward)
            sc = dns_set_cmd.get_commands()
            new_set_configs = process_commands(dns_set_cmd.get_validation_commands())

            # Generate delete commands for forwarding
            delete_cmds = []
            dns_del_cmd = DNSForwardingCommand(operator='delete', resource='service')
            delete_cmds = dns_del_cmd.generate_commands(diff['deleted'])
            dc = dns_del_cmd.get_commands()
            new_del_configs = process_commands(dc)

            # Process and verify forwarding commands
            merged_config = merge_dicts_set({"service": {"dns": {"forwarding": {}}}}, new_set_configs)
            merged_del_config = merge_dicts_delete(merged_config, new_del_configs)
            
            print("Merged DNS Forwarding Config: ")
            print(pprint.pformat(merged_del_config, indent=2, width=80))
            print("Merged DNS Forwarding Del Config: ")
            print(pprint.pformat(merged_del_config, indent=2, width=80))
            
            # Verify forwarding config
            verify = None
            validation_config = build_dns_forwarding_validation_config(new_dns_forward)
            if validation_config is not None:
                verify = provider.verify_service.call_verify('service_dns_forwarding', validation_config)
                print("Verify DNS Forwarding Config: ")
                print(pprint.pformat(verify, indent=2, width=80))
            if not is_dns_forwarding_verification_success(verify):
                return Exception(verify)

            all_delete_cmds.extend(delete_cmds)
            all_set_cmds.extend(set_cmds)

        # Handle DNS dynamic update
        dynamic_diff = (data.get('dynamic') or {}).get('diff', {})
        if dynamic_diff.get('created') or dynamic_diff.get('deleted'):
            current_ddns = data['dynamic']['current']
            new_ddns = data['dynamic']['new']
            diff = data['dynamic']['diff']

            # Generate set commands for dynamic
            set_cmds = []
            dns_set_cmd = DNSDynamicCommand(operator='set', resource='service')
            set_cmds = dns_set_cmd.generate_commands(diff['created'], current_ddns, new_ddns)
            sc = dns_set_cmd.get_commands()
            new_set_configs = process_commands(sc)

            # Generate delete commands for dynamic
            delete_cmds = []
            dns_del_cmd = DNSDynamicCommand(operator='delete', resource='service')
            delete_cmds = dns_del_cmd.generate_commands(diff['deleted'], current_ddns, new_ddns)
            dc = dns_del_cmd.get_commands()
            new_del_configs = process_commands(dc)

            # Process and verify dynamic commands
            merged_config = merge_dicts_set({"service": {"dns": {"dynamic": {}}}}, new_set_configs)
            merged_del_config = merge_dicts_delete(merged_config, new_del_configs)

            # Verify dynamic config
            verify = None
            if 'service' in merged_del_config and 'dns' in merged_del_config['service'] and \
                'dynamic' in merged_del_config['service']['dns']:
                verify = provider.verify_service.call_verify('service_dns_dynamic', merged_del_config['service']['dns']['dynamic'])
            if str(verify) != "None":
                return Exception(verify)

            all_delete_cmds.extend(delete_cmds)
            all_set_cmds.extend(set_cmds)

        # Make sure all of commands are unique
        all_cmds = list(set(all_set_cmds)) + list(set(all_delete_cmds))
        r = []
        # Execute combined commands if any
        if len(all_cmds) > 0:
            res = provider.http_service.send_request(action=Action.CONFIGURE, data=all_cmds, verify=False).json()['success']
            r.append({"cmd": all_cmds, "success": res})

        return r

    except Exception as e:
        return Exception(f"Error updating DNS configuration: {str(e)}")
