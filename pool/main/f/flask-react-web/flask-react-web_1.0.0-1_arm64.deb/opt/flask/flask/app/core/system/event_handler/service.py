import pprint
from logging import DEBUG, getLogger
from uuid import uuid4

from flask import session

from app.core.api.http.cmd.command import SHOW_ALARM
from app.core.api.http.http_request import Action
from app.core.system.event_handler.command_alarm import AlarmCommand
from app.core.system.event_handler.models import AlarmConfig
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set, process_commands
from app.socket.socket_manager import socket_manager

logger = getLogger(__name__)
logger.setLevel(DEBUG)


def fetch_alarm(provider, data: dict):
    resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ALARM, verify=False)
    payload = resp.json().get('data')
    if not isinstance(payload, dict):
        return {}
    return payload


def update_alarm(provider, data: dict):
    logger.info('Update alarm:')
    logger.info(data)

    username = session.get('username', '')
    diff = data.get('diff') or {}
    current_config = data.get('current') or {}
    config = data.get('new') or {}

    print('Diff config: ')
    print(pprint.pformat(diff, indent=2, width=80))
    print('Current config: ')
    print(pprint.pformat(current_config, indent=2, width=80))
    print('New config: ')
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    alarm_set_cmd = AlarmCommand(operator='set', resource='event-handler')
    set_cmds = alarm_set_cmd.generate_commands(data=diff.get('created') or {}, current_config=current_config, new_config=config)
    sc = alarm_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    print('New set configs: ')
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    alarm_delete_cmd = AlarmCommand(operator='delete', resource='event-handler')
    delete_cmds = alarm_delete_cmd.generate_commands(data=diff.get('deleted') or {}, current_config=current_config, new_config=config)
    dc = alarm_delete_cmd.get_commands()
    new_delete_configs = process_commands(dc)

    print('Delete commands: ')
    print(pprint.pformat(dc, indent=2, width=80))
    print('New delete configs: ')
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        current_config,
        new_delete_configs.get('service', {}).get('event-handler', {}),
        clean_empty=False,
    )
    merged_config = merge_dicts_set(
        merged_del_config,
        new_set_configs.get('service', {}).get('event-handler', {}),
    )

    print('Merged config: ')
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    try:
        service = 'event-handler'
        if hasattr(provider, 'verify_service') and provider.verify_service is not None and merged_config and merged_config.get('event', None):
            if hasattr(provider.verify_service, 'call_verify'):
                verify = provider.verify_service.call_verify(service, merged_config.get('event', {}))
    except Exception as e:
        print('Alarm verify skipped (validator may not support event-handler):')
        print(str(e))
        verify = None

    print('Verify: ')
    print(pprint.pformat(verify, indent=2, width=80))

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != 'None' and str(verify).replace('\n', '') not in ['', '{}']:
        return [{'success': False, 'error': str(verify), 'cmd': cmds}]

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update Alarm',
            'content': 'Alarm is successfully updated',
        },
    )

    # Update DB
    AlarmConfig.refresh(config)

    result = []
    print('Commands: ')
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        result.append({'cmd': cmds, 'success': res.get('success'), 'error': res.get('error')})

    return result


def verify_alarm(provider, data: dict):
    try:
        if hasattr(provider, 'verify_service') and provider.verify_service is not None:
            if hasattr(provider.verify_service, 'call_verify'):
                if data.get('event', None):
                    return provider.verify_service.call_verify('alarm', data.get('event'))
    except Exception as e:
        print('Alarm verify skipped (validator may not support alarm):')
        print(str(e))
    return ''
