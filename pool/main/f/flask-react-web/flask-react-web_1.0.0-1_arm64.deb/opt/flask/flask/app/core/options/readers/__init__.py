from .ssh import read_ssh_definition


READERS = {
    "ssh": read_ssh_definition,
}
