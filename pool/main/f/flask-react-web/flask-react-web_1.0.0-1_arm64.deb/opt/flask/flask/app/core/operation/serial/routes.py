from flask import jsonify, request
from pydantic import ValidationError

from app.auth.utils import login_required, permission_required
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.manager import api_manager
from app.core.api.http.cmd.compare import compare_configs
from app.core.operation import vyos_operation_bp
from app.core.operation.serial.models import SerialConfig, UpdateSerialConfigDTO
from app.core.operation.serial.parser import parse_to_serial_config, parse_serial_config_to_form, revision
from app.core.utils.validate.pydantic_error_format import format_pydantic_error


class SerialConflictError(ValueError):
    pass


def _response(result):
    if isinstance(result, Exception):
        status = 409 if isinstance(result, SerialConflictError) \
            else 400 if isinstance(result, ValueError) \
                else 502
        return jsonify({'error': str(result)}), status
    return jsonify(result), 200


@vyos_operation_bp.route('/serial', methods=['GET'])
@login_required
def get_serial_configuration():
    os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
    if isinstance(os_config, Exception):
        return _response(os_config)
    if not isinstance(os_config, dict) or not os_config:
        return _response(RuntimeError('Could not read the running configuration'))
    return _response(parse_serial_config_to_form(
        (os_config.get('service') or {}).get('serial') or {},
        slip_interfaces=(os_config.get('interfaces') or {}).get('slip-tty') or {},
        ppp_interfaces=(os_config.get('interfaces') or {}).get('ppp-tty') or {},
    ))


@vyos_operation_bp.route('/serial', methods=['PUT'])
@login_required
@permission_required(['administrator'])
def update_serial_configuration():
    try:
        data = UpdateSerialConfigDTO.model_validate_json(request.data)
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        if isinstance(os_config, Exception):
            return _response(os_config)
        if not isinstance(os_config, dict) or not os_config:
            return _response(RuntimeError('Could not read the running configuration'))
        current_config = (os_config.get('service') or {}).get('serial') or {}
        slip_interfaces = (os_config.get('interfaces') or {}).get('slip-tty') or {}
        ppp_interfaces = (os_config.get('interfaces') or {}).get('ppp-tty') or {}
        if data.revision != revision(current_config, slip_interfaces, ppp_interfaces):
            SerialConfig.refresh(current_config)
            return _response(SerialConflictError('Serial configuration changed on the device. Reload the page before saving.'))
        new_config = parse_to_serial_config(data, current_config)
        diff = compare_configs(new_config, current_config)

        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SERIAL,
            data={
                'current': current_config, 'new': new_config, 'diff': diff,
                'ppp_interfaces': ppp_interfaces,
                'ppp_values': None if data.ppp_interfaces is None else {
                    name: value.model_dump(by_alias=True, exclude_none=True)
                    for name, value in data.ppp_interfaces.items()
                },
                'slip_interfaces': slip_interfaces,
                'slip_values': None if data.slip_interfaces is None else {
                    name: value.model_dump(by_alias=True, exclude_none=True)
                    for name, value in data.slip_interfaces.items()
                },
            },
        )
        if isinstance(result, Exception):
            return _response(result)
        failures = [item for item in result if item.get('success') is not True]
        if failures:
            return jsonify({'error': '\n'.join(str(item.get('error') or 'Serial configuration update failed') for item in failures)}), 400
        saved_interfaces = result[-1].get('slip_interfaces', slip_interfaces) if result else slip_interfaces
        saved_ppp = result[-1].get('ppp_interfaces', ppp_interfaces) if result else ppp_interfaces
        return _response(parse_serial_config_to_form(new_config, slip_interfaces=saved_interfaces, ppp_interfaces=saved_ppp))
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except ValueError as error:
        return _response(error)
