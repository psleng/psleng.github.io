from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.log.logger import logger
from pydantic import BaseModel
from typing import Optional, List


class RIPngInterfaceDTO(BaseModel):
    id: Optional[str] = None
    name: str
    splitHorizon: str = "enabled"  # enabled, disabled, poison-reverse


class RIPngRedistributionProtocolDTO(BaseModel):
    enabled: bool = False
    metric: Optional[str] = ""


class RIPngRedistributionDTO(BaseModel):
    connected: RIPngRedistributionProtocolDTO = RIPngRedistributionProtocolDTO()
    kernel: RIPngRedistributionProtocolDTO = RIPngRedistributionProtocolDTO()
    ospfv3: RIPngRedistributionProtocolDTO = RIPngRedistributionProtocolDTO()
    static: RIPngRedistributionProtocolDTO = RIPngRedistributionProtocolDTO()


class RIPngAdvancedConfigDTO(BaseModel):
    aggregateAddresses: List[str] = []
    passiveInterfaces: List[str] = []
    defaultInformationOriginate: bool = False
    defaultMetric: Optional[str] = ""
    routeMap: Optional[str] = ""
    timersGarbageCollection: Optional[str] = ""
    timersTimeout: Optional[str] = ""
    timersUpdate: Optional[str] = ""


class UpdateRIPngDTO(BaseModel):
    aggregateAddresses: List[str] = []
    networks: List[str] = []
    passiveInterfaces: List[str] = []
    routes: List[str] = []
    interfaces: List[RIPngInterfaceDTO] = []
    redistribution: RIPngRedistributionDTO = RIPngRedistributionDTO()
    advanced: RIPngAdvancedConfigDTO = RIPngAdvancedConfigDTO()


class VerifyRIPngDTO(BaseModel):
    verify_type: str
    interfaces: Optional[List[RIPngInterfaceDTO]] = []


class RIPngConfig(db.Model):
    __tablename__ = 'vyos_config_ripng'
    
    id = Column(Integer, primary_key=True)
    default_information_originate = Column(Boolean, default=False)
    default_metric = Column(Integer)
    route_map = Column(String(100))
    
    timers_garbage_collection = Column(Integer)
    timers_timeout = Column(Integer)
    timers_update = Column(Integer)
    
    aggregate_addresses = relationship("RIPngAggregateAddress", back_populates="ripng_config", cascade="all, delete-orphan")
    networks = relationship("RIPngNetwork", back_populates="ripng_config", cascade="all, delete-orphan")
    passive_interfaces = relationship("RIPngPassiveInterface", back_populates="ripng_config", cascade="all, delete-orphan")
    routes = relationship("RIPngRoute", back_populates="ripng_config", cascade="all, delete-orphan")
    interfaces = relationship("RIPngInterface", back_populates="ripng_config", cascade="all, delete-orphan")
    redistributes = relationship("RIPngRedistribute", back_populates="ripng_config", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'id': self.id,
            'default_information_originate': self.default_information_originate,
            'default_metric': self.default_metric,
            'route_map': self.route_map,
            'aggregate_addresses': [a.serialize() for a in self.aggregate_addresses],
            'networks': [n.serialize() for n in self.networks],
            'passive_interfaces': [pi.serialize() for pi in self.passive_interfaces],
            'routes': [r.serialize() for r in self.routes],
            'timers_garbage_collection': self.timers_garbage_collection,
            'timers_timeout': self.timers_timeout,
            'timers_update': self.timers_update,
            'interfaces': [intf.serialize() for intf in self.interfaces],
            'redistributes': [r.serialize() for r in self.redistributes]
        }
    
    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_ripng_aggregate_address',
            'vyos_config_ripng_network',
            'vyos_config_ripng_passive_interface',
            'vyos_config_ripng_route',
            'vyos_config_ripng_interface',
            'vyos_config_ripng_redistribute',
            'vyos_config_ripng'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh RIPng configuration from VyOS data"""
        try:
            cls.truncate()
            
            ripng_config = cls()
            
            ripng_config.default_information_originate = 'default-information' in data and 'originate' in data.get('default-information', {})
            
            if 'default-metric' in data:
                ripng_config.default_metric = int(data['default-metric'])
            
            if 'route-map' in data:
                ripng_config.route_map = data['route-map']
            
            if 'timers' in data:
                timers = data['timers']
                if 'garbage-collection' in timers:
                    ripng_config.timers_garbage_collection = int(timers['garbage-collection'])
                if 'timeout' in timers:
                    ripng_config.timers_timeout = int(timers['timeout'])
                if 'update' in timers:
                    ripng_config.timers_update = int(timers['update'])
            
            db.session.add(ripng_config)
            db.session.flush()
            
            if 'aggregate-address' in data:
                if isinstance(data['aggregate-address'], list):
                    aggregate_list = data['aggregate-address']
                elif isinstance(data['aggregate-address'], str):
                    aggregate_list = [data['aggregate-address']]
                elif isinstance(data['aggregate-address'], dict):
                    aggregate_list = list(data['aggregate-address'].keys())
                for address in aggregate_list:
                    db.session.add(RIPngAggregateAddress(
                        ripng_config_id=ripng_config.id,
                        address=address
                    ))
            
            if 'network' in data:
                if isinstance(data['network'], list):
                    network_list = data['network']
                elif isinstance(data['network'], str):
                    network_list = [data['network']]
                elif isinstance(data['network'], dict):
                    network_list = list(data['network'].keys())
                for network in network_list:
                    db.session.add(RIPngNetwork(
                        ripng_config_id=ripng_config.id,
                        network=network
                    ))
            
            if 'passive-interface' in data:
                if isinstance(data['passive-interface'], list):
                    passive_list = data['passive-interface']
                elif isinstance(data['passive-interface'], str):
                    passive_list = [data['passive-interface']]
                elif isinstance(data['passive-interface'], dict):
                    passive_list = list(data['passive-interface'].keys())
                for intf_name in passive_list:
                    db.session.add(RIPngPassiveInterface(
                        ripng_config_id=ripng_config.id,
                        interface_name=intf_name
                    ))
            
            if 'route' in data:
                if isinstance(data['route'], list):
                    route_list = data['route']
                elif isinstance(data['route'], str):
                    route_list = [data['route']]
                elif isinstance(data['route'], dict):
                    route_list = list(data['route'].keys())
                for route in route_list:
                    db.session.add(RIPngRoute(
                        ripng_config_id=ripng_config.id,
                        route=route
                    ))
            
            if 'interface' in data:
                for intf_name, intf_data in data['interface'].items():
                    interface = RIPngInterface(
                        ripng_config_id=ripng_config.id,
                        interface_name=intf_name,
                        split_horizon_enabled='split-horizon' in intf_data and (intf_data['split-horizon'] == {} or intf_data['split-horizon'] is True),
                        split_horizon_disable='split-horizon' in intf_data and isinstance(intf_data['split-horizon'], dict) and 'disable' in intf_data['split-horizon'],
                        split_horizon_poison_reverse='split-horizon' in intf_data and isinstance(intf_data['split-horizon'], dict) and 'poison-reverse' in intf_data['split-horizon']
                    )
                    db.session.add(interface)
            
            if 'redistribute' in data:
                for protocol, protocol_data in data['redistribute'].items():
                    redistribute = RIPngRedistribute(
                        ripng_config_id=ripng_config.id,
                        protocol=protocol,
                        metric=int(protocol_data['metric']) if isinstance(protocol_data, dict) and 'metric' in protocol_data else None
                    )
                    db.session.add(redistribute)
            
            db.session.commit()
            logger.info("RIPng configuration refreshed successfully")
            
        except Exception as e:
            logger.error(f"Error refreshing RIPng configuration: {e}")


class RIPngInterface(db.Model):
    __tablename__ = 'vyos_config_ripng_interface'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    split_horizon_enabled = Column(Boolean, default=False)
    split_horizon_disable = Column(Boolean, default=False)
    split_horizon_poison_reverse = Column(Boolean, default=False)
    
    ripng_config = relationship("RIPngConfig", back_populates="interfaces")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name,
            'split_horizon_enabled': self.split_horizon_enabled,
            'split_horizon_disable': self.split_horizon_disable,
            'split_horizon_poison_reverse': self.split_horizon_poison_reverse
        }


class RIPngAggregateAddress(db.Model):
    __tablename__ = 'vyos_config_ripng_aggregate_address'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    address = Column(String(100), nullable=False)
    
    ripng_config = relationship("RIPngConfig", back_populates="aggregate_addresses")
    
    def serialize(self):
        return {
            'address': self.address
        }


class RIPngNetwork(db.Model):
    __tablename__ = 'vyos_config_ripng_network'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    network = Column(String(100), nullable=False)
    
    ripng_config = relationship("RIPngConfig", back_populates="networks")
    
    def serialize(self):
        return {
            'network': self.network
        }


class RIPngPassiveInterface(db.Model):
    __tablename__ = 'vyos_config_ripng_passive_interface'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    
    ripng_config = relationship("RIPngConfig", back_populates="passive_interfaces")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name
        }


class RIPngRoute(db.Model):
    __tablename__ = 'vyos_config_ripng_route'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    route = Column(String(100), nullable=False)
    
    ripng_config = relationship("RIPngConfig", back_populates="routes")
    
    def serialize(self):
        return {
            'route': self.route
        }


class RIPngRedistribute(db.Model):
    __tablename__ = 'vyos_config_ripng_redistribute'
    
    id = Column(Integer, primary_key=True)
    ripng_config_id = Column(Integer, ForeignKey('vyos_config_ripng.id'), nullable=False)
    protocol = Column(String(50), nullable=False)
    metric = Column(Integer)
    
    ripng_config = relationship("RIPngConfig", back_populates="redistributes")
    
    def serialize(self):
        return {
            'protocol': self.protocol,
            'metric': self.metric
        }


RIPng = RIPngConfig
