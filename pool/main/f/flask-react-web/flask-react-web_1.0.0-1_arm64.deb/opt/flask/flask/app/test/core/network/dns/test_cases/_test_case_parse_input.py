import pytest
import json

test_case_valid = [
    pytest.param(
        {
            "valid_json": json.dumps({
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "198.51.100.0",
                                    "203.0.113.0"
                                ]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            })
        },
        id="valid_dns_json_1"
    )
]
test_case_invalid = [
    pytest.param(
        {
            "invalid_json": json.dumps({
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "999.999.999.999"
                                ]
                            }
                        }
                    }
                }
            })
        },
        id="invalid_dns_json_1"
    ),
    pytest.param(
        {
            "invalid_json": json.dumps({
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": None
                            }
                        }
                    }
                }
            })
        },
        id="invalid_dns_json_2"
    )
]

test_case_minimal = [
    pytest.param(
        {
            "minimal_json": json.dumps({
                "dns": {
                    "forwarding": {
                        "domain": {}
                    }
                }
            })
        },
        id="minimal_dns_json_1"
    )
]

test_case_comparison = [
    pytest.param(
        {
            "current_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "198.51.100.0"
                                ]
                            }
                        }
                    }
                }
            },
            "new_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "198.51.100.0",
                                    "203.0.113.0"
                                ]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            },
            "expected_diff": {
                "created": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": [
                                        "203.0.113.0"
                                    ]
                                },
                                "dns.example9.com": {
                                    "name-server": "2001:db8:abcd:12::1"
                                }
                            }
                        }
                    }
                },
                "deleted": {}
            }
        },
        id="dns_comparison_1"
    ),
    pytest.param(
        {
            "current_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "198.51.100.0",
                                    "203.0.113.0"
                                ]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            },
            "new_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": [
                                    "198.51.100.0"
                                ]
                            }
                        }
                    }
                }
            },
            "expected_diff": {
                "created": {},
                "deleted": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": [
                                        "203.0.113.0"
                                    ]
                                },
                                "dns.example9.com": {
                                    "name-server": "2001:db8:abcd:12::1"
                                }
                            }
                        }
                    }
                }
            }
        },
        id="dns_comparison_2"
    )
]

