from typing import Dict, List, Optional

from ipaddress import IPv6Address

from pydantic import BaseModel, field_validator
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import db


class NDPProxyPrefixDTO(BaseModel):
    value: Optional[str] = None
    enabled: Optional[bool] = None
    mode: Optional[str] = None
    interface: Optional[str] = None

    @field_validator('mode')
    @classmethod
    def validate_mode(cls, value):
        if value in (None, ''):
            return value
        if value not in ('static', 'auto', 'interface'):
            raise ValueError('Mode must be static, auto, or interface')
        return value


class NDPProxyInterfaceDTO(BaseModel):
    name: Optional[str] = None
    enabled: Optional[bool] = None
    enable_router_bit: Optional[bool] = None
    timeout: Optional[int] = None
    ttl: Optional[int] = None
    prefixes: Optional[List[NDPProxyPrefixDTO]] = None


class NDPProxyDTO(BaseModel):
    route_refresh: Optional[int] = None
    interfaces: Optional[List[NDPProxyInterfaceDTO]] = None


class NDPNeighborAddressResetDTO(BaseModel):
    address: IPv6Address


class NDPNeighborInterfaceResetDTO(BaseModel):
    interface: str

    @field_validator('interface')
    @classmethod
    def validate_interface(cls, value):
        normalized = value.strip()
        if not normalized:
            raise ValueError('Interface name is required')
        if len(normalized) > 64 or any(char not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.:-' for char in normalized):
            raise ValueError('Interface name contains unsupported characters')
        return normalized


class NDPProxyConfig(db.Model):
    __tablename__ = 'vyos_ndp_proxy_config'

    id = Column(Integer, primary_key=True)
    route_refresh = Column(Integer, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(NDPProxyPrefix).delete()
        db.session.query(NDPProxyInterface).delete()
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: Dict):
        from app.core.network.ndp_proxy.parser import parse_ndp_proxy_config

        parsed = parse_ndp_proxy_config(data or {})
        cls.truncate()
        cfg = cls(route_refresh=_to_int(parsed.get('route_refresh')))
        db.session.add(cfg)
        db.session.flush()

        for intf in parsed.get('interfaces') or []:
            row = NDPProxyInterface(
                config_id=cfg.id,
                name=intf.get('name'),
                enabled=bool(intf.get('enabled', True)),
                enable_router_bit=bool(intf.get('enable_router_bit', False)),
                timeout=_to_int(intf.get('timeout')),
                ttl=_to_int(intf.get('ttl')),
            )
            db.session.add(row)
            db.session.flush()

            for prefix in intf.get('prefixes') or []:
                db.session.add(NDPProxyPrefix(
                    interface_id=row.id,
                    value=prefix.get('value'),
                    enabled=bool(prefix.get('enabled', True)),
                    mode=prefix.get('mode') or None,
                    proxy_interface=prefix.get('interface') or None,
                ))

        db.session.commit()

    def serialize(self):
        return {
            'route_refresh': self.route_refresh,
            'interfaces': [i.serialize() for i in self.interfaces],
        }


class NDPProxyInterface(db.Model):
    __tablename__ = 'vyos_ndp_proxy_interface'

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_ndp_proxy_config.id'), nullable=False)
    name = Column(String(64), nullable=False)
    enabled = Column(Boolean, nullable=True)
    enable_router_bit = Column(Boolean, nullable=True)
    timeout = Column(Integer, nullable=True)
    ttl = Column(Integer, nullable=True)

    config = relationship('NDPProxyConfig', backref='interfaces')
    prefixes = relationship('NDPProxyPrefix', back_populates='interface', cascade='all, delete-orphan')

    def serialize(self):
        return {
            'name': self.name,
            'enabled': self.enabled,
            'enable_router_bit': self.enable_router_bit,
            'timeout': self.timeout,
            'ttl': self.ttl,
            'prefixes': [p.serialize() for p in self.prefixes],
        }


class NDPProxyPrefix(db.Model):
    __tablename__ = 'vyos_ndp_proxy_prefix'

    id = Column(Integer, primary_key=True)
    interface_id = Column(Integer, ForeignKey('vyos_ndp_proxy_interface.id'), nullable=False)
    value = Column(String(128), nullable=False)
    enabled = Column(Boolean, nullable=True)
    mode = Column(String(16), nullable=True)
    proxy_interface = Column(String(64), nullable=True)

    interface = relationship('NDPProxyInterface', back_populates='prefixes')

    def serialize(self):
        return {
            'value': self.value,
            'enabled': self.enabled,
            'mode': self.mode,
            'interface': self.proxy_interface or '',
        }


def _to_int(value):
    if value is None or value == '':
        return None
    try:
        return int(value)
    except Exception:
        return None
