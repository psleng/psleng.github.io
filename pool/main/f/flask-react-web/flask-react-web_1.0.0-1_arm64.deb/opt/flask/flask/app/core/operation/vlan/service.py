
from app.core.operation.vlan.command_vlan import VLANCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.operation.vlan.models import VLANInterfaceConfig

def update_vlan(provider, data):
    logger.info("Update VLAN:")
    logger.info(data)
    username = session['username']
    new_config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(new_config, indent=2, width=80))
    
    set_cmds = []
    iface_set_cmd = VLANCommand(operator='set', resource='vlan')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=new_config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = VLANCommand(operator='delete', resource='vlan')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    intf_service = "ethernet"

    curr_configs = {
        "interfaces": {
            "ethernet": {}
        }
    }
    for eth_name in current_config:
        curr_config = provider.verify_service.query_interface_config(intf_service, eth_name)
        curr_configs["interfaces"]["ethernet"][eth_name] = curr_config

    print("Current interfaces configs: ")
    print(pprint.pformat(curr_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(curr_configs, new_delete_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    
    # Clean up empty MTU dicts that cause VyOS validation error
    def cleanup_empty_mtu(config):
        if isinstance(config, dict):
            if 'mtu' in config and config['mtu'] == {}:
                del config['mtu']
            for key, value in list(config.items()):
                if isinstance(value, dict):
                    cleanup_empty_mtu(value)
        return config
    
    merged_config = cleanup_empty_mtu(merged_config)
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = {}
    if merged_config:
        for eth_name in merged_config.get('interfaces', {}).get('ethernet', {}):
            print("Config to verify: ")
            print(pprint.pformat(merged_config['interfaces']['ethernet'][eth_name], indent=1, width=80))
            verify[eth_name] = ""
            verify[eth_name] = provider.verify_service.query_interface_verify(
                intf_service, 
                eth_name, 
                merged_config['interfaces']['ethernet'][eth_name]
            )
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if any(str(v) != "None" and str(v) != "" and v != {} for v in verify.values()):
        return [{"success": False, "error": verify, "cmd": cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update VLAN",
                "content": "VLAN is successfully updated"
            }
    )
    # save to db:
    if merged_config.get('interfaces', {}).get('ethernet', None):
        VLANInterfaceConfig.refresh(merged_config['interfaces']['ethernet'])
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r
