from datetime import datetime

from app.core.operation.models import SoftwareUpdateJob, UserManagement
from app.core.operation.software_management.service import get_system_update_status
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


UPDATE_NOTIFICATION_ACTION = "software-update-available"
_alert_active = False
ACTIVE_UPDATE_STATES = ("queued", "applying")


def check_software_update_available(app_context):
    global _alert_active
    try:
        update_status = get_system_update_status()
        if not update_status["update_available"]:
            if _alert_active:
                socket_manager.emit_to_all(
                    event="notification",
                    data={"type": "remove", "action": UPDATE_NOTIFICATION_ACTION},
                )
            _alert_active = False
            return update_status

        with app_context:
            active_job = SoftwareUpdateJob.query.filter(
                SoftwareUpdateJob.state.in_(ACTIVE_UPDATE_STATES),
            ).first()
            if active_job:
                return {
                    **update_status,
                    "notified": False,
                    "install_started": True,
                    "job_id": active_job.id,
                }

            administrators = UserManagement.query.filter(
                UserManagement.role.ilike("administrator"),
                UserManagement.status.is_(True),
            ).all()
            admin_usernames = {user.user_name for user in administrators if user.user_name}

        connected_usernames = set(socket_manager.get_connected_clients().keys())
        usernames = sorted(admin_usernames & connected_usernames)

        notification = {
            "id": str(int(datetime.now().timestamp() * 1000)),
            "type": "info",
            "title": "Software update available",
            "content": "A new software image is available. Do you want to install it now?",
            "action": UPDATE_NOTIFICATION_ACTION,
            "url": update_status.get("url"),
            "local_version": update_status.get("local_version"),
            "remote_version": update_status.get("remote_version"),
        }
        for username in usernames:
            socket_manager.emit_to_user(username, event="notification", data=notification)

        _alert_active = True
        return {**update_status, "notified": bool(usernames)}
    except Exception as exc:
        logger.error(f"Software update availability check failed: {exc}")
        return {"success": False, "errors": [str(exc)]}
