from pydantic import BaseModel, StrictBool
from sqlalchemy import Boolean, Column, Integer, Text, text

from app.db.database import db


class UpdateSoftwareManagementDTO(BaseModel):
    disableUpdate: StrictBool = False
    url: str = ""


class SoftwareUpdateCheckConfig(db.Model):
    __tablename__ = "vyos_config_software_update_check"

    id = Column(Integer, primary_key=True)
    update_disabled = Column(Boolean, nullable=False, default=False)
    url = Column(Text, nullable=True)

    def serialize(self):
        return {
            "disableUpdate": bool(self.update_disabled),
            "url": self.url or "",
        }

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data):
        cls.truncate()
        config = data if isinstance(data, dict) else {}
        db.session.add(cls(
            update_disabled="disable" in config,
            url=str(config.get("url") or "") or None,
        ))
        db.session.commit()
