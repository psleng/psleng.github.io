import os
from dataclasses import dataclass
from enum import Enum, StrEnum
import requests
from typing import overload
import json
from app.core.api.api import API_REQUEST
from dotenv import load_dotenv
from app.log.logger import logger
from flask import has_app_context, has_request_context, current_app

class GraphqlRequest(API_REQUEST):

    def _get_timeout(self) -> float:
        timeout_seconds = os.environ.get('VYOS_HTTP_TIMEOUT_SECONDS')
        try:
            return float(timeout_seconds) if timeout_seconds else 50.0
        except Exception:
            return 50.0

    def __init__(self, hostname=None, apikey=None, port=None, protocol=None):
        super().__init__()
        load_dotenv()
        self.url = None
        if hostname and apikey and port and protocol:
            self.hostname = hostname
            self.apikey = apikey 
            self.port = port
            self.protocol = protocol
        else:
            if has_app_context():
                self.hostname = current_app.config.get("VYOS_HOSTNAME")
                self.apikey = current_app.config.get("VYOS_APIKEY")
                self.port = current_app.config.get("VYOS_PORT")
                self.protocol = current_app.config.get("VYOS_PROTOCOL")
            else:
                self.hostname = os.environ.get("VYOS_HOSTNAME")
                self.apikey = os.environ.get("VYOS_APIKEY")
                self.port = os.environ.get("VYOS_PORT")
                self.protocol = os.environ.get("VYOS_PROTOCOL")
        self.set_url(protocol=self.protocol, hostname=self.hostname, port=self.port)

    def __enter__(self):
        logger.log("Entering the context")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        logger.log("Exiting the context")
        return False
        
    def set_url(self, protocol, hostname, port):
        self.url = f"{protocol}://{hostname}:{port}/graphql"

    def send_request(self, function_name, data, verify: bool):
        data_str = f'key: "{self.apikey}"'
        
        if data:
            if isinstance(data, str):
                data_str += f", {data}"
            elif isinstance(data, dict):
                formatted_items = []
                for k, v in data.items():
                    if v == "":
                        formatted_items.append(f'{k}: ""')
                    else:
                        formatted_items.append(f"{k}: {v}")
                if formatted_items:
                    data_str += ", " + ", ".join(formatted_items)
        
        payload = {
            "query": "{ " + function_name + f" (data: {{ {data_str} }}) " + "{ success errors data { result } } }"
        }
        headers = {}

        response = requests.post(
            url=self.url,
            headers=headers,
            json=payload,
            verify=verify,
            # timeout=self._get_timeout(),
        )

        logger.log("URL: ")
        logger.log(self.url)
        logger.log("Payload: ")
        logger.log( payload)
        logger.log("Status Code: ")
        logger.log( response.status_code)
        # logger.log("Response: ")
        # logger.log(pprint.pformat( response.json()['data'], indent=2, width=80))
        
        return response


    def send_simple_mutation_request(self, function_name, data, verify: bool):
        key_override = None
        if isinstance(data, dict):
            key_override = data.get('key')
        api_key = key_override if key_override else self.apikey

        data_str = f'key: {json.dumps(api_key)}'

        if data:
            if isinstance(data, str):
                data_str += f", {data}"
            elif isinstance(data, dict):
                formatted_items = []
                for k, v in data.items():
                    if k == 'key':
                        continue
                    if isinstance(v, str):
                        formatted_items.append(f'{k}: {json.dumps(v)}')
                    elif isinstance(v, bool):
                        formatted_items.append(f"{k}: {str(v).lower()}")
                    elif v is None:
                        formatted_items.append(f"{k}: null")
                    else:
                        formatted_items.append(f"{k}: {v}")
                if formatted_items:
                    data_str += ", " + ", ".join(formatted_items)

        payload = {
            "query": "mutation { " + function_name + f" (data: {{ {data_str} }}) " + "{ success errors data { result } } }"
        }

        headers = {
            "Content-Type": "application/json"
        }

        response = requests.post(
            url=self.url,
            headers=headers,
            json=payload,
            verify=verify,
            # timeout=self._get_timeout(),
        )

        logger.log("Mutation URL: ")
        logger.log(self.url)
        logger.log("Mutation Payload: ")
        logger.log(payload)
        logger.log("Status Code: ")
        logger.log(response.status_code)

        return response


    def send_mutation_request(self, function_name, mutation_name, input_name, data, verify: bool):
        
        if isinstance(data, dict):
            mutation_data = data.copy()
            mutation_data["key"] = self.apikey
        else:
            mutation_data = {"key": self.apikey}
        
        mutation_query = f"mutation {function_name}($data: {input_name}!) {{ {mutation_name}(data: $data) {{ success errors data {{ result }} }} }}"
        
        payload = {
            "query": mutation_query,
            "variables": {
                "data": mutation_data
            }
        }
        
        headers = {
            "Content-Type": "application/json"
        }

        response = requests.post(
            url=self.url,
            headers=headers,
            json=payload,
            verify=verify,
            # timeout=self._get_timeout(),
        )

        logger.log("Mutation URL: ")
        logger.log(self.url)
        logger.log("Mutation Payload: ")
        logger.log(payload)
        logger.log("Status Code: ")
        logger.log(response.status_code)
        # logger.log("Response: ")
        # logger.log(pprint.pformat(response.json(), indent=2, width=80))
        
        return response
        

    def send_str_request(self, function_name, data, verify):
        
        data_str = f'key: "{self.apikey}", {data}'
        
        payload = {
            "query": "{ " + function_name + f" (data: {{ {data_str} }}) " + "{ success errors data { result } } }"
        }

        response = requests.post(
            url=self.url,
            headers={},
            json=payload,
            verify=verify,
            # timeout=self._get_timeout(),
        )

        logger.log("URL: ")
        logger.log(self.url)
        logger.log("Payload: ")
        logger.log( payload)
        logger.log("Status Code: ")
        logger.log( response.status_code)

        return response

if __name__ == "__main__":
    req = GraphqlRequest(hostname="localhost", apikey="mykey", protocol="https", port=443)
    res = req.send_request(function_name='ShowRulesNat', data="direction: source, family: inet", verify=False)
    print(res.json())
