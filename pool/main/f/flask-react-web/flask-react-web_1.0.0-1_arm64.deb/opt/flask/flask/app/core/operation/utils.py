import time
import functools
from typing import Callable, Any
from app.config import global_config
from app.log.logger import logger

import os
import re
from typing import List
from app.core.utils.check_os import is_linux

def read_ike_dh_group() -> List[str]:
    
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/vpn/ipsec/ike-group/node.tag/proposal/node.tag/dh-group/node.def'
    default_list = ['1', '2', '5', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32']
    
    if not is_linux() or not os.path.exists(file_path):
        return default_list
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            match = re.search(r'allowed:\s*echo\s+"([^"]+)"', content)
            if match:
                values = match.group(1).split()
                return values
    except Exception as e:
        logger.error(f"Error reading IKE DH group file: {e}")
    
    return default_list

def read_ike_encryption() -> List[str]:
    
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/vpn/ipsec/ike-group/node.tag/proposal/node.tag/encryption/node.def'
    
    default_list = ['null', 'aes128', 'aes192', 'aes256', 'aes128ctr', 'aes192ctr', 'aes256ctr', 'aes128ccm64', 'aes192ccm64', 'aes256ccm64', 
                    'aes128ccm96', 'aes192ccm96', 'aes256ccm96', 'aes128ccm128', 'aes192ccm128', 'aes256ccm128', 'aes128gcm64', 'aes192gcm64', 
                    'aes256gcm64', 'aes128gcm96', 'aes192gcm96', 'aes256gcm96', 'aes128gcm128', 'aes192gcm128', 'aes256gcm128', 'aes128gmac', 
                    'aes192gmac', 'aes256gmac', '3des', 'blowfish128', 'blowfish192', 'blowfish256', 'camellia128', 'camellia192', 'camellia256', 
                    'camellia128ctr', 'camellia192ctr', 'camellia256ctr', 'camellia128ccm64', 'camellia192ccm64', 'camellia256ccm64', 
                    'camellia128ccm96', 'camellia192ccm96', 'camellia256ccm96', 'camellia128ccm128', 'camellia192ccm128', 'camellia256ccm128', 
                    'serpent128', 'serpent192', 'serpent256', 'twofish128', 'twofish192', 'twofish256', 'cast128', 'chacha20poly1305']
    
    if not is_linux() or not os.path.exists(file_path):
        return default_list
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            match = re.search(r'allowed:\s*echo\s+"([^"]+)"', content)
            if match:
                values = match.group(1).split()
                return values
    except Exception as e:
        logger.error(f"Error reading IKE encryption file: {e}")
    
    return default_list

def read_ike_hash():
    
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/vpn/ipsec/ike-group/node.tag/proposal/node.tag/hash/node.def'
    
    default_list = ['md5', 'md5_128', 'sha1', 'sha1_160', 'sha256', 'sha256_96', 'sha384', 'sha512', 'aesxcbc', 'aescmac', 'aes128gmac', 'aes192gmac', 'aes256gmac']
    
    if not is_linux() or not os.path.exists(file_path):
        return default_list
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            match = re.search(r'allowed:\s*echo\s+"([^"]+)"', content)
            if match:
                values = match.group(1).split()
                return values
    except Exception as e:
        logger.error(f"Error reading IKE hash file: {e}")
    
    return default_list

def read_ike_pseudo_random_function():
   
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/vpn/ipsec/ike-group/node.tag/proposal/node.tag/prf/node.def'
    
    default_list = ['prfmd5', 'prfsha1', 'prfaesxcbc', 'prfaescmac', 'prfsha256', 'prfsha384', 'prfsha512']
    
    if not is_linux() or not os.path.exists(file_path):
        return default_list
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            match = re.search(r'allowed:\s*echo\s+"([^"]+)"', content)
            if match:
                values = match.group(1).split()
                return values
    except Exception as e:
        logger.error(f"Error reading IKE PRF file: {e}")
    
    return default_list

def read_esp_encryption():
    
    return read_ike_encryption()

def read_esp_hash():
    
    return read_ike_hash()

def read_esp_pfs():
    
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/vpn/ipsec/esp-group/node.tag/pfs/node.def'
    
    default_list = ['enable', 'dh-group1', 'dh-group2', 'dh-group5', 'dh-group14', 'dh-group15', 'dh-group16', 'dh-group17', 'dh-group18', 
                    'dh-group19', 'dh-group20', 'dh-group21', 'dh-group22', 'dh-group23', 'dh-group24', 'dh-group25', 'dh-group26', 'dh-group27', 
                    'dh-group28', 'dh-group29', 'dh-group30', 'dh-group31', 'dh-group32', 'disable']
    
    if not is_linux() or not os.path.exists(file_path):
        return default_list
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            match = re.search(r'allowed:\s*echo\s+"([^"]+)"', content)
            if match:
                values = match.group(1).split()
                return values
    except Exception as e:
        logger.error(f"Error reading ESP PFS file: {e}")
    
    return default_list

def measure_time(log_level: str = 'INFO') -> Callable:
    """
    A decorator that measures and logs the execution time of a function.
    Args:
        log_level (str): The logging level to use. Default is 'INFO'.
            Valid values are: 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            log_method = getattr(logger, log_level.lower(), logger.info)
            start_time = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                end_time = time.perf_counter()
                execution_time = end_time - start_time
                logger.debug(f"Function '{func.__name__}' executed in {execution_time:.10f} seconds")
                return result
            except Exception as e:
                end_time = time.perf_counter()
                execution_time = end_time - start_time                
                logger.error(f"Function '{func.__name__}' failed after {execution_time:.10f} seconds. ")
                logger.error(f"Error: {str(e)}")
                raise
                
        return wrapper
    return decorator


def pause_scheduler(do_pause: bool, pause_actions: list[str] = ['UPDATE']) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            paused = False
            if do_pause:
                logger.debug("Kwargs: ")
                logger.debug(kwargs)
                # Pause scheduler before the call
                try:
                    action = kwargs.get('action')
                    if action in pause_actions and global_config.app_scheduler and global_config.app_scheduler.running is True:
                        logger.debug("--- Pause scheduler ---")
                        pause_result = global_config.app_scheduler.pause()
                        logger.debug(f"Pause result: {pause_result}")
                        paused = True
                except Exception as e:
                    logger.error(f"Error pausing scheduler: {str(e)}")
            
            result = func(*args, **kwargs)
            
            if do_pause and paused:
                # Resume scheduler after the call
                try:
                    action = kwargs.get('action')
                    logger.debug("Current apcheduler running before resume:")
                    logger.debug(global_config.app_scheduler.running)
                    if action in pause_actions and global_config.app_scheduler:
                        logger.debug("--- Resume scheduler ---")
                        global_config.app_scheduler.resume()
                        paused = False
                except Exception as e:
                    logger.error(f"Error resuming scheduler: {str(e)}")
    
            return result
        return wrapper
    return decorator


def router_pause_scheduler(func: Callable | None = None) -> Callable:
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            paused = False

            try:
                if global_config.app_scheduler and global_config.app_scheduler.running is True:
                    logger.debug("--- Pause scheduler (route) ---")
                    global_config.app_scheduler.pause()
                    logger.debug(f"Paused: {global_config.app_scheduler.running is False}")
                    paused = True
            except Exception as e:
                logger.error(f"Error pausing scheduler (route): {str(e)}")

            try:
                return fn(*args, **kwargs)
            finally:
                if paused:
                    try:
                        if global_config.app_scheduler:
                            logger.debug("--- Resume scheduler (route) ---")
                            global_config.app_scheduler.resume()
                    except Exception as e:
                        logger.error(f"Error resuming scheduler (route): {str(e)}")

        return wrapper

    if func is not None:
        return decorator(func)

    return decorator

def read_vyos_api_port():
    """
        - Flask backend to read /etc/nginx/sites-available/default file in order to set request port.
        - Use crossplane (by nginxinc) package to parse nginx config file.
        - Sample read:
            server {
                listen 0.0.0.0:443 ssl;
                ...
            }
        - Return port number.
        - If read failed, set to default 443.
    """
    
    default_port = 443
    nginx_site_paths = [
        "/etc/nginx/sites-enabled/default",
    ]

    if not is_linux():
        return default_port

    try:
        import crossplane  # type: ignore
    except Exception as e:
        logger.warning(f"read_vyos_api_port: crossplane not available: {e}")
        return default_port

    ssl_candidates: list[int] = []
    non_ssl_candidates: list[int] = []

    def _extract_port_from_listen_args(args: list[str]):
        for token in args:
            token = str(token).strip()
            if token.isdigit():
                try:
                    return int(token)
                except Exception:
                    continue

            port_match = re.search(r":(?P<port>\d+)$", token)
            if port_match:
                try:
                    return int(port_match.group("port"))
                except Exception:
                    continue
        return None

    def _iter_directives(directives):
        if not isinstance(directives, list):
            return
        for directive in directives:
            if not isinstance(directive, dict):
                continue
            yield directive
            block = directive.get("block")
            if isinstance(block, list):
                yield from _iter_directives(block)

    def _server_blocks_from_parsed(directives):
        for directive in _iter_directives(directives):
            if directive.get("directive") == "server" and isinstance(directive.get("block"), list):
                yield directive

    parsed_any = False
    for nginx_site_path in nginx_site_paths:
        if not os.path.exists(nginx_site_path):
            continue

        try:
            result = crossplane.parse(
                nginx_site_path,
                single=True,
                check_ctx=False,
            )
        except Exception as e:
            logger.warning(f"read_vyos_api_port: crossplane failed to parse {nginx_site_path}: {e}")
            continue

        if not isinstance(result, dict) or result.get("status") != "ok":
            logger.warning(f"read_vyos_api_port: unexpected crossplane parse result for {nginx_site_path}")
            continue

        config = result.get("config")
        if not isinstance(config, list):
            continue

        parsed_any = True

        for cfg in config:
            parsed = cfg.get("parsed")
            if not isinstance(parsed, list):
                continue

            for server in _server_blocks_from_parsed(parsed):
                block = server.get("block", [])
                if not isinstance(block, list):
                    continue

                for directive in block:
                    if not isinstance(directive, dict):
                        continue
                    if directive.get("directive") != "listen":
                        continue

                    args = directive.get("args") or []
                    if not isinstance(args, list):
                        continue

                    port = _extract_port_from_listen_args(args)
                    if not port:
                        continue

                    is_ssl = any(str(arg).lower() == "ssl" for arg in args)
                    if is_ssl:
                        ssl_candidates.append(port)
                    else:
                        non_ssl_candidates.append(port)

    if not parsed_any:
        return default_port

    if ssl_candidates:
        return ssl_candidates[0]

    if non_ssl_candidates:
        for p in non_ssl_candidates:
            if p != 80:
                return p
        return non_ssl_candidates[0]

    return default_port
