from pydantic import BaseModel
from pydantic import StrictStr
from pydantic import ConfigDict

from typing import Optional
from typing import List
from typing import Dict
from typing import Union


class RadiusServerDTO(BaseModel):
    model_config = ConfigDict(extra="allow")


class UpdateRadiusDTO(BaseModel):
    model_config = ConfigDict(extra="allow")

    server: Optional[Dict[StrictStr, Dict]] = None
    security_mode: Optional[StrictStr] = None
    source_address: Optional[Union[List[StrictStr], StrictStr]] = None


class UpdateTacacsDTO(BaseModel):
    model_config = ConfigDict(extra="allow")

    server: Optional[Dict[StrictStr, Dict]] = None
    security_mode: Optional[StrictStr] = None
    source_address: Optional[Union[List[StrictStr], StrictStr]] = None
    timeout: Optional[StrictStr] = None


class BannerDTO(BaseModel):
    pre_login: Optional[StrictStr] = None
    post_login: Optional[StrictStr] = None


class OtherOptionsDTO(BaseModel):
    model_config = ConfigDict(extra="allow")

    banner: Optional[BannerDTO] = None
    max_sessions: Optional[StrictStr] = None
    timeout: Optional[StrictStr] = None


class UpdateAAADTO(BaseModel):
    model_config = ConfigDict(extra="allow")

    saml: Optional[Dict] = None
    radius: Optional[UpdateRadiusDTO] = None
    tacacs: Optional[UpdateTacacsDTO] = None
    local_users: Optional[List[Dict]] = None
    other_options: Optional[OtherOptionsDTO] = None

    type: Optional[StrictStr] = None
    banner: Optional[BannerDTO] = None
    max_sessions: Optional[StrictStr] = None
    timeout: Optional[StrictStr] = None
