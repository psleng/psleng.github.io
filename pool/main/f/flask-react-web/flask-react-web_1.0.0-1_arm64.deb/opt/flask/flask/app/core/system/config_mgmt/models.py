from typing import Optional

from pydantic import BaseModel, Field, field_validator


COMMIT_REVISIONS_MIN = 1
COMMIT_REVISIONS_MAX = 65535


class UpdateConfigMgmtDTO(BaseModel):
    """`system config-management commit-revisions <1-65535>`.

    ``None`` means the node should be removed from the configuration, which is
    how the UI submits an emptied field.
    """

    commit_revisions: Optional[int] = Field(
        default=None,
        ge=COMMIT_REVISIONS_MIN,
        le=COMMIT_REVISIONS_MAX,
    )

    @field_validator('commit_revisions', mode='before')
    @classmethod
    def empty_string_means_delete(cls, value):
        if isinstance(value, str) and value.strip() == '':
            return None
        return value


class CommitDiffQueryDTO(BaseModel):
    """Two revisions to compare. ``rev2`` defaults to the running config."""

    rev: int = Field(ge=0)
    rev2: Optional[int] = Field(default=None, ge=0)
    commands: bool = False


class ApplyCommitDiffDTO(BaseModel):
    """Apply the `rev` -> `rev2` command set to the running configuration."""

    rev: int = Field(ge=0)
    rev2: Optional[int] = Field(default=None, ge=0)


class ConfigFilePathDTO(BaseModel):
    """A device-side path (or URL) for the save/load config-file operations."""

    path: str = Field(min_length=1, max_length=4096)

    @field_validator('path')
    @classmethod
    def strip_and_require(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError('Configuration file path is required')
        return stripped
