import pprint

def parse_to_snmp_config(config):
    
    if not config:
        return {}
    
    return config
    

def parse_snmp_monitor_community(data):
    print("snmp community:")
    print(pprint.pformat(data, indent=2))
    if 'ShowCommunitiesSnmpQuery' in data and 'data' in data['ShowCommunitiesSnmpQuery'] and \
        'result' in data['ShowCommunitiesSnmpQuery']['data']:
        return data['ShowCommunitiesSnmpQuery']['data']['result']
    return []


def parse_snmp_monitor_mib(data):
    print("snmp mib")
    print(pprint.pformat(data, indent=2))
    if 'ShowIfmibSnmpQuery' in data and 'data' in data['ShowIfmibSnmpQuery'] and \
        'result' in data['ShowIfmibSnmpQuery']['data']:
        return data['ShowIfmibSnmpQuery']['data']['result']
    return []


def parse_snmp_monitor_v3(data):
    print("snmp v3")
    print(pprint.pformat(data, indent=2))
    if 'ShowSnmpV3SnmpQuery' in data and 'data' in data['ShowSnmpV3SnmpQuery'] and \
        'result' in data['ShowSnmpV3SnmpQuery']['data']:
        return data['ShowSnmpV3SnmpQuery']['data']['result']
    return data