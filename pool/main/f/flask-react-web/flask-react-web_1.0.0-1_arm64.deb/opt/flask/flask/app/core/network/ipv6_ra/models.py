from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.log.logger import logger
from pydantic import BaseModel
from typing import List, Optional


class IPv6RAPrefixDTO(BaseModel):
    prefix: str
    decrement_lifetime: Optional[bool] = False
    deprecate_prefix: Optional[bool] = False
    no_autonomous_flag: Optional[bool] = False
    no_on_link_flag: Optional[bool] = False
    preferred_lifetime: Optional[str] = None
    valid_lifetime: Optional[str] = None


class IPv6RARouteDTO(BaseModel):
    prefix: str
    no_remove_route: Optional[bool] = False
    route_preference: Optional[str] = None
    valid_lifetime: Optional[str] = None


class IPv6RAInterfaceDTO(BaseModel):
    interface_name: str
    auto_ignore_prefixes: Optional[List[str]] = []
    default_lifetime: Optional[str] = None
    default_preference: Optional[str] = None
    hop_limit: Optional[str] = None
    interval_max: Optional[str] = None
    interval_min: Optional[str] = None
    link_mtu: Optional[str] = None
    managed_flag: Optional[bool] = False
    name_servers: Optional[List[str]] = []
    name_server_lifetime: Optional[str] = None
    no_send_advert: Optional[bool] = False
    no_send_interval: Optional[bool] = False
    other_config_flag: Optional[bool] = False
    prefixes: Optional[List[IPv6RAPrefixDTO]] = []
    reachable_time: Optional[str] = None
    retrans_timer: Optional[str] = None
    source_addresses: Optional[List[str]] = []
    routes: Optional[List[IPv6RARouteDTO]] = []


class IPv6RADTO(BaseModel):
    interfaces: List[IPv6RAInterfaceDTO]


class IPv6RAAutoIgnore(db.Model):
    __tablename__ = "vyos_config_ipv6_ra_auto_ignore"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ipv6_ra_id = Column(Integer, ForeignKey('vyos_config_ipv6_ra.id', ondelete='CASCADE'), nullable=False)
    prefix = Column(String, nullable=False)
    
    ipv6_ra = relationship("IPv6RA", back_populates="auto_ignore_prefixes")


class IPv6RAPrefix(db.Model):
    __tablename__ = "vyos_config_ipv6_ra_prefix"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ipv6_ra_id = Column(Integer, ForeignKey('vyos_config_ipv6_ra.id', ondelete='CASCADE'), nullable=False)
    prefix = Column(String, nullable=False)
    decrement_lifetime = Column(Boolean, default=False)
    deprecate_prefix = Column(Boolean, default=False)
    no_autonomous_flag = Column(Boolean, default=False)
    no_on_link_flag = Column(Boolean, default=False)
    preferred_lifetime = Column(String, nullable=True)
    valid_lifetime = Column(String, nullable=True)
    
    ipv6_ra = relationship("IPv6RA", back_populates="prefixes")


class IPv6RASourceAddress(db.Model):
    __tablename__ = "vyos_config_ipv6_ra_source_address"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ipv6_ra_id = Column(Integer, ForeignKey('vyos_config_ipv6_ra.id', ondelete='CASCADE'), nullable=False)
    address = Column(String, nullable=False)
    
    ipv6_ra = relationship("IPv6RA", back_populates="source_addresses")


class IPv6RANameServer(db.Model):
    __tablename__ = "vyos_config_ipv6_ra_name_server"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ipv6_ra_id = Column(Integer, ForeignKey('vyos_config_ipv6_ra.id', ondelete='CASCADE'), nullable=False)
    address = Column(String, nullable=False)
    
    ipv6_ra = relationship("IPv6RA", back_populates="name_servers")


class IPv6RARoute(db.Model):
    __tablename__ = "vyos_config_ipv6_ra_route"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ipv6_ra_id = Column(Integer, ForeignKey('vyos_config_ipv6_ra.id', ondelete='CASCADE'), nullable=False)
    prefix = Column(String, nullable=False)
    no_remove_route = Column(Boolean, default=False)
    route_preference = Column(String, nullable=True)
    valid_lifetime = Column(String, nullable=True)
    
    ipv6_ra = relationship("IPv6RA", back_populates="routes")


class IPv6RA(db.Model):
    __tablename__ = "vyos_config_ipv6_ra"

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_name = Column(String, nullable=False, unique=True)
    
    default_lifetime = Column(String, nullable=True)
    default_preference = Column(String, nullable=True)
    hop_limit = Column(String, nullable=True)
    interval_max = Column(String, nullable=True)
    interval_min = Column(String, nullable=True)
    link_mtu = Column(String, nullable=True)
    name_server_lifetime = Column(String, nullable=True)
    reachable_time = Column(String, nullable=True)
    retrans_timer = Column(String, nullable=True)
    
    managed_flag = Column(Boolean, default=False)
    no_send_advert = Column(Boolean, default=False)
    no_send_interval = Column(Boolean, default=False)
    other_config_flag = Column(Boolean, default=False)
    
    auto_ignore_prefixes = relationship("IPv6RAAutoIgnore", back_populates="ipv6_ra", cascade="all, delete-orphan")
    prefixes = relationship("IPv6RAPrefix", back_populates="ipv6_ra", cascade="all, delete-orphan")
    source_addresses = relationship("IPv6RASourceAddress", back_populates="ipv6_ra", cascade="all, delete-orphan")
    name_servers = relationship("IPv6RANameServer", back_populates="ipv6_ra", cascade="all, delete-orphan")
    routes = relationship("IPv6RARoute", back_populates="ipv6_ra", cascade="all, delete-orphan")
    
    @classmethod
    def truncate(cls):
        try:
            db.session.query(IPv6RARoute).delete()
            db.session.query(IPv6RANameServer).delete()
            db.session.query(IPv6RASourceAddress).delete()
            db.session.query(IPv6RAPrefix).delete()
            db.session.query(IPv6RAAutoIgnore).delete()
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            logger.error(f"Error truncating IPv6 RA config: {e}")
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        try:
            logger.debug(f"Refreshing IPv6 RA config with data: {data}")
            
            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()
            
            if not data or not isinstance(data, dict):
                logger.warning("No IPv6 RA data to refresh")
                return
            
            if 'interface' not in data:
                logger.warning("No interface key in IPv6 RA data")
                return
            
            interfaces_data = data['interface']
            if not isinstance(interfaces_data, dict):
                logger.warning("Invalid interface data format")
                return
            
            for interface_name, config in interfaces_data.items():
                if not isinstance(config, dict):
                    continue
                
                default_lifetime = config.get('default-lifetime')
                if isinstance(default_lifetime, dict):
                    default_lifetime = None
                else:
                    default_lifetime = str(default_lifetime) if default_lifetime else None
                
                default_preference = config.get('default-preference')
                if isinstance(default_preference, dict):
                    default_preference = None
                else:
                    default_preference = str(default_preference) if default_preference else None
                
                hop_limit = config.get('hop-limit')
                if isinstance(hop_limit, dict):
                    hop_limit = None
                else:
                    hop_limit = str(hop_limit) if hop_limit else None
            
                interval_max = None
                interval_min = None
                if 'interval' in config and isinstance(config['interval'], dict):
                    interval_data = config['interval']
                    max_val = interval_data.get('max')
                    if max_val and not isinstance(max_val, dict):
                        interval_max = str(max_val)
                    min_val = interval_data.get('min')
                    if min_val and not isinstance(min_val, dict):
                        interval_min = str(min_val)
                
                link_mtu = config.get('link-mtu')
                if isinstance(link_mtu, dict):
                    link_mtu = None
                else:
                    link_mtu = str(link_mtu) if link_mtu else None
                
                name_server_lifetime = config.get('name-server-lifetime')
                if isinstance(name_server_lifetime, dict):
                    name_server_lifetime = None
                else:
                    name_server_lifetime = str(name_server_lifetime) if name_server_lifetime else None
                
                reachable_time = config.get('reachable-time')
                if isinstance(reachable_time, dict):
                    reachable_time = None
                else:
                    reachable_time = str(reachable_time) if reachable_time else None
                
                retrans_timer = config.get('retrans-timer')
                if isinstance(retrans_timer, dict):
                    retrans_timer = None
                else:
                    retrans_timer = str(retrans_timer) if retrans_timer else None
                
                managed_flag = 'managed-flag' in config
                no_send_advert = 'no-send-advert' in config
                no_send_interval = 'no-send-interval' in config
                other_config_flag = 'other-config-flag' in config
                
                new_ipv6_ra = cls(
                    interface_name=interface_name,
                    default_lifetime=default_lifetime,
                    default_preference=default_preference,
                    hop_limit=hop_limit,
                    interval_max=interval_max,
                    interval_min=interval_min,
                    link_mtu=link_mtu,
                    name_server_lifetime=name_server_lifetime,
                    reachable_time=reachable_time,
                    retrans_timer=retrans_timer,
                    managed_flag=managed_flag,
                    no_send_advert=no_send_advert,
                    no_send_interval=no_send_interval,
                    other_config_flag=other_config_flag
                )
                
                if app_context:
                    with app_context:
                        db.session.add(new_ipv6_ra)
                        db.session.flush()
                else:
                    db.session.add(new_ipv6_ra)
                    db.session.flush()
                
                if 'auto-ignore' in config:
                    auto_ignore = config['auto-ignore']
                    if not isinstance(auto_ignore, list):
                        auto_ignore = [auto_ignore] if auto_ignore else []
                    
                    for prefix in auto_ignore:
                        if prefix and not isinstance(prefix, dict):
                            ignore_record = IPv6RAAutoIgnore(
                                ipv6_ra_id=new_ipv6_ra.id,
                                prefix=str(prefix)
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(ignore_record)
                            else:
                                db.session.add(ignore_record)
                
                if 'prefix' in config:
                    prefixes = config['prefix']
                    if isinstance(prefixes, dict):
                        for prefix_key, prefix_config in prefixes.items():
                            if prefix_key and not isinstance(prefix_key, dict):
                                decrement_lifetime = False
                                deprecate_prefix = False
                                no_autonomous_flag = False
                                no_on_link_flag = False
                                preferred_lifetime = None
                                valid_lifetime = None
                                
                                if isinstance(prefix_config, dict):
                                    decrement_lifetime = 'decrement-lifetime' in prefix_config
                                    deprecate_prefix = 'deprecate-prefix' in prefix_config
                                    no_autonomous_flag = 'no-autonomous-flag' in prefix_config
                                    no_on_link_flag = 'no-on-link-flag' in prefix_config
                                    
                                    pref_lifetime = prefix_config.get('preferred-lifetime')
                                    if pref_lifetime and not isinstance(pref_lifetime, dict):
                                        preferred_lifetime = str(pref_lifetime)
                                    
                                    valid_lt = prefix_config.get('valid-lifetime')
                                    if valid_lt and not isinstance(valid_lt, dict):
                                        valid_lifetime = str(valid_lt)
                                
                                prefix_record = IPv6RAPrefix(
                                    ipv6_ra_id=new_ipv6_ra.id,
                                    prefix=str(prefix_key),
                                    decrement_lifetime=decrement_lifetime,
                                    deprecate_prefix=deprecate_prefix,
                                    no_autonomous_flag=no_autonomous_flag,
                                    no_on_link_flag=no_on_link_flag,
                                    preferred_lifetime=preferred_lifetime,
                                    valid_lifetime=valid_lifetime
                                )
                                if app_context:
                                    with app_context:
                                        db.session.add(prefix_record)
                                else:
                                    db.session.add(prefix_record)
                    elif isinstance(prefixes, list):
                        for prefix in prefixes:
                            if prefix and not isinstance(prefix, dict):
                                prefix_record = IPv6RAPrefix(
                                    ipv6_ra_id=new_ipv6_ra.id,
                                    prefix=str(prefix),
                                    decrement_lifetime=False,
                                    deprecate_prefix=False,
                                    no_autonomous_flag=False,
                                    no_on_link_flag=False,
                                    preferred_lifetime=None,
                                    valid_lifetime=None
                                )
                                if app_context:
                                    with app_context:
                                        db.session.add(prefix_record)
                                else:
                                    db.session.add(prefix_record)
                    else:
                        if prefixes and not isinstance(prefixes, dict):
                            prefix_record = IPv6RAPrefix(
                                ipv6_ra_id=new_ipv6_ra.id,
                                prefix=str(prefixes),
                                decrement_lifetime=False,
                                deprecate_prefix=False,
                                no_autonomous_flag=False,
                                no_on_link_flag=False,
                                preferred_lifetime=None,
                                valid_lifetime=None
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(prefix_record)
                            else:
                                db.session.add(prefix_record)
                
                if 'source-address' in config:
                    source_addrs = config['source-address']
                    if not isinstance(source_addrs, list):
                        source_addrs = [source_addrs] if source_addrs else []
                    
                    for addr in source_addrs:
                        if addr and not isinstance(addr, dict):
                            addr_record = IPv6RASourceAddress(
                                ipv6_ra_id=new_ipv6_ra.id,
                                address=str(addr)
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(addr_record)
                            else:
                                db.session.add(addr_record)
                
                if 'name-server' in config:
                    name_servers = config['name-server']
                    if not isinstance(name_servers, list):
                        name_servers = [name_servers] if name_servers else []
                    
                    for ns in name_servers:
                        if ns and not isinstance(ns, dict):
                            ns_record = IPv6RANameServer(
                                ipv6_ra_id=new_ipv6_ra.id,
                                address=str(ns)
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(ns_record)
                            else:
                                db.session.add(ns_record)
                
                if 'route' in config:
                    routes = config['route']
                    if isinstance(routes, dict):
                        for route_prefix, route_config in routes.items():
                            if not isinstance(route_config, dict):
                                route_config = {}
                            
                            no_remove = 'no-remove-route' in route_config
                            route_pref = route_config.get('route-preference')
                            if isinstance(route_pref, dict):
                                route_pref = None
                            else:
                                route_pref = str(route_pref) if route_pref else None
                            
                            valid_lifetime = route_config.get('valid-lifetime')
                            if isinstance(valid_lifetime, dict):
                                valid_lifetime = None
                            else:
                                valid_lifetime = str(valid_lifetime) if valid_lifetime else None
                            
                            route_record = IPv6RARoute(
                                ipv6_ra_id=new_ipv6_ra.id,
                                prefix=str(route_prefix),
                                no_remove_route=no_remove,
                                route_preference=route_pref,
                                valid_lifetime=valid_lifetime
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(route_record)
                            else:
                                db.session.add(route_record)
            
            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
        except Exception as e:
            logger.error(f"Error refreshing IPv6 RA data: {e}")

    def serialize(self):
        
        return {
            'interface_name': self.interface_name,
            'default_lifetime': self.default_lifetime,
            'default_preference': self.default_preference,
            'hop_limit': self.hop_limit,
            'interval_max': self.interval_max,
            'interval_min': self.interval_min,
            'link_mtu': self.link_mtu,
            'name_server_lifetime': self.name_server_lifetime,
            'reachable_time': self.reachable_time,
            'retrans_timer': self.retrans_timer,
            'managed_flag': self.managed_flag,
            'no_send_advert': self.no_send_advert,
            'no_send_interval': self.no_send_interval,
            'other_config_flag': self.other_config_flag,
            'auto_ignore_prefixes': [p.prefix for p in self.auto_ignore_prefixes],
            'prefixes': [
                {
                    'prefix': p.prefix,
                    'decrement_lifetime': p.decrement_lifetime,
                    'deprecate_prefix': p.deprecate_prefix,
                    'no_autonomous_flag': p.no_autonomous_flag,
                    'no_on_link_flag': p.no_on_link_flag,
                    'preferred_lifetime': p.preferred_lifetime,
                    'valid_lifetime': p.valid_lifetime
                }
                for p in self.prefixes
            ],
            'source_addresses': [a.address for a in self.source_addresses],
            'name_servers': [ns.address for ns in self.name_servers],
            'routes': [
                {
                    'prefix': r.prefix,
                    'no_remove_route': r.no_remove_route,
                    'route_preference': r.route_preference,
                    'valid_lifetime': r.valid_lifetime
                }
                for r in self.routes
            ]
        }
