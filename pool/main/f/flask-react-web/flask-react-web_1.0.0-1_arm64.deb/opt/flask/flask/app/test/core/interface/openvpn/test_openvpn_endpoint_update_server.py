import pytest
import json
import requests
from app.core.api.http.http_request import Action
import pprint

class TestOpenVPNEndpointUpdateServer:

    @classmethod
    def setup_class(cls):
        
        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as e:
            print(f"Registration error (user may already exist): {e}")

    def _delete_and_login(self, test_service_provider):
        
        DELETE_OPENVPN = '{"op": "delete", "path": ["interfaces", "openvpn"]}'
        delete_response = test_service_provider.http_service.send_request(
            action=Action.CONFIGURE, data=DELETE_OPENVPN, verify=False
        )
        
        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def _get_initial_config(self):
        """Returns the initial server configuration following config_condition.md rules"""
        return {
            "general": {
                "name": "vtun0",
                "description": "Initial Server Config",
                "mode": "server",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localHost": ["192.168.1.1"],
                "localPort": "1194",  
                "localAddress": None,
                "protocol": "udp",
                "server": {
                    "bridge": "",
                    "subnet": "10.8.0.0/24", 
                    "topology": "subnet",
                    "domainName": "vpn.example.com",
                    "maxConnections": 100,
                    "nameServer": ["8.8.8.8"],
                    "clients": [],
                    "clientIpPool": {
                        "disabled": False,
                        "start": "10.8.0.100",
                        "stop": "10.8.0.200",
                        "subnetMask": "255.255.255.0"
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": ["192.168.1.0/24"],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": True,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ['testCA'],
                    "certificate": ['testCert'],
                    "cryptKey": [],
                    "dhParams": "test-dh",  
                    "peerFingerprint": [],
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "",
                    "dataCiphers": []
                },
                "hash": {
                    "algorithm": "sha256"
                }
            }
        }

    def test_update_endpoint_modify_all_fields(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_initial_config()
        print("\n=== Creating Initial Server Configuration ===")
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to create initial config: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print("Initial server config created successfully")
        
        # Update ALL fields
        import copy
        updated_config = copy.deepcopy(initial_config)
        
        updated_config["general"]["description"] = "Comprehensive Server Update Test"
        updated_config["general"]["enabled"] = True
        
        updated_config["openvpn"]["localHost"] = ["192.168.10.1"]
        updated_config["openvpn"]["localPort"] = "1195"
        
        updated_config["openvpn"]["server"]["subnet"] = "10.9.0.0/24"
        updated_config["openvpn"]["server"]["topology"] = "net30"
        updated_config["openvpn"]["server"]["domainName"] = "updated-vpn.example.com"
        updated_config["openvpn"]["server"]["maxConnections"] = 500
        updated_config["openvpn"]["server"]["nameServer"] = ["1.1.1.1", "8.8.8.8"]
        updated_config["openvpn"]["server"]["pushRoutes"] = ["192.168.10.0/24", "10.0.0.0/8"]
        updated_config["openvpn"]["server"]["rejectUnconfiguredClients"] = True
        updated_config["openvpn"]["server"]["clientIpPool"]["disabled"] = False
        updated_config["openvpn"]["server"]["clientIpPool"]["start"] = "10.9.0.100"
        updated_config["openvpn"]["server"]["clientIpPool"]["stop"] = "10.9.0.200"
        updated_config["openvpn"]["server"]["clientIpPool"]["subnetMask"] = "255.255.255.0"
        
        updated_config["openvpn"]["advanced"]["keepAlive"]["interval"] = 20
        updated_config["openvpn"]["advanced"]["keepAlive"]["failureCount"] = 5
        updated_config["openvpn"]["advanced"]["persistentTunnel"] = False
        updated_config["openvpn"]["advanced"]["useLzoCompression"] = False
        updated_config["openvpn"]["advanced"]["replaceDefaultRoute"] = True
        
        updated_config["security"]["tls"]["tlsVersionMin"] = "1.3"
        updated_config["security"]["tls"]["dhParams"] = "test-dh-2"
        updated_config["security"]["encryption"]["dataCiphers"] = ["aes256", "aes128"]
        updated_config["security"]["hash"]["algorithm"] = "sha512"
        
        print("\n=== Updating ALL Server Configuration Fields ===")
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to update config: {response.text}"
        
        response_data = response.json()
        print("\n=== Update Commands Generated ===")
        for item in response_data:
            print(f"Command: {item.get('cmd', 'N/A')}")
            print(f"Success: {item.get('success', False)}")
            if not item.get('success', False):
                print(f"Update failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print("\nServer config updated successfully")
        
        print("\n=== Retrieving Updated Configuration ===")
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, 
            data=FETCH_OPENVPN, 
            verify=False
        )
        
        fetched_config = fetch_response.json()
        print("\n=== Fetched Configuration ===")
        pprint.pprint(fetched_config)
        
        assert 'data' in fetched_config, "data field not found in response"
        assert 'openvpn' in fetched_config['data'], "openvpn field not found in data"
        assert 'vtun0' in fetched_config['data']['openvpn'], "vtun0 not found in config"
        
        vtun0_config = fetched_config['data']['openvpn']['vtun0']
        
        print("\n=== Verifying All Updated Server Fields ===")
        
        assert vtun0_config['description'] == 'Comprehensive_Server_Update_Test', \
            f"Description mismatch: {vtun0_config.get('description')}"
        print("+ Description updated")
        
        assert vtun0_config['local-port'] == '1195', \
            f"Local port mismatch: {vtun0_config.get('local-port')}"
        print("+ Local port updated")
        
        # Verify NO remote-host
        assert 'remote-host' not in vtun0_config, \
            "Server mode should not have remote-host"
        print("+ Remote host correctly absent (server mode)")
        
        # Verify NO remote-port
        assert 'remote-port' not in vtun0_config, \
            "Server mode should not have remote-port"
        print("+ Remote port correctly absent (server mode)")
        
        # Verify NO remote-address
        assert 'remote-address' not in vtun0_config, \
            "Server mode should not have remote-address"
        print("+ Remote address correctly absent (server mode)")
        
        assert vtun0_config['server']['subnet'] == '10.9.0.0/24', \
            f"Subnet mismatch: {vtun0_config['server'].get('subnet')}"
        print("+ Subnet updated")
        
        assert vtun0_config['server']['topology'] == 'net30', \
            f"Topology mismatch: {vtun0_config['server'].get('topology')}"
        print("+ Topology updated")
        
        assert vtun0_config['server']['domain-name'] == 'updated-vpn.example.com', \
            f"Domain name mismatch: {vtun0_config['server'].get('domain-name')}"
        print("+ Domain name updated")
        
        assert vtun0_config['server']['max-connections'] == '500', \
            f"Max connections mismatch: {vtun0_config['server'].get('max-connections')}"
        print("+ Max connections updated")
        
        assert '1.1.1.1' in vtun0_config['server']['name-server'], \
            f"Name server mismatch: {vtun0_config['server'].get('name-server')}"
        print("+ Name servers updated")
        
        assert '192.168.10.0/24' in vtun0_config['server']['push-route'], \
            f"Push route mismatch: {vtun0_config['server'].get('push-route')}"
        print("+ Push routes updated")
        
        assert 'reject-unconfigured-clients' in vtun0_config['server'], \
            "Reject unconfigured clients should be set"
        print("+ Reject unconfigured clients enabled")
        
        assert vtun0_config['server']['client-ip-pool']['start'] == '10.9.0.100', \
            f"Client IP pool start mismatch: {vtun0_config['server']['client-ip-pool'].get('start')}"
        print("+ Client IP pool start updated")
        
        assert vtun0_config['server']['client-ip-pool']['stop'] == '10.9.0.200', \
            f"Client IP pool stop mismatch: {vtun0_config['server']['client-ip-pool'].get('stop')}"
        print("+ Client IP pool stop updated")
        
        assert vtun0_config['keep-alive']['interval'] == '20', \
            f"Keepalive interval mismatch: {vtun0_config['keep-alive'].get('interval')}"
        print("+ Keepalive interval updated")
        
        assert vtun0_config['keep-alive']['failure-count'] == '5', \
            f"Keepalive failure count mismatch: {vtun0_config['keep-alive'].get('failure-count')}"
        print("+ Keepalive failure count updated")
        
        assert 'persistent-tunnel' not in vtun0_config, \
            "Persistent tunnel should be disabled"
        print("+ Persistent tunnel disabled")
        
        assert 'use-lzo-compression' not in vtun0_config, \
            "LZO compression should be disabled"
        print("+ LZO compression disabled")
        
        assert vtun0_config['hash'] == 'sha512', \
            f"Hash algorithm mismatch: {vtun0_config.get('hash')}"
        print("+ Hash algorithm updated")
        
        assert vtun0_config['tls']['tls-version-min'] == '1.3', \
            f"TLS version mismatch: {vtun0_config['tls'].get('tls-version-min')}"
        print("+ TLS version updated")
        
        assert vtun0_config['tls']['dh-params'] == 'test-dh-2', \
            f"DH params mismatch: {vtun0_config['tls'].get('dh-params')}"
        print("+ DH params updated (server mode)")
        
        # Verify NO tls role
        assert 'role' not in vtun0_config['tls'], \
            "Server mode should not have TLS role"
        print("+ TLS role correctly absent (server mode)")
        
        assert 'aes256' in vtun0_config['encryption']['data-ciphers'], \
            f"Data ciphers mismatch: {vtun0_config['encryption'].get('data-ciphers')}"
        print("+ Data ciphers updated")
        
        print("\n" + "="*50)
        print("ALL SERVER FIELDS SUCCESSFULLY UPDATED AND VERIFIED!")
        print("="*50)