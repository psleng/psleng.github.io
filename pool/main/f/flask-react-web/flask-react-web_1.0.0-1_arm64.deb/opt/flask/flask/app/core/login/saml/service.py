from app.core.api.http.http_request import Action, SHOW_SAML_CONFIG
import json


def auth_saml(provider, data):
    """Handle SAML auth operations using the new /auth endpoint format."""
    saml_type = data.get("type")

    if saml_type == "AUTH":
        relay_state = data.get("RelayState", "")
        hostname = data.get("hostname", "127.0.0.1")
        api_data = {
            "op": "login",
            "service": "saml",
            "hostname": hostname,
            "relay_state": relay_state,
        }
        resp = provider.http_service.send_request(
            action=Action.AUTH,
            data=json.dumps(api_data),
            verify=False,
        )
        resp_json = resp.json()
        if resp_json.get("success") != True:
            raise Exception(f"{resp_json.get('error', 'Unknown error')}")

        resp_data = resp_json.get("data")
        # The SP returns {url: "https://.../login/s/<token>", secret: "..."}
        # Extract session token from the URL path and return both
        login_url = resp_data.get("url", "")
        session_token = login_url.rstrip("/").rsplit("/", 1)[-1] if login_url else ""
        return {
            "sso_url": login_url,
            "session": session_token,
            "secret": resp_data.get("secret", ""),
        }

    elif saml_type == "CHECK_AUTH":
        session_key = data.get("session", "")
        secret = data.get("secret", "")
        api_data = {
            "op": "validate",
            "service": "saml",
            "session": session_key,
            "secret": secret,
        }
        resp = provider.http_service.send_request(
            action=Action.AUTH,
            data=json.dumps(api_data),
            verify=False,
        )
        resp_json = resp.json()
        if resp_json.get("success") != True:
            raise Exception(f"{resp_json.get('error', 'Unknown error')}")

        resp_data = resp_json.get("data")
        # Map new response shape to what the route expects
        return {
            "auth_status": resp_data.get("status"),
            "auth_level": resp_data.get("level"),
            "user_id": resp_data.get("name"),
            "local_name": resp_data.get("local_name"),
        }

    else:
        raise Exception(f"Unknown SAML auth type: {saml_type}")


def fetch_saml_config(provider, data):
    data = provider.http_service.send_request(
        action=Action.RETRIEVE, data=SHOW_SAML_CONFIG, verify=False
    )

    # VyOS's /retrieve returns HTTP 400 when the config path is not present
    # (e.g. SAML has never been configured on this device). That's not a real
    # error for us — the login page just needs to know there is no SAML config
    # yet, so surface it as an empty dict rather than raising.
    if data.status_code == 400:
        return {}

    data_json = data.json()
    if data_json.get("success") != True:
        raise Exception(f"{data_json.get('error', 'Unknown error')}")

    saml_config = data_json.get("data")
    if saml_config is None:
        return {}
    return saml_config


def fetch_saml_info(provider, data):
    api_data = {"op": "SAML", "data": {"type": "INFO"}}

    resp = provider.http_service.send_request(
        action=Action.AUTH, data=json.dumps(api_data), verify=False
    )

    resp_json = resp.json()
    if resp_json.get("success") != True:
        raise Exception(f"{resp_json.get('error', 'Unknown error')}")

    resp_data = resp_json.get("data")
    return resp_data
