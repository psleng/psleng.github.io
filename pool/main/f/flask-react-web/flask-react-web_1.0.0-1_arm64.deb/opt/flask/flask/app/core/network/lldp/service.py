import json
from uuid import uuid4

from flask import session

from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.api.http.http_request import Action
from app.core.network.lldp.command_lldp import LLDPCommand
from app.core.network.lldp.config import verification_config
from app.core.network.lldp.models import LLDPConfig
from app.core.utils.validate.verify_parser import format_verify
from app.log.logger import logger
from app.socket.socket_manager import socket_manager

VERIFY_SERVICE = 'service_lldp'


def update_lldp(provider, data):
    logger.info('Update LLDP configuration')
    username = session.get('username')
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff') or {}

    if config is None:
        if current_config is None:
            LLDPConfig.truncate()
            return []

        delete_command = LLDPCommand(operator='delete', resource='service')
        delete_command.generate(*LLDPCommand.BASE_PATH)
        commands = delete_command.cmds
        response = provider.http_service.send_request(
            action=Action.CONFIGURE, data=commands, verify=False,
        )
        result = response.json()
        if not result.get('success'):
            return [{'cmd': commands, 'success': False, 'error': result.get('error') or 'Failed to delete LLDP configuration'}]
        response.raise_for_status()
        LLDPConfig.truncate()
        socket_manager.emit_to_user(username, event='notification', data={
            'id': str(uuid4()), 'type': 'ignore', 'title': 'Success: Delete LLDP',
            'content': 'LLDP configuration deleted successfully',
        })
        return [{'cmd': commands, 'success': True, 'error': None}]

    set_command = LLDPCommand(operator='set', resource='service')
    set_commands = set_command.generate_commands(
        data=diff.get('created') or {}, current_config=current_config, new_config=config,
    )
    if not config and current_config != {}:
        set_command.generate(*LLDPCommand.BASE_PATH)
        set_commands = set_command.cmds
    delete_command = LLDPCommand(operator='delete', resource='service')
    delete_commands = delete_command.generate_commands(
        data=diff.get('deleted') or {}, current_config=current_config, new_config=config,
    )
    commands = list(dict.fromkeys(delete_commands + set_commands))

    verify = verify_lldp(provider, config)
    error = '' if verify in (None, {}, '', 'None', 'null') else format_verify(str(verify))
    if error:
        return [{'cmd': commands, 'success': False, 'error': error}]

    results = []
    if commands:
        response = provider.http_service.send_request(
            action=Action.CONFIGURE, data=commands, verify=False,
        )
        result = response.json()
        if not result.get('success'):
            return [{'cmd': commands, 'success': False, 'error': result.get('error') or 'Failed to update LLDP configuration'}]
        response.raise_for_status()
        results.append({'cmd': commands, 'success': True, 'error': None})

    LLDPConfig.refresh(config)
    if commands:
        socket_manager.emit_to_user(username, event='notification', data={
            'id': str(uuid4()), 'type': 'ignore', 'title': 'Success: Update LLDP',
            'content': 'LLDP is successfully updated',
        })
    return results


def verify_lldp(provider, data):
    if data is None:
        return None
    context = provider.verify_service.call_get_config(VERIFY_SERVICE) or {}
    if 'snmp' in data and 'system_snmp_enabled' not in context:
        snmp_config = provider.verify_service.call_get_config('snmp') or {}
        if not snmp_config or 'deleted' in snmp_config:
            return 'SNMP must be configured to enable LLDP SNMP!'
        context['system_snmp_enabled'] = ''
    return provider.verify_service.call_verify(VERIFY_SERVICE, verification_config(data, context))


def fetch_lldp_config(provider, data=None):
    response = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_ALL_CONFIGS,
        verify=False,
    )
    payload = response.json()
    if not payload.get('success'):
        raise ValueError(payload.get('error') or 'Failed to load LLDP configuration')
    response.raise_for_status()
    config = payload.get('data') or {}
    return (config.get('service') or {}).get('lldp')


def fetch_lldp_neighbors(provider, data=None):
    params = {'detail': 'true'}
    if (data or {}).get('interface'):
        params['interface'] = json.dumps(data['interface'])
    response = provider.graphql_service.send_request(
        function_name='ShowNeighborsLldp', data=params, verify=False,
    )
    response.raise_for_status()
    payload = response.json()
    query = (payload.get('data') or {}).get('ShowNeighborsLldp') or {}
    if payload.get('errors') or not query.get('success'):
        raise ValueError(query.get('errors') or payload.get('errors') or 'Failed to load LLDP neighbors')
    return (query.get('data') or {}).get('result') or {}
