from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.service.config import refresh_config, refresh_service_stat, init_service_stat
from app.log.logger import logger
from app.config import global_config
from datetime import datetime, timedelta
from flask import session
from app.core.models import Services, AdminSelectedService
from app.db.database import db
from flask import jsonify
import traceback
   
def fetch_os_config(app_context):
    try:
        os_config = refresh_db_os_config(app_context=app_context)
        return os_config
    except Exception as e:
        logger.error("Fetch OS config failed: ")
        logger.error(str(e))
        return None


def refresh_db_os_config(app_context=None):
    res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)

    retry_job_id = 'fetch_os_config_5s'
    if isinstance(res, Exception) or not res:
        logger.debug("OS config fetch returned empty or invalid data, scheduling retry in 5 seconds")

        scheduler = global_config.app_scheduler
        if scheduler and scheduler.get_job(id=retry_job_id) is None:
            run_time = datetime.now() + timedelta(seconds=5)
            scheduler.add_job(
                id=retry_job_id,
                func=fetch_os_config,
                args=[app_context],
                trigger="date",
                run_date=run_time,
                misfire_grace_time=10,
                coalesce=True,
                max_instances=1
            )
            logger.debug(f"Scheduled retry job '{retry_job_id}' to run at {run_time}")

        return None

    scheduler = global_config.app_scheduler
    if scheduler and scheduler.get_job(id=retry_job_id) is not None:
        scheduler.remove_job(retry_job_id)
        logger.debug(f"Removed retry job '{retry_job_id}' as valid data was received")

    config_data = res

    if app_context is not None:
        with app_context:
            refresh_config(config_data)
    else:
        refresh_config(config_data)

    return config_data


def fetch_init_service_stat(app_context):
    try:
        service_stat = init_db_service_stat(app_context=app_context)
        return service_stat
    except Exception as e:
        logger.error("Fetch service stat failed: ")
        logger.error(str(e))
        return None

def init_db_services():
    try:

        Services.init_services()
    except Exception as e:
        logger.error("Initialize services failed: ")
        logger.error(str(e))

def init_admin_selected_services():
    print("Initializing admin selected services...")
    try:

        exists_row = db.session.query(AdminSelectedService.id).first()

        if exists_row is None:
            AdminSelectedService.init_admin_services() 

    except Exception as e:
        logger.error("Initialize admin services failed: ")
        logger.error(str(e))
        return None
    

def fetch_service_stat(app_context):
    try:
        with app_context:
            return refresh_db_service_stat(app_context=app_context)
    except Exception as e:

        logger.error("Fetch service stat failed")
        logger.error("".join(traceback.format_exception(type(e), e, e.__traceback__)))
        return None


def refresh_db_service_stat(app_context=None):
    logger.debug("Refreshing service stat...")
    selected = AdminSelectedService.query.all()
    selected_service_ids = [s.service_id for s in selected] if selected else []

    services = Services.query.filter(Services.id.in_(selected_service_ids)).all() if selected_service_ids else []
    selected_service_names = [s.name for s in services]

    service_api_targets = {
        "DHCP": API_TARGET.DHCP_POOL_STATISTICS,
        "NTP": API_TARGET.NTP_SYSTEM,
        "DNS": API_TARGET.DNS_NAMESERVERS,
        "NAT": API_TARGET.NAT_STAT,
        "Firewall": API_TARGET.FIREWALL_QUERY_GQL,
        "Wireguard": API_TARGET.INTERFACE_WIREGUARD,
        "IPSEC": API_TARGET.IPSEC_STAT,
        "VRRP": API_TARGET.VRRP,
        "SNMP": API_TARGET.SNMP_STATS,
        "Load Balancing": API_TARGET.WAN_LOAD_BALANCING_MONITOR,
        #"OpenVPN": API_TARGET.OPENVPN_STAT
    }

    service_stat = {}

    logger.debug(f"Selected services for stat refresh: {selected_service_names}")
    for service in selected_service_names:
        api_target = service_api_targets.get(service)

        if not api_target:
            continue

        try:
            if api_target == API_TARGET.NAT_STAT:
                src = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={"direction": "source"})
                dst = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={"direction": "destination"})

                service_stat[service] = {
                    "source": src,
                    "destination": dst,
                }

            elif api_target == API_TARGET.WAN_LOAD_BALANCING_MONITOR:
                service_stat[service] = api_manager.call(
                    action=API_ACTION.MONITOR,
                    target=API_TARGET.WAN_LOAD_BALANCING_MONITOR,
                    data={"target": "summary"},
                )

            else:
                stat = api_manager.call(action=API_ACTION.READ, target=api_target)
                service_stat[service] = stat

        except Exception as e:
            logger.exception("Failed to fetch stats")
            service_stat[service] = {"error": str(e)}
    logger.debug('service_stat:', service_stat)
    logger.debug(selected_service_names)
    if app_context is not None:
        with app_context:
            refresh_service_stat(service_stat)
    else:
        refresh_service_stat(service_stat)

    return service_stat


def init_db_service_stat(app_context=None):

    if app_context is not None:
        with app_context:
            init_service_stat()
    else:
        init_service_stat()

    return None
