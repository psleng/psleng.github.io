import json
import os
import shutil
import threading
from datetime import datetime
from uuid import uuid4

from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.manager import api_manager
from app.core.operation.models import SoftwareUpdateJob
from app.db import db
from app.event.jobs.system.save_config import save_running_config
from app.log.logger import logger


ACTIVE_STATES = ("queued", "applying")


def _format_error(error):
    if error is None:
        return None
    if isinstance(error, str):
        return error
    if isinstance(error, list):
        return "\n".join(filter(None, (_format_error(item) for item in error)))
    if isinstance(error, dict):
        return str(error.get("message")) if error.get("message") else json.dumps(error)
    return str(error)


def delete_temporary_image(path):
    if not path:
        return
    try:
        if os.path.isfile(path):
            os.remove(path)
        parent = os.path.dirname(path)
        if os.path.isdir(parent):
            shutil.rmtree(parent, ignore_errors=True)
    except Exception as exc:
        logger.warning(f"Failed to delete temporary software image {path}: {exc}")


def _run_job(app, job_id, options):
    with app.app_context():
        job = db.session.get(SoftwareUpdateJob, job_id)
        if not job:
            return
        try:
            job.state = "applying"
            job.started_at = datetime.utcnow()
            db.session.commit()

            update_options = dict(options)
            update_options.pop('reboot_after_update', None)
            response_data = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.SYSTEM_IMAGE,
                data={"location": job.source, **update_options},
            )
            response = response_data.get("response")
            body = response_data.get("response_data") or {}
            status_code = getattr(response, "status_code", 200)
            errors = response_data.get("errors") or body.get("errors")
            if status_code >= 400 or response_data.get("success") is False or errors:
                raise RuntimeError(_format_error(errors or body.get("error")) or "Failed to update software image")

            job.state = "succeeded"
            job.message = "Software image update completed"
        except Exception as exc:
            db.session.rollback()
            job = db.session.get(SoftwareUpdateJob, job_id)
            if job:
                job.state = "failed"
                job.error = str(exc)
            logger.exception(f"Software update job {job_id} failed")
        finally:
            job = db.session.get(SoftwareUpdateJob, job_id)
            if job:
                delete_temporary_image(job.temporary_path)
                job.temporary_path = None
                job.finished_at = datetime.utcnow()
                db.session.commit()


def create_job(app, user_id, source, temporary_path=None, original_filename=None, options=None):
    active = SoftwareUpdateJob.query.filter(
        SoftwareUpdateJob.state.in_(ACTIVE_STATES),
    ).order_by(SoftwareUpdateJob.created_at.desc()).first()
    if active:
        return active, False

    options = options or {}
    if options.get('reboot_after_update'):
        save_running_config()

    job = SoftwareUpdateJob(
        id=str(uuid4()),
        user_id=str(user_id),
        source=source,
        temporary_path=temporary_path,
        original_filename=original_filename,
        state="queued",
        message="Software image update queued",
    )
    db.session.add(job)
    db.session.commit()
    threading.Thread(target=_run_job, args=(app, job.id, options), daemon=True).start()
    return job, True
