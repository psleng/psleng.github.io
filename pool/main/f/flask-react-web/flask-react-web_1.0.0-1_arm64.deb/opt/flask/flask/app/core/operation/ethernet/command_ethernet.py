from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
from app.core.operation.ip_options.command_ip_options import IPOptionCommand
from app.core.operation.dhcp_options.command_dhcp_options import DHCPOptionCommand
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

def format_description(description: str) -> str:
    return description.replace(' ', '_')

class EthernetCommand(IfaceCommand):
    """
    Ethernet command class:

    - set/delete interfaces ethernet <ethN>
    - set/delete interfaces ethernet <ethN> address {x.x.x.x/n | h:h:h:h:h:h:h:h/x | dhcp | dhcpv6}
    - set/delete interfaces ethernet <ethN> description <text>
    - set/delete interfaces ethernet <ethN> disable
    - set/delete interfaces ethernet <ethN> disable-flow-control
    - set/delete interfaces ethernet <ethN> disable-link-detect
    - set/delete interfaces ethernet <ethN> duplex {auto | half | full}
    - set/delete interfaces ethernet <ethN> speed {auto | 10 | 100 | 1000}
    - set/delete interfaces ethernet <ethN> mtu <68-16000>

    Extra:
    - IP options
    - DHCP options
    
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'ethernet'),
                name=kwargs.get('name', None)
            )
            self.attributes = {
                'interfaces': {
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Ethernet command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
    
    def get_all_commands(self):
        all_cmds = self.cmds.copy()
        return all_cmds
    
    def get_all_vyos_commands(self):
        all_vyos_cmds = self.vyos_cmds.copy()
        return all_vyos_cmds

    def _process_ethernet_interface(self, eth_name, eth_config, current_config, new_config):
        """Process Ethernet interface configuration"""
        base = ['interfaces', 'ethernet', eth_name]
        
        if 'address' in eth_config:
            addresses = eth_config['address']
            if not isinstance(addresses, list):
                addresses = [addresses]
            for addr in addresses:
                if is_str_not_empty(addr):
                    self.generate(*base, 'address', str(addr))
                    addr_lower = str(addr).lower()
                    if addr_lower == 'dhcp' or addr_lower == 'dhcpv6':
                        system_base = ['system', 'name-server', eth_name]
                        if self.operator == 'set':
                            self.generate(*system_base)
                        elif self.operator == 'delete':
                            self.generate(*system_base)
        
        if 'description' in eth_config:
            desc = format_description(eth_config['description'])
            if is_str_not_empty(desc):
                self.generate(*base, 'description', desc)
        
        if 'disable' in eth_config:
            self.generate(*base, 'disable')
        
        if 'disable-flow-control' in eth_config:
            self.generate(*base, 'disable-flow-control')
        
        if 'disable-link-detect' in eth_config:
            self.generate(*base, 'disable-link-detect')
        
        if 'duplex' in eth_config:
            duplex = eth_config['duplex']
            if is_str_not_empty(duplex) and duplex in ['auto', 'half', 'full']:
                self.generate(*base, 'duplex', str(duplex))
        
        if 'speed' in eth_config:
            speed = eth_config['speed']
            if is_str_not_empty(speed) and speed in ['auto', '10', '100', '1000']:
                self.generate(*base, 'speed', str(speed))
        
        if 'mtu' in eth_config:
            mtu = eth_config['mtu']
            if is_str_not_empty(mtu):
                self.generate(*base, 'mtu', str(mtu))
        
        if 'dhcp-options' in eth_config or 'dhcpv6-options' in eth_config:
            dhcp_cmd = DHCPOptionCommand(
                operator=self.operator,
                intf_type="ethernet",
                intf_name=eth_name
            )
            dhcp_data = {}
            if 'dhcp-options' in eth_config:
                dhcp_data['dhcp-options'] = eth_config['dhcp-options']
            if 'dhcpv6-options' in eth_config:
                dhcp_data['dhcpv6-options'] = eth_config['dhcpv6-options']
            
            dhcp_cmd.generate_commands(data=dhcp_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(dhcp_cmd.cmds)
            self.vyos_cmds.extend(dhcp_cmd.vyos_cmds)
        
        if 'ip' in eth_config or 'ipv6' in eth_config:
            ip_cmd = IPOptionCommand(
                operator=self.operator,
                intf_type="ethernet",
                intf_name=eth_name
            )
            ip_data = {}
            if 'ip' in eth_config:
                ip_data['ip'] = eth_config['ip']
            if 'ipv6' in eth_config:
                ip_data['ipv6'] = eth_config['ipv6']
            ip_cmd.generate_commands(data=ip_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(ip_cmd.cmds)
            self.vyos_cmds.extend(ip_cmd.vyos_cmds)

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            for eth_name, config in data.items():
                self._process_ethernet_interface(eth_name, config, current_config, new_config)

            return self.get_all_commands()

        except Exception as e:
            print(f"Error generating Ethernet commands: {e}")
            return []
