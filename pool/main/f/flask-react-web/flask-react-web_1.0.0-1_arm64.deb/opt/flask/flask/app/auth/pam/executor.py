import json
import logging
import math
import os
from pathlib import Path
import signal
import sys
import time

from gevent import Timeout, sleep, spawn
from gevent import subprocess


class PamAuthenticationBusyError(RuntimeError):
    pass


class PamAuthenticationTimeoutError(TimeoutError):
    pass


class PamAuthenticationProcessError(RuntimeError):
    pass


_HELPER_PATH = Path(__file__).with_name("worker.py")
_MAX_MESSAGE_BYTES = 65536
_CLEANUP_TIMEOUT_SECONDS = 1.0
_PIPE_DRAIN_TIMEOUT_SECONDS = 1.0
_POLL_INTERVAL_SECONDS = 0.05
logger = logging.getLogger(__name__)

_active_attempts = set()
_reaping_processes = set()


def _send(process, message):
    payload = (json.dumps(message) + "\n").encode("utf-8")
    if len(payload) > _MAX_MESSAGE_BYTES:
        raise PamAuthenticationProcessError("PAM message exceeds size limit")
    process.stdin.write(payload)
    process.stdin.flush()


def _close_pipes(process):
    for stream in (process.stdin, process.stdout):
        if stream is not None and not stream.closed:
            try:
                stream.close()
            except OSError:
                logger.warning("Failed closing PAM helper pipe (pid=%s)", process.pid)


def _poll_for_exit(process, deadline):
    
    while True:
        return_code = process.poll()
        if return_code is not None:
            return return_code
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        sleep(min(_POLL_INTERVAL_SECONDS, remaining))


def _reap_in_background(process):
    try:
        while process.poll() is None:
            sleep(_POLL_INTERVAL_SECONDS)
        _close_pipes(process)
    finally:
        _reaping_processes.discard(process)


def _kill_and_reap(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    except PermissionError:
        if process.poll() is None:
            process.kill()

    cleanup_deadline = time.monotonic() + _CLEANUP_TIMEOUT_SECONDS
    if _poll_for_exit(process, cleanup_deadline) is None:
        logger.error("PAM helper cleanup delayed (pid=%s); reaping in background", process.pid)
        _reaping_processes.add(process)
        spawn(_reap_in_background, process)
    else:
        _close_pipes(process)


def _readline_before_deadline(process, response_buffer, deadline, timeout_error,
                              trace_callback=None):
    process_exit_observed_at = None
    while True:
        newline_index = response_buffer.find(b"\n")
        if newline_index >= 0:
            line = bytes(response_buffer[:newline_index + 1])
            del response_buffer[:newline_index + 1]
            return line

        if len(response_buffer) > _MAX_MESSAGE_BYTES:
            raise PamAuthenticationProcessError("PAM helper response exceeds size limit")

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise timeout_error

        try:
            read_size = min(
                4096,
                max(1, _MAX_MESSAGE_BYTES + 1 - len(response_buffer)),
            )
            chunk = os.read(process.stdout.fileno(), read_size)
        except BlockingIOError:
            return_code = process.poll()
            if return_code is not None:
                now = time.monotonic()
                if process_exit_observed_at is None:
                    process_exit_observed_at = now
                    logger.debug(
                        "PAM helper exit observed while response pipe is pending "
                        "(pid=%s return_code=%s)",
                        process.pid, return_code,
                    )
                    if trace_callback is not None:
                        trace_callback(
                            "PAM helper exited; draining pending response bytes "
                            "(pid=%s return_code=%s grace_seconds=%.3f)",
                            process.pid, return_code,
                            _PIPE_DRAIN_TIMEOUT_SECONDS,
                        )
                elif now - process_exit_observed_at >= _PIPE_DRAIN_TIMEOUT_SECONDS:
                    raise PamAuthenticationProcessError(
                        "PAM helper exited before returning a complete response "
                        f"(return code {return_code})"
                    )
            sleep(min(_POLL_INTERVAL_SECONDS, remaining))
            continue
        except InterruptedError:
            continue

        if not chunk:
            raise PamAuthenticationProcessError(
                "PAM helper closed before returning a complete response"
            )
        response_buffer.extend(chunk)


def _run_callback_before_deadline(callback, prompt, deadline, timeout_error):
    callback_greenlet = spawn(callback, prompt)
    try:
        while not callback_greenlet.ready():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                callback_greenlet.kill(block=False)
                raise timeout_error
            sleep(min(_POLL_INTERVAL_SECONDS, remaining))
        return callback_greenlet.get()
    finally:
        if not callback_greenlet.ready():
            callback_greenlet.kill(block=False)


def run_pam_authentication(username, password, request_id, otp_callback,
                           timeout_seconds=90.0, max_workers=4,
                           trace_callback=None):
    """Return serializable PAM results; kill and reap on timeout or failure.
    """
    logger.debug("BEGIN: run_pam_authentication")
    started_at = time.monotonic()
    log_context = "user=%r request_id=%r" % (username, request_id)

    def trace(message, *args):
        logger.debug(message, *args)
        if trace_callback is None:
            return
        try:
            trace_callback(message % args if args else message)
        except Exception:
            logger.exception("PAM trace callback failed (%s)", log_context)

    trace("Starting run_pam_authentication (%s)", log_context)
    logger.debug(
        "PAM executor entered (%s password_provided=%s raw_timeout=%r "
        "raw_max_workers=%r)",
        log_context, bool(password), timeout_seconds, max_workers,
    )

    logger.debug("Normalizing PAM executor configuration (%s)", log_context)
    try:
        timeout_seconds = float(timeout_seconds)
        max_workers = int(max_workers)
    except (TypeError, ValueError):
        logger.exception(
            "Failed to normalize PAM executor configuration "
            "(%s raw_timeout=%r raw_max_workers=%r)",
            log_context, timeout_seconds, max_workers,
        )
        raise
    logger.debug(
        "PAM executor configuration normalized (%s timeout_seconds=%s "
        "max_workers=%s)",
        log_context, timeout_seconds, max_workers,
    )
    if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
        logger.debug(
            "Rejecting invalid PAM authentication timeout (%s timeout_seconds=%r)",
            log_context, timeout_seconds,
        )
        raise ValueError("PAM authentication timeout must be finite and positive")
    if max_workers <= 0:
        logger.debug(
            "Rejecting invalid PAM authentication capacity (%s max_workers=%r)",
            log_context, max_workers,
        )
        raise ValueError("PAM authentication max workers must be greater than zero")

    active_count = len(_active_attempts)
    reaping_count = len(_reaping_processes)
    duplicate_request = request_id in _active_attempts
    logger.debug(
        "Checking PAM executor capacity (%s active_attempts=%s "
        "reaping_processes=%s max_workers=%s duplicate_request=%s)",
        log_context, active_count, reaping_count, max_workers, duplicate_request,
    )
    if (duplicate_request or active_count >= max_workers
            or reaping_count >= max_workers):
        if duplicate_request:
            busy_reason = "duplicate request ID"
        elif active_count >= max_workers:
            busy_reason = "active process limit reached"
        else:
            busy_reason = "background reaper limit reached"
        logger.debug(
            "Rejecting PAM authentication because capacity is busy "
            "(%s reason=%s active_attempts=%s reaping_processes=%s "
            "max_workers=%s)",
            log_context, busy_reason, active_count, reaping_count, max_workers,
        )
        raise PamAuthenticationBusyError("PAM authentication capacity is busy")

    _active_attempts.add(request_id)
    logger.debug(
        "Reserved PAM authentication slot (%s active_attempts=%s)",
        log_context, len(_active_attempts),
    )
    process = None
    deadline = time.monotonic() + timeout_seconds
    logger.debug(
        "Calculated PAM authentication deadline (%s timeout_seconds=%s)",
        log_context, timeout_seconds,
    )
    try:
        logger.debug(
            "Launching isolated PAM helper (%s helper_path=%s)",
            log_context, _HELPER_PATH,
        )
        process = subprocess.Popen(
            [sys.executable, "-u", str(_HELPER_PATH)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, close_fds=True, start_new_session=True,
        )
        logger.debug(
            "PAM helper launched (%s pid=%s)", log_context, process.pid,
        )
        os.set_blocking(process.stdout.fileno(), False)
        response_buffer = bytearray()
        trace(
            "PAM helper launched and stdout set nonblocking (%s pid=%s)",
            log_context, process.pid,
        )
        remaining = deadline - time.monotonic()
        timeout_error = PamAuthenticationTimeoutError(
            f"PAM authentication exceeded {timeout_seconds:g} seconds"
        )
        logger.debug(
            "Starting PAM protocol deadline guard (%s pid=%s "
            "remaining_seconds=%.3f)",
            log_context, process.pid, max(0.0, remaining),
        )
        if remaining <= 0:
            logger.debug(
                "PAM deadline expired before credentials could be sent "
                "(%s pid=%s)",
                log_context, process.pid,
            )
            raise timeout_error
        with Timeout(remaining, timeout_error):
            logger.debug(
                "Sending credentials to PAM helper (%s pid=%s; values omitted)",
                log_context, process.pid,
            )
            _send(process, {"username": username, "password": password})
            logger.debug(
                "Credentials sent to PAM helper (%s pid=%s)",
                log_context, process.pid,
            )
            trace(
                "Credentials sent; waiting for PAM helper response "
                "(%s pid=%s remaining_seconds=%.3f)",
                log_context, process.pid, max(0.0, deadline - time.monotonic()),
            )
            while True:
                logger.debug(
                    "Waiting for PAM helper response (%s pid=%s)",
                    log_context, process.pid,
                )
                line = _readline_before_deadline(
                    process, response_buffer, deadline, timeout_error, trace
                )
                logger.debug(
                    "Read PAM helper response (%s pid=%s bytes=%s eof=%s)",
                    log_context, process.pid, len(line), not bool(line),
                )
                if not line or len(line) > _MAX_MESSAGE_BYTES:
                    logger.debug(
                        "Rejecting missing or oversized PAM helper response "
                        "(%s pid=%s bytes=%s limit=%s)",
                        log_context, process.pid, len(line), _MAX_MESSAGE_BYTES,
                    )
                    raise PamAuthenticationProcessError(
                        "PAM helper closed or invalid response"
                    )
                message = json.loads(line)
                message_type = message.get("type")
                logger.debug(
                    "Decoded PAM helper response (%s pid=%s type=%r keys=%s)",
                    log_context, process.pid, message_type,
                    sorted(message.keys()) if isinstance(message, dict) else "n/a",
                )
                trace(
                    "Received PAM helper response (%s pid=%s type=%r)",
                    log_context, process.pid, message_type,
                )
                if message_type == "otp":
                    prompt = message["prompt"]
                    logger.debug(
                        "PAM helper requested OTP (%s pid=%s prompt_length=%s)",
                        log_context, process.pid, len(prompt),
                    )
                    trace(
                        "Waiting for OTP callback (%s pid=%s remaining_seconds=%.3f)",
                        log_context, process.pid,
                        max(0.0, deadline - time.monotonic()),
                    )
                    otp = _run_callback_before_deadline(
                        otp_callback, prompt, deadline, timeout_error
                    )
                    logger.debug(
                        "OTP callback completed (%s pid=%s otp_provided=%s; "
                        "value omitted)",
                        log_context, process.pid, bool(otp),
                    )
                    if not otp:
                        logger.debug(
                            "OTP callback returned no value (%s pid=%s)",
                            log_context, process.pid,
                        )
                        raise PamAuthenticationTimeoutError(
                            "OTP submission cancelled or timed out"
                        )
                    logger.debug(
                        "Sending OTP response to PAM helper "
                        "(%s pid=%s; value omitted)",
                        log_context, process.pid,
                    )
                    _send(process, {"otp": otp})
                    logger.debug(
                        "OTP response sent to PAM helper (%s pid=%s)",
                        log_context, process.pid,
                    )
                    trace(
                        "OTP response sent; waiting for PAM helper result "
                        "(%s pid=%s remaining_seconds=%.3f)",
                        log_context, process.pid,
                        max(0.0, deadline - time.monotonic()),
                    )
                elif message_type == "result":
                    logger.debug(
                        "PAM helper returned final result (%s pid=%s success=%r "
                        "privilege_level=%r)",
                        log_context, process.pid, message.get("success"),
                        message.get("privilege_level"),
                    )
                    if type(message.get("success")) is not bool:
                        logger.debug(
                            "Rejecting PAM result with non-boolean success value "
                            "(%s pid=%s success_type=%s)",
                            log_context, process.pid,
                            type(message.get("success")).__name__,
                        )
                        raise PamAuthenticationProcessError("Invalid PAM result")
                    logger.debug(
                        "Waiting for PAM helper to exit after final result "
                        "(%s pid=%s)",
                        log_context, process.pid,
                    )
                    return_code = _poll_for_exit(process, deadline)
                    if return_code is None:
                        raise timeout_error
                    logger.debug(
                        "PAM helper exited after final result (%s pid=%s "
                        "return_code=%s)",
                        log_context, process.pid, return_code,
                    )
                    if return_code != 0:
                        raise PamAuthenticationProcessError(
                            "PAM helper exited unsuccessfully"
                        )
                    logger.debug(
                        "Returning PAM authentication result (%s pid=%s success=%s "
                        "elapsed_seconds=%.3f)",
                        log_context, process.pid, message["success"],
                        time.monotonic() - started_at,
                    )
                    trace(
                        "PAM helper completed (%s pid=%s success=%s "
                        "elapsed_seconds=%.3f)",
                        log_context, process.pid, message["success"],
                        time.monotonic() - started_at,
                    )
                    return message
                elif message_type == "error":
                    logger.debug(
                        "PAM helper reported an error (%s pid=%s error_type=%r)",
                        log_context, process.pid, message.get("error_type"),
                    )
                    raise PamAuthenticationProcessError(
                        f"PAM helper failed: {message.get('error_type', 'unknown error')}"
                    )
                else:
                    logger.debug(
                        "PAM helper returned unknown response type "
                        "(%s pid=%s type=%r)",
                        log_context, process.pid, message_type,
                    )
                    raise PamAuthenticationProcessError("Unknown PAM helper response")
    except PamAuthenticationTimeoutError as error:
        trace(
            "PAM authentication deadline reached (%s pid=%s "
            "elapsed_seconds=%.3f)",
            log_context, getattr(process, "pid", None),
            time.monotonic() - started_at,
        )
        logger.debug(
            "PAM authentication timed out (%s pid=%s error=%r "
            "elapsed_seconds=%.3f)",
            log_context, getattr(process, "pid", None), error,
            time.monotonic() - started_at,
        )
        raise
    except Exception:
        logger.exception(
            "PAM authentication executor failed (%s pid=%s "
            "elapsed_seconds=%.3f)",
            log_context, getattr(process, "pid", None),
            time.monotonic() - started_at,
        )
        raise
    finally:
        try:
            if process is not None:
                trace(
                    "Starting PAM helper cleanup (%s pid=%s return_code=%r)",
                    log_context, process.pid, process.poll(),
                )
                logger.debug(
                    "Starting PAM helper cleanup (%s pid=%s return_code=%r)",
                    log_context, process.pid, process.poll(),
                )
                _kill_and_reap(process)
                trace(
                    "PAM helper cleanup finished (%s pid=%s return_code=%r)",
                    log_context, process.pid, process.poll(),
                )
                logger.debug(
                    "PAM helper cleanup completed or delegated "
                    "(%s pid=%s return_code=%r reaping_processes=%s)",
                    log_context, process.pid, process.poll(),
                    len(_reaping_processes),
                )
            else:
                logger.debug(
                    "Skipping PAM helper cleanup because launch did not complete (%s)",
                    log_context,
                )
        finally:
            _active_attempts.discard(request_id)
            trace(
                "Released PAM authentication slot (%s active_attempts=%s "
                "elapsed_seconds=%.3f)",
                log_context, len(_active_attempts),
                time.monotonic() - started_at,
            )
            logger.debug(
                "Released PAM authentication slot (%s active_attempts=%s "
                "reaping_processes=%s elapsed_seconds=%.3f)",
                log_context, len(_active_attempts), len(_reaping_processes),
                time.monotonic() - started_at,
            )
