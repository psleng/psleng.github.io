from app.log.logger import logger


def has_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ''
    return True


def parse_to_openvpn_config(data: dict, current_config: dict = None):
    config = {}
    general = data.get('general', {})
    openvpn = data.get('openvpn', {})
    security = data.get('security', {})
    advanced = openvpn.get('advanced', {})
    tls = security.get('tls', {})
    encryption = security.get('encryption', {})
    server = openvpn.get('server', {})

    if 'description' in general:
        config['description'] = general['description']
    if 'deviceType' in openvpn and has_value(openvpn['deviceType']):
        config['device-type'] = openvpn['deviceType']
    hash_algorithm = security.get('hash', {}).get('algorithm')
    if hash_algorithm and (not isinstance(hash_algorithm, str) or hash_algorithm.strip()):
        config['hash'] = hash_algorithm
    if 'ipVersion' in advanced:
        config['ip-version'] = advanced['ipVersion']

    if 'keepAlive' in advanced:
        keep_alive_config = {}
        if 'failureCount' in advanced['keepAlive']:
            failure_count = advanced['keepAlive']['failureCount']
            if has_value(failure_count):
                keep_alive_config['failure-count'] = str(failure_count)
        if 'interval' in advanced['keepAlive']:
            interval = advanced['keepAlive']['interval']
            if has_value(interval):
                keep_alive_config['interval'] = str(interval)
        if keep_alive_config:
            config['keep-alive'] = keep_alive_config

    if 'localHost' in openvpn:
        config['local-host'] = openvpn['localHost']

    if 'localPort' in openvpn and has_value(openvpn['localPort']):
        config['local-port'] = openvpn['localPort']

    if 'localAddress' in openvpn:
        if isinstance(openvpn['localAddress'], str) and openvpn['localAddress'].strip():
            config['local-address'] = {openvpn['localAddress']: {}}
        elif isinstance(openvpn['localAddress'], dict):
            config['local-address'] = openvpn['localAddress']

    if 'mode' in general and general['mode']:
        config['mode'] = general['mode']
    elif current_config and 'mode' in current_config:
        config['mode'] = current_config['mode']

    if advanced.get('persistentTunnel') is True:
        config['persistent-tunnel'] = {}

    if 'protocol' in openvpn:
        config['protocol'] = openvpn['protocol']

    if 'remoteAddress' in openvpn and openvpn['remoteAddress']:
        if isinstance(openvpn['remoteAddress'], str) and openvpn['remoteAddress'].strip():
            config['remote-address'] = openvpn['remoteAddress']
        elif not isinstance(openvpn['remoteAddress'], str):
            config['remote-address'] = openvpn['remoteAddress']

    if 'remoteHost' in openvpn:
        if isinstance(openvpn['remoteHost'], str):
            config['remote-host'] = [openvpn['remoteHost']]
        elif isinstance(openvpn['remoteHost'], list):
            config['remote-host'] = openvpn['remoteHost']

    if 'remotePort' in openvpn and has_value(openvpn['remotePort']):
        config['remote-port'] = str(openvpn['remotePort'])

    if server:
        server_config = {}
        if 'clientIpPool' in server and server['clientIpPool']:
            pool = server['clientIpPool']
            if pool.get('start') or pool.get('stop') or pool.get('subnetMask'):
                server_config['client-ip-pool'] = {
                    'start': pool['start'],
                    'stop': pool['stop'],
                    'disabled': pool['disabled'],
                    'subnet-mask': pool['subnetMask']
                }
        if 'clientIpv6Pool' in server and server['clientIpv6Pool']:
            pool = server['clientIpv6Pool']
            if pool.get('base'):
                server_config['client-ipv6-pool'] = {
                    'base': pool['base'],
                    'disabled': pool['disabled']
                }
        if 'subnet' in server and server['subnet'] and server['subnet'].strip():
            server_config['subnet'] = server['subnet']
        if 'clients' in server and isinstance(server['clients'], list) and len(server['clients']) > 0:
            server_config['client'] = {}
            for client in server['clients']:
                if 'name' in client:
                    _client = {}
                    if 'ip' in client:
                        _client['ip'] = client['ip']
                    if 'pushRoute' in client:
                        if isinstance(client['pushRoute'], list):
                            _client['push-route'] = client['pushRoute']
                        else:
                            _client['push-route'] = client['pushRoute']
                    if 'subnet' in client:
                        if isinstance(client['subnet'], list):
                            _client['subnet'] = client['subnet']
                        else:
                            _client['subnet'] = client['subnet']
                    server_config['client'].update({client['name']: _client})
        if 'topology' in server:
            server_config['topology'] = server['topology']
        if 'domainName' in server and server['domainName'] and server['domainName'].strip():
            server_config['domain-name'] = server['domainName']
        if 'maxConnections' in server:
            server_config['max-connections'] = str(server['maxConnections'])
        if 'nameServer' in server and server['nameServer'] and len(server['nameServer']) > 0:
            server_config['name-server'] = server['nameServer']
        if 'pushRoutes' in server and server['pushRoutes'] and len(server['pushRoutes']) > 0:
            server_config['push-route'] = []
            for pushRoute in server['pushRoutes']:
                server_config['push-route'].append(pushRoute)
        if server.get('rejectUnconfiguredClients') is True:
            server_config['reject-unconfigured-clients'] = {}
        
        if server_config:
            config['server'] = server_config

    if tls:
        tls_config = {}
        if 'caCert' in tls and tls['caCert']:
            tls_config['ca-certificate'] = tls['caCert']
        if 'certificate' in tls and tls['certificate']:
            tls_config['certificate'] = tls['certificate']
        if 'authKey' in tls and tls['authKey'] and len(tls['authKey']) > 0:
            tls_config['auth-key'] = tls['authKey']
        if 'cryptKey' in tls and tls['cryptKey'] and len(tls['cryptKey']) > 0:
            tls_config['crypt-key'] = tls['cryptKey']
        if 'dhParams' in tls and tls['dhParams']:
            tls_config['dh-params'] = tls['dhParams']
        if 'role' in tls and tls['role'] and tls['role'].strip():
            if current_config and 'tls' in current_config and 'role' in current_config.get('tls', {}):
                tls_config['role'] = tls['role']
            elif current_config and 'tls' not in current_config:
                tls_config['role'] = tls['role']
            elif not current_config:
                tls_config['role'] = tls['role']
        if 'tlsVersionMin' in tls and tls['tlsVersionMin']:
            tls_config['tls-version-min'] = tls['tlsVersionMin']
        if 'peerFingerprint' in tls and tls['peerFingerprint'] and len(tls['peerFingerprint']) > 0:
            tls_config['peer-fingerprint'] = tls['peerFingerprint']
        if 'sharedSecretKey' in tls and tls['sharedSecretKey']:
            tls_config['shared-secret-key'] = tls['sharedSecretKey']
        if tls_config:
            config['tls'] = tls_config

    if encryption:
        encryption_config = {}
        mode = config.get('mode')
        legacy_cipher = encryption.get('cipher')
        uses_tls = bool(config.get('tls')) or mode in ('client', 'server')
        if mode == 'site-to-site':
            fallback = encryption.get('dataCiphersFallback')
            if fallback is None and uses_tls:
                fallback = legacy_cipher
            if fallback:
                encryption_config['data-ciphers-fallback'] = fallback
        if mode in ('client', 'server'):
            data_ciphers = encryption.get('dataCiphers') or []
            if not data_ciphers and legacy_cipher:
                data_ciphers = [legacy_cipher]
            if data_ciphers:
                encryption_config['data-ciphers'] = data_ciphers

        if legacy_cipher and not uses_tls:
            encryption_config['cipher'] = legacy_cipher
        if encryption_config:
            config['encryption'] = encryption_config

    if advanced.get('useLzoCompression') is True:
        config['use-lzo-compression'] = {}

    # logger.debug("Parsed openvpn config: ")
    # logger.debug(config)

    return config

def parse_current_openvpn_interface_config(interface_config: dict, name: str):

    config = {}
    if not interface_config:
        return config
    if not interface_config.get('interfaces', {}):
        return config
    if not interface_config.get('interfaces', {}).get('openvpn', {}):
        return config
    for interface, interface_conf in interface_config.get('interfaces', {}).get('openvpn', {}).items():
        if interface == name:
            config = interface_conf
            break

    if 'remote-host' in config:
        if isinstance(config['remote-host'], str):
            config['remote-host'] = [config['remote-host']]

    if 'local-host' in config:
        if isinstance(config['local-host'], str):
            config['local-host'] = [config['local-host']]

    return config


def parse_current_all_openvpn_interfaces_config(interface_config: dict):
    config = {}
    if not interface_config:
        return config
    openvpn_section = interface_config.get('interfaces', {}).get('openvpn', {})
    if not isinstance(openvpn_section, dict):
        return config

    for interface, interface_conf in openvpn_section.items():
        if not isinstance(interface_conf, dict):
            continue
        entry = dict(interface_conf)
        if 'remote-host' in entry and isinstance(entry['remote-host'], str):
            entry['remote-host'] = [entry['remote-host']]
        if 'local-host' in entry and isinstance(entry['local-host'], str):
            entry['local-host'] = [entry['local-host']]
        config[interface] = entry

    return config


def parse_to_openvpn_bulk_config(interfaces_data) -> dict:
    bulk_config: dict = {'interfaces': {'openvpn': {}}}
    if not interfaces_data:
        return bulk_config

    for iface in interfaces_data:
        if iface is None:
            continue
        if hasattr(iface, 'model_dump'):
            iface_dict = iface.model_dump()
        elif isinstance(iface, dict):
            iface_dict = iface
        else:
            continue

        general = iface_dict.get('general') or {}
        name = general.get('name')
        if not name:
            continue

        parsed = parse_to_openvpn_config(iface_dict)
        bulk_config['interfaces']['openvpn'][name] = parsed

    return bulk_config

def parse_openvpn_monitor_info(data: dict):
    logger.debug("Parsing openvpn monitor info")
    if not isinstance(data, dict):
        return []

    try:
        monitor_info = data.get('data', {}).get('ShowOpenvpn', {}).get('data', {}).get('result', [])
        if not isinstance(monitor_info, list):
            logger.warning("OpenVPN monitor info 'result' is not a list.")
            return []
        
        processed_info = []
        for item in monitor_info:
            processed_item = {
                'intf': item.get('intf', 'N/A'),
                'description': item.get('description', ''),
                'state': item.get('state', 'down'),
                'mode': item.get('mode', 'unknown'),
                'date': item.get('date', ''),
                'local_host': item.get('local_host', ''),
                'local_port': item.get('local_port', ''),
                'remote_host': item.get('remote_host', ''),
                'remote_port': item.get('remote_port', ''),
                'tx_bytes': item.get('tx_bytes', 0),
                'rx_bytes': item.get('rx_bytes', 0),
                'tunnel': item.get('tunnel', ''),
                'online_since': item.get('online_since', ''),
                'clients': []
            }
            
            if item.get('clients') and isinstance(item.get('clients'), list):
                for client in item.get('clients'):
                    processed_client = {
                        'name': client.get('name', 'N/A'),
                        'remote_host': client.get('remote_host', ''),
                        'tunnel': client.get('tunnel', ''),
                        'rx_bytes': client.get('rx_bytes', 0),
                        'tx_bytes': client.get('tx_bytes', 0),
                        'online_since': client.get('online_since', '')
                    }
                    processed_item['clients'].append(processed_client)
            
            processed_info.append(processed_item)
        
        logger.debug(f"Parsed openvpn monitor info: {processed_info}")
        return processed_info
    except Exception as e:
        logger.error(f"Error parsing openvpn monitor info: {e}")
        return []

def parse_openvpn_shared_secret(data: str):

    result = {
        "shared_secret": "",
        "private_key": "",
        "key": "",
        "version": ""
    }

    if not isinstance(data, str):
        return result

    # Example header: -----BEGIN OpenVPN Static key V1-----
    begin_marker = "-----BEGIN OpenVPN Static key"
    end_marker = "-----END OpenVPN Static key"

    stripped = data.strip()
    begin_idx = stripped.find(begin_marker)
    end_idx = stripped.find(end_marker)

    value = ""
    if begin_idx != -1 and end_idx != -1 and end_idx >= begin_idx:
        end_line_end = stripped.find("\n", end_idx)
        if end_line_end == -1:
            end_line_end = len(stripped)
        value = stripped[begin_idx:end_line_end].strip() + "\n"
    else:
        lines = [ln.rstrip() for ln in stripped.splitlines() if ln.strip()]
        for ln in lines:
            lower = ln.lower()
            if ':' in ln and ('shared' in lower and 'secret' in lower):
                value = ln.split(':', 1)[1].strip()
                break

        if not value and lines:
            value = stripped

    result['shared_secret'] = value
    result['private_key'] = value

    if isinstance(value, str) and value.strip().startswith(begin_marker):
        lines = [ln.rstrip("\r") for ln in value.strip().splitlines()]
        if lines:
            header = lines[0].strip()
            version = ""
            if " Static key V" in header:
                try:
                    v_part = header.split(" Static key V", 1)[1]
                    v_part = v_part.split("-----", 1)[0]
                    version = v_part.strip()
                except Exception:
                    version = ""

            key_lines = []
            for ln in lines[1:]:
                if ln.strip().startswith(end_marker):
                    break
                if ln.strip():
                    key_lines.append(ln.strip())

            result['version'] = version
            result['key'] = "\n".join(key_lines).strip()

    if not result.get('version'):
        result['version'] = "1"
    if not result.get('key') and isinstance(value, str):
        result['key'] = value.strip()

    return result
