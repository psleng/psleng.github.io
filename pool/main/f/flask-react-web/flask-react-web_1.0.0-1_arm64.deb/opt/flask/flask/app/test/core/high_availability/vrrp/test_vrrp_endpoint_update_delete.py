import copy
import pprint
import requests
from app.core.api.http.http_request import Action


class TestVRRPEndpointUpdateDelete1Local:

    @classmethod
    def setup_class(cls):
        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as exc:
            print(f"Registration error (user may already exist): {exc}")

    def _delete_and_login(self, test_service_provider):
        delete_payload = '{"op": "delete", "path": ["high_availability", "vrrp"]}'
        test_service_provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_payload,
            verify=False,
        )

        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def test_delete_local_config_with_empty_fields(self, test_service_provider):
        """
        Test deletion of VRRP local configuration by sending empty fields.
        
        Steps:
        1. Start with an initial local configuration
        2. Send a config with empty fields
        3. Verify the configuration is deleted
        """
        vrrp_url = "http://localhost/webapi/vyos/high-availability/vrrp"
        cookies = self._delete_and_login(test_service_provider)

        # Step 1: Create initial local configuration
        initial_config = {
              "connection": {  
                "group": [
                {
                    "VRRPGeneral": {
                        "groupName": "test",
                        "description": "test description",
                        "enable": True,
                        "address": [
                            "10.10.10.10",
                            "20.20.20.20"
                        ],
                        "interface": "eth0",
                        "VRID": 70
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 60,
                        "authenticationPassword": "password",
                        "excludedAddresses": [
                            "20.20.20.20",
                            "30.30.30.30"
                        ],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 90,
                        "priority": 78,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 40,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 200,
                            "masterRepeat": 5
                        },
                        "track": {
                            "excludeVRRP": True,
                            "interface": "eth0"
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test2",
                        "description": "",
                        "enable": True,
                        "address": [
                            "192.0.2.1"
                        ],
                        "interface": "eth0",
                        "VRID": 79
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "track": {
                            "excludeVRRP": False,
                            "interface": ""
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test3",
                        "description": "asdasd",
                        "enable": True,
                        "address": [
                            "30.30.30.30"
                        ],
                        "interface": "br2",
                        "VRID": 1
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": ""
                        },
                        "track": {
                            "excludeVRRP": False,
                            "interface": ""
                        }
                    }
                }
                ],
                "syncGroup": 
                [
                    {
                        "groupName": "test",
                        "member": [],
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "3.3.3.3"
                        }
                    },
                    {
                        "groupName": "test2",
                        "member": [
                            "test2",
                            "test"
                        ],
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": ""
                        }
                    }
                ]

            },
            "globalParameters": {
                "delay": 5,
                "version": 2,
                "enableSNMP": True,
                "GARP": {
                    "interval": 100,
                    "masterDelay": 50,
                    "masterRefresh": 5,
                    "masterRefreshRepeat": 1,
                    "masterRepeat": 200
                }
            }
        }


        print("\n=== Creating Initial Local Configuration ===")
        initial_response = requests.put(vrrp_url, json=initial_config, cookies=cookies)
        print(f"Initial config response status: {initial_response.status_code}")
        assert initial_response.status_code == 200, f"Failed to create initial config: {initial_response.text}"
        initial_commands = initial_response.json()
        print("Initial commands generated:")
        pprint.pprint(initial_commands)
        for item in initial_commands:
            assert item.get("success", False), f"Initial command failed: {item.get('error', 'Unknown error')}"

        fetch_payload = '{"op": "showConfig", "path": ["high-availability", "vrrp"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=fetch_payload,
            verify=False,
        )
        fetched_config = fetch_response.json()
        print("\n=== Initial Configuration Created ===")
        pprint.pprint(fetched_config)
        vrrp_config = fetched_config.get("data", {})
        groups = vrrp_config.get("group", {})
        assert len(groups) == 3, "Expected 3 VRRP groups"
        globalParams = vrrp_config.get("global-parameters", {})
        assert globalParams.get("startup-delay") == "5", "Global startup delay mismatch"
        syncGroups = vrrp_config.get("sync-group", {})
        assert len(syncGroups) == 2, "Expected 2 sync groups"

        # Step 2: Send empty configuration to delete everything
        
        empty_config = {
            "connection": {
                "group": [],
                "syncGroup": []
            },
            "globalParameters": {
            
            }
        }


        print("\n=== Sending Empty Configuration to Delete ===")
        delete_response = requests.put(vrrp_url, json=empty_config, cookies=cookies)
        assert delete_response.status_code == 200, f"Failed to delete config: {delete_response.text}"
        delete_commands = delete_response.json()
        print("Delete commands generated:")
        pprint.pprint(delete_commands)
        for item in delete_commands:
            assert item.get("success", False), f"Delete command failed: {item.get('error', 'Unknown error')}"

        # Step 3: Verify configuration is deleted
        fetch_after_delete = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=fetch_payload,
            verify=False,
        )
        fetched_after_delete = fetch_after_delete.json()
        print("\n=== Configuration After Deletion ===")
        pprint.pprint(fetched_after_delete)

        try:
            vrrp_config_after = fetched_after_delete.get("data", {})
            global_params_after = vrrp_config_after.get("global-parameters", {})
            group_after = vrrp_config_after.get("group", {})
            sync_group_after = vrrp_config_after.get("sync-group", {})
            
            
            assert len(group_after) == 0, "Expected 0 VRRP groups"
            assert len(sync_group_after) == 0, "Expected 0 VRRP groups"

            assert global_params_after.get("startup-delay") is None, "Global startup delay should be deleted"
            assert global_params_after.get("version") is None, "Global version should be deleted"
            assert global_params_after.get("delay") is None, "Global delay should be deleted"
            garp_after = global_params_after.get("garp", {})
            assert garp_after == {}, "Global GARP should be deleted"
            assert global_params_after.get("snmp") is None, "Global SNMP should be deleted"
        
            
            print("\n All local configuration successfully deleted")
        except AssertionError as e:
            if "Unable to locate VRRP configuration" in str(e):
                print("\n VRRP configuration completely removed (expected)")
            else:
                raise
