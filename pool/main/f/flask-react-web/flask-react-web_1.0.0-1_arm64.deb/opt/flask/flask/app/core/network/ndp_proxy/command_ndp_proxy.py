from typing import Any, Dict
import pprint
from app.core.api.http.cmd.command import Command


def _present(value: Any) -> bool:
    return value is not None and str(value).strip() not in ('', 'None')


class NDPProxyCommand(Command):
    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        parts = [str(arg) for arg in args if _present(arg)]
        self.cmds.append(self._build_command(*parts))
        self.vyos_cmds.append(' '.join(parts))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data or not isinstance(data, dict):
            return []

        base = ['service', 'ndp-proxy']
        if 'route-refresh' in data:
            self._generate_value(base, 'route-refresh', data.get('route-refresh'))

        interfaces = data.get('interface')
        if isinstance(interfaces, dict):
            for name, intf_cfg in interfaces.items():
                self._generate_interface(base, str(name), intf_cfg, new_config)

        return self.cmds

    def _generate_value(self, base: list, key: str, value: Any):
        if self.operator == 'delete':
            self.generate(*base, key, value)
        elif _present(value):
            self.generate(*base, key, value)

    def _generate_flag(self, base: list, key: str):
        self.generate(*base, key)

    def _generate_interface(self, base: list, name: str, intf_cfg: Any, new_config=None):
        intf_path = [*base, 'interface', name]

        print("New config: ")
        print(pprint.pformat(new_config, indent=4))

        if self.operator == "delete" and name not in new_config.get('interface', {}):
            self.generate(*intf_path)
            return
        
        if not isinstance(intf_cfg, dict):
            self.generate(*intf_path)
            return

        if not intf_cfg:
            self.generate(*intf_path)
            return

        if 'disable' in intf_cfg:
            self._generate_flag(intf_path, 'disable')
        if 'enable-router-bit' in intf_cfg:
            self._generate_flag(intf_path, 'enable-router-bit')
        if 'timeout' in intf_cfg:
            self._generate_value(intf_path, 'timeout', intf_cfg.get('timeout'))
        if 'ttl' in intf_cfg:
            self._generate_value(intf_path, 'ttl', intf_cfg.get('ttl'))

        prefixes = intf_cfg.get('prefix')
        if isinstance(prefixes, dict):
            for prefix_value, prefix_cfg in prefixes.items():
                self._generate_prefix(intf_path, str(prefix_value), prefix_cfg)

    def _generate_prefix(self, intf_path: list, value: str, prefix_cfg: Any):
        prefix_path = [*intf_path, 'prefix', value]
        if not isinstance(prefix_cfg, dict):
            self.generate(*prefix_path)
            return

        if not prefix_cfg:
            self.generate(*prefix_path)
            return

        if 'disable' in prefix_cfg:
            self._generate_flag(prefix_path, 'disable')
        if 'mode' in prefix_cfg:
            self._generate_value(prefix_path, 'mode', prefix_cfg.get('mode'))
        if 'interface' in prefix_cfg:
            self._generate_value(prefix_path, 'interface', prefix_cfg.get('interface'))
