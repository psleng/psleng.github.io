from datetime import datetime, timezone
from threading import Lock
from typing import Any

import jwt
import requests
from flask import current_app, request, session
from werkzeug.exceptions import ServiceUnavailable
from .web_sessions import cloud_session_was_revoked, start_web_session

CLOUD_SESSION_COOKIE = "IGOS_CLOUD_SESSION"
_session_states: dict[str, bool] = {}
_session_states_lock = Lock()


def _verify_ssl(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).lower() in ("1", "true", "yes")


def _cloud_auth_config() -> dict[str, Any]:
    return {
        "apikey": current_app.config["VYOS_APIKEY"],
        "hostname": current_app.config["VYOS_HOSTNAME"],
        "port": current_app.config["VYOS_PORT"],
        "protocol": current_app.config["VYOS_PROTOCOL"],
        "verify_ssl": current_app.config.get("VYOS_VERIFY_SSL", False),
    }


def _call_cloud_auth(
    op: str,
    sid: str | None = None,
    sids: list[str] | None = None,
    config: dict[str, Any] | None = None,
) -> Any:
    config = config or _cloud_auth_config()
    payload = {
        "key": config["apikey"],
        "service": "cloud",
        "op": op,
    }
    if sid is not None:
        payload["sid"] = sid
    if sids is not None:
        payload["sids"] = sids

    response = requests.post(
        f"{config['protocol']}://{config['hostname']}:{config['port']}/auth",
        json=payload,
        timeout=(3.0, 15.0),
        verify=_verify_ssl(config["verify_ssl"]),
    )
    response.raise_for_status()

    result = response.json()
    if not result.get("success"):
        raise ValueError(result.get("error") or "Cloud authentication failed")
    return result.get("data")


def _set_session_state(sid: str, active: bool) -> None:
    with _session_states_lock:
        _session_states[sid] = active


def refresh_cloud_sessions() -> None:
    with _session_states_lock:
        session_ids = [sid for sid, active in _session_states.items() if active]

    if not session_ids:
        return

    try:
        statuses = _call_cloud_auth("validate_batch", sids=session_ids)
        if not isinstance(statuses, dict):
            raise ValueError("Cloud session batch response is invalid")
    except (requests.RequestException, TypeError, ValueError) as error:
        current_app.logger.warning(f"Cloud session validation unavailable: {error}")
        return

    for sid in session_ids:
        active = statuses.get(sid)
        if isinstance(active, bool):
            _set_session_state(sid, active)
        else:
            current_app.logger.warning(
                f"Cloud session batch response omitted session: {sid}"
            )


def authenticate_cloud_cookie() -> bool:
    token = request.cookies.get(CLOUD_SESSION_COOKIE)
    if not token:
        current_app.logger.warning("Cloud authentication cookie is not present")
        return False

    try:
        header = jwt.get_unverified_header(token)
        if header.get("alg") != "RS256" or not header.get("kid"):
            current_app.logger.warning(
                "Cloud JWT has an invalid algorithm or missing key ID"
            )
            return False

        jwks = _call_cloud_auth("jwks")
        jwk = next(
            key for key in jwks.get("keys", []) if key.get("kid") == header["kid"]
        )
        signing_key = jwt.PyJWK.from_dict(jwk).key
        claims = jwt.decode(
            token,
            signing_key,
            algorithms=["RS256"],
            options={"require": ["sid", "exp", "role"]},
        )

        sid = claims["sid"]
        if not isinstance(sid, str):
            current_app.logger.warning("Cloud JWT has an invalid session ID")
            return False
        if cloud_session_was_revoked(sid):
            return False
        if not _call_cloud_auth("validate", sid):
            current_app.logger.warning(f"Cloud JWT session is not active: {sid}")
            return False
        _set_session_state(sid, True)

        permission = claims["role"]
        if permission not in ("administrator", "operator+", "operator"):
            current_app.logger.warning(
                f"Cloud JWT has an unsupported permission: {permission}"
            )
            return False

        user_id = sid.rsplit("_", 1)[-1]
        if not user_id:
            return False

        session["user_id"] = user_id
        session["username"] = "PerleCLOUD"
        session["permission"] = permission
        session["auth_source"] = "cloud"
        session["cloud_sid"] = sid
        session["expires_at"] = datetime.fromtimestamp(
            claims["exp"], timezone.utc
        ).isoformat()
        session.permanent = True
        start_web_session("cloud")
        current_app.logger.info(f"Cloud authentication succeeded for session: {sid}")
        return True
    except (KeyError, StopIteration, TypeError, ValueError, jwt.PyJWTError) as error:
        current_app.logger.warning(f"Cloud authentication rejected: {error}")
    except requests.RequestException as error:
        current_app.logger.warning(f"Cloud authentication unavailable: {error}")
        raise ServiceUnavailable("Cloud authentication is temporarily unavailable. Please try again.") from error
    return False


def cloud_session_is_active() -> bool:
    if session.get("auth_source") != "cloud":
        return True

    sid = session.get("cloud_sid")
    if not isinstance(sid, str):
        return False

    with _session_states_lock:
        active = _session_states.get(sid)

    if active is None:
        try:
            active = _call_cloud_auth("validate", sid)
            if not isinstance(active, bool):
                raise ValueError("Cloud session validation response is invalid")
        except (requests.RequestException, TypeError, ValueError) as error:
            current_app.logger.warning(f"Cloud session validation unavailable: {error}")
            raise ServiceUnavailable("Cloud authentication is temporarily unavailable. Please try again.") from error
        _set_session_state(sid, active)
        return active

    return active
