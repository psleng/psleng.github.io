from pydantic import BaseModel
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, Text
import json

class IPTunnelConfig(db.Model):
    __tablename__ = 'vyos_config_iptunnel'

    id = Column(Integer, primary_key=True)
    
    tunnel_name = Column(String(255), nullable=False)
    tunnel_type = Column(String(50), nullable=False)  # gre, ipip, sit, vti
    description = Column(Text)
    disable = Column(Boolean, default=False)
    
    # Common tunnel parameters
    source_address = Column(String(255))
    remote_address = Column(String(255))
    ttl = Column(Integer)
    tos = Column(String(50))
    
    # GRE specific
    gre_key = Column(String(255))
    gre_checksum = Column(Boolean, default=False)
    
    # SIT specific
    sit_6rd_prefix = Column(String(255))
    sit_6rd_relay_prefix = Column(String(255))
    
    # ERSPAN specific
    erspan_direction = Column(String(50))  # Direction: ingress or egress
    
    # IP addresses
    ipv4_addresses = Column(Text)  # JSON array of addresses
    ipv6_addresses = Column(Text)  # JSON array of addresses
    
    # IPv6 options
    ipv6_eui64_prefix = Column(String(255))  # IPv6 EUI-64 prefix
    ipv6_accept_dad = Column(Integer)  # Duplicate Address Detection (0, 1, or 2)
    ipv6_dup_addr_detect_transmits = Column(Integer)  # Number of DAD NS transmits (0 or N)
    ipv6_base_reachable_time = Column(Integer)  # Base reachable time in seconds (1-3600000)
    ipv6_address_autoconf = Column(Boolean, default=False)  # Enable IPv6 address autoconfiguration
    ipv6_adjust_mss = Column(String(255))  # Adjust MSS (clamp-mss-to-pmtu or 536-65535)
    ipv6_disable_forwarding = Column(Boolean, default=False)  # Disable IPv6 forwarding
    ipv6_source_validation = Column(String(255))  # IPv6 source validation (strict, loose, or disable)
    ipv6_no_default_link_local = Column(Boolean, default=False)  # Remove default link-local IPv6 address
    
    # Interface parameters
    mtu = Column(Integer)
    multicast = Column(Boolean, default=False)
    
    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        db.session.execute(text("DELETE FROM vyos_config_iptunnel"))

    @classmethod
    def refresh(cls, config):
        """Refresh tunnel configurations from VyOS config"""
        try:
            cls.truncate()
            
            # Process different tunnel types
            tunnel_types = ['gre', 'ipip', 'sit', 'vti']
            
            for tunnel_type in tunnel_types:
                if tunnel_type in config:
                    for tunnel_name, tunnel_config in config[tunnel_type].items():
                        tunnel_record = cls()
                        tunnel_record.tunnel_name = tunnel_name
                        tunnel_record.tunnel_type = tunnel_type
                        tunnel_record.description = tunnel_config.get('description', '')
                        tunnel_record.disable = 'disable' in tunnel_config
                        
                        tunnel_record.source_address = tunnel_config.get('source-address', '')
                        tunnel_record.remote_address = tunnel_config.get('remote', '')
                        tunnel_record.ttl = tunnel_config.get('ttl')
                        tunnel_record.tos = tunnel_config.get('tos')
                        tunnel_record.mtu = tunnel_config.get('mtu')
                        tunnel_record.multicast = 'enable-multicast' in tunnel_config
                        tunnel_record.disable_link_detect = 'disable-link-detect' in tunnel_config
                        
                        # IP General Options
                        ip_config = tunnel_config.get('ip', {})
                        if ip_config:
                            tunnel_record.ip_arp_cache_timeout = int(ip_config.get('arp-cache-timeout', 30)) if 'arp-cache-timeout' in ip_config else None
                            tunnel_record.ip_adjust_mss = ip_config.get('adjust-mss', '')
                            tunnel_record.ip_enable_arp_accept = 'enable-arp-accept' in ip_config
                            tunnel_record.ip_enable_arp_announce = 'enable-arp-announce' in ip_config
                            tunnel_record.ip_disable_arp_filter = 'disable-arp-filter' in ip_config
                            tunnel_record.ip_enable_arp_ignore = 'enable-arp-ignore' in ip_config
                            tunnel_record.ip_enable_directed_broadcast = 'enable-directed-broadcast' in ip_config
                            tunnel_record.ip_disable_forwarding = 'disable-forwarding' in ip_config
                            tunnel_record.ip_enable_proxy_arp = 'enable-proxy-arp' in ip_config
                            tunnel_record.ip_enable_proxy_arp_pvlan = 'proxy-arp-pvlan' in ip_config
                        
                        # GRE specific
                        if tunnel_type == 'gre':
                            tunnel_record.gre_key = tunnel_config.get('key')
                            tunnel_record.gre_checksum = 'checksum' in tunnel_config
                        
                        # SIT specific  
                        if tunnel_type == 'sit':
                            tunnel_record.sit_6rd_prefix = tunnel_config.get('6rd-prefix')
                            tunnel_record.sit_6rd_relay_prefix = tunnel_config.get('6rd-relay-prefix')
                        
                        # ERSPAN specific
                        if tunnel_type == 'erspan':
                            parameters_config = tunnel_config.get('parameters', {})
                            if 'erspan' in parameters_config:
                                tunnel_record.erspan_direction = parameters_config['erspan'].get('direction', '')
                            else:
                                tunnel_record.erspan_direction = ''
                        
                        # Store IP addresses as JSON
                        addresses = tunnel_config.get('address', [])
                        if addresses:
                            ipv4_addrs = []
                            ipv6_addrs = []
                            for addr in addresses:
                                if ':' in addr:
                                    ipv6_addrs.append(addr)
                                else:
                                    ipv4_addrs.append(addr)
                            tunnel_record.ipv4_addresses = json.dumps(ipv4_addrs)
                            tunnel_record.ipv6_addresses = json.dumps(ipv6_addrs)
                        
                        # IPv6 options
                        ipv6_config = tunnel_config.get('ipv6', {})
                        if ipv6_config:
                            # IPv6 address options (under ipv6 > address)
                            address_config = ipv6_config.get('address', {})
                            if isinstance(address_config, dict):
                                # EUI-64 address
                                if 'eui64' in address_config:
                                    tunnel_record.ipv6_eui64_prefix = address_config['eui64']
                                else:
                                    tunnel_record.ipv6_eui64_prefix = ''
                                # Autoconf
                                if 'autoconf' in address_config:
                                    tunnel_record.ipv6_address_autoconf = True
                                else:
                                    tunnel_record.ipv6_address_autoconf = False
                                # No default link-local
                                if 'no-default-link-local' in address_config:
                                    tunnel_record.ipv6_no_default_link_local = True
                                else:
                                    tunnel_record.ipv6_no_default_link_local = False
                            else:
                                tunnel_record.ipv6_eui64_prefix = ''
                                tunnel_record.ipv6_address_autoconf = False
                                tunnel_record.ipv6_no_default_link_local = False
                            
                            # Accept DAD (Duplicate Address Detection)
                            if 'accept-dad' in ipv6_config:
                                tunnel_record.ipv6_accept_dad = int(ipv6_config['accept-dad'])
                            else:
                                tunnel_record.ipv6_accept_dad = None
                            
                            # Number of DAD transmits
                            if 'dup-addr-detect-transmits' in ipv6_config:
                                tunnel_record.ipv6_dup_addr_detect_transmits = int(ipv6_config['dup-addr-detect-transmits'])
                            else:
                                tunnel_record.ipv6_dup_addr_detect_transmits = None
                            
                            # Base reachable time
                            if 'base-reachable-time' in ipv6_config:
                                tunnel_record.ipv6_base_reachable_time = int(ipv6_config['base-reachable-time'])
                            else:
                                tunnel_record.ipv6_base_reachable_time = None
                            
                            # Adjust MSS
                            if 'adjust-mss' in ipv6_config:
                                tunnel_record.ipv6_adjust_mss = ipv6_config['adjust-mss']
                            else:
                                tunnel_record.ipv6_adjust_mss = ''
                            
                            # Disable forwarding
                            if 'disable-forwarding' in ipv6_config:
                                tunnel_record.ipv6_disable_forwarding = True
                            else:
                                tunnel_record.ipv6_disable_forwarding = False
                            
                            # Source validation
                            if 'source-validation' in ipv6_config:
                                tunnel_record.ipv6_source_validation = ipv6_config['source-validation']
                            else:
                                tunnel_record.ipv6_source_validation = ''
                        else:
                            # Reset all IPv6 options if no ipv6 config
                            tunnel_record.ipv6_eui64_prefix = ''
                            tunnel_record.ipv6_address_autoconf = False
                            tunnel_record.ipv6_accept_dad = None
                            tunnel_record.ipv6_dup_addr_detect_transmits = None
                            tunnel_record.ipv6_base_reachable_time = None
                            tunnel_record.ipv6_adjust_mss = ''
                            tunnel_record.ipv6_disable_forwarding = False
                            tunnel_record.ipv6_source_validation = ''
                            tunnel_record.ipv6_no_default_link_local = False
                        
                        db.session.add(tunnel_record)
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            print(f"Error refreshing IP tunnel data: {e}")
            raise e

    def get_full_config(self):
        """Return the full tunnel configuration in VyOS format"""
        config = {}
        
        tunnel_config = {}
        
        if self.description:
            tunnel_config['description'] = self.description
        
        if self.disable:
            tunnel_config['disable'] = {}
        
        if self.source_address:
            tunnel_config['source-address'] = self.source_address
        
        if self.remote_address:
            tunnel_config['remote'] = self.remote_address
        
        if self.ttl:
            tunnel_config['ttl'] = self.ttl
        
        if self.tos:
            tunnel_config['tos'] = self.tos
        
        if self.mtu:
            tunnel_config['mtu'] = self.mtu
        
        if self.multicast:
            tunnel_config['multicast'] = {}
        
        # Add tunnel type specific configs
        if self.tunnel_type == 'gre':
            if self.gre_key:
                tunnel_config['key'] = self.gre_key
            if self.gre_checksum:
                tunnel_config['checksum'] = {}
        
        elif self.tunnel_type == 'sit':
            if self.sit_6rd_prefix:
                tunnel_config['6rd-prefix'] = self.sit_6rd_prefix
            if self.sit_6rd_relay_prefix:
                tunnel_config['6rd-relay-prefix'] = self.sit_6rd_relay_prefix
        
        elif self.tunnel_type == 'erspan':
            if self.erspan_direction:
                if 'parameters' not in tunnel_config:
                    tunnel_config['parameters'] = {}
                if 'erspan' not in tunnel_config['parameters']:
                    tunnel_config['parameters']['erspan'] = {}
                tunnel_config['parameters']['erspan']['direction'] = self.erspan_direction
        
        # Add IP addresses
        addresses = []
        if self.ipv4_addresses:
            try:
                addresses.extend(json.loads(self.ipv4_addresses))
            except (json.JSONDecodeError, TypeError):
                pass
        
        if self.ipv6_addresses:
            try:
                addresses.extend(json.loads(self.ipv6_addresses))
            except (json.JSONDecodeError, TypeError):
                pass
        
        if addresses:
            tunnel_config['address'] = addresses
        
        # IPv6 options
        if self.ipv6_eui64_prefix or self.ipv6_accept_dad is not None or self.ipv6_dup_addr_detect_transmits is not None or self.ipv6_base_reachable_time is not None or self.ipv6_address_autoconf or self.ipv6_adjust_mss or self.ipv6_disable_forwarding or self.ipv6_source_validation or self.ipv6_no_default_link_local:
            if 'ipv6' not in tunnel_config:
                tunnel_config['ipv6'] = {}
            
            # IPv6 address options
            if self.ipv6_eui64_prefix or self.ipv6_address_autoconf or self.ipv6_no_default_link_local:
                if 'address' not in tunnel_config['ipv6']:
                    tunnel_config['ipv6']['address'] = {}
                
                if self.ipv6_eui64_prefix:
                    tunnel_config['ipv6']['address']['eui64'] = self.ipv6_eui64_prefix
                
                if self.ipv6_address_autoconf:
                    tunnel_config['ipv6']['address']['autoconf'] = {}
                
                if self.ipv6_no_default_link_local:
                    tunnel_config['ipv6']['address']['no-default-link-local'] = {}
            
            # Accept DAD (directly under ipv6)
            if self.ipv6_accept_dad is not None:
                tunnel_config['ipv6']['accept-dad'] = str(self.ipv6_accept_dad)
            
            # DAD transmits (directly under ipv6)
            if self.ipv6_dup_addr_detect_transmits is not None:
                tunnel_config['ipv6']['dup-addr-detect-transmits'] = str(self.ipv6_dup_addr_detect_transmits)
            
            # Base reachable time (directly under ipv6)
            if self.ipv6_base_reachable_time is not None:
                tunnel_config['ipv6']['base-reachable-time'] = str(self.ipv6_base_reachable_time)
            
            # Adjust MSS (directly under ipv6)
            if self.ipv6_adjust_mss:
                tunnel_config['ipv6']['adjust-mss'] = self.ipv6_adjust_mss
            
            # Disable forwarding (flag - directly under ipv6)
            if self.ipv6_disable_forwarding:
                tunnel_config['ipv6']['disable-forwarding'] = {}
            
            # Source validation (directly under ipv6)
            if self.ipv6_source_validation:
                tunnel_config['ipv6']['source-validation'] = self.ipv6_source_validation
        
        # Structure the config by tunnel type
        if self.tunnel_type not in config:
            config[self.tunnel_type] = {}
        
        config[self.tunnel_type][self.tunnel_name] = tunnel_config
        
        return config

    @classmethod
    def get_current_config(cls):
        """Get all current tunnel configurations"""
        records = cls.query.all()
        if not records:
            return {}
        
        config = {}
        for record in records:
            tunnel_config = record.get_full_config()
            # Merge configs by tunnel type
            for tunnel_type, tunnels in tunnel_config.items():
                if tunnel_type not in config:
                    config[tunnel_type] = {}
                config[tunnel_type].update(tunnels)
        
        return config

    def serialize(self):
        """Serialize tunnel record for API responses"""
        ipv4_addrs = []
        ipv6_addrs = []
        
        if self.ipv4_addresses:
            try:
                ipv4_addrs = json.loads(self.ipv4_addresses)
            except (json.JSONDecodeError, TypeError):
                pass
        
        if self.ipv6_addresses:
            try:
                ipv6_addrs = json.loads(self.ipv6_addresses)
            except (json.JSONDecodeError, TypeError):
                pass
        
        return {
            'id': self.id,
            'tunnel_name': self.tunnel_name,
            'tunnel_type': self.tunnel_type,
            'description': self.description,
            'disable': self.disable,
            'source_address': self.source_address,
            'remote_address': self.remote_address,
            'ttl': self.ttl,
            'tos': self.tos,
            'mtu': self.mtu,
            'multicast': self.multicast,
            'gre_key': self.gre_key,
            'gre_checksum': self.gre_checksum,
            'sit_6rd_prefix': self.sit_6rd_prefix,
            'sit_6rd_relay_prefix': self.sit_6rd_relay_prefix,
            'ipv4_addresses': ipv4_addrs,
            'ipv6_addresses': ipv6_addrs,
            'ipv6_eui64_prefix': self.ipv6_eui64_prefix,
            'ipv6_accept_dad': self.ipv6_accept_dad,
            'ipv6_dup_addr_detect_transmits': self.ipv6_dup_addr_detect_transmits,
            'ipv6_base_reachable_time': self.ipv6_base_reachable_time,
            'ipv6_address_autoconf': self.ipv6_address_autoconf,
            'ipv6_adjust_mss': self.ipv6_adjust_mss,
            'ipv6_disable_forwarding': self.ipv6_disable_forwarding,
            'ipv6_source_validation': self.ipv6_source_validation,
            'ipv6_no_default_link_local': self.ipv6_no_default_link_local,
            'erspan_direction': self.erspan_direction,
        }


class CreateIPTunnelInterfaceDTO(BaseModel):
    tunnel_name: str
    tunnel_type: str = "gre"  # gre, ipip, sit, vti
    description: str = ""
    disable: bool = False
    source_address: str = ""
    remote_address: str = ""
    ttl: int = None
    tos: str = ""
    mtu: int = None
    multicast: bool = False
    disable_link_detect: bool = False
    # IP General Options
    ip_arp_cache_timeout: int = None
    ip_adjust_mss: str = ""
    ip_enable_arp_accept: bool = False
    ip_enable_arp_announce: bool = False
    ip_disable_arp_filter: bool = False
    ip_enable_arp_ignore: bool = False
    ip_enable_directed_broadcast: bool = False
    ip_disable_forwarding: bool = False
    ip_enable_proxy_arp: bool = False
    ip_enable_proxy_arp_pvlan: bool = False
    ip_source_validation: str = ""
    gre_key: str = ""
    gre_checksum: bool = False
    sit_6rd_prefix: str = ""
    sit_6rd_relay_prefix: str = ""
    ipv4_addresses: list = []
    ipv6_addresses: list = []
    ipv6_eui64_prefix: str = ""
    ipv6_accept_dad: int = None
    ipv6_dup_addr_detect_transmits: int = None
    ipv6_base_reachable_time: int = None
    ipv6_address_autoconf: bool = False
    ipv6_adjust_mss: str = ""
    ipv6_disable_forwarding: bool = False
    ipv6_source_validation: str = ""
    ipv6_no_default_link_local: bool = False
    erspan_direction: str = ""