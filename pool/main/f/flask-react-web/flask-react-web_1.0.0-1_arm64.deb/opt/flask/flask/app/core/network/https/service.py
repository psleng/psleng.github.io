
import pprint
from flask import session
from uuid import uuid4

from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_HTTPS_CONFIG
from app.core.network.https.command_https import HTTPSCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.socket.socket_manager import socket_manager
from app.core.network.https.models import HTTPSConfig


def fetch_https_config(provider, params=None):
    https_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_HTTPS_CONFIG, verify=False)
    data = https_response.json().get('data')
    parsed = data or {}
    return parsed


def update_https(provider, data):
    username = session.get('username')
    diff = data.get('diff')
    current_https = data.get('current')
    new_https = data.get('new')

    print('HTTPS Diff data:')
    print(pprint.pformat(diff, indent=2, width=80))

    r = []

    # Set commands
    https_set_cmd = HTTPSCommand(operator='set', resource='service')
    set_cmds = https_set_cmd.generate_commands((diff or {}).get('created') or {}, current_https, new_https)
    sc = https_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    print("New set config: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    # Delete commands
    https_del_cmd = HTTPSCommand(operator='delete', resource='service')
    delete_cmds = https_del_cmd.generate_commands((diff or {}).get('deleted') or {}, current_https, new_https)
    dc = https_del_cmd.get_commands()
    delete_certificates = 'service https certificates' in dc
    new_del_configs = process_commands([cmd for cmd in dc if cmd != 'service https certificates'])

    print("New delete config: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    # Validate
    
    service = "service_https"
    curr_config = {}
    try:
        curr_config = provider.verify_service.call_get_config(service)
    except Exception as e:
        print("Error getting current https config:")
        print(str(e))
        curr_config = {}

    current_raw_config = curr_config if curr_config else {}
    print("Current raw config:")
    print(pprint.pformat(current_raw_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        current_raw_config,
        new_del_configs.get('service', {}).get('https', {}),
        clean_empty=False
    )
    if delete_certificates:
        merged_del_config.pop('certificates', None)
        merged_del_config.get('service', {}).get('https', {}).pop('certificates', None)
    merged_config = merge_dicts_set(
        merged_del_config,
        new_set_configs.get('service', {}).get('https', {})
    )

    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    verify = None
    if 'service' in merged_config and 'https' in merged_config['service']:
        verify = provider.verify_service.call_verify(service, merged_config['service']['https'])

    print('HTTPS verify:')
    print(pprint.pformat(verify, indent=2, width=80))

    if str(verify) not in ('None', '', 'null') and verify is not None and verify != {}:
        return Exception(verify)

    # Update DB 
    HTTPSConfig.refresh(new_https)

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update HTTPS',
            'content': 'HTTPS is successfully updated'
        }
    )

    executed_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    if len(executed_cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=executed_cmds, verify=False).json()
        r.append({'cmd': executed_cmds, 'success': res.get('success'), 'error': res.get('error')})

    return r


def verify_https(provider, data):
    service = 'service_https'
    verify = provider.verify_service.call_verify(service, data)
    return verify
