from pydantic import BaseModel
from typing import Optional, List
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.log.logger import logger
import json

class AreaRangeDTO(BaseModel):
    prefix: str
    advertise: bool = True


class AreaTypeConfigDTO(BaseModel):
    defaultInformationOriginate: bool = False
    noSummary: bool = False


class AreaDTO(BaseModel):
    id: Optional[str] = None
    areaNumber: str
    ranges: List[AreaRangeDTO] = []
    areaType: str = "normal"
    areaTypeConfig: AreaTypeConfigDTO = AreaTypeConfigDTO()


class InterfaceDTO(BaseModel):
    id: Optional[str] = None
    name: str
    area: str
    cost: Optional[str] = ""
    deadInterval: Optional[str] = ""
    helloInterval: Optional[str] = ""
    ifmtu: Optional[str] = ""
    instanceId: Optional[str] = ""
    mtuIgnore: bool = False
    network: str = "broadcast"
    passive: bool = False
    priority: Optional[str] = ""
    retransmitInterval: Optional[str] = ""
    transmitDelay: Optional[str] = ""


class RedistributionProtocolDTO(BaseModel):
    enabled: bool = False
    metric: Optional[str] = ""
    metricType: Optional[str] = ""


class RedistributionDTO(BaseModel):
    connected: RedistributionProtocolDTO = RedistributionProtocolDTO()
    kernel: RedistributionProtocolDTO = RedistributionProtocolDTO()
    static: RedistributionProtocolDTO = RedistributionProtocolDTO()


class AdvancedConfigDTO(BaseModel):
    autoCostReferenceBandwidth: Optional[str] = ""
    defaultInformationAlways: bool = False
    defaultInformationMetric: Optional[str] = ""
    defaultInformationMetricType: Optional[str] = ""
    logAdjacencyChanges: bool = False
    routerId: Optional[str] = ""
    distanceGlobal: Optional[str] = ""
    distanceOspfExternal: Optional[str] = ""
    distanceOspfInterArea: Optional[str] = ""
    distanceOspfIntraArea: Optional[str] = ""
    gracefulRestart: bool = False
    gracefulRestartGracePeriod: Optional[str] = ""


class UpdateOSPFv3DTO(BaseModel):
    areas: Optional[List[AreaDTO]] = []
    interfaces: Optional[List[InterfaceDTO]] = []
    redistribution: RedistributionDTO = RedistributionDTO()
    advanced: AdvancedConfigDTO = AdvancedConfigDTO()


class VerifyOSPFv3DTO(BaseModel):
    verify_type: str
    areas: Optional[List[AreaDTO]] = []
    interfaces: Optional[List[InterfaceDTO]] = []


class OSPFv3Config(db.Model):
    __tablename__ = 'vyos_config_ospfv3'
    
    id = Column(Integer, primary_key=True)
    
    auto_cost_reference_bandwidth = Column(Integer)
    log_adjacency_changes_detail = Column(Boolean, default=False)
    
    parameters_router_id = Column(String(50))
    
    default_information_always = Column(Boolean, default=False)
    default_information_metric = Column(Integer)
    default_information_metric_type = Column(Integer)
    
    distance_global = Column(Integer)
    distance_ospf_external = Column(Integer)
    distance_ospf_inter_area = Column(Integer)
    distance_ospf_intra_area = Column(Integer)
    
    graceful_restart = Column(Boolean, default=False)
    graceful_restart_grace_period = Column(Integer)
    
    areas = relationship("OSPFv3Area", back_populates="ospfv3_config", cascade="all, delete-orphan")
    interfaces = relationship("OSPFv3Interface", back_populates="ospfv3_config", cascade="all, delete-orphan")
    redistributes = relationship("OSPFv3Redistribute", back_populates="ospfv3_config", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'id': self.id,
            'auto_cost_reference_bandwidth': self.auto_cost_reference_bandwidth,
            'log_adjacency_changes_detail': self.log_adjacency_changes_detail,
            'parameters_router_id': self.parameters_router_id,
            'default_information_always': self.default_information_always,
            'default_information_metric': self.default_information_metric,
            'default_information_metric_type': self.default_information_metric_type,
            'distance_global': self.distance_global,
            'distance_ospf_external': self.distance_ospf_external,
            'distance_ospf_inter_area': self.distance_ospf_inter_area,
            'distance_ospf_intra_area': self.distance_ospf_intra_area,
            'graceful_restart': self.graceful_restart,
            'graceful_restart_grace_period': self.graceful_restart_grace_period,
            'areas': [area.serialize() for area in self.areas],
            'interfaces': [intf.serialize() for intf in self.interfaces],
            'redistributes': [r.serialize() for r in self.redistributes]
        }

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_ospfv3_area_range',
            'vyos_config_ospfv3_area',
            'vyos_config_ospfv3_interface',
            'vyos_config_ospfv3_redistribute',
            'vyos_config_ospfv3'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh OSPFv3 configuration from VyOS data"""
        try:
            logger.info("Refreshing OSPFv3 configuration")
            logger.info(data)
            cls.truncate()
            
            ospfv3_config = cls()
            
            if 'auto-cost' in data and 'reference-bandwidth' in data['auto-cost']:
                ospfv3_config.auto_cost_reference_bandwidth = int(data['auto-cost']['reference-bandwidth'])
            
            ospfv3_config.log_adjacency_changes_detail = 'log-adjacency-changes' in data and 'detail' in data.get('log-adjacency-changes', {})
            
            if 'parameters' in data:
                params = data['parameters']
                ospfv3_config.parameters_router_id = params.get('router-id')
            
            if 'default-information' in data:
                default_info = data['default-information']
                ospfv3_config.default_information_always = 'always' in default_info
                if 'metric' in default_info:
                    ospfv3_config.default_information_metric = int(default_info['metric'])
                if 'metric-type' in default_info:
                    ospfv3_config.default_information_metric_type = int(default_info['metric-type'])
            
            if 'distance' in data:
                distance = data['distance']
                if 'global' in distance:
                    ospfv3_config.distance_global = int(distance['global'])
                if 'ospf' in distance:
                    ospf_dist = distance['ospf']
                    if 'external' in ospf_dist:
                        ospfv3_config.distance_ospf_external = int(ospf_dist['external'])
                    if 'inter-area' in ospf_dist:
                        ospfv3_config.distance_ospf_inter_area = int(ospf_dist['inter-area'])
                    if 'intra-area' in ospf_dist:
                        ospfv3_config.distance_ospf_intra_area = int(ospf_dist['intra-area'])
            
            if 'graceful-restart' in data:
                gr = data['graceful-restart']
                ospfv3_config.graceful_restart = True
                if isinstance(gr, dict) and 'grace-period' in gr:
                    ospfv3_config.graceful_restart_grace_period = int(gr['grace-period'])
            
            db.session.add(ospfv3_config)
            db.session.flush()
            
            if 'area' in data:
                for area_num, area_data in data['area'].items():
                    area = OSPFv3Area(
                        ospfv3_config_id=ospfv3_config.id,
                        area_number=str(area_num)
                    )
                    
                    if 'area-type' in area_data:
                        area_type = area_data['area-type']
                        if 'normal' in area_type:
                            area.area_type = 'normal'
                        elif 'nssa' in area_type:
                            area.area_type = 'nssa'
                            nssa = area_type['nssa']
                            area.area_type_default_information_originate = 'default-information-originate' in nssa
                            area.area_type_no_summary = 'no-summary' in nssa
                        elif 'stub' in area_type:
                            area.area_type = 'stub'
                            stub = area_type['stub']
                            area.area_type_no_summary = 'no-summary' in stub
                    
                    db.session.add(area)
                    db.session.flush()
                    
                    if 'range' in area_data:
                        for range_prefix, range_data in area_data['range'].items():
                            area_range = OSPFv3AreaRange(
                                area_id=area.id,
                                range_prefix=range_prefix,
                                advertise='advertise' in range_data if isinstance(range_data, dict) else True
                            )
                            db.session.add(area_range)
            
            if 'interface' in data:
                for intf_name, intf_data in data['interface'].items():
                    interface = OSPFv3Interface(
                        ospfv3_config_id=ospfv3_config.id,
                        interface_name=intf_name,
                        area=str(intf_data['area']) if 'area' in intf_data else None,
                        cost=int(intf_data['cost']) if 'cost' in intf_data else None,
                        dead_interval=int(intf_data['dead-interval']) if 'dead-interval' in intf_data else None,
                        hello_interval=int(intf_data['hello-interval']) if 'hello-interval' in intf_data else None,
                        ifmtu=int(intf_data['ifmtu']) if 'ifmtu' in intf_data else None,
                        instance_id=int(intf_data['instance-id']) if 'instance-id' in intf_data else None,
                        mtu_ignore='mtu-ignore' in intf_data,
                        network=intf_data.get('network'),
                        passive='passive' in intf_data,
                        priority=int(intf_data['priority']) if 'priority' in intf_data else None,
                        retransmit_interval=int(intf_data['retransmit-interval']) if 'retransmit-interval' in intf_data else None,
                        transmit_delay=int(intf_data['transmit-delay']) if 'transmit-delay' in intf_data else None
                    )
                    db.session.add(interface)
            
            if 'redistribute' in data:
                redistribute_data = data['redistribute']
                if isinstance(redistribute_data, str):
                    redistribute_data = [redistribute_data]
                if isinstance(redistribute_data, list):
                    redistribute_data = {proto: {} for proto in redistribute_data}
                for protocol, protocol_data in redistribute_data.items():
                    redistribute = OSPFv3Redistribute(
                        ospfv3_config_id=ospfv3_config.id,
                        protocol=protocol,
                        metric=int(protocol_data['metric']) if isinstance(protocol_data, dict) and 'metric' in protocol_data else None,
                        metric_type=int(protocol_data['metric-type']) if isinstance(protocol_data, dict) and 'metric-type' in protocol_data else None
                    )
                    db.session.add(redistribute)
            
            db.session.commit()
            logger.info("OSPFv3 configuration refreshed successfully")
            
        except Exception as e:
            logger.error(f"Error refreshing OSPFv3 configuration: {e}")
            # db.session.rollback()
            raise


class OSPFv3Area(db.Model):
    __tablename__ = 'vyos_config_ospfv3_area'
    
    id = Column(Integer, primary_key=True)
    ospfv3_config_id = Column(Integer, ForeignKey('vyos_config_ospfv3.id'), nullable=False)
    area_number = Column(String(50), nullable=False)
    area_type = Column(String(50))
    area_type_default_information_originate = Column(Boolean, default=False)
    area_type_no_summary = Column(Boolean, default=False)
    
    ospfv3_config = relationship("OSPFv3Config", back_populates="areas")
    ranges = relationship("OSPFv3AreaRange", back_populates="area", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'area_number': self.area_number,
            'area_type': self.area_type,
            'area_type_default_information_originate': self.area_type_default_information_originate,
            'area_type_no_summary': self.area_type_no_summary,
            'ranges': [r.serialize() for r in self.ranges]
        }


class OSPFv3AreaRange(db.Model):
    __tablename__ = 'vyos_config_ospfv3_area_range'
    
    id = Column(Integer, primary_key=True)
    area_id = Column(Integer, ForeignKey('vyos_config_ospfv3_area.id'), nullable=False)
    range_prefix = Column(String(100), nullable=False)
    advertise = Column(Boolean, default=True)
    
    area = relationship("OSPFv3Area", back_populates="ranges")
    
    def serialize(self):
        return {
            'range_prefix': self.range_prefix,
            'advertise': self.advertise
        }


class OSPFv3Interface(db.Model):
    __tablename__ = 'vyos_config_ospfv3_interface'
    
    id = Column(Integer, primary_key=True)
    ospfv3_config_id = Column(Integer, ForeignKey('vyos_config_ospfv3.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    area = Column(String(50))
    cost = Column(Integer)
    dead_interval = Column(Integer)
    hello_interval = Column(Integer)
    ifmtu = Column(Integer)
    instance_id = Column(Integer)
    mtu_ignore = Column(Boolean, default=False)
    network = Column(String(50))
    passive = Column(Boolean, default=False)
    priority = Column(Integer)
    retransmit_interval = Column(Integer)
    transmit_delay = Column(Integer)
    
    ospfv3_config = relationship("OSPFv3Config", back_populates="interfaces")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name,
            'area': self.area,
            'cost': self.cost,
            'dead_interval': self.dead_interval,
            'hello_interval': self.hello_interval,
            'ifmtu': self.ifmtu,
            'instance_id': self.instance_id,
            'mtu_ignore': self.mtu_ignore,
            'network': self.network,
            'passive': self.passive,
            'priority': self.priority,
            'retransmit_interval': self.retransmit_interval,
            'transmit_delay': self.transmit_delay
        }


class OSPFv3Redistribute(db.Model):
    __tablename__ = 'vyos_config_ospfv3_redistribute'
    
    id = Column(Integer, primary_key=True)
    ospfv3_config_id = Column(Integer, ForeignKey('vyos_config_ospfv3.id'), nullable=False)
    protocol = Column(String(50), nullable=False)
    metric = Column(Integer)
    metric_type = Column(Integer)
    
    ospfv3_config = relationship("OSPFv3Config", back_populates="redistributes")
    
    def serialize(self):
        return {
            'protocol': self.protocol,
            'metric': self.metric,
            'metric_type': self.metric_type
        }


OSPFv3 = OSPFv3Config
