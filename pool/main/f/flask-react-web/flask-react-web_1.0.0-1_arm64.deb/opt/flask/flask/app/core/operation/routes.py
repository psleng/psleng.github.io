from app.core.operation.bridge.parser import parse_to_bridge_config, parse_current_bridge_interface_config
from app.core.operation.ethernet.parser import parse_current_ethernet_interface_config, parse_all_bridge_interfaces_config
from app.core.operation.models import CreateBridgeInterfaceDTO, UpdateBridgeInterfaceDTO
from . import vyos_operation_bp
from flask import jsonify, request, current_app, session, send_from_directory
import json
from app.core.operation.models import CreateOpenvpnInterfaceDTO, CreateInterfaceDTO, UpdateSystemDatetimeDTO, UpdateSystemInfoDTO, UpdateInterfaceDTO, UpdateEthernetInterfaceByNameDTO, \
     DeleteInterfaceAddressDTO, DeleteInterfaceListDTO, UpdateInterfaceAddressDTO, CreateInterfaceAddressDTO, UpdateWifiInterfaceByNameDTO, UpdateOpenVPNInterfaceByNameDTO, UpdateAllOpenvpnInterfacesDTO, OpenVPNMonitorDTO, OnboardingConfigurationDTO, \
      CreateIPTunnelInterfaceDTO, UpdateIPTunnelInterfaceDTO
from app.core.models import Interface, Memory, System, ServiceStatistic, UpdateSelectedServicesDTO, Services, SelectedServices, AdminSelectedService
from pydantic import ValidationError
from app.event.jobs.interface.fetch_interface import refresh_db_interface_operation
from app.event.jobs.system.performance import refresh_db_memory_operation, salt_fetch_cpu
from app.event.jobs.system.system_info import refresh_db_system_info
from app.event.a_sync.interface import update_intf_async, update_intf_address_async, create_intf_address_async, delete_intf_address_async
from app.core.utils.system_time import system_timestamp, system_utc_timestamp
from datetime import datetime
import pytz
import subprocess
import os 
import shutil
from app.core.utils.system import get_load_averages
import threading
from app.auth.utils import login_required, permission_required
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.operation.ethernet.parser import parse_to_ethernet_config
from app.core.operation.openvpn.parser import parse_to_openvpn_config, parse_current_openvpn_interface_config, parse_to_openvpn_bulk_config
from app.core.operation.parser import parse_to_interface_config
from app.core.network.dhcp.parser import parse_to_single_dhcp_pool
import pprint
from app.core.security.models import FirewallOperation
from app.event.jobs.interface.fetch_interface import refresh_db_interface_operation
from app.core.operation.service import get_selected_services
from app.core.api.http.cmd.compare import compare_configs
from app.core.operation.wifi.models import WiFiInterfaceConfig
from copy import deepcopy
from app.core.network.dhcp.parser import parse_dhcp
from app.core.operation.parser import parse_to_system_config, parse_system
from app.core.utils.process_config import normalize_config
from app.core.models import SystemDefault
from app.log.logger import logger
from app.db import db
from app.core.utils.check_os import is_linux
from app.core.operation.system_information import parse_boot_images, parse_system_version, parse_wireless_country_code
from app.core.operation.models import UserManagement
from app.auth.models import User, TempUserExpiryTime
from app.core.operation.models import UserVerifyDTO, UpdateUserDTO
from app.core.api.http.srv.parser import parse_to_single_user_config, parse_to_user_config, parse_user_db_to_user_config
from app.core.operation.wireguard.parser import parse_to_wireguard_config, parse_current_wireguard_interface_config, parse_to_wireguard_bulk_config
from app.core.operation.models import UpdateWireguardInterfaceByNameDTO, CreateWireguardInterfaceDTO, UpdateAllWireguardInterfacesDTO, UpdateVlanInterfaceDTO
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig
from app.core.operation.l2tpv3.models import L2TPv3InterfaceConfig
from app.core.operation.wireguard.models import WireguardInterfaceConfig
from app.core.operation.models import PKICaCertificate, PKICertificate, OpenVPNSharedSecretKey, KeyPair, PKIDH, PKIOpenSSHKey
from app.core.operation.ipsec.models import IPsecConfig, UpdateIPsecInterfaceDTO, CreateIPsecInterfaceDTO
from app.core.operation.ipsec.parser import _parse_with_vti_addresses, parse_to_ipsec_config, parse_current_ipsec_interface_config
from app.core.operation.iptunnels.models import IPTunnelConfig
from app.core.operation.utils import read_ike_dh_group, read_ike_encryption, read_ike_hash, read_ike_pseudo_random_function, read_esp_encryption, read_esp_hash, read_esp_pfs
from app.core.operation.vlan.parser import parse_to_vlan_config, parse_current_vlan_interface_config
from app.core.operation.vlan.models import VLANInterfaceConfig
from app.core.operation.bridge.models import BridgeInterfaceConfig
from app.core.utils.validate.pydantic_error_format import format_pydantic_error
from app.core.operation.models import InterfaceAddressDHCP
from app.core.models import InterfaceConfig
from app.core.api.http.http_request import HTTPRequest, Action
from app.core.api.http.cmd.command import SHOW_SYSTEMS_BOOT_IMG, SHOW_SYSTEMS_VERSION
from app.core.api.http.graphql_requests import GraphqlRequest
from urllib.parse import urlparse
from werkzeug.utils import secure_filename
from app.core.operation.cellular.parser import parse_to_wwan_config, parse_current_wwan_interface_config
from app.core.operation.cellular.models import (
    UpdateWWANInterfaceDTO,
    WWANInterfaceConfig,
)
from app.core.operation.system_reboot import get_reboot_status as get_reboot_status_service, run_reboot_command
from app.core.operation.models import SoftwareUpdateJob
from app.core.operation.software_management.software_update import create_job, delete_temporary_image
from app.core.operation.software_management.models import SoftwareUpdateCheckConfig, UpdateSoftwareManagementDTO
from app.core.operation.software_management.parsers import parse_to_vyos_config
from app.core.operation.software_management.service import get_system_update_status
from app.core.operation.diagnose.models import PingDiagnosticDTO, TracerouteDiagnosticDTO
from app.core.operation.diagnose.service import DiagnosticServiceError
from app.socket.socket_manager import socket_manager
from app.core.api.http.srv.onboarding import OnboardingConfigurationError, OnboardingValidationError

SOFTWARE_IMAGE_STORAGE_ROOT = "/var/lib/flask"


def _read_onboarding_status():
    field = 'ShowIgosOnboardingPerleIgosOnboardingQuery'
    response = GraphqlRequest().send_request(
        function_name=field,
        data=None,
        verify=False,
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict) or payload.get('errors'):
        raise ValueError('Unable to query the device onboarding status.')

    query_data = (payload.get('data') or {}).get(field)
    if not isinstance(query_data, dict) or query_data.get('success') is not True or query_data.get('errors'):
        raise ValueError('The device onboarding status query failed.')

    result = (query_data.get('data') or {}).get('result')
    if not isinstance(result, dict) or not isinstance(result.get('required'), bool):
        raise ValueError('The device returned an invalid onboarding status.')

    return {'required': result['required']}


@vyos_operation_bp.route('/onboarding/status', methods=['GET'])
@login_required
def get_onboarding_status():
    try:
        return jsonify(_read_onboarding_status()), 200
    except Exception as error:
        logger.error("Failed to read onboarding status: %s", error)
        return jsonify({"error": "The device onboarding status could not be read."}), 502


@vyos_operation_bp.route('/onboarding/complete', methods=['POST'])
@login_required
def complete_onboarding():
    try:
        refreshed_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.OS_CONFIG,
            data={"refresh": True},
        )
        if isinstance(refreshed_config, Exception) or not refreshed_config:
            raise ValueError("Unable to refresh the saved VyOS configuration")
        status = _read_onboarding_status()
    except Exception as error:
        logger.error("Failed to refresh onboarding status: %s", error)
        return jsonify({"error": "The saved device configuration could not be refreshed."}), 502

    if status['required']:
        return jsonify({"error": "Configure the device timezone before completing setup."}), 400

    return jsonify(status), 200


@vyos_operation_bp.route('/onboarding/configure', methods=['POST'])
@login_required
def configure_onboarding():
    try:
        configuration = OnboardingConfigurationDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.ONBOARDING,
            data={
                **configuration.model_dump(),
                'username': session['username'],
            },
        )
        if isinstance(result, OnboardingValidationError):
            return jsonify({'verify': str(result)}), 400
        if isinstance(result, Exception):
            logger.error('Failed to configure onboarding: %s', result)
            return jsonify({'error': str(result)}), 502
        return jsonify(result), 200
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except OnboardingValidationError as error:
        return jsonify({'verify': str(error)}), 400
    except OnboardingConfigurationError as error:
        logger.error('Failed to configure onboarding: %s', error)
        return jsonify({'error': str(error)}), 502
    except Exception as error:
        logger.error('Failed to configure onboarding: %s', error)
        return jsonify({'error': 'The initial device configuration could not be saved.'}), 500


@vyos_operation_bp.route('/diagnose/ping', methods=['POST'])
@login_required
def diagnose_ping():
    try:
        diagnostic = PingDiagnosticDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DIAGNOSE_PING,
            data=diagnostic,
        )
        if isinstance(result, DiagnosticServiceError):
            return jsonify({'error': str(result)}), 502
        if isinstance(result, Exception):
            logger.error(f'Ping diagnostic failed: {str(result)}')
            return jsonify({'error': 'Unable to run ping diagnostic.'}), 500
        return jsonify(result), 200
    except ValidationError as exc:
        return jsonify({'error': format_pydantic_error(exc)}), 400
    except DiagnosticServiceError as exc:
        return jsonify({'error': str(exc)}), 502
    except Exception as exc:
        logger.error(f'Ping diagnostic failed: {str(exc)}')
        return jsonify({'error': 'Unable to run ping diagnostic.'}), 500


@vyos_operation_bp.route('/diagnose/traceroute', methods=['POST'])
@login_required
def diagnose_traceroute():
    try:
        diagnostic = TracerouteDiagnosticDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DIAGNOSE_TRACEROUTE,
            data=diagnostic,
        )
        if isinstance(result, DiagnosticServiceError):
            return jsonify({'error': str(result)}), 502
        if isinstance(result, Exception):
            logger.error(f'Traceroute diagnostic failed: {str(result)}')
            return jsonify({'error': 'Unable to run traceroute diagnostic.'}), 500
        return jsonify(result), 200
    except ValidationError as exc:
        return jsonify({'error': format_pydantic_error(exc)}), 400
    except DiagnosticServiceError as exc:
        return jsonify({'error': str(exc)}), 502
    except Exception as exc:
        logger.error(f'Traceroute diagnostic failed: {str(exc)}')
        return jsonify({'error': 'Unable to run traceroute diagnostic.'}), 500


def _software_image_options(data):
    def as_bool(name):
        value = data.get(name, False)
        return value if isinstance(value, bool) else str(value).lower() == 'true'

    set_as_default = as_bool('setAsDefault')
    return {
        'image_name': str(data.get('imageName', '')).strip(),
        'set_as_default': set_as_default,
        'reboot_after_update': set_as_default and as_bool('rebootAfterUpdate'),
        'copy_config': as_bool('copyConfigs'),
        'copy_ssh_host_keys': as_bool('copySshHostKey'),
        'copy_ssh_known_hosts': as_bool('copySshKnownHost'),
    }

@vyos_operation_bp.route('/system/load-average/history', methods=['GET'])
def get_load_average_history():
    try:
        from app.core.models import LoadAverageHistory
        interval = (request.args.get('interval') or 'fast').strip().lower()

        # Each data point is collected every 5 seconds.
        # - fast: return up to 60 points (5s spacing)
        # - slow: return up to 60 points (30s spacing => every 6th point)
        max_points = 60

        try:
            limit = int(request.args.get('limit', max_points))
        except Exception:
            limit = max_points
        if limit <= 0:
            limit = max_points
        limit = min(limit, max_points)

        # pull max data point from in-memory: 360
        raw = LoadAverageHistory.get_last(360)

        if interval == 'slow':
            rows = raw[::6]
        else:
            rows = raw

        if len(rows) > limit:
            rows = rows[-limit:]

        return jsonify([r.serialize() for r in rows]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


def run_command(command):
    return subprocess.Popen(command, shell=True, stdout=subprocess.PIPE).stdout.read().decode('utf-8')


def _validate_software_image_source(source):
    if not isinstance(source, str):
        return "ISO source is required"

    value = source.strip()
    if value == "":
        return "ISO source is required"

    if value.startswith(("http://", "https://")):
        parsed = urlparse(value)
        if not parsed.scheme or not parsed.netloc:
            return "Enter a valid HTTP or HTTPS URL"
        return None

    if value.startswith("/"):
        if not value.lower().endswith(".iso"):
            return "Local file path must point to an .iso file"
        return None

    return "Enter an HTTP/HTTPS URL or an absolute local .iso path"


@vyos_operation_bp.route('/software/update-check', methods=['GET'])
@login_required
def get_software_update_check():
    try:
        config = SoftwareUpdateCheckConfig.query.order_by(
            SoftwareUpdateCheckConfig.id.desc()
        ).first()
        return jsonify(config.serialize() if config else {
            "autoCheck": False,
            "url": "",
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/update-check', methods=['PUT'])
@login_required
def update_software_update_check():
    try:
        data = UpdateSoftwareManagementDTO.model_validate_json(request.data)
        current_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.SYSTEM_UPDATE_CHECK,
        )
        if isinstance(current_config, Exception):
            return jsonify({'error': str(current_config)}), 400

        new_config = parse_to_vyos_config(data.model_dump())
        diff_config = compare_configs(new_config, current_config or {})
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SYSTEM_UPDATE_CHECK,
            data={
                "current": current_config or {},
                "new": new_config,
                "diff": diff_config,
            },
        )

        api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.OS_CONFIG,
            data={"refresh": True},
        )

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/update-check/install', methods=['POST'])
@login_required
@permission_required(permissions=['administrator'])
def install_available_software_update():
    try:
        update_status = get_system_update_status()
        if not update_status['update_available']:
            return jsonify({
                'success': True,
                'update_available': False,
                'current_version': update_status.get('local_version'),
                'available_version': update_status.get('remote_version'),
            }), 200

        image_url = str(update_status.get('url') or '').strip()
        validation_error = _validate_software_image_source(image_url)
        if validation_error:
            raise ValueError(f"Software update check returned an invalid URL: {validation_error}")

        return jsonify({
            'success': True,
            'update_available': True,
            'current_version': update_status.get('local_version'),
            'available_version': update_status.get('remote_version'),
            'image': {
                'url': image_url,
                'version': update_status.get('remote_version'),
            },
        }), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400


def _response_json(response):
    if response is None:
        return {}

    try:
        return response.json()
    except Exception:
        return {}


def _save_uploaded_software_image(uploaded_file):
    if uploaded_file is None or uploaded_file.filename is None or uploaded_file.filename.strip() == "":
        raise ValueError("ISO image file is required")

    filename = secure_filename(uploaded_file.filename)
    if filename == "":
        raise ValueError("ISO image file is required")
    if not filename.lower().endswith(".iso"):
        raise ValueError("Uploaded file must be an .iso image")

    timestamp = f"{datetime.utcnow().isoformat(timespec='seconds')}Z"
    directory_name = timestamp.replace(":", "-")
    upload_dir = os.path.join(SOFTWARE_IMAGE_STORAGE_ROOT, directory_name)
    os.makedirs(upload_dir, exist_ok=True)

    image_path = os.path.join(upload_dir, filename)
    try:
        uploaded_file.save(image_path)
    except Exception:
        shutil.rmtree(upload_dir, ignore_errors=True)
        raise
    return image_path, directory_name, filename


def _get_request_root_url():
    return request.host_url.rstrip('/')


def _uploaded_image_url(directory_name, filename):
    return f"{_get_request_root_url()}/webapi/vyos/opr/software/uploaded/{directory_name}/{filename}"


def _local_image_url(source):
    source_path = os.path.abspath(source)
    if not os.path.isfile(source_path):
        raise ValueError(f"Local image file does not exist: {source}")
    if not source_path.lower().endswith(".iso"):
        raise ValueError("Local file path must point to an .iso file")
    storage_root = os.path.abspath(SOFTWARE_IMAGE_STORAGE_ROOT)
    if source_path != storage_root and not source_path.startswith(f"{storage_root}/"):
        raise ValueError(f"Local image file must be under {SOFTWARE_IMAGE_STORAGE_ROOT}")

    parent_dir = os.path.dirname(source_path)
    directory_name = "__software_image_root__" if parent_dir == storage_root else os.path.basename(parent_dir)
    filename = os.path.basename(source_path)
    return f"{_get_request_root_url()}/webapi/vyos/opr/software/local-file/{directory_name}/{filename}"


def _uploaded_source_path(source):
    try:
        parsed = urlparse(source)
        path = parsed.path if parsed.scheme else source
        prefix = "/webapi/vyos/opr/software/uploaded/"
        if not path.startswith(prefix):
            return None

        relative_path = path[len(prefix):]
        parts = relative_path.split("/")
        if len(parts) != 2:
            return None

        directory_name = secure_filename(parts[0])
        filename = secure_filename(parts[1])
        if directory_name == "" or filename == "":
            return None

        image_path = os.path.abspath(os.path.join(SOFTWARE_IMAGE_STORAGE_ROOT, directory_name, filename))
        storage_root = os.path.abspath(SOFTWARE_IMAGE_STORAGE_ROOT)
        if not image_path.startswith(f"{storage_root}/"):
            return None

        return image_path
    except Exception:
        return None


def _delete_uploaded_software_image(source):
    image_path = _uploaded_source_path(source)
    if not image_path:
        return

    try:
        if os.path.isfile(image_path):
            os.remove(image_path)

        upload_dir = os.path.dirname(image_path)
        storage_root = os.path.abspath(SOFTWARE_IMAGE_STORAGE_ROOT)
        if upload_dir != storage_root and upload_dir.startswith(f"{storage_root}/") and os.path.isdir(upload_dir):
            shutil.rmtree(upload_dir, ignore_errors=True)
    except Exception as e:
        logger.warning(f"Failed to delete uploaded software image {image_path}: {e}")


def _format_software_error(error):
    if error is None:
        return None
    if isinstance(error, str):
        return error
    if isinstance(error, list):
        messages = [_format_software_error(item) for item in error]
        return "\n".join(message for message in messages if message)
    if isinstance(error, dict):
        if error.get('message'):
            return str(error.get('message'))
        return json.dumps(error)
    return str(error)


def _graphql_result(response_data, field_name):
    if not isinstance(response_data, dict):
        return []

    query_data = response_data.get('data', {}).get(field_name, {})
    if query_data.get('success') is False:
        raise ValueError(query_data.get('errors') or f"{field_name} failed")

    result = query_data.get('data', {}).get('result')
    return result if isinstance(result, (list, dict)) else []


def _is_truthy(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("yes", "true", "1")
    return bool(value)


def _load_system_image_summary_from_graphql():
    graphql = GraphqlRequest()
    image_response = graphql.send_request(
        function_name='ShowSystemImagePerleImageQuery',
        data=None,
        verify=False,
    )

    result = _graphql_result(image_response.json(), 'ShowSystemImagePerleImageQuery')

    if isinstance(result, dict):
        default_image = str(result.get('image_default') or '')
        running_image = str(result.get('image_running') or '')
        available_images = result.get('images_available') or []
        image_names = []
        for image in available_images:
            name = str(image.get('name') if isinstance(image, dict) else image or '').strip()
            if name and name not in image_names:
                image_names.append(name)

        for name in (running_image, default_image):
            if name and name not in image_names:
                image_names.append(name)

        images = [{
            "name": name,
            "is_default_boot": name == default_image,
            "is_running": name == running_image,
        } for name in image_names]

        return {
            "images": images,
            "image_default": default_image,
            "image_running": running_image,
            "console_type": str(result.get('console_type') or ''),
            "console_num": str(result.get('console_num') or ''),
        }

    images = []
    for row in result:
        if not isinstance(row, dict):
            continue

        images.append({
            "name": row.get('name', ''),
            "is_default_boot": _is_truthy(row.get('is_default_boot') or row.get('default_boot')),
            "is_running": _is_truthy(row.get('is_running') or row.get('running')),
        })

    default_image = next((image['name'] for image in images if image['is_default_boot']), '')
    running_image = next((image['name'] for image in images if image['is_running']), '')
    return {
        "images": images,
        "image_default": default_image,
        "image_running": running_image,
        "console_type": "",
        "console_num": "",
    }


def _load_system_images_from_graphql():
    return _load_system_image_summary_from_graphql()['images']


def _load_system_image_details_from_graphql():
    graphql = GraphqlRequest()
    detail_response = graphql.send_request(
        function_name='ShowSystemImageDetailsPerleImageQuery',
        data=None,
        verify=False,
    )

    detail_result = _graphql_result(detail_response.json(), 'ShowSystemImageDetailsPerleImageQuery')
    detail_rows = detail_result if isinstance(detail_result, list) else (
        detail_result.get('images_details')
        or detail_result.get('details')
        or detail_result.get('images')
        or []
    )
    details = []
    for row in detail_rows:
        if not isinstance(row, dict):
            continue

        storage_read_only = row.get('storage_read_only')
        if storage_read_only in (None, ''):
            storage_read_only = row.get('disk_ro', '')
        storage_read_write = row.get('storage_read_write')
        if storage_read_write in (None, ''):
            storage_read_write = row.get('disk_rw', '')
        storage_total = row.get('storage_total')
        if storage_total in (None, ''):
            storage_total = row.get('disk_total', '')

        details.append({
            "name": row.get('name', ''),
            "version": row.get('version', ''),
            "tools_version": row.get('tools_version', ''),
            "disk_ro": row.get('disk_ro', ''),
            "disk_rw": row.get('disk_rw', ''),
            "disk_total": row.get('disk_total', ''),
            "storage_read_only": storage_read_only,
            "storage_read_write": storage_read_write,
            "storage_total": storage_total,
        })

    return details


def _load_current_system_version():
    try:
        version_response = HTTPRequest().send_request(action=Action.SHOW, data=SHOW_SYSTEMS_VERSION, verify=False)
        version_data = _response_json(version_response).get('data', '')
        return parse_system_version(version_data)
    except Exception:
        return ""


@vyos_operation_bp.route('/software/status', methods=['GET'])
def get_software_status():
    try:
        image_summary = _load_system_image_summary_from_graphql()
        images = image_summary['images']
        running_image = next((image for image in images if image.get('is_running')), None)
        default_image = next((image for image in images if image.get('is_default_boot')), None)
        http = HTTPRequest()
        version_response = http.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_VERSION, verify=False)
        version_data = _response_json(version_response).get('data', '')
        current_version = parse_system_version(version_data)

        return jsonify({
            "current_version": current_version,
            "images": images,
            "image_default": image_summary['image_default'],
            "image_running": image_summary['image_running'],
            "console_type": image_summary['console_type'],
            "console_num": image_summary['console_num'],
        }), 200
    except Exception as e:
        try:
            http = HTTPRequest()
            version_response = http.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_VERSION, verify=False)
            images_response = http.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_BOOT_IMG, verify=False)

            version_data = _response_json(version_response).get('data', '')
            images_data = _response_json(images_response).get('data', '')
            boot_images = parse_boot_images(images_data)

            running_image = next((image for image in boot_images if image.get('running')), None)
            default_image = next((image for image in boot_images if image.get('default_boot')), None)

            current_version = parse_system_version(version_data)
            images = [{
                "name": image.get('name', ''),
                "is_default_boot": _is_truthy(image.get('default_boot')),
                "is_running": _is_truthy(image.get('running')),
            } for image in boot_images]

            return jsonify({
                "current_version": current_version,
                "images": images,
                "image_default": default_image.get('name') if default_image else "",
                "image_running": running_image.get('name') if running_image else "",
                "console_type": "",
                "console_num": "",
            }), 200
        except Exception:
            return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/details', methods=['GET'])
def get_software_image_details():
    try:
        return jsonify({
            "details": _load_system_image_details_from_graphql()
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/default-boot', methods=['POST'])
def set_software_default_boot():
    try:
        body = request.get_json(silent=True) or {}
        image_name = str(body.get('imageName', '')).strip()
        if image_name == "":
            return jsonify({"error": "Image name is required"}), 400

        images = _load_system_images_from_graphql()
        if images and not any(image.get('name') == image_name for image in images):
            return jsonify({"error": "Selected image is not installed"}), 400

        command = json.dumps({
            "op": "set_default",
            "name": image_name
        })
        response = HTTPRequest().send_request(action=Action.IMAGE, data=command, verify=False)
        response_data = _response_json(response)
        success = response_data.get('success')
        error = response_data.get('error')

        if getattr(response, 'status_code', 200) >= 400 or success is False or error:
            return jsonify({
                "success": False,
                "command": f"set system image default-boot {image_name}",
                "error": error or "Failed to set default boot image",
                "response": response_data
            }), getattr(response, 'status_code', 400) if getattr(response, 'status_code', 400) >= 400 else 400

        return jsonify({
            "success": True,
            "command": f"set system image default-boot {image_name}",
            "message": f"{image_name} will boot on the next startup",
            "response": response_data
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/delete', methods=['POST'])
def delete_software_image():
    try:
        body = request.get_json(silent=True) or {}
        image_name = str(body.get('imageName', '')).strip()
        if image_name == "":
            return jsonify({"error": "Image name is required"}), 400

        images = _load_system_images_from_graphql()
        if images and not any(image.get('name') == image_name for image in images):
            return jsonify({"error": "Selected image is not installed"}), 400

        command = f"delete system image {image_name}"
        image_response = api_manager.call(
            action=API_ACTION.DELETE,
            target=API_TARGET.SYSTEM_IMAGE,
            data={"name": image_name}
        )
        response = image_response.get('response')
        response_data = image_response.get('response_data') or {}

        status_code = getattr(response, 'status_code', 200)
        errors = image_response.get('errors') or response_data.get('errors')
        success = image_response.get('success')
        if status_code >= 400 or success is False or errors:
            return jsonify({
                "success": False,
                "command": command,
                "error": errors or response_data.get('error') or "Failed to delete system image",
                "response": response_data
            }), status_code if status_code >= 400 else 400

        return jsonify({
            "success": True,
            "command": command,
            "message": f"{image_name} deleted",
            "response": response_data
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/rename', methods=['POST'])
def rename_software_image():
    try:
        body = request.get_json(silent=True) or {}
        current_name = str(body.get('currentName', '')).strip()
        new_name = str(body.get('newName', '')).strip()
        if current_name == "" or new_name == "":
            return jsonify({"error": "Current and new image names are required"}), 400
        if current_name == new_name:
            return jsonify({"error": "New image name must be different"}), 400
        if "/" in new_name:
            return jsonify({"error": "Image name cannot contain /"}), 400

        images = _load_system_images_from_graphql()
        current_image = next((image for image in images if image.get('name') == current_name), None)
        running_image = next((image for image in images if image.get('is_running')), None)
        default_image = next((image for image in images if image.get('is_default_boot')), None)
        effective_running_image = running_image or default_image or (images[0] if images else None)
        if images and current_image is None:
            return jsonify({"error": "Selected image is not installed"}), 400
        if current_image and (current_image.get('is_running') or (effective_running_image and effective_running_image.get('name') == current_name)):
            return jsonify({"error": "Cannot rename the running image"}), 400
        if any(image.get('name') == new_name for image in images):
            return jsonify({"error": "An image with that name already exists"}), 400

        command = f"rename system image {current_name} to {new_name}"
        image_response = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SYSTEM_IMAGE_RENAME,
            data={"name": current_name, "new_name": new_name}
        )
        response = image_response.get('response')
        response_data = image_response.get('response_data') or {}

        status_code = getattr(response, 'status_code', 200)
        errors = image_response.get('errors') or response_data.get('errors')
        success = image_response.get('success')
        if status_code >= 400 or success is False or errors:
            return jsonify({
                "success": False,
                "command": command,
                "error": _format_software_error(errors or response_data.get('error')) or "Failed to rename system image",
                "response": response_data
            }), status_code if status_code >= 400 else 400

        return jsonify({
            "success": True,
            "command": command,
            "message": f"{current_name} renamed to {new_name}",
            "response": response_data
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/update', methods=['POST'])
@login_required
def update_software_image():
    try:
        body = request.get_json(silent=True) or {}
        source = str(body.get('path', body.get('source', ''))).strip()
        validation_error = _validate_software_image_source(source)
        if validation_error:
            return jsonify({"error": validation_error}), 400

        uploaded_image_path = _uploaded_source_path(source)
        image_source = uploaded_image_path or (_local_image_url(source) if source.startswith("/") else source)
        options = _software_image_options(body)
        job, created = create_job(
            current_app._get_current_object(), session['user_id'], image_source,
            temporary_path=uploaded_image_path,
            original_filename=os.path.basename(uploaded_image_path) if uploaded_image_path else None,
            options=options,
        )
        socket_manager.emit_to_all(
            event='notification',
            data={'type': 'remove', 'action': 'software-update-available'},
        )
        return jsonify({"success": True, "job": job.serialize(), "already_active": not created}), 202 if created else 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/upload', methods=['POST'])
@login_required
def upload_software_image():
    image_path = None
    try:
        image_path, directory_name, filename = _save_uploaded_software_image(request.files.get('image'))
        options = _software_image_options(request.form)
        job, created = create_job(
            current_app._get_current_object(), session['user_id'], image_path,
            temporary_path=image_path, original_filename=filename,
            options=options,
        )
        socket_manager.emit_to_all(
            event='notification',
            data={'type': 'remove', 'action': 'software-update-available'},
        )
        if not created:
            delete_temporary_image(image_path)
        return jsonify({"success": True, "job": job.serialize(), "already_active": not created}), 202 if created else 200
    except ValueError as e:
        delete_temporary_image(image_path)
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        delete_temporary_image(image_path)
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/software/jobs/current', methods=['GET'])
@login_required
def current_software_update_job():
    job = SoftwareUpdateJob.query.filter(
        SoftwareUpdateJob.user_id == str(session['user_id']),
        SoftwareUpdateJob.state.in_(("queued", "applying")),
    ).order_by(
        SoftwareUpdateJob.created_at.desc()
    ).first()
    return jsonify({"job": job.serialize() if job else None}), 200


@vyos_operation_bp.route('/software/jobs/<job_id>', methods=['GET'])
@login_required
def software_update_job_status(job_id):
    job = SoftwareUpdateJob.query.filter_by(id=job_id, user_id=str(session['user_id'])).first()
    if not job:
        return jsonify({"error": "Software update job not found"}), 404
    return jsonify({"job": job.serialize()}), 200


@vyos_operation_bp.route('/software/uploaded/<directory_name>/<filename>', methods=['GET'])
def download_uploaded_software_image(directory_name, filename):
    try:
        safe_directory_name = secure_filename(directory_name)
        safe_filename = secure_filename(filename)
        if safe_directory_name == "" or safe_filename == "":
            return jsonify({"error": "Invalid image path"}), 400
        if not safe_filename.lower().endswith(".iso"):
            return jsonify({"error": "Invalid image file"}), 400

        upload_dir = os.path.join(SOFTWARE_IMAGE_STORAGE_ROOT, safe_directory_name)
        return send_from_directory(upload_dir, safe_filename, as_attachment=False)
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@vyos_operation_bp.route('/software/local-file/<directory_name>/<filename>', methods=['GET'])
def download_local_software_image(directory_name, filename):
    try:
        safe_directory_name = secure_filename(directory_name)
        safe_filename = secure_filename(filename)
        if safe_directory_name == "" or safe_filename == "":
            return jsonify({"error": "Invalid image path"}), 400
        if not safe_filename.lower().endswith(".iso"):
            return jsonify({"error": "Invalid image file"}), 400

        upload_dir = SOFTWARE_IMAGE_STORAGE_ROOT if safe_directory_name == "__software_image_root__" else os.path.join(SOFTWARE_IMAGE_STORAGE_ROOT, safe_directory_name)
        return send_from_directory(upload_dir, safe_filename, as_attachment=False)
    except Exception as e:
        return jsonify({"error": str(e)}), 404

@vyos_operation_bp.route('/interface-conf/wifi', methods=['GET'])
def show_wifi_interfaces_config():
    try:
        wifi_iface= WiFiInterfaceConfig.query.first()
        system_conf = System.query.first()
        all_country_codes = SystemDefault.get_def_by_name('country_code')
        wifi_conf = {}
        if wifi_iface:
            wifi_conf = wifi_iface.serialize()
        wireless_country_code = None
        if system_conf:
            wireless_country_code = system_conf.wireless_country_code
        wifi_conf['wireless_country_code'] = wireless_country_code
        if all_country_codes:
            country_code_list = all_country_codes.country_code.split(',')
            wifi_conf['all_country_codes'] = country_code_list
        
        return jsonify(wifi_conf), 200
    except Exception as e:
        return jsonify({
            "error": str(e)
        }), 400

@vyos_operation_bp.route('/interface-conf/wireguard', methods=['GET'])
def show_wireguard_interfaces_config():
    try:
        wireguard_ifaces = WireguardInterfaceConfig.query.all()
        if wireguard_ifaces:
            return jsonify([iface.serialize() for iface in wireguard_ifaces]), 200
        return jsonify([]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


    
@vyos_operation_bp.route('/interface-conf/openvpn', methods=['GET'])
def show_openvpn_interfaces_config():
    try:
        openvpn_ifaces = OpenVPNInterfaceConfig.query.all()
        if openvpn_ifaces:
            return jsonify([iface.serialize() for iface in openvpn_ifaces]), 200
        return jsonify([]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-conf/ipsec', methods=['GET'])
def show_ipsec_interfaces_config():
    try:
        from app.core.models import InterfaceConfig
        ipsec_config = IPsecConfig.get_current_config()
        vti_interfaces = InterfaceConfig.query.filter_by(interface_type='vti').all()
        vti_data = {}
        for vti in vti_interfaces:
            addresses = [addr.ip_address for addr in vti.ip_addresses if addr.ip_address]
            vti_data[vti.interface] = {'address': addresses[0] if addresses else None} if addresses else {}
        ipsec_config = _parse_with_vti_addresses(ipsec_config, {'interfaces': {'vti': vti_data}})
        constants = {
            "ike_dh_group": read_ike_dh_group(),
            "ike_encryption": read_ike_encryption(),
            "ike_hash": read_ike_hash(),
            "ike_pseudo_random_function": read_ike_pseudo_random_function(),
            "esp_encryption": read_esp_encryption(),
            "esp_hash": read_esp_hash(),
            "esp_pfs": read_esp_pfs()
        }
        if ipsec_config:
            return jsonify({
                "ipsec_config": ipsec_config,
                "constants": constants
            }), 200
        return jsonify({}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-conf/iptunnels', methods=['GET'])
def show_iptunnels_interfaces_config():
    try:
        iptunnel_config = IPTunnelConfig.get_current_config()
        constants = {
            "tunnel_types": ["gre", "ipip", "sit", "vti"],
            "encapsulation_types": {
                "gre": "Generic Routing Encapsulation",
                "ipip": "IP in IP",
                "sit": "Simple Internet Transition", 
                "vti": "Virtual Tunnel Interface"
            }
        }
        if iptunnel_config:
            return jsonify({
                "iptunnel_config": iptunnel_config,
                "constants": constants
            }), 200
        return jsonify({"constants": constants}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-conf/wwan', methods=['GET'])
@login_required
def show_wwan_interfaces_config():
    try:
        wwan_ifaces = WWANInterfaceConfig.query.all()
        return jsonify([iface.serialize() for iface in wwan_ifaces]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400



@vyos_operation_bp.route('/pki', methods=['GET'])
def show_pki():
    try:
        ca_certificates = PKICaCertificate.query.all()
        certificates = PKICertificate.query.all()
        dh_params = PKIDH.query.all()
        keypairs = KeyPair.query.all()
        openssh_keys = PKIOpenSSHKey.query.all()
        openvpn_shared_secret_keys = OpenVPNSharedSecretKey.query.all()
        res = {
            'ca_certificates': [],
            'certificates': [],
            'dh_params': [],
            'keypairs': [],
            'openssh_keys': [],
            'openvpn_shared_secret_keys': [],
        }

        if ca_certificates:
            res['ca_certificates'] = [ca.serialize() for ca in ca_certificates]
        if certificates:
            res['certificates'] = [cert.serialize() for cert in certificates]
        if dh_params:
            res['dh_params'] = [dh.serialize() for dh in dh_params]
        if keypairs:
            res['keypairs'] = [kp.serialize() for kp in keypairs]
        if openssh_keys:
            res['openssh_keys'] = [key.serialize() for key in openssh_keys]
        if openvpn_shared_secret_keys:
            res['openvpn_shared_secret_keys'] = [ssk.serialize() for ssk in openvpn_shared_secret_keys]

        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
@vyos_operation_bp.route('/interface', methods=['GET'])
def show_interfaces():
    try:
        force_refresh = request.args.get('refresh', '').strip().lower() == 'true'
        if force_refresh:
            refreshed = refresh_db_interface_operation()
            if not refreshed or isinstance(refreshed, Exception):
                return jsonify({'error': 'Unable to refresh interface data from VyOS'}), 502

        records = Interface.query.filter(Interface.interface_type != "Loopback").all()
        if not records and not force_refresh:
            refresh_db_interface_operation()
            records = Interface.query.filter(Interface.interface_type != "Loopback").all()

        return jsonify([record.serialize() for record in records]), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/interface-by-type', methods=['POST'])
@login_required
def show_interfaces_by_type():
    try:
        data = request.get_json(silent=True) or {}
        interface_types = data.get('interface_types') if isinstance(data, dict) else None

        if (
            not isinstance(interface_types, list)
            or not interface_types
            or any(
                not isinstance(interface_type, str) or not interface_type.strip()
                for interface_type in interface_types
            )
        ):
            return jsonify({
                'error': 'interface_types must be a non-empty list of interface type names'
            }), 400

        normalized_types = list({
            interface_type.strip().lower()
            for interface_type in interface_types
        })
        interfaces = Interface.query.filter(
            db.func.lower(Interface.interface_type).in_(normalized_types)
        ).all()

        interfaces = [
            record for record in interfaces
            if not Interface.is_vlan_interface_name(record.interface)
            and not Interface.is_vrrp_interface_name(record.interface)
        ]

        return jsonify([record.serialize() for record in interfaces]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface-stat/cellular', methods=['GET'])
def show_interfaces_cellular():
    try:
        cellular_info = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.INTERFACE_CELLULAR)
        logger.debug(f"Cellular info: {cellular_info}")
        return jsonify(cellular_info), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/interface-monitor/wwan/<intf_name>/detail', methods=['GET'])
@login_required
def show_interface_monitor_wwan_detail(intf_name):
    try:
        detail = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.INTERFACE_CELLULAR,
            data={"intf_name": intf_name, "detail": True}
        )
        return jsonify(detail), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wwan/detail', methods=['GET'])
@login_required
def show_interface_monitor_all_wwan_details():
    try:
        os_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.OS_CONFIG,
            data={"refresh": True},
        )
        wwan_config = (
            os_config.get('interfaces', {}).get('wwan', {})
            if isinstance(os_config, dict)
            else {}
        )
        interface_names = sorted(wwan_config.keys()) if isinstance(wwan_config, dict) else []

        details = []
        for intf_name in interface_names:
            try:
                detail = api_manager.call(
                    action=API_ACTION.MONITOR,
                    target=API_TARGET.INTERFACE_CELLULAR,
                    data={"intf_name": intf_name, "detail": True},
                )
                if isinstance(detail, Exception):
                    raise detail
                row = detail if isinstance(detail, dict) else {}
                row.setdefault('interface', intf_name)
                details.append(row)
            except Exception as interface_error:
                details.append({
                    "interface": intf_name,
                    "error": str(interface_error),
                })

        return jsonify(details), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-stat/wifi', methods=['GET'])
def show_interfaces_wifi():
    try:
        wifi = WiFiInterfaceConfig.get_ssid()
        if wifi:
            # wifi is a tuple (ap_ssid, client_ssid) from the query
            return jsonify({'ap_ssid': wifi[0], 'client_ssid': wifi[1]}), 200
        else:
            return jsonify({'ap_ssid': '', 'client_ssid': ''}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_operation_bp.route('/interface/statistics', methods=['GET'])
def get_interface_statistics():
    try:
        interfaces = Interface.query.filter(Interface.interface_type != "Loopback").all()
    
        interface_stats = {
            'ethernet': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'vrrp': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'wifi': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'ap5': 0, 'ap24': 0, 'client5': 0, 'client24': 0 },
            'cellular': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'number': '', 'carrier': '', 'apn': '', 'imei': '', 'signal': '' },   
            'openvpn': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'wireguard': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'bridge': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
        }
        
        for iface in interfaces:
            iface_dict = iface.serialize()
            iface_type = 'virtual'  # Default type for misc interfaces
            
            if Interface.is_vrrp_interface_name(iface.interface) or iface.interface_type == 'VRRP':
                iface_type = 'vrrp'
            elif iface.interface_type == 'Ethernet':
                iface_type = 'ethernet'
            elif iface.interface_type in ['WLAN', 'Wireless']:
                iface_type = 'wifi'
            elif iface.interface_type == 'Bridge':
                iface_type = 'bridge'
            elif iface.interface_type in ['WWAN', 'PPPoE','Cellular'] or (isinstance(iface.interface, str) and 'wwan' in iface.interface):
                iface_type = 'cellular'
            elif iface.interface_type in ['OpenVPN']:
                iface_type = 'openvpn'
            elif iface.interface_type in ['Wireguard']:
                iface_type = 'wireguard'
        
            if iface_type not in interface_stats:
                interface_stats[iface_type] = {'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'tooltip': f'{iface_type} interfaces'}
            
            # Match the Link status shown by GenericInterfaceMonitorTab.
            flags = iface_dict.get('flags_list') or []
            is_up = iface.admin_state == 'UP' and ('NO-CARRIER' not in flags or 'LOWER_UP' in flags)
            if is_up:
                interface_stats[iface_type]['up'] += 1
            else:
                interface_stats[iface_type]['down'] += 1

            if iface.interface == 'wlan0':
                interface_stats['wifi']['ap5'] = 1 if is_up else 0
            elif iface.interface == 'wlan1':
                interface_stats['wifi']['ap24'] = 1 if is_up else 0
            elif iface.interface == 'wlan2':
                interface_stats['wifi']['client5'] = 1 if is_up else 0
            elif iface.interface == 'wlan3':
                interface_stats['wifi']['client24'] = 1 if is_up else 0
            
            interface_stats[iface_type]['rx'] += iface.rx_bytes or 0
            interface_stats[iface_type]['tx'] += iface.tx_bytes or 0

        interface_stats = {k: v for k, v in interface_stats.items() if v['up'] > 0 or v['down'] > 0}

        return jsonify(interface_stats), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/cpu', methods=['POST'])
def performance_cpu_http():
    if not is_linux():
        # Not running on Linux
        perf = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_CPU)
        return jsonify(perf), 200
    else:
        timestamp_date, timestamp_hour = system_timestamp()
        # Optimize by using linux cmd
        # output = run_command('uptime')
        # load_average = output.split("load average:")[1].strip().split(", ")
        load_average = get_load_averages()
        data = {
            "uptime": "1d 12h 30m 6s",
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": system_utc_timestamp(),
            # "load_averages": {"1": float(load_average[0]), "5": float(load_average[1]), "15": float(load_average[2])}
            "load_averages": {
                "1": round(min(float(load_average[1])*100, 100), 1), 
                "5": round(min(float(load_average[5])*100, 100), 1), 
                "15": round(min(float(load_average[15])*100, 100), 1)
            }
        }
        return jsonify(data), 200


def performance_cpu():
    try:    
        timestamp_date, timestamp_hour = system_timestamp()
        cpu = salt_fetch_cpu('hostNameVyOS-1')
        data = {
            "uptime": "",
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": system_utc_timestamp(),
            "load_averages": {
                "1": float(cpu.get('1-min')) *100, 
                "5": float(cpu.get('5-min')) *100, 
                "15": float(cpu.get('15-min'))*100
            }
        }
        return jsonify(data), 200
    except Exception as e:
        
        return jsonify(str(e)), 400
    

@vyos_operation_bp.route('/ram', methods=['POST'])
def performance_memory():

    memory_db = Memory.query.all()

    if len(memory_db) == 0:
        # CALL API
        memory = refresh_db_memory_operation()
        # memory = salt_refresh_db_memory_operation('hostNameVyOS-1')
        return jsonify(memory), 200
    
    r = {
        "memory": {
            "free": memory_db[0].free,
            "used": memory_db[0].used,
        },
        "timestamp": [memory_db[0].date, memory_db[0].time],
        "utc_timestamp": memory_db[0].utc_timestamp
    }
    return jsonify(r), 200


@vyos_operation_bp.route('/system-info', methods=['GET'])
def show_system_info():
    try:
        system_db = System.query.first()
        system = system_db.serialize() if system_db else None
        if not system:
            system = refresh_db_system_info(app_context=current_app.app_context())

        tz = None
        if isinstance(system, dict):
            tz = system.get('timezone')
        if not tz:
            tz = 'UTC'

        try:
            now = datetime.now(pytz.timezone(tz))
        except Exception:
            tz = 'UTC'
            now = datetime.now(pytz.utc)

        if isinstance(system, dict):
            system['datetime'] = f"{now.strftime('%a %Y-%m-%d %H:%M:%S')} {tz}"
            from app.core.login.db_models import SystemLoginOptions
            system['password_policy'] = SystemLoginOptions.get_password_policy()

        return jsonify(system), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/reboot', methods=['GET'])
def get_reboot_status():
    try:
        return jsonify(get_reboot_status_service()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/reboot', methods=['POST'])
def reboot_system():
    try:
        data = request.get_json() or {}
        result = run_reboot_command(data)
        return jsonify(result), 200 if result.get('success') is not False else 400
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/system-memory', methods=['GET'])
def show_system_memory():
    try:
        memory = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.SYSTEM_MEMORY,
            data=None
        )

        return jsonify(memory), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/system-info', methods=['PUT'])
@login_required
def update_system_info():
    try:
        data = UpdateSystemInfoDTO.model_validate_json(request.data)
        print("System update data input: ")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.SYSTEM, 
            data=data.model_dump(exclude_none=True)
        )
        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        if isinstance(res, list) and any(item.get('success') is False for item in res):
            return jsonify(res), 400
        refresh_db_system_info()
        return jsonify(res), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface', methods=['POST'])
@login_required
def create_interface():
    try:
        data = CreateInterfaceDTO.model_validate_json(request.data)
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE, 
            data={"intf_type": data.intf_type, "name": data.name, "desc": data.desc, "address": f"{data.address}/{data.subnet}"}
        )
        refresh_db_interface_operation()
        return jsonify(res), 200
    
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface-sync', methods=['PUT'])
@login_required
def update_interface_sync():
    try:
        data = UpdateInterfaceDTO.model_validate_json(request.data)
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE, 
            data={"intf_type": data.intf_type, "name": data.name, "desc": data.desc, "address": data.address}
        )
        
        refresh_db_interface_operation()

        return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400
    

@vyos_operation_bp.route('/interface', methods=['PUT'])
@login_required
def update_interface():
    try:
        user_id = session['user_id']
        data = UpdateInterfaceDTO.model_validate_json(request.data)
        # Update db
        Interface.update_interface_by_name(name=data.name, ipv4=data.address, desc=data.desc)
        # Create a thread to update Interface in Vyos
        task_thread = threading.Thread(target=update_intf_async, args=[data, current_app.app_context(), user_id])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200

    except ValidationError as ve:
        return ve.json(), 400

@vyos_operation_bp.route('/interface-monitor/openvpn', methods=['POST'])
@login_required
def show_interface_monitor_openvpn():
    try:
        data = OpenVPNMonitorDTO.model_validate_json(request.data)
        openvpn_type = data.openvpn_type
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.INTERFACE_OPENVPN, data=openvpn_type)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/openvpn/<intf_name>/reset', methods=['POST'])
@login_required
def reset_openvpn_interface_monitor(intf_name):
    try:
        if not intf_name:
            return jsonify({"error": "Missing required path param: intf_name"}), 400
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.OPENVPN_INTERFACE_RESET,
            data={"intf_name": intf_name}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/openvpn/client/<client_name>/reset', methods=['POST'])
@login_required
def reset_openvpn_client_monitor(client_name):
    try:
        if not client_name:
            return jsonify({"error": "Missing required path param: client_name"}), 400
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.OPENVPN_CLIENT_RESET,
            data={"client_name": client_name}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/interface-monitor/wireguard/info', methods=['GET'])
@login_required
def show_interface_monitor_wireguard_info():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.INTERFACE_WIREGUARD)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/l2tpv3/info', methods=['GET'])
@login_required
def show_interface_monitor_l2tpv3_info():
    try:
        res = api_manager.manager.provider.graphql_service.send_request(
            function_name='ShowInterfaces',
            data={'intf_type': '"l2tpv3"'},
            verify=False
        )
        return jsonify(res.json()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wireguard/<intf_name>/reset', methods=['POST'])
@login_required
def reset_wireguard_interface_monitor(intf_name):
    try:
        if not intf_name:
            return jsonify({"error": "Missing required path param: intf_name"}), 400
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.WIREGUARD_INTERFACE_RESET,
            data={"intf_name": intf_name}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wireguard/<intf_name>/peer/<peer_name>/reset', methods=['POST'])
@login_required
def reset_wireguard_peer_monitor(intf_name, peer_name):
    try:
        if not intf_name:
            return jsonify({"error": "Missing required path param: intf_name"}), 400
        if not peer_name:
            return jsonify({"error": "Missing required path param: peer_name"}), 400
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.WIREGUARD_PEER_RESET,
            data={"intf_name": intf_name, "peer_name": peer_name}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/info')
@login_required
def show_interface_monitor_wifi_info():
    try:
        print("Show interface monitor wifi info")
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_INFO)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/<intf_name>/station')
@login_required
def show_inteface_monitor_wifi_station(intf_name):
    try:
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": intf_name})
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/interface-monitor/wifi/ap/station')
@login_required
def show_interface_monitor_wifi_ap_stations():
    try:
        result = []
        wlan0_station = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": 'wlan0'})
        wlan1_station = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": 'wlan1'})
        
        if wlan0_station.get('ShowStationsWirelessQuery', None) and wlan0_station['ShowStationsWirelessQuery'].get('data', None) and \
            wlan0_station['ShowStationsWirelessQuery']['data'].get('result', None):
            for st in wlan0_station['ShowStationsWirelessQuery']['data']['result']:
                st.update({"band": "5GHz"})
                result.append(st)
        
        if wlan1_station.get('ShowStationsWirelessQuery', None) and wlan1_station['ShowStationsWirelessQuery'].get('data', None) and \
            wlan1_station['ShowStationsWirelessQuery']['data'].get('result', None):
            for st in wlan1_station['ShowStationsWirelessQuery']['data']['result']:
                st.update({"band": "2.4GHz"})
                result.append(st)
        
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/<intf_name>/scan')
@login_required
def show_interface_monitor_wifi_scan(intf_name):
    try:
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_SCAN, data={"intf_name": intf_name})
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/generic/<intf_name>/clear-counters', methods=['POST'])
@login_required
def clear_generic_interface_counters(intf_name):
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.COUNTER_INTERFACE,
            data={"intf_name": intf_name}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/generic/<intf_name>/renew-dhcp-client-lease', methods=['POST'])
@login_required
def renew_dhcp_client_lease_for_interface(intf_name):
    try:
        payload = request.get_json(silent=True) or {}
        family = payload.get('family')
        if family not in ['inet', 'inet6']:
            return jsonify({"error": "Missing or invalid required field: family"}), 400

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DHCP_CLIENT_LEASE_RENEW,
            data={"intf_name": intf_name, "family": family}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/generic/<intf_name>/release-dhcp-client-lease', methods=['POST'])
@login_required
def release_dhcp_client_lease_for_interface(intf_name):
    try:
        payload = request.get_json(silent=True) or {}
        family = payload.get('family')
        if family not in ['inet', 'inet6']:
            return jsonify({"error": "Missing or invalid required field: family"}), 400

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DHCP_CLIENT_LEASE_RELEASE,
            data={"intf_name": intf_name, "family": family}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/generic/dhcp-client-leases', methods=['GET'])
@login_required
def show_dhcp_client_leases_for_interface_monitor():
    try:
        family = request.args.get('family')
        if family not in ['inet', 'inet6']:
            return jsonify({"error": "Missing or invalid required query param: family"}), 400

        intf_name = request.args.get('interface', '')
        data = {"family": family}
        if intf_name and str(intf_name).strip() != '':
            data['interface'] = str(intf_name).strip()

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DHCP_CLIENT_LEASES_SHOW,
            data=data
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/<intf_type>/<name>', methods=['PUT'])
@login_required
def update_interface_by_name(intf_type, name):
    try:
        if intf_type == "ethernet":
            data = UpdateEthernetInterfaceByNameDTO.model_validate_json(request.data)
        elif intf_type == "wireless":
            # print("Update wifi interface by name")
            # print(pprint.pformat(request.data, indent=2, width=80))
            data = UpdateWifiInterfaceByNameDTO.model_validate_json(request.data)
        # print("Update interface by name: ")
        # print(f"Name: {name}")
        # print(f"Intf type: {intf_type}")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_config = parse_to_interface_config(intf_type, data.model_dump())
        # print("New config: ")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        # print("Parsed new config: ")
        # print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
        # print("Current config: ")
        # print(pprint.pformat(current_config.json()['data'][intf_type][name], indent=2, width=80))

        if intf_type != 'wireless':
            diff = compare_configs(new_config, current_config.json()['data'][intf_type][name])
        else:
            match_wlan_config =  {
                "interfaces": {
                    "wireless":{
                        "wlan0": new_config['wlan0'],
                        "wlan1": new_config['wlan1'],
                        "wlan2": new_config['wlan2'],
                        "wlan3": new_config['wlan3']
                    }
                }
            }
            diff = compare_configs(match_wlan_config, {"interfaces": {"wireless": current_config.json()['data'][intf_type]}})
        # Update using the diff

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config.json()['data'], 
                "new": new_config, 
                "diff": diff, 
                "intf_type": intf_type, 
                "name": name
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/openvpn', methods=['POST'])
@login_required
def create_openvpn_interface():
    try:
        data = CreateOpenvpnInterfaceDTO.model_validate_json(request.data)
        interface_name = data.general.name
        new_config = parse_to_openvpn_config(data.model_dump())
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE_OPENVPN, 
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        # Refresh DB with new interface
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/openvpn/verify', methods=['POST'])
@login_required
def verify_openvpn_interface():
    try:
        data = CreateOpenvpnInterfaceDTO.model_validate_json(request.data)
        interface_name = data.general.name
        new_config = parse_to_openvpn_config(data.model_dump())
        res = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.INTERFACE_OPENVPN,
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        if res is None or res == "None" or res == "" or res == {}:
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": str(res)}), 400

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/openvpn', methods=['PUT'])
@login_required
def update_all_openvpn_interfaces():
    try:
        data = UpdateAllOpenvpnInterfacesDTO.model_validate_json(request.data)

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_OPENVPN)
        if not isinstance(current_config, dict):
            current_config = {}
        new_config = parse_to_openvpn_bulk_config(data.interfaces)
        diff_config = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_OPENVPN,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config,
            },
        )

        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        print("Exception:", e)
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/ipsec', methods=['POST'])
@login_required
def create_ipsec_interface():
    try:
        data = CreateIPsecInterfaceDTO.model_validate_json(request.data)        
        new_config = parse_to_ipsec_config(data.model_dump())

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_ipsec_interface_config(os_config)
        logger.debug("Current ipsec config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE_IPSEC, 
            data={
                "new": new_config,
                "current": current_config,
                "diff": diff,
            }
        )
        # Refresh DB with new interface
        refresh_db_interface_operation()

        # Refresh DB with new ipsec config
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    

@vyos_operation_bp.route('/interface/iptunnels', methods=['POST'])
@login_required
def create_iptunnel_interface():
    try:
        data = CreateIPTunnelInterfaceDTO.model_validate_json(request.data)
        
        # Convert DTO to VyOS config format
        new_config = {
            data.tunnel_type: {
                data.tunnel_name: {
                    'description': data.description,
                    'disable': data.disable,
                    'source-address': data.source_address,
                    'remote': data.remote_address,
                }
            }
        }
        
        # Add optional parameters
        if data.ttl is not None:
            new_config[data.tunnel_type][data.tunnel_name]['ttl'] = data.ttl
        if data.tos:
            new_config[data.tunnel_type][data.tunnel_name]['tos'] = data.tos
        if data.mtu is not None:
            new_config[data.tunnel_type][data.tunnel_name]['mtu'] = data.mtu
        if data.multicast:
            new_config[data.tunnel_type][data.tunnel_name]['multicast'] = {}
        
        # Add tunnel type specific parameters
        if data.tunnel_type == 'gre':
            if data.gre_key:
                new_config[data.tunnel_type][data.tunnel_name]['key'] = data.gre_key
            if data.gre_checksum:
                new_config[data.tunnel_type][data.tunnel_name]['checksum'] = {}
        elif data.tunnel_type == 'sit':
            if data.sit_6rd_prefix:
                new_config[data.tunnel_type][data.tunnel_name]['6rd-prefix'] = data.sit_6rd_prefix
            if data.sit_6rd_relay_prefix:
                new_config[data.tunnel_type][data.tunnel_name]['6rd-relay-prefix'] = data.sit_6rd_relay_prefix
        
        # Add IP addresses
        addresses = []
        addresses.extend(data.ipv4_addresses)
        addresses.extend(data.ipv6_addresses)
        if addresses:
            new_config[data.tunnel_type][data.tunnel_name]['address'] = addresses
        
        # Add IPv6 options
        has_ipv6_options = data.ipv6_eui64_prefix or data.ipv6_accept_dad is not None
        if has_ipv6_options:
            new_config[data.tunnel_type][data.tunnel_name]['ipv6'] = {}
            
            # EUI-64 prefix (under ipv6 > address)
            if data.ipv6_eui64_prefix:
                new_config[data.tunnel_type][data.tunnel_name]['ipv6']['address'] = {}
                new_config[data.tunnel_type][data.tunnel_name]['ipv6']['address']['eui64'] = data.ipv6_eui64_prefix
            
            # Accept DAD (directly under ipv6)
            if data.ipv6_accept_dad is not None:
                new_config[data.tunnel_type][data.tunnel_name]['ipv6']['accept-dad'] = str(data.ipv6_accept_dad)

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = {}  # No current IP tunnel configs initially
        logger.debug("Current tunnel config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE_TUNNEL, 
            data={
                "new": new_config,
                "current": current_config,
                "diff": diff,
            }
        )
        
        # Refresh DB with new interface
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/iptunnels/<name>', methods=['PUT'])
@login_required
def update_iptunnel_interface_by_name(name):
    """Update an IP tunnel interface by name"""
    try:
        # Debug: Log raw request data
        print("\n" + "="*80)
        print("RAW REQUEST DATA:")
        print(request.data.decode('utf-8'))
        print("="*80 + "\n")
        
        data = UpdateIPTunnelInterfaceDTO.model_validate_json(request.data)
        
        # Debug: Log the DTO data received
        print("\n" + "="*80)
        print("RECEIVED DTO DATA:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        print("="*80 + "\n")
        
        # Import parser function
        from app.core.operation.iptunnels.parser import parse_to_iptunnel_config, parse_current_iptunnel_interface_config
        
        # Convert DTO to VyOS config format
        new_config = parse_to_iptunnel_config(data.model_dump())
        
        logger.debug("New iptunnel config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        # Get current OS configuration
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_iptunnel_interface_config(os_config)
        
        logger.debug("Current iptunnel config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        # Compare configurations to get diff
        current_tunnel = current_config.get('interfaces', {}).get('tunnel', {}).get(name, {})
        new_tunnel = new_config.get('interfaces', {}).get('tunnel', {}).get(name, {})
        diff = compare_configs(new_tunnel, current_tunnel)
        
        logger.debug("Config diff: ")
        logger.debug(pprint.pformat(diff, indent=2, width=80))
        
        # Call the update service
        from app.core.operation.iptunnels.service import update_iptunnel_by_name
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "iptunnels",
                "diff": diff,
                "name": name
            }
        )
        
        # Refresh DB with updated interface
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as ve:
        print("\n" + "="*80)
        print("VALIDATION ERROR:")
        print(ve.json())
        print("="*80 + "\n")
        return ve.json(), 400
    except Exception as e:
        logger.error(f"Error updating IP tunnel interface: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/ethernet/<name>', methods=['PUT'])
@login_required
def update_ethernet_interface_by_name(name):
    try:
        
        data = UpdateEthernetInterfaceByNameDTO.model_validate_json(request.data)
        
        new_config = parse_to_interface_config('ethernet', data.model_dump(exclude_none=False))
        logger.debug("New ethernet config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        
        all_bridges = parse_all_bridge_interfaces_config(os_config)
        current_config = parse_current_ethernet_interface_config(os_config, name)
        logger.debug("Current ethernet config: ")
        logger.debug(pprint.pformat(current_config.get(name, {}), indent=2, width=80))
        
        diff = compare_configs(new_config, current_config.get(name, {}))
        # Update using the diff

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config, 
                "new": new_config, 
                "diff": diff, 
                "intf_type": 'ethernet', 
                "name": name,
                "all_bridges": all_bridges
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface-conf/ethernet', methods=['GET'])
@login_required
def get_ethernet_interface():
    try:
        from app.core.operation.ethernet.models import EthernetInterfaceConfig
        ethernet_config = EthernetInterfaceConfig.query.all()
        return jsonify([eth.serialize() for eth in ethernet_config]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireless/<name>', methods=['PUT'])
@login_required
def update_wireless_interface(name):
    try:
        data = UpdateWifiInterfaceByNameDTO.model_validate_json(request.data)
        # print("Update interface by name: ")
        # print(f"Name: {name}")
        # print(f"Intf type: {intf_type}")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dict_config = data.model_dump()
        new_dhcp_wifi_config = parse_to_single_dhcp_pool(dict_config['dhcp'])
        new_system_wireless = parse_to_system_config(dict_config['system'])

        bridge_addr = {
            "address": dict_config.get('wifi', {}).get('network', {}).get('ipv4', {}).get('static', {}).get('address', ""),
            "prefix_length": dict_config.get('wifi', {}).get('network', {}).get('ipv4', {}).get('static', {}).get('prefixLength', "")
        }
        _new_bridge_conf = {}
        if bridge_addr['address'] != "" and bridge_addr['prefix_length'] != "": 
            _new_bridge_conf.update({
                "name": "br1",
                "ipv4Address": f"{bridge_addr['address']}/{bridge_addr['prefix_length']}"
            })
        
        new_bridge_config = parse_to_bridge_config(_new_bridge_conf)
        # print("New wireless config: ")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        # print("Parsed new config: ")
        # print(pprint.pformat(new_config, indent=2, width=80))
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)

        current_config = os_config.get('interfaces')
        current_dhcp = parse_dhcp(os_config.get('service', {}).get('dhcp-server', None))
        current_system_wireless = parse_system(os_config.get('system', {}).get('wireless', None))
        new_dhcp = deepcopy(current_dhcp)
        print("Current wireless config: ")
        print(pprint.pformat(current_config.get('wireless', {}), indent=2, width=80))
        
        if new_dhcp and new_dhcp.get('shared_network_name', None):
            new_dhcp['shared_network_name']['default-dhcp-pool'] = new_dhcp_wifi_config

        current_wireless = normalize_config(
            current_config.get('wireless', {}), hyphenated=True, stringify_numbers=True,
        )
        new_config = parse_to_interface_config('wireless', dict_config['wifi'], current_wireless)
        diff = compare_configs(
            {"interfaces": {"wireless": new_config}},
            {"interfaces": {"wireless": current_wireless}},
        )
        
        # print("Current DHCP config: ")
        # print(pprint.pformat(current_dhcp, indent=2, width=80))

        # print("New dhcp wifi config: ")
        # print(pprint.pformat(new_dhcp))

        diff_dhcp = compare_configs(new_dhcp, current_dhcp)

        # print("Diff dhcp: ")
        # print(pprint.pformat(diff_dhcp))

        diff_system_wireless = compare_configs(new_system_wireless, current_system_wireless)

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config, 
                "new": new_config, 
                "diff": diff, 
                "intf_type": 'wireless', 
                "current_dhcp": current_dhcp,
                "new_dhcp": new_dhcp,
                "diff_dhcp": diff_dhcp,
                "current_bridge": current_config.get('bridge', {}),
                "new_bridge": new_bridge_config,
                "current_system_wireless": current_system_wireless,
                "new_system_wireless": new_system_wireless,
                "diff_system_wireless": diff_system_wireless
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400

@vyos_operation_bp.route('/interface/openvpn/<name>', methods=['PUT'])
@login_required
def update_openvpn_interface(name):
    try:
        data = UpdateOpenVPNInterfaceByNameDTO.model_validate_json(request.data)
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_openvpn_interface_config(os_config, name)
        
        new_config = parse_to_openvpn_config(data.model_dump(), current_config)
        logger.debug("New openvpn config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))
        logger.debug("Current openvpn config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "openvpn",
                "diff": diff,
                "name": name
            }
        )
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireguard/<name>', methods=['PUT'])
@login_required
def update_wireguard_interface(name):
    try:
        data = UpdateWireguardInterfaceByNameDTO.model_validate_json(request.data)
        new_config = parse_to_wireguard_config(data.model_dump())
        logger.debug("New wireguard config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_wireguard_interface_config(os_config, name)
        logger.debug("Current wireguard config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "wireguard",
                "diff": diff,
                "name": name
            }
        )
        # Refresh DB with new interface
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wwan/<name>', methods=['PUT'])
@login_required
def update_wwan_interface(name):
    try:
        data = UpdateWWANInterfaceDTO.model_validate_json(request.data)
        new_config = parse_to_wwan_config(data.model_dump(exclude_none=False))
        logger.debug("New WWAN config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_wwan_interface_config(os_config, name)
        logger.debug("Current WWAN config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "wwan",
                "diff": diff,
                "name": name
            }
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/bridge', methods=['POST'])
@login_required
@permission_required('administrator')
def create_bridge_interface():
    try:
        data = CreateBridgeInterfaceDTO.model_validate_json(request.data)
        interface_name = data.name
        new_config = parse_to_bridge_config(data.model_dump(exclude_none=False))
        
        logger.debug("Create bridge config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.CREATE,
            target=API_TARGET.INTERFACE_BRIDGE,
            data={
                "name": interface_name,
                "data": new_config[interface_name] if interface_name in new_config else new_config
            }
        )
        
        # Refresh DB with new interface
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        logger.error(f"Error creating bridge interface: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/bridge/<name>', methods=['PUT'])
@login_required
@permission_required('administrator')
def update_bridge_interface(name):
    try:
        data = UpdateBridgeInterfaceDTO.model_validate_json(request.data)
        
        new_config = parse_to_bridge_config(data.model_dump(exclude_none=False))
        
        logger.debug("New bridge config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_bridge_interface_config(os_config, name)
        logger.debug("Current bridge config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_config, current_config)
        logger.debug("Bridge config diff: ")
        logger.debug(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "bridge",
                "diff": diff,
                "name": name
            }
        )
        
        # Refresh interface data
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        logger.error(f"Error updating bridge interface {name}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/vlan', methods=['PUT'])
@login_required
@permission_required('administrator')
def update_vlan_interface():
    try:
        data = UpdateVlanInterfaceDTO.model_validate_json(request.data)
        new_config = parse_to_vlan_config(data.model_dump())
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_vlan_interface_config(os_config)

        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "vlan",
                "diff": diff,
            }
        )
        # refresh vlan interface config
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/vlan', methods=["GET"])
@login_required
def get_vlan_interface():
    try:
        vlan_config = VLANInterfaceConfig.query.all()
        return jsonify([vlan.serialize() for vlan in vlan_config]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface-conf/bridge', methods=['GET'])
@login_required
def get_bridge_interface():
    try:
        bridge_config = BridgeInterfaceConfig.query.all()
        return jsonify([bridge.serialize() for bridge in bridge_config]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/bridge/available-interfaces', methods=['GET'])
@login_required
def get_bridgeable_interfaces():
    try:
        interfaces = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.BRIDGEABLE_INTERFACES,
            data={}
        )
        return jsonify({'interfaces': interfaces}), 200
    except Exception as e:
        logger.error(f"Error fetching bridgeable interfaces: {e}")
        return jsonify({'error': str(e)}), 500


@vyos_operation_bp.route('/interface/wireguard', methods=['POST'])
@login_required
def create_wireguard_interface():
    try:
        req_data = CreateWireguardInterfaceDTO.model_validate_json(request.data)
        interface_name = req_data.name
        new_config = parse_to_wireguard_config(req_data.model_dump())
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE_WIREGUARD, 
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        
        # Refresh DB with new interface
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireguard/verify', methods=['POST'])
@login_required
def verify_wireguard_interface():
    try:
        data = CreateWireguardInterfaceDTO.model_validate_json(request.data)
        interface_name = data.name
        new_config = parse_to_wireguard_config(data.model_dump())
        res = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.INTERFACE_WIREGUARD,
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        if res is None or res == "None" or res == "" or res == {}:
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": str(res)}), 400

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireguard', methods=['PUT'])
@login_required
def update_all_wireguard_interfaces():
    try:
        data = UpdateAllWireguardInterfacesDTO.model_validate_json(request.data)

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIREGUARD)
        if not isinstance(current_config, dict):
            current_config = {}
        new_config = parse_to_wireguard_bulk_config(data.interfaces)
        diff_config = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_WIREGUARD,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config,
            },
        )

        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        print("Exception:", e)
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface', methods=['DELETE'])
@login_required
def delete_interface():
    try:
        req_data = DeleteInterfaceListDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.DELETE, target=API_TARGET.INTERFACE, data=req_data)

        # Refresh the saved configuration before rebuilding the interface tables so
        # deleted bridge interfaces are not served from the previous OS config snapshot.
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
        refresh_db_interface_operation()
        return jsonify(res), 200
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/address', methods=['DELETE'])
@login_required
def delete_interface_address():
    try:
        data = DeleteInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.delete_ipv4(name=data.name, ipv4=data.address)

        task_thread = threading.Thread(target=delete_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400



@vyos_operation_bp.route('/interface/address', methods=['PUT'])
@login_required
def update_interface_address():
    try:
        data = UpdateInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.update_ipv4(name=data.name, current_ip=data.current_address, new_ip=data.new_address)

        task_thread = threading.Thread(target=update_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400



@vyos_operation_bp.route('/interface/address', methods=['POST'])
@login_required
def add_interface_address():
    try:
        data = CreateInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.create_ipv4(name=data.name, ipv4=data.address)

        task_thread = threading.Thread(target=create_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/system/datetime', methods=['GET'])
@login_required
def get_system_datetime():
    try:
        logger.debug("Getting system datetime...")
        dt_result = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_DATETIME, data=None)
        
        if isinstance(dt_result, Exception):
            logger.error(f"Error getting datetime: {str(dt_result)}")
            return jsonify({"error": str(dt_result)}), 400
            
        if isinstance(dt_result, dict) and "error" in dt_result:
            logger.error(f"Error in datetime response: {dt_result['error']}")
            return jsonify(dt_result), 400

        logger.debug(f"Successfully got datetime: {dt_result}")

        return jsonify({"datetime": dt_result.get('datetime'), "timezone": dt_result.get('timezone')}), 200
        
    except Exception as e:
        logger.error(f"Exception getting datetime: {str(e)}")
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/wifi', methods=['PUT'])
def update_interface_wifi():
    try:
        print("Update interface wifi")
        return jsonify({'msg': 'success'}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/services/selected', methods=['PUT'])
def update_selected_services_route():
    try:
        data = UpdateSelectedServicesDTO.model_validate_json(request.data)
        selected_services = data.selectedServices
        if selected_services is None:
            selected_services = []
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Not authenticated'}), 401
        permission = session.get('permission')
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.SEL_SERVICES, 
            data={"user_id": user_id, "permission": permission, "selected_services": selected_services}
        )
        if isinstance(res, Exception):
            logger.debug(f"Error updating selected services inside: {str(res)}")
            return jsonify({'error': str(res)}), 400
        else:
            return res
    except Exception as e:
        logger.debug(f"Error updating selected services: {str(e)}")
        return jsonify({'error': str(e)}), 400

@vyos_operation_bp.route('/services/selected', methods=['GET'])
@login_required
def get_selected_services_route():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Not authenticated'}), 401
    permission = session.get('permission')
    selected_services = get_selected_services(permission, user_id)
    return jsonify({'selectedServices': selected_services}), 200

@vyos_operation_bp.route('/services/summary', methods=['GET'])
def get_services_summary():
    default_summary = {
        "firewall": {"accepted": 0, "dropped": 0, "total": 0},
        "ntp": {"stratum": "0", "offset": "0 ms", "leap_status": "Normal"},
        "dhcp": {"active": 0, "available": 0, "lease_time": "0h"},
        "dns": {"servers": 0, "server_list": []},
        "nat": {"source_packets": 0, "source_traffic": 0.0, "destination_packets": 0, "destination_traffic": 0.0},
        "vrrp": {"groups": 0, "sync_groups": 0},
        "wireguard": {"interfaces": 0, "peers": 0},
        "ipsec": {"connections": 0, "sa": 0},
        "openvpn": {"interfaces": 0, "active_interfaces": 0},
        "snmp": {"interfaces": 0, "packets": 0, "traps": 0},
        "loadbalancing": {"up_interfaces": [], "down_interfaces": []}
    }
    json_list_features = {"server_list", "up_interfaces", "down_interfaces"}

    try:
        service_stats = (
            db.session.query(ServiceStatistic)
            .join(Services, ServiceStatistic.service_id == Services.id)
            .join(AdminSelectedService, AdminSelectedService.service_id == Services.id)
            .all()
        )

        summary = deepcopy(default_summary)

        for stat in service_stats:
            service_name = stat.service.name.lower().replace(" ", "")
            feature = stat.service_feature
            value = stat.service_stat

            if service_name in summary:
                if feature in summary[service_name]:
                    if feature in json_list_features:
                        try:
                            parsed_value = json.loads(value)
                            summary[service_name][feature] = parsed_value
                        except Exception as e:
                            summary[service_name][feature] = []
                    else:
                        summary[service_name][feature] = value

        logger.debug(f"Fetched service statistics: {summary}")
        return jsonify(summary), 200

    except Exception as e:
        logger.error(f"Failed to get services summary: {str(e)}")
        return jsonify(default_summary), 200

@vyos_operation_bp.route('/user-management', methods=['GET'])
@login_required
def get_users():
    try:
        users = []
        # os users
        os_users = UserManagement.query.all()
        users += [UserManagement.serialize(user) for user in os_users]
        
        # temp user
        db_users = User.query.all()
        users += [User.serialize(user) for user in db_users]

        return jsonify({"users": users}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/user-management/verify', methods=['POST'])
@login_required
def verify_user():
    try:
        data = UserVerifyDTO.model_validate_json(request.data)
        data_dict = data.model_dump()
        user_config = parse_to_single_user_config(data_dict)
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.USER, data={data_dict['user_name']: user_config})
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/user-management', methods=['PUT'])
@login_required
def update_users():
    try:
        from app.core.utils.process_config import merge_dicts_set

        data = UpdateUserDTO.model_validate_json(request.data)
        logger.debug("Request config:")
        logger.debug(data.model_dump())
        
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.USER)
        logger.debug("Current config:")
        logger.debug(current_config)

        new_config = parse_to_user_config(data.model_dump())
        logger.debug("New parsed config:")
        logger.debug(new_config)

        # Fetch temp user from db
        db_users = User.query.all()
        db_config = parse_user_db_to_user_config(db_users)
        logger.debug("Parsed DB users:")
        logger.debug(db_config['login'])

        # Merge current VyOS config and Db config
        current_config = merge_dicts_set(current_config, db_config['login'])
        logger.debug("Merged configs: ")
        logger.debug(current_config)

        diff = compare_configs(new_config, {"login": current_config})
        logger.debug("Diff config:")
        logger.debug(diff)

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.USER, 
            data={"current": current_config, "current_db": db_config['login'], "new": new_config, "diff": diff}
        )

        logger.debug("API response:")
        logger.debug(res)
    
        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})


        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        else: 
            return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception updating users: {str(e)}")
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/wireguard/key-pair', methods=['POST'])
@login_required
def generate_wireguard_key_pair():
    try:
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.WIREGUARD_KEY_PAIR)
        return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception generating wireguard key pair: {str(e)}")
        return jsonify({"error": str(e)}), 400
    
@vyos_operation_bp.route('/wireguard/preshared-key', methods=['POST'])
@login_required
def generate_wireguard_pre_shared_key():
    try:
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.WIREGUARD_PRE_SHARED_KEY)
        return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception generating wireguard pre shared key: {str(e)}")
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/openvpn/shared-secret', methods=['POST'])
@login_required
def generate_openvpn_shared_secret():
    try:
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.OPENVPN_SHARED_SECRET)
        return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception generating openvpn shared secret: {str(e)}")
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/wireguard/public-key', methods=['POST'])
@login_required
def derive_wireguard_public_key():
    """Derive public key from private key using wg pubkey command"""
    try:
        from app.core.utils.cmd_linux import run_linux_cmd
        data = request.get_json()
        private_key = data.get('private_key', '')
        
        if not private_key:
            return jsonify({"error": "Private key is required"}), 400
        
        # Use echo and pipe to wg pubkey command
        cmd = f'echo "{private_key}" | wg pubkey'
        output, error = run_linux_cmd(cmd)
        
        if error:
            logger.error(f"Error deriving public key: {error}")
            return jsonify({"error": error}), 400
        
        return jsonify({"public_key": output}), 200
    except Exception as e:
        logger.error(f"Exception deriving wireguard public key: {str(e)}")
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route("/syslog", methods=['POST'])
@login_required
def query_system_log():
    try:
        from app.core.operation.models import SysLogDTO

        data = SysLogDTO.model_validate_json(request.data)
        payload = data.model_dump()
        count = payload.get('count')
        minutes = payload.get('minutes')
        keyword = payload.get('keyword')
        unit = payload.get('unit')
        syslog_identifier = payload.get('syslog_identifier')
        priority = payload.get('priority')

        logger.debug(f"Syslog request payload: {payload}")

        if minutes is not None:
            res = api_manager.call(
                action=API_ACTION.READ,
                target=API_TARGET.SYS_LOG,
                data={
                    "minutes": minutes,
                    "keyword": keyword if keyword is not None else "",
                    "unit": unit,
                    "syslog_identifier": syslog_identifier,
                    "priority": priority if priority is not None else 7
                }
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
        else:
            return jsonify({'error': 'minutes is required'}), 400
        return jsonify(res), 200
    
    except Exception as e:
        logger.error("Exception getting system log")
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route("/interface/address-dhcp", methods=['GET'])
@login_required
def get_interface_address_dhcp():
    try:
        res = [row.interface_name for row in InterfaceAddressDHCP.query.all()]
        return jsonify(res), 200
    
    except Exception as e:
        logger.error("Exception getting interface address dhcp")
        logger.error(str(e))
        return jsonify([]), 400

@vyos_operation_bp.route("/interface-config/all", methods=['GET'])
@login_required
def get_interface_configs():
    try:
        res = []
        for intf in InterfaceConfig.query.all():
            res.append(intf.serialize())
        return jsonify(res), 200

    except Exception as e:
        logger.error("Exception getting interface configs")
        logger.error(str(e))
        return jsonify([]), 400


@vyos_operation_bp.route('/interface-conf/l2tpv3', methods=['GET'])
@login_required
def show_l2tpv3_interfaces_config():
    try:
        from app.core.operation.l2tpv3.models import L2TPv3InterfaceConfig
        l2tpv3_ifaces = L2TPv3InterfaceConfig.query.all()
        if l2tpv3_ifaces:
            return jsonify([iface.serialize() for iface in l2tpv3_ifaces]), 200
        return jsonify([]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/l2tpv3', methods=['POST'])
@login_required
def create_l2tpv3_interface():
    try:
        from app.core.operation.l2tpv3.models import CreateL2TPv3InterfaceDTO
        from app.core.operation.l2tpv3.parser import parse_to_l2tpv3_config
        data = CreateL2TPv3InterfaceDTO.model_validate_json(request.data)
        interface_name = data.general.name
        new_config = parse_to_l2tpv3_config(data.model_dump())
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE_L2TPV3, 
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        refresh_db_interface_operation()
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/l2tpv3/verify', methods=['POST'])
@login_required
def verify_l2tpv3_interface():
    try:
        from app.core.operation.l2tpv3.models import CreateL2TPv3InterfaceDTO
        from app.core.operation.l2tpv3.parser import parse_to_l2tpv3_config
        data = CreateL2TPv3InterfaceDTO.model_validate_json(request.data)
        interface_name = data.general.name
        new_config = parse_to_l2tpv3_config(data.model_dump())
        res = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.INTERFACE_L2TPV3,
            data={
                "name": interface_name,
                "config": new_config
            }
        )
        if res is None or res == "None" or res == "" or res == {}:
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": str(res)}), 400

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/l2tpv3', methods=['PUT'])
@login_required
def update_all_l2tpv3_interfaces():
    try:
        from app.core.operation.l2tpv3.models import UpdateAllL2TPv3InterfacesDTO
        from app.core.operation.l2tpv3.parser import parse_to_l2tpv3_bulk_config, normalize_current_l2tpv3_config
        data = UpdateAllL2TPv3InterfacesDTO.model_validate_json(request.data)

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_L2TPV3)
        if not isinstance(current_config, dict):
            current_config = {}
        current_config = normalize_current_l2tpv3_config(current_config)
        new_config = parse_to_l2tpv3_bulk_config(data.interfaces)
        diff_config = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_L2TPV3,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config,
            },
        )

        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400
    except Exception as e:
        logger.error("Exception updating l2tpv3 interfaces")
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/l2tpv3/<name>', methods=['PUT'])
@login_required
def update_l2tpv3_interface(name):
    try:
        from app.core.operation.l2tpv3.models import UpdateL2TPv3InterfaceByNameDTO
        from app.core.operation.l2tpv3.parser import parse_to_l2tpv3_config, parse_current_l2tpv3_interface_config
        data = UpdateL2TPv3InterfaceByNameDTO.model_validate_json(request.data)
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_l2tpv3_interface_config(os_config, name)
        
        new_config = parse_to_l2tpv3_config(data.model_dump(), current_config)
        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "l2tpv3",
                "diff": diff,
                "name": name
            }
        )
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400
