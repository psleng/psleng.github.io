import json
from .models import Page, SubPage, Feature, Interval, SubPageFeature, EventHandlerFilePath
from app.core.models import System
from app.db.database import db
from flask import Blueprint
from sqlalchemy import text
from app.core.utils.folder_reader import read_folder_structure, save_to_json
from app.core.utils.check_os import is_linux
from app.core.utils.debug.debug_log import debug_log
import os 
from app.log.logger import logger
import sys
import atexit
import signal
import subprocess

config_bp = Blueprint('config', __name__)

from . import routes

class Config:

    def __init__(self):
        self.config = None
        self.app_context = None
        self.app_scheduler = None
    
    def init_app(self, app):
        self.config = app.config
        self.app_context = app.app_context()

    def init_scheduler(self, scheduler):
        self.app_scheduler = scheduler

    def get_config(self):
        return self.config
    
    def get_app_context(self):
        return self.app_context
    
global_config = Config()

def load_json_config(config_path='config.json'):
    
    try:
        with open(config_path, 'r') as config_file:
            return json.load(config_file)
    except FileNotFoundError:
        print(f"Configuration file not found at {config_path}")
        return {}
    except json.JSONDecodeError:
        print(f"Invalid JSON in configuration file at {config_path}")
        return {}

def init_db(app):
    with app.app_context():
        from app.event.jobs.system.save_config import ConfigSaveState
        from app.auth.web_sessions import ensure_web_session_schema

        config_save_state = ConfigSaveState.snapshot()
        db.metadata.drop_all(
            bind=db.engine,
            tables=[table for table in db.metadata.sorted_tables if table.name != "web_sessions"],
        )
        db.create_all()
        ensure_web_session_schema()
        ConfigSaveState.restore(config_save_state)

        db.session.commit()


def feature_exist(template_dict: dict, path: str):    
    if not isinstance(path, str):
        return False
    keys = path.split('/')
    current_level = template_dict
    for key in keys:
        if isinstance(current_level, dict) and key in current_level:
            current_level = current_level[key]
        else:
            return False
    return True


def read_os_feature(save=True):

    target_path = "/opt/vyatta/share/vyatta-cfg/templates/"
    output_path = "app/core/utils/"
    output_json = os.path.join(output_path, "templates.json")
    
    if is_linux():
        # - Read the folder structure
        # - then generate templates.json        
        folder_structure = read_folder_structure(target_path)
        if save:
            save_to_json(folder_structure, output_json)
    else:
        # - Read the pre-generated templates.json file
        try:
            with open(output_json, 'r') as f:
                folder_structure = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.debug(f"Could not load templates.json: {e}")
            folder_structure = {}

    return folder_structure


def sync_event_handler_file_paths(config: dict):
    scripts = config.get('scripts', {}) if isinstance(config, dict) else {}
    if not isinstance(scripts, dict):
        return

    existing_rows = {
        str(row.name): row
        for row in EventHandlerFilePath.query.all()
        if row.name is not None
    }

    for name, value in scripts.items():
        script_name = str(name or '').strip()
        if script_name == '':
            continue

        script_value = '' if value is None else str(value)
        if is_linux() and script_value.strip() != '':
            try:
                subprocess.run(['chmod', '+x', script_value], check=True)
            except Exception as e:
                logger.warning(f"Failed to make event handler script executable for {script_name}: {e}")

        row = existing_rows.get(script_name)
        if row is None:
            db.session.add(EventHandlerFilePath(name=script_name, value=script_value))
            continue

        row.value = script_value


def init_pages(app):
        
    with app.app_context():
        # Reload and apply changes app config file
        db.session.execute(text("DELETE FROM features"))
        db.session.execute(text("DELETE FROM sub_page_features"))
        db.session.execute(text("DELETE FROM sub_pages"))
        db.session.execute(text("DELETE FROM pages"))
        db.session.execute(text("DELETE FROM intervals"))
        db.session.commit()

        config_tree = read_os_feature()
        
        config = load_json_config()

        db.session.execute(text("DELETE FROM event_handler_filepath"))
        sync_event_handler_file_paths(config)
        db.session.commit()

        # Populate pages
        for page_config in config.get('pages', []):
            page_template_path = page_config.get('template_path', None)
            page_enable = None
            if page_template_path:
                page_enable = feature_exist(config_tree, page_template_path)
            page = Page(
                page_id=page_config.get('id', ''),
                page_name=page_config.get('name', ''),
                page_url=page_config.get('url', ''),
                enabled=page_enable if page_enable is not None else page_config.get('enable', True)
            )
            db.session.add(page)
            
            # Sub-pages
            for sub_page_config in page_config.get('sub_pages', []):
                
                # Sub-page features
                features_status = []
                sub_page_features = sub_page_config.get('features', [])
                for fe in sub_page_features:
                    feature_template_path = fe.get('template_path', None)
                    feature_enable = None
                    if feature_template_path:
                        feature_enable = feature_exist(config_tree, feature_template_path)
                        features_status.append(feature_enable)
    
                    sp_feature = SubPageFeature(
                        feature_id=fe.get('name', ''),
                        feature_name=fe.get('name', ''),
                        enabled=feature_enable if feature_enable is not None else fe.get('enable', True),
                        sub_page_id=sub_page_config.get('id', '')
                    )

                    db.session.add(sp_feature)
                                   
                sub_page_template_path = sub_page_config.get('template_path', None)
                sub_page_enable = None
                if sub_page_template_path:
                    sub_page_enable = feature_exist(config_tree, sub_page_template_path)
                
                if len(features_status) > 0:
                    if not any(features_status):
                        # 1. if all of features in sub_page are False, then disable sub_page
                        is_sub_page_enabled = False
                    else:
                        # 1.1 when one of features is True, then enable sub_page
                        is_sub_page_enabled = True
                else:
                    if sub_page_enable is not None:
                        # 2. set sub_page status using template config
                        is_sub_page_enabled = sub_page_enable
                    else:
                        # 3. else: status is set in config.json file
                        # default status is set to false, then sub_page is read from template config
                        is_sub_page_enabled = sub_page_config.get('enable', False)

                sub_page = SubPage(
                    sub_page_id=sub_page_config.get('id', ''),
                    sub_page_name=sub_page_config.get('name', ''),
                    sub_page_url=sub_page_config.get('url', ''),
                    enabled=is_sub_page_enabled,
                    parent_page=page
                )

                db.session.add(sub_page)
        
        # Populate features
        for feature_config in config.get('features', []):
            feature = Feature(
                feature_id=feature_config.get('id', ''),
                feature_name=feature_config.get('name', ''),
                enabled=feature_config.get('enable', False)
            )
            db.session.add(feature)

        # Populate intervals
        for interval_config in config.get('intervals', []):
            interval = Interval(
                name=interval_config.get('name', ''),
                value=interval_config.get('seconds', 0)
            )
            db.session.add(interval)
        
        db.session.commit()

        # If Firewall IPv6 block is enabled, then disable all of IPv6 features in all of pages
        is_ipv6_enabled = True
        system_config = System.query.first()
        if system_config:
            if not system_config.ipv6_status:
                is_ipv6_enabled = False
        
        if not is_ipv6_enabled:
            sub_page_features = SubPageFeature.query.all()
            for sub_page_feature in sub_page_features:
                if "v6" in sub_page_feature.feature_id:
                    sub_page_feature.enabled = False
            db.session.commit()
        

def register_cleanup_before_shutdown(app):
    def on_shutdown():
        from app.core.api.http.srv.user_management import delete_all_tmp_users
        logger.debug("[*] Cleaning up resources before shutdown...")
        logger.debug("Delete temporary linux users within app context")
        with app.app_context():
            delete_all_tmp_users()

    # Register interpreter exit
    atexit.register(on_shutdown)

    def handle_signal(signum, frame):
        print(f"[**] Received signal {signum}, shutting down...")
        sys.exit(0)  # Triggers atexit functions

    # Register signal handlers
    signal.signal(signal.SIGINT, handle_signal)   # Ctrl+C
    signal.signal(signal.SIGTERM, handle_signal)  # kill or os shutdown
