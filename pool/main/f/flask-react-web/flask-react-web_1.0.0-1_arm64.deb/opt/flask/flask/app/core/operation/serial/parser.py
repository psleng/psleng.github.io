import hashlib
import json
import re
from copy import deepcopy
from typing import get_args, get_origin

from pydantic import BaseModel
from app.core.operation.serial.models import (
    SerialGlobalConfigDTO, SerialDeviceConfigDTO, SerialTtyProfileDTO, UpdateSerialConfigDTO,
)
from app.core.operation.serial.form_parser import write_global, write_device, write_profile
from app.core.operation.serial.constants import SERIAL_TAG_PATHS
from app.core.utils.cmd_linux import run_linux_cmd
from app.core.utils.process_config import merge_dicts_set, normalize_config
from app.log.logger import logger


SCOPE_DTOS = {'global': SerialGlobalConfigDTO, 'device': SerialDeviceConfigDTO, 'profile': SerialTtyProfileDTO}

LIST_SERIAL_DEVICES_CMD = 'sh -c "/usr/libexec/vyos/completion/list_serial.py --selector all"'
SERIAL_DEVICE_NAME = re.compile(r'^ttyS\d+$')


def device_order(name):
    digits = re.search(r'\d+', name)
    return (int(digits.group()) if digits else -1, name)


def list_serial_devices():
    output, error = run_linux_cmd(LIST_SERIAL_DEVICES_CMD)
    if error:
        logger.error(f'Could not list serial devices: {error}')
        return []
    return [s for s in (output or '').split() if SERIAL_DEVICE_NAME.match(s)]


def dto_config(value):
    if isinstance(value, BaseModel):
        return dto_config(value.model_dump(by_alias=True, exclude_none=True))
    if isinstance(value, dict):
        return {key: dto_config(item) for key, item in value.items() if item is not False and item is not None}
    if isinstance(value, list):
        return list(dict.fromkeys(value))
    if value is True:
        return {}
    return deepcopy(value)


def parse_to_serial_scope(values, scope):
    return dto_config(SCOPE_DTOS[scope].model_validate(values))


def parse_serial_scope(raw, scope):
    return {'global': write_global, 'device': write_device, 'profile': write_profile}[scope](raw)


def _nested_dto(annotation):
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return annotation, False
    if get_origin(annotation) is dict:
        child, _ = _nested_dto(get_args(annotation)[1])
        return child, True
    for argument in get_args(annotation):
        child, tagged = _nested_dto(argument)
        if child is not None:
            return child, tagged
    return None, False


def preserve_unknown(current, new, dto_type):
    
    fields = {field.alias or name: field for name, field in dto_type.model_fields.items()}
    result = {key: deepcopy(value) for key, value in current.items() if key not in fields}
    for name, value in new.items():
        old = current.get(name)
        field = fields.get(name)
        child, tagged = _nested_dto(field.annotation) if field else (None, False)
        if child and isinstance(old, dict) and isinstance(value, dict):
            if tagged:
                result[name] = {entry: preserve_unknown(old.get(entry, {}), content, child) for entry, content in value.items()}
            else:
                result[name] = preserve_unknown(old, value, child)
        else:
            result[name] = deepcopy(value)
    return result


def parse_to_serial_config(data: UpdateSerialConfigDTO, current):
    data = UpdateSerialConfigDTO.model_validate(data)
    scopes = {'global': data.global_values, 'devices': data.devices, 'profiles': data.profiles}
    result = {key: deepcopy(value) for key, value in current.items() if key not in ('device', 'profile', 'global-parameters')}
    for field, key, scope in (('global', 'global-parameters', 'global'),):
        parsed = dto_config(scopes[field])
        merged = preserve_unknown(current.get(key, {}), parsed, SCOPE_DTOS[scope])
        if merged:
            result[key] = merged
    for field, key, scope in (('devices', 'device', 'device'), ('profiles', 'profile', 'profile')):
        old = current.get(key, {})
        if scope == 'profile':
            old = old.get('tty-profile', {})
        entries = {}
        for name, values in scopes[field].items():
            parsed = dto_config(values)
            # An empty draft for an unconfigured port must not create an invalid device.
            if parsed or name in old:
                entries[name] = preserve_unknown(old.get(name, {}), parsed, SCOPE_DTOS[scope])
            elif scope == 'profile':
                entries[name] = {}
        if entries:
            result[key] = {**{k: deepcopy(v) for k, v in current.get('profile', {}).items() if k != 'tty-profile'}, 'tty-profile': entries} if scope == 'profile' else entries
        elif scope == 'profile':
            other_profiles = {k: deepcopy(v) for k, v in current.get('profile', {}).items() if k != 'tty-profile'}
            if other_profiles:
                result[key] = other_profiles
    return result


def revision(config, slip_interfaces=None, ppp_interfaces=None):
    if slip_interfaces or ppp_interfaces:
        config = {'serial': config, **({'slipInterfaces': slip_interfaces} if slip_interfaces else {}),
                  **({'pppInterfaces': ppp_interfaces} if ppp_interfaces else {})}
    return hashlib.sha256(json.dumps(config, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def parse_serial_config_to_form(config, *, slip_interfaces=None, ppp_interfaces=None):
    configured_devices = config.get('device', {})
    available = sorted(set(configured_devices) | set(list_serial_devices()), key=device_order) or ['ttyS1']
    return {
        'global': parse_serial_scope(config.get('global-parameters', {}), 'global'),
        'devices': {name: parse_serial_scope(value, 'device') for name, value in configured_devices.items()},
        'profiles': {name: parse_serial_scope(value, 'profile') for name, value in config.get('profile', {}).get('tty-profile', {}).items()},
        'availableDevices': available,
        'revision': revision(config, slip_interfaces, ppp_interfaces),
        **({'slipInterfaces': slip_interfaces_to_form(slip_interfaces)} if slip_interfaces is not None else {}),
        **({'pppInterfaces': ppp_interfaces_to_form(ppp_interfaces)} if ppp_interfaces is not None else {}),
    }


def ppp_interfaces_to_form(interfaces):
    from app.core.operation.serial.ppp import ppp_interface_to_form
    return {interface['device']: ppp_interface_to_form(interface)
            for interface in interfaces.values() if interface.get('device')}


def slip_interfaces_to_form(interfaces):
    from app.core.operation.serial.slip import SLIP_FIELDS
    return {
        interface['device']: {
            key: (True if key == 'disable-vj-comp' else str(value))
            for key, value in interface.items() if key in SLIP_FIELDS
        }
        for interface in interfaces.values() if interface.get('device')
    }


def parse_serial_verify_config(config, *, ppp_interfaces=None, slip_interfaces=None):
    result = normalize_config(config, tag_paths=SERIAL_TAG_PATHS)
    result['_invoke_context'] = 'serial'
    profiles = result.get('profile', {}).get('tty_profile', {})
    for name, device in list(result.get('device', {}).items()):
        profile = device.get('profile')
        if profile and profile not in profiles:
            raise ValueError(f'device {name}: profile "{profile}" does not exist')
        result['device'][name] = merge_dicts_set(
            profiles.get(profile, {}),
            {key: value for key, value in device.items() if key != 'profile'},
            replace_lists=True, preserve_keys=True,
        )
    for name, interface in (ppp_interfaces or {}).items():
        device = interface.get('device')
        if 'ppp' not in result.get('device', {}).get(device, {}):
            continue
        candidate = normalize_config(interface)
        candidate.update({
            'ifname': name,
            'interface_type': 'ppp',
            'authentication_protocol_selected': [
                protocol for protocol in ('chap', 'pap', 'none')
                if protocol in interface.get('authentication', {}).get('protocol', {})
            ],
        })
        result.setdefault('interface_config', {})[device] = candidate
    for name, interface in (slip_interfaces or {}).items():
        device = interface.get('device')
        if 'slip' not in result.get('device', {}).get(device, {}):
            continue
        candidate = normalize_config(interface)
        candidate.update({'ifname': name, 'interface_type': 'slip'})
        result.setdefault('interface_config', {})[device] = candidate
    return result

