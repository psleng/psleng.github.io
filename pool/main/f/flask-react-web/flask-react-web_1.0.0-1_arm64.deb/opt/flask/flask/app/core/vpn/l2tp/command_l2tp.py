def is_str_not_empty(value):
    return isinstance(value, str) and value.strip() != ''

def has_config_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ''
    return True

class L2TPCommand:
    """
    L2TPCommand class is used to generate commands for L2TP configuration:

    - set/delete vpn l2tp remote-access authentication mode {local | radius | noauth}
    - set/delete vpn l2tp remote-access authentication protocols { pap | chap | mschap | mschapv2}
    - set/delete vpn l2tp remote-access authentication local-users <username> disable
    - set/delete vpn l2tp remote-access authentication local-users <username> password <passwd>
    - set/delete vpn l2tp remote-access authentication local-users <username> static-ip <IPv4>
    - set/delete vpn l2tp remote-access authentication radius server <IPv4>
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> disable
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> key <key-in-text>
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> port <1-65535>
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> priority <1-255>
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> acct-port
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> backup
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> disable-accounting
    - set/delete vpn l2tp remote-access authentication radius server <IPv4> fail-time <0-600>
    - set/delete vpn l2tp remote-access authentication radius source-address <IPv4>
    - set/delete vpn l2tp remote-access authentication radius nas-identifier  <text>
    - set/delete vpn l2tp remote-access authentication radius nas-ip-address <IPv4>
    - set/delete vpn l2tp remote-access authentication radius timeout <1-60>
    - set/delete vpn l2tp remote-access authentication radius max-try <1-20>
    - set/delete vpn l2tp remote-access default-ipv6-pool <pool-name>
    - set/delete vpn l2tp remote-access default-pool <pool-name>
    - set/delete vpn l2tp remote-access description <text>
    - set/delete vpn l2tp remote-access gateway-address <IPv4>
    - set/delete vpn l2tp remote-access outside-address <IPv4>
    - set/delete vpn l2tp remote-access mtu <128-16384>
    - set/delete vpn l2tp remote-access name-server  <IPv4 | IPv6>
    - set/delete vpn l2tp remote-access log level <0-5>
    - set/delete vpn l2tp remote-access wins-server <IPv4>
    - set/delete vpn l2tp remote-access ipsec-settings esp-group <grp-name>
    - set/delete vpn l2tp remote-access ipsec-settings ike-group <grp-name>
    - set/delete vpn l2tp remote-access ipsec-settings lifetime <30-86400>
    - set/delete vpn l2tp remote-access ipsec-settings authentication mode {pre-shared-secret | x509}
    - set/delete vpn l2tp remote-access ipsec-settings authentication pre-shared-secret <key-name>
    - set/delete vpn l2tp remote-access ipsec-settings authentication x509 ca-certificate <ca-cert-name>
    - set/delete vpn l2tp remote-access ipsec-settings authentication x509 certificate <cert-name>
    - set/delete vpn l2tp remote-access ipsec-settings authentication x509 passphrase <text>
    - set/delete vpn l2tp remote-access lns host-name <hostname>
    - set/delete vpn l2tp remote-access lns shared-secret <secret>
    - set/delete vpn l2tp remote-access ppp-options disable-ccp
    - set/delete vpn l2tp remote-access ppp-options interface-cache <1-256000>
    - set/delete vpn l2tp remote-access ppp-options ipv4 {deny | allow | prefer | require}
    - set/delete vpn l2tp remote-access ppp-options ipv6-accept-peer-interface-id 
    - set/delete vpn l2tp remote-access ppp-options ipv6-interface-id {x:x:x:x | random}
    - set/delete vpn l2tp remote-access ppp-options ipv6-peer-interface-id {x:x:x:x | random | ipv4-addr | calling-sid}
    - set/delete vpn l2tp remote-access ppp-options lcp-echo-failure
    - set/delete vpn l2tp remote-access ppp-options lcp-echo-interval
    - set/delete vpn l2tp remote-access ppp-options lcp-echo-timeout
    - set/delete vpn l2tp remote-access ppp-options min-mtu <68-65535>
    - set/delete vpn l2tp remote-access ppp-options mppe {require | prefer | deny}
    - set/delete vpn l2tp remote-access ppp-options mru <68-65535>
    - set/delete vpn l2tp remote-access client-ip-pool <pool-name> range <x.x.x.x/n>
    - set/delete vpn l2tp remote-access client-ipv6-pool <pool-name> prefix <h:h:h:h:h:h:h:h/x>

    """
    def __init__(self, operator='set', config=None, resource='l2tp'):
        self.operator = operator
        self.resource = resource
        self.config = config or {}
        self.cmds = []
        self.vyos_cmds = []

    def generate_commands(self, data, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            l2tp_config = data.get('remote-access', data) if 'remote-access' in data else data
            
            if not l2tp_config:
                return []
            
            if 'authentication' in l2tp_config:
                self._process_authentication(l2tp_config['authentication'], current_config, new_config)
            
            self._process_general_settings(l2tp_config)
            
            if 'ipsec-settings' in l2tp_config:
                self._process_ipsec_settings(l2tp_config['ipsec-settings'])
            
            if 'lns' in l2tp_config:
                self._process_lns(l2tp_config['lns'])
            
            if 'ppp-options' in l2tp_config:
                self._process_ppp_options(l2tp_config['ppp-options'])
            
            if 'client-ip-pool' in l2tp_config:
                self._process_client_ip_pools(l2tp_config['client-ip-pool'], current_config, new_config)
            
            if 'client-ipv6-pool' in l2tp_config:
                self._process_client_ipv6_pools(l2tp_config['client-ipv6-pool'], current_config, new_config)

            return self.cmds
        except Exception as e:
            print(f"Error generating L2TP commands: {e}")
            import traceback
            traceback.print_exc()
            return []

    def _process_authentication(self, auth_config, current_config=None, new_config=None):
        base_path = ['vpn', 'l2tp', 'remote-access', 'authentication']
        
        if 'protocols' in auth_config:
            protocols = auth_config['protocols']
            if isinstance(protocols, list):
                for protocol in protocols:
                    if is_str_not_empty(protocol):
                        self.generate(*base_path, 'protocols', protocol)
            elif is_str_not_empty(protocols):
                self.generate(*base_path, 'protocols', protocols)
        
        if 'local-users' in auth_config:
            local_users = auth_config['local-users']
            if isinstance(local_users, dict):
                user_entries = local_users.get('username') if 'username' in local_users else local_users
                if isinstance(user_entries, dict):
                    for username, user_config in user_entries.items():
                        if not is_str_not_empty(username) or not isinstance(user_config, dict):
                            continue
                        user_path = base_path + ['local-users', 'username', username]
                        
                        if self.operator == 'delete':
                            if username not in new_config.get('remote-access', {}).get('authentication', {}).get('local-users', {}).get('username', {}):
                                self.generate(*user_path)
                                continue

                        if 'disable' in user_config:
                            self.generate(*user_path, 'disable')

                        if 'password' in user_config and is_str_not_empty(user_config['password']):
                            self.generate(*user_path, 'password', user_config['password'])

                        if 'static-ip' in user_config and is_str_not_empty(user_config['static-ip']):
                            self.generate(*user_path, 'static-ip', user_config['static-ip'])
        
        if 'radius' in auth_config:
            self._process_radius(auth_config['radius'], current_config, new_config)
        
        if 'mode' in auth_config and is_str_not_empty(auth_config['mode']) and self.operator != 'delete':
            self.generate(*base_path, 'mode', auth_config['mode'])

    def _process_radius(self, radius_config, current_config=None, new_config=None):
        base_path = ['vpn', 'l2tp', 'remote-access', 'authentication', 'radius']
        
        if 'server' in radius_config:
            for server_ip, server_config in radius_config['server'].items():
                server_path = base_path + ['server', server_ip]
                
                if self.operator == 'delete':
                    new_servers = new_config.get('remote-access', {}).get('authentication', {}).get('radius', {}).get('server', {})
                    if server_ip not in new_servers:
                        self.generate(*server_path)
                        continue
                
                if 'disable' in server_config:
                    self.generate(*server_path, 'disable')
                
                if 'key' in server_config and is_str_not_empty(server_config['key']):
                    self.generate(*server_path, 'key', server_config['key'])
                
                if 'port' in server_config and is_str_not_empty(str(server_config['port'])):
                    self.generate(*server_path, 'port', str(server_config['port']))
                
                if 'priority' in server_config and is_str_not_empty(str(server_config['priority'])):
                    self.generate(*server_path, 'priority', str(server_config['priority']))
                
                if 'acct-port' in server_config and is_str_not_empty(str(server_config['acct-port'])):
                    self.generate(*server_path, 'acct-port', str(server_config['acct-port']))
                
                if 'backup' in server_config:
                    self.generate(*server_path, 'backup')
                
                if 'disable-accounting' in server_config:
                    self.generate(*server_path, 'disable-accounting')
                
                if 'fail-time' in server_config and is_str_not_empty(str(server_config['fail-time'])):
                    self.generate(*server_path, 'fail-time', str(server_config['fail-time']))
        
        if 'source-address' in radius_config and is_str_not_empty(radius_config['source-address']):
            self.generate(*base_path, 'source-address', radius_config['source-address'])
        
        if 'nas-identifier' in radius_config and is_str_not_empty(radius_config['nas-identifier']):
            self.generate(*base_path, 'nas-identifier', radius_config['nas-identifier'])
        
        if 'nas-ip-address' in radius_config and is_str_not_empty(radius_config['nas-ip-address']):
            self.generate(*base_path, 'nas-ip-address', radius_config['nas-ip-address'])
        
        if 'timeout' in radius_config and is_str_not_empty(str(radius_config['timeout'])):
            self.generate(*base_path, 'timeout', str(radius_config['timeout']))
        
        if 'max-try' in radius_config and is_str_not_empty(str(radius_config['max-try'])):
            self.generate(*base_path, 'max-try', str(radius_config['max-try']))

    def _process_general_settings(self, l2tp_config):
        base_path = ['vpn', 'l2tp', 'remote-access']
        
        if 'description' in l2tp_config and is_str_not_empty(l2tp_config['description']):
            self.generate(*base_path, 'description', l2tp_config['description'])
        
        if 'default-pool' in l2tp_config and is_str_not_empty(l2tp_config['default-pool']):
            self.generate(*base_path, 'default-pool', l2tp_config['default-pool'])
        
        if 'default-ipv6-pool' in l2tp_config and is_str_not_empty(l2tp_config['default-ipv6-pool']):
            self.generate(*base_path, 'default-ipv6-pool', l2tp_config['default-ipv6-pool'])
        
        if 'gateway-address' in l2tp_config and is_str_not_empty(l2tp_config['gateway-address']):
            self.generate(*base_path, 'gateway-address', l2tp_config['gateway-address'])
        
        if 'outside-address' in l2tp_config and is_str_not_empty(l2tp_config['outside-address']):
            self.generate(*base_path, 'outside-address', l2tp_config['outside-address'])
        
        if 'mtu' in l2tp_config and has_config_value(l2tp_config['mtu']):
            self.generate(*base_path, 'mtu', str(l2tp_config['mtu']))
        
        if 'name-server' in l2tp_config:
            name_servers = l2tp_config['name-server']
            if isinstance(name_servers, list):
                for ns in name_servers:
                    if is_str_not_empty(ns):
                        self.generate(*base_path, 'name-server', ns)
            elif is_str_not_empty(name_servers):
                self.generate(*base_path, 'name-server', name_servers)
        
        if 'wins-server' in l2tp_config:
            wins_servers = l2tp_config['wins-server']
            if isinstance(wins_servers, list):
                for ws in wins_servers:
                    if is_str_not_empty(ws):
                        self.generate(*base_path, 'wins-server', ws)
            elif is_str_not_empty(wins_servers):
                self.generate(*base_path, 'wins-server', wins_servers)
        
        if 'log' in l2tp_config and 'level' in l2tp_config['log']:
            self.generate(*base_path, 'log', 'level', str(l2tp_config['log']['level']))

    def _process_ipsec_settings(self, ipsec_config):
        base_path = ['vpn', 'l2tp', 'remote-access', 'ipsec-settings']
        
        if 'esp-group' in ipsec_config and is_str_not_empty(ipsec_config['esp-group']):
            self.generate(*base_path, 'esp-group', ipsec_config['esp-group'])
        
        if 'ike-group' in ipsec_config and is_str_not_empty(ipsec_config['ike-group']):
            self.generate(*base_path, 'ike-group', ipsec_config['ike-group'])
        
        if 'lifetime' in ipsec_config and is_str_not_empty(str(ipsec_config['lifetime'])):
            self.generate(*base_path, 'lifetime', str(ipsec_config['lifetime']))
        
        if 'authentication' in ipsec_config:
            auth_config = ipsec_config['authentication']
            auth_path = base_path + ['authentication']
            
            if 'mode' in auth_config and is_str_not_empty(auth_config['mode']):
                self.generate(*auth_path, 'mode', auth_config['mode'])
            
            if 'pre-shared-secret' in auth_config and is_str_not_empty(auth_config['pre-shared-secret']):
                self.generate(*auth_path, 'pre-shared-secret', auth_config['pre-shared-secret'])
            
            if 'x509' in auth_config:
                x509_config = auth_config['x509']
                x509_path = auth_path + ['x509']
                
                if 'ca-certificate' in x509_config and is_str_not_empty(x509_config['ca-certificate']):
                    self.generate(*x509_path, 'ca-certificate', x509_config['ca-certificate'])
                
                if 'certificate' in x509_config and is_str_not_empty(x509_config['certificate']):
                    self.generate(*x509_path, 'certificate', x509_config['certificate'])
                
                if 'passphrase' in x509_config and is_str_not_empty(x509_config['passphrase']):
                    self.generate(*x509_path, 'passphrase', x509_config['passphrase'])

    def _process_lns(self, lns_config):
        base_path = ['vpn', 'l2tp', 'remote-access', 'lns']
        
        if 'host-name' in lns_config and is_str_not_empty(lns_config['host-name']):
            self.generate(*base_path, 'host-name', lns_config['host-name'])
        
        if 'shared-secret' in lns_config and is_str_not_empty(lns_config['shared-secret']):
            self.generate(*base_path, 'shared-secret', lns_config['shared-secret'])

    def _process_ppp_options(self, ppp_config):
        base_path = ['vpn', 'l2tp', 'remote-access', 'ppp-options']
        
        if 'disable-ccp' in ppp_config:
            self.generate(*base_path, 'disable-ccp')
        
        if 'interface-cache' in ppp_config and has_config_value(ppp_config['interface-cache']):
            self.generate(*base_path, 'interface-cache', str(ppp_config['interface-cache']))
        
        if 'ipv4' in ppp_config and is_str_not_empty(ppp_config['ipv4']):
            self.generate(*base_path, 'ipv4', ppp_config['ipv4'])
        
        if 'ipv6' in ppp_config and is_str_not_empty(ppp_config['ipv6']):
            self.generate(*base_path, 'ipv6', ppp_config['ipv6'])
        
        if 'ipv6-accept-peer-interface-id' in ppp_config:
            self.generate(*base_path, 'ipv6-accept-peer-interface-id')
        
        if 'ipv6-interface-id' in ppp_config and is_str_not_empty(ppp_config['ipv6-interface-id']):
            self.generate(*base_path, 'ipv6-interface-id', ppp_config['ipv6-interface-id'])
        
        if 'ipv6-peer-interface-id' in ppp_config and is_str_not_empty(ppp_config['ipv6-peer-interface-id']):
            self.generate(*base_path, 'ipv6-peer-interface-id', ppp_config['ipv6-peer-interface-id'])
        
        if 'lcp-echo-failure' in ppp_config and has_config_value(ppp_config['lcp-echo-failure']):
            self.generate(*base_path, 'lcp-echo-failure', str(ppp_config['lcp-echo-failure']))
        
        if 'lcp-echo-interval' in ppp_config and has_config_value(ppp_config['lcp-echo-interval']):
            self.generate(*base_path, 'lcp-echo-interval', str(ppp_config['lcp-echo-interval']))
        
        if 'lcp-echo-timeout' in ppp_config and has_config_value(ppp_config['lcp-echo-timeout']):
            self.generate(*base_path, 'lcp-echo-timeout', str(ppp_config['lcp-echo-timeout']))
        
        if 'min-mtu' in ppp_config and has_config_value(ppp_config['min-mtu']):
            self.generate(*base_path, 'min-mtu', str(ppp_config['min-mtu']))
        
        if 'mppe' in ppp_config and is_str_not_empty(ppp_config['mppe']):
            self.generate(*base_path, 'mppe', ppp_config['mppe'])
        
        if 'mru' in ppp_config and has_config_value(ppp_config['mru']):
            self.generate(*base_path, 'mru', str(ppp_config['mru']))

    def _process_client_ip_pools(self, pools_config, current_config=None, new_config=None):
        if isinstance(pools_config, list):
            for pool in pools_config:
                if not isinstance(pool, dict) or 'name' not in pool:
                    continue
                pool_name = pool['name']
                base_path = ['vpn', 'l2tp', 'remote-access', 'client-ip-pool', pool_name]
                
                if 'range' in pool:
                    ranges = pool['range']
                    if isinstance(ranges, list):
                        for range_val in ranges:
                            if is_str_not_empty(range_val):
                                self.generate(*base_path, 'range', range_val)
                    elif is_str_not_empty(ranges):
                        self.generate(*base_path, 'range', ranges)
        elif isinstance(pools_config, dict):
            for pool_name, pool_config in pools_config.items():
                base_path = ['vpn', 'l2tp', 'remote-access', 'client-ip-pool', pool_name]
                
                # For delete operations, check if pool should be completely deleted
                if self.operator == 'delete':
                    new_pools = new_config.get('remote-access', {}).get('client-ip-pool', {})
                    if pool_name not in new_pools:
                        self.generate(*base_path)
                        continue
                
                if 'range' in pool_config:
                    ranges = pool_config['range']
                    if isinstance(ranges, list):
                        for range_val in ranges:
                            if is_str_not_empty(range_val):
                                self.generate(*base_path, 'range', range_val)
                    elif is_str_not_empty(ranges):
                        self.generate(*base_path, 'range', ranges)

    def _process_client_ipv6_pools(self, pools_config, current_config=None, new_config=None):
        if isinstance(pools_config, list):
            for pool in pools_config:
                if not isinstance(pool, dict) or 'name' not in pool:
                    continue
                pool_name = pool['name']
                base_path = ['vpn', 'l2tp', 'remote-access', 'client-ipv6-pool', pool_name]
                
                if 'prefix' in pool:
                    prefixes = pool['prefix']
                    if isinstance(prefixes, list):
                        for prefix in prefixes:
                            if is_str_not_empty(prefix):
                                self.generate(*base_path, 'prefix', prefix)
                    elif is_str_not_empty(prefixes):
                        self.generate(*base_path, 'prefix', prefixes)
        elif isinstance(pools_config, dict):
            for pool_name, pool_config in pools_config.items():
                base_path = ['vpn', 'l2tp', 'remote-access', 'client-ipv6-pool', pool_name]
                
                # For delete operations, check if pool should be completely deleted
                if self.operator == 'delete':
                    new_pools = new_config.get('remote-access', {}).get('client-ipv6-pool', {})
                    if pool_name not in new_pools:
                        self.generate(*base_path)
                        continue
                
                if 'prefix' in pool_config:
                    prefixes = pool_config['prefix']
                    if isinstance(prefixes, dict):
                        for prefix_val in prefixes.keys():
                            if is_str_not_empty(prefix_val):
                                self.generate(*base_path, 'prefix', prefix_val)
                    elif isinstance(prefixes, list):
                        for prefix in prefixes:
                            if is_str_not_empty(prefix):
                                self.generate(*base_path, 'prefix', prefix)
                    elif is_str_not_empty(prefixes):
                        self.generate(*base_path, 'prefix', prefixes)

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
