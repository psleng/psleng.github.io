import threading
from gevent.event import Event as CooperativeEvent
from gevent.monkey import get_original


_native_allocate_lock = get_original('_thread', 'allocate_lock')


class OTPStore:
    _instance = None
    _lock = _native_allocate_lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance.otp_requests = {}
                    cls._instance.otp_requests_lock = _native_allocate_lock()
        return cls._instance

    def request_otp(self, request_id, cooperative=False):
        with self.otp_requests_lock:
            if request_id not in self.otp_requests:
                self.otp_requests[request_id] = {
                    # Use an explicit cooperative event for the process runner
                    'event': CooperativeEvent() if cooperative else threading.Event(),
                    'otp': None
                }
            return self.otp_requests[request_id]['event']

    def set_otp(self, request_id, otp):
        with self.otp_requests_lock:
            request = self.otp_requests.get(request_id)
            if request:
                request['otp'] = otp
                event = request['event']
            else:
                event = None

        if event:
            event.set()

    def get_otp(self, request_id, event=None):
        with self.otp_requests_lock:
            request = self.otp_requests.get(request_id)
            if not request or (event is not None and request['event'] is not event):
                return None

            otp = request['otp']
            # Clean up the request to prevent reuse and memory leaks
            del self.otp_requests[request_id]
            return otp

    def cancel_otp_request(self, request_id, event=None):
        with self.otp_requests_lock:
            request = self.otp_requests.get(request_id)
            if not request or (event is not None and request['event'] is not event):
                return False

            del self.otp_requests[request_id]
            request_event = request['event']

        request_event.set()
        return True


otp_store = OTPStore()
