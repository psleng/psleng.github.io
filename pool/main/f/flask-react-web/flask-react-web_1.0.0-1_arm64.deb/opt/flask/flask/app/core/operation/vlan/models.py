from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Float, BigInteger, Text, DateTime, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from app.log.logger import logger
import json

class VLANAddress(db.Model):
    
    __tablename__ = "vyos_config_vlan_address"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    vlan_config_id = Column(Integer, ForeignKey('vyos_config_vlan.id', ondelete='CASCADE'), nullable=False)
    address = Column(String, nullable=False)
    
    vlan_config = relationship("VLANInterfaceConfig", back_populates="addresses")

class VLANInterfaceConfig(db.Model):
    
    __tablename__ = "vyos_config_vlan"

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_name = Column(String, nullable=False)
    vlan_id = Column(String, nullable=False)
    description = Column(String, nullable=True)
    disabled = Column(Boolean, default=False)
    mtu = Column(String, nullable=True)
    
    addresses = relationship("VLANAddress", back_populates="vlan_config", cascade="all, delete-orphan")
    
    @classmethod
    def truncate(cls):
        try:
            db.session.query(VLANAddress).delete()
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            logger.error(f"Error truncating VLAN config: {e}")
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):

        try:
            logger.debug(f"Refreshing VLAN config with data: {data}")
            
            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()
            
            if not data or not isinstance(data, dict):
                logger.warning("No VLAN data to refresh")
                return
            
            for interface_name, config in data.items():
                if not isinstance(config, dict):
                    continue
                
                if 'vif' not in config:
                    continue
                
                vif = config.get('vif', {})
                
                for vlan_id, vlan_config in vif.items():
                    if not isinstance(vlan_config, dict):
                        continue
                    
                    addresses = vlan_config.get('address')
                    description = vlan_config.get('description')
                    disabled = 'disable' in vlan_config
                    mtu = vlan_config.get('mtu')
                    
                    new_vlan = cls(
                        interface_name=interface_name,
                        vlan_id=str(vlan_id),
                        description=description,
                        disabled=disabled,
                        mtu=mtu
                    )
                    
                    if app_context:
                        with app_context:
                            db.session.add(new_vlan)
                            db.session.flush()
                    else:
                        db.session.add(new_vlan)
                        db.session.flush()
                    
                    if addresses:
                        if not isinstance(addresses, list):
                            addresses = [addresses]
                        
                        for addr in addresses:
                            if addr:
                                addr_record = VLANAddress(
                                    vlan_config_id=new_vlan.id,
                                    address=str(addr)
                                )
                                if app_context:
                                    with app_context:
                                        db.session.add(addr_record)
                                else:
                                    db.session.add(addr_record)
            
            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
        except Exception as e:
            # db.session.rollback()
            logger.error(f"Error refreshing VLAN data: {e}")

    def serialize(self):

        result = {}
        
        if self.interface_name:
            result['interface-name'] = self.interface_name
        
        if self.vlan_id:
            result['vlan-id'] = self.vlan_id
        
        if self.addresses:
            addr_list = [addr.address for addr in self.addresses]
            if len(addr_list) == 1:
                result['address'] = addr_list[0]
            elif len(addr_list) > 1:
                result['address'] = addr_list
        
        if self.description:
            result['description'] = self.description
        
        if self.disabled:
            result['disable'] = {}
        
        if self.mtu:
            result['mtu'] = self.mtu
        
        from app.core.operation.ip_options.models import IPv4OptionConfig, IPv6OptionConfig
        from app.core.operation.dhcp_options.models import DHCPv4OptionConfig, DHCPv6OptionConfig
        
        ipv4_config = IPv4OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            vlan_id=self.vlan_id
        ).first()
        
        if ipv4_config:
            ip_result = ipv4_config.to_vyos_format()
            if ip_result:
                result['ip'] = ip_result
        
        ipv6_config = IPv6OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            vlan_id=self.vlan_id
        ).first()
            
        if ipv6_config:
            ipv6_result = ipv6_config.to_vyos_format()
            if ipv6_result:
                result['ipv6'] = ipv6_result
        
        dhcpv4_config = DHCPv4OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            vlan_id=self.vlan_id
        ).first()
        
        if dhcpv4_config:
            dhcp_result = dhcpv4_config.to_vyos_format()
            if dhcp_result:
                result['dhcp-options'] = dhcp_result
        
        dhcpv6_config = DHCPv6OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            vlan_id=self.vlan_id
        ).first()
        
        if dhcpv6_config:
            dhcpv6_result = dhcpv6_config.to_vyos_format()
            if dhcpv6_result:
                result['dhcpv6-options'] = dhcpv6_result
        
        return result