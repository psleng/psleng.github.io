from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean
from pydantic import BaseModel
import pprint
from typing import List, Optional

class AllowClientDTO(BaseModel):
    address: Optional[str] = None


class PTPDTO(BaseModel):
    interfaces: Optional[List[str]] = None
    port: Optional[str] = None


class ServerDTO(BaseModel):
    address: Optional[str] = None
    interleave: Optional[bool] = None
    noselect: Optional[bool] = None
    nts: Optional[bool] = None
    pool: Optional[bool] = None
    ptp: Optional[bool] = None


class NTPDTO(BaseModel):
    allow_clients: Optional[List[AllowClientDTO]] = None
    interface: Optional[str] = None
    ptp: Optional[PTPDTO] = None
    servers: Optional[List[ServerDTO]] = None
    leap_second: Optional[str] = None
    listen_address: Optional[str] = None


class NTPConfig(db.Model):
    __tablename__ = "vyos_ntp_config"

    id = Column(Integer, primary_key=True)
    interface = Column(String(255), nullable=True)
    listen_address = Column(String(255), nullable=True)
    leap_second = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing NTP config...")
            cls.truncate()
            
            ntp_config = cls()
            ntp_config.interface = data.get('interface')
            ntp_config.listen_address = data.get('listen_address')
            ntp_config.leap_second = data.get('leap_second')
            
            db.session.add(ntp_config)
            db.session.commit()
            
        except Exception as e:
            print("Error refreshing NTP config:", str(e))
            # db.session.rollback()

        
    def serialize(self):
        try:
            return {
                'interface': self.interface,
                'listen_address': self.listen_address,
                'leap_second': self.leap_second
            }
        except Exception as e:
            print("Error serializing NTP config:", str(e))
            return {}
    
class NTPAllowClient(db.Model):
    __tablename__ = "vyos_ntp_allow_client"

    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=True)
    
    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data: list):
        try:
            print("Refreshing NTP allow clients...")
            cls.truncate()
            
            if not data:
                return

            for address in data:
                allow_client = cls()
                allow_client.address = address
                db.session.add(allow_client)
                
            db.session.commit()
            
        except Exception as e:
            print("Error refreshing NTP allow clients:", str(e))
            # db.session.rollback()

        
    def serialize(self):
        try:
            return {
                'address': self.address
            }
        except Exception as e:
            print("Error serializing NTP allow clients:", str(e))
            return {}

class NTPServer(db.Model):
    __tablename__ = "vyos_ntp_server"

    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=True)
    interleave = Column(Boolean, nullable=True)
    noselect = Column(Boolean, nullable=True)
    nts = Column(Boolean, nullable=True)
    pool = Column(Boolean, nullable=True)
    ptp = Column(Boolean, nullable=True)
    
    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data: list):
        try:
            print("Refreshing NTP servers...")
            cls.truncate()
            
            if not data:
                return

            for server in data:
                ntp_server = cls()
                ntp_server.address = server.get('address')
                ntp_server.interleave = server.get('interleave', False)
                ntp_server.noselect = server.get('noselect', False)
                ntp_server.nts = server.get('nts', False)
                ntp_server.pool = server.get('pool', False)
                ntp_server.ptp = server.get('ptp', False)
                
                db.session.add(ntp_server)
                
            db.session.commit()
            
        except Exception as e:
            print("Error refreshing NTP servers:", str(e))
            # db.session.rollback()
        
    def serialize(self):
        try:
            return {
                'address': self.address,
                'interleave': self.interleave,
                'noselect': self.noselect,
                'nts': self.nts,
                'pool': self.pool,
                'ptp': self.ptp
            }
        except Exception as e:
            print("Error serializing NTP servers:", str(e))
            return {}

class NTPPTP(db.Model):
    __tablename__ = "vyos_ntp_ptp"

    id = Column(Integer, primary_key=True)
    port = Column(String(255), nullable=True)
    interfaces = Column(String(255), nullable=True)
    
    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing NTP PTP...")
            cls.truncate()
            
            if not data:
                return
                
            ptp = cls()
            ptp.port = data.get('port')
            
            interfaces = data.get('interfaces', [])
            if interfaces:
                ptp.interfaces = ','.join(interfaces)
                
            db.session.add(ptp)
            db.session.commit()
            
        except Exception as e:
            print("Error refreshing NTP PTP:", str(e))
            # db.session.rollback()
    
    def serialize(self):
        try:
            # Convert comma-separated interfaces back to a list
            interface_list = []
            if self.interfaces:
                interface_list = self.interfaces.split(',')
                
            return {
                'port': self.port,
                'interfaces': interface_list
            }
        except Exception as e:
            print("Error serializing NTP PTP:", str(e))
            return {}