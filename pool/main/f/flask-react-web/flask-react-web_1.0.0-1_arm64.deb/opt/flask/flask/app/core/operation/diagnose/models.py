from ipaddress import ip_address
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


DiagnosticTargetType = Literal['IPv4', 'IPv6']


def _is_valid_hostname(value: str) -> bool:
    normalized = value[:-1] if value.endswith('.') else value
    if not normalized or len(normalized) > 253:
        return False
    try:
        ip_address(normalized)
        return False
    except ValueError:
        pass

    labels = normalized.split('.')
    if all(label.isdigit() for label in labels):
        return False
    return all(
        1 <= len(label) <= 63 and
        re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?', label)
        for label in labels
    )


def _validate_target_type(target: str, target_type: DiagnosticTargetType) -> None:
    try:
        address = ip_address(target)
    except ValueError as exc:
        if _is_valid_hostname(target):
            return
        raise ValueError(
            f'Target must be a valid {target_type} address or hostname.'
        ) from exc
    expected_version = 4 if target_type == 'IPv4' else 6
    if address.version != expected_version:
        raise ValueError(
            f'Target must be a valid {target_type} address or hostname.'
        )


class DiagnosticTargetDTO(BaseModel):
    model_config = ConfigDict(extra='forbid')

    target: str

    @field_validator('target')
    @classmethod
    def normalize_target(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError('Target is required.')
        return value


class PingDiagnosticDTO(DiagnosticTargetDTO):
    ping_type: DiagnosticTargetType
    number_of_ping: int = Field(strict=True, ge=1, le=100)

    @model_validator(mode='after')
    def validate_target_matches_type(self):
        _validate_target_type(self.target, self.ping_type)
        return self


class TracerouteDiagnosticDTO(DiagnosticTargetDTO):
    traceroute_type: DiagnosticTargetType

    @model_validator(mode='after')
    def validate_target_matches_type(self):
        _validate_target_type(self.target, self.traceroute_type)
        return self
