from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.api.http.http_request import Action
from app.core.network.dns.models import DNSServer, DNSForwarding, DNSDynamicInterface
from app.core.network.dns.hostname_mapping.models import HostnameMappingConfig
from app.core.security.models import Firewallv4, Firewallv6, FirewallSettings
from app.core.network.nat.models import NATv4
from app.core.network.nat66.models import NAT66Config
from app.core.network.dhcp.models import DHCPRelay, DHCPPool, DHCPPoolv6, DHCPListenInterface, DHCPListenInterfacev6
from app.core.network.ntp.models import NTPConfig, NTPAllowClient, NTPPTP, NTPServer
from app.core.network.amp.models import AMPConfig
from app.core.models import ServiceState, System, ServiceStatistic
from app.core.network.dns.parser import parse_dns_config, parse_dns_dynamic, parse_dns_servers, parse_dns_forward
from app.core.security.parser.firewall import parse_firewall_config, parse_firewall_operation, parse_firewall_operation_log
from app.core.network.nat.parser import parse_nat_config
from app.core.network.dhcp.parser import parse_dhcp_config, parse_dhcp_relay_config
from app.core.network.ntp.parser import parse_ntp_config
from app.core.api.http.srv.parser import parse_user_config_to_db
from app.core.routing.models import GeneralRouting, GeneralRoutingV6
from app.core.routing.ospf.models import OSPF
from app.core.routing.ospfv3.models import OSPFv3
from app.core.routing.rip.models import RIP
from app.core.routing.ripng.models import RIPng
from app.core.service.country_code import read_country_code
from app.core.models import SystemDefault
from app.log.logger import logger
from app.core.operation.models import UserManagement
from app.core.operation.wireguard.models import WireguardInterfaceConfig
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig
from app.core.high_availability.vrrp.models import VRRP
from app.core.high_availability.wan_load_balancing.models import WanLoadBalancing
from app.core.operation.models import PKICaCertificate, PKICertificate, OpenVPNSharedSecretKey, KeyPair, PKIDH, PKIOpenSSHKey
from app.core.operation.parser import parse_ca_certificate_config, parse_certificate_config, parse_keypair_config, parse_openssh_config, parse_openvpn_shared_secret_key, parse_dh_config
from app.core.operation.ipsec.models import IPsecConfig
from app.core.vpn.pptp.models import PPTPConfig
from app.core.vpn.sstp.models import SSTPConfig
from app.core.vpn.l2tp.models import L2TPConfig
from app.core.operation.vlan.models import VLANInterfaceConfig
from app.core.operation.ethernet.models import EthernetInterfaceConfig
from app.core.operation.ip_options.models import IPv4OptionConfig, IPv6OptionConfig
from app.core.operation.dhcp_options.models import DHCPv4OptionConfig, DHCPv6OptionConfig
from app.core.operation.bridge.models import BridgeInterfaceConfig
from app.core.operation.cellular.models import WWANInterfaceConfig
from app.core.network.ipv6_ra.models import IPv6RA
from app.core.network.snmp.models import SNMPConfig
from app.core.operation.models import InterfaceAddressDHCP
from app.core.system.syslog.models import SyslogConfig
from app.core.system.event_handler.models import AlarmConfig
from app.core.system.email.models import EmailConfig
from app.core.routing.flex.models import FlexRoutingConfig
from app.core.network.https.models import HTTPSConfig
from app.core.network.ssh.models import SSHConfig
from app.core.network.arp.models import ARPEntry
from app.core.network.ndp_proxy.models import NDPProxyConfig
from app.core.network.lldp.models import LLDPConfig
from app.core.operation.software_management.models import SoftwareUpdateCheckConfig
from app.db.database import db
from app.core.models import Services, AdminSelectedService
from app.core.login.db_models import SystemLoginOptions
from app.core.models import InterfaceConfig
from app.core.operation.l2tpv3.models import L2TPv3InterfaceConfig
from app.config import global_config
from datetime import datetime, timedelta

def refresh_config(config):
    if isinstance(config, dict):
        AMPConfig.refresh((config.get('service') or {}).get('sla') or {})
    if config:
        HostnameMappingConfig.refresh(config.get('system') or {})
        LLDPConfig.refresh((config.get('service') or {}).get('lldp'))
        # Truncate existing tables in case the config key was deleted
        PPTPConfig.truncate()
        L2TPConfig.truncate()
        SSTPConfig.truncate()
        AlarmConfig.truncate()
        EmailConfig.truncate()
        WanLoadBalancing.truncate()
        SSHConfig.truncate()
        System.set_timezone((config.get('system') or {}).get('time-zone'))

        if 'pki' in config:
            logger.debug("PKI config: ")
            logger.debug(config['pki'])
            if 'ca' in config['pki']:
                ca_certificates = parse_ca_certificate_config(config['pki']['ca'])
                PKICaCertificate.refresh(ca_certificates)
            if 'certificate' in config['pki']:
                certificates = parse_certificate_config(config['pki']['certificate'])
                PKICertificate.refresh(certificates)
            if 'key-pair' in config['pki']:
                keypairs = parse_keypair_config(config['pki']['key-pair'])
                KeyPair.refresh(keypairs)
            if 'openssh' in config['pki']:
                openssh_keys = parse_openssh_config(config['pki']['openssh'])
                PKIOpenSSHKey.refresh(openssh_keys)
            if 'openvpn' in config['pki']:
                openvpn_shared_secret_keys = parse_openvpn_shared_secret_key(config['pki']['openvpn'])
                OpenVPNSharedSecretKey.refresh(openvpn_shared_secret_keys)
            if 'dh' in config['pki']:
                dh_items = parse_dh_config(config['pki']['dh'])
                PKIDH.refresh(dh_items)

        if 'service' in config:
            if 'dns' in config['service']:
                dns_config = parse_dns_config(config['service']['dns'])
                DNSForwarding.refresh(dns_config.get('forwarding'))
                DNSDynamicInterface.refresh(dns_config.get('dynamic'))
            
            if 'dhcp-server' in config['service']:
                parsed_dhcp_config = parse_dhcp_config({'dhcp': config['service']['dhcp-server']})
                DHCPPool.refresh(parsed_dhcp_config)
                DHCPListenInterface.refresh(parsed_dhcp_config)

                if 'disable' in parsed_dhcp_config['dhcp'] and (
                        parsed_dhcp_config['dhcp']['disable'] == True or parsed_dhcp_config['dhcp']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcp'] and parsed_dhcp_config['dhcp']['disable'] == False) or (
                        'disable' not in parsed_dhcp_config['dhcp']):
                    ServiceState.set_state('dhcp_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcp']:
                    ServiceState.set_state('dhcp_server', "enable")

            if 'dhcpv6-server' in config['service']:
                parsed_dhcp_config = parse_dhcp_config({'dhcpv6': config['service']['dhcpv6-server']})
                DHCPPoolv6.refresh(parsed_dhcp_config)
                DHCPListenInterfacev6.refresh(parsed_dhcp_config)
                if 'disable' in parsed_dhcp_config['dhcpv6'] and (
                        parsed_dhcp_config['dhcpv6']['disable'] == True or parsed_dhcp_config['dhcpv6']['disable'] == {}):
                    ServiceState.set_state('dhcpv6_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcpv6'] and parsed_dhcp_config['dhcpv6']['disable'] == False):
                    ServiceState.set_state('dhcpv6_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcpv6']:
                    ServiceState.set_state('dhcpv6_server', "enable")

            if 'dhcp-relay' in config['service']:
                dhcp_relay_config = parse_dhcp_relay_config(config['service']['dhcp-relay'])
                DHCPRelay.refresh(dhcp_relay_config)
            
            if 'ntp' in config['service']:
                ntp_config = parse_ntp_config(config['service']['ntp'])
                NTPConfig.refresh(ntp_config)
                NTPAllowClient.refresh(ntp_config.get('allow-client'))
                NTPPTP.refresh(ntp_config.get('ptp'))
                NTPServer.refresh(ntp_config.get('server'))

            if 'router-advert' in config['service']:
                # refresh IPv6 R.A for interfaces
                print("Router service")
                print(config['service']['router-advert'])
                IPv6RA.refresh(config['service']['router-advert'])

            if 'snmp' in config['service']:
                print("SNMP service")
                print(config['service']['snmp'])
                SNMPConfig.refresh(config['service']['snmp'])

            if 'https' in config['service']:
                print("HTTPS service")
                print(config['service']['https'])
                HTTPSConfig.refresh(config['service']['https'])

            if 'ssh' in config['service']:
                logger.info("Refreshing SSH service configuration")
                SSHConfig.refresh(config['service']['ssh'])

            if 'ndp-proxy' in config['service']:
                print("NDP Proxy service")
                print(config['service']['ndp-proxy'])
                NDPProxyConfig.refresh(config['service']['ndp-proxy'])

            if 'event-handler' in config['service']:
                print("Alarm config: ")
                print(config['service']['event-handler'])
                AlarmConfig.refresh(config['service']['event-handler'])

        if 'system' in config:
            SoftwareUpdateCheckConfig.refresh(config['system'].get('update-check') or {})

            if 'name-server' in config['system']:
                name_servers = parse_dns_servers(config['system']['name-server'])
                DNSServer.refresh(name_servers)
            
            if 'login' in config['system']:
                print("System login config:")
                print(config['system']['login'])
                
                users = parse_user_config_to_db(config['system'])
                UserManagement.refresh(users)
                SystemLoginOptions.refresh(config['system'].get('login') or {})
            
            if 'syslog' in config['system']:
                print("Syslog config:")
                print(config['system']['syslog'])
                SyslogConfig.refresh(config['system']['syslog'])

            if 'email' in config['system']:
                EmailConfig.refresh(config['system']['email'])

        
        if 'firewall' in config:
            firewall_config = parse_firewall_config(config['firewall'])
            Firewallv4.refresh(firewall_config, None)
            Firewallv6.refresh(firewall_config, None)
            FirewallSettings.refresh(firewall_config, None)
            # When firewall ipv6 block is enabled, disable all of ipv6 features in all pages.
            System.set_ipv6_status(firewall_config)

        if 'nat' in config:
            nat_config = parse_nat_config(config)
            NATv4.refresh(nat_config)

        if 'nat66' in config:
            NAT66Config.refresh(config['nat66'])

        if 'protocols' in config:
            GeneralRouting.refresh(config['protocols'])
            GeneralRoutingV6.refresh(config['protocols'])
            if 'ospf' in config['protocols']:
                OSPF.refresh(config['protocols']['ospf'])
            if 'ospfv3' in config['protocols']:
                OSPFv3.refresh(config['protocols']['ospfv3'])
            if 'rip' in config['protocols']:
                RIP.refresh(config['protocols']['rip'])
            if 'ripng' in config['protocols']:
                RIPng.refresh(config['protocols']['ripng'])
            if 'failover' in config['protocols']:
                FlexRoutingConfig.refresh(config['protocols']['failover'])
            if 'static' in config['protocols']:
                static_cfg = config['protocols'].get('static')
                if isinstance(static_cfg, dict) and 'arp' in static_cfg:
                    ARPEntry.refresh(static_cfg.get('arp') or {})

        
        if 'high-availability' in config:
            if 'vrrp' in config['high-availability']:
                VRRP.refresh(config['high-availability']['vrrp'])

        if 'load-balancing' in config:
            if 'wan' in config['load-balancing']:
                WanLoadBalancing.refresh(config['load-balancing']['wan'])

        if 'interfaces' in config:
            # DEBUG: Log what interfaces are available
            logger.debug(f"=== DEBUG: Available interface types: {list(config['interfaces'].keys())}")
            
            # refresh all interface configs
            InterfaceConfig.refresh(config['interfaces'])
            InterfaceConfig.sync_vrrp_entries()
            
            # refresh wifi
            # refresh openvpn
            if 'openvpn' in config['interfaces']:
                OpenVPNInterfaceConfig.refresh(config['interfaces']['openvpn'])
            if 'wireguard' in config['interfaces']:
                WireguardInterfaceConfig.refresh(config['interfaces']['wireguard'])
            WWANInterfaceConfig.refresh(config['interfaces'].get('wwan', {}))
            # refresh VLAN, IP options, and DHCP options from ethernet:
            if 'ethernet' in config['interfaces']:
                print("Ethernet config: ")
                print(config['interfaces']['ethernet'])
                EthernetInterfaceConfig.refresh(
                    config['interfaces']['ethernet'],
                    bridge_config=config['interfaces'].get('bridge', {})
                )
                # Refresh VLAN
                VLANInterfaceConfig.refresh(config['interfaces']['ethernet'])
                # Refresh IP options
                IPv4OptionConfig.refresh(config['interfaces']['ethernet'])
                IPv6OptionConfig.refresh(config['interfaces']['ethernet'])
                # Refresh DHCP options
                DHCPv4OptionConfig.refresh(config['interfaces']['ethernet'])
                DHCPv6OptionConfig.refresh(config['interfaces']['ethernet'])
            if 'bridge' in config['interfaces']:
                print("Bridge config: ")
                print(config['interfaces']['bridge'])
                BridgeInterfaceConfig.refresh(config['interfaces']['bridge'])
            
            if 'l2tpv3' in config['interfaces']:
                print("L2TPv3 config: ")
                print(config['interfaces']['l2tpv3'])
                L2TPv3InterfaceConfig.refresh(config['interfaces']['l2tpv3'])

            # refresh interfaces that use DHCP address
            InterfaceAddressDHCP.refresh(config['interfaces'])
            
            # refresh IP tunnels - VyOS stores all tunnel types under 'tunnel' key
            # Each tunnel has an 'encapsulation' field (gre/ipip/sit/vti)
            if 'tunnel' in config['interfaces']:
                logger.debug(f"Found tunnel interfaces: {list(config['interfaces']['tunnel'].keys())}")
                
                # Reorganize tunnels by encapsulation type
                tunnel_config = {}
                for tunnel_name, tunnel_data in config['interfaces']['tunnel'].items():
                    encapsulation = tunnel_data.get('encapsulation', 'gre')  # default to gre if not specified
                    if encapsulation not in tunnel_config:
                        tunnel_config[encapsulation] = {}
                    tunnel_config[encapsulation][tunnel_name] = tunnel_data
                
                if tunnel_config:
                    logger.debug(f"Refreshing IP tunnels with config: {tunnel_config}")
                    from app.core.operation.iptunnels.models import IPTunnelConfig
                    IPTunnelConfig.refresh(tunnel_config)
            else:
                logger.debug("No 'tunnel' key found in config['interfaces']")

        if 'vpn' in config:
            if 'ipsec' in config['vpn']:
                print("IPsec config: ")
                print(config['vpn']['ipsec'])
                IPsecConfig.refresh(config['vpn']['ipsec'])
            if 'pptp' in config['vpn']:
                print("PPTP config: ")
                print(config['vpn']['pptp'])
                PPTPConfig.refresh(config['vpn']['pptp'])

            if 'sstp' in config['vpn']:
                print("SSTP config: ")
                print(config['vpn']['sstp'])
                SSTPConfig.refresh(config['vpn']['sstp'])

            if 'l2tp' in config['vpn']:
                print("L2TP config: ")
                print(config['vpn']['l2tp'])
                L2TPConfig.refresh(config['vpn']['l2tp'])

def fetch_os_config(provider, data={"refresh": None}):
    try:
        do_refresh = False
        if data and isinstance(data, dict):
            do_refresh = data.get("refresh", False)
        res = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ALL_CONFIGS, verify=False)

        retry_job_id = 'fetch_os_config_5sc'
        config_json = None
        config_data = {}
        if not isinstance(res, Exception) and res and hasattr(res, 'json'):
            config_json = res.json()
            if isinstance(config_json, dict):
                config_data = config_json.get('data') or {}

        if isinstance(res, Exception) or not res or not config_data:
            if isinstance(res, Exception) or not res:
                print("Fetch os config exception: ")
                print(str(res))

            scheduler = global_config.app_scheduler
            if scheduler and scheduler.get_job(id=retry_job_id) is None:
                run_time = datetime.now() + timedelta(seconds=5)
                scheduler.add_job(
                    id=retry_job_id,
                    func=fetch_os_config,
                    args=[provider, {"refresh": do_refresh}],
                    trigger="date",
                    run_date=run_time,
                    misfire_grace_time=10,
                    coalesce=True,
                    max_instances=1
                )
                logger.debug(f"Scheduled retry job '{retry_job_id}' to run at {run_time}")

            return {}

        scheduler = global_config.app_scheduler
        if scheduler and scheduler.get_job(id=retry_job_id) is not None:
            scheduler.remove_job(retry_job_id)
            logger.debug(f"Removed retry job '{retry_job_id}' as valid data was received")

        print("Config json data: ")
        print(config_json)
        if do_refresh:
            refresh_config(config_data)
        return config_data
    except Exception as e:
        print("Fetch os config exception: ")
        print(str(e))
        return {}

def fetch_country_code(app_context):
    try:
        
        country_codes = read_country_code()
        SystemDefault.refresh(
            {"country_code": country_codes}, 
            app_context
        )

    except Exception as e:
        print("Fetch country code failed: ")
        print(str(e))
        logger.error("Fetch country code failed: ")
        logger.error(str(e))


def refresh_service_stat(stat):
    logger.debug("Refreshing service stat with data: ", stat)
    try:
        stats_to_update = {}
        #logger.debug("stat is", stat)
    
        dhcp_stats_raw = stat.get('DHCP')
        #logger.debug("DHCP stats raw:")
        #logger.debug(dhcp_stats_raw)
        if isinstance(dhcp_stats_raw, list):
            active_leases = sum(int(p.get('leases', '0')) for p in dhcp_stats_raw)
            available_ips = sum(int(p.get('available', '0')) for p in dhcp_stats_raw)
            stats_to_update['dhcp'] = {
                'active': active_leases,
                'available': available_ips,
                #'lease_time': 0
                #do something like offset
            }

        # NTP
        ntp_stats_raw = stat.get('NTP')
        if isinstance(ntp_stats_raw, dict):
            stratum = ntp_stats_raw.get('stratum', 0)
            offset_val = ntp_stats_raw.get('last_offset', 0.0)
            offset = f"{offset_val} ms"
            stats_to_update['ntp'] = {
                'stratum': stratum,
                'offset': offset
            }

        # DNS
        dns_stats_raw = stat.get('DNS')
        
        if dns_stats_raw is None:
            dns_result = []
        else:
            dns_result = (
                (dns_stats_raw.get('data') or {}).get('ShowDnsNameserversPerleDnsQuery') or {}
            ).get('data', {}).get('result', [])
        
        if isinstance(dns_result, list) and len(dns_result) > 0:
            server_list = [entry.get('server', '') for entry in dns_result if entry.get('server')]
            stats_to_update['dns'] = {
                'servers': len(server_list),
                'server_list': server_list
            }
        else:
            stats_to_update['dns'] = {
                'servers': 0,
                'server_list': []
            }

        # Firewall
        firewall_stats_raw = stat.get('Firewall')
        if isinstance(firewall_stats_raw, list):
            accepted_rules = 0
            dropped_rules = 0
            for rule in firewall_stats_raw:
                try:
                    action = rule.get('config', {}).get('action')
                    if action == 'accept':
                        accepted_rules += 1
                    elif action == 'drop':
                        dropped_rules += 1
                except (ValueError, TypeError):
                    continue
            stats_to_update['firewall'] = {
                'accepted': accepted_rules,
                'dropped': dropped_rules,
                'total': accepted_rules + dropped_rules
            }
        
        # VRRP
        vrrp_stats_raw = stat.get('VRRP')
       # print(vrrp_stats_raw)
        groups = 0
        sync_groups = 0
        if isinstance(vrrp_stats_raw, dict):
            group_config = vrrp_stats_raw.get('group', [])
            if isinstance(group_config, dict):
                groups = len(group_config)
            sync_group_config = vrrp_stats_raw.get('sync-group', [])
            if isinstance(sync_group_config, dict):
                sync_groups = len(sync_group_config)
            stats_to_update['vrrp'] = {
                'groups': groups,
                'sync_groups': sync_groups
            }

        #Wireguard
        wireguard_stats_raw = stat.get('Wireguard')
        print("Wireguard stats raw: ")
        print(wireguard_stats_raw)

        if isinstance(wireguard_stats_raw, list):
            interface_count = len(wireguard_stats_raw)
            peer_count = sum(len(iface.get("peers", [])) for iface in wireguard_stats_raw)

            stats_to_update['wireguard'] = {
                'interfaces': interface_count,
                'peers': peer_count
            }

        #print("intefaces is", interface_count)
       # print("peer_count is", peer_count)

        ipsec_stats_raw = stat.get('IPSEC')
        #print("IPsec stats raw: ")
        #print(ipsec_stats_raw)
        
        if isinstance(ipsec_stats_raw, dict):
            connections = ipsec_stats_raw.get('connections') or {}
            sa_detail = ipsec_stats_raw.get('sa_details') or {}

            connections_list = (
                (connections.get('ShowConnectionsIpsec') or {})
                .get('data', {})
                .get('result', [])
            )

            sa_result_list = (
                (sa_detail.get('ShowSaDetailIpsec') or {})
                .get('data', {})
                .get('result', [])
            )
            
            connection_count = len(connections_list)

            sa_count = 0
            for item in sa_result_list:
                if isinstance(item, dict):
                    sa_count += len(item) 

            stats_to_update['ipsec'] = {
                'connections': connection_count,
                'sa': sa_count
            }

            #print("IPsec connections: ", connection_count)
            #print("IPsec SAs: ", sa_count)

        snmp_stats_raw = stat.get('SNMP')
        logger.debug("SNMP stats raw: ")
        logger.debug(snmp_stats_raw)

        if isinstance(snmp_stats_raw, dict):
            traps = 0

            community = snmp_stats_raw.get('community') or []
            v3 = snmp_stats_raw.get('v3') or {}
            
            
            if isinstance(community, list):
                total_interfaces = sum(int(row.get("interfaces") or 0) for row in community)
                total_rx = sum(int(row.get("received_packets") or 0) for row in community)
                total_tx = sum(int(row.get("transmitted_packets") or 0) for row in community)
            else:
                total_interfaces = total_rx = total_tx = 0



            traps_list = v3.get("trap") or []
            traps = len(traps_list)

            
            stats_to_update['snmp'] = {
                'interfaces': total_interfaces,
                'packets': total_rx + total_tx,
                'traps': traps
            }

        nat_stats_raw = stat.get('NAT')
        logger.debug("NAT stats raw: ")
        logger.debug(nat_stats_raw)
        if isinstance(nat_stats_raw, dict):
            source = nat_stats_raw.get('source') or []
            destination = nat_stats_raw.get('destination') or []

            if isinstance(source, list):
                source_packets = sum(int(row.get('packets') or 0) for row in source)
                source_bytes = sum(int(row.get('bytes') or 0) for row in source)
            else:
                source_packets = source_bytes = 0

            if isinstance(destination, list):
                destination_packets = sum(int(row.get('packets') or 0) for row in destination)
                destination_bytes = sum(int(row.get('bytes') or 0) for row in destination)
            else:
                destination_packets = destination_bytes = 0

            stats_to_update['nat'] = {
                'source_packets': source_packets,
                'source_traffic': source_bytes,
                'destination_packets': destination_packets,
                'destination_traffic': destination_bytes
            }

        load_balancing_stats_raw = stat.get('Load Balancing')
        logger.debug("Load Balancing stats raw: ")
        logger.debug(load_balancing_stats_raw)
        if isinstance(load_balancing_stats_raw, dict):
            up_interfaces = []
            down_interfaces = []
            for interface_name, interface_data in load_balancing_stats_raw.items():
                if not isinstance(interface_data, dict):
                    continue
                state = interface_data.get('state')
                if state is True or state == 'true' or state == 1:
                    up_interfaces.append(interface_name)
                else:
                    down_interfaces.append(interface_name)

            stats_to_update['load balancing'] = {
                'up_interfaces': up_interfaces,
                'down_interfaces': down_interfaces,
            }

        print("Stats to update: ", stats_to_update)
        if stats_to_update:
            admin_services = (
                db.session.query(Services)
                .join(AdminSelectedService, AdminSelectedService.service_id == Services.id)
                .all()
            )

            admin_service_map = {
                service.name.lower(): service.id
                for service in admin_services
            }

            for service_name, feature_stats in stats_to_update.items():
                service_id = admin_service_map.get(service_name.lower())
                if not service_id:
                    continue  

                ServiceStatistic.refresh_stats(service_id, feature_stats)

            logger.debug("Service statistics refreshed successfully.")
        else:
            logger.debug("No valid service statistics found to refresh.")

    except Exception as e:
        logger.debug(f"An error occurred during service stat refresh: {e}")


def init_service_stat():
    try:
        ServiceStatistic.init_stat()
    except Exception as e:
        logger.error("Refresh service stat failed: ")
        logger.error(str(e))
        return None
