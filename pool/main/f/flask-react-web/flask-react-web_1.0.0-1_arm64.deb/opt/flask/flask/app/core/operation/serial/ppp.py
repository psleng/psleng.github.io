import json
import re
from copy import deepcopy

from app.core.operation.serial.models import SerialPppInterfaceDTO


PPP_FLAGS = ('disable-address-control-compression', 'disable-protocol-compression', 'magic-negotiation', 'vj-compression')
PPP_AUTH_FIELDS = ('username', 'password', 'remote-user', 'remote-password', 'challenge-interval')
PPP_SCALARS = (
    'description', 'local-address', 'remote-address', 'accm', 'idle-timeout', 'mru', 'nak-retry',
    'authentication/timeout', 'configure-request/retry', 'configure-request/timeout',
    'echo/retry', 'echo/timeout', 'terminate-request/retry', 'terminate-request/timeout',
    'ipv6/global-parameters-network-prefix', 'ipv6/local-interface-identifier', 'ipv6/remote-interface-identifier',
)


def _get(tree, path):
    for key in path.split('/'):
        if not isinstance(tree, dict) or key not in tree:
            return None
        tree = tree[key]
    return tree


def _put(tree, path, value):
    keys = path.split('/')
    for key in keys[:-1]:
        tree = tree.setdefault(key, {})
    tree[keys[-1]] = value


def _remove(tree, path):
    key, _, rest = path.partition('/')
    if rest and isinstance(tree.get(key), dict):
        _remove(tree[key], rest)
        if not tree[key]:
            del tree[key]
    elif not rest:
        tree.pop(key, None)


def _protocol(interface):
    protocols = _get(interface, 'authentication/protocol') or {}
    selected = [name for name in ('none', 'chap', 'pap') if name in protocols]
    if len(selected) > 1:
        raise ValueError('PPP authentication protocol: only one of none, chap, or pap is allowed')
    return selected[0] if selected else 'none'


def ppp_interface_to_form(interface):
    values = {path: str(value) for path in PPP_SCALARS if (value := _get(interface, path)) is not None}
    values.update({path: True for path in PPP_FLAGS if path in interface})
    protocol = _protocol(interface)
    values['authentication/protocol'] = protocol
    if protocol != 'none':
        for field in PPP_AUTH_FIELDS:
            value = _get(interface, f'authentication/protocol/{protocol}/{field}')
            if value is not None and (field != 'challenge-interval' or protocol == 'chap'):
                values[f'authentication/{field}'] = str(value)
    return values


def _apply_values(interface, values):
    values = SerialPppInterfaceDTO.model_validate(values).model_dump(by_alias=True, exclude_none=True)
    protocol = values.get('authentication/protocol') or 'none'
    for path in (*PPP_SCALARS, *PPP_FLAGS):
        _remove(interface, path)
        if path in values and values[path] is not False:
            _put(interface, path, {} if path in PPP_FLAGS else values[path])
    protocols = interface.setdefault('authentication', {}).setdefault('protocol', {})
    selected = deepcopy(protocols.get(protocol, {}))
    for field in PPP_AUTH_FIELDS:
        selected.pop(field, None)
        if protocol != 'none' and (field != 'challenge-interval' or protocol == 'chap'):
            if f'authentication/{field}' in values:
                selected[field] = values[f'authentication/{field}']
    interface['authentication']['protocol'] = {protocol: selected if protocol != 'none' else {}}


def _diff_commands(previous, candidate, path, deletes, sets):
    for key in sorted(previous.keys() - candidate.keys()):
        deletes.append(_command('delete', *path, key))
    for key in sorted(candidate):
        value = candidate[key]
        current = previous.get(key)
        if key in previous and current == value:
            continue
        if isinstance(value, dict):
            if key in previous and not isinstance(current, dict):
                deletes.append(_command('delete', *path, key))
            if value:
                _diff_commands(current if isinstance(current, dict) else {}, value, [*path, key], deletes, sets)
            else:
                if isinstance(current, dict) and current:
                    _diff_commands(current, {}, [*path, key], deletes, sets)
                sets.append(_command('set', *path, key))
        else:
            sets.append(_command('set', *path, key, str(value)))


def _ppp_devices(config):
    profiles = config.get('profile', {}).get('tty-profile', {})
    return {
        name for name, device in config.get('device', {}).items()
        if 'ppp' in device or 'ppp' in profiles.get(device.get('profile'), {})
    }


def _command(operator, *path):
    return json.dumps({'op': operator, 'path': list(path)})


def plan_ppp_interfaces(current_config, new_config, current_interfaces, values=None):
    interfaces = deepcopy(current_interfaces)
    previous_devices = _ppp_devices(current_config)
    devices = _ppp_devices(new_config)
    largest = max(
        (int(match[1]) for name in current_interfaces
         if (match := re.fullmatch(r'pppttys(\d+)', name))),
        default=-1,
    )
    set_cmds, delete_cmds = [], []

    for name, interface in list(interfaces.items()):
        if interface.get('device') in previous_devices - devices:
            delete_cmds.append(_command('delete', 'interfaces', 'ppp-tty', name))
            del interfaces[name]

    for device in sorted(devices):
        matches = [name for name, interface in interfaces.items() if interface.get('device') == device]
        if len(matches) > 1:
            raise ValueError(f'device {device}: multiple ppp-tty interfaces use this serial port')
        if matches:
            name = matches[0]
        else:
            largest += 1
            name = f'pppttys{largest}'
        previous = interfaces.get(name, {})
        interface = deepcopy(previous)
        interface['device'] = device
        if values is not None and device in values:
            _apply_values(interface, values[device])
        if not interface.get('authentication', {}).get('protocol'):
            interface.setdefault('authentication', {})['protocol'] = {'none': {}}
        _diff_commands(previous, interface, ['interfaces', 'ppp-tty', name], delete_cmds, set_cmds)
        interfaces[name] = interface

    return {'config': interfaces, 'set_cmds': set_cmds, 'delete_cmds': delete_cmds}
