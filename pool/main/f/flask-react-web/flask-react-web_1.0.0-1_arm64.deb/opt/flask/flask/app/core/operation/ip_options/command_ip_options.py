class IPOptionCommand:
    """
    IP options command, used to attach to individual interfaces:
    
    - set/delete interfaces <intf-type> <intf-name> ip adjust-mss  {clamp-mss-to-pmtu | <536-65535>}
    - set/delete interfaces <intf-type> <intf-name> ip arp-cache-timeout <1-86400>
    - set/delete interfaces <intf-type> <intf-name> ip disable-arp-filter
    - set/delete interfaces <intf-type> <intf-name> ip disable-forwarding
    - set/delete interfaces <intf-type> <intf-name> ip enable-arp-accept
    - set/delete interfaces <intf-type> <intf-name> ip enable-arp-announce
    - set/delete interfaces <intf-type> <intf-name> ip enable-arp-ignore
    - set/delete interfaces <intf-type> <intf-name> ip enable-directed-broadcast
    - set/delete interfaces <intf-type> <intf-name> ip enable-proxy-arp
    - set/delete interfaces <intf-type> <intf-name> ip proxy-arp-pvlan
    - set/delete interfaces <intf-type> <intf-name> ip source-validation {strict | loose | disable}
    - set/delete interfaces <intf-type> <intf-name> ipv6 accept-dad {0 | 1 | 2}
    - set/delete interfaces <intf-type> <intf-name> ipv6 address autoconf
    - set/delete interfaces <intf-type> <intf-name> ipv6 address eui64 <h:h:h:h:h:h:h:h/64>
    - set/delete interfaces <intf-type> <intf-name> ipv6 address interface-identifier <h:h:h:h>
    - set/delete interfaces <intf-type> <intf-name> ipv6 address no-default-link-local
    - set/delete interfaces <intf-type> <intf-name> ipv6 adjust-mss {clamp-mss-to-pmtu | <536-65535>}
    - set/delete interfaces <intf-type> <intf-name> ipv6 base-reachable-time <1-86400>
    - set/delete interfaces <intf-type> <intf-name> ipv6 disable-forwarding
    - set/delete interfaces <intf-type> <intf-name> ipv6 dup-addr-detect-transmits  <0 | N>
    - set/delete interfaces <intf-type> <intf-name> ipv6 source-validation  {strict | loose | disable}

    if vlan_id is not None, the commands will become:
        - set/delete interfaces <intf-type> <intf-name> vif <vlan-id> ip...
        - set/delete interfaces <intf-type> <intf-name> vif <vlan-id> ipv6...

    """
    def __init__(self, **kwargs):
        try:
            self.operator = kwargs.get('operator', 'set')
            self.intf_type = kwargs.get('intf_type', '')
            self.intf_name = kwargs.get('intf_name', '')
            self.vlan_id = kwargs.get('vlan_id', None)
            self.attributes = {
                'ip': {
                },
                'ipv6': {
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing IP options cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            if self.vlan_id is not None:
                base = ['interfaces', self.intf_type, self.intf_name, 'vif', str(self.vlan_id)]
            else:
                base = ['interfaces', self.intf_type, self.intf_name]
            
            if 'ip' in data and isinstance(data['ip'], dict):
                self._process_ip_config(base, data['ip'])
            
            if 'ipv6' in data and isinstance(data['ipv6'], dict):
                self._process_ipv6_config(base, data['ipv6'])
            
            return self.cmds
        
        except Exception as e:
            print(f"Error generating IP options commands: {e}")
            return []
    
    def _process_ip_config(self, base, ip_config):
        ip_base = base + ['ip']
        
        if 'adjust-mss' in ip_config:
            value = ip_config['adjust-mss']
            if value:
                self.generate(*ip_base, 'adjust-mss', str(value))
        
        if 'arp-cache-timeout' in ip_config:
            value = ip_config['arp-cache-timeout']
            if value:
                self.generate(*ip_base, 'arp-cache-timeout', str(value))
        
        if 'disable-arp-filter' in ip_config:
            self.generate(*ip_base, 'disable-arp-filter')
        
        if 'disable-forwarding' in ip_config:
            self.generate(*ip_base, 'disable-forwarding')
        
        if 'enable-arp-accept' in ip_config:
            self.generate(*ip_base, 'enable-arp-accept')
        
        if 'enable-arp-announce' in ip_config:
            self.generate(*ip_base, 'enable-arp-announce')
        
        if 'enable-arp-ignore' in ip_config:
            self.generate(*ip_base, 'enable-arp-ignore')
        
        if 'enable-directed-broadcast' in ip_config:
            self.generate(*ip_base, 'enable-directed-broadcast')
        
        if 'enable-proxy-arp' in ip_config:
            self.generate(*ip_base, 'enable-proxy-arp')
        
        if 'proxy-arp-pvlan' in ip_config:
            self.generate(*ip_base, 'proxy-arp-pvlan')
        
        if 'source-validation' in ip_config:
            value = ip_config['source-validation']
            if value:
                self.generate(*ip_base, 'source-validation', str(value))
    
    def _process_ipv6_config(self, base, ipv6_config):
        ipv6_base = base + ['ipv6']
        
        if 'accept-dad' in ipv6_config:
            value = ipv6_config['accept-dad']
            if value is not None:
                self.generate(*ipv6_base, 'accept-dad', str(value))
        
        if 'address' in ipv6_config and isinstance(ipv6_config['address'], dict):
            addr_config = ipv6_config['address']
            
            if 'autoconf' in addr_config:
                self.generate(*ipv6_base, 'address', 'autoconf')
            
            if 'eui64' in addr_config:
                value = addr_config['eui64']
                if value:
                    self.generate(*ipv6_base, 'address', 'eui64', str(value))
            
            if 'interface-identifier' in addr_config:
                value = addr_config['interface-identifier']
                if value:
                    self.generate(*ipv6_base, 'address', 'interface-identifier', str(value))
            
            if 'no-default-link-local' in addr_config:
                self.generate(*ipv6_base, 'address', 'no-default-link-local')
        
        if 'adjust-mss' in ipv6_config:
            value = ipv6_config['adjust-mss']
            if value:
                self.generate(*ipv6_base, 'adjust-mss', str(value))
        
        if 'base-reachable-time' in ipv6_config:
            value = ipv6_config['base-reachable-time']
            if value:
                self.generate(*ipv6_base, 'base-reachable-time', str(value))
        
        if 'disable-forwarding' in ipv6_config:
            self.generate(*ipv6_base, 'disable-forwarding')
        
        if 'dup-addr-detect-transmits' in ipv6_config:
            value = ipv6_config['dup-addr-detect-transmits']
            if value is not None:
                self.generate(*ipv6_base, 'dup-addr-detect-transmits', str(value))
        
        if 'source-validation' in ipv6_config:
            value = ipv6_config['source-validation']
            if value:
                self.generate(*ipv6_base, 'source-validation', str(value))
