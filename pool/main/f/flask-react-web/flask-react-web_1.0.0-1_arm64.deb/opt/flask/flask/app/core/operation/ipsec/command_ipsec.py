from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
from app.core.utils.format_str import encode_description
import pprint
from copy import deepcopy
import json

def is_str_not_empty(value):
    return str(value).strip() not in ['', 'None']

def format_description(description: str) -> str:
    # return encode_description(description)
    return description

def is_sublist_in(main_list, sub_list):
    # Compare if sub_list is a sublist of main_list
    return tuple(sub_list) in tuple(main_list)

def _references_interface(config, name):
    
    for key, value in config.items():
        if key in {'vti', 'bind', 'interface', 'dhcp-interface', 'dhcp_interface'}:
            values = value if isinstance(value, (list, dict)) else [value]
            if name in values:
                return True
        if isinstance(value, dict) and _references_interface(value, name):
            return True
    return False

def remove_deleted_vti_psk_references(current_config, new_config, configured_vtis=None):
    
    config = deepcopy(new_config)
    removed_vtis = set()
    for section, kind, binding in (
        ('site-to-site', 'peer', 'vti'),
        ('remote-access', 'connection', 'bind'),
    ):
        remaining = config.get(section, {}).get(kind, {})
        for name, entry in current_config.get(section, {}).get(kind, {}).items():
            if name not in remaining:
                vti = entry.get(binding)
                vti_name = vti.get('bind') if isinstance(vti, dict) else vti
                if is_str_not_empty(vti_name):
                    removed_vtis.add(vti_name)

    references = deepcopy(config)
    for psk in references.get('authentication', {}).get('psk', {}).values():
        psk.pop('dhcp-interface', None)
        psk.pop('dhcp_interface', None)
    unused_vtis = {name for name in removed_vtis if not _references_interface(references, name)}

    for psk in config.get('authentication', {}).get('psk', {}).values():
        for key in ('dhcp-interface', 'dhcp_interface'):
            if key not in psk:
                continue
            value = psk[key]
            interfaces = list(value) if isinstance(value, (list, dict)) else [value]
            remaining = [name for name in interfaces if name not in unused_vtis and not (
                configured_vtis is not None and isinstance(name, str)
                and name.startswith('vti') and name not in configured_vtis
            )]
            if remaining:
                psk[key] = remaining if isinstance(value, (list, dict)) else remaining[0]
            else:
                del psk[key]
    return config

class IpsecCommand(IfaceCommand):
    """
    Command class for IPsec Interface:
    
- set/delete vpn ipsec site-to-site peer <peer-name> description <text>
- set/delete vpn ipsec site-to-site peer <peer-name> disable
- set/delete vpn ipsec site-to-site peer <peer-name> local-id <id-in-text>
- set/delete vpn ipsec site-to-site peer <peer-name> mode {pre-shared-secret | rsa | x509}
- set/delete vpn ipsec site-to-site peer <peer-name> remote-id <id-intext>
- set/delete vpn ipsec site-to-site peer <peer-name> rsa {}
- set/delete vpn ipsec site-to-site peer <peer-name> rsa local-key <key>
- set/delete vpn ipsec site-to-site peer <peer-name> rsa remote-key <key>
- set/delete vpn ipsec site-to-site peer <peer-name> use-x509-id 
- set/delete vpn ipsec site-to-site peer <peer-name> x509 ca-certificate <ca-cert>
- set/delete vpn ipsec site-to-site peer <peer-name> x509 certificate <cert>
- set/delete vpn ipsec site-to-site peer <peer-name>
- set/delete vpn ipsec site-to-site peer <peer-name> connection-type {initiate | respond | none}
- set/delete vpn ipsec site-to-site peer <peer-name> default-esp-group <grp-name>
- set/delete vpn ipsec site-to-site peer <peer-name> dhcp-interface <intf-name>
- set/delete vpn ipsec site-to-site peer <peer-name> force-udp-encapsulation
- set/delete vpn ipsec site-to-site peer <peer-name> ike-group <grp-name>
- set/delete vpn ipsec site-to-site peer <peer-name> esp-group <grp-name>
- set/delete vpn ipsec site-to-site peer <peer-name> ikev2-reauth {yes | no | inherit}
- set/delete vpn ipsec site-to-site peer <peer-name> local-address {any | IPv4 | IPv6}
- set/delete vpn ipsec site-to-site peer <peer-name>  remote-address {IPv4 | IPv6}
- set/delete vpn ipsec site-to-site peer <peer-name> replay-window <0 |<1-2040> >
- set/delete vpn ipsec site-to-site peer <peer-name> disable
- set/delete vpn ipsec site-to-site peer <peer-name> local prefix {x.x.x.x/x | h:h:h:h:h:h:h:h/x}
- set/delete vpn ipsec site-to-site peer <peer-name>  local port <1-65535>
- set/delete vpn ipsec site-to-site peer <peer-name> priority <1-100>
- set/delete vpn ipsec site-to-site peer <peer-name> protocol <protocol-name>
- set/delete vpn ipsec site-to-site peer <peer-name> remote
- set/delete vpn ipsec site-to-site peer <peer-name> virtual-address {IPv4 | IPv6}
- set/delete vpn ipsec site-to-site peer <peer-name> vti bind <intf-name>
- set/delete interfaces vti <interface-name> address <x.x.x.x/n | h:h:h:h::h:h:h:h/m>
- set/delete vpn ipsec site-to-site peer <peer-name> traffic-selector local prefix {IPv4 | IPv6}
- set/delete vpn ipsec site-to-site peer <peer-name> traffic-selector remote prefix {IPv4 | IPv6}
- set/delete vpn ipsec remote-access connection <conn-name> description <text>
- set/delete vpn ipsec remote-access connection <conn-name> disable 
- set/delete vpn ipsec remote-access connection <conn-name> 
- set/delete vpn ipsec remote-access connection <conn-name> bind <intf-name>
- set/delete vpn ipsec remote-access connection <conn-name> ike-group <grp-name>
- set/delete vpn ipsec remote-access connection <conn-name> esp-group <grp-name>
- set/delete vpn ipsec remote-access connection <conn-name>  local port <1-65535>
- set/delete vpn ipsec remote-access connection <conn-name>  local prefix {x.x.x.x/x | h:h:h:h:h:h:h:h/x >
- set/delete vpn ipsec remote-access connection <conn-name> local-address {any | x.x.x.x | h:h:h:h:h:h:h:h}
- set/delete vpn ipsec remote-access connection <conn-name> pool <pool-name>
- set/delete vpn ipsec remote-access connection <conn-name> pool dhcp
- set/delete vpn ipsec remote-access connection <conn-name> pool radius
- set/delete vpn ipsec remote-access connection <conn-name> replay-window <0 | 1-2040>
- set/delete vpn ipsec remote-access connection <conn-name> timeout <1-86400>
- set/delete vpn ipsec remote-access connection <conn-name> unique {never | keep | replace}
- set/delete vpn ipsec remote-access connection <conn-name>authentication client-mode <x509 | eap-tls |eap-mschapv2 |  eap-radius>
- set/delete vpn ipsec remote-access connection <conn-name>authentication eap-id <id-in-text>
- set/delete vpn ipsec remote-access connection <conn-name>authentication local-id <id-in-text>

- set/delete vpn ipsec remote-access connection <conn-name> authentication local-users username <name> disable
- set/delete vpn ipsec remote-access connection <conn-name> authentication local-users username <name>  password <passwd>
- set/delete vpn ipsec remote-access connection <conn-name> authentication pre-shared-secret <secret>
- set/delete vpn ipsec remote-access connection <conn-name> authentication server-mode {pre-shared-secret | x509}
- set/delete vpn ipsec remote-access connection <conn-name> authentication ca-certificate <ca-name>
- set/delete vpn ipsec remote-access connection <conn-name> authentication certificate <cert-name>
- set/delete vpn ipsec remote-access dhcp interface <intf-name>
- set/delete vpn ipsec remote-access dhcp server <IPv4-address>
- set/delete vpn ipsec remote-access pool <pool-name> exclude <x.x.x.x/n | h:h::h/n>
- set/delete vpn ipsec remote-access pool <pool-name> name-server <IPv4 | IPv6>
- set/delete vpn ipsec remote-access pool <pool-name> prefix <x.x.x.x/n | h:h::h/n>
- set/delete vpn ipsec remote-access pool <pool-name> range start <IPv4 | IPv6>
- set/delete vpn ipsec remote-access pool <pool-name> range stop <IPv4 | IPv6>
- set/delete vpn ipsec remote-access radius server 2.2.2.2 nas-identifier <text>
- set/delete vpn ipsec remote-access radius timeout <1-240>
- set/delete vpn ipsec remote-access radius server 2.2.2.2
- set/delete vpn ipsec remote-access radius server 2.2.2.2 disable
- set/delete vpn ipsec remote-access radius server 2.2.2.2 disable-accounting
- set/delete vpn ipsec remote-access radius server 2.2.2.2 port <port-num>

- set/delete vpn ipsec options interface <intf-name>
- set/delete vpn ipsec options disable-route-autoinstall
- set/delete vpn ipsec options flexvpn
- set/delete vpn ipsec options virtual-ip
- set/delete vpn ipsec options retransmission attempt <1-65535>
- set/delete vpn ipsec options retransmission base <1.0-5.0>
- set/delete vpn ipsec options retransmission timeout <1-1000>
- set/delete vpn ipsec authentication psk <pre-shared-key-name> id <id-value>
- set/delete vpn ipsec authentication psk <pre-shared-key-name> dhcp-interface <intf-name>
- set/delete vpn ipsec authentication psk <pre-shared-key-name> secret <secret>
- set/delete vpn ipsec authentication psk <pre-shared-key-name> secret-type <plaintext | base64>
- set/delete vpn ipsec ike-group <ike-group-name> close-action {none | trap | start}
- set/delete vpn ipsec ike-group <ike-group-name> action {trap | clear | restart}
- set/delete vpn ipsec ike-group <ike-group-name> interval <2-86400>
- set/delete vpn ipsec ike-group <ike-group-name> timeout <2-86400>
- set/delete vpn ipsec ike-group <ike-group-name> disable-mobike
- set/delete vpn ipsec ike-group <ike-group-name> ikev2-reauth
- set/delete vpn ipsec ike-group <ike-group-name> key-exchange {ikev1 | ikev2}
- set/delete vpn ipsec ike-group <ike-group-name> lifetime <0-86400>
- set/delete vpn ipsec ike-group <ike-group-name> mode { main |aggressive }
- set/delete vpn ipsec ike-group <ike-group-name> proposal <prop-number> dh-group <grp-number>
- set/delete vpn ipsec ike-group <ike-group-name> proposal <prop-number> encryption <encryption-type>
- set/delete vpn ipsec ike-group <ike-group-name> proposal <prop-number> hash <hash-type>
- set/delete vpn ipsec ike-group <ike-group-name> proposal <prop-number> prf <prf-type>
- set/delete vpn ipsec esp-group <esp-grp-name> compression
- set/delete vpn ipsec esp-group <esp-grp-name> disable-rekey
- set/delete vpn ipsec esp-group <esp-grp-name> life-bytes <1024-26843545600000>
- set/delete vpn ipsec esp-group <esp-grp-name> life-packets <1000-26843545600000>
- set/delete vpn ipsec esp-group <esp-grp-name> lifetime <30-86400>
- set/delete vpn ipsec esp-group <esp-grp-name> mode {tunnel | transport}
- set/delete vpn ipsec esp-group <esp-grp-name> pfs <pfs-type>
- set/delete vpn ipsec esp-group <esp-grp-name> proposal <prop-number> encryption <encryption-type>
- set/delete vpn ipsec esp-group <esp-grp-name> proposal <prop-number> hash <hash-type>

    """
    # LOGIC TO MAP IPSec TO VTI:
    # operator is set and no (vti/bind) in config, then create new vti with current vti (number + 1)
    # operator is delete and deleted_config[interface] = current_config[interface], then generate default commands
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            self.base_vti = kwargs.get('base_vti', None)
            self.current_vti = kwargs.get('base_vti', None)
            self._mode = kwargs.get('mode', 'UPDATE') # _mode: CREATE or UPDATE

            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'ipsec'),
                name=self.name
            )
            self.attributes = {
                'vpn': {
                    'ipsec': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing IPsec command: {e}")

    def next_vti(self):
        if not self.current_vti:
            self.current_vti = "vti0"
            return self.current_vti
        try:
            current_num = int(self.current_vti.replace('vti', ''))
        except (ValueError, AttributeError):
            self.current_vti = "vti0"
            return self.current_vti

        new_num = current_num + 1
        self.current_vti = f"vti{new_num}"
        return self.current_vti
    
    def _build_command(self, *path_elements: str) -> str:
        command = {
            "op": self.operator,
            "path": list(path_elements)
        }
        return json.dumps(command)

    def generate(self, *args):
        # In create mode (modal), DO NOT generate delete commands if commands are not esp-group/ike-group
        if self._mode == 'CREATE' and self.operator == 'delete' and \
            is_sublist_in(list(args), ['vpn', 'ipsec', 'esp-group']) is False and \
                is_sublist_in(list(args), ['vpn', 'ipsec', 'ike-group']) is False:
            return
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []
        
        curr_config = deepcopy(current_config) if current_config else deepcopy(data)
        
        self.attributes['vpn']['ipsec'] = data
        # Process ike-group and esp-group then connections
        if 'ike-group' in data:
            self._process_ike_group_config(data['ike-group'], current_config, new_config)
        
        if 'esp-group' in data:
            self._process_esp_group_config(data['esp-group'], current_config, new_config)
        
        if 'site-to-site' in data:
            self._process_site_to_site_config(data['site-to-site'], current_config, new_config)
        
        if 'remote-access' in data:
            self._process_remote_access_config(data['remote-access'], current_config, new_config)
        
        if 'options' in data:
            self._process_options_config(data['options'])
        
        if 'authentication' in data:
            self._process_authentication_config(data['authentication'], current_config, new_config)
        
        if 'interface' in data:
            interfaces = data['interface']
            if isinstance(interfaces, list):
                for intf in interfaces:
                    if is_str_not_empty(intf):
                        self.generate('vpn', 'ipsec', 'interface', intf)
            elif is_str_not_empty(interfaces):
                self.generate('vpn', 'ipsec', 'interface', interfaces)
        
        if 'disable-uniqreqids' in data:
            self.generate('vpn', 'ipsec', 'disable-uniqreqids')
        
        print(f"Generated IPSec commands: {self.cmds}")
        return self.cmds

    def _process_site_to_site_config(self, site_to_site_config, current_config, new_config):
        """Process site-to-site peer configurations"""
        if 'peer' not in site_to_site_config:
            return

        vti_base_path = ['interfaces', 'vti']
        
        for peer_name, peer_config in site_to_site_config['peer'].items():
            base_path = ['vpn', 'ipsec', 'site-to-site', 'peer', peer_name]

            if self.operator == 'delete' and peer_name not in new_config.get('site-to-site', {}).get('peer', {}):
                self.generate(*base_path)
                current_peer = current_config.get('site-to-site', {}).get('peer', {}).get(peer_name, {})
                vti = current_peer.get('vti')
                vti_name = vti.get('bind') if isinstance(vti, dict) else vti
                if is_str_not_empty(vti_name) and not _references_interface(new_config, vti_name):
                    self.generate(*vti_base_path, vti_name)
                continue

            if 'description' in peer_config and is_str_not_empty(peer_config['description']):
                self.generate(*base_path, 'description', format_description(peer_config['description']))
            
            if 'disable' in peer_config:
                self.generate(*base_path, 'disable')
            
            if 'connection-type' in peer_config and is_str_not_empty(peer_config['connection-type']):
                self.generate(*base_path, 'connection-type', peer_config['connection-type'])
            
            if 'default-esp-group' in peer_config and is_str_not_empty(peer_config['default-esp-group']):
                self.generate(*base_path, 'default-esp-group', peer_config['default-esp-group'])
            
            if 'dhcp-interface' in peer_config and is_str_not_empty(peer_config['dhcp-interface']):
                self.generate(*base_path, 'dhcp-interface', peer_config['dhcp-interface'])
            
            if 'force-udp-encapsulation' in peer_config:
                self.generate(*base_path, 'force-udp-encapsulation')
            
            if 'ike-group' in peer_config and is_str_not_empty(peer_config['ike-group']):
                self.generate(*base_path, 'ike-group', peer_config['ike-group'])
            
            if 'esp-group' in peer_config and is_str_not_empty(peer_config['esp-group']):
                self.generate(*base_path, 'vti', 'esp-group', peer_config['esp-group'])
            
            if 'ikev2-reauth' in peer_config and is_str_not_empty(peer_config['ikev2-reauth']):
                self.generate(*base_path, 'ikev2-reauth', peer_config['ikev2-reauth'])
            
            if 'local-address' in peer_config and is_str_not_empty(peer_config['local-address']):
                self.generate(*base_path, 'local-address', peer_config['local-address'])
            
            if 'remote-address' in peer_config:
                remote_addresses = peer_config.get('remote-address')

                if isinstance(remote_addresses, list):
                    remote_addresses = [addr for addr in remote_addresses if is_str_not_empty(addr)]
                elif isinstance(remote_addresses, str) and is_str_not_empty(remote_addresses):
                    remote_addresses = [remote_addresses]
                else:
                    remote_addresses = []

                if remote_addresses:
                    for remote_addr in remote_addresses:
                        self.generate(*base_path, 'remote-address', remote_addr)
            
            if 'replay-window' in peer_config and is_str_not_empty(peer_config['replay-window']):
                self.generate(*base_path, 'replay-window', peer_config['replay-window'])
            
            if 'virtual-address' in peer_config:
                if isinstance(peer_config['virtual-address'], list):
                    for virtual_addr in peer_config['virtual-address']:
                        if is_str_not_empty(virtual_addr):
                            self.generate(*base_path, 'virtual-address', virtual_addr)
                elif is_str_not_empty(peer_config['virtual-address']):
                    self.generate(*base_path, 'virtual-address', peer_config['virtual-address'])
            
            if self.operator == 'set':
                vti_bind = None
                vti_address = None
                if isinstance(peer_config.get('vti'), dict):
                    vti_bind = peer_config['vti'].get('bind')
                    vti_address = peer_config['vti'].get('address')
                elif is_str_not_empty(peer_config.get('vti')):
                    vti_bind = peer_config.get('vti')

                current_peer = current_config.get('site-to-site', {}).get('peer', {}).get(peer_name, {})
                current_vti = current_peer.get('vti') if isinstance(current_peer, dict) else {}
                if is_str_not_empty(vti_bind):
                    self.generate(*vti_base_path, vti_bind)
                    self.generate(*base_path, 'vti', 'bind', vti_bind)
                    if is_str_not_empty(vti_address):
                        self.generate(*vti_base_path, vti_bind, 'address', vti_address)
                elif peer_name not in current_config.get('site-to-site', {}).get('peer', {}):
                    # Assign VTI to new peer
                    _next_vti = self.next_vti()
                    self.generate(*vti_base_path, _next_vti)
                    self.generate(*base_path, 'vti', 'bind', _next_vti)
                    if is_str_not_empty(vti_address):
                        self.generate(*vti_base_path, _next_vti, 'address', vti_address)
                elif is_str_not_empty(vti_address):
                    current_bind = current_vti.get('bind') if isinstance(current_vti, dict) else current_vti
                    if is_str_not_empty(current_bind):
                        self.generate(*vti_base_path, current_bind, 'address', vti_address)

            if self.operator == 'delete' and isinstance(peer_config.get('vti'), dict):
                vti_address = peer_config['vti'].get('address')
                current_peer = current_config.get('site-to-site', {}).get('peer', {}).get(peer_name, {})
                current_vti = current_peer.get('vti') if isinstance(current_peer, dict) else {}
                vti_bind = current_vti.get('bind') if isinstance(current_vti, dict) else current_vti
                if is_str_not_empty(vti_bind) and is_str_not_empty(vti_address):
                    self.generate(*vti_base_path, vti_bind, 'address', vti_address)

            if isinstance(peer_config.get('vti'), dict):
                vti = peer_config['vti']
                if 'esp-group' in vti and is_str_not_empty(vti['esp-group']):
                    self.generate(*base_path, 'vti', 'esp-group', vti['esp-group'])
                if 'traffic-selector' in vti:
                    self._process_traffic_selector_config(base_path, vti['traffic-selector'])

            if 'traffic-selector' in peer_config:
                self._process_traffic_selector_config(base_path, peer_config['traffic-selector'])
            
            if 'tunnel' in peer_config:
                self._process_peer_tunnel_config(base_path, peer_config['tunnel'], current_config, new_config)

            if 'authentication' in peer_config:
                self._process_peer_authentication(base_path, peer_config['authentication'])
    

    def _process_peer_tunnel_config(self, base_path, tunnel_config, current_config, new_config):
        """Process tunnel configuration for site-to-site peers"""
        for tunnel_id, tunnel_data in tunnel_config.items():
            tunnel_path = base_path + ['tunnel', tunnel_id]

            if self.operator == 'delete' and \
                tunnel_id not in new_config.get('site-to-site', {}).get('peer', {}).get(base_path[-1], {}).get('tunnel', {}):
                self.generate(*tunnel_path)
                continue
            
            if 'esp-group' in tunnel_data and is_str_not_empty(tunnel_data['esp-group']):
                self.generate(*tunnel_path, 'esp-group', tunnel_data['esp-group'])
            
            if 'local' in tunnel_data:
                local_config = tunnel_data['local']
                if 'prefix' in local_config:
                    if isinstance(local_config['prefix'], list):
                        for prefix in local_config['prefix']:
                            self.generate(*tunnel_path, 'local', 'prefix', prefix)
                    else:
                        self.generate(*tunnel_path, 'local', 'prefix', local_config['prefix'])
                
                if 'port' in local_config and is_str_not_empty(local_config['port']):
                    self.generate(*tunnel_path, 'local', 'port', local_config['port'])
            
            if 'remote' in tunnel_data:
                remote_config = tunnel_data['remote']
                if 'prefix' in remote_config:
                    if isinstance(remote_config['prefix'], list):
                        for prefix in remote_config['prefix']:
                            self.generate(*tunnel_path, 'remote', 'prefix', prefix)
                    else:
                        self.generate(*tunnel_path, 'remote', 'prefix', remote_config['prefix'])
                
                if 'port' in remote_config and is_str_not_empty(remote_config['port']):
                    self.generate(*tunnel_path, 'remote', 'port', remote_config['port'])
            
            if 'priority' in tunnel_data and is_str_not_empty(tunnel_data['priority']):
                self.generate(*tunnel_path, 'priority', tunnel_data['priority'])
            
            if 'protocol' in tunnel_data and is_str_not_empty(tunnel_data['protocol']):
                self.generate(*tunnel_path, 'protocol', tunnel_data['protocol'])
    
    def _process_traffic_selector_config(self, base_path, traffic_selector_config):
        """Process traffic-selector configuration for site-to-site peers"""
        ts_path = base_path + ['vti', 'traffic-selector']
        
        if 'local' in traffic_selector_config and 'prefix' in traffic_selector_config['local']:
            local_prefixes = traffic_selector_config['local']['prefix']
            if isinstance(local_prefixes, list):
                for prefix in local_prefixes:
                    if is_str_not_empty(prefix):
                        self.generate(*ts_path, 'local', 'prefix', prefix)
            elif is_str_not_empty(local_prefixes):
                self.generate(*ts_path, 'local', 'prefix', local_prefixes)
        
        if 'remote' in traffic_selector_config and 'prefix' in traffic_selector_config['remote']:
            remote_prefixes = traffic_selector_config['remote']['prefix']
            if isinstance(remote_prefixes, list):
                for prefix in remote_prefixes:
                    if is_str_not_empty(prefix):
                        self.generate(*ts_path, 'remote', 'prefix', prefix)
            elif is_str_not_empty(remote_prefixes):
                self.generate(*ts_path, 'remote', 'prefix', remote_prefixes)
    
    def _process_remote_access_config(self, remote_access_config, current_config, new_config):
        """Process remote-access configurations"""
        if 'connection' in remote_access_config:
            self._process_remote_access_connections(remote_access_config['connection'], current_config, new_config)
        
        if 'dhcp' in remote_access_config:
            self._process_remote_access_dhcp(remote_access_config['dhcp'])
        
        if 'pool' in remote_access_config:
            self._process_remote_access_pools(remote_access_config['pool'], current_config, new_config)
        
        if 'radius' in remote_access_config:
            self._process_remote_access_radius(remote_access_config['radius'], new_config)
    
    def _process_remote_access_connections(self, connections_config, current_config, new_config):
        """Process remote-access connection configurations"""
        
        vti_base_path = ['interfaces', 'vti']

        for conn_name, conn_config in connections_config.items():
            base_path = ['vpn', 'ipsec', 'remote-access', 'connection', conn_name]

            if self.operator == 'delete' and conn_name not in new_config.get('remote-access', {}).get('connection', {}):
                self.generate(*base_path)
                current_conn = current_config.get('remote-access', {}).get('connection', {}).get(conn_name, {})
                vti_name = current_conn.get('bind')
                if is_str_not_empty(vti_name) and not _references_interface(new_config, vti_name):
                    self.generate(*vti_base_path, vti_name)
                continue
            
            if 'description' in conn_config and is_str_not_empty(conn_config['description']):
                self.generate(*base_path, 'description', format_description(conn_config['description']))
            
            if 'disable' in conn_config:
                self.generate(*base_path, 'disable')
            
            # if 'bind' in conn_config and is_str_not_empty(conn_config['bind']):
            #     self.generate(*base_path, 'bind', conn_config['bind'])

            if self.operator == 'set':
                vti_bind = conn_config.get('bind') or current_config.get('remote-access', {}).get('connection', {}).get(conn_name, {}).get('bind')
                vti_address = conn_config.get('vti-address')
                if is_str_not_empty(vti_bind):
                    self.generate(*vti_base_path, vti_bind)
                    self.generate(*base_path, 'bind', vti_bind)
                    if is_str_not_empty(vti_address):
                        self.generate(*vti_base_path, vti_bind, 'address', vti_address)
                elif conn_name not in current_config.get('remote-access', {}).get('connection', {}):
                    _next_vti = self.next_vti()
                    self.generate(*vti_base_path, _next_vti)
                    self.generate(*base_path, 'bind', _next_vti)
                    if is_str_not_empty(vti_address):
                        self.generate(*vti_base_path, _next_vti, 'address', vti_address)

            if self.operator == 'delete' and 'vti-address' in conn_config:
                current_conn = current_config.get('remote-access', {}).get('connection', {}).get(conn_name, {})
                vti_bind = current_conn.get('bind')
                if is_str_not_empty(vti_bind) and is_str_not_empty(conn_config.get('vti-address')):
                    self.generate(*vti_base_path, vti_bind, 'address', conn_config['vti-address'])

            if 'ike-group' in conn_config and is_str_not_empty(conn_config['ike-group']):
                self.generate(*base_path, 'ike-group', conn_config['ike-group'])
            
            if 'esp-group' in conn_config and is_str_not_empty(conn_config['esp-group']):
                self.generate(*base_path, 'esp-group', conn_config['esp-group'])
            
            if 'local-address' in conn_config and is_str_not_empty(conn_config['local-address']):
                self.generate(*base_path, 'local-address', conn_config['local-address'])

            if 'dhcp-interface' in conn_config and is_str_not_empty(conn_config['dhcp-interface']):
                self.generate(*base_path, 'dhcp-interface', conn_config['dhcp-interface'])
            
            if 'pool' in conn_config:
                pool_config = conn_config['pool']
                if isinstance(pool_config, str) and is_str_not_empty(pool_config):
                    self.generate(*base_path, 'pool', pool_config)
                elif isinstance(pool_config, dict):
                    if 'dhcp' in pool_config:
                        self.generate(*base_path, 'pool', 'dhcp')
                    if 'radius' in pool_config:
                        self.generate(*base_path, 'pool', 'radius')
            
            if 'replay-window' in conn_config and is_str_not_empty(conn_config['replay-window']):
                self.generate(*base_path, 'replay-window', conn_config['replay-window'])
            
            if 'timeout' in conn_config and is_str_not_empty(conn_config['timeout']):
                self.generate(*base_path, 'timeout', conn_config['timeout'])
            
            if 'unique' in conn_config and is_str_not_empty(conn_config['unique']):
                self.generate(*base_path, 'unique', conn_config['unique'])
            
            if 'local' in conn_config:
                local_config = conn_config['local']
                if 'port' in local_config and is_str_not_empty(local_config['port']):
                    self.generate(*base_path, 'local', 'port', local_config['port'])
                if 'prefix' in local_config:
                    if isinstance(local_config['prefix'], list):
                        for prefix in local_config['prefix']:
                            self.generate(*base_path, 'local', 'prefix', prefix)
                    else:
                        self.generate(*base_path, 'local', 'prefix', local_config['prefix'])
                if 'address' in local_config and is_str_not_empty(local_config['address']):
                    self.generate(*base_path, 'local-address', local_config['address'])
            
            if 'authentication' in conn_config:
                self._process_connection_authentication(base_path, conn_config['authentication'])
    
    def _process_connection_authentication(self, base_path, auth_config):
        """Process authentication configuration for remote-access connections"""
        auth_path = base_path + ['authentication']
        
        if 'client-mode' in auth_config and is_str_not_empty(auth_config['client-mode']):
            self.generate(*auth_path, 'client-mode', auth_config['client-mode'])
        
        if 'eap-id' in auth_config and is_str_not_empty(auth_config['eap-id']):
            self.generate(*auth_path, 'eap-id', auth_config['eap-id'])
        
        if 'local-id' in auth_config and is_str_not_empty(auth_config['local-id']):
            self.generate(*auth_path, 'local-id', auth_config['local-id'])
        
        if 'pre-shared-secret' in auth_config and is_str_not_empty(auth_config['pre-shared-secret']):
            self.generate(*auth_path, 'pre-shared-secret', auth_config['pre-shared-secret'])
        
        if 'server-mode' in auth_config and is_str_not_empty(auth_config['server-mode']):
            self.generate(*auth_path, 'server-mode', auth_config['server-mode'])
        
        if 'ca-certificate' in auth_config and is_str_not_empty(auth_config['ca-certificate']):
            self.generate(*auth_path, 'ca-certificate', auth_config['ca-certificate'])
        
        if 'certificate' in auth_config and is_str_not_empty(auth_config['certificate']):
            self.generate(*auth_path, 'certificate', auth_config['certificate'])
        
        if 'x509' in auth_config:
            if 'certificate' in auth_config['x509']:
                self.generate(*auth_path, 'x509', 'certificate', auth_config['x509']['certificate'])
            if 'ca-certificate' in auth_config['x509']:
                if isinstance(auth_config['x509']['ca-certificate'], list):
                    for ca_cert in auth_config['x509']['ca-certificate']:
                        if is_str_not_empty(ca_cert):
                            self.generate(*auth_path, 'x509', 'ca-certificate', ca_cert)
                elif isinstance(auth_config['x509']['ca-certificate'], str):
                    if is_str_not_empty(auth_config['x509']['ca-certificate']):
                        self.generate(*auth_path, 'x509', 'ca-certificate', auth_config['x509']['ca-certificate'])
        
        if 'local-users' in auth_config:
            for username, user_config in auth_config['local-users'].items():
                user_path = auth_path + ['local-users', 'username', username]
                
                if 'disable' in user_config:
                    self.generate(*user_path, 'disable')
                
                if 'password' in user_config and is_str_not_empty(user_config['password']):
                    self.generate(*user_path, 'password', user_config['password'])
    
    def _process_peer_authentication(self, base_path, auth_config):
        """Process authentication configuration for remote-access connections"""
        auth_path = base_path + ['authentication']
        
        if 'local-id' in auth_config and is_str_not_empty(auth_config['local-id']):
                self.generate(*auth_path, 'local-id', auth_config['local-id'])
            
        if 'mode' in auth_config and is_str_not_empty(auth_config['mode']):
            self.generate(*auth_path, 'mode', auth_config['mode'])
        
        if 'remote-id' in auth_config and is_str_not_empty(auth_config['remote-id']):
            self.generate(*auth_path, 'remote-id', auth_config['remote-id'])
        
        if 'rsa' in auth_config and isinstance(auth_config['rsa'], dict):
            rsa_config = auth_config['rsa']
            if 'local-key' in rsa_config and is_str_not_empty(rsa_config['local-key']):
                self.generate(*auth_path, 'rsa', 'local-key', rsa_config['local-key'])
            if 'remote-key' in rsa_config and is_str_not_empty(rsa_config['remote-key']):
                self.generate(*auth_path, 'rsa', 'remote-key', rsa_config['remote-key'])
        
        if 'use-x509-id' in auth_config:
            self.generate(*auth_path, 'use-x509-id')
        
        if 'x509' in auth_config and isinstance(auth_config['x509'], dict):
            x509_config = auth_config['x509']
            if 'ca-certificate' in x509_config and is_str_not_empty(x509_config['ca-certificate']):
                if isinstance(x509_config['ca-certificate'], list):
                    for ca_cert in x509_config['ca-certificate']:
                        if is_str_not_empty(ca_cert):
                            self.generate(*auth_path, 'x509', 'ca-certificate', ca_cert)
                elif isinstance(x509_config['ca-certificate'], str):
                    self.generate(*auth_path, 'x509', 'ca-certificate', x509_config['ca-certificate'])
            if 'certificate' in x509_config and is_str_not_empty(x509_config['certificate']):
                self.generate(*auth_path, 'x509', 'certificate', x509_config['certificate'])
    
    def _process_remote_access_dhcp(self, dhcp_config):
        """Process remote-access DHCP configuration"""
        base_path = ['vpn', 'ipsec', 'remote-access', 'dhcp']
        
        if 'interface' in dhcp_config and is_str_not_empty(dhcp_config['interface']):
            self.generate(*base_path, 'interface', dhcp_config['interface'])
        
        if 'server' in dhcp_config and is_str_not_empty(dhcp_config['server']):
            self.generate(*base_path, 'server', dhcp_config['server'])
    
    def _process_remote_access_pools(self, pools_config, current_config, new_config):
        """Process remote-access pool configurations"""
        for pool_name, pool_config in pools_config.items():
            base_path = ['vpn', 'ipsec', 'remote-access', 'pool', pool_name]
            
            if self.operator == 'delete' and pool_name not in new_config.get('remote-access', {}).get('pool', {}):
                self.generate(*base_path)
                continue
            
            if 'exclude' in pool_config:
                if isinstance(pool_config['exclude'], list):
                    for exclude in pool_config['exclude']:
                        self.generate(*base_path, 'exclude', exclude)
                else:
                    self.generate(*base_path, 'exclude', pool_config['exclude'])
            
            if 'name-server' in pool_config:
                if isinstance(pool_config['name-server'], list):
                    for ns in pool_config['name-server']:
                        self.generate(*base_path, 'name-server', ns)
                else:
                    self.generate(*base_path, 'name-server', pool_config['name-server'])
            
            if 'prefix' in pool_config and is_str_not_empty(pool_config['prefix']):
                self.generate(*base_path, 'prefix', pool_config['prefix'])
            
            if 'range' in pool_config:
                range_config = pool_config['range']
                if 'start' in range_config and is_str_not_empty(range_config['start']):
                    self.generate(*base_path, 'range', 'start', range_config['start'])
                if 'stop' in range_config and is_str_not_empty(range_config['stop']):
                    self.generate(*base_path, 'range', 'stop', range_config['stop'])
    
    def _process_remote_access_radius(self, radius_config, new_config):
        """Process remote-access RADIUS configuration"""
        base_path = ['vpn', 'ipsec', 'remote-access', 'radius']
        
        if 'timeout' in radius_config and is_str_not_empty(radius_config['timeout']):
            self.generate(*base_path, 'timeout', radius_config['timeout'])
        
        if 'server' in radius_config:
            for server_ip, server_config in radius_config['server'].items():
                server_path = base_path + ['server', server_ip]
                remaining_servers = (new_config or {}).get('remote-access', {}).get('radius', {}).get('server', {})
                if self.operator == 'delete' and server_ip not in remaining_servers:
                    self.generate(*server_path)
                    continue
                
                if 'nas-identifier' in server_config and is_str_not_empty(server_config['nas-identifier']):
                    self.generate(*server_path, 'nas-identifier', server_config['nas-identifier'])
                
                if 'disable' in server_config:
                    self.generate(*server_path, 'disable')
                
                if 'disable-accounting' in server_config:
                    self.generate(*server_path, 'disable-accounting')
                
                if 'port' in server_config and is_str_not_empty(server_config['port']):
                    self.generate(*server_path, 'port', server_config['port'])
                
                if 'key' in server_config and is_str_not_empty(server_config['key']):
                    self.generate(*server_path, 'key', server_config['key'])
    
    def _process_options_config(self, options_config):
        """Process IPSec options configuration"""
        base_path = ['vpn', 'ipsec', 'options']
        
        # Note: interface is set globally (vpn ipsec interface), not in options
        # if 'interface' in options_config and is_str_not_empty(options_config['interface']):
        #     self.generate(*base_path, 'interface', options_config['interface'])
        
        if 'disable-route-autoinstall' in options_config:
            self.generate(*base_path, 'disable-route-autoinstall')
        
        if 'flexvpn' in options_config:
            self.generate(*base_path, 'flexvpn')
        
        if 'virtual-ip' in options_config:
            self.generate(*base_path, 'virtual-ip')
        
        if 'retransmission' in options_config:
            retrans_config = options_config['retransmission']
            retrans_path = base_path + ['retransmission']
            
            if 'attempt' in retrans_config and is_str_not_empty(retrans_config['attempt']):
                self.generate(*retrans_path, 'attempts', retrans_config['attempt'])
            
            if 'base' in retrans_config and is_str_not_empty(retrans_config['base']):
                self.generate(*retrans_path, 'base', retrans_config['base'])
            
            if 'timeout' in retrans_config and is_str_not_empty(retrans_config['timeout']):
                self.generate(*retrans_path, 'timeout', retrans_config['timeout'])
    
    def _process_authentication_config(self, auth_config, current_config, new_config):
        """Process IPSec authentication configuration"""
        if 'psk' in auth_config:
            for psk_name, psk_config in auth_config['psk'].items():
                base_path = ['vpn', 'ipsec', 'authentication', 'psk', psk_name]
                
                if self.operator == 'delete' and psk_name not in new_config.get('authentication', {}).get('psk', {}):
                    self.generate(*base_path)
                    continue
                
                if 'id' in psk_config:
                    ids = psk_config['id'] if isinstance(psk_config['id'], list) else [psk_config['id']]
                    for psk_id in ids:
                        if is_str_not_empty(psk_id):
                            self.generate(*base_path, 'id', psk_id)

                if 'dhcp-interface' in psk_config:
                    dhcp_interfaces = psk_config['dhcp-interface'] if isinstance(psk_config['dhcp-interface'], list) else [psk_config['dhcp-interface']]
                    for intf in dhcp_interfaces:
                        if is_str_not_empty(intf):
                            self.generate(*base_path, 'dhcp-interface', intf)
                
                if 'secret' in psk_config and is_str_not_empty(psk_config['secret']):
                    self.generate(*base_path, 'secret', psk_config['secret'])
                
                if 'secret-type' in psk_config and is_str_not_empty(psk_config['secret-type']):
                    self.generate(*base_path, 'secret-type', psk_config['secret-type'])
    
    def _process_ike_group_config(self, ike_groups_config, current_config, new_config):
        """Process IKE group configurations"""
        for group_name, group_config in ike_groups_config.items():
            base_path = ['vpn', 'ipsec', 'ike-group', group_name]

            if self.operator == 'delete' and group_name not in new_config.get('ike-group', {}):
                self.generate(*base_path)
                continue

            if self.operator == 'set' and not group_config:
                self.generate(*base_path)
                continue
            
            if 'close-action' in group_config and is_str_not_empty(group_config['close-action']):
                self.generate(*base_path, 'close-action', group_config['close-action'])
            
            if 'dead-peer-detection' in group_config:
                dpd_config = group_config['dead-peer-detection']
                dpd_path = base_path + ['dead-peer-detection']
                
                if 'action' in dpd_config and is_str_not_empty(dpd_config['action']):
                    self.generate(*dpd_path, 'action', dpd_config['action'])
                
                if 'interval' in dpd_config and is_str_not_empty(dpd_config['interval']):
                    self.generate(*dpd_path, 'interval', dpd_config['interval'])
                
                if 'timeout' in dpd_config and is_str_not_empty(dpd_config['timeout']):
                    self.generate(*dpd_path, 'timeout', dpd_config['timeout'])
            
            if 'disable-mobike' in group_config:
                self.generate(*base_path, 'disable-mobike')
            
            if 'ikev2-reauth' in group_config:
                val = group_config.get('ikev2-reauth')
                if isinstance(val, str) and is_str_not_empty(val):
                    self.generate(*base_path, 'ikev2-reauth', val)
                else:
                    self.generate(*base_path, 'ikev2-reauth')

            if 'key-exchange' in group_config and is_str_not_empty(group_config['key-exchange']):
                self.generate(*base_path, 'key-exchange', group_config['key-exchange'])
            
            if 'lifetime' in group_config and is_str_not_empty(group_config['lifetime']):
                self.generate(*base_path, 'lifetime', group_config['lifetime'])
            
            if 'mode' in group_config and is_str_not_empty(group_config['mode']):
                self.generate(*base_path, 'mode', group_config['mode'])
            
            if 'proposal' in group_config:
                for prop_num, prop_config in group_config['proposal'].items():
                    prop_path = base_path + ['proposal', prop_num]
                    
                    if 'dh-group' in prop_config and is_str_not_empty(prop_config['dh-group']):
                        self.generate(*prop_path, 'dh-group', prop_config['dh-group'])
                    
                    if 'encryption' in prop_config and is_str_not_empty(prop_config['encryption']):
                        self.generate(*prop_path, 'encryption', prop_config['encryption'])
                    
                    if 'hash' in prop_config and is_str_not_empty(prop_config['hash']):
                        self.generate(*prop_path, 'hash', prop_config['hash'])
                    
                    if 'prf' in prop_config and is_str_not_empty(prop_config['prf']):
                        self.generate(*prop_path, 'prf', prop_config['prf'])
    
    def _process_esp_group_config(self, esp_groups_config, current_config, new_config):
        """Process ESP group configurations"""
        for group_name, group_config in esp_groups_config.items():
            base_path = ['vpn', 'ipsec', 'esp-group', group_name]

            if self.operator == 'delete' and group_name not in new_config.get('esp-group', {}):
                self.generate(*base_path)
                continue

            if self.operator == 'set' and not group_config:
                self.generate(*base_path)
                continue
            
            if 'compression' in group_config:
                self.generate(*base_path, 'compression')
            
            if 'disable-rekey' in group_config:
                self.generate(*base_path, 'disable-rekey')
            
            if 'life-bytes' in group_config and is_str_not_empty(group_config['life-bytes']):
                self.generate(*base_path, 'life-bytes', group_config['life-bytes'])
            
            if 'life-packets' in group_config and is_str_not_empty(group_config['life-packets']):
                self.generate(*base_path, 'life-packets', group_config['life-packets'])
            
            if 'lifetime' in group_config and is_str_not_empty(group_config['lifetime']):
                self.generate(*base_path, 'lifetime', group_config['lifetime'])
            
            if 'mode' in group_config and is_str_not_empty(group_config['mode']):
                self.generate(*base_path, 'mode', group_config['mode'])
            
            if 'pfs' in group_config and is_str_not_empty(group_config['pfs']):
                self.generate(*base_path, 'pfs', group_config['pfs'])
            
            if 'proposal' in group_config:
                for prop_num, prop_config in group_config['proposal'].items():
                    prop_path = base_path + ['proposal', prop_num]
                    
                    if 'encryption' in prop_config and is_str_not_empty(prop_config['encryption']):
                        self.generate(*prop_path, 'encryption', prop_config['encryption'])
                    
                    if 'hash' in prop_config and is_str_not_empty(prop_config['hash']):
                        self.generate(*prop_path, 'hash', prop_config['hash'])

if __name__ == "__main__":
    pass
