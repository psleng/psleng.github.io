from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import relationship

from app.core.network.lldp.config import PROTOCOLS, parse_config
from app.db.database import db


class LLDPConfig(db.Model):
    __tablename__ = 'vyos_config_lldp'

    id = Column(Integer, primary_key=True)
    cdp = Column(Boolean, nullable=False, default=False)
    edp = Column(Boolean, nullable=False, default=False)
    fdp = Column(Boolean, nullable=False, default=False)
    sonmp = Column(Boolean, nullable=False, default=False)
    snmp = Column(Boolean, nullable=False, default=False)

    management_addresses = relationship(
        'LLDPManagementAddress', back_populates='config', cascade='all, delete-orphan',
        order_by='LLDPManagementAddress.id',
    )
    interfaces = relationship(
        'LLDPInterface', back_populates='config', cascade='all, delete-orphan',
        order_by='LLDPInterface.id',
    )

    def serialize(self):
        return {
            'enabled': True,
            'legacy_protocols': [name for name in PROTOCOLS if getattr(self, name)],
            'management_addresses': [row.address for row in self.management_addresses],
            'snmp': self.snmp,
            'interfaces': [row.serialize() for row in self.interfaces],
        }

    @classmethod
    def _clear(cls):
        db.session.query(LLDPManagementAddress).delete()
        db.session.query(LLDPInterface).delete()
        db.session.query(cls).delete()

    @classmethod
    def truncate(cls):
        try:
            cls._clear()
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

    @classmethod
    def refresh(cls, data):
        if data is None:
            cls.truncate()
            return
        parsed = parse_config(data)
        try:
            cls._clear()
            config = cls(
                **{name: name in parsed['legacy_protocols'] for name in PROTOCOLS},
                snmp=parsed['snmp'],
                management_addresses=[
                    LLDPManagementAddress(address=address)
                    for address in parsed['management_addresses']
                ],
                interfaces=[LLDPInterface(**interface) for interface in parsed['interfaces']],
            )
            db.session.add(config)
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise


class LLDPManagementAddress(db.Model):
    __tablename__ = 'vyos_config_lldp_management_address'
    __table_args__ = (UniqueConstraint('config_id', 'address'),)

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_lldp.id'), nullable=False)
    address = Column(String(64), nullable=False)

    config = relationship('LLDPConfig', back_populates='management_addresses')


class LLDPInterface(db.Model):
    __tablename__ = 'vyos_config_lldp_interface'
    __table_args__ = (UniqueConstraint('config_id', 'name'),)

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_lldp.id'), nullable=False)
    name = Column(String(64), nullable=False)
    mode = Column(String(16), nullable=False, default='rx-tx')

    config = relationship('LLDPConfig', back_populates='interfaces')

    def serialize(self):
        return {'name': self.name, 'mode': self.mode}
