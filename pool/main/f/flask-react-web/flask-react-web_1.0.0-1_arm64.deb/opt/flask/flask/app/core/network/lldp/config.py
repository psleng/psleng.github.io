from copy import deepcopy
from ipaddress import ip_address
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

PROTOCOLS = ('cdp', 'edp', 'fdp', 'sonmp')


class LLDPInterface(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=64, pattern=r'^[a-zA-Z0-9_.:*\-]+$')
    mode: Literal['disable', 'rx-tx', 'rx', 'tx'] = 'rx-tx'


class LLDPConfig(BaseModel):
    model_config = ConfigDict(extra='forbid')
    enabled: bool = False
    legacy_protocols: list[Literal['cdp', 'edp', 'fdp', 'sonmp']] = Field(default_factory=list)
    management_addresses: list[str] = Field(default_factory=list)
    snmp: bool = False
    interfaces: list[LLDPInterface] = Field(default_factory=list)

    @field_validator('management_addresses')
    @classmethod
    def validate_addresses(cls, addresses):
        return list(dict.fromkeys(str(ip_address(address.strip())) for address in addresses))

    @model_validator(mode='after')
    def unique_interfaces(self):
        names = [interface.name for interface in self.interfaces]
        if len(names) != len(set(names)):
            raise ValueError('Each LLDP interface may only be configured once')
        return self


def as_list(value):
    return value if isinstance(value, list) else ([] if value is None else [value])


def parse_config(raw):
    enabled = raw is not None
    raw = raw or {}
    protocols = raw.get('legacy-protocols') or {}
    return {
        'enabled': enabled,
        'legacy_protocols': [name for name in PROTOCOLS if name in protocols],
        'management_addresses': as_list(raw.get('management-address')),
        'snmp': 'snmp' in raw,
        'interfaces': [
            {'name': name, 'mode': (config or {}).get('mode', 'rx-tx')}
            for name, config in (raw.get('interface') or {}).items()
        ],
    }


def build_config(current, form):
    if not form.enabled:
        return None
    desired = deepcopy(current or {})

    protocols = desired.setdefault('legacy-protocols', {})
    for name in PROTOCOLS:
        if name in form.legacy_protocols:
            protocols.setdefault(name, {})
        else:
            protocols.pop(name, None)
    if not protocols:
        desired.pop('legacy-protocols', None)

    desired.pop('management-address', None)
    if form.management_addresses:
        desired['management-address'] = form.management_addresses

    if form.snmp:
        desired.setdefault('snmp', {})
    else:
        desired.pop('snmp', None)

    interfaces = desired.setdefault('interface', {})
    names = {interface.name for interface in form.interfaces}
    for name in list(interfaces):
        if name not in names:
            interfaces.pop(name)
    for interface in form.interfaces:
        options = interfaces.setdefault(interface.name, {})
        if interface.mode == 'rx-tx':
            if options.get('mode') != 'rx-tx':
                options.pop('mode', None)
        else:
            options['mode'] = interface.mode
    if not interfaces:
        desired.pop('interface', None)
    return desired


def verification_config(desired, context):

    def normalize(config):
        return {
            key.replace('-', '_'): normalize(value) if isinstance(value, dict) else value
            for key, value in config.items()
        }
    result = normalize({key: value for key, value in desired.items() if key != 'interface'})
    if 'interface' in desired:
        result['interface'] = {name: normalize(config) for name, config in desired['interface'].items()}
    if 'system_snmp_enabled' in context:
        result['system_snmp_enabled'] = context['system_snmp_enabled']
    if 'version' in context:
        result['version'] = context['version']
    return result
