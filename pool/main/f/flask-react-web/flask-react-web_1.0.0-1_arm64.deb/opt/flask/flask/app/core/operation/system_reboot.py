import json
import re
import subprocess
from datetime import datetime, timedelta

from app.core.api.http.cmd.command import SHOW_REBOOT
from app.core.api.http.http_request import Action
from app.core.api.manager import api_manager
from app.event.jobs.system.save_config import save_running_config


REBOOT_SCHEDULE_PATTERN = re.compile(
    r'Reboot\s+is\s+scheduled\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})',
    re.IGNORECASE
)


def _read_system_time():
    try:
        return subprocess.check_output(['date'], text=True).strip()
    except Exception:
        return ''


def _empty_reboot_schedule():
    return {
        'scheduled': False,
        'scheduled_at': None,
        'remaining_seconds': 0,
        'source': 'show reboot',
        'system_time': _read_system_time(),
    }


def _format_reboot_schedule(scheduled_at, source):
    now = datetime.now(scheduled_at.tzinfo) if scheduled_at.tzinfo else datetime.now()
    remaining_seconds = max(0, int((scheduled_at - now).total_seconds()))
    return {
        'scheduled': remaining_seconds > 0,
        'scheduled_at': scheduled_at.isoformat(),
        'remaining_seconds': remaining_seconds,
        'source': source,
        'system_time': _read_system_time(),
    }


def _parse_reboot_schedule(output):
    if isinstance(output, dict):
        output = output.get('data') or output.get('message') or ''
    if output is None:
        return _empty_reboot_schedule()

    match = REBOOT_SCHEDULE_PATTERN.search(str(output))
    if not match:
        return _empty_reboot_schedule()

    try:
        scheduled_at = datetime.strptime(match.group(1), '%Y-%m-%d %H:%M:%S')
    except ValueError:
        return _empty_reboot_schedule()

    return _format_reboot_schedule(scheduled_at, source='show reboot')


def get_reboot_status():
    response = api_manager.manager.provider.http_service.send_request(
        action=Action.SHOW,
        data=SHOW_REBOOT,
        verify=False
    ).json()
    return _parse_reboot_schedule(response)


def _calculate_reboot_time(mode, data):
    now = datetime.now()

    if mode == 'in':
        minutes = int(data.get('minutes'))
        if minutes <= 0:
            raise ValueError('Minutes must be greater than 0')
        return now + timedelta(minutes=minutes)

    if mode == 'at':
        time_value = (data.get('time') or '').strip()
        if not time_value:
            raise ValueError('Time is required')

        scheduled_time = datetime.strptime(time_value, '%H:%M').time()
        date_value = (data.get('date') or '').strip()

        if date_value:
            scheduled_date = datetime.strptime(date_value, '%d/%m/%Y').date()
            scheduled_at = datetime.combine(scheduled_date, scheduled_time)
        else:
            scheduled_at = datetime.combine(now.date(), scheduled_time)
            if scheduled_at <= now:
                scheduled_at += timedelta(days=1)

        if scheduled_at <= now:
            raise ValueError('Scheduled reboot time must be in the future')
        return scheduled_at

    return None


def _build_reboot_payload(data):
    mode = (data.get('mode') or '').strip().lower()

    if mode == 'now':
        return {'op': 'reboot', 'path': ['now']}, 'reboot now'

    if mode == 'in':
        _calculate_reboot_time(mode, data)
        minutes = int(data.get('minutes'))
        return {'op': 'reboot', 'path': ['in', str(minutes)]}, f'reboot in {minutes}'

    if mode == 'at':
        _calculate_reboot_time(mode, data)
        time_value = data.get('time').strip()
        date_value = (data.get('date') or '').strip()
        path = ['at', time_value]
        command = f'reboot at {time_value}'
        if date_value:
            path.extend(['date', date_value])
            command = f'{command} date {date_value}'
        return {'op': 'reboot', 'path': path}, command

    if mode == 'cancel':
        return {'op': 'reboot', 'path': ['cancel']}, 'reboot cancel'

    raise ValueError('Unsupported reboot mode')


def run_reboot_command(data):
    payload, command = _build_reboot_payload(data)
    mode = (data.get('mode') or '').strip().lower()

    if mode != 'cancel':
        save_running_config()

    try:
        result = api_manager.manager.provider.http_service.send_request(
            action=Action.REBOOT,
            data=json.dumps(payload),
            verify=False
        ).json()
    except Exception as e:
        if mode == 'now':
            return {
                'success': True,
                'command': command,
                'rebooting': True,
                'message': 'System is rebooting. Service is temporarily unavailable.',
                'result': {
                    'error': str(e),
                },
            }
        raise

    if result.get('success') is False:
        return {
            'success': False,
            'command': command,
            'result': result,
        }

    return {
        'success': True,
        'command': command,
        'result': result,
        'rebooting': mode == 'now',
        'status': None if mode == 'now' else get_reboot_status(),
    }
