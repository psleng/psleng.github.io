def parse_to_dhcp_options_vyos_config(dhcp_config):
    
    if not dhcp_config:
        return None, None
    
    dhcp_section = {}
    
    if dhcp_config.get('dhcpClientId'):
        dhcp_section['client-id'] = dhcp_config['dhcpClientId']
    
    if dhcp_config.get('dhcpDefaultRouteDistance'):
        dhcp_section['default-route-distance'] = dhcp_config['dhcpDefaultRouteDistance']
    
    if dhcp_config.get('dhcpHostName'):
        dhcp_section['host-name'] = dhcp_config['dhcpHostName']
    
    if dhcp_config.get('dhcpMtu'):
        dhcp_section['mtu'] = {}
    
    if dhcp_config.get('dhcpNoDefaultRoute'):
        dhcp_section['no-default-route'] = {}
    
    if dhcp_config.get('dhcpUserClass'):
        dhcp_section['user-class'] = dhcp_config['dhcpUserClass']
    
    if dhcp_config.get('dhcpVendorClassId'):
        dhcp_section['vendor-class-id'] = dhcp_config['dhcpVendorClassId']
    
    dhcpv6_section = {}
    
    if dhcp_config.get('dhcpv6Duid'):
        dhcpv6_section['duid'] = dhcp_config['dhcpv6Duid']
    
    if dhcp_config.get('dhcpv6NoRelease'):
        dhcpv6_section['no-release'] = {}
    
    if dhcp_config.get('dhcpv6ParametersOnly'):
        dhcpv6_section['parameters-only'] = {}

    if dhcp_config.get('dhcpv6NoRequestDomainName'):
        dhcpv6_section['no-request-domain-name'] = {}

    if dhcp_config.get('dhcpv6NoRequestDns'):
        dhcpv6_section['no-request-dns'] = {}
    
    if dhcp_config.get('dhcpv6RapidCommit'):
        dhcpv6_section['rapid-commit'] = {}
    
    if dhcp_config.get('dhcpv6Temporary'):
        dhcpv6_section['temporary'] = {}
    
    if dhcp_config.get('dhcpv6Pd'):
        pd_section = {}
        for instance_id, pd_config in dhcp_config['dhcpv6Pd'].items():
            pd_instance = {}
            
            if pd_config.get('length'):
                pd_instance['length'] = pd_config['length']
            
            interface_data = pd_config.get('interface') or pd_config.get('interfaces')
            if interface_data:
                pd_instance['interface'] = {}
                for intf_name, intf_config in interface_data.items():
                    pd_intf = {}
                    
                    if intf_config.get('address'):
                        pd_intf['address'] = str(intf_config['address'])
                    
                    if intf_config.get('slaId'):
                        pd_intf['sla-id'] = intf_config['slaId']
                    
                    if intf_config.get('slaLength'):
                        pd_intf['sla-length'] = intf_config['slaLength']
                    
                    if pd_intf:
                        pd_instance['interface'][intf_name] = pd_intf
            
            if pd_instance:
                pd_section[instance_id] = pd_instance
        
        if pd_section:
            dhcpv6_section['pd'] = pd_section
    
    return (
        dhcp_section if dhcp_section else None,
        dhcpv6_section if dhcpv6_section else None
    )
