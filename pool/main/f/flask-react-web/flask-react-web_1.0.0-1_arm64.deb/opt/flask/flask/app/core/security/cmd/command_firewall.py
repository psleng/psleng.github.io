from typing import List
from app.core.api.http.cmd.command import Command

def format_description(description: str) -> str:
    # Replace spaces with underscores
    return description.replace(' ', '_')

class FirewallCommand(Command):
    """
    Class for generating firewall commands
    Supports the following VyOS commands:
    set/delete firewall global-options all-ping enable/disable
    set firewall global-options state-policy established action accept/drop/reject 
    set firewall global-options state-policy invalid action accept/drop/reject 
    set firewall global-options state-policy related action accept/drop/reject 
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> action <action>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> protocol <protocol>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> source address <address>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> source address-mask <mask>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> source port <port>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> source mac-address <mac>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> destination address <address>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> destination address-mask <mask>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> destination port <port>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> destination mac-address <mac>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> inbound-interface name <interface>
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> log
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> disable
    set/delete firewall ipv4/ipv6 <direction> raw rule <rule-number> description <description>

    # Block all ipv6 options in all pages
    set/delete firewall ipv6 block

    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'ipv4'))
            self.attributes = {
                'ipv4': {
                    'prerouting': {'raw': {'default_action': 'accept', 'rule': {}}},
                    'output': {'raw': {'default_action': 'accept', 'rule': {}}}
                },
                'ipv6': {
                    'prerouting': {'raw': {'default_action': 'accept', 'rule': {}}},
                    'output': {'raw': {'default_action': 'accept', 'rule': {}}}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Firewall cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a cmd string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'
    
    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        """Return the list of raw commands"""
        return self.vyos_cmds

    def _process_rule(self, ip_version: str, direction: str, rule_number: str, rule_config: dict):
        """Process a single firewall rule and generate appropriate commands"""
        base = ['firewall', ip_version, direction, 'raw', 'rule', rule_number]
        
        if rule_config.get('action'):
            self.generate(*base, 'action', rule_config['action'].lower())
        
        if rule_config.get('protocol'):
            self.generate(*base, 'protocol', rule_config['protocol'].lower())

        if 'source' in rule_config:
            source = rule_config['source']
            if 'address' in source:
                self.generate(*base, 'source', 'address', source['address'])
            if 'address-mask' in source:
                self.generate(*base, 'source', 'address-mask', source['address-mask'])
            if 'port' in source:
                self.generate(*base, 'source', 'port', source['port'])
            if 'mac-address' in source:
                self.generate(*base, 'source', 'mac-address', source['mac-address'])

        if 'destination' in rule_config:
            dest = rule_config['destination']
            if 'address' in dest:
                self.generate(*base, 'destination', 'address', dest['address'])
            if 'address-mask' in dest:
                self.generate(*base, 'destination', 'address-mask', dest['address-mask'])
            if 'port' in dest:
                self.generate(*base, 'destination', 'port', dest['port'])
            if 'mac-address' in dest:
                self.generate(*base, 'destination', 'mac-address', dest['mac-address'])

        if 'inbound-interface' in rule_config and 'name' in rule_config['inbound-interface']:
            self.generate(*base, 'inbound-interface', 'name', rule_config['inbound-interface']['name'])
        
        if 'outbound-interface' in rule_config and 'name' in rule_config['outbound-interface']:
            self.generate(*base, 'outbound-interface', 'name', rule_config['outbound-interface']['name'])
        
        if 'log' in rule_config:
            self.generate(*base, 'log')
            
        # Handle disable flag
        if 'disable' in rule_config:
            self.generate(*base, 'disable')
            
        # Handle description
        if 'description' in rule_config:
            self.generate(*base, 'description', format_description(rule_config['description']))

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """
        Generate VyOS commands for firewall configuration
        
        Input format:
        {
            'ipv4': {
                'prerouting': {
                    'raw': {
                        'default-action': 'accept',
                        'rule': {
                            '1': {
                                'action': 'ACCEPT',
                                'protocol': 'tcp',
                                'source': {
                                    'address': '192.168.1.1',
                                    'address-mask': '255.255.255.0',
                                    'port': '80'
                                },
                                'destination': {
                                    'address': '10.0.0.1',
                                    'port': '443'
                                },
                                'inbound-interface': {
                                    'name': 'eth0'
                                }
                            }
                        }
                    }
                }
            }
        }
        """
        try:
            if not data:
                return []
            
            if 'global-options' in data:
                global_opts = data['global-options']
                
                if 'all-ping' in global_opts:
                    self.generate('firewall', 'global-options', 'all-ping', global_opts['all-ping'])

                if 'log-martians' in global_opts:
                    self.generate('firewall', 'global-options', 'log-martians', global_opts['log-martians'])

                state_policy = global_opts.get('state-policy', {})

                if 'established' in state_policy and 'action' in state_policy['established']:
                    self.generate('firewall', 'global-options', 'state-policy', 'established', 'action', state_policy['established']['action'])

                if 'invalid' in state_policy and 'action' in state_policy['invalid']:
                    self.generate('firewall', 'global-options', 'state-policy', 'invalid', 'action', state_policy['invalid']['action'])

                if 'related' in state_policy and 'action' in state_policy['related']:
                    self.generate('firewall', 'global-options', 'state-policy', 'related', 'action', state_policy['related']['action'])

            for ip_version in ['ipv4', 'ipv6']:
                if ip_version not in data:
                    continue
    
                # Handle block flag
                if 'block' in data[ip_version]:
                    self.generate('firewall', ip_version, 'block')
            
                for direction in ['prerouting', 'output']:
                    if direction not in data[ip_version]:
                        continue

                    if 'raw' not in data[ip_version][direction]:
                        continue

                    raw_config = data[ip_version][direction]['raw']

                    if 'default_action' in raw_config:
                        self.generate('firewall', ip_version, direction, 'raw', 'default-action', 
                                    raw_config['default_action'])

                    if 'rule' in raw_config:
                        for rule_number, rule_config in raw_config['rule'].items():
                            self._process_rule(ip_version, direction, rule_number, rule_config)

                            # If del_config is exactly the same as the current config, delete the entire rule
                            if self.operator == "delete" and rule_config == current_config[ip_version][direction]['raw']['rule'][rule_number]:
                                self.generate('firewall', ip_version, direction, 'raw', 'rule', rule_number)
                        
                            # Action is required, need to specify when verifying. 
                            # When not specify in set_config, use the new config
                            if self.operator == "set" and 'action' in new_config[ip_version][direction]['raw']['rule'][rule_number]:
                                self.generate('firewall', ip_version, direction, 'raw', 'rule', rule_number, 'action', 
                                    new_config[ip_version][direction]['raw']['rule'][rule_number]['action'].lower()
                                )

            return self.cmds

        except Exception as e:
            print(f"Error generating firewall commands: {e}")
            return []


if __name__ == "__main__":
    # Test data
    test_data = {
        'global-options': {
            'all-ping': {
                'ipv4-ping': {
                    'enabled': False
                },
                'log-martians': {
                    'enabled': True
                }
            },
            'state-policy' : {
                'established': {
                    'action': 'accept'
                }, 
                'invalid': {
                    'action': 'drop'
                },
                'related': {
                    'action': 'reject'
                }
            }
        },
        'ipv4': {
            'prerouting': {
                'raw': {
                    'default-action': 'accept',
                    'rule': {
                        '1': {
                            'action': 'ACCEPT',
                            'protocol': 'tcp',
                            'source': {
                                'address': '192.168.1.1',
                                'address-mask': '255.255.255.0',
                                'port': '80'
                            },
                            'destination': {
                                'address': '10.0.0.1',
                                'port': '443'
                            },
                            'inbound-interface': {
                                'name': 'eth0'
                            },
                            'enabled': True,
                            'description': 'Allow HTTPS traffic'
                        },
                        '2': {
                            'action': 'DROP',
                            'protocol': 'tcp',
                            'source': {
                                'address': '192.168.1.2'
                            },
                            'enabled': False,
                            'description': 'Block specific IP (disabled)'
                        }
                    }
                }
            }
        }
    }
    
    # Test command generation
    cmd = FirewallCommand(operator='set')
    commands = cmd.generate_commands(test_data)
    print("Generated commands:")
    for command in commands:
        print(command)
