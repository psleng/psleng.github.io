import pprint

from flask import jsonify, request

from app.auth.utils import login_required
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.http.cmd.compare import compare_configs
from app.core.api.manager import api_manager
from app.core.models import Interface
from app.core.network import vyos_network_bp
from app.core.network.nat66.models import NAT66Config, NAT66DTO
from app.core.network.nat66.parser import parse_nat66_input


@vyos_network_bp.route('/nat66', methods=['GET'])
@login_required
def get_nat66():
    try:
        interfaces = Interface.get_interface_names()
        response = {
            'interfaces': interfaces,
            'rules': [rule.serialize() for rule in NAT66Config.query.all()],
        }
        return jsonify(response), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/nat66/<direction>/rules', methods=['GET'])
@login_required
def get_nat66_rules(direction):
    if direction not in ('source', 'destination'):
        return jsonify({'error': 'Invalid NAT66 direction'}), 400
    try:
        rules = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.NAT66_RULES,
            data={'direction': direction},
        )
        return jsonify(rules), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/nat66/<direction>/stat', methods=['GET'])
@login_required
def get_nat66_stat(direction):
    if direction not in ('source', 'destination'):
        return jsonify({'error': 'Invalid NAT66 direction'}), 400
    try:
        statistics = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.NAT66_STAT,
            data={'direction': direction},
        )
        return jsonify(statistics), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/nat66', methods=['PUT'])
@login_required
def update_nat66():
    try:
        data = NAT66DTO.model_validate_json(request.data)
        request_data = data.model_dump()

        print('Validated NAT66 data:')
        print(pprint.pformat(request_data, indent=2, width=80))

        current_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.NAT66,
        )
        current_config = current_config or {}

        print('Current NAT66 config:')
        print(pprint.pformat(current_config, indent=2, width=80))

        new_config = parse_nat66_input(request_data)
        print('New NAT66 config:')
        print(pprint.pformat(new_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        print('NAT66 diff config:')
        print(pprint.pformat(diff, indent=2, width=80))

        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.NAT66,
            data={
                'current': current_config,
                'new': new_config,
                'diff': diff,
            },
        )

        if isinstance(result, Exception):
            return jsonify({'error': str(result)}), 400

        return jsonify(result), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/nat66/verify', methods=['POST'])
@login_required
def verify_nat66():
    try:
        data = NAT66DTO.model_validate_json(request.data)
        request_data = data.model_dump()

        print('Unparsed NAT66 config:')
        print(pprint.pformat(request_data, indent=2, width=80))

        nat66_config = parse_nat66_input(request_data)
        print('Parsed NAT66 config:')
        print(pprint.pformat(nat66_config, indent=2, width=80))

        verification = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.NAT66,
            data=nat66_config,
        )

        if verification in ('None', None, ''):
            return jsonify({'verify': 'Success'}), 200

        return jsonify({'verify': verification}), 400
    except Exception as error:
        print('NAT66 verification error:', error)
        return jsonify({'error': str(error)}), 400
