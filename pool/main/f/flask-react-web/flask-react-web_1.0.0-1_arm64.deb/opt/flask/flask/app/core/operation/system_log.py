from app.core.operation.parser import parse_system_log


def _escape_graphql_string(value: str) -> str:
    if value is None:
        return ""
    return str(value).replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ')


def _dict_to_graphql_args(data: dict) -> str:
    if not isinstance(data, dict):
        return ""

    parts = []
    for k, v in data.items():
        if v is None:
            continue
        if isinstance(v, str):
            parts.append(f'{k}: "{_escape_graphql_string(v)}"')
        elif isinstance(v, bool):
            parts.append(f"{k}: {'true' if v else 'false'}")
        else:
            parts.append(f"{k}: {v}")

    return ", ".join(parts)

def fetch_system_opr_log(provider, data=None):
    """
    Read all system log
    
    """    
    function_name = 'ShowTimeLogQuery'

    unit = data.get('unit')
    if isinstance(unit, str):
        unit = unit.strip()

    syslog_identifier = data.get('syslog_identifier')
    if isinstance(syslog_identifier, str):
        syslog_identifier = syslog_identifier.strip()

    gql_args = _dict_to_graphql_args({
        'minutes': data.get('minutes'),
        'keyword': data.get('keyword', ''),
        'unit': unit if unit else None,
        'syslog_identifier': syslog_identifier if syslog_identifier else None,
        'priority': data.get('priority', 7)
    })

    response = provider.graphql_service.send_request(function_name=function_name, data=gql_args, verify=False)
    response.raise_for_status()
    payload = response.json()

    if payload.get('errors'):
        raise RuntimeError(str(payload['errors']))

    response_data = payload.get('data')
    if not isinstance(response_data, dict):
        raise RuntimeError('System log query returned no data')

    query_result = response_data.get(function_name)
    if isinstance(query_result, dict) and query_result.get('success') is False:
        raise RuntimeError(str(query_result.get('errors') or 'System log query failed'))

    opr_log = parse_system_log(response_data)
    return opr_log if isinstance(opr_log, dict) else []
