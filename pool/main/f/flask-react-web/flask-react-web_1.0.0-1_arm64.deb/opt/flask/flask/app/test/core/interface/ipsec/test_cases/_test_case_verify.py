import pytest

test_verify_success_1 = pytest.param(
    {
        "site-to-site": {
            "peer": {
                "peer-1": {
                    "authentication": {
                        "mode": "pre-shared-secret",
                        "local-id": "local-id",
                        "remote-id": "remote-id"
                    },
                    "ike-group": "ike-group-1",
                    "local-address": "192.168.1.1",
                    "remote-address": "192.168.2.1"
                }
            }
        }
    },
    id="test_verify_success_ipsec_1"
)

test_verify_success_2 = pytest.param(
    {
        "site-to-site": {
            "peer": {
                "peer-rsa": {
                    "authentication": {
                        "mode": "rsa",
                        "rsa": {
                            "local-key": "local-key",
                            "remote-key": "remote-key"
                        }
                    },
                    "ike-group": "ike-group-1",
                    "local-address": "10.0.0.1",
                    "remote-address": "10.0.0.2"
                }
            }
        }
    },
    id="test_verify_success_ipsec_rsa"
)

test_verify_success_3 = pytest.param(
    {
        "remote-access": {
            "connection": {
                "conn-1": {
                    "ike-group": "ike-grp-1",
                    "esp-group": "esp-grp-1",
                    "local-address": "any",
                    "pool": ["pool-1"]
                }
            }
        }
    },
    id="test_verify_success_remote_access"
)

test_verify_success_4 = pytest.param(
    {
        "ike-group": {
            "ike-grp-1": {
                "key-exchange": "ikev2",
                "lifetime": "28800",
                "proposal": {
                    "1": {
                        "dh-group": "14",
                        "encryption": "aes256",
                        "hash": "sha256"
                    }
                }
            }
        }
    },
    id="test_verify_success_ike_group"
)

test_verify_success_5 = pytest.param(
    {
        "esp-group": {
            "esp-grp-1": {
                "lifetime": "3600",
                "mode": "tunnel",
                "pfs": "dh-group14",
                "proposal": {
                    "1": {
                        "encryption": "aes256",
                        "hash": "sha256"
                    }
                }
            }
        }
    },
    id="test_verify_success_esp_group"
)

test_verify_success = [
    test_verify_success_1,
    test_verify_success_2,
    test_verify_success_3,
    test_verify_success_4,
    test_verify_success_5,
]

test_verify_failed_1 = pytest.param(
    {
        "site-to-site": {
            "peer": {
                "peer-invalid": {
                    "authentication": {
                        "mode": "invalid-mode"
                    }
                }
            }
        }
    },
    id="test_verify_failed_ipsec_1"
)

test_verify_failed_2 = pytest.param(
    {
        "site-to-site": {
            "peer": {
                "peer-invalid-address": {
                    "authentication": {
                        "mode": "pre-shared-secret"
                    },
                    "local-address": "invalid-ip",
                    "remote-address": "192.168.1.1"
                }
            }
        }
    },
    id="test_verify_failed_invalid_address"
)

test_verify_failed_3 = pytest.param(
    {
        "ike-group": {
            "ike-invalid": {
                "key-exchange": "invalid-version"
            }
        }
    },
    id="test_verify_failed_invalid_ike_version"
)

test_verify_failed_4 = pytest.param(
    {
        "esp-group": {
            "esp-invalid": {
                "mode": "invalid-mode"
            }
        }
    },
    id="test_verify_failed_invalid_esp_mode"
)

test_verify_failed_5 = pytest.param(
    {
        "remote-access": {
            "connection": {
                "conn-invalid": {
                    "authentication": {
                        "client-mode": "invalid-client-mode"
                    }
                }
            }
        }
    },
    id="test_verify_failed_invalid_client_mode"
)

test_verify_failed = [
    test_verify_failed_1,
    test_verify_failed_2,
    test_verify_failed_3,
    test_verify_failed_4,
    test_verify_failed_5,
]
