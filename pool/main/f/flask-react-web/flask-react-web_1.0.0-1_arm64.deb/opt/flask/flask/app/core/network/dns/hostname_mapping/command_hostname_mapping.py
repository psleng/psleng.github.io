import json

from app.core.api.http.cmd.command import Command


class HostnameMappingCommand(Command):

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'system'),
        )
        self.attributes = {'host-name': {}}
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements):
        return json.dumps({'op': self.operator, 'path': list(path_elements)})

    def generate(self, *path_elements):
        self.cmds.append(self._build_command(*path_elements))
        self.vyos_cmds.append(' '.join(path_elements))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if self.operator not in ('set', 'delete'):
            raise ValueError(f'Invalid operator: {self.operator}')
        self.cmds = []
        self.vyos_cmds = []
        self.attributes = data or {'host-name': {}}
        for hostname, entry in sorted(self.attributes.get('host-name', {}).items()):
            path = [self.resource, 'static-host-mapping', 'host-name', hostname]
            if (self.operator == 'delete' and new_config is not None
                    and hostname not in new_config.get('host-name', {})):
                self.generate(*path)
                continue
            for field in ('inet', 'alias'):
                if entry.get(field):
                    self.generate(*path, field, entry[field])
        return self.cmds
