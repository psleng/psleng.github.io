from datetime import datetime, timedelta
import subprocess
from logging import getLogger

from app.log.logger import logger
from app.socket.socket_manager import socket_manager
from app.core.utils.check_os import is_linux

_service_name = 'vyos-http-api'
_last_alert_at = None

def _run_command(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def _get_service_state() -> str:
    # Expected output: "active", "inactive", "failed", "activating", etc.
    proc = _run_command(['systemctl', 'is-active', _service_name])
    out = (proc.stdout or '').strip()
    if out:
        return out
    err = (proc.stderr or '').strip()
    return err or 'unknown'


def _get_recent_logs(max_lines: int = 200) -> str:
    proc = _run_command(
        [
            'journalctl',
            '-u',
            _service_name,
            '-n',
            str(max_lines),
            '--no-pager',
        ]
    )
    return (proc.stdout or '').strip()


def fetch_vyos_http_api_status(app_context):
    global _last_alert_at
    try:
        if not is_linux():
            return None

        state = _get_service_state()
        logs = _get_recent_logs()

        deactivated_successfully = 'Deactivated successfully.' in logs
        # needs_restart = (state != 'active') or deactivated_successfully
        needs_restart = state != 'active'

        if not needs_restart:
            # TODO: send 'remove' event.
            # now = datetime.now()
            # socket_manager.emit_to_all(
            #     event='notification',
            #     data={
            #         'id': str(int(now.timestamp() * 1000)),
            #         'type': 'remove',
            #         'action': 'restart-vyos-http-api',
            #     },
            # )
            return {'service': _service_name, 'state': state, 'needs_restart': False}

        now = datetime.now()
        if _last_alert_at is not None and (now - _last_alert_at) < timedelta(seconds=60):
            return {'service': _service_name, 'state': state, 'needs_restart': True}

        _last_alert_at = now

        socket_manager.emit_to_all(
            event='notification',
            data={
                'id': str(int(now.timestamp() * 1000)),
                'type': 'error',
                'title': 'Backend API is not responding',
                'content': 'HTTP API service is not active or was deactivated. Restart is required.',
                'action': 'restart-vyos-http-api',
            },
        )

        return {'service': _service_name, 'state': state, 'needs_restart': True}

    except Exception as e:
        logger.error('fetch_vyos_http_api_status failed')
        logger.error(str(e))
        return None
