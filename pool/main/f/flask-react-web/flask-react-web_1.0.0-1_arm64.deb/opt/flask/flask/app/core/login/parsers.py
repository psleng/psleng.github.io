from typing import Any, Collection, Dict, Optional


def normalize_keys(config: Any) -> Any:
    if isinstance(config, dict):
        normalized: Dict[str, Any] = {}
        for key, value in config.items():
            new_key = str(key).replace("_", "-")
            normalized[new_key] = normalize_keys(value)
        return normalized

    if isinstance(config, list):
        return [normalize_keys(v) for v in config]

    return config


def _extract_other_options(payload: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}

    if "banner" in payload and payload.get("banner") is not None:
        out["banner"] = payload.get("banner")

    if "max_sessions" in payload and payload.get("max_sessions") is not None:
        out["max-login-session"] = payload.get("max_sessions")

    if "timeout" in payload and payload.get("timeout") is not None:
        timeout = payload.get("timeout")
        if str(timeout) != "":
            out["timeout"] = timeout

    return out


def _extract_auth_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    auth_payload = dict(payload)
    auth_payload.pop("type", None)
    auth_payload.pop("password_policy", None)
    auth_payload.pop("banner", None)
    auth_payload.pop("max_sessions", None)
    auth_payload.pop("timeout", None)
    return auth_payload


def _parse_flat_to_login_config(
    payload: Dict[str, Any], current_config: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    current_config = current_config or {}

    config_type = payload.get("type") or "noconf"

    new_config: Dict[str, Any] = dict(current_config)

    auth_nodes = ["saml", "radius", "tacacs"]

    if config_type == "saml":
        for k in ["radius", "tacacs"]:
            new_config.pop(k, None)
        new_config["saml"] = normalize_keys(_extract_auth_payload(payload))

    elif config_type == "radius":
        for k in ["saml", "tacacs"]:
            new_config.pop(k, None)
        new_config["radius"] = normalize_keys(_extract_auth_payload(payload))

    elif config_type == "tacacs":
        for k in ["saml", "radius"]:
            new_config.pop(k, None)
        new_config["tacacs"] = normalize_keys(_extract_auth_payload(payload))

    else:
        for k in auth_nodes:
            new_config.pop(k, None)

    other_opts = _extract_other_options(payload)
    for k, v in other_opts.items():
        new_config[k] = normalize_keys(v)

    return normalize_keys(new_config)


def _role_to_operator_group(role: Any) -> Optional[str]:
    role_str = str(role).strip().lower() if role is not None else ""
    if role_str == "operator":
        return "default"
    if role_str == "operator+":
        return "super-operator"
    return None


def _build_local_user_config(
    user_payload: Dict[str, Any],
    existing_user_cfg: Optional[Dict[str, Any]] = None,
    public_key_types: Optional[Collection[str]] = None,
) -> Dict[str, Any]:
    existing_user_cfg = existing_user_cfg if isinstance(existing_user_cfg, dict) else {}
    auth_existing = existing_user_cfg.get("authentication")
    auth_existing = auth_existing if isinstance(auth_existing, dict) else {}

    user_cfg: Dict[str, Any] = {}

    if user_payload.get("disabled") is True or user_payload.get("status") is False:
        user_cfg["disable"] = True

    full_name = user_payload.get("full_name")
    if full_name is None:
        full_name = user_payload.get("full-name")
    if full_name is not None:
        user_cfg["full-name"] = full_name

    operator_group = _role_to_operator_group(user_payload.get("role"))
    if operator_group:
        user_cfg["operator"] = {"group": operator_group}

    auth_cfg: Dict[str, Any] = {}
    password = user_payload.get("password")
    if password not in [None, ""]:
        auth_cfg["plaintext-password"] = password
    elif "encrypted-password" in auth_existing:
        auth_cfg["encrypted-password"] = auth_existing.get("encrypted-password")
    elif "plaintext-password" in auth_existing:
        auth_cfg["plaintext-password"] = auth_existing.get("plaintext-password")

    saml_id = user_payload.get("saml_id")
    if saml_id is None:
        saml_id = user_payload.get("saml-id")
    if saml_id is None and "saml" in user_payload:
        saml_candidate = user_payload.get("saml")
        if isinstance(saml_candidate, str) and saml_candidate.strip():
            saml_id = saml_candidate
    if isinstance(saml_id, str) and saml_id.strip():
        auth_cfg["saml"] = saml_id.strip()

    saml_jit = user_payload.get("saml_jit")
    if saml_jit is None:
        saml_jit = user_payload.get("saml-jit")
    if bool(saml_jit):
        # valueless leaf in vyos → represent as empty dict
        auth_cfg["saml-jit"] = {}

    public_keys_payload = user_payload.get("public_keys")
    if public_keys_payload is None:
        public_keys_payload = user_payload.get("public-keys")

    if public_keys_payload is not None:
        if not isinstance(public_keys_payload, list):
            raise ValueError("Public keys must be a list")

        public_keys: Dict[str, Any] = {}
        for public_key in public_keys_payload:
            if not isinstance(public_key, dict):
                raise ValueError("Each public key must be an object")

            name = str(public_key.get("name") or "").strip()
            key = str(public_key.get("key") or "").strip()
            key_type = str(public_key.get("type") or "").strip()
            if not name or not key or not key_type:
                raise ValueError("Public key name, key, and a valid type are required")
            if public_key_types is not None and key_type not in public_key_types:
                raise ValueError(f'Public key type "{key_type}" is not supported')
            if name in public_keys:
                raise ValueError(f'Public key name "{name}" must be unique')

            public_keys[name] = {"key": key, "type": key_type}

        if public_keys:
            auth_cfg["public-keys"] = public_keys
    elif isinstance(auth_existing.get("public-keys"), dict):
        auth_cfg["public-keys"] = auth_existing["public-keys"]

    if auth_cfg:
        user_cfg["authentication"] = auth_cfg

    return user_cfg


def parse_to_login_config(
    payload: Dict[str, Any],
    current_config: Optional[Dict[str, Any]] = None,
    public_key_types: Optional[Collection[str]] = None,
) -> Dict[str, Any]:
    payload = payload or {}

    if "type" in payload:
        return _parse_flat_to_login_config(payload, current_config=current_config)

    structured = payload if isinstance(payload, dict) else {}
    saml = structured.get("saml")
    radius = structured.get("radius")
    tacacs = structured.get("tacacs")

    config_type = "noconf"
    auth_payload: Dict[str, Any] = {}
    tacacs_timeout = None
    if isinstance(saml, dict) and saml:
        config_type = "saml"
        auth_payload = saml
    elif isinstance(radius, dict) and radius:
        config_type = "radius"
        auth_payload = radius
    elif isinstance(tacacs, dict) and tacacs:
        config_type = "tacacs"
        auth_payload = dict(tacacs)
        if "timeout" in auth_payload:
            tacacs_timeout = auth_payload.pop("timeout")

    other_options = structured.get("other_options")
    other_options = other_options if isinstance(other_options, dict) else {}

    timeout_unlimited = False
    if "timeout" in other_options and other_options.get("timeout") is not None:
        if str(other_options.get("timeout")) == "":
            timeout_unlimited = True

    flat_payload: Dict[str, Any] = {
        "type": config_type,
        **auth_payload,
    }

    for k in ["banner", "max_sessions"]:
        if k in other_options:
            flat_payload[k] = other_options.get(k)

    if "timeout" in other_options:
        flat_payload["timeout"] = other_options.get("timeout")

    new_config = _parse_flat_to_login_config(
        flat_payload, current_config=current_config
    )

    if config_type == "tacacs" and tacacs_timeout is not None:
        tacacs_cfg = new_config.get("tacacs")
        if not isinstance(tacacs_cfg, dict):
            tacacs_cfg = {}
            new_config["tacacs"] = tacacs_cfg
        tacacs_cfg["timeout"] = tacacs_timeout

    if timeout_unlimited:
        new_config.pop("timeout", None)

    if "local_users" in structured:
        local_users = structured.get("local_users")
        local_users = local_users if isinstance(local_users, list) else []
        keep_usernames = []
        existing_users = new_config.get("user")
        existing_users = existing_users if isinstance(existing_users, dict) else {}
        next_users: Dict[str, Any] = {}

        for user in local_users:
            if not isinstance(user, dict):
                continue

            username = user.get("user_name") or user.get("username")
            if not username:
                continue

            username = str(username)
            keep_usernames.append(username)
            next_users[username] = _build_local_user_config(
                user, existing_users.get(username), public_key_types
            )

        if next_users:
            new_config["user"] = next_users
        else:
            new_config.pop("user", None)

    return normalize_keys(new_config)
