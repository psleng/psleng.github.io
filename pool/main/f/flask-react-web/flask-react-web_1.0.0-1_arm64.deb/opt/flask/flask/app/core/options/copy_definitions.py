#!/usr/bin/env python3
import argparse
import shutil
import sys
from pathlib import Path

try:
    from .definitions import DEFINITIONS, DEFINITION_DIR
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from definitions import DEFINITIONS, DEFINITION_DIR


def install_definitions(destination=DEFINITION_DIR):
    destination = Path(destination)
    fallback_dir = destination / "template"
    destination.mkdir(parents=True, exist_ok=True)
    failures = 0

    for spec in DEFINITIONS:
        target = destination / spec.filename
        source = Path(spec.source)
        try:
            shutil.copyfile(source, target)
            print(f"Installed option definition: {source}")
            continue
        except OSError as exc:
            print(
                f"WARNING: unable to copy {source}: {exc}; "
                f"using bundled default {fallback_dir / spec.filename}",
                file=sys.stderr,
            )

        try:
            shutil.copyfile(fallback_dir / spec.filename, target)
        except OSError as exc:
            failures += 1
            print(
                f"ERROR: unable to install default definition for {spec.name}: {exc}",
                file=sys.stderr,
            )

    return failures


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", type=Path, default=DEFINITION_DIR)
    args = parser.parse_args()
    return 1 if install_definitions(args.destination) else 0


if __name__ == "__main__":
    raise SystemExit(main())
