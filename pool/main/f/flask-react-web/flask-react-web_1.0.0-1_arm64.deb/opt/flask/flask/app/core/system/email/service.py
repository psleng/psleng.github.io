from uuid import uuid4

from flask import session

from app.core.api.http.http_request import Action
from app.core.system.email.command_email import EmailCommand
from app.core.system.email.parser import parse_vyos_config_to_verify
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


SHOW_EMAIL = '{"op": "showConfig", "path": ["system", "email"]}'
DELETE_EMAIL = '{"op": "delete", "path": ["system", "email"]}'


def _emit_success(username: str, title: str, content: str):
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': title,
            'content': content,
        },
    )


def _verify_email(provider, config: dict):
    """Verify when the configured validator supports system email."""
    verify_service = getattr(provider, 'verify_service', None)
    if verify_service is None or not hasattr(verify_service, 'call_verify'):
        return None

    locations = getattr(verify_service, '_locations', None)
    if isinstance(locations, dict) and 'email' not in locations:
        return None

    try:
        verify_config = (
            config
            if isinstance(config.get('profiles'), dict)
            else parse_vyos_config_to_verify(config)
        )
        return verify_service.call_verify('email', verify_config)
    except Exception as error:
        logger.info(f'Email verification skipped: {error}')
        return None


def _verification_error(verify):
    value = str(verify).replace('\n', '')
    return value not in ('None', '', '{}')


def fetch_email(provider, data: dict):
    del data
    route_response = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_EMAIL,
        verify=False,
    )
    payload = route_response.json().get('data')
    return payload if isinstance(payload, dict) else {}


def update_email(provider, data: dict):
    logger.info('Update Email')

    username = session.get('username', '')
    config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}

    if not config:
        response = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=DELETE_EMAIL,
            verify=False,
        ).json()
        if response.get('success') is not True:
            return Exception(response.get('error') or 'Failed to delete system email configuration')

        _emit_success(
            username,
            title='Success: Delete Email',
            content='System email configuration deleted successfully',
        )
        return [{'cmd': [DELETE_EMAIL], 'success': True, 'error': response.get('error')}]

    email_set_command = EmailCommand(operator='set')
    set_cmds = email_set_command.generate_commands(
        data=diff.get('created') or {},
        current_config=current_config,
        new_config=config,
    )

    email_delete_command = EmailCommand(operator='delete')
    delete_cmds = email_delete_command.generate_commands(
        data=diff.get('deleted') or {},
        current_config=current_config,
        new_config=config,
    )

    merged_delete_config = merge_dicts_delete(
        current_config,
        diff.get('deleted') or {},
        clean_empty=True,
        aggressive=True,
    )
    merged_config = merge_dicts_set(
        merged_delete_config,
        diff.get('created') or {},
    )
    verify = _verify_email(provider, merged_config)

    commands = list(dict.fromkeys(delete_cmds + set_cmds))
    if _verification_error(verify):
        return Exception(str(verify))

    logger.info(
        f'System email update generated {len(delete_cmds)} delete and '
        f'{len(set_cmds)} set commands'
    )

    if not commands:
        return []

    response = provider.http_service.send_request(
        action=Action.CONFIGURE,
        data=commands,
        verify=False,
    ).json()
    if response.get('success') is not True:
        return Exception(response.get('error') or 'Failed to update system email configuration')

    _emit_success(
        username,
        title='Success: Update Email',
        content='System email is successfully updated',
    )
    return [{'cmd': commands, 'success': True, 'error': response.get('error')}]


def verify_email(provider, data: dict):
    verify_service = getattr(provider, 'verify_service', None)
    if verify_service is None or not hasattr(verify_service, 'call_verify'):
        raise RuntimeError('System email verification is unavailable')

    locations = getattr(verify_service, '_locations', None)
    if isinstance(locations, dict) and 'email' not in locations:
        raise RuntimeError('System email verifier is not registered')

    return verify_service.call_verify('email', data)


def send_test_email(provider, data: dict):
    message = str(data.get('message') or '')
    if not message.strip():
        raise ValueError('Test email message is required')

    command = EmailCommand.generate_test_email(message)
    response = provider.http_service.send_request(
        action=Action.GENERATE,
        data=command,
        verify=False,
    )
    status_code = int(getattr(response, 'status_code', 200))

    try:
        response_body = response.json()
    except Exception:
        response_body = {'raw': str(getattr(response, 'text', ''))}

    response_success = not (
        isinstance(response_body, dict)
        and response_body.get('success') is False
    )
    return {
        'success': status_code < 400 and response_success,
        'statusCode': status_code,
        'command': f'generate test-email message {message}',
        'response': response_body,
    }
