from app.core.api.http.http_request import Action
from app.core.login.command import LoginCommand
from app.core.api.http.cmd.command import SHOW_LOGIN_CONFIG
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.core.login.db_models import SystemLoginOptions
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
from app.log.logger import logger
from app.core.api.http.srv.user_management import update_linux_user
import pprint

def fetch_login_config(provider, data):
    resp = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_LOGIN_CONFIG,
        verify=False
    )

    resp_json = resp.json()
    if resp_json.get("success") != True:
        raise Exception(f"{resp_json.get('error', 'Unknown error')}")
    
    resp_data = resp_json.get('data')
    return resp_data

def verify_login_config(provider, data):
    pass

def update_login_config(provider, data):
    logger.info("Update System Login:")
    logger.info(data)

    username = session.get('username')
    config = data.get('new')
    current_login_config = data.get('current')
    diff = data.get('diff')
    current_db_config = data.get('current_db')

    set_cmds = []
    login_set_cmd = LoginCommand(operator='set', resource='system')
    set_cmds = login_set_cmd.generate_commands(diff['created'], current_login_config, config)
    sc = login_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    delete_cmds = []
    login_delete_cmd = LoginCommand(operator='delete', resource='system')
    delete_cmds = login_delete_cmd.generate_commands(diff['deleted'], current_login_config, config)
    dc = login_delete_cmd.get_commands()
    print("Delete commands:")
    print(pprint.pformat(dc))
    new_del_configs = process_commands(dc)

    print("New del config:")
    print(pprint.pformat(new_del_configs))

    service = "system_login"
    curr_config = provider.verify_service.call_get_config(service)
    live_config = {"system": {"login": curr_config}} if curr_config else {"system": {"login": {}}}

    merged_del_config = merge_dicts_delete(live_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    update_linux_user(diff['created'], diff['deleted'], current_db_config)

    try:
        login_cfg = None
        if isinstance(config, dict):
            login_cfg = config.get('system', {}).get('login')
        if isinstance(login_cfg, dict):
            SystemLoginOptions.refresh(login_cfg)
    except Exception:
        pass

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update AAA",
            "content": "AAA configuration is successfully updated"
        }
    )

    r = []
    print("Commands: ")
    print(pprint.pformat(cmds))
    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res.get('success'), "error": res.get('error')})

    return r
