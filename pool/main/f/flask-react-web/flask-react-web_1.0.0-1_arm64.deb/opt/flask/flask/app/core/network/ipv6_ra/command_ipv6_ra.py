from app.core.api.http.cmd.command import Command
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']


def format_description(description: str) -> str:
    return description.replace(' ', '_')


class IPv6RACommand(Command):
    """
    IPv6 Router Advertisement command class:

    General configuration:
    - set/delete service router-advert interface <intf-name> auto-ignore <h:h:h:h:h:h:h:h/x>
    - set/delete service router-advert interface <intf-name> default-lifetime <seconds>
    - set/delete service router-advert interface <intf-name> default-preference { low | medium | high }
    - set/delete service router-advert interface <intf-name> hop-limit {0 | <1-255>}
    - set/delete service router-advert interface <intf-name> interval max <4-1800>
    - set/delete service router-advert interface <intf-name> interval min <3-1350>
    - set/delete service router-advert interface <intf-name> link-mtu <1280-9000>
    - set/delete service router-advert interface <intf-name> managed-flag
    - set/delete service router-advert interface <intf-name> name-server <address>
    - set/delete service router-advert interface <intf-name> name-server-lifetime <1-7200>
    - set/delete service router-advert interface <intf-name> no-send-advert
    - set/delete service router-advert interface <intf-name> no-send-interval
    - set/delete service router-advert interface <intf-name> other-config-flag
    - set/delete service router-advert interface <intf-name> prefix <h:h:h:h:h:h:h:h/x>
    - set/delete service router-advert interface <intf-name> reachable-time { 0 | <1-3600000> }
    - set/delete service router-advert interface <intf-name> retrans-timer { 0 | <1-4294967295> }
    - set/delete service router-advert interface <intf-name> source-address <h:h:h:h:h:h:h:h>

    Route configuration:
    - set/delete service router-advert interface <intf-name> route <h:h:h:h:h:h:h:h/x>
    - set/delete service router-advert interface <intf-name> route <h:h:h:h:h:h:h:h/x> no-remove-route
    - set/delete service router-advert interface <intf-name> route <h:h:h:h:h:h:h:h/x> route-preference { low | medium | high }
    - set/delete service router-advert interface <intf-name> route <h:h:h:h:h:h:h:h/x> valid-lifetime <seconds>
    """
    
    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'interface')
            )
            self.ifname = kwargs.get('ifname', None)
            self.attributes = {
                'service': {
                    'router-advert': {
                        'interface': {}
                    }
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing IPv6RA command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
    
    def get_all_commands(self):
        all_cmds = self.cmds.copy()
        return all_cmds
    
    def get_all_vyos_commands(self):
        all_vyos_cmds = self.vyos_cmds.copy()
        return all_vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            for intf_name, config in data.items():
                self._process_ipv6_ra_interface(intf_name, config, current_config, new_config)

            return self.get_all_commands()

        except Exception as e:
            print(f"Error generating IPv6RA commands: {e}")
            return []

    def _process_ipv6_ra_interface(self, intf_name, ra_config, current_config, new_config):
        base = ['service', 'router-advert', 'interface', intf_name]

        # delete entire interface
        if self.operator == 'delete' and intf_name not in new_config.get('interface', {}):
            self.generate(*base)
            return
        
        if 'auto-ignore' in ra_config:
            auto_ignore = ra_config['auto-ignore']
            if not isinstance(auto_ignore, list):
                auto_ignore = [auto_ignore]
            for prefix in auto_ignore:
                if is_str_not_empty(prefix):
                    self.generate(*base, 'auto-ignore', str(prefix))
        
        if 'default-lifetime' in ra_config:
            lifetime = ra_config['default-lifetime']
            if is_str_not_empty(lifetime):
                self.generate(*base, 'default-lifetime', str(lifetime))
        
        if 'default-preference' in ra_config:
            pref = ra_config['default-preference']
            if is_str_not_empty(pref):
                self.generate(*base, 'default-preference', str(pref))
        
        if 'hop-limit' in ra_config:
            hop_limit = ra_config['hop-limit']
            if is_str_not_empty(hop_limit):
                self.generate(*base, 'hop-limit', str(hop_limit))
        
        if 'interval' in ra_config and isinstance(ra_config['interval'], dict):
            if 'max' in ra_config['interval']:
                interval_max = ra_config['interval']['max']
                if is_str_not_empty(interval_max):
                    self.generate(*base, 'interval', 'max', str(interval_max))
            
            if 'min' in ra_config['interval']:
                interval_min = ra_config['interval']['min']
                if is_str_not_empty(interval_min):
                    self.generate(*base, 'interval', 'min', str(interval_min))
        
        if 'link-mtu' in ra_config:
            link_mtu = ra_config['link-mtu']
            if is_str_not_empty(link_mtu):
                self.generate(*base, 'link-mtu', str(link_mtu))
        
        if 'managed-flag' in ra_config:
            self.generate(*base, 'managed-flag')
        
        if 'name-server' in ra_config:
            name_servers = ra_config['name-server']
            if not isinstance(name_servers, list):
                name_servers = [name_servers]
            for ns in name_servers:
                if is_str_not_empty(ns):
                    self.generate(*base, 'name-server', str(ns))
        
        if 'name-server-lifetime' in ra_config:
            ns_lifetime = ra_config['name-server-lifetime']
            if is_str_not_empty(ns_lifetime):
                self.generate(*base, 'name-server-lifetime', str(ns_lifetime))
        
        if 'no-send-advert' in ra_config:
            self.generate(*base, 'no-send-advert')
        
        if 'no-send-interval' in ra_config:
            self.generate(*base, 'no-send-interval')
        
        if 'other-config-flag' in ra_config:
            self.generate(*base, 'other-config-flag')
        
        if 'prefix' in ra_config:
            prefixes = ra_config['prefix']
            if isinstance(prefixes, dict):
                # VyOS format: {'prefix': {'::/64': {config}, '2001:db8::/64': {config}}}
                for prefix_key, prefix_config in prefixes.items():
                    if is_str_not_empty(prefix_key):
                        prefix_base = base + ['prefix', str(prefix_key)]
                        self.generate(*prefix_base)
                        
                        if isinstance(prefix_config, dict):
                            if 'decrement-lifetime' in prefix_config:
                                self.generate(*prefix_base, 'decrement-lifetime')
                            
                            if 'deprecate-prefix' in prefix_config:
                                self.generate(*prefix_base, 'deprecate-prefix')
                            
                            if 'no-autonomous-flag' in prefix_config:
                                self.generate(*prefix_base, 'no-autonomous-flag')
                            
                            if 'no-on-link-flag' in prefix_config:
                                self.generate(*prefix_base, 'no-on-link-flag')
                            
                            if 'preferred-lifetime' in prefix_config:
                                pref_lifetime = prefix_config['preferred-lifetime']
                                if is_str_not_empty(pref_lifetime):
                                    self.generate(*prefix_base, 'preferred-lifetime', str(pref_lifetime))
                            
                            if 'valid-lifetime' in prefix_config:
                                valid_lifetime = prefix_config['valid-lifetime']
                                if is_str_not_empty(valid_lifetime):
                                    self.generate(*prefix_base, 'valid-lifetime', str(valid_lifetime))
            elif isinstance(prefixes, list):
                # List format: ['::/64', '2001:db8::/64']
                for prefix in prefixes:
                    if is_str_not_empty(prefix):
                        self.generate(*base, 'prefix', str(prefix))
            elif is_str_not_empty(prefixes):
                # Single string format
                self.generate(*base, 'prefix', str(prefixes))
        
        if 'reachable-time' in ra_config:
            reachable_time = ra_config['reachable-time']
            if is_str_not_empty(reachable_time):
                self.generate(*base, 'reachable-time', str(reachable_time))
        
        if 'retrans-timer' in ra_config:
            retrans_timer = ra_config['retrans-timer']
            if is_str_not_empty(retrans_timer):
                self.generate(*base, 'retrans-timer', str(retrans_timer))
        
        if 'source-address' in ra_config:
            source_addrs = ra_config['source-address']
            if not isinstance(source_addrs, list):
                source_addrs = [source_addrs]
            for addr in source_addrs:
                if is_str_not_empty(addr):
                    self.generate(*base, 'source-address', str(addr))
        
        if 'route' in ra_config:
            routes = ra_config['route']
            if isinstance(routes, dict):
                for route_prefix, route_config in routes.items():
                    self._process_route(base, route_prefix, route_config)
            elif isinstance(routes, list):
                for route_prefix in routes:
                    if is_str_not_empty(route_prefix):
                        self.generate(*base, 'route', str(route_prefix))

    def _process_route(self, base, route_prefix, route_config):
        route_base = base + ['route', str(route_prefix)]
        
        self.generate(*route_base)
        
        if isinstance(route_config, dict):
            if 'no-remove-route' in route_config:
                self.generate(*route_base, 'no-remove-route')
            
            if 'route-preference' in route_config:
                route_pref = route_config['route-preference']
                if is_str_not_empty(route_pref):
                    self.generate(*route_base, 'route-preference', str(route_pref))
            
            if 'valid-lifetime' in route_config:
                valid_lifetime = route_config['valid-lifetime']
                if is_str_not_empty(valid_lifetime):
                    self.generate(*route_base, 'valid-lifetime', str(valid_lifetime))