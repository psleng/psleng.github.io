from app.core.operation.ip_options.parser import parse_to_ip_options_vyos_config
from app.core.operation.dhcp_options.parser import parse_to_dhcp_options_vyos_config


def has_value(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']


def parse_to_vlan_config(config):
    """
    Input: UpdateVlanInterfaceDTO 
    Output: Dict with interface names as keys and vif structure
    
    Example output:
    {
        'eth0': {
            'vif': {
                '10': {...}
            }
        }
    }
    """
    vlan_config = {}
    
    groups = config.get('groups', [])
    
    for group in groups:
        members = group.get('members', [])
        
        for member in members:
            interface_name = member.get('interfaceName')
            vlan_id = member.get('vlanId')
            
            if not interface_name or not vlan_id:
                continue
            
            if interface_name not in vlan_config:
                vlan_config[interface_name] = {'vif': {}}
            
            if 'vif' not in vlan_config[interface_name]:
                vlan_config[interface_name]['vif'] = {}
            
            vif_config = {}
            
            addresses = []
            
            ipv4_mode = member.get('ipv4Mode', 'static')
            if ipv4_mode == 'dhcp':
                addresses.append('dhcp')
            elif ipv4_mode == 'static' and member.get('ipv4Address'):
                addresses.append(member['ipv4Address'])
            
            ipv6_mode = member.get('ipv6Mode', 'static')
            if ipv6_mode == 'dhcpv6':
                addresses.append('dhcpv6')
            elif ipv6_mode == 'autoconf':
                pass
            elif ipv6_mode == 'static' and member.get('ipv6Address'):
                addresses.append(member['ipv6Address'])
            
            if member.get('address'):
                addr = member['address']
                if isinstance(addr, list):
                    for a in addr:
                        if a not in addresses:
                            addresses.append(a)
                elif addr not in addresses:
                    addresses.append(addr)
            
            if addresses:
                vif_config['address'] = addresses
            
            if member.get('description'):
                vif_config['description'] = member['description']
            
            if has_value(member.get('mtu')):
                vif_config['mtu'] = member['mtu']
            
            if member.get('disabled') is not None and member['disabled']:
                vif_config['disable'] = {}
            
            ip_config = member.get('ip')
            if ip_config:
                ip_section, ipv6_section = parse_to_ip_options_vyos_config(ip_config)
                if ip_section:
                    vif_config['ip'] = ip_section
                if ipv6_section:
                    vif_config['ipv6'] = ipv6_section
            
            dhcp_config = member.get('dhcp')
            if dhcp_config:
                dhcp_section, dhcpv6_section = parse_to_dhcp_options_vyos_config(dhcp_config)
                if dhcp_section:
                    vif_config['dhcp-options'] = dhcp_section
                if dhcpv6_section:
                    vif_config['dhcpv6-options'] = dhcpv6_section
            
            vlan_config[interface_name]['vif'][vlan_id] = vif_config
    
    return vlan_config


def parse_current_vlan_interface_config(config):
    """
    Input: vyos config dictionary
    Output: Dict with interface names and their vif configurations
    
    Example output:
    {
        'eth0': {
            'vif': {
                '10': {...},
                '20': {...}
            }
        }
    }
    """
    vlan_config = {}
    
    interfaces = config.get('interfaces', {})
    ethernet = interfaces.get('ethernet', {})
    
    for interface_name, interface_data in ethernet.items():
        if 'vif' in interface_data and interface_data['vif']:
            vlan_config[interface_name] = {
                'vif': interface_data['vif']
            }
        else:
            vlan_config[interface_name] = {
                'vif': {}
            }
    
    return vlan_config
