import json

from app.core.api.http.cmd.command import Command


class AMPCommand(Command):

    BASE_PATH = ('service', 'sla')
    SERVERS = {'owamp-server': 861, 'twamp-server': 862}

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'amp'),
        )
        if self.operator not in ('set', 'delete'):
            raise ValueError('AMP commands support only set and delete operations.')

    def generate(self, *path):
        self.commands.append(json.dumps({'op': self.operator, 'path': list(path)}))
        self.vyos_commands.append(' '.join(path))

    def get_commands(self):
        return self.vyos_commands

    def generate_commands(self, data=None, current_config=None, new_config=None):
        
        current = current_config or {}
        new = (data or {}) if new_config is None else new_config
        self.commands = []
        self.vyos_commands = []

        for name in self.SERVERS:
            path = (*self.BASE_PATH, name)
            old_port = current.get(name, {}).get('port')
            port = new.get(name, {}).get('port')

            if self.operator == 'delete':
                if name in current and name not in new:
                    self.generate(*path)
                elif name in new and port is None and old_port is not None:
                    self.generate(*path, 'port')
            elif name in new:
                if name not in current:
                    self.generate(*path)
                if port is not None and str(port) != str(old_port):
                    self.generate(*path, 'port', str(port))

        return self.commands
