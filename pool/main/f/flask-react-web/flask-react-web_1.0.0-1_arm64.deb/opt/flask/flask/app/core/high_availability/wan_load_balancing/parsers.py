def has_value(value):
    return value is not None and str(value).strip() not in ["", "None", "null", "NaN", "nan"]


def parse_to_vyos_config(data):
    config = {}

    interface_health = {}
    for item in data.get("interfaceHealth") or []:
        name = item.get("interfaceName")
        if not has_value(name):
            continue

        item_config = {}
        if has_value(item.get("nexthop")):
            item_config["nexthop"] = str(item["nexthop"])
        if has_value(item.get("failureCount")):
            item_config["failure-count"] = str(item["failureCount"])
        if has_value(item.get("successCount")):
            item_config["success-count"] = str(item["successCount"])

        tests = {}
        for test in item.get("tests") or []:
            test_number = test.get("testNumber")
            if not has_value(test_number):
                continue
            test_config = {}
            if has_value(test.get("respTime")):
                test_config["resp-time"] = str(test["respTime"])
            if has_value(test.get("target")):
                test_config["target"] = str(test["target"])
            if has_value(test.get("ttlLimit")):
                test_config["ttl-limit"] = str(test["ttlLimit"])
            if has_value(test.get("type")):
                test_config["type"] = str(test["type"])
            if has_value(test.get("testScript")):
                test_config["test-script"] = str(test["testScript"])
            tests[str(test_number)] = test_config

        if tests:
            item_config["test"] = tests
        interface_health[str(name)] = item_config

    if interface_health:
        config["interface-health"] = interface_health

    rules = {}
    for rule in data.get("rules") or []:
        rule_number = rule.get("ruleNumber")
        if not has_value(rule_number):
            continue

        rule_config = {}
        if has_value(rule.get("description")):
            rule_config["description"] = str(rule["description"])
        if has_value(rule.get("inboundInterface")):
            rule_config["inbound-interface"] = str(rule["inboundInterface"])

        interfaces = {}
        for intf in rule.get("interfaces") or []:
            name = intf.get("interfaceName")
            if not has_value(name):
                continue
            intf_config = {}
            if has_value(intf.get("weight")):
                intf_config["weight"] = str(intf["weight"])
            interfaces[str(name)] = intf_config
        if interfaces:
            rule_config["interface"] = interfaces

        if rule.get("exclude"):
            rule_config["exclude"] = {}
        if rule.get("failover"):
            rule_config["failover"] = {}
        if rule.get("perPacketBalancing"):
            rule_config["per-packet-balancing"] = {}
        if has_value(rule.get("protocol")):
            rule_config["protocol"] = str(rule["protocol"])

        source = rule.get("source") or {}
        source_config = {}
        if has_value(source.get("address")):
            source_config["address"] = str(source["address"])
        if has_value(source.get("port")):
            source_config["port"] = str(source["port"])
        if source_config:
            rule_config["source"] = source_config

        destination = rule.get("destination") or {}
        destination_config = {}
        if has_value(destination.get("address")):
            destination_config["address"] = str(destination["address"])
        if has_value(destination.get("port")):
            destination_config["port"] = str(destination["port"])
        if destination_config:
            rule_config["destination"] = destination_config

        rules[str(rule_number)] = rule_config

    if rules:
        config["rule"] = rules

    global_options = data.get("globalOptions") or {}
    if global_options.get("disableSourceNat"):
        config["disable-source-nat"] = {}
    if global_options.get("enableLocalTraffic"):
        config["enable-local-traffic"] = {}
    if global_options.get("flushConnections"):
        config["flush-connections"] = {}
    if global_options.get("stickyConnectionsInbound"):
        config["sticky-connections"] = {"inbound": {}}

    return config
