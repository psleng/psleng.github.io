from app.core.api.http.cmd.command import Command
import pprint

def format_description(description: str) -> str:

    return description.replace(' ', '_')

class WifiInterfaceCommand(Command):
    """
    Command class for Wifi Interface
    Support the following VyOS commands:
    VyOS commands

    - Set/delete system wireless country-code <country-code>
    - set/delete interfaces wireless wlan0 type access-point
    - Set/delete interfaces wireless <intf-name> disable
    - Set/delete interfaces wireless <intf-name> description <text>
    - Set/delete interfaces wireless <intf-name> ssid <ssid-name>
    - Set/delete interfaces wireless <intf-name> security wpa mode { wpa | wpa2 | wpa+wpa2 | wpa3 }
    - Set/delete interfaces wireless <intf-name> security wpa  cipher {GCMP | GCMP-256 | CCMP | CCMP-256 | TKIP}
    - Set/delete interfaces wireless <intf-name> disable-broadcast-ssid
    - Set/delete interfaces wireless <intf-name> isolate-stations
    - Set/delete interfaces wireless <intf-name> mgmt-frame-protection {disabled | optional | required}
    - Set/delete interfaces wireless <intf-name> max-stations <1-2007>
    - Set/delete interfaces wireless <intf-name> enable-bf-protection
    - set/delete interface bridge <bridge-intf-name> member interface <intf-name>
    - Set/delete interface <intf-type> <intf-name> address <ipv4/len>
    - Set/delete interface <intf-type> <intf-name> address dhcp
    - Set/delete interface <intf-type> <intf-name> dhcp-options client-id
    - Set/delete interface <intf-type> <intf-name> dhcp-options default-route-distance
    - Set/delete interface <intf-type> <intf-name> dhcp-options host-name
    - Set/delete interface <intf-type> <intf-name> dhcp-options mtu
    - Set/delete interface <intf-type> <intf-name> dhcp-options no-default-route
    - Set/delete interface <intf-type> <intf-name> dhcp-options reject
    - Set/delete interface <intf-type> <intf-name> dhcp-options user-class
    - Set/delete interface <intf-type> <intf-name> dhcp-options vendor-class-id
    - Set/delete interface <intf-type> <intf-name> address <ipv6/len>
    - Set/delete interface <intf-type> <intf-name> address dhcpv6
    - Set/delete interface <intf-type> <intf-name> dhcpv6-options duid 
    - Set/delete interface <intf-type> <intf-name> dhcpv6-options no-release
    - Set/delete interface <intf-type> <intf-name> dhcpv6-options parameters-only
    - Set/delete interface <intf-type> <intf-name> dhcpv6-options rapid-commit
    - Set/delete interface <intf-type> <intf-name> dhcpv6-options temporary

    // Access Control
    - Set/delete interface wireless <intf-name> security station-address mode {allow | deny}
    - Set/delete interface wireless <intf-name> security station-address {allow | deny} mac <mac-address>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'wifi'))
            self.attributes = {
                'system': {
                    'wireless': {
                        'country-code': None
                    }
                },
                'interfaces': {
                    'wireless': {}
                },
                'interface': {
                    'bridge': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing WiFi Interface command: {e}")

    def set_operator(self, operator:str):
        self.operator = operator
        return True

    def _build_command(self, *path_elements: str) -> str:
        """Build a command string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.cmds
    
    def _process_system_wireless(self, system_config):
        if 'wireless' in system_config and system_config['wireless']:
            wireless_config = system_config['wireless']
            if 'country-code' in wireless_config and wireless_config['country-code']:
                self.generate('system', 'wireless', 'country-code', wireless_config['country-code'])
            elif 'country_code' in wireless_config and wireless_config['country_code']:
                self.generate('system', 'wireless', 'country-code', wireless_config['country_code'])
    
    def _process_wireless_security(self, base_path, intf_name, security_config):
        if 'wpa' in security_config:
            wpa_config = security_config['wpa']
            if 'passphrase' in wpa_config and isinstance(wpa_config['passphrase'], str) and wpa_config['passphrase'].strip() != "":
                self.generate(*base_path, 'security', 'wpa', 'passphrase', wpa_config['passphrase'])
            if 'mode' in wpa_config and self.operator == 'set':
                # Allow wlan0 and wlan1 mode to be changable
                self.generate(*base_path, 'security', 'wpa', 'mode', wpa_config['mode'])
            if 'cipher' in wpa_config: 
                if isinstance(wpa_config['cipher'], list):
                    for c in wpa_config['cipher']:
                        self.generate(*base_path, 'security', 'wpa', 'cipher', c)
                else:
                    self.generate(*base_path, 'security', 'wpa', 'cipher', wpa_config['cipher'])
            # Access control
        if 'station-address' in security_config and isinstance(security_config['station-address'], dict):
            access_control_mode = security_config['station-address'].get('mode', "")
            access_control_accept_list = security_config['station-address'].get('accept', {}).get('mac', [])
            access_control_deny_list = security_config['station-address'].get('deny', {}).get('mac', [])
            
            if access_control_mode == 'accept' or access_control_mode == 'deny':
                self.generate(*base_path, 'security', 'station-address', 'mode', access_control_mode)

            if isinstance(access_control_accept_list, str):
                self.generate(*base_path, 'security', 'station-address', 'accept', 'mac', access_control_accept_list)
            elif isinstance(access_control_accept_list, list):
                for mac_addr in access_control_accept_list:
                    self.generate(*base_path, 'security', 'station-address', 'accept', 'mac', mac_addr)
            
            if isinstance(access_control_deny_list, str):
                self.generate(*base_path, 'security', 'station-address', 'deny', 'mac', access_control_deny_list)
            elif isinstance(access_control_deny_list, list):
                for mac_addr in access_control_deny_list:
                    self.generate(*base_path, 'security', 'station-address', 'deny', 'mac', mac_addr)
    
    def _process_dhcp_options(self, base_path, dhcp_options):
        option_mappings = {
            'client-id': ['client-id', 'client_id'],
            'default-route-distance': ['default-route-distance', 'default_route_distance'],
            'host-name': ['host-name', 'host_name'],
            'mtu': ['mtu'],
            'no-default-route': ['no-default-route', 'no_default_route'],
            'reject': ['reject'],
            'user-class': ['user-class', 'user_class'],
            'vendor-class-id': ['vendor-class-id', 'vendor_class_id']
        }
        
        for option_name, key_variants in option_mappings.items():
            for key in key_variants:
                if key in dhcp_options:
                    value = dhcp_options[key]
                    if isinstance(value, bool):
                        if value:
                            self.generate(*base_path, 'dhcp-options', option_name)
                    else:
                        self.generate(*base_path, 'dhcp-options', option_name, value)
                    break
    
    def _process_dhcpv6_options(self, base_path, dhcpv6_options):
        option_mappings = {
            'duid': ['duid'],
            'no-release': ['no-release', 'no_release'],
            'parameters-only': ['parameters-only', 'parameters_only'],
            'rapid-commit': ['rapid-commit', 'rapid_commit'],
            'temporary': ['temporary']
        }
        
        for option_name, key_variants in option_mappings.items():
            for key in key_variants:
                if key in dhcpv6_options:
                    value = dhcpv6_options[key]
                    if isinstance(value, bool) or value == {}:
                        if value is True or value == {}:
                            self.generate(*base_path, 'dhcpv6-options', option_name)
                    else:
                        self.generate(*base_path, 'dhcpv6-options', option_name, value)
                    break

    
    def _process_wireless_interface(self, intf_name, intf_config):
        base_path = ['interfaces', 'wireless', intf_name]
        
        # DO NOT LET GUI TO CHANGE type access-point/station
        # if 'type' in intf_config:
        #     self.generate(*base_path, 'type', intf_config['type'])
        
        if 'disable' in intf_config:
            self.generate(*base_path, 'disable')
        
        if 'mode' in intf_config and intf_name == 'wlan0' and \
            self.operator == 'set' and intf_config['mode'] in ['ac', 'ax']:
            # Only allow wlan0 mode to be "set"
            # And mode can only be ac or ax
            self.generate(*base_path, 'mode', intf_config['mode'])
        
        if 'description' in intf_config and intf_config['description']:
            self.generate(*base_path, 'description', format_description(intf_config['description']))
        
        if 'ssid' in intf_config and intf_config['ssid']:
            self.generate(*base_path, 'ssid', intf_config['ssid'])

        if 'address' in intf_config:
            addresses = intf_config['address']
            if not isinstance(addresses, list):
                addresses = [addresses]
            for address in addresses:
                self.generate(*base_path, 'address', address)
        
        if 'security' in intf_config:
            self._process_wireless_security(base_path, intf_name, intf_config['security'])

        disable_broadcast_ssid = intf_config.get('disable-broadcast-ssid', None)
        if disable_broadcast_ssid is None:
            disable_broadcast_ssid = intf_config.get('disable_broadcast_ssid', None)
        if (disable_broadcast_ssid is not None) and (isinstance(disable_broadcast_ssid, dict) or bool(disable_broadcast_ssid)):
            self.generate(*base_path, 'disable-broadcast-ssid')
        
        if 'isolate-stations' in intf_config:
            self.generate(*base_path, 'isolate-stations')
        
        if 'mgmt-frame-protection' in intf_config:
            self.generate(*base_path, 'mgmt-frame-protection', intf_config['mgmt-frame-protection'])
        elif 'mgmt_frame_protection' in intf_config:
            self.generate(*base_path, 'mgmt-frame-protection', intf_config['mgmt_frame_protection'])
        
        if 'max-stations' in intf_config:
            self.generate(*base_path, 'max-stations', intf_config['max-stations'])
        elif 'max_stations' in intf_config:
            self.generate(*base_path, 'max-stations', intf_config['max_stations'])
        
        enable_bf_protection = intf_config.get('enable-bf-protection', None)
        if enable_bf_protection is None:
            enable_bf_protection = intf_config.get('enable_bf_protection', None)
        if (enable_bf_protection is not None) and (isinstance(enable_bf_protection, dict) or bool(enable_bf_protection)):
            self.generate(*base_path, 'enable-bf-protection')
        
        if 'dhcp-options' in intf_config:
            self._process_dhcp_options(
                ['interfaces', 'wireless', intf_name],
                intf_config['dhcp-options']
            )

        if 'dhcpv6-options' in intf_config:
            self._process_dhcpv6_options(base_path, intf_config['dhcpv6-options'])

        if 'autoconf' in intf_config.get('ipv6', {}).get('address', {}):
            self.generate(*base_path, 'ipv6', 'address', 'autoconf')
        
        if 'network' in intf_config:
            network_config = intf_config['network']
            
            # if 'bridgeMode' in network_config and network_config['bridgeMode'] and 'bridgeInterface' in network_config:
            #     bridge_name = network_config['bridgeInterface']
            #     self.generate('interface', 'bridge', bridge_name, 'member', 'interface', intf_name)
            
            if 'ipv4' in network_config:
                ipv4_config = network_config['ipv4']
                
                if 'staticAddress' in ipv4_config and ipv4_config['staticAddress']:
                    self.generate('interface', 'wireless', intf_name, 'address', ipv4_config['staticAddress'])
                
            
            if 'ipv6' in network_config:
                ipv6_config = network_config['ipv6']
                
                if 'staticAddress' in ipv6_config and ipv6_config['staticAddress']:
                    self.generate('interface', 'wireless', intf_name, 'address', ipv6_config['staticAddress'])
                
                if 'dhcpv6' in ipv6_config and ipv6_config['dhcpv6']:
                    self.generate('interface', 'wireless', intf_name, 'address', 'dhcpv6')
                    
                    if 'dhcpv6Options' in ipv6_config and ipv6_config['dhcpv6Options']:
                        self._process_dhcpv6_options(
                            ['interface', 'wireless', intf_name],
                            ipv6_config['dhcpv6Options']
                        )
        
        if 'capabilities' in intf_config:
            self._process_capabilities(intf_name, intf_config['capabilities'], 'normal')
        

    def generate_fixed_network_commands(self):
        
        if self.operator == "set":
            # Bridge
            self.generate('interfaces', 'bridge', 'br1', 'member', 'interface', 'wlan0')
            self.generate('interfaces', 'bridge', 'br1', 'member', 'interface', 'wlan1')
            self.generate('interfaces', 'bridge', 'br1', 'address', '192.168.1.1/24')

            # DHCP-Server
            self.generate('service', 'dhcp-server', 'listen-interface', 'br1')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'lease', '86400')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'option', 'default-router', '192.168.1.1')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'option', 'name-server', '192.168.1.1')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'range', 'range_1', 'start', '192.168.1.1')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'range', 'range_1', 'stop', '192.168.1.254')
            self.generate('service', 'dhcp-server', 'shared-network-name', 'default-dhcp-pool', 'subnet', '192.168.1.0/24', 'subnet-id', '1')
        
        return None
    
    def _process_capabilities(self, intf_name, capabilities, setup='normal'):
        """Process fixed capabilities configuration for wireless interfaces"""
        base_path = ['interfaces', 'wireless', intf_name]

        if 'he' in capabilities:
            he_config = capabilities['he']
            he_base = base_path + ['capabilities', 'he']

            """ lnguyen: Commented out since this makes system unstable
            if 'channel-set-width' in he_config:
                widths = he_config['channel-set-width']
                if isinstance(widths, list):
                    for width in widths:
                        self.generate(*(he_base + ['channel-set-width', width]))
                else:
                    self.generate(*(he_base + ['channel-set-width', widths]))
            """
            
        if 'ht' in capabilities:
            ht_config = capabilities['ht']
            ht_base = base_path + ['capabilities', 'ht']
            
            if 'channel-set-width' in ht_config:
                widths = ht_config['channel-set-width']
                if isinstance(widths, list):
                    for width in widths:
                        self.generate(*(ht_base + ['channel-set-width', width]))
                else:
                    self.generate(*(ht_base + ['channel-set-width', widths]))
            
            if 'ldpc' in ht_config and setup == 'fixed':
                self.generate(*(ht_base + ['ldpc']))
            
            if 'short-gi' in ht_config and setup == 'fixed':
                gi_values = ht_config['short-gi']
                if isinstance(gi_values, list):
                    for gi in gi_values:
                        self.generate(*(ht_base + ['short-gi', gi]))
                else:
                    self.generate(*(ht_base + ['short-gi', gi_values]))
            
            if 'stbc' in ht_config and setup == 'fixed':
                stbc = ht_config['stbc']
                if 'rx' in stbc:
                    self.generate(*(ht_base + ['stbc', 'rx', stbc['rx']]))
                if 'tx' in stbc:
                    self.generate(*(ht_base + ['stbc', 'tx']))
        
        if 'vht' in capabilities:
            vht_config = capabilities['vht']
            vht_base = base_path + ['capabilities', 'vht']
            
            if 'antenna-count' in vht_config and setup == 'fixed':
                self.generate(*(vht_base + ['antenna-count', vht_config['antenna-count']]))
            
            if 'antenna-pattern-fixed' in vht_config and setup == 'fixed':
                self.generate(*(vht_base + ['antenna-pattern-fixed']))
            
            if 'center-channel-freq' in vht_config and setup == 'fixed':
                self.generate(*(vht_base + ['center-channel-freq']))
            
            if 'channel-set-width' in vht_config:
                self.generate(*(vht_base + ['channel-set-width', vht_config['channel-set-width']]))
            
            if 'ldpc' in vht_config and setup == 'fixed':
                self.generate(*(vht_base + ['ldpc']))
            
            if 'short-gi' in vht_config and setup == 'fixed':
                gi_values = vht_config['short-gi']
                if isinstance(gi_values, list):
                    for gi in gi_values:
                        self.generate(*(vht_base + ['short-gi', gi]))
                else:
                    self.generate(*(vht_base + ['short-gi', gi_values]))
            
            if 'stbc' in vht_config and setup == 'fixed':
                stbc = vht_config['stbc']
                if 'rx' in stbc:
                    self.generate(*(vht_base + ['stbc', 'rx', stbc['rx']]))
                if 'tx' in stbc:
                    self.generate(*(vht_base + ['stbc', 'tx']))

    def _process_fixed_configs(self, fixed_data):
        """Process fixed configuration data"""
        if not fixed_data or 'interfaces' not in fixed_data or 'wireless' not in fixed_data['interfaces']:
            return
            
        wireless_configs = fixed_data['interfaces']['wireless']
        for intf_name, intf_config in wireless_configs.items():
            base_path = ['interfaces', 'wireless', intf_name]
            
            if 'type' in intf_config:
                self.generate(*(base_path + ['type', intf_config['type']]))
            
            if 'channel' in intf_config:
                self.generate(*(base_path + ['channel', intf_config['channel']]))
            
            if 'mode' in intf_config:
                self.generate(*(base_path + ['mode', intf_config['mode']]))
            
            if 'max-stations' in intf_config:
                self.generate(*(base_path + ['max-stations', intf_config['max-stations']]))
            
            if 'isolate-stations' in intf_config:
                self.generate(*base_path, 'isolate-stations')
            
            if 'stationary-ap' in intf_config:
                self.generate(*base_path, 'stationary-ap')
            
            if 'physical-device' in intf_config:
                self.generate(*(base_path + ['physical-device', intf_config['physical-device']]))
            
            if 'capabilities' in intf_config:
                self._process_capabilities(intf_name, intf_config['capabilities'], 'fixed')
            
            if 'security' in intf_config and 'wpa' in intf_config['security']:
                wpa_config = intf_config['security']['wpa']
                wpa_base = base_path + ['security', 'wpa']
                
                if 'mode' in wpa_config:
                    self.generate(*(wpa_base + ['mode', wpa_config['mode']]))
                
                if 'cipher' in wpa_config:
                    ciphers = wpa_config['cipher']
                    if isinstance(ciphers, list):
                        for cipher in ciphers:
                            self.generate(*(wpa_base + ['cipher', cipher]))
                    else:
                        self.generate(*(wpa_base + ['cipher', ciphers]))

    def generate_commands(self, data, current_config, new_config):
        """
        Generate VyOS commands for WiFi interface configuration
        
        Input format example:
        {
            'system': {
                'wireless': {
                    'country-code': 'US'
                }
            },
            'interfaces': {
                'wireless': {
                    'wlan0': {
                        'type': 'access-point',
                        'description': 'WiFi AP 2.4GHz',
                        'ssid': 'MyNetwork',
                        'security': {
                            'wpa': {
                                'mode': 'wpa2',
                                'cipher': 'CCMP'
                            }
                        },
                        'disable-broadcast-ssid': False,
                        'isolate-stations': True,
                        'mgmt-frame-protection': 'optional',
                        'max-stations': 64,
                        'enable-bf-protection': True,
                        'network': {
                            'bridgeMode': True,
                            'bridgeInterface': 'br0',
                            'ipv4': {
                                'staticAddress': '192.168.1.1/24',
                                'dhcp': True,
                                'dhcpOptions': {
                                    'client_id': 'wifi-ap',
                                    'default_route_distance': 10,
                                    'host_name': 'wifi-ap',
                                    'no_default_route': True,
                                    'user_class': 'wifi',
                                    'vendor_class_id': 'wifi-ap'
                                }
                            },
                            'ipv6': {
                                'staticAddress': '2001:db8::1/64',
                                'dhcpv6': True,
                                'dhcpv6Options': {
                                    'duid': 'wifi-ap',
                                    'no_release': True,
                                    'parameters_only': True,
                                    'rapid_commit': True,
                                    'temporary': True
                                }
                            }
                        }
                    }
                }
            }
        }
        """
        if not data:
            return []

        # Fixed commands
        if isinstance(data, dict) and 'fixed_configs' in data:
            self._process_fixed_configs(data['fixed_configs'])
        if 'system' in data:
            self._process_system_wireless(data['system'])
        
        if 'interfaces' in data and 'wireless' in data['interfaces']:
            for intf_name, intf_config in data['interfaces']['wireless'].items():
                self._process_wireless_interface(intf_name, intf_config)
        
        return self.get_commands()


if __name__ == "__main__":
    test_data = {
        'system': {
            'wireless': {
                'country-code': 'US'
            }
        },
        'interfaces': {
            'wireless': {
                'wlan0': {
                    'type': 'access-point',
                    'description': 'WiFi AP 2.4GHz',
                    'ssid': 'MyNetwork',
                    'security': {
                        'wpa': {
                            'mode': 'wpa2',
                            'cipher': 'CCMP'
                        }
                    },
                    'disable_broadcast_ssid': True,
                    'isolate_stations': True,
                    'mgmt_frame_protection': 'optional',
                    'max_stations': 64,
                    'enable_bf_protection': True,
                    'network': {
                        'bridgeMode': True,
                        'bridgeInterface': 'br0',
                        'ipv4': {
                            'staticAddress': '192.168.1.1/24',
                            'dhcp': True,
                            'dhcpOptions': {
                                'client_id': 'wifi-ap',
                                'default_route_distance': 10,
                                'host_name': 'wifi-ap',
                                'no_default_route': True,
                                'user_class': 'wifi',
                                'vendor_class_id': 'wifi-ap'
                            }
                        },
                        'ipv6': {
                            'staticAddress': '2001:db8::1/64',
                            'dhcpv6': True,
                            'dhcpv6Options': {
                                'duid': 'wifi-ap',
                                'no_release': True,
                                'parameters_only': True,
                                'rapid_commit': True,
                                'temporary': True
                            }
                        }
                    }
                }
            }
        }
    }
    
    wifi_cmd = WifiInterfaceCommand(operator='set')
    commands = wifi_cmd.generate_commands(test_data)
    
    print("Generated VyOS commands:")
    for cmd in commands:
        print(f"  {cmd}")
