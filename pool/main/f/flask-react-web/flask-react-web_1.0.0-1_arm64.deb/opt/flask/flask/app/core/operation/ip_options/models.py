from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean
import json

class IPv4OptionConfig(db.Model):
    __tablename__ = 'vyos_config_ipv4_option'

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_type = Column(String(50), nullable=False)  
    interface_name = Column(String(50), nullable=False)  
    vlan_id = Column(String(10), nullable=True)  
    
    adjust_mss = Column(String(50), nullable=True) 
    arp_cache_timeout = Column(Integer, nullable=True) 
    disable_arp_filter = Column(Boolean, default=False)
    disable_forwarding = Column(Boolean, default=False)
    enable_arp_accept = Column(Boolean, default=False)
    enable_arp_announce = Column(Boolean, default=False)
    enable_arp_ignore = Column(Boolean, default=False)
    enable_directed_broadcast = Column(Boolean, default=False)
    enable_proxy_arp = Column(Boolean, default=False)
    proxy_arp_pvlan = Column(Boolean, default=False)
    source_validation = Column(String(20), nullable=True)  

    @classmethod
    def truncate(cls):
        try:
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error truncating IPv4OptionConfig: {e}")

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            for intf_name, intf_config in config.items():
                if 'ip' in intf_config:
                    cls._create_from_config('ethernet', intf_name, None, intf_config['ip'])
                
                if 'vif' in intf_config:
                    for vlan_id, vlan_config in intf_config['vif'].items():
                        if 'ip' in vlan_config:
                            cls._create_from_config('ethernet', intf_name, vlan_id, vlan_config['ip'])
            
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing IPv4OptionConfig: {e}")
            raise e

    @classmethod
    def _create_from_config(cls, intf_type, intf_name, vlan_id, ip_config):
        new_config = cls(
            interface_type=intf_type,
            interface_name=intf_name,
            vlan_id=vlan_id,
            adjust_mss=ip_config.get('adjust-mss'),
            arp_cache_timeout=int(ip_config['arp-cache-timeout']) if 'arp-cache-timeout' in ip_config else None,
            disable_arp_filter='disable-arp-filter' in ip_config,
            disable_forwarding='disable-forwarding' in ip_config,
            enable_arp_accept='enable-arp-accept' in ip_config,
            enable_arp_announce='enable-arp-announce' in ip_config,
            enable_arp_ignore='enable-arp-ignore' in ip_config,
            enable_directed_broadcast='enable-directed-broadcast' in ip_config,
            enable_proxy_arp='enable-proxy-arp' in ip_config,
            proxy_arp_pvlan='proxy-arp-pvlan' in ip_config,
            source_validation=ip_config.get('source-validation')
        )
        db.session.add(new_config)

    def serialize(self):
        return {
            'id': self.id,
            'interface_type': self.interface_type,
            'interface_name': self.interface_name,
            'vlan_id': self.vlan_id,
            'adjust_mss': self.adjust_mss,
            'arp_cache_timeout': self.arp_cache_timeout,
            'disable_arp_filter': self.disable_arp_filter,
            'disable_forwarding': self.disable_forwarding,
            'enable_arp_accept': self.enable_arp_accept,
            'enable_arp_announce': self.enable_arp_announce,
            'enable_arp_ignore': self.enable_arp_ignore,
            'enable_directed_broadcast': self.enable_directed_broadcast,
            'enable_proxy_arp': self.enable_proxy_arp,
            'proxy_arp_pvlan': self.proxy_arp_pvlan,
            'source_validation': self.source_validation
        }
    
    def to_vyos_format(self):
        
        result = {}
        
        if self.adjust_mss:
            result['adjust-mss'] = self.adjust_mss
        if self.arp_cache_timeout:
            result['arp-cache-timeout'] = str(self.arp_cache_timeout)
        if self.disable_arp_filter:
            result['disable-arp-filter'] = {}
        if self.disable_forwarding:
            result['disable-forwarding'] = {}
        if self.enable_arp_accept:
            result['enable-arp-accept'] = {}
        if self.enable_arp_announce:
            result['enable-arp-announce'] = {}
        if self.enable_arp_ignore:
            result['enable-arp-ignore'] = {}
        if self.enable_directed_broadcast:
            result['enable-directed-broadcast'] = {}
        if self.enable_proxy_arp:
            result['enable-proxy-arp'] = {}
        if self.proxy_arp_pvlan:
            result['proxy-arp-pvlan'] = {}
        if self.source_validation:
            result['source-validation'] = self.source_validation
        
        return result


class IPv6OptionConfig(db.Model):
    __tablename__ = 'vyos_config_ipv6_option'

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_type = Column(String(50), nullable=False)
    interface_name = Column(String(50), nullable=False)
    vlan_id = Column(String(10), nullable=True)
    
    accept_dad = Column(Integer, nullable=True)  
    address_autoconf = Column(Boolean, default=False)
    address_eui64 = Column(String(100), nullable=True)  
    address_interface_identifier = Column(String(50), nullable=True)  
    address_no_default_link_local = Column(Boolean, default=False)
    adjust_mss = Column(String(50), nullable=True) 
    base_reachable_time = Column(Integer, nullable=True) 
    disable_forwarding = Column(Boolean, default=False)
    dup_addr_detect_transmits = Column(Integer, nullable=True) 
    source_validation = Column(String(20), nullable=True) 

    @classmethod
    def truncate(cls):
        try:
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error truncating IPv6OptionConfig: {e}")

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            for intf_name, intf_config in config.items():
                if 'ipv6' in intf_config:
                    cls._create_from_config('ethernet', intf_name, None, intf_config['ipv6'])
                
                if 'vif' in intf_config:
                    for vlan_id, vlan_config in intf_config['vif'].items():
                        if 'ipv6' in vlan_config:
                            cls._create_from_config('ethernet', intf_name, vlan_id, vlan_config['ipv6'])
            
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing IPv6OptionConfig: {e}")
            raise e

    @classmethod
    def _create_from_config(cls, intf_type, intf_name, vlan_id, ipv6_config):
        address_config = ipv6_config.get('address', {})
        
        eui64_value = address_config.get('eui64')
        if isinstance(eui64_value, list):
            eui64_value = eui64_value[0] if eui64_value else None
        
        new_config = cls(
            interface_type=intf_type,
            interface_name=intf_name,
            vlan_id=vlan_id,
            accept_dad=int(ipv6_config['accept-dad']) if 'accept-dad' in ipv6_config else None,
            address_autoconf='autoconf' in address_config,
            address_eui64=eui64_value,
            address_interface_identifier=address_config.get('interface-identifier'),
            address_no_default_link_local='no-default-link-local' in address_config,
            adjust_mss=ipv6_config.get('adjust-mss'),
            base_reachable_time=int(ipv6_config['base-reachable-time']) if 'base-reachable-time' in ipv6_config else None,
            disable_forwarding='disable-forwarding' in ipv6_config,
            dup_addr_detect_transmits=int(ipv6_config['dup-addr-detect-transmits']) if 'dup-addr-detect-transmits' in ipv6_config else None,
            source_validation=ipv6_config.get('source-validation')
        )
        db.session.add(new_config)

    def serialize(self):
        return {
            'id': self.id,
            'interface_type': self.interface_type,
            'interface_name': self.interface_name,
            'vlan_id': self.vlan_id,
            'accept_dad': self.accept_dad,
            'address_autoconf': self.address_autoconf,
            'address_eui64': self.address_eui64,
            'address_interface_identifier': self.address_interface_identifier,
            'address_no_default_link_local': self.address_no_default_link_local,
            'adjust_mss': self.adjust_mss,
            'base_reachable_time': self.base_reachable_time,
            'disable_forwarding': self.disable_forwarding,
            'dup_addr_detect_transmits': self.dup_addr_detect_transmits,
            'source_validation': self.source_validation
        }
    
    def to_vyos_format(self):
        
        result = {}
        
        if self.accept_dad is not None:
            result['accept-dad'] = str(self.accept_dad)
        
        if self.address_autoconf or self.address_eui64 or \
           self.address_interface_identifier or self.address_no_default_link_local:
            result['address'] = {}
            if self.address_autoconf:
                result['address']['autoconf'] = {}
            if self.address_eui64:
                result['address']['eui64'] = self.address_eui64
            if self.address_interface_identifier:
                result['address']['interface-identifier'] = self.address_interface_identifier
            if self.address_no_default_link_local:
                result['address']['no-default-link-local'] = {}
        
        if self.adjust_mss:
            result['adjust-mss'] = self.adjust_mss
        if self.base_reachable_time:
            result['base-reachable-time'] = str(self.base_reachable_time)
        if self.disable_forwarding:
            result['disable-forwarding'] = {}
        if self.dup_addr_detect_transmits is not None:
            result['dup-addr-detect-transmits'] = str(self.dup_addr_detect_transmits)
        if self.source_validation:
            result['source-validation'] = self.source_validation
        
        return result
