import json

from app.core.api.http.cmd.command import Command
from app.core.network.lldp.config import PROTOCOLS, as_list


class LLDPCommand(Command):

    BASE_PATH = ('service', 'lldp')

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'service'),
        )
        self.cmds = self.commands
        self.vyos_cmds = self.vyos_commands

    def _build_command(self, *path_elements):
        return json.dumps({'op': self.operator, 'path': list(path_elements)})

    def generate(self, *path_elements):
        self.cmds.append(self._build_command(*path_elements))
        self.vyos_cmds.append(' '.join(path_elements))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data:
            return []

        current_config = current_config or {}
        new_config = new_config or {}
        protocols = data.get('legacy-protocols') or {}
        for name in PROTOCOLS:
            if name in protocols:
                if self.operator == 'delete' and name in (new_config.get('legacy-protocols') or {}):
                    continue
                self.generate(*self.BASE_PATH, 'legacy-protocols', name)

        for address in as_list(data.get('management-address')):
            self.generate(*self.BASE_PATH, 'management-address', address)

        if 'snmp' in data and (self.operator != 'delete' or 'snmp' not in new_config):
            self.generate(*self.BASE_PATH, 'snmp')

        current_interfaces = current_config.get('interface') or {}
        new_interfaces = new_config.get('interface') or {}
        for name, config in (data.get('interface') or {}).items():
            path = (*self.BASE_PATH, 'interface', name)
            if self.operator == 'delete' and name not in new_interfaces:
                self.generate(*path)
                continue
            if self.operator == 'set' and name not in current_interfaces:
                self.generate(*path)
            if not isinstance(config, dict) or 'mode' not in config:
                continue
            if self.operator == 'delete':
                if 'mode' not in (new_interfaces.get(name) or {}):
                    self.generate(*path, 'mode')
            else:
                self.generate(*path, 'mode', config['mode'])

        return self.cmds
