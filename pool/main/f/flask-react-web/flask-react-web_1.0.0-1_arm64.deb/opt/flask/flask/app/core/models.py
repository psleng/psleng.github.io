import json
import re
import time
from contextlib import nullcontext

from requests.compat import integer_types

from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, Float, BigInteger
from collections import deque
from dataclasses import dataclass
from threading import RLock
from sqlalchemy import ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy import text
from typing import List
from pydantic import BaseModel, RootModel, field_validator, Field, ConfigDict
from typing import Optional
import pprint
from app.log.logger import logger
from app.core.utils.system_time import system_timestamp, system_utc_timestamp

VRRP_INTERFACE_NAME_PATTERN = re.compile(r'^[A-Za-z][A-Za-z0-9._:-]*\d+v\d+v\d+$')

def format_description(desc: str) -> str:
    if not desc:
        return ""
    return desc.replace('_', ' ')

def convert_str(data):
    if isinstance(data, int):
        return str(data)
    elif isinstance(data, str):
        return data
    elif isinstance(data, list):
        return ','.join(data)
    
class UpdateSelectedServicesDTO(BaseModel):
    selectedServices: List[str]

class Services(db.Model):
    __tablename__ = 'vyos_services'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False, unique=True)

    @classmethod
    def init_services(cls):
        db.session.add_all([
            Services(name='DHCP'),
            Services(name='NTP'),
            Services(name='DNS'),
            Services(name='NAT'),
            Services(name='Load Balancing'),
            Services(name='Firewall'),
            Services(name='Wireguard'),
            Services(name='VRRP'),
            Services(name='IPSEC'),
            Services(name='SNMP'),
            Services(name='OpenVPN')
        ])
        db.session.commit()

class AdminSelectedService(db.Model):
    __tablename__ = 'vyos_admin_selected_service'

    id = Column(Integer, primary_key=True)
    service_id = Column(
        Integer,
        ForeignKey('vyos_services.id', ondelete='CASCADE'),
        unique=True,
        nullable=False
    )

    service = relationship('Services')

    @classmethod
    def init_admin_services(cls):
        logger.debug("Initializing admin selected services...")
        default_services = ['DHCP', 'NTP', 'DNS', 'NAT', 'Load Balancing']

        services = Services.query.filter(Services.name.in_(default_services)).all()
        db.session.add_all([cls(service_id=s.id) for s in services])
        db.session.commit()

class SelectedServices(db.Model):
    __tablename__ = 'vyos_selected_services'

    id = Column(Integer, primary_key=True)
    user_id = Column(String, nullable=False, index=True)
    service_id = Column(
        Integer,
        ForeignKey('vyos_services.id', ondelete='CASCADE'),
        nullable=False
    )
    status = Column(String, nullable=False, default='disabled')

    service = relationship('Services')

    __table_args__ = (
        db.UniqueConstraint('user_id', 'service_id', name='uq_user_service'),
    )

class ServiceStatistic(db.Model):
    __tablename__ = 'vyos_service_statistic'

    id = Column(Integer, primary_key=True)
    service_id = Column(
        Integer,
        ForeignKey('vyos_services.id', ondelete='CASCADE'),
        nullable=False
    )
    service_feature = Column(String, nullable=False)
    service_stat = Column(String, nullable=False)

    service = relationship('Services')

    @classmethod
    def init_stat(cls):
        # Clear existing stats
        cls.query.delete()

        # Build service name → id map
        service_map = {
            service.name: service.id
            for service in Services.query.all()
        }

        stats = [
            # DHCP
            ('DHCP', 'active', '0'),
            ('DHCP', 'available', '0'),
            ('DHCP', 'lease_time', '0h'),

            # NTP
            ('NTP', 'stratum', '0'),
            ('NTP', 'offset', '0 ms'),
            ('NTP', 'leap_status', 'Normal'),

            # Firewall
            ('Firewall', 'accepted', '0'),
            ('Firewall', 'dropped', '0'),
            ('Firewall', 'total', '0'),

            # DNS
            ('DNS', 'servers', '0'),
            ('DNS', 'server_list', '[]'),

            # NAT
            ('NAT', 'source_packets', '0'),
            ('NAT', 'source_traffic', '0.0'),
            ('NAT', 'destination_packets', '0'),
            ('NAT', 'destination_traffic', '0.0'),

            # Load Balancing
            ('Load Balancing', 'up_interfaces', '[]'),
            ('Load Balancing', 'down_interfaces', '[]'),

            # VRRP
            ('VRRP', 'groups', '0'),
            ('VRRP', 'sync_groups', '0'),

            # Wireguard
            ('Wireguard', 'interfaces', '0'),
            ('Wireguard', 'peers', '0'),

            # IPSEC
            ('IPSEC', 'connections', '0'),
            ('IPSEC', 'sa', '0'),

            # OpenVPN
            ('OpenVPN', 'interfaces', '0'),
            ('OpenVPN', 'active_interfaces', '0'),

            # SNMP
            ('SNMP', 'interfaces', '0'),
            ('SNMP', 'packets', '0'),
            ('SNMP', 'traps', '0'),
        ]

        for service_name, feature, value in stats:
            service_id = service_map.get(service_name)
            if not service_id:
                continue 

            db.session.add(
                cls(
                    service_id=service_id,
                    service_feature=feature,
                    service_stat=value
                )
            )

        db.session.commit()
                    

    @classmethod
    def reset_by_service(cls, service_id: int):
        cls.query.filter_by(service_id=service_id).delete()
        db.session.commit()

    @classmethod
    def refresh_stats(cls, service_id: int, stats: dict):
        for feature, value in stats.items():
            record = cls.query.filter_by(
                service_id=service_id,
                service_feature=feature
            ).first()

            if record:
                if isinstance(value, list):
                    record.service_stat = json.dumps(value)
                else:
                    record.service_stat = str(value)
            else:
                if isinstance(value, list):
                    db.session.add(
                        cls(
                            service_id=service_id,
                            service_feature=feature,
                            service_stat=json.dumps(value)
                        )
                    )
                else:
                    db.session.add(
                        cls(
                            service_id=service_id,
                            service_feature=feature,
                            service_stat=str(value)
                        )
                    )
        db.session.commit()

class SystemDefault(db.Model):
    __tablename__ = 'vyos_system_default'
    id = Column(Integer, primary_key=True)
    country_code = Column(Text, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        logger.debug("Refresh SystemDefault data")
        if app_context is not None:
            with app_context:
                SystemDefault.truncate()
        else:
            SystemDefault.truncate()
        
        country_code = data.get('country_code')
        if not country_code:
            return
        
        if isinstance(country_code, list):
            country_code = ','.join(country_code)
        
        new_data = SystemDefault(
            country_code=country_code
        )
        if app_context is not None:
            with app_context:
                db.session.add(new_data)
                db.session.commit()
        else:
            db.session.add(new_data)
            db.session.commit()
    
    @classmethod
    def get_def_by_name(cls, name: str):
        # Use getattr to get the column attribute from the class
        column = getattr(cls, name)
        return db.session.query(cls).with_entities(column).first()
    
    
class ServiceState(db.Model):

    __tablename__ = 'vyos_service_state'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)
    status = Column(String, nullable=True)

    @classmethod
    def set_state(cls, name: str, status: str):
        try:
            # Check if service existed
            service = db.session.query(cls).filter_by(name=name).first()
            if service:
                service.status = status
                db.session.commit()
            else:
                new_service = cls(name=name, status=status)
                db.session.add(new_service)
                db.session.commit()
        except Exception as e:
            logger.error("Error setting service state:")
            logger.error(str(e))

    @classmethod
    def get_state(cls, name: str):
        service = db.session.query(cls).filter_by(name=name).first()
        return service.status if service else None
        

class System(db.Model):

    __tablename__ = 'vyos_system'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)
    domain_name = Column(String, nullable=True)
    uptime = Column(String, nullable=True)
    datetime = Column(String, nullable=True)
    timezone = Column(String, nullable=True)
    version = Column(String, nullable=True)
    hardware_model = Column(String, nullable=True)
    hardware_serial = Column(String, nullable=True)
    refreshed_at = Column(Float, nullable=False, default=time.time)
    boot_img_name = Column(String, nullable=True)
    boot_img_running = Column(Boolean, default=True)
    boot_img_default = Column(Boolean, default=True)
    ipv6_status = Column(Boolean, default=True)
    wireless_country_code = Column(String, nullable=True)


    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        logger.debug("Refresh System data")
        system_data = data.get('system', {})
        datetime_data = data.get('datetime', {})

        wireless_country_code = data.get('wireless_country_code')
        if not wireless_country_code and isinstance(system_data, dict):
            wireless_obj = system_data.get('wireless', {})
            if isinstance(wireless_obj, dict):
                wireless_country_code = wireless_obj.get('country-code') or wireless_obj.get('country_code')
        
        datetime_str = datetime_data
        timezone_str = data.get('timezone')
        if isinstance(datetime_data, dict):
            datetime_str = datetime_data.get('local_time', '')
            timezone_str = timezone_str or datetime_data.get('timezone')
        
        uptime_str = data.get('uptime')
        if not uptime_str and system_data:
            uptime_data = system_data.get('uptime', {})
            if isinstance(uptime_data, dict):
                uptime_str = uptime_data.get('uptime', '')
            else:
                uptime_str = uptime_data

        version_str = data.get('version')
        if not version_str and system_data:
            version_data = system_data.get('version', {})
            if isinstance(version_data, dict):
                version_str = version_data.get('version')
            else:
                version_str = version_data
        
        new_data = System(
            name=data.get('name') or system_data.get('host_name'),
            domain_name=data.get('domain_name'),
            datetime=datetime_str,
            timezone=timezone_str,
            version=version_str,
            hardware_model=data.get('hardware_model') or system_data.get('hardware_model'),
            hardware_serial=data.get('hardware_serial') or system_data.get('hardware_serial'),
            refreshed_at=time.time(),
            uptime=uptime_str,
            boot_img_name=data.get('boot_img_name'),
            boot_img_running=data.get('boot_img_running'),
            boot_img_default=data.get('boot_img_default'),
            wireless_country_code=wireless_country_code
        )
        with app_context if app_context is not None else nullcontext():
            current_data = System.query.first()
            if not new_data.hardware_model and current_data:
                new_data.hardware_model = current_data.hardware_model
            if not new_data.hardware_serial and current_data:
                new_data.hardware_serial = current_data.hardware_serial
            System.truncate()
            db.session.add(new_data)
            db.session.commit()

    @classmethod
    def set_ipv6_status(cls, data: dict):
        if not data:
            return
        if 'ipv6' not in data:
            return
        
        system_config = System.query.first()
        if system_config:
            system_config.ipv6_status = True if 'block' not in data['ipv6'] else False
            db.session.commit()

    def serialize(self):
        return {
            "name": self.name,
            "domain_name": self.domain_name,
            "datetime": self.datetime,
            "timezone": self.timezone,
            "version": self.version,
            "hardware_model": self.hardware_model,
            "hardware_serial": self.hardware_serial,
            "uptime": self.uptime,
            "uptime_age_seconds": max(0, time.time() - self.refreshed_at) if self.refreshed_at else 0,
            "boot_img_name": self.boot_img_name,
            "boot_img_running": self.boot_img_running,
            "boot_img_default": self.boot_img_default,
            "ipv6_status": self.ipv6_status,
            "wireless_country_code": self.wireless_country_code
        }

    @classmethod
    def set_wireless_country_code(cls, country_code: str):
        if not country_code:
            return
        system_config = System.query.first()
        if system_config:
            system_config.wireless_country_code = country_code
            db.session.commit()

    @classmethod
    def set_timezone(cls, timezone: str | None):
        system_config = cls.query.first()
        if system_config:
            system_config.timezone = timezone
        else:
            db.session.add(cls(timezone=timezone))
        db.session.commit()


class Memory(db.Model):

    __tablename__ = 'vyos_memory'

    id = Column(Integer, primary_key=True)
    free = Column(Float, default=0)
    used = Column(Float, default=0)
    date = Column(String, nullable=True)
    time = Column(String, nullable=True)
    utc_timestamp = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        print("Refresh Memory data")
        new_data = Memory(
            free=data.get('memory').get('free'),
            used=data.get('memory').get('used'),
            date=data.get('timestamp')[0],
            time=data.get('timestamp')[1],
            utc_timestamp=data.get('utc_timestamp')
        )
        if app_context is not None:
            with app_context:
                Memory.truncate()
                db.session.add(new_data)
                db.session.commit()
        else:
            Memory.truncate()
            db.session.add(new_data)
            db.session.commit()


class Storage(db.Model):

    __tablename__ = 'vyos_storage'

    id = Column(Integer, primary_key=True)
    filesystem = Column(String, nullable=True)
    size = Column(BigInteger, default=0)
    used = Column(BigInteger, default=0)
    avail = Column(BigInteger, default=0)
    use_percentage = Column(String, nullable=True)
    date = Column(String, nullable=True)
    time = Column(String, nullable=True)
    utc_timestamp = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        if not isinstance(data, dict):
            return

        timestamp_date, timestamp_hour = system_timestamp()
        new_data = Storage(
            filesystem=data.get('filesystem', ''),
            size=int(data.get('size') or 0),
            used=int(data.get('used') or 0),
            avail=int(data.get('avail') or 0),
            use_percentage=str(data.get('use_percentage') or ''),
            date=timestamp_date,
            time=timestamp_hour,
            utc_timestamp=system_utc_timestamp()
        )

        if app_context is not None:
            with app_context:
                Storage.truncate()
                db.session.add(new_data)
                db.session.commit()
        else:
            Storage.truncate()
            db.session.add(new_data)
            db.session.commit()

    @classmethod
    def latest(cls):
        return cls.query.order_by(cls.id.desc()).first()

    def serialize(self):
        return {
            "filesystem": self.filesystem or "",
            "size": int(self.size or 0),
            "used": int(self.used or 0),
            "avail": int(self.avail or 0),
            "use_percentage": str(self.use_percentage or ""),
            "timestamp": [self.date, self.time],
            "utc_timestamp": self.utc_timestamp,
        }


class LoadAverageHistory:

    _buffer_lock = RLock()
    _buffer = deque(maxlen=360)

    @dataclass(frozen=True)
    class _Point:
        value: float
        timestamp_date: str | None
        timestamp_hour: str | None
        utc_timestamp: str | None

        def serialize(self):
            return {
                "value": self.value,
                "timestamp": [self.timestamp_date, self.timestamp_hour],
                "utc_timestamp": self.utc_timestamp,
            }

    @classmethod
    def append_value(cls, value: float, max_rows: int = 360):
        timestamp_date, timestamp_hour = system_timestamp()
        point = cls._Point(
            value=float(value),
            timestamp_date=timestamp_date,
            timestamp_hour=timestamp_hour,
            utc_timestamp=system_utc_timestamp(),
        )

        acquired = cls._buffer_lock.acquire(timeout=2)
        if not acquired:
            logger.error("LoadAverageHistory.append_value: timeout acquiring buffer lock")
            return False
        try:
            if max_rows and max_rows > 0 and cls._buffer.maxlen != max_rows:
                cls._buffer = deque(cls._buffer, maxlen=max_rows)
            cls._buffer.append(point)
        finally:
            cls._buffer_lock.release()

        return True

    @classmethod
    def get_last(cls, limit: int = 360):
        if not limit or limit <= 0:
            return []
        with cls._buffer_lock:
            data = list(cls._buffer)
        if len(data) <= limit:
            return data
        return data[-limit:]


class InterfaceConfigIPAddress(db.Model):
    __tablename__ = 'vyos_config_interface_ip_address'

    id = Column(Integer, primary_key=True)
    ip_address = Column(String, nullable=False)
    interface_config_id = Column(Integer, ForeignKey('vyos_config_interface.id'), nullable=False)

    interface_config = relationship('InterfaceConfig', back_populates='ip_addresses')

    def serialize(self):
        return self.ip_address


class InterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_interface'

    id = Column(Integer, primary_key=True)
    interface = Column(String, nullable=True)
    interface_type = Column(String, nullable=True)
    status = Column(String, nullable=True)
    mac_address = Column(String, nullable=True)
    mtu = Column(String, nullable=True)
    speed = Column(String, nullable=True)
    duplex = Column(String, nullable=True)
    ip_addresses = relationship('InterfaceConfigIPAddress', back_populates='interface_config', cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        db.session.execute(text("DELETE FROM vyos_config_interface_ip_address"))
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict):
        try:
            from app.core.operation.parser import parse_all_interface_config
            config_data = parse_all_interface_config(data)
            cls.truncate()
            for data in config_data:
                interface_ip_addresses = data.get('ip_address') or []
                if not isinstance(interface_ip_addresses, list):
                    interface_ip_addresses = [interface_ip_addresses] if interface_ip_addresses else []

                new_data = cls(
                    interface=data.get('interface'),
                    interface_type=data.get('interface_type'),
                    status=data.get('status'),
                    mac_address=data.get('mac_address'),
                    mtu=data.get('mtu'),
                    speed=data.get('speed'),
                    duplex=data.get('duplex')
                )
                db.session.add(new_data)
                db.session.flush()

                for ip_address in interface_ip_addresses:
                    if ip_address:
                        db.session.add(InterfaceConfigIPAddress(
                            ip_address=ip_address,
                            interface_config_id=new_data.id
                        ))
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error("Error refreshing InterfaceConfig:")
            logger.error(str(e))

    @classmethod
    def upsert(cls, data: dict):
        try:
            from app.core.operation.parser import parse_all_interface_config

            parsed_config_data = parse_all_interface_config(data)
            deduped_rows = {}
            for row in parsed_config_data:
                interface_name = row.get('interface')
                if interface_name:
                    deduped_rows[interface_name] = row

            config_data = list(deduped_rows.values())
            interfaces_to_replace = list(deduped_rows.keys())

            if interfaces_to_replace:
                existing_rows = cls.query.filter(cls.interface.in_(interfaces_to_replace)).all()
                for row in existing_rows:
                    db.session.delete(row)
                db.session.flush()

            for data in config_data:
                interface_ip_addresses = data.get('ip_address') or []
                if not isinstance(interface_ip_addresses, list):
                    interface_ip_addresses = [interface_ip_addresses] if interface_ip_addresses else []

                new_data = cls(
                    interface=data.get('interface'),
                    interface_type=data.get('interface_type'),
                    status=data.get('status'),
                    mac_address=data.get('mac_address'),
                    mtu=data.get('mtu'),
                    speed=data.get('speed'),
                    duplex=data.get('duplex')
                )
                db.session.add(new_data)
                db.session.flush()

                for ip_address in interface_ip_addresses:
                    if ip_address:
                        db.session.add(InterfaceConfigIPAddress(
                            ip_address=ip_address,
                            interface_config_id=new_data.id
                        ))

            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error("Error upserting InterfaceConfig:")
            logger.error(str(e))

    @classmethod
    def sync_vrrp_entries(cls):
        try:
            from app.core.high_availability.vrrp.models import VRRPConfig

            existing_vrrp_rows = cls.query.filter(cls.interface_type.in_(['vrrp', 'VRRP'])).all()
            for row in existing_vrrp_rows:
                db.session.delete(row)
            db.session.flush()

            for config in VRRPConfig.query.all():
                for connection in config.connection:
                    for group in connection.groups:
                        interface_label = group.group_name or group.interface or f'VRRP-{group.id}'
                        if group.group_name and group.interface and group.group_name != group.interface:
                            interface_label = f'{group.group_name} ({group.interface})'

                        new_data = cls(
                            interface=interface_label,
                            interface_type='vrrp',
                            status='enabled' if group.enable else 'disabled',
                            mac_address='',
                            mtu='',
                            speed='',
                            duplex=''
                        )
                        db.session.add(new_data)
                        db.session.flush()

                        for address in group.address:
                            if address.address:
                                db.session.add(InterfaceConfigIPAddress(
                                    ip_address=address.address,
                                    interface_config_id=new_data.id
                                ))

            db.session.commit()
        except Exception as e:
            db.session.rollback()
            logger.error("Error syncing VRRP InterfaceConfig entries:")
            logger.error(str(e))

    def serialize(self):
        return {
            "interface": self.interface,
            "interface_type": self.interface_type,
            "status": self.status,
            "ip_addresses": [ip.serialize() for ip in self.ip_addresses],
            "mac_address": self.mac_address,
            "mtu": self.mtu,
            "speed": self.speed,
            "duplex": self.duplex
        }


class Interface(db.Model):
    __tablename__ = 'vyos_operation_interface'
    
    id = Column(Integer, primary_key=True)
    admin_state = Column(String, nullable=True)
    group = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    interface_type = Column(String, nullable=True)
    ipv4 = Column(String, nullable=True)
    ipv4_addresses = Column(String, nullable=True)
    ipv4_ranges = Column(String, nullable=True)
    ipv4_scope = Column(String, nullable=True)
    ipv4_global = Column(String, default=False)
    ipv4_global_range = Column(String, nullable=True)
    ipv4_mode = Column(String, default='static')
    ipv6 = Column(String, nullable=True)
    ipv6_addresses = Column(String, nullable=True)
    ipv6_ranges = Column(String, nullable=True)
    ipv6_scope = Column(String, nullable=True)
    ipv6_global = Column(String, default=False)
    ipv6_global_range = Column(String, nullable=True)
    ipv6_mode = Column(String, default='autoconf')
    mac_address = Column(String, nullable=True)
    mtu = Column(Integer, nullable=True)
    preferred_lft = Column(String, nullable=True)
    qdisc = Column(String, nullable=True)
    qlen = Column(Integer, nullable=True)
    rx_bytes = Column(Integer, nullable=True)
    rx_errors = Column(Integer, nullable=True)
    rx_over_errors = Column(Integer, nullable=True)
    rx_dropped = Column(Integer, nullable=True)
    rx_packets = Column(Integer, nullable=True)
    state = Column(String, nullable=True)
    tx_bytes = Column(Integer, nullable=True)
    tx_errors = Column(Integer, nullable=True)
    tx_carrier_errors = Column(Integer, nullable=True)
    tx_dropped = Column(Integer, nullable=True)
    tx_packets = Column(Integer, nullable=True)
    valid_lft = Column(String, nullable=True)
    desc = Column(String, nullable=True)
    flags = Column(String, nullable=True)
    speed = Column(String, nullable=True)
    duplex = Column(String, nullable=True)
    redirect = Column(String, nullable=True)
    host_name = Column(String, nullable=True)
    hw_id = Column(String, nullable=True)
    bridge_mode = Column(String, nullable=True)
    deletable = Column(Boolean, default=True)
    editable = Column(Boolean, default=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def update_interface_by_name(cls, name: str, ipv4: str, desc: str):
        intf = db.session.query(Interface).filter_by(interface=name).first()
        if intf:
            intf.ipv4 = ipv4
            intf.desc = desc
            db.session.commit()

    @classmethod
    def get_interface_names(cls):
        ifaces = []
        names = db.session.query(Interface.interface).all()
        for name in names:
            # Don't take loopback and dummy ifaces
            if not name[0].startswith("lo") and not name[0].startswith("dum"):
                ifaces.append(name[0])
        return ifaces

    @staticmethod
    def is_vrrp_interface_name(interface_name):
        if not isinstance(interface_name, str):
            return False

        return bool(VRRP_INTERFACE_NAME_PATTERN.match(interface_name))

    @staticmethod
    def is_vlan_interface_name(interface_name):
        if not isinstance(interface_name, str):
            return False

        parent_name, separator, vlan_id = interface_name.rpartition('.')
        return bool(parent_name and separator and vlan_id.isdigit())

    @classmethod
    def create_ipv4(cls, name: str, ipv4: str):
        
        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                ip_range = ipv4.split('/')
                if len(ip_range) == 2:
                    ip_addr = ip_range[0]
                    range_val = ip_range[1]
                    
                    ips = intf.ipv4.split(',') if intf.ipv4 and intf.ipv4.strip() else []
                    ranges = intf.ipv4_ranges.split(',') if intf.ipv4_ranges and intf.ipv4_ranges.strip() else []
                    
                    if ip_addr not in ips:
                        ips.append(ip_addr)
                    if range_val not in ranges:
                        ranges.append(range_val)
                    
                    ips_str = ','.join(ips) if ips else ''
                    ranges_str = ','.join(ranges) if ranges else ''
                    
                    intf.ipv4 = ips_str
                    intf.ipv4_addresses = ips_str
                    intf.ipv4_ranges = ranges_str
                    intf.ipv4_scope = "global"
                    intf.ipv4_global = ips_str
                    intf.ipv4_global_range = ranges_str
                    intf.ipv4_mode = "static"

                    db.session.commit()
        except Exception as e:
            print("Error:", str(e))

    @classmethod
    def update_ipv4(cls, name: str, current_ip: str, new_ip: str):

        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                current_ip_range = current_ip.split('/')
                new_ip_range = new_ip.split('/')
                
                ips = intf.ipv4.split(',')
                ranges = intf.ipv4_ranges.split(',')
                indx = ips.index(current_ip_range[0])
                
                ips[indx] = new_ip_range[0]
                ranges[indx] = new_ip_range[1]

                intf.ipv4_ranges = convert_str(ranges)
                intf.ipv4 = convert_str(ips)
                intf.ipv4_addresses = convert_str(ips)

                db.session.commit()
        except Exception as e:
            print("Error:", str(e))


    @classmethod
    def delete_ipv4(cls, name: str, ipv4: str):
            
        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                ip_range = ipv4.split('/')
                
                ips = intf.ipv4.split(',')
                ranges = intf.ipv4_ranges.split(',')
                indx = ips.index(ip_range[0])
                
                del ips[indx]
                del ranges[indx]

                intf.ipv4_ranges = convert_str(ranges)
                intf.ipv4 = convert_str(ips)
                intf.ipv4_addresses = convert_str(ips)
                
                db.session.commit()    
        except Exception as e:
            logger.error("Error:")
            logger.error(str(e))

    @classmethod
    def process_bridge_member(cls, data, config_data):
        bridge_intf = {}
        interface_data = []
        if 'ShowInterfaces' in data and 'data' in data['ShowInterfaces'] and \
            'result' in data['ShowInterfaces']['data']:
            interface_data = data['ShowInterfaces']['data']['result']
        else:
            interface_data = data
            
        for d in interface_data:
                
            interface_type = d.get('link_type', d.get('interface_type', ''))
            interface_name = d.get('ifname', d.get('interface', ''))

            if interface_type == 'ether':
                if interface_name.startswith('br'):
                    interface_type = 'Bridge'

            if interface_type == 'Bridge':
                if 'bridge' in config_data and interface_name in config_data['bridge']:
                    if 'member' in config_data['bridge'][interface_name] and 'interface' in config_data['bridge'][interface_name]['member']:
                        for child_intf in config_data['bridge'][interface_name]['member']['interface']:
                            bridge_intf[child_intf] = interface_name
        
        return bridge_intf

    @classmethod
    def refresh(cls, data, config_data, app_context=None):
        logger.debug("=== Interface.refresh() called ===")
        logger.debug(f"Data type: {type(data)}")
        logger.debug(f"Config data type: {type(config_data)}")
        
        conf = config_data.json()['data']
        logger.debug("Config data keys:")
        logger.debug(list(conf.keys()))
        
        bridge_intf = cls.process_bridge_member(data, conf)
        logger.debug("Bridge interface members: ")
        logger.debug(bridge_intf)
        try:
            logger.debug('== New Interface Table ==')
            if app_context is not None:
                with app_context:
                    Interface.truncate()
            else:
                Interface.truncate()
            
            if 'ShowInterfaces' in data and 'data' in data['ShowInterfaces'] and \
                'result' in data['ShowInterfaces']['data']:
                interface_data = data['ShowInterfaces']['data']['result']
                logger.debug(f"Found ShowInterfaces structure, processing {len(interface_data)} interfaces")
            else:
                interface_data = data
                logger.debug(f"Using data directly, type: {type(interface_data)}")
                
            interfaces_to_add = []
            
            for d in interface_data:
                ipv4_addresses = []
                ipv4_ranges = []
                ipv4_scope = []
                ipv6_addresses = []
                ipv6_ranges = []
                ipv6_scope = []
                ipv4_global = []
                ipv4_global_range = []
                ipv6_global = []
                ipv6_global_range = []
                preferred_lft = ''
                valid_lft = ''
                ipv4_mode = []
                ipv6_mode = []

                address_config = []
                
                interface_type = d.get('link_type', d.get('interface_type', ''))
                interface_name = d.get('ifname', d.get('interface', ''))
    
                is_vlan = False
                parent_interface = None
                vlan_id = None
                if '.' in interface_name:
                    parts = interface_name.rsplit('.', 1)
                    if len(parts) == 2 and parts[1].isdigit():
                        is_vlan = True
                        parent_interface = parts[0]
                        vlan_id = parts[1]

                if interface_type == 'ether':
                    if interface_name.startswith('br'):
                        interface_type = 'Bridge'
                    elif Interface.is_vrrp_interface_name(interface_name):
                        interface_type = 'VRRP'
                    elif interface_name.startswith('eth'):
                        interface_type = 'Ethernet'
                    elif interface_name.startswith('wlan'):
                        interface_type = 'Wireless'
                elif interface_type == 'loopback':
                    interface_type = 'Loopback'
                elif interface_name.startswith('vtun'):
                    interface_type = 'OpenVPN'
                elif interface_name.startswith('wg'):
                        interface_type = 'Wireguard'
                
                if 'wwan' in interface_name:
                    interface_type = 'Cellular'

                # Ensure interface_type is a string before calling .lower()
                if isinstance(interface_type, list):
                    interface_type = interface_type[0] if interface_type else ''
                if not isinstance(interface_type, str):
                    interface_type = str(interface_type)
                format_iface_type = interface_type.lower()
                
                if is_vlan and parent_interface and vlan_id:
                    parent_type = format_iface_type
                    if parent_interface.startswith('br'):
                        parent_type = 'bridge'
                    elif parent_interface.startswith('eth'):
                        parent_type = 'ethernet'
                    
                    logger.debug(f"VLAN detected: {interface_name} -> parent: {parent_interface}, vlan_id: {vlan_id}, parent_type: {parent_type}")
                    
                    if parent_type in conf and parent_interface in conf[parent_type]:
                        parent_conf = conf[parent_type][parent_interface]
                        logger.debug(f"Parent config keys: {list(parent_conf.keys())}")
                        if 'vif' in parent_conf and vlan_id in parent_conf['vif']:
                            vif_conf = parent_conf['vif'][vlan_id]
                            logger.debug(f"VIF config for {vlan_id}: {vif_conf}")
                            if 'address' in vif_conf:
                                address_config = vif_conf['address']
                                logger.debug(f"Found address config: {address_config}")
                            else:
                                logger.debug(f"No 'address' key in vif config")
                        else:
                            logger.debug(f"'vif' not in parent or vlan_id {vlan_id} not found. VIF keys: {parent_conf.get('vif', {}).keys() if 'vif' in parent_conf else 'N/A'}")
                    else:
                        logger.debug(f"Parent type {parent_type} or interface {parent_interface} not in config")
                # Handle regular interfaces
                elif format_iface_type in conf and interface_name in conf[format_iface_type] \
                    and 'address' in conf[format_iface_type][interface_name]:
                    address_config = conf[format_iface_type][interface_name]['address']
                    logger.debug(f"Regular interface {interface_name} address config: {address_config}")

                # print("Address Config: ")
                # print(address_config)
                    
                if 'addr_info' in d:
                    for addr in d['addr_info']:
                        if addr.get('family') == 'inet' and 'local' in addr:
                            ipv4_addresses.append(addr['local'])
                            prefix = addr.get('prefixlen', '')
                            ipv4_ranges.append(f"{prefix}")
                            ipv4_scope.append(addr.get('scope', ''))

                            ipAddr = addr['local'] + '/' + str(prefix)
                            # print("IP: ", ipAddr)

                            if len(address_config) > 0:
                                if ipAddr in address_config:
                                    ipv4_mode.append('static')
                                elif addr.get('scope', '') == 'global':
                                    ipv4_mode.append('dhcp')
                                else:
                                    ipv4_mode.append('static')
                            
                            if addr.get('scope', '') == 'global':
                                ipv4_global.append(addr['local'])
                                ipv4_global_range.append(f"{prefix}")
                            if not preferred_lft and 'preferred_life_time' in addr:
                                preferred_lft = str(addr['preferred_life_time'])

                                if preferred_lft == '4294967295':
                                    preferred_lft = 'forever'
                                else:
                                    preferred_lft = f"{preferred_lft}sec"
                            if not valid_lft and 'valid_life_time' in addr:
                                valid_lft = str(addr['valid_life_time'])

                                if valid_lft == '4294967295':
                                    valid_lft = 'forever'
                                else:
                                    valid_lft = f"{valid_lft}sec"
                        elif addr.get('family') == 'inet6' and 'local' in addr:
                            ipv6_addresses.append(addr['local'])
                            prefix = addr.get('prefixlen', '')
                            ipv6_ranges.append(f"{prefix}")
                            ipv6_scope.append(addr.get('scope', ''))

                            if (addr['local'] + '/' + str(prefix)) in address_config:
                                ipv6_mode.append('static')
                            elif addr.get('scope', '') == 'global':
                                ipv6_mode.append('dhcp')
                            else:
                                ipv6_mode.append('static')

                            if addr.get('scope', '') == 'global':
                                ipv6_global.append(addr['local'])
                                ipv6_global_range.append(f"{prefix}")
                            if not preferred_lft and 'preferred_life_time' in addr:
                                preferred_lft = str(addr['preferred_life_time'])

                                if preferred_lft == '4294967295':
                                    preferred_lft = 'forever'
                                else:
                                    preferred_lft = f"{preferred_lft}sec"
                            if not valid_lft and 'valid_life_time' in addr:
                                valid_lft = str(addr['valid_life_time'])

                                if valid_lft == '4294967295':
                                    valid_lft = 'forever'
                                else:
                                    valid_lft = f"{valid_lft}sec"
                
                mac_address = d.get('address', d.get('mac_address', ''))
                mtu = d.get('mtu', 0)
                qdisc = d.get('qdisc', '')
                txqlen = d.get('txqlen', d.get('qlen', 0))
                
                rx_bytes = 0
                rx_packets = 0
                rx_errors = 0
                rx_over_errors = 0
                rx_dropped = 0
                tx_bytes = 0
                tx_packets = 0
                tx_errors = 0
                tx_carrier_errors = 0
                tx_dropped = 0
                if 'stats' in d:
                    rx_bytes = d['stats'].get('rx_bytes', 0)
                    rx_packets = d['stats'].get('rx_packets', 0)
                    rx_errors = d['stats'].get('rx_errors', 0)
                    rx_over_errors = d['stats'].get('rx_over_errors', 0)
                    rx_dropped = d['stats'].get('rx_dropped', 0)
                    tx_bytes = d['stats'].get('tx_bytes', 0)
                    tx_packets = d['stats'].get('tx_packets', 0)
                    tx_errors = d['stats'].get('tx_errors', 0)
                    tx_carrier_errors = d['stats'].get('tx_carrier_errors', 0)
                    tx_dropped = d['stats'].get('tx_dropped', 0)
                else:
                    rx_bytes = d.get('rx_bytes', 0)
                    rx_packets = d.get('rx_packets', 0)
                    rx_errors = d.get('rx_errors', 0)
                    rx_over_errors = d.get('rx_over_errors', 0)
                    rx_dropped = d.get('rx_dropped', 0)
                    tx_bytes = d.get('tx_bytes', 0)
                    tx_packets = d.get('tx_packets', 0)
                    tx_errors = d.get('tx_errors', 0)
                    tx_carrier_errors = d.get('tx_carrier_errors', 0)
                    tx_dropped = d.get('tx_dropped', 0)
                
                state = d.get('operstate', d.get('state', ''))
                admin_state = 'UP' if 'UP' in d.get('flags', []) else 'DOWN'
                
                description = d.get('description', d.get('desc', ''))
                flags = d.get('flags', d.get('flags', []))
                interface_conf = {}
                if format_iface_type in conf and interface_name in conf[format_iface_type]:
                    interface_conf = conf[format_iface_type][interface_name]
                

                deletable = True
                if interface_type in ['Loopback', 'Ethernet']:
                    deletable = False
                
                if isinstance(flags, list):
                    flags_str = str(flags)
                else:
                    flags_str = str(flags)
                
                new_interface = Interface(
                    group=d.get('group', 'default'),
                    interface=interface_name,
                    interface_type=interface_type,
                    ipv4=convert_str(ipv4_addresses),
                    ipv4_addresses=convert_str(ipv4_addresses),
                    ipv4_ranges=convert_str(ipv4_ranges),
                    ipv6=convert_str(ipv6_addresses),
                    ipv6_addresses=convert_str(ipv6_addresses),
                    ipv6_ranges=convert_str(ipv6_ranges),
                    mac_address=mac_address,
                    mtu=mtu,
                    preferred_lft=preferred_lft,
                    qdisc=qdisc,
                    qlen=txqlen,
                    rx_bytes=rx_bytes,
                    rx_errors=rx_errors,
                    rx_over_errors=rx_over_errors,
                    rx_dropped=rx_dropped,
                    rx_packets=rx_packets,
                    state=state,
                    admin_state=admin_state,
                    tx_bytes=tx_bytes,
                    tx_errors=tx_errors,
                    tx_carrier_errors=tx_carrier_errors,
                    tx_dropped=tx_dropped,
                    tx_packets=tx_packets,
                    valid_lft=valid_lft,
                    desc=format_description(description),
                    flags=flags_str,
                    hw_id=d.get('hw-id', interface_conf.get('hw-id', '')),
                    speed=d.get('speed', interface_conf.get('speed', '')),
                    duplex=d.get('duplex', interface_conf.get('duplex', '')),
                    host_name=d.get('host_name', ''),
                    redirect=d.get('redirect', interface_conf.get('redirect', '')),
                    bridge_mode=bridge_intf.get(interface_name, ''),
                    deletable=deletable,
                    editable=True,
                    ipv4_scope=convert_str(ipv4_scope),
                    ipv6_scope=convert_str(ipv6_scope),
                    ipv4_global=convert_str(ipv4_global),
                    ipv6_global=convert_str(ipv6_global),
                    ipv4_global_range=convert_str(ipv4_global_range),
                    ipv6_global_range=convert_str(ipv6_global_range),
                    ipv4_mode=convert_str(ipv4_mode),
                    ipv6_mode=convert_str(ipv6_mode),                    
                )
                
                if app_context is not None:
                    with app_context:
                        db.session.add(new_interface)
                else:
                    db.session.add(new_interface)
                
                logger.debug(f"Added interface: {interface_name} ({interface_type})")

            logger.debug(f"Adding {len(interfaces_to_add)} interfaces to database session")
            if app_context is not None:
                with app_context:
                    for intf in interfaces_to_add:
                        db.session.add(intf)
                    db.session.commit()
                    logger.debug("Database commit successful (with app_context)")
            else:
                for intf in interfaces_to_add:
                    db.session.add(intf)
                db.session.commit()
                logger.debug("Database commit successful (without app_context)")
        except Exception as e:
            logger.error('Create interface error')
            logger.error(str(e))

    def serialize(self):
        ipv4_list = []
        ipv6_list = []
        ipv4_scope_list = []
        ipv6_scope_list = []
        ipv4_global = ''
        ipv6_global = ''
        ipv4_global_range = ''
        ipv6_global_range = ''
        ipv4_mode = []
        ipv6_mode = []
        
        if self.ipv4_addresses and self.ipv4_ranges:
            ipv4_list = list(zip(self.ipv4_addresses.split(',') , self.ipv4_ranges.split(',')))
        if self.ipv6_addresses and self.ipv6_ranges:
            ipv6_list = list(zip(self.ipv6_addresses.split(','), self.ipv6_ranges.split(',')))
        if self.ipv4_scope:
            ipv4_scope_list = self.ipv4_scope.split(',')
        if self.ipv6_scope:
            ipv6_scope_list = self.ipv6_scope.split(',')
        if self.ipv4_global:
            ipv4_global = self.ipv4_global.split(',')[0]
        if self.ipv6_global:
            ipv6_global = self.ipv6_global.split(',')[0]
        if self.ipv4_global_range:
            ipv4_global_range = self.ipv4_global_range.split(',')[0]
        if self.ipv6_global_range:
            ipv6_global_range = self.ipv6_global_range.split(',')[0]

        if self.ipv4_mode:
            ipv4_mode = self.ipv4_mode.split(',')
        if self.ipv6_mode:
            ipv6_mode = self.ipv6_mode.split(',')
        # convert flags string to a list
        flags_list = []
        if self.flags:
            flags_string = self.flags.strip("[]").replace("'", "").replace('"', "")
            if flags_string:
                flags_list = [flag.strip() for flag in flags_string.split(',')]

        result = {
            "group": self.group,
            "interface": self.interface,
            "interface_type": self.interface_type,
            "ipv4": ipv4_list,
            "ipv4_addresses": self.ipv4_addresses,
            "ipv4_ranges": self.ipv4_ranges,
            "ipv6": ipv6_list,
            "ipv6_addresses": self.ipv6_addresses,
            "ipv6_ranges": self.ipv6_ranges,
            "mac_address": self.mac_address,
            "mtu": self.mtu,
            "preferred_lft": self.preferred_lft,
            "qdisc": self.qdisc,
            "qlen": self.qlen,
            "rx_bytes": self.rx_bytes,
            "rx_errors": self.rx_errors,
            "rx_over_errors": self.rx_over_errors,
            "rx_dropped": self.rx_dropped,
            "rx_packets": self.rx_packets,
            "state": self.state,
            "admin_state": self.admin_state,
            "tx_bytes": self.tx_bytes,
            "tx_errors": self.tx_errors,
            "tx_carrier_errors": self.tx_carrier_errors,
            "tx_dropped": self.tx_dropped,
            "tx_packets": self.tx_packets,
            "valid_lft": self.valid_lft,
            "desc": self.desc,
            "speed": self.speed,
            "duplex": self.duplex,
            "host_name": self.host_name,
            "redirect": self.redirect,
            "hw_id": self.hw_id,
            "flags": str(self.flags),
            "flags_list": flags_list,
            "bridge_mode": self.bridge_mode,
            "ipv4_scope": ipv4_scope_list,
            "ipv6_scope": ipv6_scope_list,
            "ipv4_global": ipv4_global,
            "ipv6_global": ipv6_global,
            "ipv4_global_range": ipv4_global_range,
            "ipv6_global_range": ipv6_global_range,
            "ipv4_mode": ipv4_mode,
            "ipv6_mode": ipv6_mode,
        }
        
        return result
