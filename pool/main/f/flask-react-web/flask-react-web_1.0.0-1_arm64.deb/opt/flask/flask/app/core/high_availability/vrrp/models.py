from pydantic import BaseModel, RootModel
from typing import Optional, List, Dict, Union
from decimal import Decimal
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.log.logger import logger
import json

def _to_int_or_none(value):
    if value is None or str(value).strip() in ['', 'None', 'null', 'NaN', 'nan']:
        return None
    return int(value)

class VRRPGeneralDTO(BaseModel):
    groupName: str
    description: Optional[str] = None
    enable: bool
    address: list[str]
    interface: str
    VRID: int
    
class GARPDTO(BaseModel):
    interval: Optional[Union[Decimal, str]] = None
    delay: Optional[Union[int, str]] = None
    masterRefresh: Optional[Union[int, str]] = None
    masterRefreshRepeat: Optional[Union[int, str]] = None
    masterRepeat: Optional[Union[int, str]] = None

class healthCheckDTO(BaseModel):
    isHealthCheckEnabled: Optional[bool] = None
    failureCount: Optional[Union[int, str]] = None
    interval: Optional[Union[int, str]] = None
    pingTarget: Optional[str] = None

class trackDTO(BaseModel):
    isTrackEnabled: Optional[bool] = None
    excludeVRRP: Optional[bool] = None
    interface: Optional[List[str]] = None

class VRRPAdvancedConfigDTO(BaseModel):
    advertiseInterval: Optional[Union[int, str]] = None
    authenticationPassword: Optional[str] = None
    excludedAddresses: Optional[List[str]] = None
    disableMaster: Optional[bool] = False
    peerAddress: Optional[str] = None
    delay: Optional[Union[int, str]] = None
    priority: Optional[Union[int, str]] = None
    RFC3768Compatibility: Optional[bool] = None
    GARP: Optional[GARPDTO] = None
    healthCheck: Optional[healthCheckDTO] = None
    track: Optional[trackDTO] = None

class groupDTO(BaseModel):
    VRRPGeneral: VRRPGeneralDTO 
    VRRPAdvancedConfig: Optional[VRRPAdvancedConfigDTO] = None

class syncGroupDTO(BaseModel):
    groupName: str
    member: list[str]
    healthCheck: Optional[healthCheckDTO] = None

class globalParametersDTO(BaseModel):
    delay: Optional[Union[int, str]] = None
    version: Optional[Union[int, str]] = None
    enableSNMP: Optional[bool] = None
    GARP: Optional[GARPDTO] = None

class connectionDTO(BaseModel):
    group: list[groupDTO] = []
    syncGroup: list[syncGroupDTO] = []

class UpdateVRRPDTO(BaseModel):
    connection: connectionDTO
    globalParameters: Optional[globalParametersDTO] = None

class VerifyVRRPDTO(BaseModel):
    verify_type: str
    group: Optional[List[groupDTO]] = []
    syncGroup: Optional[UpdateVRRPDTO] = []

class VRRPConfig(db.Model):
    __tablename__ = 'vyos_config_vrrp'
    
    id = Column(Integer, primary_key=True)
    
    connection = relationship("VRRPConnection", back_populates="vyos_vrrp_config", cascade="all, delete-orphan")
    global_parameters = relationship("VRRPGlobalParameters", back_populates="vyos_vrrp_config", cascade="all, delete-orphan")

    
    def serialize(self):
        return {
            'id': self.id,
            'connection': [c.serialize() for c in self.connection] if self.connection else [],
            'global_parameters': [gp.serialize() for gp in self.global_parameters] if self.global_parameters else []
        }

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_vrrp_track_interface',
            'vyos_config_vrrp_member',
            'vyos_config_vrrp_excluded_address',
            'vyos_config_vrrp_address',
            'vyos_config_vrrp_sync_group',
            'vyos_config_vrrp_group',
            'vyos_config_vrrp_connection',
            'vyos_config_vrrp_global_parameters',
            'vyos_config_vrrp'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh VRRP cconfiguration from VyOS data"""
        try:
            print("Refreshing VRRP configuration")
            print(data)
            logger.info(data)
            cls.truncate()

            vrrp_config = cls()
            db.session.add(vrrp_config)

            if 'global-parameters' in data:
                global_data = data['global-parameters']
                garp_data = global_data.get('garp', {})

                global_params = VRRPGlobalParameters(
                    delay=_to_int_or_none(global_data.get('startup-delay')),
                    version=_to_int_or_none(global_data.get('version')),
                    enable_snmp='snmp' in data, 
                    interval=_to_int_or_none(garp_data.get('interval')),
                    master_delay=_to_int_or_none(garp_data.get('master-delay')),
                    master_refresh=_to_int_or_none(garp_data.get('master-refresh')),
                    master_refresh_repeat=_to_int_or_none(garp_data.get('master-refresh-repeat')),
                    master_repeat=_to_int_or_none(garp_data.get('master-repeat'))
                )

                global_params.vyos_vrrp_config = vrrp_config
                db.session.add(global_params)

            connections = VRRPConnection()
            connections.vyos_vrrp_config = vrrp_config

            db.session.add(connections)
                      
            if 'group' in data:
                
                for vyos_group_name, group_data in data['group'].items():
                    group = VRRPGroup(
                        group_name=vyos_group_name,
                        description=group_data.get('description', ''),
                        enable = 'disable' not in group_data,
                        interface=group_data.get('interface'),
                        vrid=_to_int_or_none(group_data.get('vrid')),
                        advertise_interval=_to_int_or_none(group_data.get('advertise-interval')),
                        authentication_password=group_data.get('authentication', {}).get('password', ''),
                        disable_master='no-preempt' in group_data,
                        peer_address=group_data.get('peer-address', ''),
                        delay=_to_int_or_none(group_data.get('preempt-delay')),
                        priority=_to_int_or_none(group_data.get('priority')),
                        RFC3768_Compatibility='rfc3768-compatibility' in group_data,
                        interval=_to_int_or_none(group_data.get('garp', {}).get('interval')),
                        master_delay=_to_int_or_none(group_data.get('garp', {}).get('master-delay')),
                        master_refresh=_to_int_or_none(group_data.get('garp', {}).get('master-refresh')),
                        master_refresh_repeat=_to_int_or_none(group_data.get('garp', {}).get('master-refresh-repeat')),
                        master_repeat=_to_int_or_none(group_data.get('garp', {}).get('master-repeat')),
                        failure_count=_to_int_or_none(group_data.get('health-check', {}).get('failure-count')),
                        health_check_interval=_to_int_or_none(group_data.get('health-check', {}).get('interval')),
                        ping_target=group_data.get('health-check', {}).get('ping', ''),
                        exclude_vrrp='exclude-vrrp-interface' in group_data.get('track', {}),
                    )

                    group.connection = connections

                   
                    
                    track = group_data.get('track', {})
                    interfaces_raw = track.get('interface')

                    # Normalize to list[str]
                    if isinstance(interfaces_raw, dict):
                        # e.g., {"eth0": {}, "br1": {}}
                        interfaces = list(interfaces_raw.keys())
                    elif isinstance(interfaces_raw, list):
                        # e.g., ["eth0", "br1"]
                        interfaces = interfaces_raw
                    elif isinstance(interfaces_raw, str):
                        # e.g., "eth0"
                        interfaces = [interfaces_raw]
                    else:
                        interfaces = []

                    # Clean up: only non-empty strings
                    interfaces = [i.strip() for i in interfaces if isinstance(i, str) and i.strip()]

                    for inter in interfaces:
                        group.track_interface.append(VRRPTrackInterface(track_interface=inter))
                    
                    addresses = group_data.get('address', {})

                    for addr in addresses.keys():
                        group.address.append(VRRPAddress(address=addr))


                    for ex_addr in group_data.get('excluded-address', {}):
                        group.excluded_address.append(VRRPExcludedAddress(excluded_address=ex_addr))

                    db.session.add(group)


            if 'sync-group' in data:        
                for sync_group_name, sync_group_data in data['sync-group'].items():

                    health_check = sync_group_data.get('health-check', {})

                    sync_group = VRRPSyncGroup(
                        group_name=sync_group_name,
                        failure_count=_to_int_or_none(health_check.get('failure-count')),
                        interval=_to_int_or_none(health_check.get('interval')),
                        ping_target=health_check.get('ping', '')
                    )

                    sync_group.connection = connections

                    
                    members_raw = sync_group_data.get('member')

                    if isinstance(members_raw, str):
                        members = [members_raw]                       
                    elif isinstance(members_raw, dict):
                        members = list(members_raw.keys())           
                    elif isinstance(members_raw, list):
                        members = members_raw                        
                    else:
                        members = []

                    # filter out empty strings
                    members = [m.strip() for m in members if isinstance(m, str) and m.strip()]

                    for member_name in members:
                        sync_group.member.append(VRRPMember(member=member_name))

                    db.session.add(sync_group)
                    
            db.session.commit()
            logger.info("VRRP configuration refreshed successfully")

        except Exception as e:
            print(f"Error refreshing VRRP configuration: {e}")
            db.session.rollback()
            raise


       
          

class VRRPConnection(db.Model):
    __tablename__ = 'vyos_config_vrrp_connection'

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_vrrp.id'), nullable=False)

    vyos_vrrp_config = relationship("VRRPConfig", back_populates="connection")
    groups = relationship("VRRPGroup", back_populates="connection", cascade="all, delete-orphan")
    sync_groups = relationship("VRRPSyncGroup", back_populates="connection", cascade="all, delete-orphan")

    def serialize(self): 
        return {
         'groups': [g.serialize() for g in self.groups] if self.groups else [],
         'sync_groups': [sg.serialize() for sg in self.sync_groups] if self.sync_groups else []
        }
    

class VRRPGlobalParameters(db.Model):
    __tablename__ = 'vyos_config_vrrp_global_parameters'

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_vrrp.id'), nullable=False)
    delay = Column(Integer)
    version = Column(Integer)
    enable_snmp = Column(Boolean, default=False)
    interval = Column(Integer)
    master_delay = Column(Integer)
    master_refresh = Column(Integer)
    master_refresh_repeat = Column(Integer)
    master_repeat = Column(Integer)

    vyos_vrrp_config = relationship("VRRPConfig", back_populates="global_parameters")

    def serialize(self):
        return {
            'delay': self.delay,
            'version': self.version,
            'enable_snmp': self.enable_snmp,
            'interval': self.interval,
            'master_delay': self.master_delay,
            'master_refresh': self.master_refresh,
            'master_refresh_repeat': self.master_refresh_repeat,
            'master_repeat': self.master_repeat
        }

class VRRPGroup(db.Model):
    __tablename__ = 'vyos_config_vrrp_group'
    
    id = Column(Integer, primary_key=True)
    connection_id = Column(Integer, ForeignKey('vyos_config_vrrp_connection.id'), nullable=False)
    group_name = Column(String(50), nullable=False)
    description = Column(String(50), nullable=False)
    enable = Column(Boolean, default=False)
    interface = Column(String(50), nullable=False)
    vrid = Column(Integer)
    advertise_interval = Column(Integer)
    authentication_password = Column(String(50), nullable=False)
    disable_master = Column(Boolean, default=False) 
    peer_address = Column(String(50), nullable=False)
    delay = Column(Integer)
    priority = Column(Integer)
    RFC3768_Compatibility = Column(Boolean, default=False)
    interval = Column(Integer)
    master_delay = Column(Integer)
    master_refresh = Column(Integer)
    master_refresh_repeat = Column(Integer)
    master_repeat = Column(Integer)
    failure_count = Column(Integer)
    health_check_interval = Column(Integer)
    ping_target = Column(String(50), nullable=False)
    exclude_vrrp = Column(Boolean, default=False) 
    
    connection = relationship("VRRPConnection", back_populates="groups")
    address = relationship("VRRPAddress", back_populates="groups", cascade="all, delete-orphan")
    excluded_address = relationship("VRRPExcludedAddress", back_populates="groups", cascade="all, delete-orphan")
    track_interface = relationship("VRRPTrackInterface", back_populates="groups", cascade="all, delete-orphan")

    def serialize(self):
        return {
            'group_name': self.group_name,
            'description': self.description,
            'enable': self.enable,
            'addresses': [a.serialize() for a in self.address],
            'track_interfaces': [t.serialize() for t in self.track_interface],
            'interface': self.interface,
            'vrid': self.vrid,
            'advertise_interval': self.advertise_interval,
            'authentication_password': self.authentication_password,
            'excluded_addresses': [e.serialize() for e in self.excluded_address],
            'disable_master': self.disable_master,
            'peer_address': self.peer_address,
            'delay': self.delay,
            'priority': self.priority,
            'RFC3768_Compatibility': self.RFC3768_Compatibility,
            'interval': self.interval,
            'master_delay': self.master_delay,
            'master_refresh': self.master_refresh,
            'master_refresh_repeat': self.master_refresh_repeat,
            'master_repeat': self.master_repeat,
            'failure_count': self.failure_count,
            'health_check_interval': self.health_check_interval,
            'ping_target': self.ping_target,
            'exclude_vrrp': self.exclude_vrrp,
        }
        
class VRRPSyncGroup(db.Model):
    __tablename__ = 'vyos_config_vrrp_sync_group'
    
    id = Column(Integer, primary_key=True)
    connection_id = Column(Integer, ForeignKey('vyos_config_vrrp_connection.id'), nullable=False)
    group_name = Column(String(50), nullable=False)
    failure_count = Column(Integer)
    interval = Column(Integer)
    ping_target = Column(String(50), nullable=False)
    
    connection = relationship("VRRPConnection", back_populates="sync_groups")
    member = relationship("VRRPMember", back_populates="sync_groups", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'sync_group_name': self.group_name,
            'members': [m.serialize() for m in self.member],
            'failure_count': self.failure_count,
            'interval' : self.interval,
            'ping_target' : self.ping_target
        }

class VRRPAddress(db.Model):
    __tablename__ = 'vyos_config_vrrp_address'
    
    id = Column(Integer, primary_key=True)
    address = Column(String, nullable=False)
    group_id = Column(Integer, ForeignKey('vyos_config_vrrp_group.id'), nullable=False)

    groups = relationship("VRRPGroup", back_populates="address")
    
    def serialize(self):
        return {
            "address": self.address
        }

class VRRPExcludedAddress(db.Model):
    __tablename__ = 'vyos_config_vrrp_excluded_address'
    
    id = Column(Integer, primary_key=True)
    excluded_address = Column(String, nullable=False)
    group_id = Column(Integer, ForeignKey('vyos_config_vrrp_group.id'), nullable=False)

    groups = relationship("VRRPGroup", back_populates="excluded_address")

    def serialize(self):
        return {
            "excluded_address": self.excluded_address
        }
    

class VRRPTrackInterface(db.Model):
    __tablename__ = 'vyos_config_vrrp_track_interface'
    
    id = Column(Integer, primary_key=True)
    track_interface = Column(String, nullable=False)
    group_id = Column(Integer, ForeignKey('vyos_config_vrrp_group.id'), nullable=False)

    groups = relationship("VRRPGroup", back_populates="track_interface")

    def serialize(self):
        return {
            "track_interface": self.track_interface
        }


class VRRPMember(db.Model):
    __tablename__ = 'vyos_config_vrrp_member'
    
    id = Column(Integer, primary_key=True)
    member = Column(String, nullable=False)
    sync_group_id = Column(Integer, ForeignKey('vyos_config_vrrp_sync_group.id'), nullable=False)
    
    sync_groups = relationship("VRRPSyncGroup", back_populates="member")

    def serialize(self):
        return {
            "member": self.member,
        }
class MonitorVRRPDTO(BaseModel):
    target: str

VRRP = VRRPConfig
