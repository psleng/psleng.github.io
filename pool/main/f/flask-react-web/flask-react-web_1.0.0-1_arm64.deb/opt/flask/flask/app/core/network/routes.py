from app.core.network import vyos_network_bp
from flask import jsonify, request
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.network.dns.models import CreateDNSServerDTO, DeleteDNSServerDTO, DNSForwarding, DNSForwardingHostname, DNSForwardingIP, UpdateDNSDTO, DNSServer, DNSDynamicHostGroup, DNSDynamicInterface, \
    UpdateDynamicDNSDTO
from app.auth.utils import login_required
from app.log.logger import logger
from app.core.network.dns.jobs.dns_server import refresh_db_dns_server
from app.core.network.dns.jobs.dns_dynamic import refresh_db_dns_dynamic
from app.core.network.dns.jobs.dns import refresh_db_dns
from app.core.network.dns.cmd.compare_dns import compare_dns_forward
from app.core.api.http.cmd.compare import compare_configs
from app.core.network.dns.parser import parse_to_dns_dynamic_config
from app.core.network.dns.hostname_mapping.parser import parse_to_hostname_mapping_config, parse_to_hostname_mapping_verify_config
from app.core.network.dns.hostname_mapping.models import HostnameMappingConfig, UpdateHostnameMappingsDTO
from app.core.models import Interface
from app.core.network.nat.models import NATv4
import pprint
from app.core.network.nat.models import VerifyNATDTO, UpdateNATDTO
from app.core.network.nat.parser import parse_to_nat_config
from app.core.network.dhcp.models import VerifyDHCPDTO, UpdateDHCPDTO, DHCPPool, DHCPListenInterface, DHCPRelay, SUBNETDTO, DHCPPoolv6, DHCPListenInterfacev6
from app.core.network.dhcp.parser import parse_to_dhcp_config
from app.core.models import ServiceState
from app.core.network.dhcp.utils import is_subnet_connected
from app.core.network.ntp.models import NTPConfig, NTPAllowClient, NTPServer, NTPPTP, NTPDTO
from app.core.network.ntp.parser import parse_to_ntp_config
from app.core.network.ipv6_ra.models import IPv6RA
from pydantic.networks import IPvAnyAddress
from app.core.network.ipv6_ra.models import IPv6RADTO
from app.core.network.ipv6_ra.parser import parse_to_ipv6_ra_config
from pydantic import ValidationError
from app.core.utils.validate.pydantic_error_format import format_pydantic_error
from app.core.utils.validate.verify_parser import format_verify
from app.core.network.snmp.models import UpdateSNMPDTO, SNMPConfig, MonitorSNMPDTO
from app.core.network.snmp.parser import parse_to_snmp_config
import pprint
from app.core.network.https.models import HTTPSConfig, HTTPSAllowClient, HTTPSListenAddress, HTTPSTlsVersion, HTTPSApiKey, HTTPSDTO
from app.core.network.https.parser import parse_to_https_config
from app.core.network.ssh.models import SSHConfig, SSHDTO
from app.core.network.ssh.parser import parse_to_ssh_config
from app.core.options.models import OptionDefinition
from app.core.network.arp.models import ARPEntry, ARPDTO
from app.core.network.arp.parser import parse_to_arp_config
from app.core.network.ndp_proxy.models import (
    NDPNeighborAddressResetDTO,
    NDPNeighborInterfaceResetDTO,
    NDPProxyConfig,
    NDPProxyDTO,
)
from app.core.network.ndp_proxy.parser import parse_ndp_proxy_config, parse_to_ndp_proxy_config
from app.core.utils.decorator.route_decorator import Pipeline
admin_network = Pipeline.admin(vyos_network_bp)

@vyos_network_bp.route('/dns/hostname-mapping', methods=['GET'])
@login_required
def get_dns_hostname_mapping():
    try:
        return jsonify(HostnameMappingConfig.get_config()), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@admin_network.route('/dns/hostname-mapping/verify', methods=['POST'], pause_scheduler=False)
def verify_dns_hostname_mapping():
    try:
        data = UpdateHostnameMappingsDTO.model_validate_json(request.data)
        config = parse_to_hostname_mapping_config(data.model_dump(mode='json')['mappings'])
        verify_config = parse_to_hostname_mapping_verify_config(config)
        result = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DNS_HOSTNAME_MAPPING, data=verify_config)
        if isinstance(result, Exception):
            raise result
        result = format_verify(str(result))
        if str(result).strip() not in ('None', '', '{}'):
            return jsonify({'error': str(result)}), 400
        return jsonify({'success': True}), 200
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@admin_network.route('/dns/hostname-mapping', methods=['PUT'])
def update_dns_hostname_mapping():
    try:
        data = UpdateHostnameMappingsDTO.model_validate_json(request.data)
        new_config = parse_to_hostname_mapping_config(data.model_dump(mode='json')['mappings'])
        current = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_HOSTNAME_MAPPING)
        if isinstance(current, Exception):
            raise current
        current_config = parse_to_hostname_mapping_config(current['mappings'])
        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.DNS_HOSTNAME_MAPPING,
            data={
                'current': current_config,
                'new': new_config,
                'diff': compare_configs(new_config, current_config),
            },
        )
        if isinstance(result, Exception):
            raise result
        for item in result:
            if item.get('success') is not True:
                return jsonify({'error': item.get('error') or 'Unable to save hostname mappings.'}), 400
        return jsonify({'success': True}), 200
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/host-table', methods=['GET'])
def get_host_table():
    data = [
        {'host_name': 'example.com', 'ip_address': '1.1.1.1'},
        {'host_name': 'example-2.com', 'ip_address': '1.1.10.10'}
    ]
    return jsonify(data), 200

@vyos_network_bp.route('/host-table', methods=['POST'])
def create_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/host-table', methods=['PUT'])
def update_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/host-table', methods=['DELETE'])
def delete_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/dns', methods=['GET'])
@login_required
def get_dns():
    try:
        # DNS Server
        records = DNSServer.query.all()
        dns_server = {
            "ipv4": [],
            "ipv6": [],
            "interface": []
        }
        for record in records:
            data = record.serialize()
            if data["ip_address_type"] == "ipv4":
                dns_server["ipv4"].append(data["ip_address"])
            elif data["ip_address_type"] == "ipv6":
                dns_server["ipv6"].append(data["ip_address"])
            elif data["ip_address_type"] == "interface":
                dns_server["interface"].append(data["ip_address"])
                
        # DNS Forward
        dns_forward = DNSForwarding.query.first()
        if dns_forward:
            dns_forward = dns_forward.serialize()
        
        # DNS Dynamic
        host_groups = DNSDynamicHostGroup.query.all()
        ifaces = DNSDynamicInterface.query.all()
        host_groups = [group.serialize() for group in host_groups]
        ifaces = [iface.serialize() for iface in ifaces]
        
        # Interface List
        interfaces = Interface.get_interface_names()

        return jsonify({
            "dns_server": dns_server, 
            "forwarding": dns_forward, 
            "ddns": {
                "host_group": host_groups, 
                "dns_interface": ifaces
            },
            "interfaces": interfaces
        }), 200
    except Exception as e:
        print(e)
        return jsonify({
            "dns_server": {
                "ipv4": [],
                "ipv6": [],
                "interface": []
            },
            "forwarding": None,
            "ddns": {
                "host_group": [],
                "dns_interface": []
            }
        }), 400


@vyos_network_bp.route('/dns/server', methods=['GET'])
@login_required
def get_dns_server():
    try:
        records = DNSServer.query.all()
        response = {
            "ipv4": [],
            "ipv6": [],
            "interface": []
        }

        for record in records:
            data = record.serialize()
            if data["ip_address_type"] == "ipv4":
                response["ipv4"].append(data["ip_address"])
            elif data["ip_address_type"] == "ipv6":
                response["ipv6"].append(data["ip_address"])
            elif data["ip_address_type"] == "interface":
                response["interface"].append(data["ip_address"])

        return jsonify(response), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/server', methods=['POST'])
@login_required
def create_dns_server():
    try:
        data = CreateDNSServerDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.DNS_SERVER, data=data)
        refresh_db_dns_server()
        return jsonify(res), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/server', methods=['DELETE'])
@login_required
def delete_dns_server():
    try:
        data = DeleteDNSServerDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.DELETE, target=API_TARGET.DNS_SERVER, data=data)
        refresh_db_dns_server()
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/forward', methods=['GET'])
def get_dns_forward():
    try:
        res = DNSForwarding.query.first().serialize()
        return jsonify(res), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/forward', methods=['PUT'])
@login_required
def update_dns_forward():
    try:
        data = UpdateDNSDTO.model_validate_json(request.data)
        print(data)
        new_dns_forward = data.forwarding
        print(new_dns_forward)

        # Query in VyOS
        current_dns_forward = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_FORWARD)
        diff = (
            compare_dns_forward(new_dns_forward, current_dns_forward)
            if new_dns_forward
            else compare_configs({}, current_dns_forward)
        )

        # Send updates to VyOS
        if diff.get('created') or diff.get('deleted'):
            print("Diff data:", diff)
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_FORWARD,
                data={"current": current_dns_forward, "new": new_dns_forward, "diff": diff}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            else:
                return jsonify(res), 200

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        return jsonify({"message": "No changes detected"}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/dynamic', methods=['GET'])
@login_required
def get_dns_dynamic():
    try:
        host_groups = DNSDynamicHostGroup.query.all()
        ifaces = DNSDynamicInterface.query.all()
        host_groups = [group.serialize() for group in host_groups]
        ifaces = [iface.serialize() for iface in ifaces]

        return jsonify({
            "host_groups": host_groups,
            "ifaces": ifaces
        }), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/dynamic', methods=['PUT'])
@login_required
def update_dns_dynamic():
    try:
        data = UpdateDynamicDNSDTO.model_validate_json(request.data)
        print(data)
        return jsonify({"message": "Success"}), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/monitor/dynamic-status', methods=['GET'])
@login_required
def get_dns_dynamic_status_monitor():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_DYNAMIC_STATUS)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/nameservers', methods=['GET'])
@login_required
def get_dns_nameservers_monitor():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_NAMESERVERS)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/forwarding-statistics', methods=['GET'])
@login_required
def get_dns_forwarding_statistics_monitor():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_FORWARDING_STATISTICS)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/dynamic-reset', methods=['POST'])
@login_required
def reset_dns_dynamic_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_DYNAMIC_RESET, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/forwarding-reset', methods=['POST'])
@login_required
def reset_dns_forwarding_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_FORWARDING_RESET, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/dynamic-restart', methods=['POST'])
@login_required
def restart_dns_dynamic_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_DYNAMIC_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/monitor/forwarding-restart', methods=['POST'])
@login_required
def restart_dns_forwarding_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.DNS_FORWARDING_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns', methods=['PUT'])
@login_required
def update_dns():
    try:
        data = UpdateDNSDTO.model_validate_json(request.data)
        # print("Validated data:", data)
        new_dns_forward = data.forwarding
        new_dns_server = data.dns_server
        new_ddns = data.ddns

        # Convert to dict, then save to db
        # DNSForwarding.refresh(new_dns_forward.model_dump())

        # Query in VyOS
        current_dns = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS)
        if isinstance(current_dns, Exception):
            raise current_dns
        current_dns_forward = current_dns["forwarding"] if "forwarding" in current_dns else {}
        current_ddns =  current_dns["dynamic"] if "dynamic" in current_dns else None

        # print("Current DNS data:", current_dns)
        # print("New DNS data:", data)

        current_dns_server = (
            api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_SERVER)
            if new_dns_server is not None else []
        )
        if isinstance(current_dns_server, Exception):
            raise current_dns_server

        # diff = compare_dns_forward(new_dns_forward, current_dns_forward)
        # print("New DNS Forward:", new_dns_forward)
        print("Current DNS Forward:", current_dns_forward)
        print("New DNS Forward:", new_dns_forward)
        # Normalize new_dns_forward domains
        if new_dns_forward:
            for domain in new_dns_forward.domains:
                domain.name_servers = [str(ns) for ns in domain.name_servers]

        # Normalize current_config domains
        for domain in current_dns_forward.get('domains', []):
            domain['name_servers'] = [str(ns) for ns in domain.get('name_servers', [])]

        if new_dns_forward:
            diff_forward = compare_dns_forward(new_dns_forward, current_dns_forward)
        else:
            diff_forward = compare_configs({}, current_dns_forward)

        # print("Compare DNS Forward:", diff_forward)

        new_dns_server_entries = []
        if new_dns_server is not None:
            for server_type in ('ipv4', 'ipv6', 'interface'):
                for address in getattr(new_dns_server, server_type) or []:
                    new_dns_server_entries.append({
                        'ip_address': address,
                        'ip_address_type': server_type
                    })
        
        print("Current DDNS:", current_ddns)
        print("New DDNS:", new_ddns.model_dump().get('interfaces'))
        print("Parsed New DDNS:", parse_to_dns_dynamic_config(new_ddns.model_dump().get('interfaces')))
        diff_ddns = compare_configs(
            parse_to_dns_dynamic_config(new_ddns.model_dump().get('interfaces')), 
            current_ddns
        )

        print("Compare DNS Dynamic:", diff_ddns)

        # API Manager handles logic
        r = []
        _data = {
            "forwarding": {
                "current": current_dns_forward,
                "new": new_dns_forward,
                "diff": diff_forward
            },
            "dynamic": {
                "current": current_ddns,
                "new": new_ddns,
                "diff": diff_ddns
            }
        }

        # Update DNS Forwarding
        if diff_forward.get('created') or diff_forward.get('deleted'):
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_FORWARD,
                data={"current": current_dns_forward, "new": new_dns_forward, "diff": diff_forward}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            r += res
        else:
            DNSForwarding.refresh(new_dns_forward.model_dump() if new_dns_forward else {})

        if new_dns_server is not None:
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_SERVER,
                data={"current": current_dns_server, "new": new_dns_server_entries}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            if res:
                r += res
                refresh_db_dns_server()

        # Update DNS Dynamic
        if diff_ddns.get('created') or diff_ddns.get('deleted'):
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_DYNAMIC,
                data={"current": current_ddns, "new": new_ddns, "diff": diff_ddns}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            r += res
            refresh_db_dns_dynamic()
        
        # Update combined dns_dynamic and dns_forward
        # res = api_manager.call(action=API_ACTION.UPDATE, target=API_TARGET.DNS, data=_data)
        # if isinstance(res, Exception):
        #     return jsonify({'error': str(res)}), 400
        # r += res
        # refresh_db_dns()

        return jsonify(r), 200

    except Exception as e:
        print("Exception:", e)
        print("Type: ", type(e))
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat', methods=['GET'])
@login_required
def get_nat():
    try:
        interfaces = Interface.get_interface_names()
        nat = NATv4.query.all()
        nat_dict = {
            "interfaces": interfaces,
            "nat_v4": []
        }
        for n in nat:
            nat_dict["nat_v4"].append(n.serialize())
        
        # nat_query = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT)
        return jsonify(nat_dict), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat', methods=['PUT'])
@login_required
def update_nat():
    try:
        data = UpdateNATDTO.model_validate_json(request.data)
        print("Validated data:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT)
        print("Current NAT Config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        # Parse new config to VyOS format
        new_config = parse_to_nat_config(data.model_dump())
        print("New config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.NAT, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/verify', methods=['POST'])
@login_required
def verify_nat():
    try:
        data = VerifyNATDTO.model_validate_json(request.data)
        print("Unparsed config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        nat_config = parse_to_nat_config(data.model_dump())
        print("Parsed config: ")
        print(pprint.pformat(nat_config, indent=2, width=80))
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.NAT, data=nat_config)
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/nat/stat', methods=['GET'])
@login_required
def get_nat_stat():
    try:
        nat_source_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'source'})
        nat_destination_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'destination'})

        return jsonify({
            'source': nat_source_stat,
            'destination': nat_destination_stat
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/destination', methods=['GET'])
@login_required
def get_nat_destination():
    try:
        nat_destination = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_DESTINATION)
        return jsonify(nat_destination), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/source', methods=['GET'])
@login_required
def get_nat_source():
    try:
        nat_source = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_SOURCE)
        return jsonify(nat_source), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400



@vyos_network_bp.route('/nat/source/stat', methods=['GET'])
@login_required
def get_nat_source_stat():
    try:
        nat_source_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'source'})
        return jsonify(nat_source_stat), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/nat/destination/stat', methods=['GET'])
@login_required
def get_nat_destination_stat():
    try:
        nat_destination_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'destination'})
        return jsonify(nat_destination_stat), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp', methods=['GET'])
@login_required
def get_dhcp():
    try:
        listen_interfaces = DHCPListenInterface.query.all()
        pools = DHCPPool.query.all()
        relay = DHCPRelay.query.first()
        listen_interfaces_v6 = DHCPListenInterfacev6.query.all()
        pools_v6 = DHCPPoolv6.query.all()
        interfaces = Interface.get_interface_names()
        dhcp_state = ServiceState.get_state('dhcp_server')
        dhcpv6_state = ServiceState.get_state('dhcpv6_server')
        
        response = {
            "dhcp": {
                "listen_interface": [l.interface for l in listen_interfaces],
                "pools": [p.serialize() for p in pools],
                "disabled": dhcp_state == 'disable'
            },
            "dhcpv6": {
                "listen_interface": [l.interface for l in listen_interfaces_v6],
                "pools": [p.serialize() for p in pools_v6],
                "disabled": dhcpv6_state == 'disable'
            },
            "dhcpRelays": relay.serialize() if relay else None,
            "interfaces": interfaces
        }
        
        return jsonify(response), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/verify', methods=['POST'])
@login_required
def verify_dhcp():
    try:
        
        data = VerifyDHCPDTO.model_validate_json(request.data)
        
        print("Unparsed config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        
        dhcp_config = parse_to_dhcp_config(data.model_dump())
        
        print("Parsed config: ")
        print(pprint.pformat(dhcp_config, indent=2, width=80))
        
        if data.verify_type == "dhcp":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCP, data=dhcp_config.get("dhcp", {}))
        elif data.verify_type == "dhcpv6":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCPV6, data=dhcp_config.get("dhcpv6", {}))
        elif data.verify_type == "relay":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCP_RELAY, data=dhcp_config.get("dhcp_relay", {}))
        else:
            return jsonify({"error": "Invalid verify type"}), 400

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp', methods=['PUT'])
@login_required
def update_dhcp():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP
        new_config = dhcp_config.get("dhcp", {})
        print("Parsed config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCP, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        # Refresh DB
        # If failed to update, return old configs
        # If success, return new configs
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except Exception as e:
        print("Exception:", e.message)
        return jsonify({'error': str(e)}), 400

    
@vyos_network_bp.route('/dhcpv6', methods=['PUT'])
@login_required
def update_dhcpv6():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP
        new_config = dhcp_config.get("dhcpv6", {})
        print("Parsed config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCPV6, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/relay', methods=['PUT'])
@login_required
def update_dhcp_relay():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP Relay
        new_relay_config = dhcp_config.get("dhcp_relay", {})
        print("Parsed relay config: ")
        print(pprint.pformat(new_relay_config, indent=2, width=80))

        current_relay_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_RELAY)
        print("Current relay config: ")
        print(pprint.pformat(current_relay_config, indent=2, width=80))
        
        relay_diff = compare_configs(new_relay_config, current_relay_config)
        print("Diff relay config: ")
        print(pprint.pformat(relay_diff, indent=2, width=80))
        
        relay_res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCP_RELAY, 
            data={"current": current_relay_config, "new": new_relay_config, "diff": relay_diff}
        )

        if isinstance(relay_res, Exception):
            return jsonify({'error': str(relay_res)}), 400
        else:
            return jsonify(relay_res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/relay', methods=['GET'])
@login_required
def get_dhcp_relay():
    try:
        dhcp_relay = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_RELAY)
        
        return jsonify(dhcp_relay), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/stat', methods=['GET'])
@login_required
def get_dhcp_stat():
    try:
        dhcp_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_POOL_STATISTICS)
        return jsonify(dhcp_stat), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/pool', methods=['GET'])
@login_required
def get_dhcp_pool():
    try:
        dhcp_pool = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_POOL_LIST)
        return jsonify(dhcp_pool), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcpv6/stat', methods=['GET'])
@login_required
def get_dhcpv6_stat():
    try:
        dhcpv6_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6_POOL_STATISTICS)
        return jsonify(dhcpv6_stat), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcpv6/pool', methods=['GET'])
@login_required
def get_dhcpv6_pool():
    try:
        dhcpv6_pool = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6_POOL_LIST)
        return jsonify(dhcpv6_pool), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/restart', methods=['POST'])
@login_required
def restart_dhcp_server():
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DHCP_SERVER_RESTART,
            data={}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcpv6/restart', methods=['POST'])
@login_required
def restart_dhcpv6_server():
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.DHCPV6_SERVER_RESTART,
            data={}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/lease/clear', methods=['POST'])
@login_required
def clear_dhcp_server_lease():
    try:
        payload = request.get_json(silent=True) or {}
        family = payload.get('family')
        address = payload.get('address')
        vrf = payload.get('vrf', "")
        if family not in ['inet', 'inet6']:
            return jsonify({'error': 'Missing or invalid required field: family'}), 400
        if not address:
            return jsonify({'error': 'Missing required field: address'}), 400

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.SERVER_LEASE_DHCP,
            data={"family": family, "vrf": vrf, "address": address}
        )
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/subnet', methods=['POST'])
@login_required
def query_subnet():
    try:
        data = SUBNETDTO.model_validate_json(request.data)
        ip = is_subnet_connected(data.subnet)
        return jsonify({"ip": ip}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp', methods=['GET'])
@login_required
def get_ntp_config():
    try:
        ntp_config_data = NTPConfig.query.first()
        if not ntp_config_data:
            return jsonify({"error": "No NTP configuration found"}), 404
        
        result = ntp_config_data.serialize()
        
        allow_clients = NTPAllowClient.query.all()
        result['allow_clients'] = [client.serialize() for client in allow_clients]
        
        servers = NTPServer.query.all()
        result['servers'] = [server.serialize() for server in servers]
        
        ptp_config = NTPPTP.query.first()
        if ptp_config:
            result['ptp'] = ptp_config.serialize()
        else:
            result['ptp'] = None
        
        interfaces = Interface.get_interface_names()
        result['available_interfaces'] = interfaces
        
        return jsonify(result), 200
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ipv6ra/verify', methods=['POST'])
@login_required
def verify_ipv6_ra():
    try:
        data = IPv6RADTO.model_validate_json(request.data)
        new_ipv6_ra_config = parse_to_ipv6_ra_config(data.model_dump())

        verify = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.IPV6_RA,
            data=new_ipv6_ra_config
        )

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400

    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp', methods=['PUT'])
@login_required
def update_ntp():
    try:
        data = NTPDTO.model_validate_json(request.data)
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_ntp_config = parse_to_ntp_config(data.model_dump())
        print(pprint.pformat(new_ntp_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_ntp_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.NTP, 
            data={"current": current_config, "new": new_ntp_config, "diff": diff}
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200


        return jsonify({"success": True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp/system', methods=['GET'])
@login_required
def get_ntp_system():
    try:
        ntp_system = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP_SYSTEM)
        return jsonify(ntp_system), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp/source', methods=['GET'])
@login_required
def get_ntp_source():
    try:
        ntp_source = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP_SOURCE)
        return jsonify(ntp_source), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp/restart', methods=['POST'])
@login_required
def restart_ntp_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.NTP_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/https', methods=['GET'])
@login_required
def get_https_config():
    try:
        https_config_data = HTTPSConfig.query.first()
        if not https_config_data:
            return jsonify({
                'allow_clients': [],
                'listen_addresses': [],
                'tls_versions': [],
                'api': {'keys': []}
            }), 200

        result = https_config_data.serialize()

        allow_clients = HTTPSAllowClient.query.all()
        result['allow_clients'] = [c.serialize() for c in allow_clients]

        listen_addresses = HTTPSListenAddress.query.all()
        result['listen_addresses'] = [a.address for a in listen_addresses]

        tls_versions = HTTPSTlsVersion.query.all()
        result['tls_versions'] = [t.version for t in tls_versions]

        api_keys = HTTPSApiKey.query.all()
        if 'api' not in result or result['api'] is None:
            result['api'] = {}
        result['api']['keys'] = [k.serialize() for k in api_keys]

        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/https', methods=['PUT'])
def update_https():
    try:
        data = HTTPSDTO.model_validate_json(request.data)
        new_https_config = parse_to_https_config(data.model_dump())

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.HTTPS)
        diff = compare_configs(new_https_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.HTTPS,
            data={'current': current_config, 'new': new_https_config, 'diff': diff}
        )

        # Update DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={'refresh': True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ssh', methods=['GET'])
@login_required
def get_ssh_config():
    try:
        config = SSHConfig.query.first()
        return jsonify(config.serialize() if config else {}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ssh/options', methods=['GET'])
@login_required
def get_ssh_options():
    try:
        rows = OptionDefinition.query.filter_by(namespace='ssh').order_by(
            OptionDefinition.name
        ).all()
        return jsonify({row.name: row.serialize() for row in rows}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ssh/monitor/fingerprints', methods=['GET'])
@login_required
def get_ssh_fingerprints():
    try:
        ascii_enabled = request.args.get('ascii', 'false').lower() in ('1', 'true', 'yes')
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.SSH_FINGERPRINTS,
            data={'ascii': ascii_enabled},
        )
        return jsonify({'result': result}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ssh/monitor/dynamic-protection', methods=['GET'])
@login_required
def get_ssh_dynamic_protection():
    try:
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.SSH_DYNAMIC_PROTECTION,
        )
        return jsonify({'result': result}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/ssh', methods=['PUT'])
def update_ssh_config():
    try:
        data = SSHDTO.model_validate_json(request.data)
        dto_data = data.model_dump()
        new_config = parse_to_ssh_config(dto_data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SSH)

        diff = compare_configs(new_config, current_config or {})
        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SSH,
            data={
                'enabled': dto_data['enabled'],
                'current': current_config or {},
                'new': new_config,
                'diff': diff
            }
        )

        if isinstance(result, Exception):
            return jsonify({'error': str(result)}), 400

        api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.OS_CONFIG,
            data={'refresh': True}
        )

        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ssh/verify', methods=['POST'])
@login_required
def verify_ssh_config():
    try:
        data = SSHDTO.model_validate_json(request.data)
        config = parse_to_ssh_config(data.model_dump())
        result = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.SSH,
            data=config
        )
        if result not in (None, '', {}, 'None', 'null'):
            return jsonify({'verify': result}), 400
        return jsonify({'verify': 'Success'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp', methods=['GET'])
@login_required
def get_arp_config():
    try:
        entries = ARPEntry.query.all()
        return jsonify({'entries': [e.serialize() for e in entries]}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/arp', methods=['PUT'])
def update_arp():
    try:
        data = ARPDTO.model_validate_json(request.data)
        new_arp_config = parse_to_arp_config(data.model_dump())

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.ARP)
        diff = compare_configs(new_arp_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.ARP,
            data={'current': current_config, 'new': new_arp_config, 'diff': diff}
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={'refresh': True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/arp/verify', methods=['POST'])
def verify_arp():
    try:
        data = ARPDTO.model_validate_json(request.data)
        arp_config = parse_to_arp_config(data.model_dump())

        verify_payload = arp_config.get('protocols', {}).get('static', {}).get('arp', {})
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.ARP, data=verify_payload)

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ndp-proxy', methods=['GET'])
@login_required
def get_ndp_proxy():
    try:
        config = NDPProxyConfig.query.first()
        if config:
            return jsonify(config.serialize()), 200

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NDP_PROXY)
        return jsonify(parse_ndp_proxy_config(current_config)), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/ndp-proxy', methods=['PUT'])
def update_ndp_proxy():
    try:
        data = NDPProxyDTO.model_validate_json(request.data)
        new_config = parse_to_ndp_proxy_config(data.model_dump(exclude_none=True))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NDP_PROXY)
        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.NDP_PROXY,
            data={'current': current_config, 'new': new_config, 'diff': diff}
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={'refresh': True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except ValidationError as e:
        return jsonify({'error': format_pydantic_error(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_network.route('/ndp-proxy/verify', methods=['POST'])
def verify_ndp_proxy():
    try:
        data = NDPProxyDTO.model_validate_json(request.data)
        config = parse_to_ndp_proxy_config(data.model_dump(exclude_none=True))
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.NDP_PROXY, data=config)
        if verify and verify not in ('None', 'null'):
            return jsonify({'error': str(verify)}), 400
        return jsonify({'message': 'Success'}), 200
    except ValidationError as e:
        return jsonify({'error': format_pydantic_error(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp/monitor/ipv4', methods=['GET'])
@login_required
def monitor_arp_ipv4():
    try:
        rows = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.ARP_MONITOR_IPV4)
        return jsonify(rows), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp/monitor/ipv6', methods=['GET'])
@login_required
def monitor_arp_ipv6():
    try:
        rows = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.ARP_MONITOR_IPV6)
        return jsonify(rows), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp/monitor/reset/table', methods=['POST'])
@login_required
def reset_arp_table_monitor():
    try:
        result = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.ARP_RESET_TABLE)
        return jsonify(result), 200
    except Exception as e:
            return jsonify({'error': str(e)}), 400
    
@vyos_network_bp.route('/ndp-proxy/monitor', methods=['GET'])
@login_required
def monitor_ndp_proxy():
    try:
        rows = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.NDP_PROXY_MONITOR)
        return jsonify(rows), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp/monitor/reset/address', methods=['POST'])
@login_required
def reset_arp_address_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        address = str(payload.get('address') or '').strip()
        try:
            parsed_address = IPvAnyAddress(address)
        except ValueError:
            return jsonify({'error': 'A valid IPv4 address is required'}), 400
        if parsed_address.version != 4:
            return jsonify({'error': 'A valid IPv4 address is required'}), 400

        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.ARP_RESET_ADDRESS,
            data={'address': address}
        )
        return jsonify(result), 200
    except Exception as e:
            return jsonify({'error': str(e)}), 400
    
@vyos_network_bp.route('/ndp-proxy/monitor/reset/address', methods=['POST'])
@login_required
def reset_ndp_proxy_neighbor_address():
    try:
        data = NDPNeighborAddressResetDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.NDP_PROXY_RESET_ADDRESS,
            data={'address': str(data.address)},
        )
        return jsonify(result), 200
    except ValidationError as e:
        return jsonify({'error': format_pydantic_error(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/arp/monitor/reset/interface', methods=['POST'])
@login_required
def reset_arp_interface_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        interface = str(payload.get('interface') or '').strip()
        if not interface:
            return jsonify({'error': 'Interface is required'}), 400

        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.ARP_RESET_INTERFACE,
            data={'interface': interface}
        )
        return jsonify(result), 200
    except Exception as e:
            return jsonify({'error': str(e)}), 400
    
@vyos_network_bp.route('/ndp-proxy/monitor/reset/interface', methods=['POST'])
@login_required
def reset_ndp_proxy_neighbors_interface():
    try:
        data = NDPNeighborInterfaceResetDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.NDP_PROXY_RESET_INTERFACE,
            data={'interface': data.interface},
        )
        return jsonify(result), 200
    except ValidationError as e:
        return jsonify({'error': format_pydantic_error(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ipv6ra', methods=['GET'])
@login_required
def get_ipv6_ra():
    try:
        ipv6_ra_records = IPv6RA.query.all()
        interfaces = [record.serialize() for record in ipv6_ra_records]
        
        result = {'interfaces': interfaces}
        
        return jsonify(result), 200
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ipv6ra', methods=['PUT'])
@login_required
def update_ipv6_ra():
    try:
        
        data = IPv6RADTO.model_validate_json(request.data)
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_ipv6_ra_config = parse_to_ipv6_ra_config(data.model_dump())
        print(pprint.pformat(new_ipv6_ra_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.IPV6_RA)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_ipv6_ra_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.IPV6_RA, 
            data={"current": current_config, "new": new_ipv6_ra_config, "diff": diff}
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/snmp', methods=['GET'])
@login_required
def get_snmp():
    try:
        snmp_config = SNMPConfig.query.first()
        if not snmp_config:
            return jsonify({"error": "No SNMP configuration found"}), 404
        
        result = snmp_config.serialize()
        
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/snmp', methods=['PUT'])
@login_required
def update_snmp():
    try:
        data = UpdateSNMPDTO.model_validate_json(request.data)
        new_snmp_config = data.model_dump(by_alias=True, exclude_none=True)
        print("New SNMP config from DTO:")
        print(pprint.pformat(new_snmp_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SNMP)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_snmp_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.SNMP, 
            data={"current": current_config, "new": new_snmp_config, "diff": diff}
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    
    except ValidationError as e:
        formatted_error = format_pydantic_error(e)
        return jsonify({'error': formatted_error}), 400
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/snmp/monitor', methods=['POST'])
@login_required
def monitor_snmp():
    try:
        data = MonitorSNMPDTO.model_validate_json(request.data)
        
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.SNMP, data=data)

        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_network_bp.route('/snmp/restart', methods=['POST'])
@login_required
def restart_snmp_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.SNMP_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400
