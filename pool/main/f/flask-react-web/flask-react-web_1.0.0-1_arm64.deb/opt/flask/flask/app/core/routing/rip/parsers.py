def _has_non_empty_value(value):
    return value is not None and str(value).strip() != ''


def _parse_interfaces_to_vyos_config(data):
    interfaces = {}
    for intf in data.get('interfaces', []):
        if not _has_non_empty_value(intf.get('name')):
            continue
        
        intf_config = {}
        
        if _has_non_empty_value(intf.get('authPlaintextPassword')):
            intf_config['authentication'] = {
                'plaintext-password': intf['authPlaintextPassword']
            }
        
        if _has_non_empty_value(intf.get('receiveVersion')):
            intf_config['receive'] = {'version': intf['receiveVersion']}
        
        if _has_non_empty_value(intf.get('sendVersion')):
            intf_config['send'] = {'version': intf['sendVersion']}
        
        split_horizon = intf.get('splitHorizon', 'enabled')
        if split_horizon == 'enabled':
            intf_config['split-horizon'] = {}
        elif split_horizon == 'disabled':
            intf_config['split-horizon'] = {'disable': {}}
        elif split_horizon == 'poison-reverse':
            intf_config['split-horizon'] = {'poison-reverse': {}}
        
        interfaces[intf['name']] = intf_config
    
    return interfaces


def _parse_redistribution_to_vyos_config(data):
    redistribution = {}
    redist = data.get('redistribution', {})
    
    for protocol in ['connected', 'kernel', 'ospf', 'static']:
        if redist.get(protocol, {}).get('enabled'):
            proto_config = {}
            if _has_non_empty_value(redist[protocol].get('metric')):
                proto_config['metric'] = redist[protocol]['metric']
            redistribution[protocol] = proto_config if proto_config else {}
    
    return redistribution


def _parse_advanced_to_vyos_config(data):
    config = {}
    advanced = data.get('advanced', {})
    
    if _has_non_empty_value(advanced.get('defaultDistance')):
        config['default-distance'] = advanced['defaultDistance']
    
    if advanced.get('defaultInformationOriginate'):
        config['default-information'] = {'originate': {}}
    
    if _has_non_empty_value(advanced.get('defaultMetric')):
        config['default-metric'] = advanced['defaultMetric']
    
    if _has_non_empty_value(advanced.get('version')):
        config['version'] = advanced['version']
    
    timers = {}
    if _has_non_empty_value(advanced.get('timersGarbageCollection')):
        timers['garbage-collection'] = advanced['timersGarbageCollection']
    if _has_non_empty_value(advanced.get('timersTimeout')):
        timers['timeout'] = advanced['timersTimeout']
    if _has_non_empty_value(advanced.get('timersUpdate')):
        timers['update'] = advanced['timersUpdate']
    
    if timers:
        config['timers'] = timers
    
    if advanced.get('neighbors'):
        neighbors = [neighbor for neighbor in advanced['neighbors'] if _has_non_empty_value(neighbor)]
        if neighbors:
            config['neighbor'] = neighbors
    
    return config


def parse_to_vyos_config(data):
    """Convert RIP DTO to VyOS configuration format"""
    config = {}

    if data.get('networks'):
        networks = [network for network in data['networks']]
        if len(networks) == 1:
            config['network'] = networks[0]
        else:
            config['network'] = networks
    
    if data.get('networkDistances'):
        network_distances = {}
        for net_dist in data['networkDistances']:
            if isinstance(net_dist, dict):
                network = net_dist.get('network')
                distance = net_dist.get('distance')
                if _has_non_empty_value(network):
                    network_distances[network] = {'distance': distance} if _has_non_empty_value(distance) else {}
            else:
                if _has_non_empty_value(net_dist):
                    network_distances[net_dist] = {}
        if network_distances:
            config['network-distance'] = network_distances
    
    if data.get('passiveInterfaces'):
        config['passive-interface'] = [intf for intf in data['passiveInterfaces']]
    
    if data.get('routes'):
        routes = [route for route in data['routes']]
        if len(routes) == 1:
            config['route'] = routes[0]
        else:
            config['route'] = routes
    
    interfaces = _parse_interfaces_to_vyos_config(data)
    if interfaces:
        config['interface'] = interfaces
    
    redistribution = _parse_redistribution_to_vyos_config(data)
    if redistribution:
        config['redistribute'] = redistribution
    
    advanced_config = _parse_advanced_to_vyos_config(data)
    config.update(advanced_config)
    
    return config


def parse_to_vyos_config_verify(data):
    """Convert RIP verify DTO to VyOS configuration format"""
    return parse_to_vyos_config(data)
