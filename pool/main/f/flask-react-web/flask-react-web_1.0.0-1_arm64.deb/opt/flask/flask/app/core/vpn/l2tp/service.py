from app.core.vpn.l2tp.command_l2tp import L2TPCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_L2TP
from app.core.vpn.l2tp.models import L2TPConfig

def update_l2tp(provider, data):

    logger.info("Update L2TP:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    
    if not config or config == {}:
        logger.info("Empty config detected - deleting entire L2TP configuration")
        delete_cmd = '{"op": "delete", "path": ["vpn", "l2tp"]}'
        
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_cmd,
            verify=False,
        )

        res_json = res.json()

        if res_json.get('success'):
            logger.info("L2TP configuration deleted successfully")
            L2TPConfig.truncate()
        else:
            logger.error("Failed to delete L2TP configuration: " + str(res_json.get('error')))
            return [{
                 "success": False,
                 "error": res_json.get('error'),                 
                 "cmd": delete_cmd
        }]

        socket_manager.emit_to_user(
            username, 
            event='notification', 
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Delete L2TP",
                "content": "L2TP configuration is successfully deleted"
            }
        )
        return [{"success": True, "cmd": delete_cmd}]
    
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = L2TPCommand(operator='set', resource='vpn')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = L2TPCommand(operator='delete', resource='vpn')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "l2tp"
    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('vpn', {}).get('l2tp', {}).get('remote-access', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('vpn', {}).get('l2tp', {}).get('remote-access', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB:
    L2TPConfig.refresh(config)
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update L2TP",
                "content": "L2TP is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r

def fetch_l2tp_sessions(provider, params=None):
    l2tp_sessions = provider.graphql_service.send_request(function_name="ShowLayerTwoTpServerSessionsPerleL2TpServerQuery", data={}, verify=False)
    data = l2tp_sessions.json().get('data', {})
    return data

def fetch_l2tp_statistics(provider, params=None):
    l2tp_statistics = provider.graphql_service.send_request(function_name="ShowLayerTwoTpServerStatisticsPerleL2TpServerQuery", data={}, verify=False)
    data = l2tp_statistics.json().get('data', {})
    return data

def verify_l2tp(provider, data):
    config_to_verify = data
    verify = provider.verify_service.call_verify("l2tp", config_to_verify)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify


def fetch_l2tp(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_L2TP, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data
