from uuid import uuid4

from flask import has_request_context, session

from app.core.api.http.cmd.command import SHOW_SYSTEM
from app.core.api.http.http_request import Action
from app.core.network.dns.hostname_mapping.command_hostname_mapping import HostnameMappingCommand
from app.core.network.dns.hostname_mapping.models import HostnameMappingConfig
from app.core.network.dns.hostname_mapping.parser import (
    parse_hostname_mappings,
    parse_hostname_mapping_command_config,
    parse_merged_hostname_mapping_config,
    parse_to_hostname_mapping_verify_config,
)
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.core.utils.validate.verify_parser import format_verify
from app.log.logger import logger
from app.socket.socket_manager import socket_manager
import pprint

def update_hostname_mappings(provider, data):
    logger.info('Update hostname mappings:')
    logger.info(data)
    username = session.get('username') if has_request_context() else None
    config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}

    set_cmd = HostnameMappingCommand(operator='set', resource='system')
    set_cmds = set_cmd.generate_commands(
        data=diff.get('created'), current_config=current_config, new_config=config,
    )
    new_set_configs = process_commands(set_cmd.get_commands())

    delete_cmd = HostnameMappingCommand(operator='delete', resource='system')
    delete_cmds = delete_cmd.generate_commands(
        data=diff.get('deleted'), current_config=current_config, new_config=config,
    )
    new_delete_configs = process_commands(delete_cmd.get_commands())

    service = 'system_host_name'
    curr_config = provider.verify_service.call_get_config(service)
    if not isinstance(curr_config, dict) or not curr_config.get('hostname'):
        raise ValueError('Unable to read the system hostname configuration for verification.')
    current_raw_config = parse_hostname_mapping_command_config(curr_config)
    merged_del_config = merge_dicts_delete(
        current_raw_config, new_delete_configs, clean_empty=False, aggressive=True,
    )
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    hostnames = set(curr_config.get('static_host_mapping', {})) | set(config.get('host-name', {}))
    merged_mapping_config = parse_merged_hostname_mapping_config(merged_config, hostnames)
    verify_config = parse_to_hostname_mapping_verify_config(merged_mapping_config, curr_config)
    verify = provider.verify_service.call_verify(service, verify_config)
    verify = format_verify(str(verify))

    cmds = list(dict.fromkeys(delete_cmds + set_cmds))
    if str(verify).strip() not in ('None', '', '{}'):
        return [{'success': False, 'error': str(verify), 'cmd': cmds}]
    

    # Persist db
    HostnameMappingConfig.refresh({'static-host-mapping': merged_mapping_config})
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Hostname Mapping",
                "content": "Hostname Mapping is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r

def verify_hostname_mappings(provider, data):
    config_to_verify = data
    verify = provider.verify_service.call_verify('system_host_name', config_to_verify)
    logger.info('Verify hostname mappings:')
    logger.info(verify)
    return verify


def fetch_hostname_mappings(provider, data=None):
    response = provider.http_service.send_request(
        action=Action.RETRIEVE, data=SHOW_SYSTEM, verify=False,
    ).json()
    if response.get('success') is not True:
        raise ValueError(response.get('error') or 'Unable to load hostname mappings.')
    return {'mappings': parse_hostname_mappings(response.get('data') or {})}
