from app.core.operation.parser import parse_all_interface_config


def test_interface_page_openvpn_site_to_site_uses_local_address():
    records = parse_all_interface_config({
        'interfaces': {
            'openvpn': {
                'vtun0': {
                    'mode': 'site-to-site',
                    'local-address': {'10.10.0.1': {}}
                }
            }
        }
    })

    assert len(records) == 1
    assert records[0]['interface'] == 'vtun0'
    assert records[0]['ip_address'] == ['10.10.0.1']


def test_interface_page_openvpn_client_and_server_hide_ip_address():
    records = parse_all_interface_config({
        'interfaces': {
            'openvpn': {
                'vtun1': {
                    'mode': 'client',
                    'local-address': {'10.10.1.1': {}}
                },
                'vtun2': {
                    'mode': 'server',
                    'local-address': {'10.10.2.1': {}}
                }
            }
        }
    })

    assert len(records) == 2
    assert records[0]['interface'] == 'vtun1'
    assert records[0]['ip_address'] == []
    assert records[1]['interface'] == 'vtun2'
    assert records[1]['ip_address'] == []
