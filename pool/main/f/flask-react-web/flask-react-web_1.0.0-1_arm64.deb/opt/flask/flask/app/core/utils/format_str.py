def encode_description(desc: str) -> str:
    if desc is None:
        return '""'

    s = str(desc)
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s

    return f'"{s}"'

def decode_description(desc: str) -> str:
    if desc is None:
        return ''

    s = str(desc)
    if len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1]

    return s

def encode_entity_name():
    pass
