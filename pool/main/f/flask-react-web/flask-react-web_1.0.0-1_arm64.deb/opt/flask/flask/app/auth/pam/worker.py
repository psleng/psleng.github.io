import json
import os
import sys


MAX_MESSAGE_BYTES = 65536


def main():
    
    with os.fdopen(os.dup(sys.stdout.fileno()), "w", encoding="utf-8") as output:
        os.dup2(sys.stderr.fileno(), sys.stdout.fileno())

        def send(message):
            payload = json.dumps(message) + "\n"
            if len(payload.encode("utf-8")) > MAX_MESSAGE_BYTES:
                raise ValueError("PAM response too large")
            output.write(payload)
            output.flush()

        def receive():
            line = sys.stdin.buffer.readline(MAX_MESSAGE_BYTES + 1)
            if not line or len(line) > MAX_MESSAGE_BYTES:
                raise ValueError("Missing or oversized PAM input")
            return json.loads(line)

        def request_otp(prompt):
            send({"type": "otp", "prompt": prompt})
            return receive().get("otp")

        try:
            from pam_authenticator import ExtendPamAuthenticator

            credentials = receive()
            auth = ExtendPamAuthenticator()
            success = auth.authenticate(
                credentials["username"], 
                credentials["password"],
                service="login", 
                interactive=True, 
                call_end=True,
                otp_callback=request_otp,
            )
            send({"type": "result", "success": success,
                  "reason": str(auth.reason),
                  "privilege_level": auth.get_privilege_level()})
        except Exception as error:
            send({"type": "error", "error_type": type(error).__name__})


if __name__ == "__main__":
    main()
    