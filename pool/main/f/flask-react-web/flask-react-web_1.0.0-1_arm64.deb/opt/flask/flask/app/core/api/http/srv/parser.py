import pprint
from app.log.logger import logger

def parse_to_user_config(data):
    result = {
        'login': {'user': {}}
    }

    if data.get('users'):
        for user in data['users']:
            user_config = parse_to_single_user_config(user)
            result['login']['user'][str(user['user_name'])] = user_config

    return result


def create_user_config(user):
    config = {}
    
    if user.get('password'):
        config['authentication'] = {}
        config['authentication']['plaintext-password'] = user['password']
    if user.get('role'):
        config['type'] = user['role']
    if user.get('disabled') is True:
        config['disable'] = {}
    if  user.get('full_name'):
        config['full-name'] = user['full_name']
    
    return config


def parse_to_single_user_config(user):

    user_config = create_user_config(user)
    if user.get('expiry_time'):
        user_config['expiry-time'] = user['expiry_time']
    return user_config

def parse_user_db_to_user_config(data):
    result = {
        'login': {'user': {}}
    }

    for user in data:
        user_dict = {
            'user_name': user.email,
            'role': 'administrator',
            'disabled': False,
        }

        if hasattr(user, 'temp_user_expiry_time') and user.temp_user_expiry_time:
            user_dict['expiry_time'] = user.temp_user_expiry_time.expiry_time

        user_config = parse_to_single_user_config(user_dict)
        result['login']['user'][user.email] = user_config

    return result


def parse_user_config_to_db(data):
    """
    Parse User configuration from VyOS format to a structure ready for DB
    
    Args:
        Sample input data:
        {"login": {"user": {"test_user": {"authentication": {"plaintext-password": "testing123", "type": "administrator", "disable": {} }, "full-name": "TestName"}}}
    
    """
    logger.debug("Parse user input data: ")
    logger.debug(data)

    result = {
        'users' : {}
    }
    if 'system' in data:
        data = data['system']
    
    if 'login' not in data:
        return result

    user_data = data['login']
    r = []
    
    if 'user' in user_data:
        for user_name, user in user_data['user'].items():
            processed_user = {
                'user-name': user_name
            }

            if 'authentication' in user:
                if 'plaintext-password' in user['authentication']:
                    processed_user['plaintext-password'] = user['authentication']['plaintext-password']
                if 'plaintext_password' in user['authentication']:
                    processed_user['plaintext-password'] = user['authentication']['plaintext_password']

            role = user.get('type', 'administrator')
            operator_group_name = None
            if isinstance(user.get('operator'), dict):
                group_val = user.get('operator', {}).get('group')
                if isinstance(group_val, dict) and len(group_val) > 0:
                    operator_group_name = next(iter(group_val.keys()))
                elif isinstance(group_val, list) and len(group_val) > 0:
                    # handle group as a list ['default'] or ['super-operator']
                    first = next((g for g in group_val if isinstance(g, str) and g.strip()), None)
                    if first:
                        operator_group_name = first.strip()
                elif isinstance(group_val, str) and group_val.strip():
                    operator_group_name = group_val.strip()

            if operator_group_name == 'default':
                role = 'operator'
            elif operator_group_name == 'super-operator':
                role = 'operator+'

            processed_user['type'] = role

            if 'disable' in user:
                processed_user['disable'] = True
            else:
                processed_user['disable'] = False

            if 'full-name' in user:
                processed_user['full-name'] = user['full-name']
            if 'full_name' in user:
                processed_user['full-name'] = user['full_name']
            if 'fullname' in user:
                processed_user['full-name'] = user['fullname']
            
            result['users'][user_name] = processed_user
            r.append(processed_user)
    return r

if __name__ == '__main__':
    test_input = {
        'users' :[
        {
            'user_name': "Andrewp",
            'full_name': "Andrew Peter",
            'password': "yourPasswordHere",
            'type': "administrator",
            'disabled': False,
            'expiry_time': "1h"
        },
        {
            'user_name': "TestUser",
            'full_name': "Test Name",
            'password': "testing123",
            'type': "operator",
            'disabled': True
        }
        ]
    }
    test_auth = {
        "login": {
            "user": {
                "test_user": {
                    "authentication": {
                        "plaintext-password": "testing123"
                    },
                    "type": "administrator",
                    "disable": {},
                    "full-name": "TestName"
                },
                "test_user2": {
                    "authentication": {
                        "plaintext-password": "testing456"
                    },
                    "type": "operator",
                    "full-name": "TestName1"
                }
            }
        } 
    }
    result = parse_to_user_config(test_input)
    print("Parsed React to Vyos Result")
    print(pprint.pformat(result, indent=2, width=80))
    print("Parsed Vyos to DB Result")
    print(pprint.pformat(parse_user_config_to_db(test_auth), indent=2, width=80))