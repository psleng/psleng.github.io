from typing import Literal, Optional
from pydantic import BaseModel, Field
from sqlalchemy import Boolean, Column, Integer, String

from app.db.database import db


def _database_text(value, default=''):
    if isinstance(value, (str, int, float)):
        return str(value)
    return default


def _description_text(value):
    if not isinstance(value, dict):
        return _database_text(value)

    words = []
    for key, nested_value in value.items():
        words.append(str(key))
        nested_description = _description_text(nested_value)
        if nested_description:
            words.append(nested_description)
    return ' '.join(words)


class NAT66Rule(BaseModel):
    rule_id: str = Field(pattern=r'^[1-9][0-9]{0,5}$')
    rule_type: Literal['source', 'destination']
    description: Optional[str] = ''
    disable: bool = False
    exclude: bool = False
    log: bool = False
    protocol: Optional[str] = 'all'
    outbound_interface: Optional[str] = ''
    inbound_interface: Optional[str] = ''
    source_address: Optional[str] = ''
    source_port: Optional[str] = ''
    destination_address: Optional[str] = ''
    destination_port: Optional[str] = ''
    translation_address: Optional[str] = ''
    translation_port: Optional[str] = ''

class NAT66Rules(BaseModel):
    source: list[NAT66Rule] = Field(default_factory=list)
    destination: list[NAT66Rule] = Field(default_factory=list)

class NAT66DTO(BaseModel):
    NATv6: NAT66Rules


class NAT66Config(db.Model):
    __tablename__ = 'nat66'

    id = Column(Integer, primary_key=True)
    rule_type = Column(String, nullable=False)
    rule_id = Column(String, nullable=False)
    description = Column(String, nullable=True)
    protocol = Column(String, nullable=True)
    disable = Column(Boolean, default=False)
    exclude = Column(Boolean, default=False)
    log = Column(Boolean, default=False)
    outbound_interface = Column(String, nullable=True)
    inbound_interface = Column(String, nullable=True)
    source_address = Column(String, nullable=True)
    source_port = Column(String, nullable=True)
    destination_address = Column(String, nullable=True)
    destination_port = Column(String, nullable=True)
    translation_address = Column(String, nullable=True)
    translation_port = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, config):
        """Replace database rows with the supplied VyOS NAT66 config."""
        try:
            cls.truncate()

            for direction in ('source', 'destination'):
                rules = config.get(direction, {}).get('rule', {})
                for rule_id, rule in rules.items():
                    source_address_key = (
                        'prefix' if direction == 'source' else 'address'
                    )
                    db.session.add(
                        cls(
                            rule_type=direction,
                            rule_id=str(rule_id),
                            description=_description_text(
                                rule.get('description', '')
                            ),
                            protocol=_database_text(
                                rule.get('protocol', 'all'), 'all'
                            ),
                            disable='disable' in rule,
                            exclude='exclude' in rule,
                            log='log' in rule,
                            outbound_interface=_database_text(
                                rule.get('outbound-interface', {}).get(
                                    'name', ''
                                )
                            ),
                            inbound_interface=_database_text(
                                rule.get('inbound-interface', {}).get(
                                    'name', ''
                                )
                            ),
                            source_address=_database_text(
                                rule.get('source', {}).get(
                                    source_address_key, ''
                                )
                            ),
                            source_port=_database_text(
                                rule.get('source', {}).get('port', '')
                            ),
                            destination_address=_database_text(
                                rule.get('destination', {}).get('prefix', '')
                            ),
                            destination_port=_database_text(
                                rule.get('destination', {}).get('port', '')
                            ),
                            translation_address=_database_text(
                                rule.get('translation', {}).get('address', '')
                            ),
                            translation_port=_database_text(
                                rule.get('translation', {}).get('port', '')
                            ),
                        )
                    )

            db.session.commit()
        except Exception:
            raise

    def serialize(self):
        return {
            'rule_id': self.rule_id,
            'rule_type': self.rule_type,
            'description': (self.description or '').replace('_', ' '),
            'protocol': self.protocol or 'all',
            'disable': bool(self.disable),
            'exclude': bool(self.exclude),
            'log': bool(self.log),
            'outbound_interface': self.outbound_interface or '',
            'inbound_interface': self.inbound_interface or '',
            'source_address': self.source_address or '',
            'source_port': self.source_port or '',
            'destination_address': self.destination_address or '',
            'destination_port': self.destination_port or '',
            'translation_address': self.translation_address or '',
            'translation_port': self.translation_port or '',
        }
