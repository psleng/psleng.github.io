
from app.core.routing.ospf.command_ospf import OSPFCommand
from app.core.routing.ospf.models import OSPFConfig
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_OSPF

def update_ospf(provider, data):

    logger.info("Update OSPF:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')

    if not config or config == {}:
        print("Empty config detected - deleting entire OSPF configuration")
        delete_cmd = '{"op": "delete", "path": ["protocols", "ospf"]}'
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_cmd,
            verify=False,
        )

        res_json = res.json()

        if res_json.get('success'):
            print("OSPF configuration deleted successfully")
            OSPFConfig.truncate()
        else:
            print("Failed to delete OSPF configuration")
            return [{
                "success": False,
                "error": res_json.get('error'),
                "cmd": delete_cmd
        }]
        
        socket_manager.emit_to_user(
            username, 
            event='notification', 
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Delete OSPF",
                "content": "OSPF configuration deleted successfully"
            }
        )
        
        return [{"cmd": [delete_cmd], "success": res['success'], "error": res['error']}]
    
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = OSPFCommand(operator='set', resource='ospf')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = OSPFCommand(operator='delete', resource='ospf')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "ospf"
    curr_config = provider.verify_service.call_get_config(service)
    current_raw_config = curr_config if curr_config else {}
    print("Current raw config:")
    print(pprint.pformat(current_raw_config, indent=2, width=80))
    
    merged_del_config = merge_dicts_delete(current_raw_config, new_delete_configs.get('protocols', {}).get('ospf', {}), clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('protocols', {}).get('ospf', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB
    OSPFConfig.refresh(merged_config)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update OSPF",
                "content": "OSPF is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_ospf(provider, data):
    config_to_verify = data
    verify = provider.verify_service.call_verify("ospf", config_to_verify)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify


def fetch_ospf(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_OSPF, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data


def fetch_ospf_monitor(provider, data=None):
    keyword = "overview"
    if isinstance(data, dict):
        keyword = data.get("keyword") or keyword

    response = provider.graphql_service.send_request(
        function_name="ShowOspfPerleOspfQuery",
        data={"keyword": f'"{keyword}"'},
        verify=False,
    )

    try:
        return response.json()
    except Exception as e:
        return {
            "error": str(e),
            "status_code": getattr(response, "status_code", None),
            "response_text": getattr(response, "text", None),
        }


def restart_ospfd(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartFrrRestartFrrMutation',
        data={"daemon": "ospfd"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}
