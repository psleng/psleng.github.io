from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
from app.core.operation.ip_options.command_ip_options import IPOptionCommand
from app.core.operation.dhcp_options.command_dhcp_options import DHCPOptionCommand
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']

def format_description(description: str) -> str:
    return description.replace(' ', '_')

class VLANCommand(IfaceCommand):
    """
    VLAN command class:

    - set/delete interface <intf-type> <intf-name> vif <vlan-id>
    - set/delete interface <intf-type> <intf-name> vif <vlan-id> address {x.x.x.x/n | h:h:h:h:h:h:h:h/x | dhcp | dhcpv6}
    - set/delete interface <intf-type> <intf-name> vif <vlan-id> description <text>
    - set/delete interface <intf-type> <intf-name> vif <vlan-id> disable
    - set/delete interface <intf-type> <intf-name> vif <vlan-id> mtu <68-16000>

    Extra:
    - IP options
    - DHCP options
    
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'vlan'),
                name=kwargs.get('name', None)
            )
            self.attributes = {
                'interfaces': {
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing VLAN command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
    
    def get_all_commands(self):
        # VLAN, IP options, and DHCP options
        all_cmds = self.cmds.copy()
        return all_cmds
    
    def get_all_vyos_commands(self):
        # VLAN, IP options, and DHCP options
        all_vyos_cmds = self.vyos_cmds.copy()
        return all_vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            for interface_name, config in data.items():
                if 'vif' in config:
                    intf_type = self._detect_interface_type(interface_name)
                    intf_name = interface_name
                    
                    for vlan_id, vlan_config in config['vif'].items():
                        self._process_vlan_interface(intf_type, intf_name, vlan_id, vlan_config, current_config, new_config)
            
            return self.get_all_commands()
        
        except Exception as e:
            print(f"Error generating VLAN commands: {e}")
            return []
    
    def _detect_interface_type(self, interface_name):

        if interface_name.startswith('eth'):
            return 'ethernet'
        elif interface_name.startswith('br'):
            return 'bridge'
        elif interface_name.startswith('wlan'):
            return 'wireless'
        else:
            # default to ethernet
            return 'ethernet'
    
    def _process_vlan_interface(self, intf_type, intf_name, vlan_id, vlan_config, current_config, new_config):
        base = ['interfaces', intf_type, intf_name, 'vif', str(vlan_id)]

        if self.operator == 'delete' and str(vlan_id) not in new_config.get(intf_name, {}).get('vif', {}):
            # delete entire vlan interface
            self.generate(*base)
            return
        
        if self.operator == 'set':
            self.generate(*base)
        
        if 'address' in vlan_config:
            addresses = vlan_config['address']
            if not isinstance(addresses, list):
                addresses = [addresses]
            for addr in addresses:
                self.generate(*base, 'address', str(addr))
                addr_lower = str(addr).lower()
                if addr_lower == 'dhcp' or addr_lower == 'dhcpv6':
                    vlan_intf_name = f'{intf_name}.{vlan_id}'
                    system_base = ['system', 'name-server', vlan_intf_name]
                    if self.operator == 'set':
                        self.generate(*system_base)
                    elif self.operator == 'delete':
                        self.generate(*system_base)
        
        if 'description' in vlan_config:
            desc = format_description(vlan_config['description'])
            if is_str_not_empty(desc):
                self.generate(*base, 'description', desc)
        
        if 'disable' in vlan_config:
            self.generate(*base, 'disable')
        
        if 'mtu' in vlan_config:
            mtu = vlan_config['mtu']
            if is_str_not_empty(mtu):
                self.generate(*base, 'mtu', str(mtu))
        
        if 'dhcp-options' in vlan_config or 'dhcpv6-options' in vlan_config:
            dhcp_cmd = DHCPOptionCommand(
                operator=self.operator,
                intf_type=intf_type,
                intf_name=intf_name,
                vlan_id=vlan_id
            )
            dhcp_data = {}
            if 'dhcp-options' in vlan_config:
                dhcp_data['dhcp-options'] = vlan_config['dhcp-options']
            if 'dhcpv6-options' in vlan_config:
                dhcp_data['dhcpv6-options'] = vlan_config['dhcpv6-options']
            
            dhcp_cmd.generate_commands(data=dhcp_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(dhcp_cmd.cmds)
            self.vyos_cmds.extend(dhcp_cmd.vyos_cmds)
        
        if 'ip' in vlan_config or 'ipv6' in vlan_config:
            ip_cmd = IPOptionCommand(
                operator=self.operator,
                intf_type=intf_type,
                intf_name=intf_name,
                vlan_id=vlan_id
            )
            ip_data = {}
            if 'ip' in vlan_config:
                ip_data['ip'] = vlan_config['ip']
            if 'ipv6' in vlan_config:
                ip_data['ipv6'] = vlan_config['ipv6']
            ip_cmd.generate_commands(data=ip_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(ip_cmd.cmds)
            self.vyos_cmds.extend(ip_cmd.vyos_cmds)
    
