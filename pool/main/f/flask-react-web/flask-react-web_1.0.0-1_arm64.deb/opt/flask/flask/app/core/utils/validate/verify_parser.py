import re


def extract_config_error_message(message: str) -> str:
    if not message:
        return ''

    match = re.search(r'(?:[\w.]+\.)?ConfigError:\s*(.+)', str(message), re.DOTALL)
    if not match:
        return ''

    return match.group(1).strip()


def format_verify(message: str) -> str:
    """
    Parse VyOS verification output and extract error messages.
    
    - Ignores: 
        - line break
        - empty strings
        - 'None'
    
    Messages are separated by double newlines (\n\n), can start with 'WARNING:'.
    """
    if not message:
        return ''
    
    message = message.strip()
    
    if message == 'None' or not message:
        return ''
    
    message_blocks = message.split('\n\n')
    
    error_blocks = []
    for block in message_blocks:
        block = block.strip()
        
        if not block:
            continue
        
        if block == 'None':
            continue
        
        if block.startswith('WARNING:'):
            continue
        
        error_blocks.append(block)
    
    if error_blocks:
        return '\n\n'.join(error_blocks)
    
    return ''