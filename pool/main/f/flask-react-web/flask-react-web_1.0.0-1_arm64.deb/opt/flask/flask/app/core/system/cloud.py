import json
import subprocess


def set_cloud_connection(action):
    commands = {'connect': 'start', 'disconnect': 'stop'}
    if not isinstance(action, str) or action not in commands:
        raise ValueError('Action must be connect or disconnect')

    subprocess.run(
        ['systemctl', commands[action], 'igos-cloud-proxy'],
        capture_output=True,
        text=True,
        timeout=15,
        check=True,
    )


def get_cloud_status():
    try:
        # Flask service runs as root and can access this socket
        result = subprocess.run(
            [
                'curl', '--silent', '--show-error', '--fail', '--max-time', '3',
                '--unix-socket', '/run/igos-cloud-proxy/local-api.sock',
                'http://localhost/perlecloud/status',
            ],
            capture_output=True,
            text=True,
            timeout=4,
            check=True,
        )
        status = json.loads(result.stdout)
        connected = isinstance(status, dict) and status.get('cloud_connection_status') == 'connected'
        return {'connected': connected}
    except (OSError, subprocess.SubprocessError, ValueError):
        return {'connected': False}
