from app.log.logger import logger
from app.core.operation.bridge.models import BridgeInterfaceConfig
from app.core.operation.bridge.command_bridge import BridgeCommand
from app.core.api.http.cmd.compare import compare_configs
from app.core.api.http.srv.interface import process_commands
from uuid import uuid4
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from app.core.utils.cmd_linux import run_linux_cmd
import pprint
from app.core.operation.bridge.models import BridgeInterfaceConfig
from app.core.models import InterfaceConfig
from flask import session

def fetch_bridge_config(provider, data):

    try:
        bridges = BridgeInterfaceConfig.query.all()
        
        result = {}
        for bridge in bridges:
            result[bridge.interface_name] = bridge.serialize()
        
        logger.info(f"Fetched {len(bridges)} bridge configurations")
        return result
        
    except Exception as e:
        logger.error(f"Error fetching bridge config: {e}")
        return {}


def fetch_bridgeable_interfaces(provider, data):
    try:
        cmd = "/usr/libexec/vyos/completion/list_interfaces --bridgeable"
        output, error = run_linux_cmd(cmd)
        
        if error:
            logger.error(f"Error fetching bridgeable interfaces: {error}")
            return []
        
        if not output:
            logger.warning("No bridgeable interfaces found")
            return []
        
        interfaces = output.split()
        
        filtered_interfaces = [
            iface for iface in interfaces 
            if iface.lower() != 'lo' and not iface.lower().startswith('wlan')
        ]
        
        logger.info(f"Found {len(filtered_interfaces)} bridgeable interfaces: {filtered_interfaces}")
        return filtered_interfaces
        
    except Exception as e:
        logger.error(f"Exception in fetch_bridgeable_interfaces: {e}")
        return []


def create_bridge_interface(provider, data):

    username = session['username']
    name = data.get('name')
    config = data.get('data')

    set_cmds = []
    iface_set_cmd = BridgeCommand(operator='set', resource='bridge', name=name)
    set_cmds = iface_set_cmd.generate_commands(data={name: config})
    if not set_cmds:
        iface_set_cmd.generate('interfaces', 'bridge', name)
        set_cmds = iface_set_cmd.get_all_commands()
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)

    # Validate configs
    service = "bridge"
    merged_config = new_set_configs.get('interfaces', {}).get('bridge', {}).get(name, {})
    merged_config.update({"ifname": name})

    print("Verify merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    verify = None
    if merged_config:
        verify = provider.verify_service.query_interface_verify(
            service, 
            name, 
            merged_config
        )
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    bridge_refresh_config = new_set_configs.get('interfaces', {}).get('bridge', {})
    if not bridge_refresh_config:
        bridge_refresh_config = {name: {}}

    InterfaceConfig.upsert({
        'bridge': bridge_refresh_config
    })
    BridgeInterfaceConfig.upsert(bridge_refresh_config)

    r = []
    cmds = set_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    # Emit notification
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Create Bridge",
                "content": "Bridge is successfully created"
            }
    )

    return r


def _bridge_config_for_name(config, bridge_name):
    if not isinstance(config, dict) or not bridge_name:
        return {}

    if bridge_name in config and isinstance(config[bridge_name], dict):
        return {bridge_name: config[bridge_name]}

    bridges = config.get('interfaces', {}).get('bridge', {})
    if isinstance(bridges, dict) and bridge_name in bridges and isinstance(bridges[bridge_name], dict):
        return {bridge_name: bridges[bridge_name]}

    return {}


def update_bridge_by_name(provider, data):
    
    logger.info("Update Bridge:")
    logger.info(data)
    username = session['username']
    new_config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    bridge_name = data.get('name')

    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(new_config, indent=2, width=80))
    
    set_cmds = []
    iface_set_cmd = BridgeCommand(operator='set', resource='bridge')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=new_config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = BridgeCommand(operator='delete', resource='bridge')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    intf_service = "bridge"

    curr_config = provider.verify_service.query_interface_config(intf_service, bridge_name)
    curr_configs = {
        "interfaces": {
            "bridge": {
                bridge_name: curr_config or {}
            }
        }
    }

    print("Current interfaces configs: ")
    print(pprint.pformat(curr_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(curr_configs, new_delete_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    merged_bridge_config = merged_config.get('interfaces', {}).get('bridge', {}).get(bridge_name, {})

    if merged_bridge_config:
        verify = provider.verify_service.query_interface_verify(
                intf_service, 
                bridge_name, 
                merged_bridge_config
            )
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    
    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": verify, "cmd": cmds}]

    bridge_refresh_config = _bridge_config_for_name(new_config, bridge_name)

    if bridge_refresh_config:
        InterfaceConfig.upsert({
            'bridge': bridge_refresh_config
        })

    # save to db:
    if bridge_refresh_config:
        BridgeInterfaceConfig.upsert(bridge_refresh_config)
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Bridge",
                "content": "Bridge is successfully updated"
            }
    )

    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r
