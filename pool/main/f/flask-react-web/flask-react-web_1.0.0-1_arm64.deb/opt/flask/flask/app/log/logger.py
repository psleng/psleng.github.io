import os
import logging
import traceback
from datetime import datetime
import pprint
from dotenv import load_dotenv
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

LOG_DIR = os.getenv('FLASK_LOG_DIR', '/var/log/flask-react-web')
class Logger:
    def __init__(self, module_name=None, verbose=False):

        self.verbose = verbose
        self.module_name = module_name


        self.debug_mode = self._check_debug_mode()
        self.logging_enabled = self._should_log()

        try:
            if not os.path.exists(LOG_DIR):
                os.makedirs(LOG_DIR)
            self.log_file = os.path.join(LOG_DIR, 'app.log')
        except (OSError, IOError) as e:
            print(f"Error creating log directory {LOG_DIR}: {e}. File logging will be disabled.")
            self.logging_enabled = False
            self.log_file = None
    
    def _check_debug_mode(self):
        env_path = Path(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))) / '.env'
        if env_path.exists():
            load_dotenv(env_path)
            return os.getenv('FLASK_DEBUG', '').lower() == 'true'
        
        return os.getenv('FLASK_DEBUG', '').lower() == 'true'
        
    def _should_log(self):
        env_path = Path(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))) / '.env'
        if env_path.exists():
            load_dotenv(env_path)
            return os.getenv('FLASK_LOG', '').lower() == 'true'
        
        return os.getenv('FLASK_LOG', '').lower() == 'true'
    
    def debug(self, message, *args, **kwargs):        
        self._log(message, 'debug', *args, **kwargs)
    
    def info(self, message, *args, **kwargs):
        self._log(message, 'info', *args, **kwargs)
    
    def warning(self, message, *args, **kwargs):
        self._log(message, 'warning', *args, **kwargs)
    
    def error(self, message, *args, **kwargs):
        self._log(message, 'error', *args, **kwargs)

    def exception(self, message, *args, **kwargs):
        """Log the active exception and its traceback at error level."""
        if args:
            try:
                message = message % args
            except (TypeError, ValueError):
                message = f"{message} {' '.join(map(str, args))}"

        exception_traceback = traceback.format_exc()
        self._log(f"{message}\n{exception_traceback}", 'error', **kwargs)
    
    def log(self, message, *args, **kwargs):
        # set level to debug
        self._log(message, 'debug', *args, **kwargs)
    
    def _log(self, message, level='debug', *args, **kwargs):
        if not self.logging_enabled:
            return

        if self.verbose and not isinstance(message, str):
            log_content = pprint.pformat(message, indent=2, width=80)
        else:
            log_content = message

        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        module_prefix = f"[{self.module_name}] " if self.module_name else ""
        log_entry = f"{timestamp} - {level.upper()} - {module_prefix}{log_content}\n"

        if self.debug_mode:
            print(log_entry.strip())

        if self.log_file:
            try:
                with open(self.log_file, 'a') as f:
                    f.write(log_entry)
            except (OSError, IOError) as e:
                print(f"Error writing to log file: {e}. Disabling file logging.")
                self.log_file = None


# default logger instance
logger = Logger(verbose=True)