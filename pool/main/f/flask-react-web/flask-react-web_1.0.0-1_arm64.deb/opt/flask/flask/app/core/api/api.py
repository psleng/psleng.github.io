from abc import ABC, abstractmethod
from enum import StrEnum


class API(ABC):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def call(self):
        return None

    @abstractmethod
    def get_api_type(self):
        return None


class API_REQUEST(ABC):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def send_request(self):
        return None


class ServiceProvider:
    def __init__(
        self, http_service: API_REQUEST, graphql_service: API_REQUEST, verify_service
    ):
        self.http_service = http_service
        self.graphql_service = graphql_service
        self.verify_service = verify_service


class API_ACTION(StrEnum):
    GENERATE = "GENERATE"
    CREATE = "CREATE"
    READ = "READ"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    VERIFY = "VERIFY"
    MONITOR = "MONITOR"
    REFRESH = "REFRESH"
    AUTH = "AUTH"
    SAVE = "SAVE"


class API_TARGET(StrEnum):
    OS_CONFIG = "OS_CONFIG"
    INTERFACE = "INTERFACE"
    INTERFACE_CONFIG = "INTERFACE_CONFIG"
    INTERFACE_ADDRESS = "INTERFACE_ADDRESS"
    INTERFACE_IPV4 = "INTERFACE_IPV4"
    INTERFACE_BY_NAME = "INTERFACE_BY_NAME"
    SYSTEM = "SYSTEM"
    ONBOARDING = "ONBOARDING"
    SYSTEM_DATETIME = "SYSTEM_DATETIME"
    SYSTEM_CPU = "SYSTEM_CPU"
    SYSTEM_MEMORY = "SYSTEM_MEMORY"
    SYSTEM_STORAGE = "SYSTEM_STORAGE"
    SYSTEM_IMAGE = "SYSTEM_IMAGE"
    SYSTEM_IMAGE_DELETE = "SYSTEM_IMAGE_DELETE"
    SYSTEM_IMAGE_RENAME = "SYSTEM_IMAGE_RENAME"
    SYSTEM_UPDATE_CHECK = "SYSTEM_UPDATE_CHECK"
    DIAGNOSE_PING = "DIAGNOSE_PING"
    DIAGNOSE_TRACEROUTE = "DIAGNOSE_TRACEROUTE"
    DNS = "DNS"
    DNS_HOSTNAME_MAPPING = "DNS_HOSTNAME_MAPPING"
    DNS_SERVER = "DNS_SERVER"
    DNS_FORWARD = "DNS_FORWARD"
    DNS_DYNAMIC = "DNS_DYNAMIC"
    DNS_DYNAMIC_STATUS = "DNS_DYNAMIC_STATUS"
    DNS_FORWARDING_STATISTICS = "DNS_FORWARDING_STATISTICS"
    DNS_NAMESERVERS = "DNS_NAMESERVERS"
    DNS_DYNAMIC_RESET = "DNS_DYNAMIC_RESET"
    DNS_FORWARDING_RESET = "DNS_FORWARDING_RESET"
    DNS_DYNAMIC_RESTART = "DNS_DYNAMIC_RESTART"
    DNS_FORWARDING_RESTART = "DNS_FORWARDING_RESTART"
    FIREWALL = "FIREWALL"
    FIREWALL_IPV4 = "FIREWALL_IPV4"
    FIREWALL_IPV6 = "FIREWALL_IPV6"
    FIREWALL_ZONE = "FIREWALL_ZONE"
    FIREWALL_OPR = "FIREWALL_OPR"
    FIREWALL_OPR_GQL = "FIREWALL_OPR_GQL"
    FIREWALL_QUERY_GQL = "FIREWALL_QUERY_GQL"
    FIREWALL_OPR_LOG = "FIREWALL_OPR_LOG"
    NAT = "NAT"
    NAT66 = "NAT66"
    NAT66_RULES = "NAT66_RULES"
    NAT66_STAT = "NAT66_STAT"
    NAT_STAT = "NAT_STAT"
    NAT_DESTINATION = "NAT_DESTINATION"
    NAT_SOURCE = "NAT_SOURCE"
    DHCP = "DHCP"
    DHCPV6 = "DHCPV6"
    DHCP_RELAY = "DHCP_RELAY"
    DHCP_POOL_LIST = "DHCP_POOL_LIST"
    DHCP_POOL_STATISTICS = "DHCP_POOL_STATISTICS"
    DHCPV6_POOL_LIST = "DHCPv6_POOL_LIST"
    DHCPV6_POOL_STATISTICS = "DHCPv6_POOL_STATISTICS"
    NTP = "NTP"
    NTP_SYSTEM = "NTP_SYSTEM"
    NTP_SOURCE = "NTP_SOURCE"
    NTP_RESTART = "NTP_RESTART"
    OSPFD_RESTART = "OSPFD_RESTART"
    OSPF6D_RESTART = "OSPF6D_RESTART"
    RIPD_RESTART = "RIPD_RESTART"
    RIPNGD_RESTART = "RIPNGD_RESTART"
    HTTPS = "HTTPS"
    SSH = "SSH"
    SSH_FINGERPRINTS = "SSH_FINGERPRINTS"
    SSH_DYNAMIC_PROTECTION = "SSH_DYNAMIC_PROTECTION"
    ARP = "ARP"
    NDP_PROXY = "NDP_PROXY"
    ARP_MONITOR_IPV4 = "ARP_MONITOR_IPV4"
    ARP_MONITOR_IPV6 = "ARP_MONITOR_IPV6"
    ARP_RESET_TABLE = "ARP_RESET_TABLE"
    ARP_RESET_ADDRESS = "ARP_RESET_ADDRESS"
    ARP_RESET_INTERFACE = "ARP_RESET_INTERFACE"
    NDP_PROXY_MONITOR = "NDP_PROXY_MONITOR"
    NDP_PROXY_RESET_ADDRESS = "NDP_PROXY_RESET_ADDRESS"
    NDP_PROXY_RESET_INTERFACE = "NDP_PROXY_RESET_INTERFACE"
    IPV6_RA = "IPV6_RA"
    INTERFACE_WIFI = "INTERFACE_WIFI"
    INTERFACE_WIFI_INFO = "INTERFACE_WIFI_INFO"
    INTERFACE_WIFI_STATION = "INTERFACE_WIFI_STATION"
    INTERFACE_WIFI_SCAN = "INTERFACE_WIFI_SCAN"
    INTERFACE_CELLULAR = "INTERFACE_CELLULAR"
    INTERFACE_ETHERNET = "INTERFACE_ETHERNET"
    INTERFACE_BRIDGE = "INTERFACE_BRIDGE"
    BRIDGEABLE_INTERFACES = "BRIDGEABLE_INTERFACES"
    ROUTER_ADVERTISEMENT = "ROUTER_ADVERTISEMENT"
    GENERAL_ROUTING = "GENERAL_ROUTING"
    GENERAL_ROUTING_V6 = "GENERAL_ROUTING_V6"
    GENERAL_ROUTING_MONITOR = "GENERAL_ROUTING_MONITOR"
    OSPF_MONITOR = "OSPF_MONITOR"
    OSPFV3_MONITOR = "OSPFV3_MONITOR"
    FLEX_ROUTING = "FLEX_ROUTING"
    LOGIN = "LOGIN"
    USER = "USER"
    WIREGUARD_KEY_PAIR = "WIREGUARD_KEY_PAIR"
    WIREGUARD_PRE_SHARED_KEY = "WIREGUARD_PRE_SHARED_KEY"
    OPENVPN_SHARED_SECRET = "OPENVPN_SHARED_SECRET"
    SAML = "SAML"
    INTERFACE_WIREGUARD = "INTERFACE_WIREGUARD"
    WIREGUARD_INTERFACE_RESET = "WIREGUARD_INTERFACE_RESET"
    WIREGUARD_PEER_RESET = "WIREGUARD_PEER_RESET"
    INTERFACE_OPENVPN = "INTERFACE_OPENVPN"
    INTERFACE_L2TPV3 = "INTERFACE_L2TPV3"
    OPENVPN_INTERFACE_RESET = "OPENVPN_INTERFACE_RESET"
    OPENVPN_CLIENT_RESET = "OPENVPN_CLIENT_RESET"
    INTERFACE_IPSEC = "INTERFACE_IPSEC"
    INTERFACE_TUNNEL = "INTERFACE_TUNNEL"
    PKI_CA = "PKI_CA"
    PKI_CERTIFICATE = "PKI_CERTIFICATE"
    PKI_CRL = "PKI_CRL"
    PKI_DH = "PKI_DH"
    PKI_KEY_PAIR = "PKI_KEY_PAIR"
    KEYCERT = "KEYCERT"
    KEYCERT_AUTHORITY_MONITOR = "KEYCERT_AUTHORITY_MONITOR"
    KEYCERT_CERTIFICATE_MONITOR = "KEYCERT_CERTIFICATE_MONITOR"
    OSPF = "OSPF"
    OSPFv3 = "OSPFv3"
    RIP = "RIP"
    RIPng = "RIPng"
    PPTP = "PPTP"
    SSTP = "SSTP"
    L2TP = "L2TP"
    VRRP = "VRRP"
    WAN_LOAD_BALANCING = "WAN_LOAD_BALANCING"
    WAN_LOAD_BALANCING_MONITOR = "WAN_LOAD_BALANCING_MONITOR"
    SNMP = "SNMP"
    SNMP_STATS = "SNMP_STATS"
    SYS_LOG = "SYS_LOG"
    SYSLOG_CONFIG = "SYSLOG_CONFIG"
    ALARM = "ALARM"
    EMAIL = "EMAIL"
    EMAIL_TEST = "EMAIL_TEST"
    SERVER_LEASE_DHCP = "SERVER_LEASE_DHCP"
    COUNTER_INTERFACE = "COUNTER_INTERFACE"
    SNMP_RESTART = "SNMP_RESTART"
    IPSEC_RESTART = "IPSEC_RESTART"
    DHCP_CLIENT_LEASE_RENEW = "DHCP_CLIENT_LEASE_RENEW"
    DHCP_CLIENT_LEASE_RELEASE = "DHCP_CLIENT_LEASE_RELEASE"
    DHCP_CLIENT_LEASES_SHOW = "DHCP_CLIENT_LEASES_SHOW"
    DHCP_SERVER_RESTART = "DHCP_SERVER_RESTART"
    DHCPV6_SERVER_RESTART = "DHCPV6_SERVER_RESTART"
    IPSEC_STAT = "IPSEC_STAT"
    IPSEC_CONNECTIONS = "IPSEC_CONNECTIONS"
    IPSEC_SA_DETAIL = "IPSEC_SA_DETAIL"
    IPSEC_RESET_REMOTE_ACCESS_ALL = "IPSEC_RESET_REMOTE_ACCESS_ALL"
    IPSEC_RESET_SITE_TO_SITE_ALL = "IPSEC_RESET_SITE_TO_SITE_ALL"
    IPSEC_RESET_SITE_TO_SITE_PEER = "IPSEC_RESET_SITE_TO_SITE_PEER"
    SEL_SERVICES = "SEL_SERVICES"
    L2TP_SESSIONS = "L2TP_SESSIONS"
    L2TP_STATISTICS = "L2TP_STATISTICS"
    SSTP_SESSIONS = "SSTP_SESSIONS"
    SSTP_STATISTICS = "SSTP_STATISTICS"
    PPTP_SESSIONS = "PPTP_SESSIONS"
    PPTP_STATISTICS = "PPTP_STATISTICS"
    CONFIG_FILE = "CONFIG_FILE"


class API_RESOLVER:
    def __init__(self):
        self._actions = None

    def actions(self):
        from app.core.api.http.srv.system_performance import (
            fetch_ram as fetch_ram_http,
            fetch_cpu as fetch_cpu_http,
            fetch_storage as fetch_storage_http,
        )
        from app.core.api.http.srv.system_info import (
            fetch_system_info as fetch_system_info_http,
            fetch_system_info_gql as fetch_system_info_gql_http,
        )

        # Import DNS services only when needed to avoid circular imports
        from app.core.network.dns.hostname_mapping.service import (
            fetch_hostname_mappings,
            update_hostname_mappings,
            verify_hostname_mappings,
        )
        from app.core.network.dns.service import (
            fetch_dns_config as fetch_dns_config_http,
            fetch_dns_forward as fetch_dns_forward_http,
            fetch_dns_dynamic as fetch_dns_dynamic_http,
            fetch_dns_dynamic_status as fetch_dns_dynamic_status_http,
            fetch_dns_forwarding_statistics as fetch_dns_forwarding_statistics_http,
            fetch_dns_nameservers as fetch_dns_nameservers_http,
            reset_dns_dynamic as reset_dns_dynamic_http,
            reset_dns_forwarding as reset_dns_forwarding_http,
            restart_dns_dynamic as restart_dns_dynamic_http,
            restart_dns_forwarding as restart_dns_forwarding_http,
            fetch_dns_server as fetch_dns_server_http,
            delete_dns_server as delete_dns_server_http,
            create_dns_server as create_dns_server_http,
            update_dns_server as update_dns_server_http,
            update_dns_forward as update_dns_forward_http,
            update_dns_dynamic as update_dns_dynamic_http,
            update_dns as update_dns_http,
        )
        from app.core.security.service.firewall import (
            fetch_firewall_config as fetch_firewall_config_http,
            fetch_firewall_opr as fetch_firewall_opr_http,
            fetch_firewall_opr_graphql as fetch_firewall_opr_graphql_http,
            fetch_firewall_query_graphql as fetch_firewall_query_graphql_http,
            fetch_firewall_opr_log as fetch_firewall_opr_log_http,
            update_firewall as update_firewall_http,
            verify_firewall as verify_firewall_http,
        )

        from app.core.network.nat.service import (
            fetch_nat_config as fetch_nat_config_http,
            update_nat as update_nat_http,
            verify_nat as verify_nat_http,
            fetch_nat_stat as fetch_nat_stat_http,
            fetch_nat_destination_translation as fetch_nat_destination_translation_http,
            fetch_nat_source_translation as fetch_nat_source_translation_http,
        )
        from app.core.network.nat66.service import fetch_nat66, update_nat66, verify_nat66
        from app.core.network.nat66.service import fetch_nat66_rules, fetch_nat66_stat

        from app.core.api.http.srv.system_info import (
            fetch_datetime as fetch_datetime_http,
            update_system as update_system_http,
        )
        from app.core.api.http.srv.onboarding import (
            configure_onboarding as configure_onboarding_http,
        )

        from app.core.network.dhcp.service import (
            fetch_dhcp_config as fetch_dhcp_config_http,
            fetch_dhcpv6_config as fetch_dhcpv6_config_http,
            verify_dhcp as verify_dhcp_http,
            update_dhcp_config as update_dhcp_config_http,
            fetch_dhcp_relay_config as fetch_dhcp_relay_config_http,
            fetch_dhcp_pool_list as fetch_dhcp_pool_list_http,
            fetch_dhcp_statistics as fetch_dhcp_pool_statistics_http,
            fetch_dhcpv6_pool_list as fetch_dhcpv6_pool_list_http,
            fetch_dhcpv6_statistics as fetch_dhcpv6_pool_statistics_http,
            update_dhcp_relay as update_dhcp_relay_http,
            verify_dhcpv6 as verify_dhcpv6_http,
            update_dhcpv6_config as update_dhcpv6_config_http,
            restart_dhcp_server as restart_dhcp_server_http,
            restart_dhcpv6_server as restart_dhcpv6_server_http,
        )

        from app.core.service.config import (
            fetch_os_config as fetch_os_config_http,
        )

        from app.core.api.http.srv.interface import fetch_interface_gql

        from app.core.api.http.srv.user_management import (
            fetch_user_config as fetch_user_config_http,
            update_user as update_user_http,
            verify_user as verify_user_http,
        )

        from app.core.network.ntp.service import (
            fetch_ntp_config as fetch_ntp_config_http,
            verify_ntp as verify_ntp_http,
            update_ntp as update_ntp_http,
            fetch_ntp_system as fetch_ntp_system_http,
            fetch_ntp_source_gql as fetch_ntp_source_http,
            fetch_ntp_system_gql as fetch_ntp_system_gql_http,
            restart_ntp as restart_ntp_http,
        )
        from app.core.network.https.service import (
            fetch_https_config as fetch_https_config_http,
            update_https as update_https_http,
            verify_https as verify_https_http,
        )
        from app.core.network.ssh.service import (
            fetch_ssh_config as fetch_ssh_config_http,
            fetch_ssh_fingerprints as fetch_ssh_fingerprints_http,
            fetch_ssh_dynamic_protection as fetch_ssh_dynamic_protection_http,
            update_ssh as update_ssh_http,
            verify_ssh as verify_ssh_http
        )
        from app.core.network.arp.service import (
            fetch_arp_config as fetch_arp_config_http,
            fetch_arp_monitor_ipv4 as fetch_arp_monitor_ipv4_http,
            fetch_arp_monitor_ipv6 as fetch_arp_monitor_ipv6_http,
            reset_arp_table as reset_arp_table_http,
            reset_arp_address as reset_arp_address_http,
            reset_arp_interface as reset_arp_interface_http,
            fetch_arp_monitor_ipv6 as fetch_ndp_proxy_monitor_http,
            reset_ipv6_neighbor_address as reset_ndp_proxy_address_http,
            reset_ipv6_neighbors_interface as reset_ndp_proxy_interface_http,
            update_arp as update_arp_http,
            verify_arp as verify_arp_http,
        )
        from app.core.network.ndp_proxy.service import (
            fetch_ndp_proxy_config as fetch_ndp_proxy_config_http,
            update_ndp_proxy as update_ndp_proxy_http,
            verify_ndp_proxy as verify_ndp_proxy_http,
        )
        from app.core.operation.service import (
            add_system_image as add_system_image_http,
            delete_system_image as delete_system_image_http,
            rename_system_image as rename_system_image_http,
            save_running_config as save_running_config_http,
            update_selected_services as update_selected_services_http,
        )
        from app.core.operation.ethernet.service import (
            fetch_ethernet_config as fetch_ethernet_config_http,
        )
        from app.core.operation.router_advert.service import (
            fetch_router_advertisement_config as fetch_router_advertisement_config_http,
        )
        from app.core.api.http.srv.interface import (
            update_interface_by_name as update_interface_by_name_http,
        )
        from app.core.operation.bridge.service import (
            fetch_bridge_config as fetch_bridge_config_http,
            create_bridge_interface as create_bridge_interface_http,
            fetch_bridgeable_interfaces as fetch_bridgeable_interfaces_http,
        )

        from app.core.api.http.srv.interface import (
            create_interface as create_interface_http,
            fetch_interface as fetch_interface_http,
            update_interface as update_interface_http,
            delete_interface as delete_interface_http,
            fetch_interface_config as fetch_interface_config_http,
            delete_interface_address as delete_interface_address_http,
            fetch_wifi_info as fetch_wifi_info_http,
            fetch_wifi_station as fetch_wifi_station_http,
            fetch_wifi_scan as fetch_wifi_scan_http,
            fetch_cellular_info as fetch_cellular_info_http,
            fetch_wireguard_info as fetch_wireguard_info_http,
            reset_wireguard_interface as reset_wireguard_interface_http,
            reset_wireguard_peer as reset_wireguard_peer_http,
            fetch_openvpn_info as fetch_openvpn_info_http,
            reset_openvpn_interface as reset_openvpn_interface_http,
            reset_openvpn_client as reset_openvpn_client_http,
            dhcp_server_lease as dhcp_server_lease_http,
            counter_interface as counter_interface_http,
            renew_dhcp_client_lease as renew_dhcp_client_lease_http,
            release_dhcp_client_lease as release_dhcp_client_lease_http,
            show_dhcp_client_leases as show_dhcp_client_leases_http,
        )

        from app.core.routing.service import (
            update_general_routing as update_general_routing_http,
            fetch_general_routing_monitor as fetch_general_routing_monitor_http,
            verify_general_routing as verify_general_routing_http,
            fetch_general_routing as fetch_general_routing_http,
            fetch_general_routing_v6 as fetch_general_routing_v6_http,
        )

        from app.core.routing.flex.service import (
            fetch_flex_routing as fetch_flex_routing_http,
            update_flex_routing as update_flex_routing_http,
        )

        from app.core.routing.ospf.service import (
            update_ospf as update_ospf_http,
            verify_ospf as verify_ospf_http,
            fetch_ospf as fetch_ospf_http,
            fetch_ospf_monitor as fetch_ospf_monitor_http,
            restart_ospfd as restart_ospfd_http,
        )

        from app.core.operation.software_management.service import (
            fetch_update_check as fetch_update_check_http,
            update_update_check as update_update_check_http,
        )

        from app.core.routing.ospfv3.service import (
            update_ospfv3 as update_ospfv3_http,
            verify_ospfv3 as verify_ospfv3_http,
            fetch_ospfv3 as fetch_ospfv3_http,
            fetch_ospfv3_monitor as fetch_ospfv3_monitor_http,
            restart_ospf6d as restart_ospf6d_http,
        )

        from app.core.high_availability.vrrp.service import (
            fetch_vrrp as fetch_vrrp_http,
            verify_vrrp as verify_vrrp_http,
            update_vrrp as update_vrrp_http,
            monitor_vrrp as monitor_vrrp_http,
        )
        from app.core.high_availability.wan_load_balancing.service import (
            fetch_wan_load_balancing as fetch_wan_load_balancing_http,
            verify_wan_load_balancing as verify_wan_load_balancing_http,
            update_wan_load_balancing as update_wan_load_balancing_http,
            monitor_wan_load_balancing as monitor_wan_load_balancing_http,
        )

        from app.core.routing.rip.service import (
            update_rip as update_rip_http,
            verify_rip as verify_rip_http,
            fetch_rip as fetch_rip_http,
            restart_ripd as restart_ripd_http,
        )

        from app.core.routing.ripng.service import (
            update_ripng as update_ripng_http,
            verify_ripng as verify_ripng_http,
            fetch_ripng as fetch_ripng_http,
            restart_ripngd as restart_ripngd_http,
        )

        from app.core.api.http.srv.system_info import (
            fetch_datetime as fetch_datetime_http,
            update_system as update_system_http,
        )

        from app.core.operation.wireguard.service import (
            create_wireguard_key_pair as create_wireguard_key_pair_http,
            create_wireguard_interface as create_wireguard_interface_http,
            create_wireguard_pre_shared_key as create_wireguard_pre_shared_key_http,
            verify_wireguard as verify_wireguard_http,
            update_wireguard as update_wireguard_http,
            fetch_wireguard as fetch_wireguard_http,
        )

        from app.core.operation.openvpn.service import (
            create_openvpn_interface as create_openvpn_interface_http,
            create_openvpn_shared_secret as create_openvpn_shared_secret_http,
            verify_openvpn as verify_openvpn_http,
            update_openvpn as update_openvpn_http,
            fetch_openvpn as fetch_openvpn_http,
        )

        from app.core.operation.l2tpv3.service import (
            create_l2tpv3_interface as create_l2tpv3_interface_http,
            verify_l2tpv3 as verify_l2tpv3_http,
            update_l2tpv3 as update_l2tpv3_http,
            fetch_l2tpv3 as fetch_l2tpv3_http,
        )

        from app.core.login.service import (
            fetch_login_config as fetch_login_config_http,
            update_login_config as update_login_config_http,
        )

        from app.core.login.saml.service import (
            auth_saml as auth_saml_http,
            fetch_saml_config as fetch_saml_config_http,
            fetch_saml_info as fetch_saml_info_http,
        )

        from app.core.system.keycert.service import (
            generate_pki_ca as generate_pki_ca_http,
            generate_pki_certificate as generate_pki_certificate_http,
            generate_pki_crl as generate_pki_crl_http,
            generate_pki_dh as generate_pki_dh_http,
            generate_pki_key_pair as generate_pki_key_pair_http,
            update_keycert as update_keycert_http,
            verify_keycert as verify_keycert_http,
            fetch_keycert as fetch_keycert_http,
            fetch_keycert_authorities_monitor as fetch_keycert_authorities_monitor_http,
            fetch_keycert_certificates_monitor as fetch_keycert_certificates_monitor_http,
        )

        from app.core.operation.ipsec.service import (
            verify_ipsec as verify_ipsec_http,
            create_ipsec as create_ipsec_http,
            fetch_ipsec as fetch_ipsec_http,
            fetch_ipsec_stats as fetch_ipsec_stats_http,
            fetch_ipsec_connections as fetch_ipsec_connections_http,
            fetch_ipsec_sa_detail as fetch_ipsec_sa_detail_http,
            restart_ipsec as restart_ipsec_http,
            reset_ipsec_remote_access_all as reset_ipsec_remote_access_all_http,
            reset_ipsec_site_to_site_all as reset_ipsec_site_to_site_all_http,
            reset_ipsec_site_to_site_peer as reset_ipsec_site_to_site_peer_http,
        )

        from app.core.vpn.pptp.service import (
            update_pptp as update_pptp_http,
            verify_pptp as verify_pptp_http,
            fetch_pptp as fetch_pptp_http,
            fetch_pptp_sessions as fetch_pptp_sessions_http,
            fetch_pptp_statistics as fetch_pptp_statistics_http,
        )

        from app.core.vpn.sstp.service import (
            update_sstp as update_sstp_http,
            verify_sstp as verify_sstp_http,
            fetch_sstp as fetch_sstp_http,
            fetch_sstp_sessions as fetch_sstp_sessions_http,
            fetch_sstp_statistics as fetch_sstp_statistics_http,
        )

        from app.core.vpn.l2tp.service import (
            update_l2tp as update_l2tp_http,
            verify_l2tp as verify_l2tp_http,
            fetch_l2tp as fetch_l2tp_http,
            fetch_l2tp_sessions as fetch_l2tp_sessions_http,
            fetch_l2tp_statistics as fetch_l2tp_statistics_http,
        )

        from app.core.network.ipv6_ra.service import (
            fetch_ipv6_ra as fetch_ipv6_ra_http,
            update_ipv6_ra as update_ipv6_ra_http,
            verify_ipv6_ra as verify_ipv6_ra_http,
        )

        from app.core.operation.ipsec.service import (
            update_ipsec as update_ipsec_http,
        )

        from app.core.network.snmp.service import (
            update_snmp as update_snmp_http,
            fetch_snmp as fetch_snmp_http,
            monitor_snmp as monitor_snmp_http,
            fetch_snmp_stats as fetch_snmp_stats_http,
            restart_snmp as restart_snmp_http,
        )

        from app.core.operation.system_log import (
            fetch_system_opr_log as fetch_system_opr_log_http,
        )

        from app.core.system.syslog.service import (
            fetch_syslog as fetch_syslog_http,
            update_syslog as update_syslog_http,
            verify_syslog as verify_syslog_http,
        )
        from app.core.system.event_handler.service import (
            fetch_alarm as fetch_alarm_http,
            update_alarm as update_alarm_http,
            verify_alarm as verify_alarm_http,
        )
        from app.core.system.email.service import (
            fetch_email as fetch_email_http,
            send_test_email as send_test_email_http,
            update_email as update_email_http,
            verify_email as verify_email_http,
        )

        from app.core.operation.iptunnels.service import (
            create_iptunnels as create_iptunnels_http,
            update_iptunnel_by_name as update_iptunnel_by_name_http,
        )

        from app.core.operation.diagnose.service import (
            run_ping_diagnostic as run_ping_diagnostic_http,
            run_traceroute_diagnostic as run_traceroute_diagnostic_http,
        )

        self._actions = {
            API_ACTION.GENERATE: {
                API_TARGET.PKI_CA: generate_pki_ca_http,
                API_TARGET.PKI_CERTIFICATE: generate_pki_certificate_http,
                API_TARGET.PKI_CRL: generate_pki_crl_http,
                API_TARGET.PKI_DH: generate_pki_dh_http,
                API_TARGET.PKI_KEY_PAIR: generate_pki_key_pair_http,
                API_TARGET.EMAIL_TEST: send_test_email_http,
            },
            API_ACTION.CREATE: {
                API_TARGET.INTERFACE: create_interface_http,
                API_TARGET.DNS_SERVER: create_dns_server_http,
                API_TARGET.WIREGUARD_KEY_PAIR: create_wireguard_key_pair_http,
                API_TARGET.WIREGUARD_PRE_SHARED_KEY: create_wireguard_pre_shared_key_http,
                API_TARGET.OPENVPN_SHARED_SECRET: create_openvpn_shared_secret_http,
                API_TARGET.INTERFACE_OPENVPN: create_openvpn_interface_http,
                API_TARGET.INTERFACE_L2TPV3: create_l2tpv3_interface_http,
                API_TARGET.INTERFACE_WIREGUARD: create_wireguard_interface_http,
                API_TARGET.INTERFACE_IPSEC: create_ipsec_http,
                API_TARGET.INTERFACE_BRIDGE: create_bridge_interface_http,
                API_TARGET.INTERFACE_TUNNEL: create_iptunnels_http,
            },
            API_ACTION.READ: {
                API_TARGET.OS_CONFIG: fetch_os_config_http,
                API_TARGET.INTERFACE: fetch_interface_gql,
                API_TARGET.INTERFACE_CONFIG: fetch_interface_config_http,
                API_TARGET.INTERFACE_WIREGUARD: fetch_wireguard_info_http,
                API_TARGET.SYSTEM: fetch_system_info_gql_http,
                API_TARGET.SYSTEM_CPU: fetch_cpu_http,
                API_TARGET.SYSTEM_MEMORY: fetch_ram_http,
                API_TARGET.SYSTEM_STORAGE: fetch_storage_http,
                API_TARGET.SYSTEM_DATETIME: fetch_datetime_http,
                API_TARGET.DNS: fetch_dns_config_http,
                API_TARGET.DNS_HOSTNAME_MAPPING: fetch_hostname_mappings,
                API_TARGET.DNS_SERVER: fetch_dns_server_http,
                API_TARGET.DNS_FORWARD: fetch_dns_forward_http,
                API_TARGET.DNS_DYNAMIC: fetch_dns_dynamic_http,
                API_TARGET.DNS_NAMESERVERS: fetch_dns_nameservers_http,
                API_TARGET.FIREWALL: fetch_firewall_config_http,
                API_TARGET.FIREWALL_OPR: fetch_firewall_opr_http,
                API_TARGET.FIREWALL_OPR_GQL: fetch_firewall_opr_graphql_http,
                API_TARGET.FIREWALL_QUERY_GQL: fetch_firewall_query_graphql_http,
                API_TARGET.FIREWALL_OPR_LOG: fetch_firewall_opr_log_http,
                API_TARGET.NAT: fetch_nat_config_http,
                API_TARGET.NAT66: fetch_nat66,
                API_TARGET.NAT66_RULES: fetch_nat66_rules,
                API_TARGET.NAT66_STAT: fetch_nat66_stat,
                API_TARGET.NAT_STAT: fetch_nat_stat_http,
                API_TARGET.NAT_DESTINATION: fetch_nat_destination_translation_http,
                API_TARGET.NAT_SOURCE: fetch_nat_source_translation_http,
                API_TARGET.DHCP: fetch_dhcp_config_http,
                API_TARGET.DHCPV6: fetch_dhcpv6_config_http,
                API_TARGET.DHCP_RELAY: fetch_dhcp_relay_config_http,
                API_TARGET.DHCP_POOL_LIST: fetch_dhcp_pool_list_http,
                API_TARGET.DHCP_POOL_STATISTICS: fetch_dhcp_pool_statistics_http,
                API_TARGET.DHCPV6_POOL_LIST: fetch_dhcpv6_pool_list_http,
                API_TARGET.DHCPV6_POOL_STATISTICS: fetch_dhcpv6_pool_statistics_http,
                API_TARGET.NTP: fetch_ntp_config_http,
                API_TARGET.NTP_SYSTEM: fetch_ntp_system_gql_http,
                API_TARGET.NTP_SOURCE: fetch_ntp_source_http,
                API_TARGET.HTTPS: fetch_https_config_http,
                API_TARGET.SSH: fetch_ssh_config_http,
                API_TARGET.ARP: fetch_arp_config_http,
                API_TARGET.NDP_PROXY: fetch_ndp_proxy_config_http,
                API_TARGET.IPV6_RA: fetch_ipv6_ra_http,
                API_TARGET.INTERFACE_ETHERNET: fetch_ethernet_config_http,
                API_TARGET.INTERFACE_BRIDGE: fetch_bridge_config_http,
                API_TARGET.BRIDGEABLE_INTERFACES: fetch_bridgeable_interfaces_http,
                API_TARGET.ROUTER_ADVERTISEMENT: fetch_router_advertisement_config_http,
                API_TARGET.INTERFACE_WIFI_INFO: fetch_wifi_info_http,
                API_TARGET.INTERFACE_WIFI_STATION: fetch_wifi_station_http,
                API_TARGET.INTERFACE_WIFI_SCAN: fetch_wifi_scan_http,
                API_TARGET.GENERAL_ROUTING_MONITOR: fetch_general_routing_monitor_http,
                API_TARGET.GENERAL_ROUTING: fetch_general_routing_http,
                API_TARGET.GENERAL_ROUTING_V6: fetch_general_routing_v6_http,
                API_TARGET.OSPF_MONITOR: fetch_ospf_monitor_http,
                API_TARGET.OSPFV3_MONITOR: fetch_ospfv3_monitor_http,
                API_TARGET.FLEX_ROUTING: fetch_flex_routing_http,
                API_TARGET.LOGIN: fetch_login_config_http,
                API_TARGET.USER: fetch_user_config_http,
                API_TARGET.SAML: fetch_saml_config_http,
                API_TARGET.KEYCERT: fetch_keycert_http,
                API_TARGET.INTERFACE_IPSEC: fetch_ipsec_http,
                API_TARGET.OSPF: fetch_ospf_http,
                API_TARGET.SYSTEM_UPDATE_CHECK: fetch_update_check_http,
                API_TARGET.OSPFv3: fetch_ospfv3_http,
                API_TARGET.VRRP: fetch_vrrp_http,
                API_TARGET.WAN_LOAD_BALANCING: fetch_wan_load_balancing_http,
                API_TARGET.RIP: fetch_rip_http,
                API_TARGET.RIPng: fetch_ripng_http,
                API_TARGET.PPTP: fetch_pptp_http,
                API_TARGET.SSTP: fetch_sstp_http,
                API_TARGET.L2TP: fetch_l2tp_http,
                API_TARGET.SNMP: fetch_snmp_http,
                API_TARGET.SNMP_STATS: fetch_snmp_stats_http,
                API_TARGET.SYS_LOG: fetch_system_opr_log_http,
                API_TARGET.SYSLOG_CONFIG: fetch_syslog_http,
                API_TARGET.IPSEC_STAT: fetch_ipsec_stats_http,
                API_TARGET.ALARM: fetch_alarm_http,
                API_TARGET.EMAIL: fetch_email_http,
                API_TARGET.KEYCERT_AUTHORITY_MONITOR: fetch_keycert_authorities_monitor_http,
                API_TARGET.KEYCERT_CERTIFICATE_MONITOR: fetch_keycert_certificates_monitor_http,
                API_TARGET.INTERFACE_OPENVPN: fetch_openvpn_http,
                API_TARGET.INTERFACE_L2TPV3: fetch_l2tpv3_http,
                API_TARGET.INTERFACE_WIREGUARD: fetch_wireguard_http,
            },
            API_ACTION.UPDATE: {
                API_TARGET.ONBOARDING: configure_onboarding_http,
                API_TARGET.INTERFACE: update_interface_http,
                API_TARGET.INTERFACE_BY_NAME: update_interface_by_name_http,
                API_TARGET.DNS_FORWARD: update_dns_forward_http,
                API_TARGET.DNS_DYNAMIC: update_dns_dynamic_http,
                API_TARGET.DNS_SERVER: update_dns_server_http,
                API_TARGET.DNS: update_dns_http,
                API_TARGET.DNS_HOSTNAME_MAPPING: update_hostname_mappings,
                API_TARGET.FIREWALL: update_firewall_http,
                API_TARGET.NAT: update_nat_http,
                API_TARGET.NAT66: update_nat66,
                API_TARGET.SYSTEM: update_system_http,
                API_TARGET.SYSTEM_IMAGE: add_system_image_http,
                API_TARGET.SYSTEM_IMAGE_RENAME: rename_system_image_http,
                API_TARGET.DHCP: update_dhcp_config_http,
                API_TARGET.DHCP_RELAY: update_dhcp_relay_http,
                API_TARGET.DHCPV6: update_dhcpv6_config_http,
                API_TARGET.NTP: update_ntp_http,
                API_TARGET.HTTPS: update_https_http,
                API_TARGET.SSH: update_ssh_http,
                API_TARGET.ARP: update_arp_http,
                API_TARGET.NDP_PROXY: update_ndp_proxy_http,
                API_TARGET.IPV6_RA: update_ipv6_ra_http,
                API_TARGET.GENERAL_ROUTING: update_general_routing_http,
                API_TARGET.FLEX_ROUTING: update_flex_routing_http,
                API_TARGET.LOGIN: update_login_config_http,
                API_TARGET.USER: update_user_http,
                API_TARGET.KEYCERT: update_keycert_http,
                API_TARGET.OSPF: update_ospf_http,
                API_TARGET.SYSTEM_UPDATE_CHECK: update_update_check_http,
                API_TARGET.OSPFv3: update_ospfv3_http,
                API_TARGET.VRRP: update_vrrp_http,
                API_TARGET.WAN_LOAD_BALANCING: update_wan_load_balancing_http,
                API_TARGET.RIP: update_rip_http,
                API_TARGET.RIPng: update_ripng_http,
                API_TARGET.PPTP: update_pptp_http,
                API_TARGET.SSTP: update_sstp_http,
                API_TARGET.L2TP: update_l2tp_http,
                API_TARGET.INTERFACE_IPSEC: update_ipsec_http,
                API_TARGET.SNMP: update_snmp_http,
                API_TARGET.SYSLOG_CONFIG: update_syslog_http,
                API_TARGET.SEL_SERVICES: update_selected_services_http,
                API_TARGET.ALARM: update_alarm_http,
                API_TARGET.EMAIL: update_email_http,
                API_TARGET.INTERFACE_OPENVPN: update_openvpn_http,
                API_TARGET.INTERFACE_L2TPV3: update_l2tpv3_http,
                API_TARGET.INTERFACE_WIREGUARD: update_wireguard_http,
            },
            API_ACTION.DELETE: {
                API_TARGET.INTERFACE: delete_interface_http,
                API_TARGET.INTERFACE_ADDRESS: delete_interface_address_http,
                API_TARGET.DNS_SERVER: delete_dns_server_http,
                API_TARGET.SYSTEM_IMAGE: delete_system_image_http,
            },
            API_ACTION.VERIFY: {
                API_TARGET.DNS_HOSTNAME_MAPPING: verify_hostname_mappings,
                API_TARGET.ARP: verify_arp_http,
                API_TARGET.FIREWALL: verify_firewall_http,
                API_TARGET.NAT: verify_nat_http,
                API_TARGET.NAT66: verify_nat66,
                API_TARGET.DHCP: verify_dhcp_http,
                API_TARGET.DHCPV6: verify_dhcpv6_http,
                API_TARGET.NTP: verify_ntp_http,
                API_TARGET.HTTPS: verify_https_http,
                API_TARGET.SSH: verify_ssh_http,
                API_TARGET.NDP_PROXY: verify_ndp_proxy_http,
                API_TARGET.IPV6_RA: verify_ipv6_ra_http,
                API_TARGET.GENERAL_ROUTING: verify_general_routing_http,
                API_TARGET.USER: verify_user_http,
                API_TARGET.KEYCERT: verify_keycert_http,
                API_TARGET.INTERFACE_IPSEC: verify_ipsec_http,
                API_TARGET.OSPF: verify_ospf_http,
                API_TARGET.OSPFv3: verify_ospfv3_http,
                API_TARGET.VRRP: verify_vrrp_http,
                API_TARGET.WAN_LOAD_BALANCING: verify_wan_load_balancing_http,
                API_TARGET.RIP: verify_rip_http,
                API_TARGET.RIPng: verify_ripng_http,
                API_TARGET.PPTP: verify_pptp_http,
                API_TARGET.SSTP: verify_sstp_http,
                API_TARGET.L2TP: verify_l2tp_http,
                API_TARGET.SYSLOG_CONFIG: verify_syslog_http,
                API_TARGET.ALARM: verify_alarm_http,
                API_TARGET.EMAIL: verify_email_http,
                API_TARGET.INTERFACE_OPENVPN: verify_openvpn_http,
                API_TARGET.INTERFACE_L2TPV3: verify_l2tpv3_http,
                API_TARGET.INTERFACE_WIREGUARD: verify_wireguard_http,
            },
            API_ACTION.MONITOR: {
                API_TARGET.DIAGNOSE_PING: run_ping_diagnostic_http,
                API_TARGET.DIAGNOSE_TRACEROUTE: run_traceroute_diagnostic_http,
                API_TARGET.SSH_FINGERPRINTS: fetch_ssh_fingerprints_http,
                API_TARGET.SSH_DYNAMIC_PROTECTION: fetch_ssh_dynamic_protection_http,
                API_TARGET.INTERFACE_CELLULAR: fetch_cellular_info_http,
                API_TARGET.INTERFACE_WIREGUARD: fetch_wireguard_info_http,
                API_TARGET.WIREGUARD_INTERFACE_RESET: reset_wireguard_interface_http,
                API_TARGET.WIREGUARD_PEER_RESET: reset_wireguard_peer_http,
                API_TARGET.INTERFACE_OPENVPN: fetch_openvpn_info_http,
                API_TARGET.OPENVPN_INTERFACE_RESET: reset_openvpn_interface_http,
                API_TARGET.OPENVPN_CLIENT_RESET: reset_openvpn_client_http,
                API_TARGET.SAML: fetch_saml_info_http,
                API_TARGET.SNMP: monitor_snmp_http,
                API_TARGET.SNMP_RESTART: restart_snmp_http,
                API_TARGET.VRRP: monitor_vrrp_http,
                API_TARGET.WAN_LOAD_BALANCING_MONITOR: monitor_wan_load_balancing_http,
                API_TARGET.ARP_MONITOR_IPV4: fetch_arp_monitor_ipv4_http,
                API_TARGET.ARP_MONITOR_IPV6: fetch_arp_monitor_ipv6_http,
                API_TARGET.ARP_RESET_TABLE: reset_arp_table_http,
                API_TARGET.ARP_RESET_ADDRESS: reset_arp_address_http,
                API_TARGET.ARP_RESET_INTERFACE: reset_arp_interface_http,
                API_TARGET.NDP_PROXY_MONITOR: fetch_ndp_proxy_monitor_http,
                API_TARGET.NDP_PROXY_RESET_ADDRESS: reset_ndp_proxy_address_http,
                API_TARGET.NDP_PROXY_RESET_INTERFACE: reset_ndp_proxy_interface_http,
                API_TARGET.OSPF_MONITOR: fetch_ospf_monitor_http,
                API_TARGET.OSPFV3_MONITOR: fetch_ospfv3_monitor_http,
                API_TARGET.OSPFD_RESTART: restart_ospfd_http,
                API_TARGET.OSPF6D_RESTART: restart_ospf6d_http,
                API_TARGET.RIPD_RESTART: restart_ripd_http,
                API_TARGET.RIPNGD_RESTART: restart_ripngd_http,
                API_TARGET.SERVER_LEASE_DHCP: dhcp_server_lease_http,
                API_TARGET.COUNTER_INTERFACE: counter_interface_http,
                API_TARGET.DHCP_CLIENT_LEASE_RENEW: renew_dhcp_client_lease_http,
                API_TARGET.DHCP_CLIENT_LEASE_RELEASE: release_dhcp_client_lease_http,
                API_TARGET.DHCP_CLIENT_LEASES_SHOW: show_dhcp_client_leases_http,
                API_TARGET.DHCP_SERVER_RESTART: restart_dhcp_server_http,
                API_TARGET.DHCPV6_SERVER_RESTART: restart_dhcpv6_server_http,
                API_TARGET.NTP_RESTART: restart_ntp_http,
                API_TARGET.DNS_DYNAMIC_STATUS: fetch_dns_dynamic_status_http,
                API_TARGET.DNS_FORWARDING_STATISTICS: fetch_dns_forwarding_statistics_http,
                API_TARGET.DNS_NAMESERVERS: fetch_dns_nameservers_http,
                API_TARGET.DNS_DYNAMIC_RESET: reset_dns_dynamic_http,
                API_TARGET.DNS_FORWARDING_RESET: reset_dns_forwarding_http,
                API_TARGET.DNS_DYNAMIC_RESTART: restart_dns_dynamic_http,
                API_TARGET.DNS_FORWARDING_RESTART: restart_dns_forwarding_http,
                API_TARGET.IPSEC_RESTART: restart_ipsec_http,
                API_TARGET.IPSEC_CONNECTIONS: fetch_ipsec_connections_http,
                API_TARGET.IPSEC_SA_DETAIL: fetch_ipsec_sa_detail_http,
                API_TARGET.L2TP_SESSIONS: fetch_l2tp_sessions_http,
                API_TARGET.L2TP_STATISTICS: fetch_l2tp_statistics_http,
                API_TARGET.PPTP_SESSIONS: fetch_pptp_sessions_http,
                API_TARGET.PPTP_STATISTICS: fetch_pptp_statistics_http,
                API_TARGET.SSTP_SESSIONS: fetch_sstp_sessions_http,
                API_TARGET.SSTP_STATISTICS: fetch_sstp_statistics_http,
                API_TARGET.IPSEC_RESET_REMOTE_ACCESS_ALL: reset_ipsec_remote_access_all_http,
                API_TARGET.IPSEC_RESET_SITE_TO_SITE_ALL: reset_ipsec_site_to_site_all_http,
                API_TARGET.IPSEC_RESET_SITE_TO_SITE_PEER: reset_ipsec_site_to_site_peer_http,
            },
            API_ACTION.AUTH: {API_TARGET.SAML: auth_saml_http},
            API_ACTION.SAVE: {API_TARGET.CONFIG_FILE: save_running_config_http},
        }
        return self._actions
