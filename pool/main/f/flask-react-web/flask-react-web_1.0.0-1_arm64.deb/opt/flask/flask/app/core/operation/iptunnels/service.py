from app.core.operation.iptunnels.command_iptunnels import IPTunnelCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger


def update_iptunnel(provider, data):
    logger.info("Update IP tunnel:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    tunnel_set_cmd = IPTunnelCommand(operator='set', resource='tunnel')
    set_cmds = tunnel_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = tunnel_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    tunnel_delete_cmd = IPTunnelCommand(operator='delete', resource='tunnel')
    delete_cmds = tunnel_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = tunnel_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "tunnel"
    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}).get('tunnel', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}).get('tunnel', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    # Note: Tunnel validation might not be available, skip for now
    verify = None
    # if merged_config:
    #     verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update IP Tunnel",
                "content": "IP Tunnel is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_iptunnel(provider, data):
    # Tunnel verification might not be implemented yet
    pass


def create_iptunnels(provider, data):
    logger.info("Create IP tunnel:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    # For CREATE, config is already structured as {tunnel_type: {tunnel_name: {...}}}
    # Extract tunnel type and name
    tunnel_types = ['gre', 'ipip', 'sit', 'vti']
    tunnel_type = None
    tunnel_name = None
    
    for tt in tunnel_types:
        if tt in config:
            tunnel_type = tt
            tunnel_name = list(config[tt].keys())[0] if config[tt] else None
            break
    
    if not tunnel_type or not tunnel_name:
        return [{"success": False, "error": "No tunnel data found in config"}]
    
    print(f"Creating tunnel: {tunnel_name}, type: {tunnel_type}")
    
    # For CREATE, diff is also already in the correct structure
    # Just pass it directly to command generator
    structured_created = diff.get('created', {})
    structured_deleted = diff.get('deleted', {})
    
    print("Data for command generator:")
    print(pprint.pformat(structured_created, indent=2, width=80))

    set_cmds = []
    tunnel_set_cmd = IPTunnelCommand(operator='set', resource='tunnel', mode='CREATE')
    set_cmds = tunnel_set_cmd.generate_commands(data=structured_created, current_config=current_config, new_config=config)
    sc = tunnel_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    tunnel_delete_cmd = IPTunnelCommand(operator='delete', resource='tunnel', mode='CREATE')
    delete_cmds = tunnel_delete_cmd.generate_commands(data=structured_deleted, current_config=current_config, new_config=config)
    dc = tunnel_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "tunnel"
    merged_config = merge_dicts_set({}, new_set_configs.get('interfaces', {}).get('tunnel', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    # Note: Tunnel validation might not be available, skip for now
    verify = None
    # if merged_config:
    #     verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Create IP Tunnel",
                "content": "IP Tunnel is successfully created"
            }
    )
    
    r = []
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_iptunnel_by_name(provider, data):
    """Update a specific IP tunnel interface by name"""
    logger.info("Update IP tunnel by name:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    tunnel_name = data.get('name')
    
    # Extract tunnel type from nested structure
    tunnel_config = config.get('interfaces', {}).get('tunnel', {}).get(tunnel_name, {})
    tunnel_type = tunnel_config.get('encapsulation')  # e.g., 'gre', 'ipip', 'sit', etc.
    
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))
    print("Extracted tunnel type: ")
    print(tunnel_type)

    # Restructure diff data for command generator
    # Generator expects: {tunnel_type: {tunnel_name: {field: value}}}
    structured_created = {}
    if diff.get('created'):
        structured_created = {tunnel_type: {tunnel_name: diff['created']}}
    
    structured_deleted = {}
    if diff.get('deleted'):
        structured_deleted = {tunnel_type: {tunnel_name: diff['deleted']}}
    
    print("Structured created data: ")
    print(pprint.pformat(structured_created, indent=2, width=80))
    print("Structured deleted data: ")
    print(pprint.pformat(structured_deleted, indent=2, width=80))

    set_cmds = []
    tunnel_set_cmd = IPTunnelCommand(operator='set', resource='tunnel')
    set_cmds = tunnel_set_cmd.generate_commands(data=structured_created, current_config=current_config, new_config=config)
    sc = tunnel_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    tunnel_delete_cmd = IPTunnelCommand(operator='delete', resource='tunnel')
    delete_cmds = tunnel_delete_cmd.generate_commands(data=structured_deleted, current_config=current_config, new_config=config)
    dc = tunnel_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "tunnel"
    tunnel_current = current_config.get('interfaces', {}).get('tunnel', {}).get(tunnel_name, {})
    tunnel_new_delete = new_delete_configs.get('interfaces', {}).get('tunnel', {}).get(tunnel_name, {})
    tunnel_new_set = new_set_configs.get('interfaces', {}).get('tunnel', {}).get(tunnel_name, {})
    
    # Handle case where tunnel_new_set might be a string (for flag-type sets like 'disable-link-detect')
    # This happens when process_commands() parses set commands for flag fields
    if isinstance(tunnel_new_set, str):
        print(f"Converting tunnel_new_set from string '{tunnel_new_set}' to dict")
        tunnel_new_set = {tunnel_new_set: {}}
    
    # Handle case where tunnel_new_delete might be a string (for flag-type deletes like 'enable-multicast')
    # This happens when process_commands() parses delete commands for flag fields
    if isinstance(tunnel_new_delete, str):
        print(f"Converting tunnel_new_delete from string '{tunnel_new_delete}' to dict")
        tunnel_new_delete = {tunnel_new_delete: {}}
    
    merged_del_config = merge_dicts_delete(tunnel_current, tunnel_new_delete)
    merged_config = merge_dicts_set(merged_del_config, tunnel_new_set)
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    # Note: Tunnel validation might not be available, skip for now
    verify = None
    # if merged_config:
    #     verify = provider.verify_service.call_verify(service, {tunnel_name: merged_config})
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": f"Success: Update IP Tunnel {tunnel_name}",
                "content": f"IP Tunnel {tunnel_name} is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def fetch_iptunnel(data):
    # This function would fetch tunnel data from VyOS
    # For now, return empty as it's handled by the GraphQL queries
    pass