from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_WIREGUARD_GENERATE_KEY_PAIR, SHOW_WIREGUARD_GENERATE_PRE_SHARED_KEY
from app.core.operation.wireguard.parser import parse_wireguard_key_pair, parse_wireguard_pre_shared_key, parse_wireguard_monitor_info, parse_current_all_wireguard_interfaces_config
from app.core.operation.wireguard.command_wireguard import WireguardCommand
from flask import session
from uuid import uuid4
import pprint
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from app.core.models import InterfaceConfig
from app.core.operation.wireguard.models import WireguardInterfaceConfig
from app.db.database import db

def validate_unique_wireguard_port(config, current_name=None):
    if not isinstance(config, dict):
        return None

    listen_port = config.get('port')
    if listen_port in (None, ""):
        return None

    existing_interfaces = WireguardInterfaceConfig.query.all()
    for interface in existing_interfaces:
        if current_name and interface.iface_name == current_name:
            continue

        if interface.listen_port == listen_port:
            return f"Listen Port {listen_port} is already used by WireGuard interface {interface.iface_name}."

    return None


def normalize_wireguard_refresh_config(name, config):
    if not isinstance(config, dict):
        return {}

    if isinstance(config.get('interfaces'), dict):
        interfaces_config = config['interfaces']
        if isinstance(interfaces_config.get('wireguard'), dict):
            return interfaces_config.get('wireguard', {})

    if isinstance(config.get('wireguard'), dict):
        return config.get('wireguard', {})

    if name in config and isinstance(config.get(name), dict):
        return config

    return {name: config}


def create_wireguard_pre_shared_key(provider, data):
    res = provider.http_service.send_request(action=Action.GENERATE, data=SHOW_WIREGUARD_GENERATE_PRE_SHARED_KEY, verify=False)
    return parse_wireguard_pre_shared_key(res.json()['data'])

def create_wireguard_key_pair(provider, data):
    res = provider.http_service.send_request(action=Action.GENERATE, data=SHOW_WIREGUARD_GENERATE_KEY_PAIR, verify=False)
    return parse_wireguard_key_pair(res.json()['data'])


def create_wireguard_interface(provider, data):
    
    print("Create wireguard:")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    name = data.get('name')
    config = data.get('config')
    set_cmds = []
    iface_set_cmd = WireguardCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands(data={name: config})
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    # Validate configs
    service = "wireguard"
    merged_config = merge_dicts_set({}, new_set_configs.get('interfaces', {}))    
    
    verify = None
    if merged_config and merged_config.get('wireguard', {}).get(name, None):
        pki = provider.verify_service.call_get_config("pki")
        merged_config['wireguard'][name]['pki'] = pki
        merged_config['wireguard'][name]['ifname'] = name
        port_conflict_error = validate_unique_wireguard_port(merged_config['wireguard'][name], name)
        if port_conflict_error:
            return [{"success": False, "error": port_conflict_error, "cmd": set_cmds}]
        verify = provider.verify_service.query_interface_verify(
            service, 
            name,
            merged_config.get('wireguard', {}).get(name, None)
        )
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    InterfaceConfig.upsert({
        'wireguard': {
            name: config
        }
    })

    WireguardInterfaceConfig.upsert({name: config})

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Create Wireguard",
                "content": "Wireguard is successfully updated"
            }
    )
    
    r = []
    cmds = set_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r



def update_wireguard_by_name(provider, data):
    print("Update wireguard by name")
    print(data)
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    name = data.get('name')
    
    set_cmds = []
    iface_set_cmd = WireguardCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, new_config)
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = WireguardCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Validate configs
    service = "wireguard"
    curr_config = provider.verify_service.query_interface_config(service, name)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        current_config, 
        new_delete_configs.get('interfaces', {}).get('wireguard', {}).get(name, None)
    )
    merged_config = merge_dicts_set(
        merged_del_config, 
        new_set_configs.get('interfaces', {}).get('wireguard', {}).get(name, None)
    )    
    
    verify = None
    if merged_config:
        port_conflict_error = validate_unique_wireguard_port(merged_config, name)
        if port_conflict_error:
            return [{"success": False, "error": port_conflict_error, "cmd": excecuted_cmds}]

        verify = provider.verify_service.query_interface_verify(
            service, 
            name,
            merged_config
        )

    print("Verify config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    print("Verify")
    print(verify)

    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": verify, "cmd": excecuted_cmds}]

    InterfaceConfig.upsert({
        'wireguard': {
            name: merged_config
        }
    })

    WireguardInterfaceConfig.upsert({name: merged_config})
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Wireguard",
                "content": "Wireguard is successfully updated"
            }
    )
    
    r = []
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def fetch_wireguard(provider, data):
    try:
        response = provider.http_service.show_all_configs()
        config = response.json().get('data', {}) if response and hasattr(response, 'json') else {}
    except Exception:
        config = {}
    if not isinstance(config, dict):
        return {}
    parsed = parse_current_all_wireguard_interfaces_config(config)
    return {'interfaces': {'wireguard': parsed}}


def verify_wireguard(provider, data):
    print("Verify wireguard:")
    print(pprint.pformat(data, indent=2, width=80))
    name = data.get('name')
    config = data.get('config')

    iface_cmd = WireguardCommand(operator='set', resource='interfaces', name=name)
    iface_cmd.generate_commands(data={name: config})
    commands = iface_cmd.get_commands()

    processed = process_commands(commands)
    normalized_config = (processed.get('interfaces') or {}).get('wireguard', {}).get(name, {})
    normalized_config['ifname'] = name
    print("Normalized config for verify:")
    print(pprint.pformat(normalized_config, indent=2, width=80))

    verify = provider.verify_service.call_verify_interface("wireguard", name, normalized_config)
    return verify


def update_wireguard(provider, data):
    print("Update wireguard (bulk):")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    new_config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}

    if not isinstance(new_config, dict):
        new_config = {}
    if not isinstance(current_config, dict):
        current_config = {}
    if not isinstance(diff, dict):
        diff = {}

    new_wireguard = (new_config.get('interfaces') or {}).get('wireguard') or {}
    current_wireguard = (current_config.get('interfaces') or {}).get('wireguard') or {}
    diff_created = ((diff.get('created') or {}).get('interfaces') or {}).get('wireguard') or {}
    diff_deleted = ((diff.get('deleted') or {}).get('interfaces') or {}).get('wireguard') or {}

    if not isinstance(new_wireguard, dict):
        new_wireguard = {}
    if not isinstance(current_wireguard, dict):
        current_wireguard = {}
    if not isinstance(diff_created, dict):
        diff_created = {}
    if not isinstance(diff_deleted, dict):
        diff_deleted = {}

    all_set_cmds: list = []
    all_delete_cmds: list = []
    sc: list = []
    dc: list = []
    new_set_configs: dict = {}
    new_delete_configs: dict = {}

    for name, iface_config in new_wireguard.items():
        iface_created = diff_created.get(name, iface_config) or {}
        iface_current = current_wireguard.get(name, {}) or {}
        iface_set_cmd = WireguardCommand(operator='set', resource='interfaces', name=name)
        _set_cmds = iface_set_cmd.generate_commands(
            data={name: iface_created},
            current_config=iface_current,
            new_config=iface_config,
            all_config=new_wireguard
        )
        all_set_cmds.extend(_set_cmds)
        sc.extend(iface_set_cmd.get_commands())

    if sc:
        processed = process_commands(sc)
        new_set_configs = merge_dicts_set(new_set_configs, processed)

    for name, iface_deleted in diff_deleted.items():
        iface_current = current_wireguard.get(name, {}) or {}
        iface_delete_cmd = WireguardCommand(operator='delete', resource='interfaces', name=name)
        _del_cmds = iface_delete_cmd.generate_commands(
            data={name: iface_deleted},
            current_config=iface_current,
            new_config=new_wireguard.get(name, {}),
            all_config=new_wireguard
        )
        all_delete_cmds.extend(_del_cmds)
        dc.extend(iface_delete_cmd.get_commands())

    if dc:
        processed = process_commands(dc)
        new_delete_configs = merge_dicts_delete(new_delete_configs, processed, aggressive=True)

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    service = "wireguard"
    curr_configs = {
        "interfaces": {
            "wireguard": {}
        }
    }
    for wireguard_name in current_wireguard:
        curr_config = provider.verify_service.query_interface_config(service, wireguard_name)
        curr_configs["interfaces"]["wireguard"][wireguard_name] = curr_config

    print("Current interfaces configs: ")
    print(pprint.pformat(curr_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(curr_configs, new_delete_configs, aggressive=True)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    print("Merged config:")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = {}
    wireguard_configs = (merged_config.get('interfaces') or {}).get('wireguard') or {}
    for iface_name, iface_config in wireguard_configs.items():
        if not iface_config or not isinstance(iface_config, dict):
            continue
        port_conflict_error = validate_unique_wireguard_port(iface_config, iface_name)
        if port_conflict_error:
            verify[iface_name] = port_conflict_error
            continue
        
        iface_config['ifname'] = iface_name
        verify_result = provider.verify_service.query_interface_verify(
            service,
            iface_name,
            iface_config
        )
        if verify_result and str(verify_result) != "None" and str(verify_result) != "":
            verify[iface_name] = verify_result

    print("Verify:")
    print(pprint.pformat(verify, indent=2, width=80))

    excecuted_cmds = list(dict.fromkeys(all_delete_cmds)) + list(dict.fromkeys(all_set_cmds))

    if any(str(v) != "None" and str(v) != "" and v != {} for v in verify.values()):
        return [{"success": False, "error": verify, "cmd": excecuted_cmds}]

    new_interfaces_section = (new_config.get('interfaces') or {})
    normalized = normalize_wireguard_refresh_config(None, new_interfaces_section)
    InterfaceConfig.upsert({'wireguard': normalized})
    WireguardInterfaceConfig.refresh(normalized)

    # Delete removed interfaces from InterfaceConfig
    deleted_names = [name for name in diff_deleted if name not in new_wireguard]
    if deleted_names:
        InterfaceConfig.query.filter(
            InterfaceConfig.interface.in_(deleted_names),
            InterfaceConfig.interface_type.in_(['wireguard', 'Wireguard'])
        ).delete(synchronize_session=False)
        db.session.commit()

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update Wireguard",
            "content": "Wireguard is successfully updated",
        },
    )

    r: list = []
    print("Commands:")
    print(pprint.pformat(excecuted_cmds, indent=2, width=80))

    if len(excecuted_cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=excecuted_cmds, verify=False).json()
        r.append({"cmd": excecuted_cmds, "success": res.get('success'), "error": res.get('error')})

    return r