from __future__ import annotations

import json
import shlex
from datetime import tzinfo
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from uuid import uuid4

import requests
from flask import session

from app.core.api.http.cmd.command import SHOW_SYSTEMS_TIMEZONE
from app.core.api.http.http_request import Action
from app.core.system.config_mgmt.parser import (
    command_to_configure_op,
    extract_config_text,
    parse_commit_log,
    parse_commit_revisions,
    parse_diff_commands,
)
from app.core.utils.cmd_linux import run_linux_cmd
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


SHOW_CONFIG_MGMT = '{"op": "showConfig", "path": ["system", "config-management"]}'

COMMIT_REVISIONS_PATH = ('system', 'config-management', 'commit-revisions')

COMMIT_LOG_FUNCTION = 'ShowCommitLogConfigMgmt'
COMMIT_FILE_FUNCTION = 'ShowCommitFileConfigMgmt'
COMMIT_DIFF_FUNCTION = 'ShowCommitDiffConfigMgmt'
CONFIG_ARCHIVE_DIR = '/config/archive'
VYOS_SCRIPT_TEMPLATE = '/opt/vyatta/etc/functions/script-template'


class ConfigMgmtServiceError(Exception):
    """A config-management operation could not be completed."""


def _emit_success(title: str, content: str) -> None:
    username = session.get('username')
    if not username:
        return
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': title,
            'content': content,
        },
    )


def _format_graphql_errors(errors: Any) -> str:
    if not errors:
        return ''
    if isinstance(errors, str):
        return errors
    if isinstance(errors, list):
        messages = []
        for error in errors:
            if isinstance(error, dict):
                message = error.get('message')
                if message:
                    messages.append(str(message))
            elif error:
                messages.append(str(error))
        return '; '.join(messages)
    return str(errors)


def _read_graphql_operation(response, function_name: str) -> Any:
    try:
        response.raise_for_status()
    except Exception as exc:
        status_code = getattr(response, 'status_code', None)
        suffix = f' (HTTP {status_code})' if status_code else ''
        raise ConfigMgmtServiceError(
            f'Config management request failed{suffix}.'
        ) from exc

    try:
        payload = response.json()
    except Exception as exc:
        raise ConfigMgmtServiceError(
            'Config management response was not valid JSON.'
        ) from exc

    transport_error = _format_graphql_errors(payload.get('errors'))
    if transport_error:
        raise ConfigMgmtServiceError(transport_error)

    payload_data = payload.get('data')
    operation = payload_data.get(function_name) if isinstance(payload_data, dict) else None
    if not isinstance(operation, dict):
        raise ConfigMgmtServiceError(
            f'Config management response did not include {function_name}.'
        )

    operation_error = _format_graphql_errors(operation.get('errors'))
    if operation.get('success') is False or operation_error:
        raise ConfigMgmtServiceError(
            operation_error or 'Config management command failed on the device.'
        )

    operation_data = operation.get('data')
    return operation_data.get('result') if isinstance(operation_data, dict) else None


def _as_text(result: Any) -> str:
    if result is None:
        return ''
    if isinstance(result, (list, tuple)):
        return '\n'.join(str(item) for item in result)
    return str(result)


def _send_configure(provider, commands: List[str]) -> Dict[str, Any]:
    ops = [json.dumps(command_to_configure_op(command)) for command in commands]
    response = provider.http_service.send_request(
        action=Action.CONFIGURE,
        data=ops,
        verify=False,
    )
    try:
        result = response.json()
    except Exception as exc:
        raise ConfigMgmtServiceError(
            'The device returned an invalid response to the configuration change.'
        ) from exc

    if not isinstance(result, dict) or not result.get('success'):
        error = ''
        if isinstance(result, dict):
            error = result.get('error') or ''
        raise ConfigMgmtServiceError(error or 'Failed to apply the configuration change.')

    return result


def fetch_config_mgmt(provider, data=None) -> Dict[str, Any]:
    del data
    response = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_CONFIG_MGMT,
        verify=False,
    )
    try:
        payload = response.json()
    except Exception as exc:
        raise ConfigMgmtServiceError(
            'The device returned an invalid config-management response.'
        ) from exc

    subtree = payload.get('data') if isinstance(payload, dict) else None
    return {'commit_revisions': parse_commit_revisions(subtree)}


def update_config_mgmt(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    commit_revisions = (data or {}).get('commit_revisions')

    if commit_revisions is None:
        current = fetch_config_mgmt(provider).get('commit_revisions')
        if current is None:
            # Nothing configured and nothing requested: no command to send.
            return {'commands': [], 'commit_revisions': None}
        commands = ['delete ' + ' '.join(COMMIT_REVISIONS_PATH)]
    else:
        commands = ['set ' + ' '.join((*COMMIT_REVISIONS_PATH, str(commit_revisions)))]

    logger.info(f'Update config-management commit-revisions: {commands}')
    _send_configure(provider, commands)

    _emit_success(
        'Success: Config Management',
        'Number of revisions deleted'
        if commit_revisions is None
        else f'Number of revisions set to {commit_revisions}',
    )
    return {'commands': commands, 'commit_revisions': commit_revisions}


def _device_timezone(provider) -> Optional[tzinfo]:
    try:
        response = provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=SHOW_SYSTEMS_TIMEZONE,
            verify=False,
        )
        payload = response.json().get('data')
    except Exception as error:
        logger.info(f'Could not read the device timezone: {error}')
        return None

    name = payload
    if isinstance(payload, dict):
        name = payload.get('time-zone')
    if isinstance(name, (list, tuple)):
        name = name[0] if name else None
    if not isinstance(name, str) or not name.strip():
        return None

    try:
        return ZoneInfo(name.strip())
    except (ZoneInfoNotFoundError, ValueError) as error:
        logger.info(f'Unknown device timezone {name!r}: {error}')
        return None


def fetch_commit_log(provider, data=None) -> Dict[str, Any]:
    del data
    response = provider.graphql_service.send_request(
        function_name=COMMIT_LOG_FUNCTION,
        data={},
        verify=False,
    )
    result = _read_graphql_operation(response, COMMIT_LOG_FUNCTION)
    return {
        'commits': parse_commit_log(result, _device_timezone(provider)),
        'raw': _as_text(result),
    }


def fetch_commit_file(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    rev = int((data or {}).get('rev', 0))
    response = provider.graphql_service.send_request(
        function_name=COMMIT_FILE_FUNCTION,
        data=f'rev: {rev}',
        verify=False,
    )
    result = _read_graphql_operation(response, COMMIT_FILE_FUNCTION)
    return {'rev': rev, 'content': extract_config_text(result, rev)}


def fetch_commit_diff(provider, data: Dict[str, Any]) -> Dict[str, Any]:

    data = data or {}
    rev = int(data.get('rev', 0))
    rev2: Optional[int] = data.get('rev2')
    commands = bool(data.get('commands'))

    arguments = [f'rev: {rev}']
    if rev2 is not None:
        arguments.append(f'rev2: {int(rev2)}')
    arguments.append(f'commands: {str(commands).lower()}')

    response = provider.graphql_service.send_request(
        function_name=COMMIT_DIFF_FUNCTION,
        data=', '.join(arguments),
        verify=False,
    )
    result = extract_config_text(_read_graphql_operation(response, COMMIT_DIFF_FUNCTION), rev)

    payload: Dict[str, Any] = {
        'rev': rev,
        'rev2': rev2,
        'commands': commands,
        'result': result,
    }
    if commands:
        payload['command_list'] = parse_diff_commands(result)
    return payload


def apply_commit_diff(provider, data: Dict[str, Any]) -> Dict[str, Any]:

    data = data or {}
    rev = int(data.get('rev', 0))
    rev2: Optional[int] = data.get('rev2')

    diff = fetch_commit_diff(provider, {'rev': rev, 'rev2': rev2, 'commands': True})
    commands = diff.get('command_list') or []

    if not commands:
        return {
            'commands': [],
            'applied': False,
            'message': 'There is no difference between the selected revisions.',
        }

    logger.info(f'Apply config-management diff rev {rev} -> {rev2}: {len(commands)} command(s)')
    _send_configure(provider, commands)

    _emit_success(
        'Success: Config Management',
        f'Applied {len(commands)} command(s) from revision {rev} to '
        f'{"running configuration" if rev2 is None else f"revision {rev2}"}',
    )
    return {'commands': commands, 'applied': True, 'message': None}


def _config_file_op(provider, op: str, path: str) -> Dict[str, Any]:
    http_service = provider.http_service
    base_url = getattr(http_service, 'url', None)
    apikey = getattr(http_service, 'apikey', None)
    if not base_url:
        raise ConfigMgmtServiceError('The device HTTP service URL is not configured.')

    payload = json.dumps({'op': op, 'file': path})
    response = requests.post(
        url=f"{base_url.rstrip('/')}/config-file",
        data={'data': payload, 'key': apikey},
        verify=False,
    )

    try:
        result = response.json()
    except Exception as exc:
        raise ConfigMgmtServiceError(
            f'The device returned an invalid response to the config-file {op}.'
        ) from exc

    if not isinstance(result, dict):
        raise ConfigMgmtServiceError(
            f'The device returned an invalid response to the config-file {op}.'
        )

    if not result.get('success'):
        raise ConfigMgmtServiceError(
            result.get('error') or f'The device rejected the config-file {op}.'
        )

    return {'op': op, 'path': path, 'result': result.get('data')}


def save_config_file(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    path = (data or {}).get('path')
    if not path:
        raise ConfigMgmtServiceError('Configuration file path is required.')
    logger.info(f'Save running configuration to {path}')
    result = _config_file_op(provider, 'save', path)
    _emit_success('Success: Config Management', f'Running configuration saved to {path}')
    return result


def load_config_file(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    path = (data or {}).get('path')
    if not path:
        raise ConfigMgmtServiceError('Configuration file path is required.')
    logger.info(f'Load configuration from {path}')
    result = _config_file_op(provider, 'load', path)
    _emit_success('Success: Config Management', f'Configuration loaded from {path}')
    return result


def revision_archive_path(rev: int) -> str:
    return f'{CONFIG_ARCHIVE_DIR}/config.boot.{int(rev)}.gz'


def load_config_file_cmd(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    del provider
    file_name = (data or {}).get('fileName') or (data or {}).get('path')
    if not file_name:
        raise ConfigMgmtServiceError('Configuration file name is required.')

    script = '\n'.join([
        f'source {VYOS_SCRIPT_TEMPLATE}',
        f'load {shlex.quote(str(file_name))}',
        'commit',
        'exit',
    ])
    command = f'/bin/vbash -c {shlex.quote(script)}'

    logger.info(f'Load configuration file {file_name}')
    output, error = run_linux_cmd(command)

    if error:
        if 'no configuration changes' in error.lower():
            return {'fileName': file_name, 'result': error, 'changed': False}
        raise ConfigMgmtServiceError(error)

    _emit_success('Success: Config Management', f'Configuration loaded from {file_name}')
    return {'fileName': file_name, 'result': output, 'changed': True}


def load_commit_revision(provider, data: Dict[str, Any]) -> Dict[str, Any]:
    rev = int((data or {}).get('rev', 0))
    file_name = revision_archive_path(rev)
    result = load_config_file_cmd(provider, {'fileName': file_name})
    return {'rev': rev, **result}
