from flask import jsonify, request
from pydantic import ValidationError

from app.auth.utils import login_required, permission_required
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.manager import api_manager
from app.core.network import vyos_network_bp
from app.core.network.amp.models import AMPConfig, AMPConfigDTO, AMPMonitor
from app.core.utils.decorator.route_decorator import Pipeline
from app.core.utils.validate.pydantic_error_format import format_pydantic_error


admin_amp = Pipeline.admin(vyos_network_bp)


def _call(action, data=None):
    result = api_manager.call(action=action, target=API_TARGET.AMP, data=data)
    if isinstance(result, Exception):
        raise result
    return jsonify(result), 200


@vyos_network_bp.route('/amp', methods=['GET'])
@login_required
def get_amp():
    try:
        return jsonify(AMPConfig.get_config()), 200
    except Exception as error:
        return jsonify({'error': str(error)}), 400


def _configure(action):
    try:
        config = AMPConfigDTO.model_validate_json(request.data)
        return _call(action, config.to_config())
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@admin_amp.route('/amp', methods=['PUT'])
def update_amp():
    return _configure(API_ACTION.UPDATE)


@admin_amp.route('/amp/verify', methods=['POST'], pause_scheduler=False)
def verify_amp():
    return _configure(API_ACTION.VERIFY)


@vyos_network_bp.route('/amp/monitor', methods=['POST'])
@permission_required(permissions=['administrator', 'operator', 'operator+'])
def monitor_amp():
    try:
        data = AMPMonitor.model_validate_json(request.data)
        return _call(API_ACTION.MONITOR, data)
    except ValidationError as error:
        return jsonify({'error': format_pydantic_error(error)}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400
