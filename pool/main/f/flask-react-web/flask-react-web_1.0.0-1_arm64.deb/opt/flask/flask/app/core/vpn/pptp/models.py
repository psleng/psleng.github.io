from pydantic import BaseModel
from typing import Optional, List

from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship

class PPTPGeneralDTO(BaseModel):
    description: Optional[str] = ''
    defaultIPPool: Optional[str] = ''
    defaultIPv6Pool: Optional[str] = ''
    gatewayAddress: Optional[str] = ''
    outsideAddress: Optional[str] = ''


class PPTPPPDTO(BaseModel):
    controlProtocol: Optional[bool] = None
    interfaceCaching: Optional[int] = None
    IPv4Negotiation: Optional[str] = None
    IPv6Negotiation: Optional[str] = None
    acceptPeerInterfaceID: Optional[bool] = None
    IPv6InterfaceID: Optional[str] = None
    IPv6PeerInterface: Optional[str] = None
    LCPEchoFailure: Optional[int] = None
    LCPEchoInterval: Optional[int] = None
    LCPEchoTimeout: Optional[int] = None
    minMTU: Optional[int] = None
    MPPE: Optional[str] = None
    MRU: Optional[int] = None


class PPTPAdvancedDTO(BaseModel):
    MTU: Optional[int] = None
    nameServers: Optional[List[str]] = []
    log: Optional[int] = None
    WINS: Optional[List[str]] = []
    PPP: Optional[PPTPPPDTO] = None


class PPTPIPPoolDTO(BaseModel):
    name: str
    subnet: Optional[str] = ''


class PPTPClientIPPoolsDTO(BaseModel):
    pools: Optional[List[PPTPIPPoolDTO]] = []


class PPTPIPv6PoolDTO(BaseModel):
    name: str
    prefix: Optional[str] = ''


class PPTPClientIPv6PoolsDTO(BaseModel):
    IPv6Pools: Optional[List[PPTPIPv6PoolDTO]] = []


class PPTPConnectionDTO(BaseModel):
    general: Optional[PPTPGeneralDTO] = None
    advanced: Optional[PPTPAdvancedDTO] = None
    clientIPPools: Optional[PPTPClientIPPoolsDTO] = None
    clientIPv6Pools: Optional[PPTPClientIPv6PoolsDTO] = None


class PPTPLocalUserDTO(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None 
    password: Optional[str] = ''
    staticIP: Optional[str] = ''
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True 


class PPTPLocalUsersDTO(BaseModel):
    users: Optional[List[PPTPLocalUserDTO]] = []


class PPTPRadiusServerDTO(BaseModel):
    address: str
    port: Optional[int] = 1812
    key: Optional[str] = ''  # Shared secret key
    secret: Optional[str] = '' 
    priority: Optional[int] = 1
    accountingPort: Optional[int] = 1813
    failTimePenalty: Optional[int] = 0
    disableAccounting: Optional[bool] = False
    backup: Optional[bool] = False
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True 


class PPTPRadiusOptionsDTO(BaseModel):
    sourceAddress: Optional[str] = None
    NASIdentifier: Optional[str] = None
    NASIPAddress: Optional[str] = None
    timeout: Optional[int] = None
    maxTry: Optional[int] = None
    acctTimeout: Optional[int] = None


class PPTPRadiusDTO(BaseModel):
    servers: Optional[List[PPTPRadiusServerDTO]] = []
    options: Optional[PPTPRadiusOptionsDTO] = None


class PPTPSecurityDTO(BaseModel):
    protocol: Optional[List[str]] = []
    mode: Optional[str] = ''
    localUsers: Optional[PPTPLocalUsersDTO] = None
    radius: Optional[PPTPRadiusDTO] = None


class UpdatePPTPDTO(BaseModel):
    connection: Optional[PPTPConnectionDTO] = None
    security: Optional[PPTPSecurityDTO] = None


class PPTPConfig(db.Model):
    __tablename__ = 'vyos_config_pptp'
    
    id = Column(Integer, primary_key=True)
    description = Column(String(255))
    default_pool = Column(String(100))
    default_ipv6_pool = Column(String(100))
    gateway_address = Column(String(50))
    outside_address = Column(String(50))
    mtu = Column(Integer)
    log_level = Column(Integer)
    
    auth_mode = Column(String(50))
    auth_protocols = Column(Text)
    
    radius_source_address = Column(String(50))
    radius_nas_identifier = Column(String(100))
    radius_nas_ip_address = Column(String(50))
    radius_timeout = Column(Integer)
    radius_acct_timeout = Column(Integer)
    radius_max_try = Column(Integer)
    
    ppp_disable_ccp = Column(Boolean, default=False)
    ppp_interface_cache = Column(Integer)
    ppp_ipv4 = Column(String(20))
    ppp_ipv6 = Column(String(20))
    ppp_ipv6_accept_peer_interface_id = Column(Boolean, default=False)
    ppp_ipv6_interface_id = Column(String(50))
    ppp_ipv6_peer_interface_id = Column(String(50))
    ppp_lcp_echo_failure = Column(Integer)
    ppp_lcp_echo_interval = Column(Integer)
    ppp_lcp_echo_timeout = Column(Integer)
    ppp_min_mtu = Column(Integer)
    ppp_mppe = Column(String(20))
    ppp_mru = Column(Integer)
    
    name_servers = Column(Text)
    wins_servers = Column(Text)
    
    local_users = relationship('PPTPLocalUser', back_populates='config', cascade='all, delete-orphan')
    radius_servers = relationship('PPTPRadiusServer', back_populates='config', cascade='all, delete-orphan')
    ip_pools = relationship('PPTPIPPool', back_populates='config', cascade='all, delete-orphan')
    ipv6_pools = relationship('PPTPIPv6Pool', back_populates='config', cascade='all, delete-orphan')

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_pptp_ipv6_pool',
            'vyos_config_pptp_ip_pool',
            'vyos_config_pptp_radius_server',
            'vyos_config_pptp_local_user',
            'vyos_config_pptp'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config):
        cls.truncate()
        
        if 'remote-access' not in config:
            return
        
        remote_access = config['remote-access']
        pptp_config = cls()
        
        pptp_config.description = remote_access.get('description', '')
        pptp_config.default_pool = remote_access.get('default-pool', '')
        pptp_config.default_ipv6_pool = remote_access.get('default-ipv6-pool', '')
        pptp_config.gateway_address = remote_access.get('gateway-address', '')
        pptp_config.outside_address = remote_access.get('outside-address', '')
        pptp_config.mtu = int(remote_access.get('mtu', 0)) if remote_access.get('mtu') else None
        
        if 'log' in remote_access and 'level' in remote_access['log']:
            pptp_config.log_level = int(remote_access['log']['level'])
        
        if isinstance(remote_access.get('name-server'), list):
            pptp_config.name_servers = ','.join(remote_access['name-server'])
        elif remote_access.get('name-server'):
            pptp_config.name_servers = remote_access['name-server']
        
        if isinstance(remote_access.get('wins-server'), list):
            pptp_config.wins_servers = ','.join(remote_access['wins-server'])
        elif remote_access.get('wins-server'):
            pptp_config.wins_servers = remote_access['wins-server']
        
        if 'authentication' in remote_access:
            auth = remote_access['authentication']
            pptp_config.auth_mode = auth.get('mode', '')
            
            if 'protocols' in auth:
                if isinstance(auth['protocols'], list):
                    pptp_config.auth_protocols = ','.join(auth['protocols'])
                else:
                    pptp_config.auth_protocols = auth['protocols']
            
            if 'local-users' in auth and 'username' in auth['local-users']:
                for username, user_data in auth['local-users']['username'].items():
                    local_user = PPTPLocalUser(
                        username=username,
                        password=user_data.get('password', ''),
                        static_ip=user_data.get('static-ip', ''),
                        disabled='disable' in user_data
                    )
                    pptp_config.local_users.append(local_user)
            
            if 'radius' in auth:
                radius = auth['radius']
                pptp_config.radius_source_address = radius.get('source-address', '')
                pptp_config.radius_nas_identifier = radius.get('nas-identifier', '')
                pptp_config.radius_nas_ip_address = radius.get('nas-ip-address', '')
                pptp_config.radius_timeout = int(radius.get('timeout', 0)) if radius.get('timeout') else None
                pptp_config.radius_acct_timeout = int(radius.get('acct-timeout', 0)) if radius.get('acct-timeout') else None
                pptp_config.radius_max_try = int(radius.get('max-try', 0)) if radius.get('max-try') else None
                
                if 'server' in radius:
                    for server_ip, server_data in radius['server'].items():
                        radius_server = PPTPRadiusServer(
                            address=server_ip,
                            port=int(server_data.get('port', 1812)) if server_data.get('port') else 1812,
                            acct_port=int(server_data.get('acct-port', 1813)) if server_data.get('acct-port') else None,
                            key=server_data.get('key', ''),
                            priority=int(server_data.get('priority', 1)) if server_data.get('priority') else 1,
                            disabled='disable' in server_data,
                            backup='backup' in server_data,
                            disable_accounting='disable-accounting' in server_data,
                            fail_time=int(server_data.get('fail-time', 0)) if server_data.get('fail-time') else None
                        )
                        pptp_config.radius_servers.append(radius_server)
        
        if 'ppp-options' in remote_access:
            ppp = remote_access['ppp-options']
            pptp_config.ppp_disable_ccp = 'disable-ccp' in ppp
            pptp_config.ppp_interface_cache = int(ppp.get('interface-cache', 0)) if ppp.get('interface-cache') else None
            pptp_config.ppp_ipv4 = ppp.get('ipv4', '')
            pptp_config.ppp_ipv6 = ppp.get('ipv6', '')
            pptp_config.ppp_ipv6_accept_peer_interface_id = 'ipv6-accept-peer-interface-id' in ppp
            pptp_config.ppp_ipv6_interface_id = ppp.get('ipv6-interface-id', '')
            pptp_config.ppp_ipv6_peer_interface_id = ppp.get('ipv6-peer-interface-id', '')
            pptp_config.ppp_lcp_echo_failure = int(ppp.get('lcp-echo-failure', 0)) if ppp.get('lcp-echo-failure') else None
            pptp_config.ppp_lcp_echo_interval = int(ppp.get('lcp-echo-interval', 0)) if ppp.get('lcp-echo-interval') else None
            pptp_config.ppp_lcp_echo_timeout = int(ppp.get('lcp-echo-timeout', 0)) if ppp.get('lcp-echo-timeout') else None
            pptp_config.ppp_min_mtu = int(ppp.get('min-mtu', 0)) if ppp.get('min-mtu') else None
            pptp_config.ppp_mppe = ppp.get('mppe', '')
            pptp_config.ppp_mru = int(ppp.get('mru', 0)) if ppp.get('mru') else None
        
        if 'client-ip-pool' in remote_access:
            for pool_name, pool_data in remote_access['client-ip-pool'].items():
                ip_pool = PPTPIPPool(
                    name=pool_name,
                    range=pool_data.get('range', '')
                )
                pptp_config.ip_pools.append(ip_pool)
        
        pptp_config.ipv6_pools = []
        
        if 'client-ipv6-pool' in remote_access:
            for pool_name, pool_data in remote_access['client-ipv6-pool'].items():
                if 'prefix' in pool_data:
                    if isinstance(pool_data['prefix'], dict):
                        prefixes = ','.join(pool_data['prefix'].keys())
                    elif isinstance(pool_data['prefix'], str):
                        prefixes = pool_data['prefix']
                    else:
                        continue
                    
                    ipv6_pool = PPTPIPv6Pool(
                        name=pool_name,
                        prefix=prefixes
                    )
                    pptp_config.ipv6_pools.append(ipv6_pool)
        
        db.session.add(pptp_config)
        db.session.commit()

    def serialize(self):
        result = {}
        
        if self.description:
            result['description'] = self.description
        if self.default_pool:
            result['default-pool'] = self.default_pool
        if self.default_ipv6_pool:
            result['default-ipv6-pool'] = self.default_ipv6_pool
        if self.gateway_address:
            result['gateway-address'] = self.gateway_address
        if self.outside_address:
            result['outside-address'] = self.outside_address
        if self.mtu:
            result['mtu'] = str(self.mtu)
        
        if self.log_level is not None:
            result['log'] = {'level': str(self.log_level)}
        
        if self.name_servers:
            result['name-server'] = self.name_servers.split(',') if ',' in self.name_servers else self.name_servers
        
        if self.wins_servers:
            result['wins-server'] = self.wins_servers.split(',') if ',' in self.wins_servers else self.wins_servers
        
        auth = {}
        if self.auth_mode:
            auth['mode'] = self.auth_mode
        if self.auth_protocols:
            auth['protocols'] = self.auth_protocols.split(',') if ',' in self.auth_protocols else [self.auth_protocols]
        
        if self.local_users:
            auth['local-users'] = {'username': {}}
            for user in self.local_users:
                auth['local-users']['username'][user.username] = user.serialize()
        
        if self.radius_servers or self.radius_source_address or self.radius_nas_identifier:
            radius = {}
            if self.radius_source_address:
                radius['source-address'] = self.radius_source_address
            if self.radius_nas_identifier:
                radius['nas-identifier'] = self.radius_nas_identifier
            if self.radius_nas_ip_address:
                radius['nas-ip-address'] = self.radius_nas_ip_address
            if self.radius_timeout is not None:
                radius['timeout'] = str(self.radius_timeout)
            if self.radius_acct_timeout is not None:
                radius['acct-timeout'] = str(self.radius_acct_timeout)
            if self.radius_max_try is not None:
                radius['max-try'] = str(self.radius_max_try)
            
            if self.radius_servers:
                radius['server'] = {}
                for server in self.radius_servers:
                    radius['server'][server.address] = server.serialize()
            
            auth['radius'] = radius
        
        if auth:
            result['authentication'] = auth
        
        ppp = {}
        if self.ppp_disable_ccp:
            ppp['disable-ccp'] = {}
        if self.ppp_interface_cache is not None:
            ppp['interface-cache'] = str(self.ppp_interface_cache)
        if self.ppp_ipv4:
            ppp['ipv4'] = self.ppp_ipv4
        if self.ppp_ipv6:
            ppp['ipv6'] = self.ppp_ipv6
        if self.ppp_ipv6_accept_peer_interface_id:
            ppp['ipv6-accept-peer-interface-id'] = {}
        if self.ppp_ipv6_interface_id:
            ppp['ipv6-interface-id'] = self.ppp_ipv6_interface_id
        if self.ppp_ipv6_peer_interface_id:
            ppp['ipv6-peer-interface-id'] = self.ppp_ipv6_peer_interface_id
        if self.ppp_lcp_echo_failure is not None:
            ppp['lcp-echo-failure'] = str(self.ppp_lcp_echo_failure)
        if self.ppp_lcp_echo_interval is not None:
            ppp['lcp-echo-interval'] = str(self.ppp_lcp_echo_interval)
        if self.ppp_lcp_echo_timeout is not None:
            ppp['lcp-echo-timeout'] = str(self.ppp_lcp_echo_timeout)
        if self.ppp_min_mtu is not None:
            ppp['min-mtu'] = str(self.ppp_min_mtu)
        if self.ppp_mppe:
            ppp['mppe'] = self.ppp_mppe
        if self.ppp_mru is not None:
            ppp['mru'] = str(self.ppp_mru)
        
        if ppp:
            result['ppp-options'] = ppp
        
        if self.ip_pools:
            result['client-ip-pool'] = {}
            for pool in self.ip_pools:
                result['client-ip-pool'][pool.name] = pool.serialize()
        
        if self.ipv6_pools:
            result['client-ipv6-pool'] = {}
            for pool in self.ipv6_pools:
                result['client-ipv6-pool'][pool.name] = pool.serialize()
        
        return result


class PPTPLocalUser(db.Model):
    __tablename__ = 'vyos_config_pptp_local_user'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_pptp.id'), nullable=False)
    username = Column(String(100), nullable=False)
    password = Column(String(255))
    static_ip = Column(String(50))
    disabled = Column(Boolean, default=False)
    
    config = relationship('PPTPConfig', back_populates='local_users')

    def serialize(self):
        result = {}
        if self.password:
            result['password'] = self.password
        if self.static_ip:
            result['static-ip'] = self.static_ip
        if self.disabled:
            result['disable'] = {}
        return result


class PPTPRadiusServer(db.Model):
    __tablename__ = 'vyos_config_pptp_radius_server'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_pptp.id'), nullable=False)
    address = Column(String(50), nullable=False)
    port = Column(Integer, default=1812)
    acct_port = Column(Integer)
    key = Column(String(255))
    priority = Column(Integer, default=1)
    disabled = Column(Boolean, default=False)
    backup = Column(Boolean, default=False)
    disable_accounting = Column(Boolean, default=False)
    fail_time = Column(Integer)
    
    config = relationship('PPTPConfig', back_populates='radius_servers')

    def serialize(self):
        result = {}
        if self.port:
            result['port'] = str(self.port)
        if self.acct_port:
            result['acct-port'] = str(self.acct_port)
        if self.key:
            result['key'] = self.key
        if self.priority:
            result['priority'] = str(self.priority)
        if self.disabled:
            result['disable'] = {}
        if self.backup:
            result['backup'] = {}
        if self.disable_accounting:
            result['disable-accounting'] = {}
        if self.fail_time:
            result['fail-time'] = str(self.fail_time)
        return result


class PPTPIPPool(db.Model):
    __tablename__ = 'vyos_config_pptp_ip_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_pptp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    range = Column(String(100))
    
    config = relationship('PPTPConfig', back_populates='ip_pools')

    def serialize(self):
        result = {}
        if self.range:
            result['range'] = self.range
        return result


class PPTPIPv6Pool(db.Model):
    __tablename__ = 'vyos_config_pptp_ipv6_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_pptp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    prefix = Column(Text)
    
    config = relationship('PPTPConfig', back_populates='ipv6_pools')

    def serialize(self):
        result = {}
        if self.prefix:
            if isinstance(self.prefix, str):
                prefixes = self.prefix.split(',') if ',' in self.prefix else [self.prefix]
                result['prefix'] = {p.strip(): {} for p in prefixes if p.strip()}
            elif isinstance(self.prefix, dict):
                result['prefix'] = {k: {} for k in self.prefix.keys()}
        return result
