import pprint
import requests
from app.core.api.http.http_request import Action


class TestVRRPEndpointUpdate0:

    @classmethod
    def setup_class(cls):
        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as exc:
            print(f"Registration error (user may already exist): {exc}")

    def _delete_and_login(self, test_service_provider):
        delete_payload = '{"op": "delete", "path": ["high-availability", "vrrp"]}'
        test_service_provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_payload,
            verify=False,
        )

        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def test_clean_state_configuration(self, test_service_provider):
        vrrp_url = "http://localhost/webapi/vyos/high-availability/vrrp"
        cookies = self._delete_and_login(test_service_provider)

        clean_state_config = {
            "connection": {  
                "group": [
                {
                    "VRRPGeneral": {
                        "groupName": "test",
                        "description": "test description",
                        "enable": True,
                        "address": [
                            "10.10.10.10",
                            "20.20.20.20"
                        ],
                        "interface": "eth0",
                        "VRID": 70
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 60,
                        "authenticationPassword": "password",
                        "excludedAddresses": [
                            "20.20.20.20",
                            "30.30.30.30"
                        ],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 90,
                        "priority": 78,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 40,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 200,
                            "masterRepeat": 5
                        },
                        "track": {
                            
                            "excludeVRRP": True,
                            "interface": ["eth0"]
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test2",
                        "description": "",
                        "enable": True,
                        "address": [
                            "192.0.2.1"
                        ],
                        "interface": "eth0",
                        "VRID": 79
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "track": {
                           
                            "excludeVRRP": False,
                            "interface": ["br1","br2"]
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test3",
                        "description": "asdasd",
                        "enable": True,
                        "address": [
                            "30.30.30.30"
                        ],
                        "interface": "br2",
                        "VRID": 1
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "healthCheck": {
                            "isHealthCheckEnabled": True,
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "3.3.3.3"
                        },
                        "track": {
                          
                            "excludeVRRP": False,
                            "interface": ["eth1"]
                        }
                    }
                }
                ],
                "syncGroup": 
                [
                    {
                        "groupName": "test",
                        "member": [],
                        "healthCheck": {
                            "isHealthCheckEnabled": True,
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "3.3.3.3"
                        }
                    },
                    {
                        "groupName": "test2",
                        "member": 
                            ["test2", "test"]
                        ,
                        "healthCheck": {
                            "isHealthCheckEnabled": True,
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "5.5.5.5"
                        }
                    }
                ]

            },
            "globalParameters": {
                "delay": 5,
                "version": 2,
                "enableSNMP": True,
                "GARP": {
                    "interval": 100,
                    "masterDelay": 50,
                    "masterRefresh": 5,
                    "masterRefreshRepeat": 1,
                    "masterRepeat": 200
                }
            }
        }

        response = requests.put(vrrp_url, json=clean_state_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to apply clean state config: {response.text}"

        response_data = response.json()
        print("\n=== Commands Generated (VRRP Clean State) ===")
        pprint.pprint(response_data)
        for item in response_data:
            assert item.get("success", False), f"Command execution failed: {item.get('error', 'Unknown error')}"

        fetch_payload = '{"op": "showConfig", "path": ["high-availability", "vrrp"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=fetch_payload,
            verify=False,
        )

        if fetch_response.status_code != 200:
            return
        fetched_config = fetch_response.json()
        print("\n=== Fetched VRRP Configuration ===")
        pprint.pprint(fetched_config)

        data = fetched_config.get("data", {})
        
        # Validate global parameters
        gp = data.get("global-parameters", {})
        assert isinstance(gp, dict), "Global parameters should be a dictionary"
        assert str(gp.get("startup-delay")) == "5", "Startup delay should be 5"
        assert str(gp.get("version")) == "2", "Version should be 2"
        assert str(gp.get("garp", {}).get("interval", "")) == "100", "GARP interval mismatch"

        # Validate groups
        groups = data.get("group", {})
        assert isinstance(groups, dict), "Groups should be a dictionary"
        assert len(groups) == 3, "Expected 3 VRRP groups"

        g0 = groups.get("test", {})
        assert str(g0.get("advertise-interval")) == "60", "Group 'test' advertise interval mismatch"
        assert str(g0.get("authentication", {}).get("password", "")) == "password", "Group 'test' password mismatch"
        assert str(g0.get("priority")) == "78", "Group 'test' priority mismatch"
        g1 = groups.get("test2", {})
        assert g1.get("address", {}) == {"192.0.2.1": {}}, "Group 'test2' address mismatch"

        g2 = groups.get("test3", {})
        assert g2.get("address", {}) == {"30.30.30.30": {}}, "Group 'test3' address mismatch"
        assert str(g2.get("health-check", {}).get("interval", "")) == "60", "Group 'test3' health-check interval mismatch"

        # Validate sync groups
        sync_groups = data.get("sync-group", {})
        assert isinstance(data.get("sync-group"), dict), "Sync groups should be a dictionary"
        assert len(sync_groups) == 2, "Expected 2 sync groups"
        assert "test2" in sync_groups, "Sync group 'test2' missing"
        assert "test" in sync_groups, "Sync group 'test' missing"
        
        members = sync_groups.get("test2", {}).get("member", [])
        #assert set(["test", "test2"]).issubset(set(members)), "Sync group 'test2' must include 'test' and 'test2'"



        print("\n" + "=" * 50)
        print("VRRP CLEAN STATE CONFIGURATION SUCCESSFULLY CREATED AND VERIFIED!")
        print("=" * 50)