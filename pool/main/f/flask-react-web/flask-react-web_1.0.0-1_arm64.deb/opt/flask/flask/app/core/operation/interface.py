import re

VRRP_INTERFACE_NAME_PATTERN = re.compile(r'^[A-Za-z][A-Za-z0-9._:-]*\d+v\d+v\d+$')

def is_deletable_interface(iface):
    return str(iface).lower() not in ['ethernet', 'loopback', 'wwan', 'wireless']

def is_vrrp_interface_name(interface_name):
    if not isinstance(interface_name, str):
        return False

    return bool(VRRP_INTERFACE_NAME_PATTERN.match(interface_name))

def load_interfaces_json(txt, conf):
    interfaces = []

    blocks = re.split(r'\n(?=\S+:)', txt)

    for block in blocks:
        main_match = re.match(
            r'(\S+):\s+<([^>]+)>\s+mtu\s+(\d+)\s+qdisc\s+(\S+)\s+state\s+(\S+)\s+group\s+(\S+)\s+qlen\s+(\d+)',
            block, re.DOTALL
        )
        if not main_match:
            continue

        interface_name = main_match.group(1)
        flags = main_match.group(2).split(",")
        mtu = int(main_match.group(3))
        qdisc = main_match.group(4)
        state = main_match.group(5)
        group = main_match.group(6)
        qlen = int(main_match.group(7))

        # Extract MAC address
        mac_match = re.search(r'link/\S+\s+([0-9a-f:]+)', block)
        mac_address = mac_match.group(1) if mac_match else None

        # Extract IPv4 address
        ipv4_match = re.search(r'inet\s+([\d.]+)/\d+', block)
        ipv4_address = ipv4_match.group(1) if ipv4_match else None

        # Extract IPv6 address
        ipv6_match = re.search(r'inet6\s+([\da-f:]+)/\d+', block)
        ipv6_address = ipv6_match.group(1) if ipv6_match else None

        # Extract RX and TX stats
        rx_match = re.search(
            r'RX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )
        tx_match = re.search(
            r'TX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )

        # Extract numeric rows for RX and TX stats
        if rx_match:
            rx_bytes = int(rx_match.group(1))
            rx_packets = int(rx_match.group(2))
        else:
            # Extract from the next line if header match fails
            rx_numeric_match = re.search(
                r'RX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if rx_numeric_match:
                rx_bytes = int(rx_numeric_match.group(1))
                rx_packets = int(rx_numeric_match.group(2))
            else:
                rx_bytes = rx_packets = 0

        if tx_match:
            tx_bytes = int(tx_match.group(1))
            tx_packets = int(tx_match.group(2))
        else:
            # Extract from the next line if header match fails
            tx_numeric_match = re.search(
                r'TX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if tx_numeric_match:
                tx_bytes = int(tx_numeric_match.group(1))
                tx_packets = int(tx_numeric_match.group(2))
            else:
                tx_bytes = tx_packets = 0

        # Extract valid_lft and preferred_lft
        lft_match = re.search(r'valid_lft\s+(\S+)\s+preferred_lft\s+(\S+)', block)
        valid_lft = lft_match.group(1) if lft_match else None
        preferred_lft = lft_match.group(2) if lft_match else None

        # Interface Type
        interface_type = "unknown"
        if interface_name[:2] == "br":
            interface_type = "Bridge"
        elif interface_name[:3] == "dum":
            interface_type = "Dummy"
        elif is_vrrp_interface_name(interface_name):
            interface_type = "VRRP"
        elif interface_name[:3] == "eth":
            interface_type = "Ethernet"
        elif interface_name[:2] == "lo":
            interface_type = "Loopback"

        # Extract from config
        intf_conf = conf.get(interface_type.lower()).get(interface_name)
        if intf_conf:
            desc = intf_conf.get('description')
            hw_id = intf_conf.get('hw-id')
            speed = intf_conf.get('speed')
            dhcp_options = intf_conf.get('dhcp-options')
            host_name = dhcp_options.get('host-name') if dhcp_options else None
            redirect = intf_conf.get('redirect')

        interface_info = {
            'interface': interface_name,
            'interface_type': interface_type,
            'flags': flags,
            'mtu': mtu,
            'qdisc': qdisc,
            'state': state,
            'group': group,
            'qlen': qlen,
            'mac_address': mac_address,
            'ipv4': ipv4_address,
            'ipv6': ipv6_address,
            'rx_bytes': rx_bytes,
            'rx_packets': rx_packets,
            'tx_bytes': tx_bytes,
            'tx_packets': tx_packets,
            'valid_lft': valid_lft,
            'preferred_lft': preferred_lft,
            'desc': desc,
            'hw_id': hw_id,
            'speed': speed,
            'host_name': host_name,
            'redirect': redirect
        }

        interfaces.append(interface_info)

    return interfaces


def load_interfaces_json_v2(txt, conf):
    interfaces = []

    blocks = re.split(r'\n(?=\S+:)', txt)

    for block in blocks:
        main_match = re.match(
            r'(\S+):\s+<([^>]+)>\s+mtu\s+(\d+)\s+qdisc\s+(\S+)\s+state\s+(\S+)\s+group\s+(\S+)\s+qlen\s+(\d+)',
            block, re.DOTALL
        )
        if not main_match:
            continue

        interface_name = main_match.group(1)
        flags = main_match.group(2).split(",")
        mtu = int(main_match.group(3))
        qdisc = main_match.group(4)
        state = main_match.group(5)
        group = main_match.group(6)
        qlen = int(main_match.group(7))

        # Extract MAC address
        mac_match = re.search(r'link/\S+\s+([0-9a-f:]+)', block)
        mac_address = mac_match.group(1) if mac_match else None

        # Extract all IPv4 addresses
        ipv4_addresses = re.findall(r'inet\s+([\d.]+)/\d+', block)

        # Extract all IPv6 addresses
        ipv6_addresses = re.findall(r'inet6\s+([\da-f:]+)/\d+', block)

        # Extract RX and TX stats
        rx_match = re.search(
            r'RX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )
        tx_match = re.search(
            r'TX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )

        # Extract numeric rows for RX and TX stats
        if rx_match:
            rx_bytes = int(rx_match.group(1))
            rx_packets = int(rx_match.group(2))
        else:
            # Extract from the next line if header match fails
            rx_numeric_match = re.search(
                r'RX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if rx_numeric_match:
                rx_bytes = int(rx_numeric_match.group(1))
                rx_packets = int(rx_numeric_match.group(2))
            else:
                rx_bytes = rx_packets = 0

        if tx_match:
            tx_bytes = int(tx_match.group(1))
            tx_packets = int(tx_match.group(2))
        else:
            # Extract from the next line if header match fails
            tx_numeric_match = re.search(
                r'TX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if tx_numeric_match:
                tx_bytes = int(tx_numeric_match.group(1))
                tx_packets = int(tx_numeric_match.group(2))
            else:
                tx_bytes = tx_packets = 0

        # Extract valid_lft and preferred_lft
        lft_match = re.search(r'valid_lft\s+(\S+)\s+preferred_lft\s+(\S+)', block)
        valid_lft = lft_match.group(1) if lft_match else None
        preferred_lft = lft_match.group(2) if lft_match else None

        # Interface Type
        interface_type = "unknown"
        if interface_name[:2] == "br":
            interface_type = "Bridge"
        elif interface_name[:3] == "dum":
            interface_type = "Dummy"
        elif is_vrrp_interface_name(interface_name):
            interface_type = "VRRP"
        elif interface_name[:3] == "eth":
            interface_type = "Ethernet"
        elif interface_name[:2] == "lo":
            interface_type = "Loopback"

        # Extract from config
        desc = ""
        hw_id = ""
        speed = ""
        host_name = ""
        redirect = ""
        intf_conf = conf.get(interface_type.lower()).get(interface_name) if conf and conf.get(interface_type.lower()) else None
        if intf_conf:
            desc = intf_conf.get('description')
            hw_id = intf_conf.get('hw-id')
            speed = intf_conf.get('speed')
            dhcp_options = intf_conf.get('dhcp-options')
            host_name = dhcp_options.get('host-name') if dhcp_options else None
            redirect = intf_conf.get('redirect')

        interface_info = {
            'interface': interface_name,
            'interface_type': interface_type,
            'flags': flags,
            'mtu': mtu,
            'qdisc': qdisc,
            'state': state,
            'group': group,
            'qlen': qlen,
            'mac_address': mac_address,
            'ipv4': ipv4_addresses,  # Changed to list of IPv4 addresses
            'ipv6': ipv6_addresses,  # Changed to list of IPv6 addresses
            'rx_bytes': rx_bytes,
            'rx_packets': rx_packets,
            'tx_bytes': tx_bytes,
            'tx_packets': tx_packets,
            'valid_lft': valid_lft,
            'preferred_lft': preferred_lft,
            'desc': desc,
            'hw_id': hw_id,
            'speed': speed,
            'host_name': host_name,
            'redirect': redirect
        }

        interfaces.append(interface_info)

    return interfaces


def load_interfaces_json_v3(txt, conf):
    interfaces = []

    blocks = re.split(r'\n(?=\S+:)', txt)

    for block in blocks:
        main_match = re.match(
            r'(\S+):\s+<([^>]+)>\s+mtu\s+(\d+)\s+qdisc\s+(\S+)\s+state\s+(\S+)\s+group\s+(\S+)\s+qlen\s+(\d+)',
            block, re.DOTALL
        )
        if not main_match:
            continue

        interface_name = main_match.group(1)
        flags = main_match.group(2).split(",")
        mtu = int(main_match.group(3))
        qdisc = main_match.group(4)
        state = main_match.group(5)
        group = main_match.group(6)
        qlen = int(main_match.group(7))

        # Extract MAC address
        mac_match = re.search(r'link/\S+\s+([0-9a-f:]+)', block)
        mac_address = mac_match.group(1) if mac_match else None

        # Extract IPv4 addresses with subnet
        ipv4_details = re.findall(r'inet\s+([\d.]+)/(\d+)', block)
        ipv4_addresses = [addr for addr, _ in ipv4_details]
        ipv4_ranges = [str(subnet) for _, subnet in ipv4_details]

        # Extract IPv6 addresses with subnet
        ipv6_details = re.findall(r'inet6\s+([\da-f:]+)/(\d+)', block)
        ipv6_addresses = [addr for addr, _ in ipv6_details]
        ipv6_ranges = [str(subnet) for _, subnet in ipv6_details]

        # Extract RX and TX stats
        rx_match = re.search(
            r'RX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )
        tx_match = re.search(
            r'TX:\s*(?:bytes\s+(\d+)\s+packets\s+(\d+))', 
            block, re.IGNORECASE
        )

        # Extract numeric rows for RX and TX stats
        if rx_match:
            rx_bytes = int(rx_match.group(1))
            rx_packets = int(rx_match.group(2))
        else:
            # Extract from the next line if header match fails
            rx_numeric_match = re.search(
                r'RX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if rx_numeric_match:
                rx_bytes = int(rx_numeric_match.group(1))
                rx_packets = int(rx_numeric_match.group(2))
            else:
                rx_bytes = rx_packets = 0

        if tx_match:
            tx_bytes = int(tx_match.group(1))
            tx_packets = int(tx_match.group(2))
        else:
            # Extract from the next line if header match fails
            tx_numeric_match = re.search(
                r'TX:.*\n\s*(\d+)\s+(\d+)', 
                block, re.IGNORECASE | re.MULTILINE
            )
            if tx_numeric_match:
                tx_bytes = int(tx_numeric_match.group(1))
                tx_packets = int(tx_numeric_match.group(2))
            else:
                tx_bytes = tx_packets = 0

        # Extract valid_lft and preferred_lft
        lft_match = re.search(r'valid_lft\s+(\S+)\s+preferred_lft\s+(\S+)', block)
        valid_lft = lft_match.group(1) if lft_match else None
        preferred_lft = lft_match.group(2) if lft_match else None

        # Interface Type
        interface_type = "unknown"
        if interface_name[:2] == "br":
            interface_type = "Bridge"
        elif interface_name[:3] == "dum":
            interface_type = "Dummy"
        elif is_vrrp_interface_name(interface_name):
            interface_type = "VRRP"
        elif interface_name[:3] == "eth":
            interface_type = "Ethernet"
        elif interface_name[:2] == "lo":
            interface_type = "Loopback"
        elif interface_name[:3] == "tun":
            interface_type = "Tunnel"
        elif interface_name[:3] == "wla":
            interface_type = "Wireless"
        elif interface_name[:3] == "wwa":
            interface_type = "WWAN"

        # Extract from config
        desc = ""
        hw_id = ""
        speed = ""
        host_name = ""
        redirect = ""
        admin_state = "UP"
        intf_conf = conf.get(interface_type.lower()).get(interface_name) if conf and conf.get(interface_type.lower()) else None
        if intf_conf:
            desc = intf_conf.get('description')
            hw_id = intf_conf.get('hw-id')
            speed = intf_conf.get('speed')
            dhcp_options = intf_conf.get('dhcp-options')
            host_name = dhcp_options.get('host-name') if dhcp_options else None
            redirect = intf_conf.get('redirect')
            admin_state = "DOWN" if 'disable' in intf_conf else "UP"

        interface_info = {
            'interface': interface_name,
            'interface_type': interface_type,
            'flags': flags,
            'mtu': mtu,
            'qdisc': qdisc,
            'admin_state': admin_state,
            'state': state,
            'group': group,
            'qlen': qlen,
            'mac_address': mac_address,
            'ipv4': {
                'addresses': ipv4_addresses,
                'ranges': ipv4_ranges
            },
            'ipv6': {
                'addresses': ipv6_addresses,
                'ranges': ipv6_ranges
            },
            'rx_bytes': rx_bytes,
            'rx_packets': rx_packets,
            'tx_bytes': tx_bytes,
            'tx_packets': tx_packets,
            'valid_lft': valid_lft,
            'preferred_lft': preferred_lft,
            'desc': desc,
            'hw_id': hw_id,
            'speed': speed,
            'host_name': host_name,
            'redirect': redirect,
            'deletable': is_deletable_interface(interface_type),
            'editable': True
        }

        # Add tunnel-specific configuration if this is a tunnel interface
        if interface_type == "Tunnel" and intf_conf:
            iptunnels_config = {
                'local': intf_conf.get('source-address', intf_conf.get('local', '')),
                'remote': intf_conf.get('remote', ''),
                'encapsulation': intf_conf.get('encapsulation', ''),
                'address': intf_conf.get('address', []),
                'ttl': intf_conf.get('ttl', ''),
                'tos': intf_conf.get('tos', ''),
                'mtu': intf_conf.get('mtu', ''),
                'key': intf_conf.get('key', ''),
                'checksum': intf_conf.get('checksum', ''),
                'vrf': intf_conf.get('vrf', ''),
                '6rd-prefix': intf_conf.get('6rd-prefix', ''),
                '6rd-relay-prefix': intf_conf.get('6rd-relay-prefix', ''),
                'description': intf_conf.get('description', ''),
                'disable': intf_conf.get('disable', False)
            }
            # Only include flag-type fields if they actually exist in config
            if 'enable-multicast' in intf_conf:
                iptunnels_config['enable-multicast'] = intf_conf['enable-multicast']
            if 'disable-link-detect' in intf_conf:
                iptunnels_config['disable-link-detect'] = intf_conf['disable-link-detect']
            
            # Add IP General Options if they exist
            if 'ip' in intf_conf:
                ip_conf = intf_conf['ip']
                iptunnels_config['ip'] = {}
                
                # Only include IP fields if they exist
                if 'arp-cache-timeout' in ip_conf:
                    iptunnels_config['ip']['arp-cache-timeout'] = ip_conf['arp-cache-timeout']
                if 'adjust-mss' in ip_conf:
                    iptunnels_config['ip']['adjust-mss'] = ip_conf['adjust-mss']
                if 'enable-arp-accept' in ip_conf:
                    iptunnels_config['ip']['enable-arp-accept'] = ip_conf['enable-arp-accept']
                if 'enable-arp-announce' in ip_conf:
                    iptunnels_config['ip']['enable-arp-announce'] = ip_conf['enable-arp-announce']
                if 'disable-arp-filter' in ip_conf:
                    iptunnels_config['ip']['disable-arp-filter'] = ip_conf['disable-arp-filter']
                if 'enable-arp-ignore' in ip_conf:
                    iptunnels_config['ip']['enable-arp-ignore'] = ip_conf['enable-arp-ignore']
                if 'enable-directed-broadcast' in ip_conf:
                    iptunnels_config['ip']['enable-directed-broadcast'] = ip_conf['enable-directed-broadcast']
                if 'disable-forwarding' in ip_conf:
                    iptunnels_config['ip']['disable-forwarding'] = ip_conf['disable-forwarding']
                if 'enable-proxy-arp' in ip_conf:
                    iptunnels_config['ip']['enable-proxy-arp'] = ip_conf['enable-proxy-arp']
                if 'proxy-arp-pvlan' in ip_conf:
                    iptunnels_config['ip']['proxy-arp-pvlan'] = ip_conf['proxy-arp-pvlan']
                if 'source-validation' in ip_conf:
                    iptunnels_config['ip']['source-validation'] = ip_conf['source-validation']
            
            interface_info['iptunnels_config'] = iptunnels_config

        interfaces.append(interface_info)

    return interfaces

if __name__ == "__main__":
    string = """eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 08:00:27:7a:17:fc brd ff:ff:ff:ff:ff:ff
    altname enp0s3
    inet 10.10.200.42/16 brd 10.10.255.255 scope global dynamic eth0
       valid_lft 151549sec preferred_lft 151549sec
    inet6 fe80::a00:27ff:fe7a:17fc/64 scope link 
       valid_lft forever preferred_lft forever

    RX:     bytes  packets  errors  dropped  overrun       mcast
         98357551   492698       0        0        0        9611
    TX:     bytes  packets  errors  dropped  carrier  collisions
         11972459    38690       0        0        0           0
lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 fe80::200:ff:fe00:0/64 scope link 
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever

    RX:  bytes  packets  errors  dropped  overrun       mcast
         39612      536       0        0        0           0
    TX:  bytes  packets  errors  dropped  carrier  collisions
         39612      536       0        0        0           0"""

    interfaces_info_v2 = load_interfaces_json_v2(string, dict())

    interfaces_info_v3 = load_interfaces_json_v3(string, dict())
    print(interfaces_info_v2)
    print(interfaces_info_v3)
