from . import vyos_login_bp
from .models import UpdateAAADTO

from flask import jsonify, request, session, redirect
import json
from app.core.api.api import API_TARGET, API_ACTION
from app.core.api.manager import api_manager

from app.core.login.parsers import parse_to_login_config
from app.core.login.db_models import SystemLoginOptions
from app.core.api.http.cmd.compare import compare_configs
from app.core.operation.models import UserManagement
from app.auth.models import User
from app.auth.utils import login_required
from app.core.api.http.srv.parser import parse_user_db_to_user_config
from app.log.logger import logger
from app.core.options.models import OptionDefinition
import pprint


def _get_public_key_type_definition():
    return OptionDefinition.query.filter_by(
        namespace="aaa", name="public-key-type"
    ).first()


def _get_public_key_type_values(definition):
    if definition is None:
        return set()
    return {
        item.get("value") if isinstance(item, dict) else item
        for item in definition.values
        if (isinstance(item, str) and item)
        or (isinstance(item, dict) and item.get("value"))
    }


def normalize_keys(config: dict) -> dict:
    normalized = {}
    for key, value in config.items():
        new_key = key.replace("_", "-")
        if isinstance(value, dict):
            normalized[new_key] = normalize_keys(value)
        elif isinstance(value, list):
            normalized[new_key] = [
                normalize_keys(v) if isinstance(v, dict) else v for v in value
            ]
        else:
            normalized[new_key] = value
    return normalized


@vyos_login_bp.route("/AAA", methods=["GET"])
@login_required
def show_aaa_config():
    try:
        opt = (
            SystemLoginOptions.query.filter(
                SystemLoginOptions.login_config_json.isnot(None)
            )
            .filter(SystemLoginOptions.login_config_json != "")
            .filter(
                (SystemLoginOptions.login_config_json.contains('"radius"'))
                | (SystemLoginOptions.login_config_json.contains('"tacacs"'))
                | (SystemLoginOptions.login_config_json.contains('"saml"'))
            )
            .order_by(SystemLoginOptions.id.desc())
            .first()
        )

        if not opt:
            opt = (
                SystemLoginOptions.query.filter(
                    SystemLoginOptions.login_config_json.isnot(None)
                )
                .filter(SystemLoginOptions.login_config_json != "")
                .order_by(SystemLoginOptions.id.desc())
                .first()
            )
        payload = (
            opt.serialize()
            if opt
            else {
                "saml": None,
                "radius": None,
                "tacacs": None,
                "local_users": [],
                "other_options": {},
            }
        )

        return jsonify({"success": True, "data": payload})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_login_bp.route("/AAA", methods=["PUT"])
@login_required
def update_aaa_config():
    try:
        data = UpdateAAADTO.model_validate_json(request.data)
        AAAConfig = data.model_dump(exclude_none=True)

        current_config = api_manager.call(
            action=API_ACTION.READ, target=API_TARGET.LOGIN
        )
        if isinstance(current_config, Exception):
            return jsonify({"error": str(current_config)}), 400
        print("AAA config: ")
        print(pprint.pformat(AAAConfig))
        public_key_types = _get_public_key_type_values(
            _get_public_key_type_definition()
        )
        if not public_key_types:
            raise ValueError("Public key type options are unavailable")
        new_login_cfg = parse_to_login_config(
            AAAConfig,
            current_config=current_config,
            public_key_types=public_key_types,
        )

        new_login_config = {"system": {"login": new_login_cfg}}

        current_login_config = {"system": {"login": normalize_keys(current_config)}}

        print("New login config:")
        print(pprint.pformat(new_login_config))

        print("Curent login config:")
        print(pprint.pformat(current_login_config))

        # Fetch temp user from db
        db_users = User.query.all()
        db_config = parse_user_db_to_user_config(db_users)
        logger.debug("Parsed DB users:")
        logger.debug(db_config["login"])

        diff = compare_configs(new_login_config, current_login_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.LOGIN,
            data={
                "current": current_login_config,
                "new": new_login_config,
                "diff": diff,
                "current_db": db_config["login"],
            },
        )

        # Refresh DB
        api_manager.call(
            action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True}
        )

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400

        return jsonify(res), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_login_bp.route("/AAA/options", methods=["GET"])
@login_required
def get_aaa_options():
    try:
        definition = _get_public_key_type_definition()
        return jsonify({
            "public-key-type": definition.serialize() if definition else None,
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400
