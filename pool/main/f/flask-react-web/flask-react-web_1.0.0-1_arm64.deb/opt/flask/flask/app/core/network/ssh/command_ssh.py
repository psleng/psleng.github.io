from typing import Any

from app.core.api.http.cmd.command import Command


class SSHCommand(Command):
    
    BASE_PATH = ('service', 'ssh')
    MULTI_VALUE_FIELDS = {
        'cipher',
        'hostkey-algorithm',
        'key-exchange',
        'listen-address',
        'mac',
        'port',
        'pubkey-accepted-algorithm',
    }

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'service'),
        )
        self.commands: list[str] = []
        self.vyos_commands: list[str] = []

    def generate_commands(
        self,
        data: dict | None = None,
        current_config: dict | None = None,
        new_config: dict | None = None,
    ) -> list[str]:

        del current_config, new_config

        if not data:
            return []

        for field, value in data.items():
            print(
                f'[SSH COMMAND] field={field!r}, '
                f'value type={type(value).__name__}, value={value!r}'
            )
            self._generate_field(field, value)
        return self.commands

    def generate_delete_service_command(self) -> list[str]:
        self._append_command(list(self.BASE_PATH))
        return self.commands

    def generate_enable_service_command(self) -> list[str]:
        self._append_command(list(self.BASE_PATH))
        return self.commands

    def get_commands(self) -> list[str]:
        return self.vyos_commands

    def _generate_field(self, field: str, value: Any) -> None:
        if field == 'trusted-user-ca' and value in (None, ''):
            if self.operator == 'delete':
                self._append_command([*self.BASE_PATH, field])
            return

        path = [*self.BASE_PATH, field]

        if field in self.MULTI_VALUE_FIELDS:
            self._generate_list(value if isinstance(value, list) else [value], path)
            return

        if field == 'access-control':
            self._generate_access_control(value, path)
            return

        if field == 'dynamic-protection':
            self._generate_dynamic_protection(value, path)
            return

        if field == 'rekey':
            self._generate_scalar_group(value, path)
            return

        self._generate_scalar(value, path)

    def _generate_scalar(self, value: Any, path: list[str]) -> None:
        if self.operator == 'delete' or isinstance(value, dict):
            self._append_command(path)
        else:
            self._append_command([*path, str(value)])

    def _generate_scalar_group(self, values: dict, path: list[str]) -> None:
        for field, value in values.items():
            self._generate_scalar(value, [*path, field])

    def _generate_access_control(self, access_control: dict, path: list[str]) -> None:
        for action, action_config in access_control.items():
            print(f'[SSH COMMAND] access action={action!r}, config type={type(action_config).__name__}, config={action_config!r}')
            users = action_config.get('user', [])
            self._generate_list(users if isinstance(users, list) else [users], [*path, action, 'user'])

    def _generate_dynamic_protection(self, protection: dict, path: list[str]) -> None:
        if not protection:
            self._append_command(path)
            return

        for field, value in protection.items():
            field_path = [*path, field]
            if field == 'allow-from':
                self._generate_list(value if isinstance(value, list) else [value], field_path)
            else:
                self._generate_scalar(value, field_path)

    def _generate_value(self, value: Any, path: list[str]) -> None:
        if isinstance(value, dict):
            self._generate_dictionary(value, path)
            return

        if isinstance(value, list):
            self._generate_list(value, path)
            return

        self._append_command([*path, str(value)])

    def _generate_dictionary(self, value: dict, path: list[str]) -> None:
        if not value:
            self._append_command(path)
            return

        for key, child_value in value.items():
            self._generate_value(child_value, [*path, str(key)])

    def _generate_list(self, values: list, path: list[str]) -> None:
        for value in values:
            self._append_command([*path, str(value)])

    def _append_command(self, path: list[str]) -> None:
        json_path = ','.join(f'"{element}"' for element in path)
        self.commands.append(f'{{"op":"{self.operator}", "path": [{json_path}]}}')
        self.vyos_commands.append(' '.join(path))
