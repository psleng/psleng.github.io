from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.core.utils.format_str import decode_description

def tls_values(value):
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return list(value)
    return [value] if value else []


class OpenVPNRemoteHost(db.Model):
    __tablename__ = 'vyos_config_openvpn_remote_host'
    id = Column(Integer, primary_key=True)
    host = Column(String(255), nullable=False)
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False)

    def serialize(self):
        return self.host

class OpenVPNLocalHost(db.Model):
    __tablename__ = 'vyos_config_openvpn_local_host'
    id = Column(Integer, primary_key=True)
    host = Column(String(255), nullable=False)
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False)

    def serialize(self):
        return self.host

class OpenVPNEncryption(db.Model):
    __tablename__ = 'vyos_config_openvpn_encryption'
    id = Column(Integer, primary_key=True)
    cipher = Column(String(255))
    data_ciphers = Column(String(255))
    data_ciphers_fallback = Column(String(255))
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False, unique=True)

    def serialize(self):
        return {
            'cipher': self.cipher,
            'data_ciphers_fallback': self.data_ciphers_fallback,
            'data_ciphers': self.data_ciphers.split(' ') if self.data_ciphers else []
        }

class OpenVPNServerClientPushRoute(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_push_route'
    id = Column(Integer, primary_key=True)
    route = Column(String(255), nullable=False)
    client_id = Column(Integer, ForeignKey('vyos_config_openvpn_server_client.id'), nullable=False)

    def serialize(self):
        return self.route

class OpenVPNServerClientSubnet(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_subnet'
    id = Column(Integer, primary_key=True)
    subnet = Column(String(255), nullable=False)
    client_id = Column(Integer, ForeignKey('vyos_config_openvpn_server_client.id'), nullable=False)

    def serialize(self):
        return self.subnet

class OpenVPNServerClient(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client'
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    ip = Column(String(255))
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)
    push_routes = relationship('OpenVPNServerClientPushRoute', backref='client', lazy=True, cascade="all, delete-orphan")
    subnets = relationship('OpenVPNServerClientSubnet', backref='client', lazy=True, cascade="all, delete-orphan")

    def serialize(self):
        return {
            'ip': self.ip,
            'push_routes': [r.serialize() for r in self.push_routes],
            'subnets': [s.serialize() for s in self.subnets]
        }

class OpenVPNServerClientIpPool(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_ip_pool'
    id = Column(Integer, primary_key=True)
    start = Column(String(255))
    stop = Column(String(255))
    subnet_mask = Column(String(255))
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False, unique=True)

    def serialize(self):
        return {'start': self.start, 'stop': self.stop, 'subnet_mask': self.subnet_mask}

class OpenVPNServerNameServer(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_name_server'
    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=False)
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)

    def serialize(self):
        return self.address

class OpenVPNServerPushRoute(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_push_route'
    id = Column(Integer, primary_key=True)
    route = Column(String(255), nullable=False)
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)

    def serialize(self):
        return self.route

class OpenVPNServer(db.Model):
    __tablename__ = 'vyos_config_openvpn_server'
    id = Column(Integer, primary_key=True)
    subnet = Column(String(255))
    topology = Column(String(50))
    domain_name = Column(String(255))
    max_connections = Column(Integer)
    reject_unconfigured_clients = Column(Boolean, default=False)
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False, unique=True)
    clients = relationship('OpenVPNServerClient', backref='server', lazy=True, cascade="all, delete-orphan")
    client_ip_pool = relationship('OpenVPNServerClientIpPool', uselist=False, backref='server', lazy=True, cascade="all, delete-orphan")
    name_servers = relationship('OpenVPNServerNameServer', backref='server', lazy=True, cascade="all, delete-orphan")
    push_routes = relationship('OpenVPNServerPushRoute', backref='server', lazy=True, cascade="all, delete-orphan")

    def serialize(self):
        return {
            'subnet': self.subnet,
            'topology': self.topology,
            'domain_name': self.domain_name,
            'max_connections': self.max_connections,
            'reject_unconfigured_clients': self.reject_unconfigured_clients,
            'clients': {client.name: client.serialize() for client in self.clients},
            'client_ip_pool': self.client_ip_pool.serialize() if self.client_ip_pool else None,
            'name_servers': [ns.serialize() for ns in self.name_servers],
            'push_routes': [pr.serialize() for pr in self.push_routes]
        }

class OpenVPNInterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_openvpn_interface'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), unique=True, nullable=False)
    description = Column(Text)
    device_type = Column(String(50))
    hash_algo = Column(String(50))
    ip_version = Column(String(50))
    keep_alive_failure_count = Column(Integer)
    keep_alive_interval = Column(Integer)
    local_address = Column(String(255))
    local_port = Column(Integer)
    mode = Column(String(50))
    persistent_tunnel = Column(Boolean, default=False)
    protocol = Column(String(50))
    remote_address = Column(String(255))
    remote_port = Column(Integer)
    replace_default_route = Column(Boolean, default=False)
    tls_auth_key = Column(String(255))
    tls_ca_certificate = Column(String(255), default='')
    tls_certificate = Column(String(255), default='')
    tls_peer_fingerprint = Column(JSON, default=list)
    tls_crypt_key = Column(String(255))
    tls_dh_params = Column(String(255))
    tls_role = Column(String(50))
    tls_version_min = Column(String(50))
    use_lzo_compression = Column(Boolean, default=False)

    remote_hosts = relationship('OpenVPNRemoteHost', backref='interface', lazy=True, cascade="all, delete-orphan")
    local_hosts = relationship('OpenVPNLocalHost', backref='interface', lazy=True, cascade="all, delete-orphan")
    encryption = relationship('OpenVPNEncryption', uselist=False, backref='interface', lazy=True, cascade="all, delete-orphan")
    server = relationship('OpenVPNServer', uselist=False, backref='interface', lazy=True, cascade="all, delete-orphan")

    def load_tls_values(self, config):
        tls = config.get('tls') or {}
        ca_certificates = tls_values(tls.get('ca-certificate'))
        self.tls_ca_certificate = ca_certificates[0] if ca_certificates else ''
        certificates = tls_values(tls.get('certificate'))
        self.tls_certificate = certificates[0] if certificates else ''
        self.tls_peer_fingerprint = tls_values(tls.get('peer-fingerprint'))

    @classmethod
    def truncate(cls):
        db.session.query(OpenVPNRemoteHost).delete()
        db.session.query(OpenVPNLocalHost).delete()
        db.session.query(OpenVPNServerClientPushRoute).delete()
        db.session.query(OpenVPNServerClientSubnet).delete()
        db.session.query(OpenVPNServerClient).delete()
        db.session.query(OpenVPNServerClientIpPool).delete()
        db.session.query(OpenVPNServerNameServer).delete()
        db.session.query(OpenVPNServerPushRoute).delete()
        db.session.query(OpenVPNServer).delete()
        db.session.query(OpenVPNEncryption).delete()
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, config):
        try:
            # print("OpenVPN config: ")
            # print(config)
            cls.truncate()
            for iface_name, iface_config in config.items():
                if not isinstance(iface_config, dict):
                    continue

                local_address_config = iface_config.get('local-address', {})
                local_address = None
                if isinstance(local_address_config, dict):
                    local_address = next(iter(local_address_config), None)
                elif isinstance(local_address_config, list):
                    local_address = local_address_config[0] if local_address_config else None
                elif local_address_config not in [None, '']:
                    local_address = local_address_config

                new_iface = cls(
                    name=iface_name,
                    description=decode_description(iface_config.get('description')),
                    device_type=iface_config.get('device-type'),
                    hash_algo=iface_config.get('hash'),
                    ip_version=iface_config.get('ip-version'),
                    local_address=local_address,
                    local_port=iface_config.get('local-port'),
                    mode=iface_config.get('mode'),
                    persistent_tunnel='persistent-tunnel' in iface_config,
                    protocol=iface_config.get('protocol'),
                    remote_address=iface_config.get('remote-address'),
                    remote_port=iface_config.get('remote-port'),
                    replace_default_route='replace-default-route' in iface_config,
                    use_lzo_compression='use-lzo-compression' in iface_config
                )

                if isinstance(iface_config.get('keep-alive'), dict):
                    new_iface.keep_alive_failure_count = iface_config['keep-alive'].get('failure-count')
                    new_iface.keep_alive_interval = iface_config['keep-alive'].get('interval')

                new_iface.load_tls_values(iface_config)
                if isinstance(iface_config.get('tls'), dict):
                    new_iface.tls_auth_key = iface_config['tls'].get('auth-key')
                    new_iface.tls_crypt_key = iface_config['tls'].get('crypt-key')
                    new_iface.tls_dh_params = iface_config['tls'].get('dh-params')
                    new_iface.tls_role = iface_config['tls'].get('role')
                    new_iface.tls_version_min = iface_config['tls'].get('tls-version-min')

                if 'remote-host' in iface_config:
                    remote_hosts = iface_config['remote-host']
                    print("Remote hosts:", remote_hosts)
                    if isinstance(remote_hosts, str):
                        new_iface.remote_hosts.append(OpenVPNRemoteHost(host=remote_hosts))
                    elif isinstance(remote_hosts, dict):
                        for host in remote_hosts.keys():
                            new_iface.remote_hosts.append(OpenVPNRemoteHost(host=host))
                    elif isinstance(remote_hosts, list):
                        for host in remote_hosts:
                            new_iface.remote_hosts.append(OpenVPNRemoteHost(host=host))

                if 'local-host' in iface_config:
                    local_hosts = iface_config['local-host']
                    if isinstance(local_hosts, str):
                        new_iface.local_hosts.append(OpenVPNLocalHost(host=local_hosts))
                    elif isinstance(local_hosts, dict):
                        for host in local_hosts.keys():
                            new_iface.local_hosts.append(OpenVPNLocalHost(host=host))
                    elif isinstance(local_hosts, list):
                        for host in local_hosts:
                            new_iface.local_hosts.append(OpenVPNLocalHost(host=host))
                
                if isinstance(iface_config.get('encryption'), dict):
                    data_ciphers_list = iface_config['encryption'].get('data-ciphers')
                    data_ciphers_str = ' '.join(data_ciphers_list) if isinstance(data_ciphers_list, list) else data_ciphers_list
                    new_iface.encryption = OpenVPNEncryption(
                        cipher=iface_config['encryption'].get('cipher'),
                        data_ciphers_fallback=iface_config['encryption'].get('data-ciphers-fallback'),
                        data_ciphers=data_ciphers_str
                    )

                if isinstance(iface_config.get('server'), dict):
                    server_config = iface_config['server']
                    new_server = OpenVPNServer(
                        subnet=server_config.get('subnet'),
                        topology=server_config.get('topology'),
                        domain_name=server_config.get('domain-name'),
                        max_connections=server_config.get('max-connections'),
                        reject_unconfigured_clients='reject-unconfigured-clients' in server_config
                    )
                    new_iface.server = new_server

                    if 'client-ip-pool' in server_config:
                        pool_config = server_config['client-ip-pool']
                        new_server.client_ip_pool = OpenVPNServerClientIpPool(
                            start=pool_config.get('start'),
                            stop=pool_config.get('stop'),
                            subnet_mask=pool_config.get('subnet-mask')
                        )

                    if 'name-server' in server_config:
                        ns_config = server_config['name-server']
                        if isinstance(ns_config, str):
                            new_server.name_servers.append(OpenVPNServerNameServer(address=ns_config))
                        elif isinstance(ns_config, dict):
                             for ns in ns_config.keys():
                                new_server.name_servers.append(OpenVPNServerNameServer(address=ns))

                    if 'push-route' in server_config:
                        pr_config = server_config['push-route']
                        if isinstance(pr_config, str):
                            new_server.push_routes.append(OpenVPNServerPushRoute(route=pr_config))
                        elif isinstance(pr_config, dict):
                            for route in pr_config.keys():
                                new_server.push_routes.append(OpenVPNServerPushRoute(route=route))

                    if isinstance(server_config.get('client'), dict):
                        for client_name, client_config in server_config['client'].items():
                            if not isinstance(client_config, dict):
                                continue

                            new_client = OpenVPNServerClient(
                                name=client_name,
                                ip=client_config.get('ip')
                            )
                            new_server.clients.append(new_client)

                            if 'push-route' in client_config:
                                cr_config = client_config['push-route']
                                if isinstance(cr_config, str):
                                    new_client.push_routes.append(OpenVPNServerClientPushRoute(route=cr_config))
                                elif isinstance(cr_config, dict):
                                    for route in cr_config.keys():
                                        new_client.push_routes.append(OpenVPNServerClientPushRoute(route=route))
                            
                            if 'subnet' in client_config:
                                cs_config = client_config['subnet']
                                if isinstance(cs_config, str):
                                    new_client.subnets.append(OpenVPNServerClientSubnet(subnet=cs_config))
                                elif isinstance(cs_config, dict):
                                    for subnet in cs_config.keys():
                                        new_client.subnets.append(OpenVPNServerClientSubnet(subnet=subnet))

                db.session.add(new_iface)
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing OpenVPN interface data: {e}")
            raise e

    @classmethod
    def upsert(cls, config: dict):
        try:
            if not config or not isinstance(config, dict):
                return

            interface_names = list(config.keys())
            existing_interfaces = cls.query.filter(cls.name.in_(interface_names)).all()
            existing_by_name = {iface.name: iface for iface in existing_interfaces}

            for iface_name, iface_config in config.items():
                if not isinstance(iface_config, dict):
                    continue

                existing_iface = existing_by_name.get(iface_name)

                local_address_config = iface_config.get('local-address', {})
                local_address = None
                if isinstance(local_address_config, dict):
                    local_address = next(iter(local_address_config), None)
                elif isinstance(local_address_config, list):
                    local_address = local_address_config[0] if local_address_config else None
                elif local_address_config not in [None, '']:
                    local_address = local_address_config

                if existing_iface:
                    existing_iface.description = decode_description(iface_config.get('description'))
                    existing_iface.device_type = iface_config.get('device-type')
                    existing_iface.hash_algo = iface_config.get('hash')
                    existing_iface.ip_version = iface_config.get('ip-version')
                    existing_iface.local_address = local_address
                    existing_iface.local_port = iface_config.get('local-port')
                    existing_iface.mode = iface_config.get('mode')
                    existing_iface.persistent_tunnel = 'persistent-tunnel' in iface_config
                    existing_iface.protocol = iface_config.get('protocol')
                    existing_iface.remote_address = iface_config.get('remote-address')
                    existing_iface.remote_port = iface_config.get('remote-port')
                    existing_iface.replace_default_route = 'replace-default-route' in iface_config
                    existing_iface.use_lzo_compression = 'use-lzo-compression' in iface_config

                    if isinstance(iface_config.get('keep-alive'), dict):
                        existing_iface.keep_alive_failure_count = iface_config['keep-alive'].get('failure-count')
                        existing_iface.keep_alive_interval = iface_config['keep-alive'].get('interval')
                    else:
                        existing_iface.keep_alive_failure_count = None
                        existing_iface.keep_alive_interval = None

                    existing_iface.load_tls_values(iface_config)
                    if isinstance(iface_config.get('tls'), dict):
                        existing_iface.tls_auth_key = iface_config['tls'].get('auth-key')
                        existing_iface.tls_crypt_key = iface_config['tls'].get('crypt-key')
                        existing_iface.tls_dh_params = iface_config['tls'].get('dh-params')
                        existing_iface.tls_role = iface_config['tls'].get('role')
                        existing_iface.tls_version_min = iface_config['tls'].get('tls-version-min')

                    existing_iface.remote_hosts.clear()
                    existing_iface.local_hosts.clear()
                    existing_iface.encryption = None
                    existing_iface.server = None
                    db.session.flush()
                else:
                    new_iface = cls(
                        name=iface_name,
                        description=decode_description(iface_config.get('description')),
                        device_type=iface_config.get('device-type'),
                        hash_algo=iface_config.get('hash'),
                        ip_version=iface_config.get('ip-version'),
                        local_address=local_address,
                        local_port=iface_config.get('local-port'),
                        mode=iface_config.get('mode'),
                        persistent_tunnel='persistent-tunnel' in iface_config,
                        protocol=iface_config.get('protocol'),
                        remote_address=iface_config.get('remote-address'),
                        remote_port=iface_config.get('remote-port'),
                        replace_default_route='replace-default-route' in iface_config,
                        use_lzo_compression='use-lzo-compression' in iface_config
                    )

                    if isinstance(iface_config.get('keep-alive'), dict):
                        new_iface.keep_alive_failure_count = iface_config['keep-alive'].get('failure-count')
                        new_iface.keep_alive_interval = iface_config['keep-alive'].get('interval')

                    new_iface.load_tls_values(iface_config)
                    if isinstance(iface_config.get('tls'), dict):
                        new_iface.tls_auth_key = iface_config['tls'].get('auth-key')
                        new_iface.tls_crypt_key = iface_config['tls'].get('crypt-key')
                        new_iface.tls_dh_params = iface_config['tls'].get('dh-params')
                        new_iface.tls_role = iface_config['tls'].get('role')
                        new_iface.tls_version_min = iface_config['tls'].get('tls-version-min')

                    db.session.add(new_iface)
                    db.session.flush()
                    existing_iface = new_iface

                if 'remote-host' in iface_config:
                    remote_hosts = iface_config['remote-host']
                    if isinstance(remote_hosts, str):
                        existing_iface.remote_hosts.append(OpenVPNRemoteHost(host=remote_hosts))
                    elif isinstance(remote_hosts, dict):
                        for host in remote_hosts.keys():
                            existing_iface.remote_hosts.append(OpenVPNRemoteHost(host=host))
                    elif isinstance(remote_hosts, list):
                        for host in remote_hosts:
                            existing_iface.remote_hosts.append(OpenVPNRemoteHost(host=host))

                if 'local-host' in iface_config:
                    local_hosts = iface_config['local-host']
                    if isinstance(local_hosts, str):
                        existing_iface.local_hosts.append(OpenVPNLocalHost(host=local_hosts))
                    elif isinstance(local_hosts, dict):
                        for host in local_hosts.keys():
                            existing_iface.local_hosts.append(OpenVPNLocalHost(host=host))
                    elif isinstance(local_hosts, list):
                        for host in local_hosts:
                            existing_iface.local_hosts.append(OpenVPNLocalHost(host=host))

                if isinstance(iface_config.get('encryption'), dict):
                    data_ciphers_list = iface_config['encryption'].get('data-ciphers')
                    data_ciphers_str = ' '.join(data_ciphers_list) if isinstance(data_ciphers_list, list) else data_ciphers_list
                    existing_iface.encryption = OpenVPNEncryption(
                        cipher=iface_config['encryption'].get('cipher'),
                        data_ciphers_fallback=iface_config['encryption'].get('data-ciphers-fallback'),
                        data_ciphers=data_ciphers_str
                    )

                if isinstance(iface_config.get('server'), dict):
                    server_config = iface_config['server']
                    new_server = OpenVPNServer(
                        subnet=server_config.get('subnet'),
                        topology=server_config.get('topology'),
                        domain_name=server_config.get('domain-name'),
                        max_connections=server_config.get('max-connections'),
                        reject_unconfigured_clients='reject-unconfigured-clients' in server_config
                    )
                    existing_iface.server = new_server

                    if 'client-ip-pool' in server_config:
                        pool_config = server_config['client-ip-pool']
                        new_server.client_ip_pool = OpenVPNServerClientIpPool(
                            start=pool_config.get('start'),
                            stop=pool_config.get('stop'),
                            subnet_mask=pool_config.get('subnet-mask')
                        )

                    if 'name-server' in server_config:
                        ns_config = server_config['name-server']
                        if isinstance(ns_config, str):
                            new_server.name_servers.append(OpenVPNServerNameServer(address=ns_config))
                        elif isinstance(ns_config, dict):
                            for ns in ns_config.keys():
                                new_server.name_servers.append(OpenVPNServerNameServer(address=ns))

                    if 'push-route' in server_config:
                        pr_config = server_config['push-route']
                        if isinstance(pr_config, str):
                            new_server.push_routes.append(OpenVPNServerPushRoute(route=pr_config))
                        elif isinstance(pr_config, dict):
                            for route in pr_config.keys():
                                new_server.push_routes.append(OpenVPNServerPushRoute(route=route))

                    if isinstance(server_config.get('client'), dict):
                        for client_name, client_config in server_config['client'].items():
                            if not isinstance(client_config, dict):
                                continue

                            new_client = OpenVPNServerClient(
                                name=client_name,
                                ip=client_config.get('ip')
                            )
                            new_server.clients.append(new_client)

                            if 'push-route' in client_config:
                                cr_config = client_config['push-route']
                                if isinstance(cr_config, str):
                                    new_client.push_routes.append(OpenVPNServerClientPushRoute(route=cr_config))
                                elif isinstance(cr_config, dict):
                                    for route in cr_config.keys():
                                        new_client.push_routes.append(OpenVPNServerClientPushRoute(route=route))

                            if 'subnet' in client_config:
                                cs_config = client_config['subnet']
                                if isinstance(cs_config, str):
                                    new_client.subnets.append(OpenVPNServerClientSubnet(subnet=cs_config))
                                elif isinstance(cs_config, dict):
                                    for subnet in cs_config.keys():
                                        new_client.subnets.append(OpenVPNServerClientSubnet(subnet=subnet))

            db.session.commit()
        except Exception as e:
            print(f"Error upserting OpenVPN interface data: {e}")
            raise e

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'device_type': self.device_type,
            'hash_algo': self.hash_algo,
            'ip_version': self.ip_version,
            'keep_alive_failure_count': self.keep_alive_failure_count,
            'keep_alive_interval': self.keep_alive_interval,
            'local_address': self.local_address,
            'local_port': self.local_port,
            'mode': self.mode,
            'persistent_tunnel': self.persistent_tunnel,
            'protocol': self.protocol,
            'remote_address': self.remote_address,
            'remote_port': self.remote_port,
            'replace_default_route': self.replace_default_route,
            'tls_auth_key': self.tls_auth_key,
            'tls_ca_certificate': self.tls_ca_certificate or '',
            'tls_certificate': self.tls_certificate or '',
            'tls_peer_fingerprint': tls_values(self.tls_peer_fingerprint),
            'tls_crypt_key': self.tls_crypt_key,
            'tls_dh_params': self.tls_dh_params,
            'tls_role': self.tls_role,
            'tls_version_min': self.tls_version_min,
            'use_lzo_compression': self.use_lzo_compression,
            'remote_hosts': [host.serialize() for host in self.remote_hosts],
            'local_hosts': [host.serialize() for host in self.local_hosts],
            'encryption': self.encryption.serialize() if self.encryption else None,
            'server': self.server.serialize() if self.server else None
        }
