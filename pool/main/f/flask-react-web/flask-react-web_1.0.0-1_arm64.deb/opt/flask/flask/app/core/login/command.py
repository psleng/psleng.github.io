from app.core.api.http.cmd.command import Command
from typing import Optional


def is_str_not_empty(value) -> bool:
    return value is not None and str(value).strip() not in ["", "None"]


class LoginCommand(Command):
    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get("operator", "set"),
                resource=kwargs.get("resource", "system"),
            )
            self.attributes = {"system": {"login": {}}}
            self.cmds = []
            self.vyos_cmds = []

            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Login command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ",".join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(" ".join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _del_or_set_scalar(self, *path, value=None):
        if self.operator == "delete":
            if is_str_not_empty(value):
                self.generate(*path, str(value))
            else:
                self.generate(*path)
            return
        if is_str_not_empty(value):
            self.generate(*path, str(value))

    def _set_bool_keyword(self, *path, enabled: Optional[bool]):
        if self.operator == "delete":
            if enabled:
                self.generate(*path)
            return

        if enabled:
            self.generate(*path)

    def _process_other(self, login_cfg: dict):
        banner = login_cfg.get("banner")
        if isinstance(banner, dict):
            if "pre-login" in banner:
                self._del_or_set_scalar(
                    self.resource,
                    "login",
                    "banner",
                    "pre-login",
                    value=banner.get("pre-login"),
                )
            if "post-login" in banner:
                self._del_or_set_scalar(
                    self.resource,
                    "login",
                    "banner",
                    "post-login",
                    value=banner.get("post-login"),
                )
        elif banner is not None:
            self._del_or_set_scalar(self.resource, "login", "banner", value=banner)

        if "max-login-session" in login_cfg:
            self._del_or_set_scalar(
                self.resource,
                "login",
                "max-login-session",
                value=login_cfg.get("max-login-session"),
            )
        elif "max-sessions" in login_cfg:
            self._del_or_set_scalar(
                self.resource,
                "login",
                "max-login-session",
                value=login_cfg.get("max-sessions"),
            )
        elif "max_sessions" in login_cfg:
            self._del_or_set_scalar(
                self.resource,
                "login",
                "max-login-session",
                value=login_cfg.get("max_sessions"),
            )

        if "timeout" in login_cfg:
            self._del_or_set_scalar(
                self.resource, "login", "timeout", value=login_cfg.get("timeout")
            )

    def _process_radius(self, radius_cfg: dict, new_login_cfg: Optional[dict] = None):
        base = [self.resource, "login", "radius"]

        if not isinstance(radius_cfg, dict):
            return

        if self.operator == "delete" and (radius_cfg == {}):
            self.generate(*base)
            return

        if "security-mode" in radius_cfg:
            self._del_or_set_scalar(
                *base, "security-mode", value=radius_cfg.get("security-mode")
            )

        if "source-address" in radius_cfg:
            src = radius_cfg.get("source-address")
            if isinstance(src, list):
                for ip in src:
                    if is_str_not_empty(ip):
                        self.generate(*base, "source-address", str(ip))
            elif is_str_not_empty(src):
                self.generate(*base, "source-address", str(src))

        if "server" in radius_cfg:
            servers = radius_cfg.get("server")
            if isinstance(servers, dict):
                for addr, server_cfg in servers.items():
                    if not is_str_not_empty(addr):
                        continue
                    if not isinstance(server_cfg, dict):
                        server_cfg = {}

                    server_base = base + ["server", str(addr)]
                    new_server_cfg = {}
                    if isinstance(new_login_cfg, dict):
                        new_radius_cfg = new_login_cfg.get("radius")
                        new_servers = (
                            new_radius_cfg.get("server", {})
                            if isinstance(new_radius_cfg, dict)
                            else {}
                        )
                        if self.operator == "delete" and (
                            not isinstance(new_servers, dict) or addr not in new_servers
                        ):
                            self.generate(*server_base)
                            continue
                        if isinstance(new_servers, dict) and isinstance(
                            new_servers.get(addr), dict
                        ):
                            new_server_cfg = new_servers.get(addr)

                    if server_cfg.get("disable") is True:
                        self.generate(*server_base, "disable")

                    if "key" in server_cfg:
                        self._del_or_set_scalar(
                            *server_base, "key", value=server_cfg.get("key")
                        )

                    if "port" in server_cfg:
                        if self.operator == "delete" and not is_str_not_empty(
                            new_server_cfg.get("port")
                        ):
                            continue
                        self._del_or_set_scalar(
                            *server_base, "port", value=server_cfg.get("port")
                        )

                    if "priority" in server_cfg:
                        if self.operator == "delete" and not is_str_not_empty(
                            new_server_cfg.get("priority")
                        ):
                            continue
                        self._del_or_set_scalar(
                            *server_base, "priority", value=server_cfg.get("priority")
                        )

                    if "timeout" in server_cfg:
                        if self.operator == "delete" and not is_str_not_empty(
                            new_server_cfg.get("timeout")
                        ):
                            continue
                        self._del_or_set_scalar(
                            *server_base, "timeout", value=server_cfg.get("timeout")
                        )

    def _process_saml(self, saml_cfg: dict):
        base = [self.resource, "login", "saml"]

        if not isinstance(saml_cfg, dict):
            return

        if self.operator == "delete" and (saml_cfg == {}):
            self.generate(*base)
            return

        # Basic scalars
        if "provider" in saml_cfg:
            self._del_or_set_scalar(*base, "provider", value=saml_cfg.get("provider"))
        if "entity-id" in saml_cfg:
            self._del_or_set_scalar(*base, "entity-id", value=saml_cfg.get("entity-id"))
        if "metadata-url" in saml_cfg:
            self._del_or_set_scalar(
                *base, "metadata-url", value=saml_cfg.get("metadata-url")
            )

        # Advanced scalars
        if "acs-hostname" in saml_cfg:
            self._del_or_set_scalar(
                *base, "acs-hostname", value=saml_cfg.get("acs-hostname")
            )
        if "serial-address" in saml_cfg:
            self._del_or_set_scalar(
                *base, "serial-address", value=saml_cfg.get("serial-address")
            )
        if "certificate" in saml_cfg:
            self._del_or_set_scalar(
                *base, "certificate", value=saml_cfg.get("certificate")
            )

        # Encrypt (valueless children under encrypt/)
        encrypt = saml_cfg.get("encrypt")
        if isinstance(encrypt, dict):
            if self.operator == "delete" and encrypt == {}:
                self.generate(*base, "encrypt")
            else:
                if "assertions" in encrypt:
                    self.generate(*base, "encrypt", "assertions")
                if "name-id" in encrypt:
                    self.generate(*base, "encrypt", "name-id")

        # Sign (valueless children under sign/)
        sign = saml_cfg.get("sign")
        if isinstance(sign, dict):
            if self.operator == "delete" and sign == {}:
                self.generate(*base, "sign")
            else:
                if "messages" in sign:
                    self.generate(*base, "sign", "messages")

        # JIT role → attribute → value(s)
        jit = saml_cfg.get("jit")
        if isinstance(jit, dict):
            jit_base = base + ["jit"]
            if self.operator == "delete" and jit == {}:
                self.generate(*jit_base)
            else:
                for role in ("admin", "operator", "super-operator"):
                    role_cfg = jit.get(role)
                    if not isinstance(role_cfg, dict):
                        continue
                    role_base = jit_base + [role]
                    if self.operator == "delete" and role_cfg == {}:
                        self.generate(*role_base)
                        continue

                    attrs = role_cfg.get("attribute")
                    if not isinstance(attrs, dict):
                        continue
                    for attr_name, attr_cfg in attrs.items():
                        if not is_str_not_empty(attr_name):
                            continue
                        attr_base = role_base + ["attribute", str(attr_name)]
                        if not isinstance(attr_cfg, dict):
                            continue
                        if self.operator == "delete" and attr_cfg == {}:
                            self.generate(*attr_base)
                            continue
                        values = attr_cfg.get("value")
                        if isinstance(values, list):
                            for v in values:
                                if is_str_not_empty(v):
                                    self.generate(*attr_base, "value", str(v))
                        elif is_str_not_empty(values):
                            self.generate(*attr_base, "value", str(values))

    def _process_tacacs(self, tacacs_cfg: dict):
        base = [self.resource, "login", "tacacs"]

        if not isinstance(tacacs_cfg, dict):
            return

        if self.operator == "delete" and (tacacs_cfg == {}):
            self.generate(*base)
            return

        if "security-mode" in tacacs_cfg:
            self._del_or_set_scalar(
                *base, "security-mode", value=tacacs_cfg.get("security-mode")
            )

        if "source-address" in tacacs_cfg:
            src = tacacs_cfg.get("source-address")
            if isinstance(src, list):
                for ip in src:
                    if is_str_not_empty(ip):
                        self.generate(*base, "source-address", str(ip))
            elif is_str_not_empty(src):
                self.generate(*base, "source-address", str(src))

        if "timeout" in tacacs_cfg:
            self._del_or_set_scalar(*base, "timeout", value=tacacs_cfg.get("timeout"))

        if "server" in tacacs_cfg:
            servers = tacacs_cfg.get("server")
            if isinstance(servers, dict):
                for addr, server_cfg in servers.items():
                    if not is_str_not_empty(addr):
                        continue

                    server_base = base + ["server", str(addr)]
                    if self.operator == "delete":
                        self.generate(*server_base)
                        continue

                    if not server_cfg or not isinstance(server_cfg, dict):
                        self.generate(*server_base)
                        continue

                    if server_cfg.get("disable") is True:
                        self.generate(*server_base, "disable")

                    if "key" in server_cfg:
                        self._del_or_set_scalar(
                            *server_base, "key", value=server_cfg.get("key")
                        )

                    if "port" in server_cfg:
                        self._del_or_set_scalar(
                            *server_base, "port", value=server_cfg.get("port")
                        )

    def _process_local_users(
        self, login_cfg: dict, new_login_cfg: Optional[dict] = None
    ):
        if not isinstance(login_cfg, dict):
            return

        users_cfg = login_cfg.get("user")
        if not isinstance(users_cfg, dict):
            return

        base = [self.resource, "login", "user"]
        next_users_cfg = None
        if isinstance(new_login_cfg, dict):
            candidate = new_login_cfg.get("user")
            if isinstance(candidate, dict):
                next_users_cfg = candidate

        for username, user_cfg in users_cfg.items():
            if not is_str_not_empty(username):
                continue

            user_base = base + [str(username)]
            next_user_cfg = (
                next_users_cfg.get(username)
                if isinstance(next_users_cfg, dict)
                else None
            )

            if self.operator == "delete" and next_user_cfg is None:
                self.generate(*user_base)
                continue

            if not isinstance(user_cfg, dict) or user_cfg == {}:
                self.generate(*user_base)
                continue

            if user_cfg.get("disable") is True:
                self.generate(*user_base, "disable")

            if "full-name" in user_cfg:
                self._del_or_set_scalar(
                    *user_base, "full-name", value=user_cfg.get("full-name")
                )

            if user_cfg.get("operator", {}).get("group", None) in [
                "default",
                "super-operator",
            ]:
                self._del_or_set_scalar(
                    *user_base,
                    "operator",
                    "group",
                    value=user_cfg.get("operator").get("group"),
                )

            auth = user_cfg.get("authentication")
            if isinstance(auth, dict):
                auth_base = user_base + ["authentication"]

                if "encrypted-password" in auth:
                    self._del_or_set_scalar(
                        *auth_base,
                        "encrypted-password",
                        value=auth.get("encrypted-password"),
                    )

                if "plaintext-password" in auth:
                    self._del_or_set_scalar(
                        *auth_base,
                        "plaintext-password",
                        value=auth.get("plaintext-password"),
                    )

                if "saml" in auth:
                    self._del_or_set_scalar(*auth_base, "saml", value=auth.get("saml"))

                if "saml-jit" in auth:
                    # valueless leaf: emit path with no value regardless of the
                    # payload's inner shape ({}, True, "", etc.)
                    self.generate(*auth_base, "saml-jit")

                if "principal" in auth:
                    principal = auth.get("principal")
                    if isinstance(principal, list):
                        for p in principal:
                            if is_str_not_empty(p):
                                self.generate(*auth_base, "principal", str(p))
                    elif is_str_not_empty(principal):
                        self.generate(*auth_base, "principal", str(principal))

                if "public-keys" in auth:
                    pks = auth.get("public-keys")
                    if isinstance(pks, dict):
                        next_auth = next_user_cfg.get("authentication") if isinstance(next_user_cfg, dict) else {}
                        next_pks = next_auth.get("public-keys") if isinstance(next_auth, dict) else {}
                        for pk_name, pk_cfg in pks.items():
                            if not is_str_not_empty(pk_name):
                                continue

                            pk_base = auth_base + ["public-keys", str(pk_name)]
                            if self.operator == "delete" and (
                                not isinstance(next_pks, dict) or pk_name not in next_pks
                            ):
                                self.generate(*pk_base)
                                continue

                            if self.operator == "set":
                                self.generate(*pk_base)

                            if not isinstance(pk_cfg, dict) or pk_cfg == {}:
                                if self.operator != "set":
                                    self.generate(*pk_base)
                                continue

                            if "key" in pk_cfg:
                                self._del_or_set_scalar(
                                    *pk_base, "key", value=pk_cfg.get("key")
                                )
                            if "type" in pk_cfg:
                                self._del_or_set_scalar(
                                    *pk_base, "type", value=pk_cfg.get("type")
                                )

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data or not isinstance(data, dict):
                return []

            current_login_conf = current_config.get("system", {}).get("login", {})
            new_login_conf = new_config.get("system", {}).get("login", {})

            system_cfg = data.get("system", {})
            login_cfg = system_cfg.get("login", {})
            if not login_cfg or not isinstance(login_cfg, dict):
                return []

            self.attributes["system"]["login"] = login_cfg

            self._process_other(login_cfg)

            for auth_node, processor in (
                ("radius", self._process_radius),
                ("saml", self._process_saml),
                ("tacacs", self._process_tacacs),
            ):
                if (
                    self.operator == "delete"
                    and auth_node in current_login_conf
                    and auth_node not in new_login_conf
                ):
                    # The parent deletion includes all servers and options.
                    self.generate(self.resource, "login", auth_node)
                    continue

                if auth_node in login_cfg:
                    if auth_node == "radius":
                        processor(login_cfg[auth_node], new_login_conf)
                    else:
                        processor(login_cfg[auth_node])

            self._process_local_users(login_cfg, new_login_conf)

            return self.cmds
        except Exception as e:
            print(f"Error generating Login commands: {e}")
            return []
