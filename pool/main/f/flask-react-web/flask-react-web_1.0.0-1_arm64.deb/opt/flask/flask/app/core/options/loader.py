from pathlib import Path

from app.db.database import db
from app.log.logger import logger

from .models import OptionDefinition
from .readers import READERS
from .definitions import DEFINITIONS, DEFINITION_DIR


def load_option_definitions(definition_dir=DEFINITION_DIR):
    
    definition_dir = Path(definition_dir)
    parsed = []

    for spec in DEFINITIONS:
        path = definition_dir / spec.filename
        if not path.is_file():
            path = definition_dir / "template" / spec.filename
        try:
            content = path.read_text(encoding="utf-8")
            parsed.append((spec, READERS[spec.reader](content)))
        except (OSError, UnicodeError, ValueError) as exc:
            logger.error("Unable to load option definition %s: %s", path, exc)
            continue

    OptionDefinition.query.delete()
    for spec, data in parsed:
        row = OptionDefinition(
            namespace=spec.namespace,
            name=spec.name,
            value_type=data["type"],
            help_text=data["help"],
            is_multi=data["multi"],
        )
        row.values = data["values"]
        db.session.add(row)
    db.session.commit()
    return len(parsed)


def init_options(app):
    with app.app_context():
        loaded = load_option_definitions()
        logger.info("Loaded %d option definitions", loaded)
