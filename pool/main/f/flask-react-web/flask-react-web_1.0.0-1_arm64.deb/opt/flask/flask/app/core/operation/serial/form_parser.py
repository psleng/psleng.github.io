from app.core.operation.serial.constants import SERIAL_TRANSPORTS
from app.core.operation.serial.validation import validate_name


def validate_page_values(values):
    if not isinstance(values, dict):
        raise ValueError('Serial settings must be an object')
    for key, value in values.items():
        if not isinstance(key, str) or not (isinstance(value, (str, bool)) or
                isinstance(value, list) and all(isinstance(item, str) for item in value)):
            raise ValueError('Serial values must be strings, booleans, or lists of strings')


def join(base, name):
    return f'{base}/{name}' if base else name


def copy_value(result, key, value):
    if value is not None and value != '' and value != []:
        result[key] = value


def read_marker(values, path):
    value = values.get(path)
    if value is not None and not isinstance(value, bool):
        raise ValueError(f'{path}: a boolean is required')
    return value


def read_choice(values, path, choices):
    value = values.get(f'{path}/$choice', '')
    if not isinstance(value, str) or value and value not in choices:
        raise ValueError(f'{path}: invalid mode')
    return value


def read_transport(values):
    if not isinstance(values, dict):
        raise ValueError('Serial settings must be an object')
    value = values.get('$transport', '')
    if not isinstance(value, str) or value and value not in SERIAL_TRANSPORTS:
        raise ValueError('Invalid serial service')
    return value


def read_entries(values, path, minimum=None, maximum=None):
    entries = values.get(path)
    if entries is None:
        return None
    if not isinstance(entries, list) or any(not isinstance(name, str) for name in entries) or len(entries) != len(set(entries)):
        raise ValueError(f'{path}: unique entry names are required')
    for name in entries:
        validate_name(name, minimum, maximum)
    return entries


def read_global_modbus_gateway_tls(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'template', values.get(join(base, 'template')))
    return result if result or marker is True or force else None


def write_global_modbus_gateway_tls(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'template' in raw:
        result[join(base, 'template')] = str(raw['template'])
    return result


def read_global_modbus_gateway(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'allow-broadcast', values.get(join(base, 'allow-broadcast')))
    copy_value(result, 'character-timeout', values.get(join(base, 'character-timeout')))
    copy_value(result, 'disable-exceptions', values.get(join(base, 'disable-exceptions')))
    copy_value(result, 'disable-queuing', values.get(join(base, 'disable-queuing')))
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    copy_value(result, 'message-timeout', values.get(join(base, 'message-timeout')))
    copy_value(result, 'next-request-delay', values.get(join(base, 'next-request-delay')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    return result if result or marker is True or force else None


def write_global_modbus_gateway(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('allow-broadcast', 'character-timeout', 'disable-exceptions', 'disable-queuing', 'idle-timeout', 'message-timeout', 'next-request-delay', 'port', 'tls') for key in raw):
        result[base] = True
    if 'allow-broadcast' in raw:
        result[join(base, 'allow-broadcast')] = True
    if 'character-timeout' in raw:
        result[join(base, 'character-timeout')] = str(raw['character-timeout'])
    if 'disable-exceptions' in raw:
        result[join(base, 'disable-exceptions')] = True
    if 'disable-queuing' in raw:
        result[join(base, 'disable-queuing')] = True
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if 'message-timeout' in raw:
        result[join(base, 'message-timeout')] = str(raw['message-timeout'])
    if 'next-request-delay' in raw:
        result[join(base, 'next-request-delay')] = str(raw['next-request-delay'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    return result


def read_global_process_break(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'ssh-string', values.get(join(base, 'ssh-string')))
    return result if result or marker is True or force else None


def write_global_process_break(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'ssh-string' in raw:
        result[join(base, 'ssh-string')] = str(raw['ssh-string'])
    return result


def read_global_ssh_telnet_server_logging_local(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'view-string', values.get(join(base, 'view-string')))
    return result if result or marker is True or force else None


def write_global_ssh_telnet_server_logging_local(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'view-string' in raw:
        result[join(base, 'view-string')] = str(raw['view-string'])
    return result


def read_global_ssh_telnet_server_logging_nfs_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'directory', values.get(join(base, 'directory')))
    return result if result or marker is True or force else None


def write_global_ssh_telnet_server_logging_nfs_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'directory') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'directory' in raw:
        result[join(base, 'directory')] = str(raw['directory'])
    return result


def read_global_ssh_telnet_server_logging_nfs(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    content = read_global_ssh_telnet_server_logging_nfs_server(values, join(base, 'server'), force=False)
    if content is not None:
        result['server'] = content
    return result if result or marker is True or force else None


def write_global_ssh_telnet_server_logging_nfs(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if isinstance(raw.get('server'), dict):
        write_global_ssh_telnet_server_logging_nfs_server(raw['server'], join(base, 'server'), result)
    return result


def read_global_ssh_telnet_server_logging_syslog(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'level', values.get(join(base, 'level')))
    return result if result or marker is True or force else None


def write_global_ssh_telnet_server_logging_syslog(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'level' in raw:
        result[join(base, 'level')] = str(raw['level'])
    return result


def read_global_ssh_telnet_server_logging(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'keystroke-logging', values.get(join(base, 'keystroke-logging')))
    content = read_global_ssh_telnet_server_logging_local(values, join(base, 'local'), force=False)
    if content is not None:
        result['local'] = content
    content = read_global_ssh_telnet_server_logging_nfs(values, join(base, 'nfs'), force=False)
    if content is not None:
        result['nfs'] = content
    content = read_global_ssh_telnet_server_logging_syslog(values, join(base, 'syslog'), force=False)
    if content is not None:
        result['syslog'] = content
    copy_value(result, 'timestamping', values.get(join(base, 'timestamping')))
    return result if result or marker is True or force else None


def write_global_ssh_telnet_server_logging(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('keystroke-logging', 'local', 'nfs', 'syslog', 'timestamping') for key in raw):
        result[base] = True
    if 'keystroke-logging' in raw:
        result[join(base, 'keystroke-logging')] = True
    if isinstance(raw.get('local'), dict):
        write_global_ssh_telnet_server_logging_local(raw['local'], join(base, 'local'), result)
    if isinstance(raw.get('nfs'), dict):
        write_global_ssh_telnet_server_logging_nfs(raw['nfs'], join(base, 'nfs'), result)
    if isinstance(raw.get('syslog'), dict):
        write_global_ssh_telnet_server_logging_syslog(raw['syslog'], join(base, 'syslog'), result)
    if 'timestamping' in raw:
        result[join(base, 'timestamping')] = True
    return result


def read_global_tcp_keep_alive(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'interval', values.get(join(base, 'interval')))
    copy_value(result, 'retry', values.get(join(base, 'retry')))
    copy_value(result, 'retry-timeout', values.get(join(base, 'retry-timeout')))
    return result if result or marker is True or force else None


def write_global_tcp_keep_alive(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('interval', 'retry', 'retry-timeout') for key in raw):
        result[base] = True
    if 'interval' in raw:
        result[join(base, 'interval')] = str(raw['interval'])
    if 'retry' in raw:
        result[join(base, 'retry')] = str(raw['retry'])
    if 'retry-timeout' in raw:
        result[join(base, 'retry-timeout')] = str(raw['retry-timeout'])
    return result


def read_global_tls_template_cipher_options(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'encryption', values.get(join(base, 'encryption')))
    copy_value(result, 'hmac', values.get(join(base, 'hmac')))
    copy_value(result, 'key-exchange', values.get(join(base, 'key-exchange')))
    copy_value(result, 'max-key-size', values.get(join(base, 'max-key-size')))
    copy_value(result, 'min-key-size', values.get(join(base, 'min-key-size')))
    return result if result or marker is True or force else None


def write_global_tls_template_cipher_options(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('encryption', 'hmac', 'key-exchange', 'max-key-size', 'min-key-size') for key in raw):
        result[base] = True
    if 'encryption' in raw:
        result[join(base, 'encryption')] = str(raw['encryption'])
    if 'hmac' in raw:
        result[join(base, 'hmac')] = str(raw['hmac'])
    if 'key-exchange' in raw:
        result[join(base, 'key-exchange')] = str(raw['key-exchange'])
    if 'max-key-size' in raw:
        result[join(base, 'max-key-size')] = str(raw['max-key-size'])
    if 'min-key-size' in raw:
        result[join(base, 'min-key-size')] = str(raw['min-key-size'])
    return result


def read_global_tls_template_peer_verification(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'common-name', values.get(join(base, 'common-name')))
    copy_value(result, 'country', values.get(join(base, 'country')))
    copy_value(result, 'email', values.get(join(base, 'email')))
    copy_value(result, 'locality', values.get(join(base, 'locality')))
    copy_value(result, 'organization', values.get(join(base, 'organization')))
    copy_value(result, 'organization-unit', values.get(join(base, 'organization-unit')))
    copy_value(result, 'state', values.get(join(base, 'state')))
    return result if result or marker is True or force else None


def write_global_tls_template_peer_verification(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('common-name', 'country', 'email', 'locality', 'organization', 'organization-unit', 'state') for key in raw):
        result[base] = True
    if 'common-name' in raw:
        result[join(base, 'common-name')] = str(raw['common-name'])
    if 'country' in raw:
        result[join(base, 'country')] = str(raw['country'])
    if 'email' in raw:
        result[join(base, 'email')] = str(raw['email'])
    if 'locality' in raw:
        result[join(base, 'locality')] = str(raw['locality'])
    if 'organization' in raw:
        result[join(base, 'organization')] = str(raw['organization'])
    if 'organization-unit' in raw:
        result[join(base, 'organization-unit')] = str(raw['organization-unit'])
    if 'state' in raw:
        result[join(base, 'state')] = str(raw['state'])
    return result


def read_global_tls_template(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'certificate', values.get(join(base, 'certificate')))
    entries = read_entries(values, join(base, 'cipher-options'), 1, 5)
    if entries:
        result['cipher-options'] = {name: read_global_tls_template_cipher_options(values, join(join(base, 'cipher-options'), name), force=True) for name in entries}
    copy_value(result, 'passphrase', values.get(join(base, 'passphrase')))
    content = read_global_tls_template_peer_verification(values, join(base, 'peer-verification'), force=False)
    if content is not None:
        result['peer-verification'] = content
    copy_value(result, 'role', values.get(join(base, 'role')))
    copy_value(result, 'version', values.get(join(base, 'version')))
    return result if result or marker is True or force else None


def write_global_tls_template(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('certificate', 'cipher-options', 'passphrase', 'peer-verification', 'role', 'version') for key in raw):
        result[base] = True
    if 'certificate' in raw:
        result[join(base, 'certificate')] = str(raw['certificate'])
    if isinstance(raw.get('cipher-options'), dict):
        result[join(base, 'cipher-options')] = list(raw['cipher-options'])
        for name, content in raw['cipher-options'].items():
            write_global_tls_template_cipher_options(content, join(join(base, 'cipher-options'), name), result)
    if 'passphrase' in raw:
        result[join(base, 'passphrase')] = str(raw['passphrase'])
    if isinstance(raw.get('peer-verification'), dict):
        write_global_tls_template_peer_verification(raw['peer-verification'], join(base, 'peer-verification'), result)
    if 'role' in raw:
        result[join(base, 'role')] = str(raw['role'])
    if 'version' in raw:
        result[join(base, 'version')] = str(raw['version'])
    return result


def read_global_tls(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    entries = read_entries(values, join(base, 'template'))
    if entries:
        result['template'] = {name: read_global_tls_template(values, join(join(base, 'template'), name), force=True) for name in entries}
    return result if result or marker is True or force else None


def write_global_tls(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('template',) for key in raw):
        result[base] = True
    if isinstance(raw.get('template'), dict):
        result[join(base, 'template')] = list(raw['template'])
        for name, content in raw['template'].items():
            write_global_tls_template(content, join(join(base, 'template'), name), result)
    return result


def read_baud_remap(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'remap', values.get(join(base, 'remap')))
    return result if result or marker is True or force else None


def write_baud_remap(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('remap',) for key in raw):
        result[base] = True
    if 'remap' in raw:
        result[join(base, 'remap')] = str(raw['remap'])
    return result


def read_global_trueport_speed(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_baud_remap(values, join(base, '110'), force=False)
    if content is not None:
        result['110'] = content
    content = read_baud_remap(values, join(base, '1200'), force=False)
    if content is not None:
        result['1200'] = content
    content = read_baud_remap(values, join(base, '134'), force=False)
    if content is not None:
        result['134'] = content
    content = read_baud_remap(values, join(base, '150'), force=False)
    if content is not None:
        result['150'] = content
    content = read_baud_remap(values, join(base, '1800'), force=False)
    if content is not None:
        result['1800'] = content
    content = read_baud_remap(values, join(base, '19200'), force=False)
    if content is not None:
        result['19200'] = content
    content = read_baud_remap(values, join(base, '200'), force=False)
    if content is not None:
        result['200'] = content
    content = read_baud_remap(values, join(base, '2400'), force=False)
    if content is not None:
        result['2400'] = content
    content = read_baud_remap(values, join(base, '300'), force=False)
    if content is not None:
        result['300'] = content
    content = read_baud_remap(values, join(base, '38400'), force=False)
    if content is not None:
        result['38400'] = content
    content = read_baud_remap(values, join(base, '4800'), force=False)
    if content is not None:
        result['4800'] = content
    content = read_baud_remap(values, join(base, '50'), force=False)
    if content is not None:
        result['50'] = content
    content = read_baud_remap(values, join(base, '600'), force=False)
    if content is not None:
        result['600'] = content
    content = read_baud_remap(values, join(base, '75'), force=False)
    if content is not None:
        result['75'] = content
    content = read_baud_remap(values, join(base, '9600'), force=False)
    if content is not None:
        result['9600'] = content
    return result if result or marker is True or force else None


def write_global_trueport_speed(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('110', '1200', '134', '150', '1800', '19200', '200', '2400', '300', '38400', '4800', '50', '600', '75', '9600') for key in raw):
        result[base] = True
    if isinstance(raw.get('110'), dict):
        write_baud_remap(raw['110'], join(base, '110'), result)
    if isinstance(raw.get('1200'), dict):
        write_baud_remap(raw['1200'], join(base, '1200'), result)
    if isinstance(raw.get('134'), dict):
        write_baud_remap(raw['134'], join(base, '134'), result)
    if isinstance(raw.get('150'), dict):
        write_baud_remap(raw['150'], join(base, '150'), result)
    if isinstance(raw.get('1800'), dict):
        write_baud_remap(raw['1800'], join(base, '1800'), result)
    if isinstance(raw.get('19200'), dict):
        write_baud_remap(raw['19200'], join(base, '19200'), result)
    if isinstance(raw.get('200'), dict):
        write_baud_remap(raw['200'], join(base, '200'), result)
    if isinstance(raw.get('2400'), dict):
        write_baud_remap(raw['2400'], join(base, '2400'), result)
    if isinstance(raw.get('300'), dict):
        write_baud_remap(raw['300'], join(base, '300'), result)
    if isinstance(raw.get('38400'), dict):
        write_baud_remap(raw['38400'], join(base, '38400'), result)
    if isinstance(raw.get('4800'), dict):
        write_baud_remap(raw['4800'], join(base, '4800'), result)
    if isinstance(raw.get('50'), dict):
        write_baud_remap(raw['50'], join(base, '50'), result)
    if isinstance(raw.get('600'), dict):
        write_baud_remap(raw['600'], join(base, '600'), result)
    if isinstance(raw.get('75'), dict):
        write_baud_remap(raw['75'], join(base, '75'), result)
    if isinstance(raw.get('9600'), dict):
        write_baud_remap(raw['9600'], join(base, '9600'), result)
    return result


def read_global_trueport(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_global_trueport_speed(values, join(base, 'speed'), force=False)
    if content is not None:
        result['speed'] = content
    return result if result or marker is True or force else None


def write_global_trueport(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('speed',) for key in raw):
        result[base] = True
    if isinstance(raw.get('speed'), dict):
        write_global_trueport_speed(raw['speed'], join(base, 'speed'), result)
    return result


def read_global_virtual_modem_directory_entry(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'phone-number', values.get(join(base, 'phone-number')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_global_virtual_modem_directory_entry(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'phone-number', 'port') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'phone-number' in raw:
        result[join(base, 'phone-number')] = str(raw['phone-number'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_global_virtual_modem(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    entries = read_entries(values, join(base, 'directory-entry'), 1, 8)
    if entries:
        result['directory-entry'] = {name: read_global_virtual_modem_directory_entry(values, join(join(base, 'directory-entry'), name), force=True) for name in entries}
    return result if result or marker is True or force else None


def write_global_virtual_modem(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('directory-entry',) for key in raw):
        result[base] = True
    if isinstance(raw.get('directory-entry'), dict):
        result[join(base, 'directory-entry')] = list(raw['directory-entry'])
        for name, content in raw['directory-entry'].items():
            write_global_virtual_modem_directory_entry(content, join(join(base, 'directory-entry'), name), result)
    return result


def read_global(values, base="", force=False):
    validate_page_values(values)
    result = {}
    if not isinstance(values, dict):
        raise ValueError('Serial settings must be an object')
    copy_value(result, 'flush-on-close', values.get(join(base, 'flush-on-close')))
    content = read_global_modbus_gateway(values, join(base, 'modbus-gateway'), force=False)
    if content is not None:
        result['modbus-gateway'] = content
    content = read_global_process_break(values, join(base, 'process-break'), force=False)
    if content is not None:
        result['process-break'] = content
    content = read_global_ssh_telnet_server_logging(values, join(base, 'ssh-telnet-server-logging'), force=False)
    if content is not None:
        result['ssh-telnet-server-logging'] = content
    content = read_global_tcp_keep_alive(values, join(base, 'tcp-keep-alive'), force=False)
    if content is not None:
        result['tcp-keep-alive'] = content
    content = read_global_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_global_trueport(values, join(base, 'trueport'), force=False)
    if content is not None:
        result['trueport'] = content
    content = read_global_virtual_modem(values, join(base, 'virtual-modem'), force=False)
    if content is not None:
        result['virtual-modem'] = content
    return result


def write_global(raw, base="", result=None):
    result = {} if result is None else result
    if 'flush-on-close' in raw:
        result[join(base, 'flush-on-close')] = True
    if isinstance(raw.get('modbus-gateway'), dict):
        write_global_modbus_gateway(raw['modbus-gateway'], join(base, 'modbus-gateway'), result)
    if isinstance(raw.get('process-break'), dict):
        write_global_process_break(raw['process-break'], join(base, 'process-break'), result)
    if isinstance(raw.get('ssh-telnet-server-logging'), dict):
        write_global_ssh_telnet_server_logging(raw['ssh-telnet-server-logging'], join(base, 'ssh-telnet-server-logging'), result)
    if isinstance(raw.get('tcp-keep-alive'), dict):
        write_global_tcp_keep_alive(raw['tcp-keep-alive'], join(base, 'tcp-keep-alive'), result)
    if isinstance(raw.get('tls'), dict):
        write_global_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('trueport'), dict):
        write_global_trueport(raw['trueport'], join(base, 'trueport'), result)
    if isinstance(raw.get('virtual-modem'), dict):
        write_global_virtual_modem(raw['virtual-modem'], join(base, 'virtual-modem'), result)
    return result


def read_device_protocol_rs232_rts_toggle(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'final-delay', values.get(join(base, 'final-delay')))
    copy_value(result, 'initial-delay', values.get(join(base, 'initial-delay')))
    return result if result or marker is True or force else None


def write_device_protocol_rs232_rts_toggle(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'final-delay' in raw:
        result[join(base, 'final-delay')] = str(raw['final-delay'])
    if 'initial-delay' in raw:
        result[join(base, 'initial-delay')] = str(raw['initial-delay'])
    return result


def read_device_protocol_rs232(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'flow-control', values.get(join(base, 'flow-control')))
    copy_value(result, 'monitor-signal', values.get(join(base, 'monitor-signal')))
    content = read_device_protocol_rs232_rts_toggle(values, join(base, 'rts-toggle'), force=False)
    if content is not None:
        result['rts-toggle'] = content
    return result if result or marker is True or force else None


def write_device_protocol_rs232(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('flow-control', 'monitor-signal', 'rts-toggle') for key in raw):
        result[base] = True
    if 'flow-control' in raw:
        result[join(base, 'flow-control')] = str(raw['flow-control'])
    if 'monitor-signal' in raw:
        result[join(base, 'monitor-signal')] = [str(item) for item in (raw['monitor-signal'] if isinstance(raw['monitor-signal'], list) else [raw['monitor-signal']])]
    if isinstance(raw.get('rts-toggle'), dict):
        write_device_protocol_rs232_rts_toggle(raw['rts-toggle'], join(base, 'rts-toggle'), result)
    return result


def read_device_protocol_rs422(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'flow-control', values.get(join(base, 'flow-control')))
    copy_value(result, 'disable-line-termination', values.get(join(base, 'disable-line-termination')))
    return result if result or marker is True or force else None


def write_device_protocol_rs422(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('flow-control', 'disable-line-termination') for key in raw):
        result[base] = True
    if 'flow-control' in raw:
        result[join(base, 'flow-control')] = str(raw['flow-control'])
    if 'disable-line-termination' in raw:
        result[join(base, 'disable-line-termination')] = True
    return result


def read_device_protocol_rs485_full(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'flow-control', values.get(join(base, 'flow-control')))
    copy_value(result, 'disable-line-termination', values.get(join(base, 'disable-line-termination')))
    return result if result or marker is True or force else None


def write_device_protocol_rs485_full(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('flow-control', 'disable-line-termination') for key in raw):
        result[base] = True
    if 'flow-control' in raw:
        result[join(base, 'flow-control')] = str(raw['flow-control'])
    if 'disable-line-termination' in raw:
        result[join(base, 'disable-line-termination')] = True
    return result


def read_device_protocol_rs485_half(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'flow-control', values.get(join(base, 'flow-control')))
    copy_value(result, 'disable-echo-suppression', values.get(join(base, 'disable-echo-suppression')))
    copy_value(result, 'disable-line-termination', values.get(join(base, 'disable-line-termination')))
    return result if result or marker is True or force else None


def write_device_protocol_rs485_half(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('flow-control', 'disable-echo-suppression', 'disable-line-termination') for key in raw):
        result[base] = True
    if 'flow-control' in raw:
        result[join(base, 'flow-control')] = str(raw['flow-control'])
    if 'disable-echo-suppression' in raw:
        result[join(base, 'disable-echo-suppression')] = True
    if 'disable-line-termination' in raw:
        result[join(base, 'disable-line-termination')] = True
    return result


def read_device_protocol(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('rs232', 'rs422', 'rs485-full', 'rs485-half'))
    if selected == 'rs232':
        content = read_device_protocol_rs232(values, join(base, 'rs232'), force=True)
        if content is not None:
            result['rs232'] = content
    if selected == 'rs422':
        content = read_device_protocol_rs422(values, join(base, 'rs422'), force=True)
        if content is not None:
            result['rs422'] = content
    if selected == 'rs485-full':
        content = read_device_protocol_rs485_full(values, join(base, 'rs485-full'), force=True)
        if content is not None:
            result['rs485-full'] = content
    if selected == 'rs485-half':
        content = read_device_protocol_rs485_half(values, join(base, 'rs485-half'), force=True)
        if content is not None:
            result['rs485-half'] = content
    return result if result or marker is True or force else None


def write_device_protocol(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('rs232', 'rs422', 'rs485-full', 'rs485-half') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('rs232', 'rs422', 'rs485-full', 'rs485-half') if name in raw), '')
    if isinstance(raw.get('rs232'), dict):
        write_device_protocol_rs232(raw['rs232'], join(base, 'rs232'), result)
    if isinstance(raw.get('rs422'), dict):
        write_device_protocol_rs422(raw['rs422'], join(base, 'rs422'), result)
    if isinstance(raw.get('rs485-full'), dict):
        write_device_protocol_rs485_full(raw['rs485-full'], join(base, 'rs485-full'), result)
    if isinstance(raw.get('rs485-half'), dict):
        write_device_protocol_rs485_half(raw['rs485-half'], join(base, 'rs485-half'), result)
    return result


def read_device_login_modem_dial_out(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'phone-number', values.get(join(base, 'phone-number')))
    copy_value(result, 'retry', values.get(join(base, 'retry')))
    copy_value(result, 'timeout', values.get(join(base, 'timeout')))
    return result if result or marker is True or force else None


def write_device_login_modem_dial_out(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'phone-number' in raw:
        result[join(base, 'phone-number')] = str(raw['phone-number'])
    if 'retry' in raw:
        result[join(base, 'retry')] = str(raw['retry'])
    if 'timeout' in raw:
        result[join(base, 'timeout')] = str(raw['timeout'])
    return result


def read_device_login_modem_dial(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('in', 'out'))
    if selected == 'in':
        copy_value(result, 'in', values.get(join(base, 'in')))
        result.setdefault('in', True)
    if selected == 'out':
        content = read_device_login_modem_dial_out(values, join(base, 'out'), force=True)
        if content is not None:
            result['out'] = content
    return result if result or marker is True or force else None


def write_device_login_modem_dial(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('in', 'out') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('in', 'out') if name in raw), '')
    if 'in' in raw:
        result[join(base, 'in')] = True
    if isinstance(raw.get('out'), dict):
        write_device_login_modem_dial_out(raw['out'], join(base, 'out'), result)
    return result


def read_device_login_modem(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_login_modem_dial(values, join(base, 'dial'), force=False)
    if content is not None:
        result['dial'] = content
    copy_value(result, 'initialization-string', values.get(join(base, 'initialization-string')))
    return result if result or marker is True or force else None


def write_device_login_modem(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('dial', 'initialization-string') for key in raw):
        result[base] = True
    if isinstance(raw.get('dial'), dict):
        write_device_login_modem_dial(raw['dial'], join(base, 'dial'), result)
    if 'initialization-string' in raw:
        result[join(base, 'initialization-string')] = str(raw['initialization-string'])
    return result


def read_device_login_transmit_string(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'at-start', values.get(join(base, 'at-start')))
    copy_value(result, 'delay-after-transmit', values.get(join(base, 'delay-after-transmit')))
    return result if result or marker is True or force else None


def write_device_login_transmit_string(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('at-start', 'delay-after-transmit') for key in raw):
        result[base] = True
    if 'at-start' in raw:
        result[join(base, 'at-start')] = str(raw['at-start'])
    if 'delay-after-transmit' in raw:
        result[join(base, 'delay-after-transmit')] = str(raw['delay-after-transmit'])
    return result


def read_device_login(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_device_login_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_login(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('idle-timeout', 'modem', 'post-login-banner', 'pre-login-banner', 'session-timeout', 'transmit-string') for key in raw):
        result[base] = True
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('transmit-string'), dict):
        write_device_login_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_modbus_gateway_master_slave_mapping_list_entry(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'protocol', values.get(join(base, 'protocol')))
    copy_value(result, 'range-mode', values.get(join(base, 'range-mode')))
    copy_value(result, 'slave-ip', values.get(join(base, 'slave-ip')))
    copy_value(result, 'uid', values.get(join(base, 'uid')))
    return result if result or marker is True or force else None


def write_device_modbus_gateway_master_slave_mapping_list_entry(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('port', 'protocol', 'range-mode', 'slave-ip', 'uid') for key in raw):
        result[base] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'protocol' in raw:
        result[join(base, 'protocol')] = str(raw['protocol'])
    if 'range-mode' in raw:
        result[join(base, 'range-mode')] = str(raw['range-mode'])
    if 'slave-ip' in raw:
        result[join(base, 'slave-ip')] = str(raw['slave-ip'])
    if 'uid' in raw:
        result[join(base, 'uid')] = str(raw['uid'])
    return result


def read_device_modbus_gateway_master_slave_mapping_list(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    entries = read_entries(values, join(base, 'entry'), 1, 16)
    if entries:
        result['entry'] = {name: read_device_modbus_gateway_master_slave_mapping_list_entry(values, join(join(base, 'entry'), name), force=True) for name in entries}
    return result if result or marker is True or force else None


def write_device_modbus_gateway_master_slave_mapping_list(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('entry',) for key in raw):
        result[base] = True
    if isinstance(raw.get('entry'), dict):
        result[join(base, 'entry')] = list(raw['entry'])
        for name, content in raw['entry'].items():
            write_device_modbus_gateway_master_slave_mapping_list_entry(content, join(join(base, 'entry'), name), result)
    return result


def read_device_modbus_gateway_master(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_modbus_gateway_master_slave_mapping_list(values, join(base, 'slave-mapping-list'), force=False)
    if content is not None:
        result['slave-mapping-list'] = content
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    return result if result or marker is True or force else None


def write_device_modbus_gateway_master(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('slave-mapping-list', 'tls') for key in raw):
        result[base] = True
    if isinstance(raw.get('slave-mapping-list'), dict):
        write_device_modbus_gateway_master_slave_mapping_list(raw['slave-mapping-list'], join(base, 'slave-mapping-list'), result)
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    return result


def read_device_modbus_gateway_protocol_ascii(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'append-crlf', values.get(join(base, 'append-crlf')))
    return result if result or marker is True or force else None


def write_device_modbus_gateway_protocol_ascii(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('append-crlf',) for key in raw):
        result[base] = True
    if 'append-crlf' in raw:
        result[join(base, 'append-crlf')] = True
    return result


def read_device_modbus_gateway_protocol(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('ascii', 'rtu'))
    if selected == 'ascii':
        content = read_device_modbus_gateway_protocol_ascii(values, join(base, 'ascii'), force=True)
        if content is not None:
            result['ascii'] = content
    if selected == 'rtu':
        copy_value(result, 'rtu', values.get(join(base, 'rtu')))
        result.setdefault('rtu', True)
    return result if result or marker is True or force else None


def write_device_modbus_gateway_protocol(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('ascii', 'rtu') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('ascii', 'rtu') if name in raw), '')
    if isinstance(raw.get('ascii'), dict):
        write_device_modbus_gateway_protocol_ascii(raw['ascii'], join(base, 'ascii'), result)
    if 'rtu' in raw:
        result[join(base, 'rtu')] = True
    return result


def read_device_modbus_gateway_slave_remap_uid_list_entry(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'from', values.get(join(base, 'from')))
    copy_value(result, 'to', values.get(join(base, 'to')))
    return result if result or marker is True or force else None


def write_device_modbus_gateway_slave_remap_uid_list_entry(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('from', 'to') for key in raw):
        result[base] = True
    if 'from' in raw:
        result[join(base, 'from')] = str(raw['from'])
    if 'to' in raw:
        result[join(base, 'to')] = str(raw['to'])
    return result


def read_device_modbus_gateway_slave_remap_uid_list(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    entries = read_entries(values, join(base, 'entry'), 1, 48)
    if entries:
        result['entry'] = {name: read_device_modbus_gateway_slave_remap_uid_list_entry(values, join(join(base, 'entry'), name), force=True) for name in entries}
    return result if result or marker is True or force else None


def write_device_modbus_gateway_slave_remap_uid_list(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('entry',) for key in raw):
        result[base] = True
    if isinstance(raw.get('entry'), dict):
        result[join(base, 'entry')] = list(raw['entry'])
        for name, content in raw['entry'].items():
            write_device_modbus_gateway_slave_remap_uid_list_entry(content, join(join(base, 'entry'), name), result)
    return result


def read_device_modbus_gateway_slave(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    content = read_device_modbus_gateway_slave_remap_uid_list(values, join(base, 'remap-uid-list'), force=False)
    if content is not None:
        result['remap-uid-list'] = content
    copy_value(result, 'uid', values.get(join(base, 'uid')))
    return result if result or marker is True or force else None


def write_device_modbus_gateway_slave(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'remap-uid-list', 'uid') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if isinstance(raw.get('remap-uid-list'), dict):
        write_device_modbus_gateway_slave_remap_uid_list(raw['remap-uid-list'], join(base, 'remap-uid-list'), result)
    if 'uid' in raw:
        result[join(base, 'uid')] = str(raw['uid'])
    return result


def read_device_modbus_gateway(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('master', 'slave'))
    if selected == 'master':
        content = read_device_modbus_gateway_master(values, join(base, 'master'), force=True)
        if content is not None:
            result['master'] = content
    content = read_device_modbus_gateway_protocol(values, join(base, 'protocol'), force=False)
    if content is not None:
        result['protocol'] = content
    if selected == 'slave':
        content = read_device_modbus_gateway_slave(values, join(base, 'slave'), force=True)
        if content is not None:
            result['slave'] = content
    return result if result or marker is True or force else None


def write_device_modbus_gateway(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('master', 'protocol', 'slave') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('master', 'slave') if name in raw), '')
    if isinstance(raw.get('master'), dict):
        write_device_modbus_gateway_master(raw['master'], join(base, 'master'), result)
    if isinstance(raw.get('protocol'), dict):
        write_device_modbus_gateway_protocol(raw['protocol'], join(base, 'protocol'), result)
    if isinstance(raw.get('slave'), dict):
        write_device_modbus_gateway_slave(raw['slave'], join(base, 'slave'), result)
    return result


def read_device_nine_bits_remote(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_nine_bits_remote(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'port') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_nine_bits(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'delay', values.get(join(base, 'delay')))
    content = read_device_nine_bits_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    return result if result or marker is True or force else None


def write_device_nine_bits(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('delay', 'remote') for key in raw):
        result[base] = True
    if 'delay' in raw:
        result[join(base, 'delay')] = str(raw['delay'])
    if isinstance(raw.get('remote'), dict):
        write_device_nine_bits_remote(raw['remote'], join(base, 'remote'), result)
    return result


def read_device_ppp_modem_dial_both(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    if marker is not True:
        return None
    copy_value(result, 'phone-number', values.get(join(base, 'phone-number')))
    copy_value(result, 'retry', values.get(join(base, 'retry')))
    copy_value(result, 'timeout', values.get(join(base, 'timeout')))
    return result if result or marker is True or force else None


def write_device_ppp_modem_dial_both(raw, base="", result=None):
    result = {} if result is None else result
    if True:
        result[base] = True
    if 'phone-number' in raw:
        result[join(base, 'phone-number')] = str(raw['phone-number'])
    if 'retry' in raw:
        result[join(base, 'retry')] = str(raw['retry'])
    if 'timeout' in raw:
        result[join(base, 'timeout')] = str(raw['timeout'])
    return result


def read_device_ppp_modem_dial(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('both', 'in', 'out'))
    if selected == 'both':
        content = read_device_ppp_modem_dial_both(values, join(base, 'both'), force=True)
        if content is not None:
            result['both'] = content
    if selected == 'in':
        copy_value(result, 'in', values.get(join(base, 'in')))
        result.setdefault('in', True)
    if selected == 'out':
        content = read_device_login_modem_dial_out(values, join(base, 'out'), force=True)
        if content is not None:
            result['out'] = content
    return result if result or marker is True or force else None


def write_device_ppp_modem_dial(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('both', 'in', 'out') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('both', 'in', 'out') if name in raw), '')
    if isinstance(raw.get('both'), dict):
        write_device_ppp_modem_dial_both(raw['both'], join(base, 'both'), result)
    if 'in' in raw:
        result[join(base, 'in')] = True
    if isinstance(raw.get('out'), dict):
        write_device_login_modem_dial_out(raw['out'], join(base, 'out'), result)
    return result


def read_device_ppp_modem(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ppp_modem_dial(values, join(base, 'dial'), force=False)
    if content is not None:
        result['dial'] = content
    copy_value(result, 'initialization-string', values.get(join(base, 'initialization-string')))
    return result if result or marker is True or force else None


def write_device_ppp_modem(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('dial', 'initialization-string') for key in raw):
        result[base] = True
    if isinstance(raw.get('dial'), dict):
        write_device_ppp_modem_dial(raw['dial'], join(base, 'dial'), result)
    if 'initialization-string' in raw:
        result[join(base, 'initialization-string')] = str(raw['initialization-string'])
    return result


def read_device_ppp(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ppp_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    return result if result or marker is True or force else None


def write_device_ppp(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('modem',) for key in raw):
        result[base] = True
    if isinstance(raw.get('modem'), dict):
        write_device_ppp_modem(raw['modem'], join(base, 'modem'), result)
    return result


def read_device_remote_printer(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'map-cr-to-crlf', values.get(join(base, 'map-cr-to-crlf')))
    content = read_device_login_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_remote_printer(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('map-cr-to-crlf', 'transmit-string') for key in raw):
        result[base] = True
    if 'map-cr-to-crlf' in raw:
        result[join(base, 'map-cr-to-crlf')] = True
    if isinstance(raw.get('transmit-string'), dict):
        write_device_login_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_serial_tunnel_client(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_nine_bits_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    return result if result or marker is True or force else None


def write_device_serial_tunnel_client(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('remote',) for key in raw):
        result[base] = True
    if isinstance(raw.get('remote'), dict):
        write_device_nine_bits_remote(raw['remote'], join(base, 'remote'), result)
    return result


def read_device_serial_tunnel_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_serial_tunnel_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('port',) for key in raw):
        result[base] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_serial_tunnel(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    copy_value(result, 'break-length', values.get(join(base, 'break-length')))
    if selected == 'client':
        content = read_device_serial_tunnel_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'delay-after-break', values.get(join(base, 'delay-after-break')))
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_device_serial_tunnel_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    return result if result or marker is True or force else None


def write_device_serial_tunnel(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('break-length', 'client', 'delay-after-break', 'send-tcp-keepalive', 'server', 'tls') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if 'break-length' in raw:
        result[join(base, 'break-length')] = str(raw['break-length'])
    if isinstance(raw.get('client'), dict):
        write_device_serial_tunnel_client(raw['client'], join(base, 'client'), result)
    if 'delay-after-break' in raw:
        result[join(base, 'delay-after-break')] = str(raw['delay-after-break'])
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_device_serial_tunnel_server(raw['server'], join(base, 'server'), result)
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    return result


def read_device_slip(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ppp_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    return result if result or marker is True or force else None


def write_device_slip(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('modem',) for key in raw):
        result[base] = True
    if isinstance(raw.get('modem'), dict):
        write_device_ppp_modem(raw['modem'], join(base, 'modem'), result)
    return result


def read_device_ssh_client_initiate(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('any-character', 'character'))
    if selected == 'any-character':
        copy_value(result, 'any-character', values.get(join(base, 'any-character')))
        result.setdefault('any-character', True)
    if selected == 'character':
        copy_value(result, 'character', values.get(join(base, 'character')))
    return result if result or marker is True or force else None


def write_device_ssh_client_initiate(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('any-character', 'character') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('any-character', 'character') if name in raw), '')
    if 'any-character' in raw:
        result[join(base, 'any-character')] = True
    if 'character' in raw:
        result[join(base, 'character')] = str(raw['character'])
    return result


def read_device_ssh_client(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ssh_client_initiate(values, join(base, 'initiate'), force=False)
    if content is not None:
        result['initiate'] = content
    copy_value(result, 'login-name', values.get(join(base, 'login-name')))
    content = read_device_nine_bits_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    copy_value(result, 'terminal-type', values.get(join(base, 'terminal-type')))
    return result if result or marker is True or force else None


def write_device_ssh_client(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('initiate', 'login-name', 'remote', 'terminal-type') for key in raw):
        result[base] = True
    if isinstance(raw.get('initiate'), dict):
        write_device_ssh_client_initiate(raw['initiate'], join(base, 'initiate'), result)
    if 'login-name' in raw:
        result[join(base, 'login-name')] = str(raw['login-name'])
    if isinstance(raw.get('remote'), dict):
        write_device_nine_bits_remote(raw['remote'], join(base, 'remote'), result)
    if 'terminal-type' in raw:
        result[join(base, 'terminal-type')] = str(raw['terminal-type'])
    return result


def read_device_ssh_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'multi-session-limit', values.get(join(base, 'multi-session-limit')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_device_ssh_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'multi-session-limit', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'multi-session-limit' in raw:
        result[join(base, 'multi-session-limit')] = str(raw['multi-session-limit'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_device_ssh_transmit_string(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'at-end', values.get(join(base, 'at-end')))
    copy_value(result, 'at-start', values.get(join(base, 'at-start')))
    copy_value(result, 'delay-after-transmit', values.get(join(base, 'delay-after-transmit')))
    return result if result or marker is True or force else None


def write_device_ssh_transmit_string(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('at-end', 'at-start', 'delay-after-transmit') for key in raw):
        result[base] = True
    if 'at-end' in raw:
        result[join(base, 'at-end')] = str(raw['at-end'])
    if 'at-start' in raw:
        result[join(base, 'at-start')] = str(raw['at-start'])
    if 'delay-after-transmit' in raw:
        result[join(base, 'delay-after-transmit')] = str(raw['delay-after-transmit'])
    return result


def read_device_ssh(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_ssh_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_device_ssh_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_ssh(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'server', 'session-timeout', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_ssh_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_device_ssh_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_tcp_client_remote_backup(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_tcp_client_remote_backup(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'port') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_tcp_client_remote_multi_host_entry(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_tcp_client_remote_multi_host_entry(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'port') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_tcp_client_remote_multi_host(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    entries = read_entries(values, join(base, 'entry'), 1, 50)
    if entries:
        result['entry'] = {name: read_device_tcp_client_remote_multi_host_entry(values, join(join(base, 'entry'), name), force=True) for name in entries}
    return result if result or marker is True or force else None


def write_device_tcp_client_remote_multi_host(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('entry',) for key in raw):
        result[base] = True
    if isinstance(raw.get('entry'), dict):
        result[join(base, 'entry')] = list(raw['entry'])
        for name, content in raw['entry'].items():
            write_device_tcp_client_remote_multi_host_entry(content, join(join(base, 'entry'), name), result)
    return result


def read_device_tcp_client_remote_primary(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_tcp_client_remote_primary(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'port') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_tcp_client_remote(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_tcp_client_remote_backup(values, join(base, 'backup'), force=False)
    if content is not None:
        result['backup'] = content
    content = read_device_tcp_client_remote_multi_host(values, join(base, 'multi-host'), force=False)
    if content is not None:
        result['multi-host'] = content
    content = read_device_tcp_client_remote_primary(values, join(base, 'primary'), force=False)
    if content is not None:
        result['primary'] = content
    return result if result or marker is True or force else None


def write_device_tcp_client_remote(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('backup', 'multi-host', 'primary') for key in raw):
        result[base] = True
    if isinstance(raw.get('backup'), dict):
        write_device_tcp_client_remote_backup(raw['backup'], join(base, 'backup'), result)
    if isinstance(raw.get('multi-host'), dict):
        write_device_tcp_client_remote_multi_host(raw['multi-host'], join(base, 'multi-host'), result)
    if isinstance(raw.get('primary'), dict):
        write_device_tcp_client_remote_primary(raw['primary'], join(base, 'primary'), result)
    return result


def read_device_tcp_client(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ssh_client_initiate(values, join(base, 'initiate'), force=False)
    if content is not None:
        result['initiate'] = content
    content = read_device_tcp_client_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    copy_value(result, 'send-description-on-connect', values.get(join(base, 'send-description-on-connect')))
    return result if result or marker is True or force else None


def write_device_tcp_client(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('initiate', 'remote', 'send-description-on-connect') for key in raw):
        result[base] = True
    if isinstance(raw.get('initiate'), dict):
        write_device_ssh_client_initiate(raw['initiate'], join(base, 'initiate'), result)
    if isinstance(raw.get('remote'), dict):
        write_device_tcp_client_remote(raw['remote'], join(base, 'remote'), result)
    if 'send-description-on-connect' in raw:
        result[join(base, 'send-description-on-connect')] = True
    return result


def read_device_tcp_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'allow-multiple-connections', values.get(join(base, 'allow-multiple-connections')))
    copy_value(result, 'authenticate-user', values.get(join(base, 'authenticate-user')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_device_tcp_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'allow-multiple-connections', 'authenticate-user', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'allow-multiple-connections' in raw:
        result[join(base, 'allow-multiple-connections')] = True
    if 'authenticate-user' in raw:
        result[join(base, 'authenticate-user')] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_device_tcp(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_tcp_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    copy_value(result, 'serial-buffering', values.get(join(base, 'serial-buffering')))
    if selected == 'server':
        content = read_device_tcp_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_tcp(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'serial-buffering', 'server', 'session-timeout', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_tcp_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if 'serial-buffering' in raw:
        result[join(base, 'serial-buffering')] = True
    if isinstance(raw.get('server'), dict):
        write_device_tcp_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_telnet_client(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_ssh_client_initiate(values, join(base, 'initiate'), force=False)
    if content is not None:
        result['initiate'] = content
    copy_value(result, 'map-cr-to-crlf', values.get(join(base, 'map-cr-to-crlf')))
    content = read_device_nine_bits_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    copy_value(result, 'terminal-type', values.get(join(base, 'terminal-type')))
    return result if result or marker is True or force else None


def write_device_telnet_client(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('initiate', 'map-cr-to-crlf', 'remote', 'terminal-type') for key in raw):
        result[base] = True
    if isinstance(raw.get('initiate'), dict):
        write_device_ssh_client_initiate(raw['initiate'], join(base, 'initiate'), result)
    if 'map-cr-to-crlf' in raw:
        result[join(base, 'map-cr-to-crlf')] = True
    if isinstance(raw.get('remote'), dict):
        write_device_nine_bits_remote(raw['remote'], join(base, 'remote'), result)
    if 'terminal-type' in raw:
        result[join(base, 'terminal-type')] = str(raw['terminal-type'])
    return result


def read_device_telnet_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'address', values.get(join(base, 'address')))
    copy_value(result, 'authenticate-user', values.get(join(base, 'authenticate-user')))
    copy_value(result, 'multi-session-limit', values.get(join(base, 'multi-session-limit')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_device_telnet_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'authenticate-user', 'multi-session-limit', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'address' in raw:
        result[join(base, 'address')] = str(raw['address'])
    if 'authenticate-user' in raw:
        result[join(base, 'authenticate-user')] = True
    if 'multi-session-limit' in raw:
        result[join(base, 'multi-session-limit')] = str(raw['multi-session-limit'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_device_telnet(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_telnet_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_device_telnet_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_telnet(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'server', 'session-timeout', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_telnet_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_device_telnet_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_trueport_client(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_tcp_client_remote(values, join(base, 'remote'), force=False)
    if content is not None:
        result['remote'] = content
    copy_value(result, 'send-description-on-connect', values.get(join(base, 'send-description-on-connect')))
    return result if result or marker is True or force else None


def write_device_trueport_client(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('remote', 'send-description-on-connect') for key in raw):
        result[base] = True
    if isinstance(raw.get('remote'), dict):
        write_device_tcp_client_remote(raw['remote'], join(base, 'remote'), result)
    if 'send-description-on-connect' in raw:
        result[join(base, 'send-description-on-connect')] = True
    return result


def read_device_trueport_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'allow-multiple-connections', values.get(join(base, 'allow-multiple-connections')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_trueport_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('allow-multiple-connections', 'port') for key in raw):
        result[base] = True
    if 'allow-multiple-connections' in raw:
        result[join(base, 'allow-multiple-connections')] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_trueport(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_trueport_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    copy_value(result, 'serial-buffering', values.get(join(base, 'serial-buffering')))
    if selected == 'server':
        content = read_device_trueport_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    copy_value(result, 'signal-active', values.get(join(base, 'signal-active')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_trueport(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'send-tcp-keepalive', 'serial-buffering', 'server', 'session-timeout', 'signal-active', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_trueport_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if 'serial-buffering' in raw:
        result[join(base, 'serial-buffering')] = True
    if isinstance(raw.get('server'), dict):
        write_device_trueport_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if 'signal-active' in raw:
        result[join(base, 'signal-active')] = True
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_udp_rule_address(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'end', values.get(join(base, 'end')))
    copy_value(result, 'start', values.get(join(base, 'start')))
    return result if result or marker is True or force else None


def write_device_udp_rule_address(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('end', 'start') for key in raw):
        result[base] = True
    if 'end' in raw:
        result[join(base, 'end')] = str(raw['end'])
    if 'start' in raw:
        result[join(base, 'start')] = str(raw['start'])
    return result


def read_device_udp_rule_direction_both(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'port', values.get(join(base, 'port')))
    return result if result or marker is True or force else None


def write_device_udp_rule_direction_both(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('port',) for key in raw):
        result[base] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    return result


def read_device_udp_rule_direction_lan_serial(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'source-port', values.get(join(base, 'source-port')))
    return result if result or marker is True or force else None


def write_device_udp_rule_direction_lan_serial(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('source-port',) for key in raw):
        result[base] = True
    if 'source-port' in raw:
        result[join(base, 'source-port')] = str(raw['source-port'])
    return result


def read_device_udp_rule_direction_serial_lan(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'destination-port', values.get(join(base, 'destination-port')))
    return result if result or marker is True or force else None


def write_device_udp_rule_direction_serial_lan(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('destination-port',) for key in raw):
        result[base] = True
    if 'destination-port' in raw:
        result[join(base, 'destination-port')] = str(raw['destination-port'])
    return result


def read_device_udp_rule_direction(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('both', 'lan-serial', 'serial-lan'))
    if selected == 'both':
        content = read_device_udp_rule_direction_both(values, join(base, 'both'), force=True)
        if content is not None:
            result['both'] = content
    if selected == 'lan-serial':
        content = read_device_udp_rule_direction_lan_serial(values, join(base, 'lan-serial'), force=True)
        if content is not None:
            result['lan-serial'] = content
    if selected == 'serial-lan':
        content = read_device_udp_rule_direction_serial_lan(values, join(base, 'serial-lan'), force=True)
        if content is not None:
            result['serial-lan'] = content
    return result if result or marker is True or force else None


def write_device_udp_rule_direction(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('both', 'lan-serial', 'serial-lan') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('both', 'lan-serial', 'serial-lan') if name in raw), '')
    if isinstance(raw.get('both'), dict):
        write_device_udp_rule_direction_both(raw['both'], join(base, 'both'), result)
    if isinstance(raw.get('lan-serial'), dict):
        write_device_udp_rule_direction_lan_serial(raw['lan-serial'], join(base, 'lan-serial'), result)
    if isinstance(raw.get('serial-lan'), dict):
        write_device_udp_rule_direction_serial_lan(raw['serial-lan'], join(base, 'serial-lan'), result)
    return result


def read_device_udp_rule(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_udp_rule_address(values, join(base, 'address'), force=False)
    if content is not None:
        result['address'] = content
    content = read_device_udp_rule_direction(values, join(base, 'direction'), force=False)
    if content is not None:
        result['direction'] = content
    return result if result or marker is True or force else None


def write_device_udp_rule(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('address', 'direction') for key in raw):
        result[base] = True
    if isinstance(raw.get('address'), dict):
        write_device_udp_rule_address(raw['address'], join(base, 'address'), result)
    if isinstance(raw.get('direction'), dict):
        write_device_udp_rule_direction(raw['direction'], join(base, 'direction'), result)
    return result


def read_device_udp(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'multicast-interface', values.get(join(base, 'multicast-interface')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    entries = read_entries(values, join(base, 'rule'), 1, 10)
    if entries:
        result['rule'] = {name: read_device_udp_rule(values, join(join(base, 'rule'), name), force=True) for name in entries}
    content = read_device_login_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_udp(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('multicast-interface', 'port', 'rule', 'transmit-string') for key in raw):
        result[base] = True
    if 'multicast-interface' in raw:
        result[join(base, 'multicast-interface')] = str(raw['multicast-interface'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if isinstance(raw.get('rule'), dict):
        result[join(base, 'rule')] = list(raw['rule'])
        for name, content in raw['rule'].items():
            write_device_udp_rule(content, join(join(base, 'rule'), name), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_login_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_virtual_modem_hardware_signals(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'dcd', values.get(join(base, 'dcd')))
    copy_value(result, 'dtr', values.get(join(base, 'dtr')))
    copy_value(result, 'rts', values.get(join(base, 'rts')))
    return result if result or marker is True or force else None


def write_device_virtual_modem_hardware_signals(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('dcd', 'dtr', 'rts') for key in raw):
        result[base] = True
    if 'dcd' in raw:
        result[join(base, 'dcd')] = str(raw['dcd'])
    if 'dtr' in raw:
        result[join(base, 'dtr')] = str(raw['dtr'])
    if 'rts' in raw:
        result[join(base, 'rts')] = str(raw['rts'])
    return result


def read_device_virtual_modem_send_connect_status_verbose(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'failure-string', values.get(join(base, 'failure-string')))
    copy_value(result, 'success-string', values.get(join(base, 'success-string')))
    return result if result or marker is True or force else None


def write_device_virtual_modem_send_connect_status_verbose(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('failure-string', 'success-string') for key in raw):
        result[base] = True
    if 'failure-string' in raw:
        result[join(base, 'failure-string')] = str(raw['failure-string'])
    if 'success-string' in raw:
        result[join(base, 'success-string')] = str(raw['success-string'])
    return result


def read_device_virtual_modem_send_connect_status(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('none', 'numeric', 'verbose'))
    if selected == 'none':
        copy_value(result, 'none', values.get(join(base, 'none')))
        result.setdefault('none', True)
    if selected == 'numeric':
        copy_value(result, 'numeric', values.get(join(base, 'numeric')))
        result.setdefault('numeric', True)
    if selected == 'verbose':
        content = read_device_virtual_modem_send_connect_status_verbose(values, join(base, 'verbose'), force=True)
        if content is not None:
            result['verbose'] = content
    return result if result or marker is True or force else None


def write_device_virtual_modem_send_connect_status(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('none', 'numeric', 'verbose') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('none', 'numeric', 'verbose') if name in raw), '')
    if 'none' in raw:
        result[join(base, 'none')] = True
    if 'numeric' in raw:
        result[join(base, 'numeric')] = True
    if isinstance(raw.get('verbose'), dict):
        write_device_virtual_modem_send_connect_status_verbose(raw['verbose'], join(base, 'verbose'), result)
    return result


def read_device_virtual_modem(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_serial_tunnel_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'disable-echo', values.get(join(base, 'disable-echo')))
    content = read_device_virtual_modem_hardware_signals(values, join(base, 'hardware-signals'), force=False)
    if content is not None:
        result['hardware-signals'] = content
    copy_value(result, 'initialization-string', values.get(join(base, 'initialization-string')))
    copy_value(result, 'response-delay', values.get(join(base, 'response-delay')))
    content = read_device_virtual_modem_send_connect_status(values, join(base, 'send-connect-status'), force=False)
    if content is not None:
        result['send-connect-status'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_device_serial_tunnel_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_login_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_device_virtual_modem(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'disable-echo', 'hardware-signals', 'initialization-string', 'response-delay', 'send-connect-status', 'send-tcp-keepalive', 'server', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_serial_tunnel_client(raw['client'], join(base, 'client'), result)
    if 'disable-echo' in raw:
        result[join(base, 'disable-echo')] = True
    if isinstance(raw.get('hardware-signals'), dict):
        write_device_virtual_modem_hardware_signals(raw['hardware-signals'], join(base, 'hardware-signals'), result)
    if 'initialization-string' in raw:
        result[join(base, 'initialization-string')] = str(raw['initialization-string'])
    if 'response-delay' in raw:
        result[join(base, 'response-delay')] = str(raw['response-delay'])
    if isinstance(raw.get('send-connect-status'), dict):
        write_device_virtual_modem_send_connect_status(raw['send-connect-status'], join(base, 'send-connect-status'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_device_serial_tunnel_server(raw['server'], join(base, 'server'), result)
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_login_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_device_packet_forwarding_prevent_message_fragmentation(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'delay-between-messages', values.get(join(base, 'delay-between-messages')))
    return result if result or marker is True or force else None


def write_device_packet_forwarding_prevent_message_fragmentation(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('delay-between-messages',) for key in raw):
        result[base] = True
    if 'delay-between-messages' in raw:
        result[join(base, 'delay-between-messages')] = str(raw['delay-between-messages'])
    return result


def read_device_packet_forwarding_custom_frame(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'end-value1', values.get(join(base, 'end-value1')))
    copy_value(result, 'end-value2', values.get(join(base, 'end-value2')))
    copy_value(result, 'start-value1', values.get(join(base, 'start-value1')))
    copy_value(result, 'start-value2', values.get(join(base, 'start-value2')))
    copy_value(result, 'transmit-start-characters', values.get(join(base, 'transmit-start-characters')))
    return result if result or marker is True or force else None


def write_device_packet_forwarding_custom_frame(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('end-value1', 'end-value2', 'start-value1', 'start-value2', 'transmit-start-characters') for key in raw):
        result[base] = True
    if 'end-value1' in raw:
        result[join(base, 'end-value1')] = str(raw['end-value1'])
    if 'end-value2' in raw:
        result[join(base, 'end-value2')] = str(raw['end-value2'])
    if 'start-value1' in raw:
        result[join(base, 'start-value1')] = str(raw['start-value1'])
    if 'start-value2' in raw:
        result[join(base, 'start-value2')] = str(raw['start-value2'])
    if 'transmit-start-characters' in raw:
        result[join(base, 'transmit-start-characters')] = True
    return result


def read_device_packet_forwarding_custom_packet(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'force-transmit-timer', values.get(join(base, 'force-transmit-timer')))
    copy_value(result, 'idle-timer', values.get(join(base, 'idle-timer')))
    copy_value(result, 'packet-size', values.get(join(base, 'packet-size')))
    copy_value(result, 'trigger-value1', values.get(join(base, 'trigger-value1')))
    copy_value(result, 'trigger-value2', values.get(join(base, 'trigger-value2')))
    return result if result or marker is True or force else None


def write_device_packet_forwarding_custom_packet(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('force-transmit-timer', 'idle-timer', 'packet-size', 'trigger-value1', 'trigger-value2') for key in raw):
        result[base] = True
    if 'force-transmit-timer' in raw:
        result[join(base, 'force-transmit-timer')] = str(raw['force-transmit-timer'])
    if 'idle-timer' in raw:
        result[join(base, 'idle-timer')] = str(raw['idle-timer'])
    if 'packet-size' in raw:
        result[join(base, 'packet-size')] = str(raw['packet-size'])
    if 'trigger-value1' in raw:
        result[join(base, 'trigger-value1')] = str(raw['trigger-value1'])
    if 'trigger-value2' in raw:
        result[join(base, 'trigger-value2')] = str(raw['trigger-value2'])
    return result


def read_device_packet_forwarding_custom(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_packet_forwarding_custom_frame(values, join(base, 'frame'), force=False)
    if content is not None:
        result['frame'] = content
    content = read_device_packet_forwarding_custom_packet(values, join(base, 'packet'), force=False)
    if content is not None:
        result['packet'] = content
    copy_value(result, 'forwarding-rule', values.get(join(base, 'forwarding-rule')))
    return result if result or marker is True or force else None


def write_device_packet_forwarding_custom(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('frame', 'packet', 'forwarding-rule') for key in raw):
        result[base] = True
    if isinstance(raw.get('frame'), dict):
        write_device_packet_forwarding_custom_frame(raw['frame'], join(base, 'frame'), result)
    if isinstance(raw.get('packet'), dict):
        write_device_packet_forwarding_custom_packet(raw['packet'], join(base, 'packet'), result)
    if 'forwarding-rule' in raw:
        result[join(base, 'forwarding-rule')] = str(raw['forwarding-rule'])
    return result


def read_device_packet_forwarding(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('minimize-latency', 'optimize-network-throughput', 'prevent-message-fragmentation', 'custom'))
    if selected == 'minimize-latency':
        copy_value(result, 'minimize-latency', values.get(join(base, 'minimize-latency')))
        result.setdefault('minimize-latency', True)
    if selected == 'optimize-network-throughput':
        copy_value(result, 'optimize-network-throughput', values.get(join(base, 'optimize-network-throughput')))
        result.setdefault('optimize-network-throughput', True)
    if selected == 'prevent-message-fragmentation':
        content = read_device_packet_forwarding_prevent_message_fragmentation(values, join(base, 'prevent-message-fragmentation'), force=True)
        if content is not None:
            result['prevent-message-fragmentation'] = content
    if selected == 'custom':
        content = read_device_packet_forwarding_custom(values, join(base, 'custom'), force=True)
        if content is not None:
            result['custom'] = content
    return result if result or marker is True or force else None


def write_device_packet_forwarding(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('minimize-latency', 'optimize-network-throughput', 'prevent-message-fragmentation', 'custom') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('minimize-latency', 'optimize-network-throughput', 'prevent-message-fragmentation', 'custom') if name in raw), '')
    if 'minimize-latency' in raw:
        result[join(base, 'minimize-latency')] = True
    if 'optimize-network-throughput' in raw:
        result[join(base, 'optimize-network-throughput')] = True
    if isinstance(raw.get('prevent-message-fragmentation'), dict):
        write_device_packet_forwarding_prevent_message_fragmentation(raw['prevent-message-fragmentation'], join(base, 'prevent-message-fragmentation'), result)
    if isinstance(raw.get('custom'), dict):
        write_device_packet_forwarding_custom(raw['custom'], join(base, 'custom'), result)
    return result


def read_device(values, base="", force=False):
    validate_page_values(values)
    result = {}
    if not isinstance(values, dict):
        raise ValueError('Serial settings must be an object')
    transport = read_transport(values)
    copy_value(result, 'disable', values.get(join(base, 'disable')))
    copy_value(result, 'description', values.get(join(base, 'description')))
    copy_value(result, 'profile', values.get(join(base, 'profile')))
    content = read_device_protocol(values, join(base, 'protocol'), force=False)
    if content is not None:
        result['protocol'] = content
    copy_value(result, 'speed', values.get(join(base, 'speed')))
    copy_value(result, 'data-bits', values.get(join(base, 'data-bits')))
    copy_value(result, 'parity', values.get(join(base, 'parity')))
    copy_value(result, 'stop-bits', values.get(join(base, 'stop-bits')))
    copy_value(result, 'discard-chars-rxd-with-errors', values.get(join(base, 'discard-chars-rxd-with-errors')))
    if transport == 'login':
        content = read_device_login(values, join(base, 'login'), force=True)
        if content is not None:
            result['login'] = content
    if transport == 'modbus-gateway':
        content = read_device_modbus_gateway(values, join(base, 'modbus-gateway'), force=True)
        if content is not None:
            result['modbus-gateway'] = content
    if transport == 'nine-bits':
        content = read_device_nine_bits(values, join(base, 'nine-bits'), force=True)
        if content is not None:
            result['nine-bits'] = content
    if transport == 'ppp':
        content = read_device_ppp(values, join(base, 'ppp'), force=True)
        if content is not None:
            result['ppp'] = content
    if transport == 'remote-printer':
        content = read_device_remote_printer(values, join(base, 'remote-printer'), force=True)
        if content is not None:
            result['remote-printer'] = content
    if transport == 'serial-tunnel':
        content = read_device_serial_tunnel(values, join(base, 'serial-tunnel'), force=True)
        if content is not None:
            result['serial-tunnel'] = content
    if transport == 'slip':
        content = read_device_slip(values, join(base, 'slip'), force=True)
        if content is not None:
            result['slip'] = content
    if transport == 'ssh':
        content = read_device_ssh(values, join(base, 'ssh'), force=True)
        if content is not None:
            result['ssh'] = content
    if transport == 'tcp':
        content = read_device_tcp(values, join(base, 'tcp'), force=True)
        if content is not None:
            result['tcp'] = content
    if transport == 'telnet':
        content = read_device_telnet(values, join(base, 'telnet'), force=True)
        if content is not None:
            result['telnet'] = content
    if transport == 'trueport':
        content = read_device_trueport(values, join(base, 'trueport'), force=True)
        if content is not None:
            result['trueport'] = content
    if transport == 'udp':
        content = read_device_udp(values, join(base, 'udp'), force=True)
        if content is not None:
            result['udp'] = content
    if transport == 'virtual-modem':
        content = read_device_virtual_modem(values, join(base, 'virtual-modem'), force=True)
        if content is not None:
            result['virtual-modem'] = content
    content = read_device_packet_forwarding(values, join(base, 'packet-forwarding'), force=False)
    if content is not None:
        result['packet-forwarding'] = content
    return result


def write_device(raw, base="", result=None):
    result = {} if result is None else result
    result['$transport'] = next((name for name in SERIAL_TRANSPORTS if name in raw), '')
    if 'disable' in raw:
        result[join(base, 'disable')] = True
    if 'description' in raw:
        result[join(base, 'description')] = str(raw['description'])
    if 'profile' in raw:
        result[join(base, 'profile')] = str(raw['profile'])
    if isinstance(raw.get('protocol'), dict):
        write_device_protocol(raw['protocol'], join(base, 'protocol'), result)
    if 'speed' in raw:
        result[join(base, 'speed')] = str(raw['speed'])
    if 'data-bits' in raw:
        result[join(base, 'data-bits')] = str(raw['data-bits'])
    if 'parity' in raw:
        result[join(base, 'parity')] = str(raw['parity'])
    if 'stop-bits' in raw:
        result[join(base, 'stop-bits')] = str(raw['stop-bits'])
    if 'discard-chars-rxd-with-errors' in raw:
        result[join(base, 'discard-chars-rxd-with-errors')] = True
    if isinstance(raw.get('login'), dict):
        write_device_login(raw['login'], join(base, 'login'), result)
    if isinstance(raw.get('modbus-gateway'), dict):
        write_device_modbus_gateway(raw['modbus-gateway'], join(base, 'modbus-gateway'), result)
    if isinstance(raw.get('nine-bits'), dict):
        write_device_nine_bits(raw['nine-bits'], join(base, 'nine-bits'), result)
    if isinstance(raw.get('ppp'), dict):
        write_device_ppp(raw['ppp'], join(base, 'ppp'), result)
    if isinstance(raw.get('remote-printer'), dict):
        write_device_remote_printer(raw['remote-printer'], join(base, 'remote-printer'), result)
    if isinstance(raw.get('serial-tunnel'), dict):
        write_device_serial_tunnel(raw['serial-tunnel'], join(base, 'serial-tunnel'), result)
    if isinstance(raw.get('slip'), dict):
        write_device_slip(raw['slip'], join(base, 'slip'), result)
    if isinstance(raw.get('ssh'), dict):
        write_device_ssh(raw['ssh'], join(base, 'ssh'), result)
    if isinstance(raw.get('tcp'), dict):
        write_device_tcp(raw['tcp'], join(base, 'tcp'), result)
    if isinstance(raw.get('telnet'), dict):
        write_device_telnet(raw['telnet'], join(base, 'telnet'), result)
    if isinstance(raw.get('trueport'), dict):
        write_device_trueport(raw['trueport'], join(base, 'trueport'), result)
    if isinstance(raw.get('udp'), dict):
        write_device_udp(raw['udp'], join(base, 'udp'), result)
    if isinstance(raw.get('virtual-modem'), dict):
        write_device_virtual_modem(raw['virtual-modem'], join(base, 'virtual-modem'), result)
    if isinstance(raw.get('packet-forwarding'), dict):
        write_device_packet_forwarding(raw['packet-forwarding'], join(base, 'packet-forwarding'), result)
    return result


def read_profile_modbus_gateway(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_modbus_gateway_master(values, join(base, 'master'), force=False)
    if content is not None:
        result['master'] = content
    content = read_device_modbus_gateway_protocol(values, join(base, 'protocol'), force=False)
    if content is not None:
        result['protocol'] = content
    return result if result or marker is True or force else None


def write_profile_modbus_gateway(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('master', 'protocol') for key in raw):
        result[base] = True
    if isinstance(raw.get('master'), dict):
        write_device_modbus_gateway_master(raw['master'], join(base, 'master'), result)
    if isinstance(raw.get('protocol'), dict):
        write_device_modbus_gateway_protocol(raw['protocol'], join(base, 'protocol'), result)
    return result


def read_profile_serial_tunnel(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'break-length', values.get(join(base, 'break-length')))
    content = read_device_serial_tunnel_client(values, join(base, 'client'), force=False)
    if content is not None:
        result['client'] = content
    copy_value(result, 'delay-after-break', values.get(join(base, 'delay-after-break')))
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    return result if result or marker is True or force else None


def write_profile_serial_tunnel(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('break-length', 'client', 'delay-after-break', 'send-tcp-keepalive', 'tls') for key in raw):
        result[base] = True
    if 'break-length' in raw:
        result[join(base, 'break-length')] = str(raw['break-length'])
    if isinstance(raw.get('client'), dict):
        write_device_serial_tunnel_client(raw['client'], join(base, 'client'), result)
    if 'delay-after-break' in raw:
        result[join(base, 'delay-after-break')] = str(raw['delay-after-break'])
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    return result


def read_profile_ssh_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'multi-session-limit', values.get(join(base, 'multi-session-limit')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_profile_ssh_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('multi-session-limit', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'multi-session-limit' in raw:
        result[join(base, 'multi-session-limit')] = str(raw['multi-session-limit'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_profile_ssh(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_ssh_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_profile_ssh_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_profile_ssh(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'server', 'session-timeout', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_ssh_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_profile_ssh_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_profile_tcp_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'allow-multiple-connections', values.get(join(base, 'allow-multiple-connections')))
    copy_value(result, 'authenticate-user', values.get(join(base, 'authenticate-user')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_profile_tcp_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('allow-multiple-connections', 'authenticate-user', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'allow-multiple-connections' in raw:
        result[join(base, 'allow-multiple-connections')] = True
    if 'authenticate-user' in raw:
        result[join(base, 'authenticate-user')] = True
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_profile_tcp(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_tcp_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    copy_value(result, 'serial-buffering', values.get(join(base, 'serial-buffering')))
    if selected == 'server':
        content = read_profile_tcp_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_profile_tcp(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'serial-buffering', 'server', 'session-timeout', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_tcp_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if 'serial-buffering' in raw:
        result[join(base, 'serial-buffering')] = True
    if isinstance(raw.get('server'), dict):
        write_profile_tcp_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_profile_telnet_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'authenticate-user', values.get(join(base, 'authenticate-user')))
    copy_value(result, 'multi-session-limit', values.get(join(base, 'multi-session-limit')))
    copy_value(result, 'port', values.get(join(base, 'port')))
    copy_value(result, 'post-login-banner', values.get(join(base, 'post-login-banner')))
    copy_value(result, 'pre-login-banner', values.get(join(base, 'pre-login-banner')))
    return result if result or marker is True or force else None


def write_profile_telnet_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('authenticate-user', 'multi-session-limit', 'port', 'post-login-banner', 'pre-login-banner') for key in raw):
        result[base] = True
    if 'authenticate-user' in raw:
        result[join(base, 'authenticate-user')] = True
    if 'multi-session-limit' in raw:
        result[join(base, 'multi-session-limit')] = str(raw['multi-session-limit'])
    if 'port' in raw:
        result[join(base, 'port')] = str(raw['port'])
    if 'post-login-banner' in raw:
        result[join(base, 'post-login-banner')] = True
    if 'pre-login-banner' in raw:
        result[join(base, 'pre-login-banner')] = True
    return result


def read_profile_telnet(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_telnet_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    content = read_device_login_modem(values, join(base, 'modem'), force=False)
    if content is not None:
        result['modem'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    if selected == 'server':
        content = read_profile_telnet_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_profile_telnet(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'modem', 'send-tcp-keepalive', 'server', 'session-timeout', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_telnet_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if isinstance(raw.get('modem'), dict):
        write_device_login_modem(raw['modem'], join(base, 'modem'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('server'), dict):
        write_profile_telnet_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_profile_trueport_server(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    copy_value(result, 'allow-multiple-connections', values.get(join(base, 'allow-multiple-connections')))
    return result if result or marker is True or force else None


def write_profile_trueport_server(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('allow-multiple-connections',) for key in raw):
        result[base] = True
    if 'allow-multiple-connections' in raw:
        result[join(base, 'allow-multiple-connections')] = True
    return result


def read_profile_trueport(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    selected = read_choice(values, base, ('client', 'server'))
    if selected == 'client':
        content = read_device_trueport_client(values, join(base, 'client'), force=True)
        if content is not None:
            result['client'] = content
    copy_value(result, 'idle-timeout', values.get(join(base, 'idle-timeout')))
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    copy_value(result, 'serial-buffering', values.get(join(base, 'serial-buffering')))
    if selected == 'server':
        content = read_profile_trueport_server(values, join(base, 'server'), force=True)
        if content is not None:
            result['server'] = content
    copy_value(result, 'session-timeout', values.get(join(base, 'session-timeout')))
    copy_value(result, 'signal-active', values.get(join(base, 'signal-active')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_ssh_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_profile_trueport(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'idle-timeout', 'send-tcp-keepalive', 'serial-buffering', 'server', 'session-timeout', 'signal-active', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    result[f'{base}/$choice'] = next((name for name in ('client', 'server') if name in raw), '')
    if isinstance(raw.get('client'), dict):
        write_device_trueport_client(raw['client'], join(base, 'client'), result)
    if 'idle-timeout' in raw:
        result[join(base, 'idle-timeout')] = str(raw['idle-timeout'])
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if 'serial-buffering' in raw:
        result[join(base, 'serial-buffering')] = True
    if isinstance(raw.get('server'), dict):
        write_profile_trueport_server(raw['server'], join(base, 'server'), result)
    if 'session-timeout' in raw:
        result[join(base, 'session-timeout')] = str(raw['session-timeout'])
    if 'signal-active' in raw:
        result[join(base, 'signal-active')] = True
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_ssh_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_profile_virtual_modem(values, base="", force=False):
    result = {}
    marker = read_marker(values, base)
    content = read_device_serial_tunnel_client(values, join(base, 'client'), force=False)
    if content is not None:
        result['client'] = content
    copy_value(result, 'disable-echo', values.get(join(base, 'disable-echo')))
    content = read_device_virtual_modem_hardware_signals(values, join(base, 'hardware-signals'), force=False)
    if content is not None:
        result['hardware-signals'] = content
    copy_value(result, 'initialization-string', values.get(join(base, 'initialization-string')))
    copy_value(result, 'response-delay', values.get(join(base, 'response-delay')))
    content = read_device_virtual_modem_send_connect_status(values, join(base, 'send-connect-status'), force=False)
    if content is not None:
        result['send-connect-status'] = content
    copy_value(result, 'send-tcp-keepalive', values.get(join(base, 'send-tcp-keepalive')))
    content = read_global_modbus_gateway_tls(values, join(base, 'tls'), force=False)
    if content is not None:
        result['tls'] = content
    content = read_device_login_transmit_string(values, join(base, 'transmit-string'), force=False)
    if content is not None:
        result['transmit-string'] = content
    return result if result or marker is True or force else None


def write_profile_virtual_modem(raw, base="", result=None):
    result = {} if result is None else result
    if not raw or any(key not in ('client', 'disable-echo', 'hardware-signals', 'initialization-string', 'response-delay', 'send-connect-status', 'send-tcp-keepalive', 'tls', 'transmit-string') for key in raw):
        result[base] = True
    if isinstance(raw.get('client'), dict):
        write_device_serial_tunnel_client(raw['client'], join(base, 'client'), result)
    if 'disable-echo' in raw:
        result[join(base, 'disable-echo')] = True
    if isinstance(raw.get('hardware-signals'), dict):
        write_device_virtual_modem_hardware_signals(raw['hardware-signals'], join(base, 'hardware-signals'), result)
    if 'initialization-string' in raw:
        result[join(base, 'initialization-string')] = str(raw['initialization-string'])
    if 'response-delay' in raw:
        result[join(base, 'response-delay')] = str(raw['response-delay'])
    if isinstance(raw.get('send-connect-status'), dict):
        write_device_virtual_modem_send_connect_status(raw['send-connect-status'], join(base, 'send-connect-status'), result)
    if 'send-tcp-keepalive' in raw:
        result[join(base, 'send-tcp-keepalive')] = True
    if isinstance(raw.get('tls'), dict):
        write_global_modbus_gateway_tls(raw['tls'], join(base, 'tls'), result)
    if isinstance(raw.get('transmit-string'), dict):
        write_device_login_transmit_string(raw['transmit-string'], join(base, 'transmit-string'), result)
    return result


def read_profile(values, base="", force=False):
    validate_page_values(values)
    result = {}
    if not isinstance(values, dict):
        raise ValueError('Serial settings must be an object')
    transport = read_transport(values)
    content = read_device_protocol(values, join(base, 'protocol'), force=False)
    if content is not None:
        result['protocol'] = content
    copy_value(result, 'speed', values.get(join(base, 'speed')))
    copy_value(result, 'data-bits', values.get(join(base, 'data-bits')))
    copy_value(result, 'parity', values.get(join(base, 'parity')))
    copy_value(result, 'stop-bits', values.get(join(base, 'stop-bits')))
    copy_value(result, 'discard-chars-rxd-with-errors', values.get(join(base, 'discard-chars-rxd-with-errors')))
    if transport == 'login':
        content = read_device_login(values, join(base, 'login'), force=True)
        if content is not None:
            result['login'] = content
    if transport == 'modbus-gateway':
        content = read_profile_modbus_gateway(values, join(base, 'modbus-gateway'), force=True)
        if content is not None:
            result['modbus-gateway'] = content
    if transport == 'nine-bits':
        content = read_device_nine_bits(values, join(base, 'nine-bits'), force=True)
        if content is not None:
            result['nine-bits'] = content
    if transport == 'ppp':
        content = read_device_ppp(values, join(base, 'ppp'), force=True)
        if content is not None:
            result['ppp'] = content
    if transport == 'remote-printer':
        content = read_device_remote_printer(values, join(base, 'remote-printer'), force=True)
        if content is not None:
            result['remote-printer'] = content
    if transport == 'serial-tunnel':
        content = read_profile_serial_tunnel(values, join(base, 'serial-tunnel'), force=True)
        if content is not None:
            result['serial-tunnel'] = content
    if transport == 'slip':
        content = read_device_slip(values, join(base, 'slip'), force=True)
        if content is not None:
            result['slip'] = content
    if transport == 'ssh':
        content = read_profile_ssh(values, join(base, 'ssh'), force=True)
        if content is not None:
            result['ssh'] = content
    if transport == 'tcp':
        content = read_profile_tcp(values, join(base, 'tcp'), force=True)
        if content is not None:
            result['tcp'] = content
    if transport == 'telnet':
        content = read_profile_telnet(values, join(base, 'telnet'), force=True)
        if content is not None:
            result['telnet'] = content
    if transport == 'trueport':
        content = read_profile_trueport(values, join(base, 'trueport'), force=True)
        if content is not None:
            result['trueport'] = content
    if transport == 'udp':
        content = read_device_udp(values, join(base, 'udp'), force=True)
        if content is not None:
            result['udp'] = content
    if transport == 'virtual-modem':
        content = read_profile_virtual_modem(values, join(base, 'virtual-modem'), force=True)
        if content is not None:
            result['virtual-modem'] = content
    content = read_device_packet_forwarding(values, join(base, 'packet-forwarding'), force=False)
    if content is not None:
        result['packet-forwarding'] = content
    return result


def write_profile(raw, base="", result=None):
    result = {} if result is None else result
    result['$transport'] = next((name for name in SERIAL_TRANSPORTS if name in raw), '')
    if isinstance(raw.get('protocol'), dict):
        write_device_protocol(raw['protocol'], join(base, 'protocol'), result)
    if 'speed' in raw:
        result[join(base, 'speed')] = str(raw['speed'])
    if 'data-bits' in raw:
        result[join(base, 'data-bits')] = str(raw['data-bits'])
    if 'parity' in raw:
        result[join(base, 'parity')] = str(raw['parity'])
    if 'stop-bits' in raw:
        result[join(base, 'stop-bits')] = str(raw['stop-bits'])
    if 'discard-chars-rxd-with-errors' in raw:
        result[join(base, 'discard-chars-rxd-with-errors')] = True
    if isinstance(raw.get('login'), dict):
        write_device_login(raw['login'], join(base, 'login'), result)
    if isinstance(raw.get('modbus-gateway'), dict):
        write_profile_modbus_gateway(raw['modbus-gateway'], join(base, 'modbus-gateway'), result)
    if isinstance(raw.get('nine-bits'), dict):
        write_device_nine_bits(raw['nine-bits'], join(base, 'nine-bits'), result)
    if isinstance(raw.get('ppp'), dict):
        write_device_ppp(raw['ppp'], join(base, 'ppp'), result)
    if isinstance(raw.get('remote-printer'), dict):
        write_device_remote_printer(raw['remote-printer'], join(base, 'remote-printer'), result)
    if isinstance(raw.get('serial-tunnel'), dict):
        write_profile_serial_tunnel(raw['serial-tunnel'], join(base, 'serial-tunnel'), result)
    if isinstance(raw.get('slip'), dict):
        write_device_slip(raw['slip'], join(base, 'slip'), result)
    if isinstance(raw.get('ssh'), dict):
        write_profile_ssh(raw['ssh'], join(base, 'ssh'), result)
    if isinstance(raw.get('tcp'), dict):
        write_profile_tcp(raw['tcp'], join(base, 'tcp'), result)
    if isinstance(raw.get('telnet'), dict):
        write_profile_telnet(raw['telnet'], join(base, 'telnet'), result)
    if isinstance(raw.get('trueport'), dict):
        write_profile_trueport(raw['trueport'], join(base, 'trueport'), result)
    if isinstance(raw.get('udp'), dict):
        write_device_udp(raw['udp'], join(base, 'udp'), result)
    if isinstance(raw.get('virtual-modem'), dict):
        write_profile_virtual_modem(raw['virtual-modem'], join(base, 'virtual-modem'), result)
    if isinstance(raw.get('packet-forwarding'), dict):
        write_device_packet_forwarding(raw['packet-forwarding'], join(base, 'packet-forwarding'), result)
    return result
