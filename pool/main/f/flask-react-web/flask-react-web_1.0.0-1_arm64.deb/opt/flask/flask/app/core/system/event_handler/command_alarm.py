from typing import Any, Dict, List, Optional
import json

from app.core.api.http.cmd.command import Command


def is_str_not_empty(value: Any) -> bool:
    return str(value) not in ['', 'None']


def _is_empty_dict(value: Any) -> bool:
    return isinstance(value, dict) and len(value) == 0


class AlarmCommand(Command):
    """Command class for service event-handler commands.

    Supported commands (set/delete):

    - set/delete service event-handler event <event-name> filter pattern <text>
    - set/delete service event-handler event <event-name> filter syslog-identifier <syslog-id>
    - set/delete service event-handler event <event-name> script path <path-to-the-script>
    - set/delete service event-handler event <event-name> script environment <env-var-name> value <value-in-text>
    """

    ENVIRONMENT_VARIABLE_ALIASES = {
        'event name': 'event_name',
        'event_name': 'event_name',
        'description': 'description',
        'gui_level': 'gui_level',
        'sms_number': 'sms_number',
    }

    def __init__(self, operator: str = 'set', config: Optional[dict] = None, resource: str = 'event-handler'):
        super().__init__(operator=operator, resource=resource)
        self.config = config or {}
        self.cmds: List[str] = []
        self.vyos_cmds: List[str] = []

    def _build_command(self, *path_elements: str) -> str:
        command = {
            "op": self.operator,
            "path": list(path_elements)
        }
        return json.dumps(command)

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _normalize_environment_variable_name(self, env_name: Any) -> str:
        normalized_name = str(env_name or '').strip()
        if normalized_name == '':
            return ''
        return self.ENVIRONMENT_VARIABLE_ALIASES.get(normalized_name, normalized_name)

    def generate_commands(self, data: Optional[Dict[str, Any]] = None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            alarm_cfg = data
            if isinstance(alarm_cfg, dict) and 'service' in alarm_cfg and isinstance(alarm_cfg.get('service'), dict):
                alarm_cfg = alarm_cfg['service'].get('event-handler', {})
            if isinstance(alarm_cfg, dict) and 'event-handler' in alarm_cfg and isinstance(alarm_cfg.get('event-handler'), dict):
                alarm_cfg = alarm_cfg.get('event-handler')

            if not isinstance(alarm_cfg, dict):
                return []

            event_cfg = alarm_cfg.get('event', alarm_cfg)
            if isinstance(event_cfg, dict):
                self._process_event_config(event_cfg, new_config or {})

            return self.cmds
        except Exception as e:
            print(f"Error generating Alarm commands: {e}")
            return []

    def _process_event_config(self, event_cfg: Dict[str, Any], new_config: Dict[str, Any]):
        normalized_new_config = new_config
        if isinstance(normalized_new_config, dict) and 'service' in normalized_new_config and isinstance(normalized_new_config.get('service'), dict):
            normalized_new_config = normalized_new_config['service'].get('event-handler', {})
        if isinstance(normalized_new_config, dict) and 'event-handler' in normalized_new_config and isinstance(normalized_new_config.get('event-handler'), dict):
            normalized_new_config = normalized_new_config.get('event-handler')
        if isinstance(normalized_new_config, dict):
            normalized_new_config = normalized_new_config.get('event', normalized_new_config)
        else:
            normalized_new_config = {}

        for event_name, event_data in event_cfg.items():
            base_path = ['service', 'event-handler', 'event', str(event_name)]

            if not event_data or _is_empty_dict(event_data):
                self.generate(*base_path)
                continue

            if self.operator == 'delete' and event_name not in normalized_new_config:
                self.generate(*base_path)
                continue

            if not isinstance(event_data, dict):
                continue

            if 'filter' in event_data:
                self._process_filter_config(base_path, event_data.get('filter'))

            if 'script' in event_data:
                self._process_script_config(base_path, event_data.get('script'))

    def _process_filter_config(self, base_path: List[str], filter_cfg: Any):
        if filter_cfg is None or not isinstance(filter_cfg, dict):
            return

        filter_path = base_path + ['filter']

        if 'pattern' in filter_cfg:
            if self.operator == 'delete':
                self.generate(*(filter_path + ['pattern']))
            else:
                pattern = filter_cfg.get('pattern')
                if is_str_not_empty(pattern):
                    self.generate(*(filter_path + ['pattern', str(pattern)]))

        if 'syslog-identifier' in filter_cfg:
            if self.operator == 'delete':
                self.generate(*(filter_path + ['syslog-identifier']))
            else:
                syslog_identifier = filter_cfg.get('syslog-identifier')
                if is_str_not_empty(syslog_identifier):
                    self.generate(*(filter_path + ['syslog-identifier', str(syslog_identifier)]))

    def _process_script_config(self, base_path: List[str], script_cfg: Any):
        if script_cfg is None or not isinstance(script_cfg, dict):
            return

        script_path = base_path + ['script']

        if 'path' in script_cfg:
            if self.operator == 'delete':
                self.generate(*(script_path + ['path']))
            else:
                script_value = script_cfg.get('path')
                if is_str_not_empty(script_value):
                    self.generate(*(script_path + ['path', str(script_value)]))

        environment_cfg = script_cfg.get('environment')
        if environment_cfg is None or not isinstance(environment_cfg, dict):
            return

        for env_name, env_value in environment_cfg.items():
            normalized_env_name = self._normalize_environment_variable_name(env_name)
            if normalized_env_name == '':
                continue

            env_path = script_path + ['environment', normalized_env_name]

            if self.operator == 'delete':
                if env_value is None or _is_empty_dict(env_value) or env_value == '':
                    self.generate(*env_path)
                else:
                    self.generate(*(env_path + ['value']))
                continue

            if isinstance(env_value, dict):
                value = env_value.get('value')
            else:
                value = env_value

            if is_str_not_empty(value):
                self.generate(*(env_path + ['value', str(value)]))