import json
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from uuid import uuid4
 
from pydantic import BaseModel
 
from app.config.models import EventHandlerFilePath
from app.db.database import db
from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import relationship
 
 
class AlarmEnvironmentVariableDTO(BaseModel):
    name: str = ''
    value: Optional[str] = ''
 
 
class AlarmEventDTO(BaseModel):
    eventNameId: str = ''
    eventName: Optional[str] = ''
    description: Optional[str] = ''
    guiLevel: Optional[str] = ''
    smsNumber: Optional[str] = ''
    eventType: Optional[str] = 'custom'
    filterPattern: Optional[str] = ''
    syslogIdentifier: Optional[str] = ''
    interfaceName: Optional[str] = ''
    serviceName: Optional[str] = ''
    vrrpGroupName: Optional[str] = ''
    guiNotification: bool = False
    sms: bool = False
    email: bool = False


class UpdateAlarmDTO(BaseModel):
    events: List[AlarmEventDTO] = []


class VerifyAlarmDTO(UpdateAlarmDTO):
    pass


def empty_alarm_frontend():
    return {
        'events': []
    }


def serialize_alarm_actions(actions: Any) -> Dict[str, bool]:
    action_data = actions if isinstance(actions, dict) else {}
    return {
        'guiNotification': bool(action_data.get('gui-notification', False)),
        'sms': bool(action_data.get('sms', False)),
        'email': bool(action_data.get('email', False)),
    }


SERVICE_OPTIONS = [
    {'value': 'DHCP', 'label': 'DHCP', 'description': 'Kea DHCPv4 Service'},
    {'value': 'DHCPv6', 'label': 'DHCPv6', 'description': 'Kea DHCPv6 Service'},
    {'value': 'IPSec', 'label': 'IPSec', 'description': 'strongSwan IPsec IKEv1/IKEv2 daemon using swanctl'},
    {'value': 'Router Advertisement', 'label': 'Router Advertisement', 'description': 'Router advertisement daemon for IPv6'},
    {'value': 'SNMP', 'label': 'SNMP', 'description': 'Simple Network Management Protocol (SNMP) Daemon'},
    {'value': 'SSH', 'label': 'SSH', 'description': 'OpenBSD Secure Shell server'},
    {'value': 'VRRP', 'label': 'VRRP', 'description': 'Keepalive Daemon (LVS and VRRP)'},
]


EVENT_NAME_ENVIRONMENT_VARIABLES = ['event_name', 'event name']
DESCRIPTION_ENVIRONMENT_VARIABLE = 'description'
GUI_LEVEL_ENVIRONMENT_VARIABLE = 'gui_level'
SMS_NUMBER_ENVIRONMENT_VARIABLE = 'sms_number'
EMAIL_ENABLED_ENVIRONMENT_VARIABLE = 'email_enabled'


def get_alarm_script_actions(script_path: Any, environment_data: Any = None) -> Dict[str, bool]:
    normalized_script_path = str(script_path or '').strip()
    gui_path = EventHandlerFilePath.get_event_handler_script_path('event_gui_notification')
    sms_path = EventHandlerFilePath.get_event_handler_script_path('event_sms_notification')

    gui_notification = normalized_script_path != '' and normalized_script_path == gui_path and gui_path != ''
    sms = normalized_script_path != '' and normalized_script_path == sms_path and sms_path != ''
    email = get_environment_value(environment_data, EMAIL_ENABLED_ENVIRONMENT_VARIABLE).strip().lower() in (
        '1', 'true', 'yes', 'on',
    )

    return {
        'guiNotification': gui_notification,
        'sms': sms,
        'email': email,
    }


def infer_alarm_event_type_from_details(event_name: Any, syslog_identifier: Any, filter_pattern: Any) -> str:
    normalized_syslog_identifier = str(syslog_identifier or '').strip().lower()
    normalized_filter_pattern = str(filter_pattern or '').strip()
    normalized_filter_pattern_lower = normalized_filter_pattern.lower()

    if normalized_filter_pattern == '.*pam_unix\\(([^c]|c[^r]|cr[^o]|cro[^n]).*:session\\): session opened.*':
        return 'login_success'

    if normalized_filter_pattern == '.*pam_unix\\(([^c]|c[^r]|cr[^o]|cro[^n]).*:auth\\): authentication failure;.*':
        return 'login_failed'

    if normalized_syslog_identifier == 'vyos-netlinkd':
        if 'RTM_NEWLINK.*<intf-name>,.*state=DOWN.*' in normalized_filter_pattern_lower:
            return 'interface_down'
        if 'RTM_NEWLINK.*<intf-name>,.*state=UP.*' in normalized_filter_pattern_lower:
            return 'interface_up'

    if normalized_syslog_identifier == 'systemd':
        if normalized_filter_pattern.startswith('.*Started '):
            description = normalized_filter_pattern[len('.*Started '):].strip()
            if description.endswith('.*'):
                description = description[:-len('.*')].strip()
            if any(option['description'] == description for option in SERVICE_OPTIONS):
                return 'service_up'
        if normalized_filter_pattern.startswith('.*Stopped '):
            description = normalized_filter_pattern[len('.*Stopped '):].strip()
            if description.endswith('.*'):
                description = description[:-len('.*')].strip()
            if any(option['description'] == description for option in SERVICE_OPTIONS):
                return 'service_down'

    if normalized_syslog_identifier == 'keepalived-fifo.py':
        if normalized_filter_pattern.startswith('.*INSTANCE ') and ' changed state to ' in normalized_filter_pattern:
            return 'vrrp_status'

    return infer_alarm_event_type(event_name)


def infer_alarm_event_type(event_name: Any) -> str:
    name = str(event_name or '').strip().lower()
    if name.startswith('interface_up_'):
        return 'interface_up'
    if name.startswith('interface_down_'):
        return 'interface_down'
    if name.startswith('service_up_'):
        return 'service_up'
    if name.startswith('service_down_'):
        return 'service_down'
    if name.startswith('login_success_'):
        return 'login_success'
    if name.startswith('login_failed_'):
        return 'login_failed'
    if name.startswith('vrrp_status_'):
        return 'vrrp_status'
    return 'custom'


def extract_interface_name_from_pattern(event_type: Any, filter_pattern: Any) -> str:
    if str(event_type or '').strip() not in ['interface_up', 'interface_down']:
        return ''

    normalized_filter_pattern = str(filter_pattern or '').strip()
    match = normalized_filter_pattern.find(':')
    if not normalized_filter_pattern.startswith('.*') or match == -1:
        return ''

    interface_name = normalized_filter_pattern[2:match].strip()
    if interface_name in ['', '<intf-name>']:
        return ''

    return interface_name


def extract_service_name_from_pattern(event_type: Any, filter_pattern: Any) -> str:
    normalized_event_type = str(event_type or '').strip()
    if normalized_event_type not in ['service_up', 'service_down']:
        return ''

    normalized_filter_pattern = str(filter_pattern or '').strip()
    prefix = '.*Started ' if normalized_event_type == 'service_up' else '.*Stopped '
    if not normalized_filter_pattern.startswith(prefix):
        return ''

    suffix = '.*'
    description = normalized_filter_pattern[len(prefix):].strip()
    if description.endswith(suffix):
        description = description[:-len(suffix)].strip()

    matched_option = next((option for option in SERVICE_OPTIONS if option['description'] == description), None)
    if matched_option is None:
        return ''

    return str(matched_option['value'])


def extract_vrrp_group_name_from_pattern(event_type: Any, filter_pattern: Any) -> str:
    if str(event_type or '').strip() != 'vrrp_status':
        return ''

    normalized_filter_pattern = str(filter_pattern or '').strip()
    prefix = '.*INSTANCE '
    suffix_marker = ' changed state to '
    if not normalized_filter_pattern.startswith(prefix) or suffix_marker not in normalized_filter_pattern:
        return ''

    group_name = normalized_filter_pattern[len(prefix):].split(suffix_marker)[0].strip()
    if group_name in ['', '<group-name>']:
        return ''

    return group_name


def get_environment_value_from_names(environment_data: Any, environment_names: List[str]) -> str:
    for environment_name in environment_names:
        value = get_environment_value(environment_data, environment_name)
        if value != '':
            return value

    return ''


def get_environment_value(environment_data: Any, environment_name: Any) -> str:
    if not isinstance(environment_data, dict):
        return ''

    normalized_name = str(environment_name or '').strip().lower()
    for env_name, env_value in environment_data.items():
        if str(env_name or '').strip().lower() != normalized_name:
            continue

        if isinstance(env_value, dict):
            return str(env_value.get('value') or '')
        return str(env_value or '')

    return ''


def serialize_alarm_config(config):
    result = empty_alarm_frontend()

    if not isinstance(config, dict):
        return result

    event_map = config.get('event', config)
    if not isinstance(event_map, dict):
        return result

    for event_name, event_data in event_map.items():
        if not isinstance(event_data, dict):
            result['events'].append({
                'eventNameId': str(event_name),
                'eventName': '',
                'description': '',
                'guiLevel': '',
                'smsNumber': '',
                'eventType': infer_alarm_event_type(event_name),
                'filterPattern': '',
                'syslogIdentifier': '',
                'interfaceName': '',
                'serviceName': '',
                'guiNotification': False,
                'sms': False,
                'email': False,
            })
            continue

        filter_data = event_data.get('filter') or {}
        script_data = event_data.get('script') or {}
        environment_data = script_data.get('environment') or {} if isinstance(script_data, dict) else {}
        script_path = ''
        if isinstance(script_data, dict):
            script_path = str(script_data.get('path') or '')
        actions = get_alarm_script_actions(script_path, environment_data)

        result['events'].append({
            'eventNameId': str(event_name),
            'eventName': get_environment_value_from_names(environment_data, EVENT_NAME_ENVIRONMENT_VARIABLES),
            'description': get_environment_value(environment_data, DESCRIPTION_ENVIRONMENT_VARIABLE),
            'guiLevel': get_environment_value(environment_data, GUI_LEVEL_ENVIRONMENT_VARIABLE),
            'smsNumber': get_environment_value(environment_data, SMS_NUMBER_ENVIRONMENT_VARIABLE),
            'eventType': infer_alarm_event_type_from_details(
                event_name,
                filter_data.get('syslog-identifier') if isinstance(filter_data, dict) else '',
                filter_data.get('pattern') if isinstance(filter_data, dict) else '',
            ),
            'filterPattern': str(filter_data.get('pattern') or ''),
            'syslogIdentifier': str(filter_data.get('syslog-identifier') or ''),
            'interfaceName': extract_interface_name_from_pattern(
                infer_alarm_event_type_from_details(
                    event_name,
                    filter_data.get('syslog-identifier') if isinstance(filter_data, dict) else '',
                    filter_data.get('pattern') if isinstance(filter_data, dict) else '',
                ),
                filter_data.get('pattern') if isinstance(filter_data, dict) else '',
            ),
            'serviceName': extract_service_name_from_pattern(
                infer_alarm_event_type_from_details(
                    event_name,
                    filter_data.get('syslog-identifier') if isinstance(filter_data, dict) else '',
                    filter_data.get('pattern') if isinstance(filter_data, dict) else '',
                ),
                filter_data.get('pattern') if isinstance(filter_data, dict) else '',
            ),
            'guiNotification': actions['guiNotification'],
            'sms': actions['sms'],
            'email': actions['email'],
        })

    return result


class AlarmConfig(db.Model):
    __tablename__ = 'vyos_config_alarm'

    id = Column(Integer, primary_key=True)

    events = relationship('AlarmEvent', back_populates='alarm_config', cascade='all, delete-orphan')

    @classmethod
    def truncate(cls):
        tables_to_clear = [
            'vyos_config_alarm_environment_variable',
            'vyos_config_alarm_event',
            'vyos_config_alarm'
        ]

        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config: Dict[str, Any]):
        try:
            cls.truncate()

            row = cls()
            db.session.add(row)
            db.session.flush()

            cfg = config or {}
            frontend_events = cfg.get('events') if isinstance(cfg, dict) else None
            if isinstance(frontend_events, list):
                for event_data in frontend_events:
                    if not isinstance(event_data, dict):
                        continue

                    event_name = str(event_data.get('eventNameId') or '')
                    if event_name == '':
                        continue

                    event_row = AlarmEvent(
                        alarm_config_id=row.id,
                        name=event_name,
                        event_type=str(event_data.get('eventType') or infer_alarm_event_type(event_name)),
                        filter_pattern=str(event_data.get('filterPattern') or ''),
                        syslog_identifier=str(event_data.get('syslogIdentifier') or ''),
                        gui_notification=bool(event_data.get('guiNotification', False)),
                        sms=bool(event_data.get('sms', False)),
                        email=bool(event_data.get('email', event_data.get('other', False))),
                    )
                    db.session.add(event_row)
                    db.session.flush()

                    for env_name, env_value in {
                        'event_name': str(event_data.get('eventName') or ''),
                        DESCRIPTION_ENVIRONMENT_VARIABLE: str(event_data.get('description') or ''),
                        GUI_LEVEL_ENVIRONMENT_VARIABLE: str(event_data.get('guiLevel') or ''),
                        SMS_NUMBER_ENVIRONMENT_VARIABLE: str(event_data.get('smsNumber') or ''),
                        EMAIL_ENABLED_ENVIRONMENT_VARIABLE: 'true' if event_row.email else '',
                    }.items():
                        if env_value.strip() == '':
                            continue

                        db.session.add(AlarmEnvironmentVariable(
                            event_id=event_row.id,
                            name=env_name,
                            value=env_value,
                        ))

                db.session.commit()
                return

            event_map = cfg.get('event', cfg)
            if not isinstance(event_map, dict):
                db.session.commit()
                return

            for event_name, event_data in event_map.items():
                event_row = AlarmEvent(
                    alarm_config_id=row.id,
                    name=str(event_name),
                    event_type=infer_alarm_event_type(event_name),
                    gui_notification=False,
                    sms=False,
                    email=False,
                )
                if isinstance(event_data, dict):
                    filter_data = event_data.get('filter') or {}
                    script_data = event_data.get('script') or {}
                    environment_data = script_data.get('environment') or {} if isinstance(script_data, dict) else {}

                    if isinstance(filter_data, dict):
                        event_row.filter_pattern = str(filter_data.get('pattern') or '')
                        event_row.syslog_identifier = str(filter_data.get('syslog-identifier') or '')

                    if isinstance(script_data, dict):
                        event_row.script_path = str(script_data.get('path') or '')

                    action_data = get_alarm_script_actions(event_row.script_path, environment_data)
                    event_row.event_type = infer_alarm_event_type_from_details(
                        event_name,
                        event_row.syslog_identifier,
                        event_row.filter_pattern,
                    )
                    event_row.gui_notification = action_data['guiNotification']
                    event_row.sms = action_data['sms']
                    event_row.email = action_data['email']

                db.session.add(event_row)
                db.session.flush()

                if isinstance(event_data, dict):
                    script_data = event_data.get('script') or {}
                    environment_data = script_data.get('environment') or {}

                    if isinstance(environment_data, dict):
                        for env_name, env_value in environment_data.items():
                            value = ''
                            if isinstance(env_value, dict):
                                value = env_value.get('value') or ''
                            elif env_value is not None:
                                value = env_value

                            db.session.add(AlarmEnvironmentVariable(
                                event_id=event_row.id,
                                name=env_name,
                                value=str(value) if value is not None else '',
                            ))

            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

    @staticmethod
    def empty_frontend() -> Dict[str, Any]:
        return empty_alarm_frontend()

    def serialize(self) -> Dict[str, Any]:
        return {
            'events': [event.serialize() for event in (self.events or [])]
        }


class AlarmEvent(db.Model):
    __tablename__ = 'vyos_config_alarm_event'

    id = Column(Integer, primary_key=True)
    alarm_config_id = Column(Integer, ForeignKey('vyos_config_alarm.id'), nullable=False)
    name = Column(String, nullable=False)
    event_type = Column(String, nullable=True)
    filter_pattern = Column(Text, nullable=True)
    syslog_identifier = Column(String, nullable=True)
    gui_notification = Column(Boolean, nullable=True, default=False)
    sms = Column(Boolean, nullable=True, default=False)
    email = Column('other', Boolean, nullable=True, default=False)
    script_path = Column(Text, nullable=True)

    alarm_config = relationship('AlarmConfig', back_populates='events')
    environment = relationship('AlarmEnvironmentVariable', back_populates='event', cascade='all, delete-orphan')

    def serialize(self) -> Dict[str, Any]:
        event_type = infer_alarm_event_type_from_details(
            self.name,
            self.syslog_identifier,
            self.filter_pattern,
        )
        environment_map = {
            str(item.name or '').strip().lower(): str(item.value or '')
            for item in (self.environment or [])
            if str(item.name or '').strip() != ''
        }
        action_data = get_alarm_script_actions(self.script_path, environment_map)
        return {
            'eventNameId': str(self.name or ''),
            'eventName': next((environment_map.get(name, '') for name in EVENT_NAME_ENVIRONMENT_VARIABLES if environment_map.get(name, '') != ''), ''),
            'description': environment_map.get(DESCRIPTION_ENVIRONMENT_VARIABLE, ''),
            'guiLevel': environment_map.get(GUI_LEVEL_ENVIRONMENT_VARIABLE, ''),
            'smsNumber': environment_map.get(SMS_NUMBER_ENVIRONMENT_VARIABLE, ''),
            'eventType': event_type,
            'filterPattern': str(self.filter_pattern or ''),
            'syslogIdentifier': str(self.syslog_identifier or ''),
            'interfaceName': extract_interface_name_from_pattern(event_type, self.filter_pattern),
            'serviceName': extract_service_name_from_pattern(event_type, self.filter_pattern),
            'vrrpGroupName': extract_vrrp_group_name_from_pattern(event_type, self.filter_pattern),
            'guiNotification': action_data['guiNotification'],
            'sms': action_data['sms'],
            'email': action_data['email'],
        }


class AlarmEnvironmentVariable(db.Model):
    __tablename__ = 'vyos_config_alarm_environment_variable'

    id = Column(Integer, primary_key=True)
    event_id = Column(Integer, ForeignKey('vyos_config_alarm_event.id'), nullable=False)
    name = Column(String, nullable=False)
    value = Column(Text, nullable=True)

    event = relationship('AlarmEvent', back_populates='environment')

    def serialize(self) -> Dict[str, Any]:
        return {
            'name': str(self.name or ''),
            'value': str(self.value or ''),
        }


class AlarmCallbackEvent(db.Model):
    __tablename__ = 'vyos_config_alarm_callback_event'
    __table_args__ = (
        Index('ix_alarm_callback_received_id', 'received_at', 'id'),
        Index('ix_alarm_callback_level_received', 'gui_level', 'received_at'),
    )

    id = Column(Integer, primary_key=True)
    event = Column(String, nullable=False)
    message = Column(Text, nullable=True)
    event_name = Column(String, nullable=True)
    gui_level = Column(String, nullable=True)
    payload = Column(Text, nullable=False)
    source_event_id = Column(String(64), nullable=False, unique=True, default=lambda: str(uuid4()))
    occurred_at = Column(DateTime, nullable=False, default=datetime.now)
    received_at = Column(DateTime, nullable=False, default=datetime.now)
    created_at = Column(DateTime, nullable=False, default=datetime.now)

    user_states = relationship(
        'AlarmNotificationUserState',
        back_populates='event',
        cascade='all, delete-orphan',
    )

    RETENTION_LIMITS = {
        'critical': 40,
        'warning': 30,
        'info': 30,
    }

    @staticmethod
    def normalize_gui_level(value: Any) -> str:
        normalized = str(value or '').strip().lower()
        return normalized if normalized in AlarmCallbackEvent.RETENTION_LIMITS else 'info'

    @staticmethod
    def parse_occurred_at(value: Any) -> datetime:
        if isinstance(value, datetime):
            return value
        if isinstance(value, str) and value.strip() != '':
            try:
                parsed = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
                if parsed.tzinfo is not None:
                    return parsed.astimezone(timezone.utc).replace(tzinfo=None)
                return parsed
            except ValueError:
                pass
        return datetime.now()

    @classmethod
    def create_from_payload(cls, payload: Any):
        row, _created = cls.get_or_create_from_payload(payload)
        return row

    @classmethod
    def get_or_create_from_payload(cls, payload: Any):
        payload_data = payload if isinstance(payload, dict) else {}
        gui_level = cls.normalize_gui_level(payload_data.get('gui_level'))
        source_event_id = str(payload_data.get('source_event_id') or '').strip()
        if source_event_id == '':
            source_event_id = str(uuid4())

        existing = cls.query.filter_by(source_event_id=source_event_id).first()
        if existing is not None:
            return existing, False

        limit = cls.RETENTION_LIMITS.get(gui_level)
        if limit:
            limit_lvl_count = cls.query.filter(cls.gui_level == gui_level).count()
            if limit_lvl_count >= limit:
                oldest = cls.query.filter(cls.gui_level == gui_level).order_by(cls.created_at.asc(), cls.id.asc()).first()
                if oldest:
                    db.session.delete(oldest)
                    db.session.flush()

        row = cls(
            event=str(payload_data.get('event') or ''),
            message=str(payload_data.get('message') or ''),
            event_name=str(payload_data.get('event_name') or ''),
            gui_level=gui_level,
            payload=json.dumps(payload_data, ensure_ascii=False),
            source_event_id=source_event_id,
            occurred_at=cls.parse_occurred_at(payload_data.get('occurred_at')),
            received_at=datetime.now(),
        )
        db.session.add(row)
        try:
            db.session.commit()
            return row, True
        except IntegrityError:
            db.session.rollback()
            existing = cls.query.filter_by(source_event_id=source_event_id).first()
            if existing is not None:
                return existing, False
            raise

    @classmethod
    def list_serialized(cls) -> List[Dict[str, Any]]:
        return [row.serialize() for row in cls.query.order_by(cls.created_at.desc(), cls.id.desc()).all()]

    @classmethod
    def list_for_user(cls, username: str, after_id: Optional[int] = None, limit: int = 100):
        query = cls.query
        if after_id is not None:
            query = query.filter(cls.id > after_id)

        events = query.order_by(cls.id.desc()).limit(limit).all()
        event_ids = [event.id for event in events]
        states = {
            state.event_id: state
            for state in AlarmNotificationUserState.query.filter(
                AlarmNotificationUserState.username == username,
                AlarmNotificationUserState.event_id.in_(event_ids),
            ).all()
        } if event_ids else {}

        active = [
            event.serialize_notification(is_read=bool(states.get(event.id) and states[event.id].read_at))
            for event in events
            if states.get(event.id) is None or states[event.id].dismissed_at is None
        ]

        all_states = {
            state.event_id: state
            for state in AlarmNotificationUserState.query.filter_by(username=username).all()
        }
        unread_counts = {'critical': 0, 'warning': 0, 'info': 0}
        for event in cls.query.all():
            state = all_states.get(event.id)
            if state is None or (state.dismissed_at is None and state.read_at is None):
                unread_counts[cls.normalize_gui_level(event.gui_level)] += 1

        return active, unread_counts

    def serialize_notification(self, is_read: bool = False) -> Dict[str, Any]:
        level = self.normalize_gui_level(self.gui_level)
        event_name = str(self.event_name or '').strip()
        received_at = self.received_at or self.created_at
        occurred_at = self.occurred_at or self.created_at
        return {
            'id': str(self.id),
            'sourceEventId': str(self.source_event_id or ''),
            'type': level,
            'level': level,
            'title': f"Event {event_name}:" if event_name else 'Notification:',
            'content': str(self.message or ''),
            'description': str(self.message or ''),
            'eventName': event_name,
            'eventType': str(self.event or ''),
            'occurredAt': occurred_at.isoformat() if occurred_at else '',
            'receivedAt': received_at.isoformat() if received_at else '',
            'timestamp': received_at.isoformat() if received_at else '',
            'isRead': bool(is_read),
            'persisted': True,
        }

    def serialize(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'event': str(self.event or ''),
            'message': str(self.message or ''),
            'event_name': str(self.event_name or ''),
            'gui_level': str(self.gui_level or ''),
            'payload': str(self.payload or ''),
            'source_event_id': str(self.source_event_id or ''),
            'occurred_at': self.occurred_at.isoformat() if self.occurred_at else '',
            'received_at': self.received_at.isoformat() if self.received_at else '',
            'created_at': self.created_at.isoformat() if self.created_at else '',
        }


class AlarmNotificationUserState(db.Model):
    __tablename__ = 'vyos_config_alarm_notification_user_state'
    __table_args__ = (
        UniqueConstraint('event_id', 'username', name='uq_alarm_notification_event_username'),
        Index('ix_alarm_notification_user_active', 'username', 'dismissed_at', 'event_id'),
    )

    id = Column(Integer, primary_key=True)
    event_id = Column(
        Integer,
        ForeignKey('vyos_config_alarm_callback_event.id', ondelete='CASCADE'),
        nullable=False,
        index=True,
    )
    username = Column(String, nullable=False, index=True)
    read_at = Column(DateTime, nullable=True)
    dismissed_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    event = relationship('AlarmCallbackEvent', back_populates='user_states')

    @classmethod
    def get_or_create(cls, event_id: int, username: str):
        state = cls.query.filter_by(event_id=event_id, username=username).first()
        if state is None:
            state = cls(event_id=event_id, username=username)
            db.session.add(state)
        return state

    @classmethod
    def mark_read(cls, event_id: int, username: str):
        state = cls.get_or_create(event_id, username)
        if state.read_at is None:
            state.read_at = datetime.now()
        state.updated_at = datetime.now()
        return state

    @classmethod
    def dismiss(cls, event_id: int, username: str):
        state = cls.get_or_create(event_id, username)
        if state.read_at is None:
            state.read_at = datetime.now()
        if state.dismissed_at is None:
            state.dismissed_at = datetime.now()
        state.updated_at = datetime.now()
        return state
