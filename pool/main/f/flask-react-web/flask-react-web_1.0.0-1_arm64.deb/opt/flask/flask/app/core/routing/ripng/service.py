from app.core.routing.ripng.command_ripng import RIPngCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_RIPNG
from app.core.routing.ripng.models import RIPngConfig


def update_ripng(provider, data):
    logger.info("Update RIPng:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    if not config or config == {}:
        print("Empty config detected - deleting entire RIPng configuration")
        delete_cmd = '{"op": "delete", "path": ["protocols", "ripng"]}'
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_cmd,
            verify=False,
        )
        res_json = res.json()

        if res_json.get('success'):
            print("RIPng configuration deleted successfully")
            RIPngConfig.truncate()
        else:
            print("Failed to delete RIPng configuration")
            return [{
                "success": False,
                "error": res_json.get('error'),
                "cmd": delete_cmd
        }]

        
        socket_manager.emit_to_user(
            username, 
            event='notification', 
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Delete RIPng",
                "content": "RIPng configuration deleted successfully"
            }
        )
        
        return [{"success": True, "cmd": delete_cmd}]

    set_cmds = []
    iface_set_cmd = RIPngCommand(operator='set', resource='ripng')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = RIPngCommand(operator='delete', resource='ripng')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    service = "ripng"
    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('protocols', {}).get('ripng', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('protocols', {}).get('ripng', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB
    RIPngConfig.refresh(config)

    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update RIPng",
                "content": "RIPng is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_ripng(provider, data):
    config_to_verify = data
    verify = provider.verify_service.call_verify("ripng", config_to_verify)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify


def fetch_ripng(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_RIPNG, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data


def restart_ripngd(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartFrrRestartFrrMutation',
        data={"daemon": "ripngd"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}
