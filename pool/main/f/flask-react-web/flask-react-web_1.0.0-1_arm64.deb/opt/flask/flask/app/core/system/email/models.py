from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db.database import db


class EmailOAuth2DTO(BaseModel):
    clientId: str = ''
    clientSecret: str = ''
    refreshToken: str = ''
    scope: str = ''
    tokenUrl: str = ''


class EmailProfileDTO(BaseModel):
    name: str = ''
    authentication: Literal['password', 'oauth2'] = 'password'
    caFile: str = ''
    fromEmail: str = ''
    noValidateCert: bool = False
    oauth2: EmailOAuth2DTO = Field(default_factory=EmailOAuth2DTO)
    password: str = ''
    port: Optional[int] = Field(default=None, ge=1, le=65535)
    security: Literal['none', 'starttls', 'tls'] = 'starttls'
    smtpHost: str = ''
    username: str = ''

    @field_validator('port', mode='before')
    @classmethod
    def empty_port_as_none(cls, value):
        return None if value == '' else value

    @model_validator(mode='after')
    def validate_required_settings(self):
        missing = []
        if not self.name.strip():
            missing.append('profile name')
        if not self.fromEmail.strip():
            missing.append('from email')
        if not self.smtpHost.strip():
            missing.append('SMTP host')
        if not self.username.strip():
            missing.append('username')
        if self.authentication == 'password' and not self.password:
            missing.append('password')
        if self.authentication == 'oauth2':
            if not self.oauth2.clientId.strip():
                missing.append('OAuth2 client ID')
            if not self.oauth2.refreshToken.strip():
                missing.append('OAuth2 refresh token')
            if not self.oauth2.tokenUrl.strip():
                missing.append('OAuth2 token URL')
        if missing:
            raise ValueError(f"Email profile is missing: {', '.join(missing)}")
        return self


class EmailRecipientDTO(BaseModel):
    name: str = ''
    email: str = ''
    enabled: bool = False
    subject: str = ''

    @model_validator(mode='after')
    def validate_required_settings(self):
        if not self.name.strip():
            raise ValueError('Email recipient name is required')
        if not self.email.strip():
            raise ValueError(f'Email address is required for recipient {self.name}')
        return self


class TestEmailDTO(BaseModel):
    message: str = Field(min_length=1, max_length=4096)

    @field_validator('message')
    @classmethod
    def validate_message(cls, value: str):
        if not value.strip():
            raise ValueError('Test email message is required')
        return value


class UpdateEmailDTO(BaseModel):
    activeProfile: str = ''
    profiles: List[EmailProfileDTO] = Field(default_factory=list)
    recipients: List[EmailRecipientDTO] = Field(default_factory=list)

    @model_validator(mode='after')
    def validate_references(self):
        profile_names = [profile.name.strip() for profile in self.profiles]
        recipient_names = [recipient.name.strip() for recipient in self.recipients]
        if len(profile_names) != len(set(profile_names)):
            raise ValueError('Email profile names must be unique')
        if len(recipient_names) != len(set(recipient_names)):
            raise ValueError('Email recipient names must be unique')
        if self.activeProfile and self.activeProfile not in profile_names:
            raise ValueError('Active email profile must reference an existing profile')
        return self


class EmailConfig(db.Model):
    __tablename__ = 'vyos_config_email'

    id = Column(Integer, primary_key=True)
    active_profile = Column(String, nullable=True)

    profiles = relationship(
        'EmailProfile',
        back_populates='email_config',
        cascade='all, delete-orphan',
    )
    recipients = relationship(
        'EmailRecipient',
        back_populates='email_config',
        cascade='all, delete-orphan',
    )

    @staticmethod
    def empty_frontend() -> Dict[str, Any]:
        return {'activeProfile': '', 'profiles': [], 'recipients': []}

    @classmethod
    def truncate(cls):
        from sqlalchemy import text

        for table_name in (
            'vyos_config_email_profile',
            'vyos_config_email_recipient',
            'vyos_config_email',
        ):
            db.session.execute(text(f'DELETE FROM {table_name}'))

    @classmethod
    def refresh(cls, config: Dict[str, Any]):
        try:
            cls.truncate()

            data = config if isinstance(config, dict) else {}
            row = cls(active_profile=str(data.get('active-profile') or ''))
            db.session.add(row)
            db.session.flush()

            profiles = data.get('profile') or {}
            if isinstance(profiles, dict):
                for profile_name, profile_data in profiles.items():
                    profile = profile_data if isinstance(profile_data, dict) else {}
                    oauth2 = profile.get('oauth2') if isinstance(profile.get('oauth2'), dict) else {}
                    raw_port = profile.get('port')
                    try:
                        port = int(raw_port) if raw_port not in (None, '') else 0
                    except (TypeError, ValueError):
                        port = 0

                    db.session.add(EmailProfile(
                        email_config_id=row.id,
                        name=str(profile_name),
                        authentication=str(profile.get('authentication') or 'password'),
                        ca_file=str(profile.get('ca-file') or ''),
                        from_email=str(profile.get('from-email') or ''),
                        no_validate_cert=(
                            'no-validate-cert' in profile
                            and profile.get('no-validate-cert') is not False
                            and profile.get('no-validate-cert') is not None
                        ),
                        oauth2_client_id=str(oauth2.get('client-id') or ''),
                        oauth2_client_secret=str(oauth2.get('client-secret') or ''),
                        oauth2_refresh_token=str(oauth2.get('refresh-token') or ''),
                        oauth2_scope=str(oauth2.get('scope') or ''),
                        oauth2_token_url=str(oauth2.get('token-url') or ''),
                        password=str(profile.get('password') or ''),
                        port=port,
                        security=str(profile.get('security') or 'starttls'),
                        smtp_host=str(profile.get('smtp-host') or ''),
                        username=str(profile.get('username') or ''),
                    ))

            recipients = data.get('recipient') or {}
            if isinstance(recipients, dict):
                for recipient_name, recipient_data in recipients.items():
                    recipient = recipient_data if isinstance(recipient_data, dict) else {}
                    db.session.add(EmailRecipient(
                        email_config_id=row.id,
                        name=str(recipient_name),
                        email=str(recipient.get('email') or ''),
                        enabled=(
                            'enable' in recipient
                            and recipient.get('enable') is not False
                            and recipient.get('enable') is not None
                        ),
                        subject=str(recipient.get('subject') or ''),
                    ))

            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

    def serialize(self) -> Dict[str, Any]:
        return {
            'activeProfile': str(self.active_profile or ''),
            'profiles': [profile.serialize() for profile in (self.profiles or [])],
            'recipients': [recipient.serialize() for recipient in (self.recipients or [])],
        }


class EmailProfile(db.Model):
    __tablename__ = 'vyos_config_email_profile'

    id = Column(Integer, primary_key=True)
    email_config_id = Column(Integer, ForeignKey('vyos_config_email.id'), nullable=False)
    name = Column(String, nullable=False)
    authentication = Column(String, nullable=False, default='password')
    ca_file = Column(Text, nullable=True)
    from_email = Column(String, nullable=True)
    no_validate_cert = Column(Boolean, nullable=False, default=False)
    oauth2_client_id = Column(Text, nullable=True)
    oauth2_client_secret = Column(Text, nullable=True)
    oauth2_refresh_token = Column(Text, nullable=True)
    oauth2_scope = Column(Text, nullable=True)
    oauth2_token_url = Column(Text, nullable=True)
    password = Column(Text, nullable=True)
    port = Column(Integer, nullable=False, default=0)
    security = Column(String, nullable=False, default='starttls')
    smtp_host = Column(String, nullable=True)
    username = Column(Text, nullable=True)

    email_config = relationship('EmailConfig', back_populates='profiles')

    def serialize(self) -> Dict[str, Any]:
        return {
            'name': str(self.name or ''),
            'authentication': str(self.authentication or 'password'),
            'caFile': str(self.ca_file or ''),
            'fromEmail': str(self.from_email or ''),
            'noValidateCert': bool(self.no_validate_cert),
            'oauth2': {
                'clientId': str(self.oauth2_client_id or ''),
                'clientSecret': str(self.oauth2_client_secret or ''),
                'refreshToken': str(self.oauth2_refresh_token or ''),
                'scope': str(self.oauth2_scope or ''),
                'tokenUrl': str(self.oauth2_token_url or ''),
            },
            'password': str(self.password or ''),
            'port': int(self.port) if self.port else '',
            'security': str(self.security or 'starttls'),
            'smtpHost': str(self.smtp_host or ''),
            'username': str(self.username or ''),
        }


class EmailRecipient(db.Model):
    __tablename__ = 'vyos_config_email_recipient'

    id = Column(Integer, primary_key=True)
    email_config_id = Column(Integer, ForeignKey('vyos_config_email.id'), nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, nullable=True)
    enabled = Column(Boolean, nullable=False, default=False)
    subject = Column(Text, nullable=True)

    email_config = relationship('EmailConfig', back_populates='recipients')

    def serialize(self) -> Dict[str, Any]:
        return {
            'name': str(self.name or ''),
            'email': str(self.email or ''),
            'enabled': bool(self.enabled),
            'subject': str(self.subject or ''),
        }
