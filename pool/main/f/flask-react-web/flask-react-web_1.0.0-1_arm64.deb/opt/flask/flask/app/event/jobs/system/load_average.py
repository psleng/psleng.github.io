import re
import subprocess
import time
import os
import logging
import sys
import threading
from logging.handlers import RotatingFileHandler
from logging import getLogger, DEBUG

from app.core.utils.check_os import is_linux
from app.core.models import LoadAverageHistory

logger = getLogger(__name__)
logger.setLevel(DEBUG)


def _configure_loadavg_file_logging() -> None:
    log_dir = '/var/log/flask-react-web'
    log_path = os.path.join(log_dir, 'fetch_load_average.log')
    handler_key = '_fetch_load_average_file_handler'

    if getattr(logger, handler_key, None) is not None:
        return

    try:
        os.makedirs(log_dir, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
        )
        file_handler.setLevel(DEBUG)
        file_handler.setFormatter(
            logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s')
        )
        logger.addHandler(file_handler)
        setattr(logger, handler_key, file_handler)
        logger.propagate = True
        logger.debug(f"fetch_load_average file logging enabled: {log_path}")
    except Exception:
        logger.exception(f"fetch_load_average file logging could not be enabled at {log_path}")


def _parse_uptime_load_average_1(output: str):
    if not output:
        return None

    match = re.search(r"load average[s]?:\s*([0-9]+(?:\.[0-9]+)?(?:\s*,\s*[0-9]+(?:\.[0-9]+)?)+)", output)
    if not match:
        return None
    try:
        values = [value.strip() for value in match.group(1).split(',') if value.strip()]
        if not values:
            return None
        return float(values[0])
    except Exception:
        return None


def fetch_load_average(app_context):
    # _configure_loadavg_file_logging()
    start = time.perf_counter()
    pid = os.getpid()
    thread_id = threading.get_ident()
    try:
        frame = sys._getframe()
        is_apscheduler = False
        for _ in range(25):
            if frame is None:
                break
            filename = frame.f_code.co_filename or ''
            if 'apscheduler' in filename.replace('\\', '/').lower():
                is_apscheduler = True
                break
            frame = frame.f_back
    except Exception:
        is_apscheduler = False

    trigger_source = 'apscheduler' if is_apscheduler else 'manual'
    logger.debug(f"fetch_load_average scheduled trigger: start source={trigger_source} pid={pid} tid={thread_id}")
    try:
        result = refresh_db_load_average_history(app_context=app_context)
        duration_ms = (time.perf_counter() - start) * 1000
        logger.debug(
            f"fetch_load_average scheduled trigger: done source={trigger_source} "
            f"pid={pid} tid={thread_id} duration_ms={duration_ms:.2f} result={result}"
        )
        return result
    except Exception:
        duration_ms = (time.perf_counter() - start) * 1000
        logger.exception(
            f"fetch_load_average scheduled trigger: failed source={trigger_source} "
            f"pid={pid} tid={thread_id} duration_ms={duration_ms:.2f}"
        )
        return None


def refresh_db_load_average_history(app_context=None):
    if not is_linux():
        return None

    try:
        proc = subprocess.Popen(
            ["uptime"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            stdout, stderr = proc.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except Exception:
                logger.exception("Error killing uptime process after timeout")
            try:
                stdout, stderr = proc.communicate(timeout=1)
            except Exception:
                return None
        if stderr:
            logger.error(f"Error executing uptime: {stderr.decode(errors='ignore')}")
            return None

        output = stdout.decode(errors='ignore').strip()
        load_avg_1 = _parse_uptime_load_average_1(output)
        if load_avg_1 is None:
            return None

        load_avg_1 = load_avg_1 / 2
        if app_context is not None:
            if hasattr(app_context, 'app_context') and callable(getattr(app_context, 'app_context')):
                with app_context.app_context():
                    LoadAverageHistory.append_value(load_avg_1)
            else:
                with app_context:
                    LoadAverageHistory.append_value(load_avg_1)
        else:
            LoadAverageHistory.append_value(load_avg_1)

        return load_avg_1
    except Exception as e:
        logger.error(f"Error refresh load average history: {str(e)}")
        return None
