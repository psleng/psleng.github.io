### MFA with PAM:

#### Setup Radius server
```bash
Set system login radius server <radius-server-ip>
Set system login radius server <radius-server-ip> key <radius-server-key>
Set system login radius server <radius-server-ip> port <radius-server-port>
Set system login radius server <radius-server-ip> timeout <radius-server-timeout>
```

#### Requirements.txt
```bash
python-pam
```

#### Extend python-pam:
- Implement interactive conversation function that can handle OTP prompts.
- Listen to PAM events: **PAM_PROMPT_ECHO_OFF** and **PAM_PROMPT_ECHO_ON** 


#### Workflow
0. Users go to /login page, react will register a websoket as guest and get a ssid from flask.
1. User will input username and password, react will send a request to flask with ssid, username and password.
2. Flask will use **pam_authenticator.py** to call pam_start a login process and expect the password prompt, in order to call PAM stack.
3. Based on the response from PAM stack (Radius configured), there are three possible responses:
    - (1) Authentication failure
    - (2) Welcome message
    - (3) OTP prompt
4. (1) and (2): Flask will return 401/200 to react, end the request.
5. (3) OTP prompt: The login request waits cooperatively while React submits the OTP over WebSocket. Flask forwards it to the PAM helper over a private pipe (see **otp_store.py**).
6. If OTP is correct, user will be logged in, otherwise, Flask will return 401 to react, end the request.

#### Backend timeout and concurrency

Each PAM login runs in its own subprocess, so a blocked authentication does not
freeze Flask's gevent event loop.

```bash
PAM_AUTH_TIMEOUT_SECONDS=90
PAM_AUTH_MAX_PROCESSES=4
```

- **Capacity:** Up to <PAM_AUTH_MAX_PROCESSES> PAM logins can run at once per Gunicorn worker.
- **Timeout:** The <PAM_AUTH_TIMEOUT_SECONDS> seconds budget includes authentication and OTP exchange;
  helper startup time is deducted once launch completes. On expiry, Flask sends
  SIGKILL to the helper's process group, clears the OTP waiter and frees the
  active slot. The request returns **504**, with up to one extra second for cleanup.
- **Busy:** When all slots are occupied, another login returns **503** immediately:
  "Authentication service is busy. Try again in <PAM_AUTH_TIMEOUT_SECONDS> seconds." The message and
  `Retry-After` header use the configured timeout, not a fixed value. Duplicate
  requests using an active socket ID also return 503.
- **OTP:** `send_socket_otp` stays in `pam_authenticator.py`. It runs in Flask,
  exchanging OTPs with the browser over WebSocket and with the helper over private pipes.

If cleanup takes longer, it continues in the background. When pending cleanups
reach the process limit, new PAM logins return 503 until cleanup progresses.

### Workflow Diagram

```mermaid
sequenceDiagram
    participant User
    participant ReactFrontend as React Frontend
    participant FlaskBackend as Flask Backend
    participant PAM_OS as PAM/OS
    participant RadiusServer as Radius Server

    User->>ReactFrontend: Navigates to /login
    ReactFrontend->>FlaskBackend: Request WebSocket SSID
    FlaskBackend-->>ReactFrontend: Provides SSID

    User->>ReactFrontend: Enters username & password
    ReactFrontend->>FlaskBackend: POST /login (credentials + SSID)

    FlaskBackend->>PAM_OS: <extend_python_pam>.pam_start('sudo login ...')
    PAM_OS->>FlaskBackend: "Password:"
    FlaskBackend->>PAM_OS: Sends password

    PAM_OS->>RadiusServer: Authentication Request
    RadiusServer-->>PAM_OS: Response

    alt PAM_SERVICE_ERR
        PAM_OS->>FlaskBackend: "Authentication failure"
        FlaskBackend-->>ReactFrontend: 401 Unauthorized
        ReactFrontend-->>User: Shows error message
    else PAM_SUCCESS
        PAM_OS->>FlaskBackend: "Welcome to..."
        FlaskBackend-->>ReactFrontend: 200 OK (Login successful)
        ReactFrontend-->>User: Redirects to dashboard
    else PAM_PROMPT_ECHO_ON, PAM_PROMPT_ECHO_OFF
        PAM_OS->>FlaskBackend: "OTP:"
        FlaskBackend->>ReactFrontend: (via WebSocket) clientRequest 'login-mfa-password'
        ReactFrontend->>User: Shows OTP input field

        User->>ReactFrontend: Enters OTP
        ReactFrontend->>FlaskBackend: (via WebSocket) sendOTP
        FlaskBackend->>PAM_OS: (via <extend_pam_python> with thread event) Sends OTP

        PAM_OS->>RadiusServer: Verify OTP
        RadiusServer-->>PAM_OS: OTP Response

        alt PAM_SUCCESS
            PAM_OS->>FlaskBackend: "Welcome to..."
            FlaskBackend-->>ReactFrontend: 200 OK (Login successful)
            ReactFrontend-->>User: Redirects to dashboard
        else PAM_ERROR_MSG
            PAM_OS->>FlaskBackend: "Authentication failure"
            FlaskBackend-->>ReactFrontend: 401 Unauthorized
            ReactFrontend-->>User: Shows "Invalid OTP"
        end
    end
```
