import operator
from typing import Any, Dict, List, Optional

from app.core.api.http.cmd.command import Command


def is_str_not_empty(value: Any) -> bool:
    return isinstance(value, str) and value.strip() != ''


def _is_empty_dict(value: Any) -> bool:
    return isinstance(value, dict) and len(value) == 0


class SyslogCommand(Command):
    """SyslogCommand class is used to generate commands for system syslog configuration.

    Supported commands (set/delete):

    Console facilities:
    - set/delete system syslog console facility { all | auth | authpriv | cron | daemon | kern | lpr | mail | mark | news | syslog | user | uucp | local0 | local1 | local2 | local3 | local4 | local5 | local6 | local7 }
    - set/delete system syslog console facility <facility-name> level { emerg | alert | crit | err | warning | notice | info | debug | all }

    Local facilities:
    - set/delete system syslog local facility { all | auth | authpriv | cron | daemon | kern | lpr | mail | mark | news | syslog | user | uucp | local0 | local1 | local2 | local3 | local4 | local5 | local6 | local7 }
    - set/delete system syslog local facility <facility-name> level { emerg | alert | crit | err | warning | notice | info | debug | all }

    Remote syslog destinations:
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname }
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } facility { all | auth | authpriv | cron | daemon | kern | lpr | mail | mark | news | syslog | user | uucp | local0 | local1 | local2 | local3 | local4 | local5 | local6 | local7 }
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } facility <facility-name> level { emerg | alert | crit | err | warning | notice | info | debug | all }

    Remote formatting:
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } format include-timezone
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } format octet-counted

    Remote transport:
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } port <1-65535>
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } protocol { udp | tcp }
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } source-address { x.x.x.x | h:h:h::h }

    Remote TLS:
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } tls auth-mode { anon | fingerprint | certvalid | name }
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } tls ca-certificate <ca-name>
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } tls certificate <cert-name>
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } tls permitted-peer <peer-finger-print>

    Remote VRF:
    - set/delete system syslog remote { x.x.x.x | h:h:h::h | hostname } vrf <vrf-name>

    Marker:
    - set/delete system syslog marker disable
    - set/delete system syslog marker interval <1-65535>

    Preserve FQDN:
    - set/delete system syslog preserve-fqdn
    """

    def __init__(self, operator: str = 'set', config: Optional[dict] = None, resource: str = 'system'):
        super().__init__(operator=operator, resource=resource)
        self.config = config or {}
        self.cmds: List[str] = []
        self.vyos_cmds: List[str] = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data: Optional[Dict[str, Any]] = None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            syslog_cfg = data
            if isinstance(syslog_cfg, dict) and 'system' in syslog_cfg and isinstance(syslog_cfg.get('system'), dict):
                syslog_cfg = syslog_cfg['system'].get('syslog', {})
            if isinstance(syslog_cfg, dict) and 'syslog' in syslog_cfg and isinstance(syslog_cfg.get('syslog'), dict):
                syslog_cfg = syslog_cfg.get('syslog')

            if not isinstance(syslog_cfg, dict):
                return []

            if 'console' in syslog_cfg:
                self._process_console(syslog_cfg.get('console'), current_config, new_config)

            if 'local' in syslog_cfg:
                self._process_local(syslog_cfg.get('local'), current_config, new_config)

            if 'remote' in syslog_cfg:
                self._process_remote(syslog_cfg.get('remote'), current_config, new_config)

            if 'marker' in syslog_cfg:
                self._process_marker(syslog_cfg.get('marker'))

            if 'preserve-fqdn' in syslog_cfg:
                self._process_preserve_fqdn(syslog_cfg.get('preserve-fqdn'))

            return self.cmds
        except Exception as e:
            print(f"Error generating Syslog commands: {e}")
            return []

    def _process_console(self, console_cfg: Any, current_config, new_config):
        base_path = ['system', 'syslog', 'console']
        if console_cfg is None:
            return
        if _is_empty_dict(console_cfg):
            self.generate(*base_path)
            return
        if not isinstance(console_cfg, dict):
            return

        facility_cfg = console_cfg.get('facility')
        if not isinstance(facility_cfg, dict):
            return

        for facility, opts in facility_cfg.items():
            facility_path = base_path + ['facility', str(facility)]

            if self.operator == 'delete' and facility not in new_config.get('console', {}).get('facility', {}):
                self.generate(*facility_path)
                continue
            elif self.operator == 'set':
                self.generate(*facility_path)

            if isinstance(opts, dict) and is_str_not_empty(opts.get('level')):
                if self.operator == 'delete':
                    self.generate(*(facility_path + ['level']))
                else:
                    self.generate(*(facility_path + ['level', str(opts.get('level'))]))

    def _process_local(self, local_cfg: Any, current_config, new_config):
        base_path = ['system', 'syslog', 'local']
        if local_cfg is None:
            return
        if _is_empty_dict(local_cfg):
            self.generate(*base_path)
            return
        if not isinstance(local_cfg, dict):
            return

        facility_cfg = local_cfg.get('facility')
        if not isinstance(facility_cfg, dict):
            return

        for facility, opts in facility_cfg.items():
            facility_path = base_path + ['facility', str(facility)]

            if self.operator == 'delete' and facility not in new_config.get('local', {}).get('facility', {}):
                self.generate(*facility_path)
                continue
            elif self.operator == 'set':
                self.generate(*facility_path)

            if isinstance(opts, dict) and is_str_not_empty(opts.get('level')):
                if self.operator == 'delete':
                    self.generate(*(facility_path + ['level']))
                else:
                    self.generate(*(facility_path + ['level', str(opts.get('level'))]))

    def _process_remote(self, remote_cfg: Any, current_config, new_config):
        if remote_cfg is None:
            return
        base_path = ['system', 'syslog', 'remote']
        if _is_empty_dict(remote_cfg):
            self.generate(*base_path)
            return
        if not isinstance(remote_cfg, dict):
            return

        for host, opts in remote_cfg.items():
            host_path = base_path + [str(host)]

            if self.operator == 'delete' and host not in new_config.get('remote', {}):
                self.generate(*host_path)
                continue
            elif self.operator == 'set':
                self.generate(*host_path)

            if not isinstance(opts, dict):
                continue

            for key in ['port', 'protocol', 'source-address', 'vrf']:
                if key not in opts:
                    continue
                if self.operator == 'delete':
                    self.generate(*(host_path + [key]))
                else:
                    v = opts.get(key)
                    if v is None:
                        continue
                    self.generate(*(host_path + [key, str(v)]))

            fmt = opts.get('format')
            if fmt is not None:
                fmt_path = host_path + ['format']
                if _is_empty_dict(fmt):
                    self.generate(*fmt_path)
                elif isinstance(fmt, dict):
                    if 'include-timezone' in fmt:
                        self.generate(*(fmt_path + ['include-timezone']))
                    if 'octet-counted' in fmt:
                        self.generate(*(fmt_path + ['octet-counted']))

            tls = opts.get('tls')
            if tls is not None:
                tls_path = host_path + ['tls']
                if _is_empty_dict(tls):
                    self.generate(*tls_path)
                elif isinstance(tls, dict):
                    for key in ['auth-mode', 'ca-certificate', 'certificate', 'permitted-peer']:
                        if key not in tls:
                            continue
                        if self.operator == 'delete':
                            self.generate(*(tls_path + [key]))
                        else:
                            v = tls.get(key)
                            if v is None:
                                continue
                            self.generate(*(tls_path + [key, str(v)]))

            fac = opts.get('facility')
            if isinstance(fac, dict):
                for facility, fopts in fac.items():
                    facility_path = host_path + ['facility', str(facility)]

                    if self.operator == 'delete' and (fopts is None or _is_empty_dict(fopts) or not isinstance(fopts, dict) or fopts == {}):
                        self.generate(*facility_path)
                        continue
                    elif self.operator == 'set':
                        self.generate(*facility_path)

                    if isinstance(fopts, dict) and is_str_not_empty(fopts.get('level')):
                        if self.operator == 'delete':
                            self.generate(*(facility_path + ['level']))
                        else:
                            self.generate(*(facility_path + ['level', str(fopts.get('level'))]))

    def _process_marker(self, marker_cfg: Any):
        base_path = ['system', 'syslog', 'marker']
        if marker_cfg is None:
            return
        if _is_empty_dict(marker_cfg):
            self.generate(*base_path)
            return
        if not isinstance(marker_cfg, dict):
            return

        if 'disable' in marker_cfg:
            self.generate(*(base_path + ['disable']))

        if 'interval' in marker_cfg:
            if self.operator == 'delete':
                self.generate(*(base_path + ['interval']))
            else:
                v = marker_cfg.get('interval')
                if v is not None:
                    self.generate(*(base_path + ['interval', str(v)]))

    def _process_preserve_fqdn(self, preserve_cfg: Any):
        base_path = ['system', 'syslog', 'preserve-fqdn']
        if preserve_cfg is None:
            return

        self.generate(*base_path)
