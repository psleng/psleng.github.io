from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint
from copy import deepcopy
import json

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

def has_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ''
    return True

def is_int(value):
    return isinstance(value, int)

def format_description(description: str) -> str:
    return description

class OpenvpnCommand(IfaceCommand):
    """
    Command class for OpenVPN Interface:
    Extends the IfaceCommand class, it supports all of commands in IfaceCommand
    And extra commands specific to OpenVPN interface:

    - set/delete interfaces openvpn <interface-name> disable
    - set/delete interfaces openvpn <interface-name> mode {site-to-site | client | server}
    - set/delete interfaces openvpn <interface-name> <description>
    - set/delete interfaces openvpn <interface-name> device-type {tun | tap}
    - set/delete interfaces openvpn <interface-name> local-address <x.x.x.x | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> local-host <x.x.x.x| h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> local-port <1-65535>
    - set/delete interfaces openvpn <interface-name> protocol {udp | tcp-passive | tcp-active}
    - set/delete interfaces openvpn <interface-name> remote-address <x.x.x.x | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> remote-host <x.x.x.x | h:h:h:h:h:h:h:h | host-name>
    - set/delete interfaces openvpn <interface-name> remote-port <1-65535>

    # Server mode commands
    - set/delete interfaces openvpn <interface-name> server client <client-name> {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces openvpn <interface-name> server client <client-name> push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server client <client-name> subnet {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server client-ip-pool disable
    - set/delete interfaces openvpn <interface-name> server client-ip-pool start <n.n.n.n>
    - set/delete interfaces openvpn <interface-name> server client-ip-pool stop <n.n.n.n>
    - set/delete interfaces openvpn <interface-name> server client-ip-pool subnet-mask <m.m.m.m>
    - set/delete interfaces openvpn <interface-name> server client-ipv6-pool disable
    - set/delete interfaces openvpn <interface-name> server client-ipv6-pool base <h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> server domain-name <domain>
    - set/delete interfaces openvpn <interface-name> server max-connections <1-4096>
    - set/delete interfaces openvpn <interface-name> server name-server  {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces openvpn <interface-name> server push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x} metric <0-4294967295>
    - set/delete interfaces openvpn <interface-name> server reject-unconfigured-clients
    - set/delete interfaces openvpn <interface-name> server subnet {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server topology {subnet | point-to-point}

    # Security commands
    - set/delete interfaces openvpn <interface-name> tls auth-key <key-name>
    - set/delete interfaces openvpn <interface-name> tls ca-certificate <ca-cert-name>
    - set/delete interfaces openvpn <interface-name> tls certificate <cert-name>
    - set/delete interfaces openvpn <interface-name> tls crypt-key <key-name>
    - set/delete interfaces openvpn <interface-name> tls dh-params <dh-params-name>
    - set/delete interfaces openvpn <interface-name> tls peer-fingerprint <finger-print>
    - set/delete interfaces openvpn <interface-name> tls role {active | passive}
    - set/delete interfaces openvpn <interface-name> tls tls-version-min {1.0 | 1.1 | 1.2 ….}
    - set/delete interfaces openvpn <interface-name> encryption cipher {none | 3des …}
    - set/delete interfaces openvpn <interface-name> encryption data-ciphers {none | 3des …}
    - set/delete interfaces openvpn <interface-name> hash {md5 | sha1 …}
    - set/delete interfaces openvpn <interface-name> shared-secret-key <key>

    # Advanced commands
    - set/delete interfaces openvpn <interface-name> ip-version {auto | ipv4 | ipv6}
    - set/delete interfaces openvpn <interface-name> keep-alive failure-count <0-1000>
    - set/delete interfaces openvpn <interface-name> keep-alive interval <0-600>
    - set/delete interfaces openvpn <interface-name> persistent-tunnel
    - set/delete interfaces openvpn <interface-name> use-lzo-compression
    - set/delete interfaces openvpn <interface-name> replace-default-route local 1


    """
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'openvpn'),
                name=self.name
            )
            self.attributes = {
                'interfaces': {
                    'openvpn': {
                        self.name: {}
                    }
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing OpenVPN command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        command = {
            "op": self.operator,
            "path": [str(element) for element in path_elements]
        }
        return json.dumps(command)

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []
        # current_config is None: create new config
        # current_config is not None: update config
        curr_config = deepcopy(current_config) if current_config else deepcopy(data)
        

        self.attributes['interfaces']['openvpn'] = data

        for iface_name, iface_config in self.attributes['interfaces']['openvpn'].items():
            base_path = ['interfaces', 'openvpn', iface_name]

            mode = iface_config.get('mode') or curr_config.get('mode')

            if self.operator == 'delete' and iface_name not in new_config:
                self.generate(*base_path)
                continue

            simple_keys = [
                'disable',
                'persistent-tunnel',
                'use-lzo-compression',
            ]

            if 'mode' in iface_config:
                value = iface_config['mode']
                if isinstance(value, str) and is_str_not_empty(value):
                    self.generate(*base_path, 'mode', value)
            if 'shared-secret-key' in iface_config and is_str_not_empty(iface_config['shared-secret-key']):
                self.generate(*base_path, 'shared-secret-key', iface_config['shared-secret-key'])
            if 'description' in iface_config and has_value(iface_config['description']):
                self.generate(*base_path, 'description', format_description(iface_config['description']))
            if 'device-type' in iface_config:
                if isinstance(iface_config['device-type'], str) and is_str_not_empty(iface_config['device-type']):
                    self.generate(*base_path, 'device-type', iface_config['device-type'])
            if 'local-address' in iface_config:
                if isinstance(iface_config['local-address'], dict):
                    for ip_addr in iface_config['local-address'].keys():
                        self.generate(*base_path, 'local-address', ip_addr)
            for key in simple_keys:
                if key in iface_config:
                    value = iface_config[key]
                    if isinstance(value, dict) and not value:
                        self.generate(*base_path, key)
                    elif (isinstance(value, str) or isinstance(value, int)) and is_str_not_empty(value):
                        self.generate(*base_path, key, value)
            if 'local-host' in iface_config and mode != 'client':
                if isinstance(iface_config['local-host'], list):
                    for host in iface_config['local-host']:
                        if isinstance(host, str) and is_str_not_empty(host):
                            self.generate(*base_path, 'local-host', host)
                elif isinstance(iface_config['local-host'], str) and is_str_not_empty(iface_config['local-host']):
                    self.generate(*base_path, 'local-host', iface_config['local-host'])
            if 'local-port' in iface_config and is_str_not_empty(iface_config['local-port']) and mode != 'client':
                self.generate(*base_path, 'local-port', iface_config['local-port'])
            if 'protocol' in iface_config:
                if isinstance(iface_config['protocol'], str) and is_str_not_empty(iface_config['protocol']):
                    self.generate(*base_path, 'protocol', iface_config['protocol'])
            if 'remote-address' in iface_config:
                if (isinstance(iface_config['remote-address'], str) or isinstance(iface_config['remote-address'], int)) and is_str_not_empty(iface_config['remote-address']):
                    self.generate(*base_path, 'remote-address', iface_config['remote-address'])
            if 'remote-host' in iface_config and mode != 'server':
                if isinstance(iface_config['remote-host'], list):
                    for host in iface_config['remote-host']:
                        if isinstance(host, str) and is_str_not_empty(host):
                            self.generate(*base_path, 'remote-host', host)
                elif isinstance(iface_config['remote-host'], str) and is_str_not_empty(iface_config['remote-host']):
                    self.generate(*base_path, 'remote-host', iface_config['remote-host'])
            if 'remote-port' in iface_config and mode != 'server':
                if (isinstance(iface_config['remote-port'], str) or isinstance(iface_config['remote-port'], int)) and is_str_not_empty(iface_config['remote-port']):
                    self.generate(*base_path, 'remote-port', iface_config['remote-port'])
            if 'hash' in iface_config:
                if isinstance(iface_config['hash'], str) and is_str_not_empty(iface_config['hash']):
                    self.generate(*base_path, 'hash', iface_config['hash'])
            if 'ip-version' in iface_config:
                if isinstance(iface_config['ip-version'], str) and is_str_not_empty(iface_config['ip-version']):
                    self.generate(*base_path, 'ip-version', iface_config['ip-version'])
            if 'keep-alive' in iface_config:
                self._process_keep_alive_config(base_path, iface_config['keep-alive'])
            # if 'persistent-tunnel' in iface_config:
            #     self.generate(*base_path, 'persistent-tunnel')
            # if 'use-lzo-compression' in iface_config:
            #     self.generate(*base_path, 'use-lzo-compression')
            if 'server' in iface_config:
                new_mode = None
                if isinstance(new_config, dict):
                    new_iface = new_config.get(iface_name)
                    if isinstance(new_iface, dict):
                        new_mode = new_iface.get('mode')
                if self.operator == 'delete' and new_mode is not None and new_mode != 'server':
                    self.generate(*base_path, 'server')
                elif self.operator == 'delete' or mode == 'server':
                    self._process_server_config(base_path, iface_config['server'])
            if 'tls' in iface_config:
                self._process_tls_config(base_path, iface_config['tls'], iface_config, curr_config)
            if 'encryption' in iface_config:
                self._process_encryption_config(base_path, iface_config['encryption'])
            if 'replace-default-route' in iface_config:
                self.generate(*base_path, 'replace-default-route', 'local', '1')

        print(f"Generated commands: {self.cmds}")
        return self.cmds

    def _process_server_config(self, base_path, server_config):
        server_base_path = base_path + ['server']
        for key, value in server_config.items():
            if key == 'client':
                for client_name, client_config in value.items():
                    client_path = server_base_path + ['client', client_name]
                    if 'ip' in client_config:
                        self.generate(*client_path, 'ip', client_config['ip'])
                    if 'push-route' in client_config:
                        if isinstance(client_config['push-route'], list):
                            for route in client_config['push-route']:
                                self.generate(*client_path, 'push-route', route)
                        elif isinstance(client_config['push-route'], str):
                            self.generate(*client_path, 'push-route', client_config['push-route'])
                    if 'subnet' in client_config:
                        if isinstance(client_config['subnet'], list):
                            for subnet in client_config['subnet']:
                                self.generate(*client_path, 'subnet', subnet)
                        elif isinstance(client_config['subnet'], str):
                            self.generate(*client_path, 'subnet', client_config['subnet'])
            elif key in ['client-ip-pool', 'client-ipv6-pool'] and value.get('disabled') is False:
                pool_path = server_base_path + [key]
                for pool_key, pool_value in value.items():
                    if pool_key != 'disabled' and pool_value != '' and pool_value is not None:
                        self.generate(*pool_path, pool_key, pool_value)
            elif key == 'push-route':
                if isinstance(value, list): 
                    for route in value:
                        self.generate(*server_base_path, 'push-route', route)
                elif isinstance(value, str):
                    self.generate(*server_base_path, 'push-route', value)
            elif key in ['domain-name', 'topology']:
                if (isinstance(value, str) or isinstance(value, int)) and is_str_not_empty(value):
                    self.generate(*server_base_path, key, value)
            elif key == 'max-connections':
                try:
                    max_conn = int(value)
                    if max_conn > 0 and max_conn < 4096:
                        self.generate(*server_base_path, key, str(max_conn))
                except (ValueError, TypeError):
                    pass
            elif key == 'name-server':
                if isinstance(value, list):
                    for ns in value:
                        self.generate(*server_base_path, 'name-server', ns)
                elif isinstance(value, str) and value:
                    self.generate(*server_base_path, 'name-server', value)
            elif key == 'subnet':
                if isinstance(value, list):
                    for subnet in value:
                        self.generate(*server_base_path, 'subnet', subnet)
                elif isinstance(value, str) and value:
                    self.generate(*server_base_path, 'subnet', value)
            elif key == 'reject-unconfigured-clients':
                if (isinstance(value, bool) and value) or isinstance(value, dict):
                    self.generate(*server_base_path, 'reject-unconfigured-clients')

    def _process_tls_config(self, base_path, tls_config, iface_config, curr_config):
        tls_base_path = base_path + ['tls']
        mode = iface_config.get('mode') or curr_config.get('mode')
        for key, value in tls_config.items():
            if key == 'ca-certificate':
                if isinstance(value, str) and value:
                    self.generate(*tls_base_path, 'ca-certificate', value)
            elif key == 'certificate':
                if isinstance(value, str) and value:
                    self.generate(*tls_base_path, 'certificate', value)
            elif key == 'peer-fingerprint':
                if isinstance(value, list):
                    for fingerprint in value:
                        if fingerprint:  # Skip empty strings
                            self.generate(*tls_base_path, 'peer-fingerprint', fingerprint)
                elif isinstance(value, str) and value:
                    self.generate(*tls_base_path, 'peer-fingerprint', value)
            elif key == 'auth-key' and value:
                if isinstance(value, list):
                    for authKey in value:
                        if authKey:
                            self.generate(*tls_base_path, 'auth-key', authKey)
                elif isinstance(value, str) and value:
                    self.generate(*tls_base_path, 'auth-key', value)
            elif key == 'crypt-key' and value:
                if isinstance(value, list):
                    for cryptKey in value:
                        if cryptKey:
                            self.generate(*tls_base_path, 'crypt-key', cryptKey)
                elif isinstance(value, str) and value:
                    self.generate(*tls_base_path, 'crypt-key', value)
            elif key == 'dh-params' and value and value != "" and mode != 'client':
                self.generate(*tls_base_path, 'dh-params', value)
            elif key == 'role' and value and mode not in ['client', 'server']:
                self.generate(*tls_base_path, 'role', value)
            elif key == 'tls-version-min' and value and value != "":
                self.generate(*tls_base_path, 'tls-version-min', value)

    def _process_encryption_config(self, base_path, encryption_config):
        enc_base_path = base_path + ['encryption']
        for key, value in encryption_config.items():
            if key == 'data-ciphers':
                if isinstance(value, list):
                    for cipher in value:
                        if cipher:  # Skip empty strings
                            self.generate(*enc_base_path, 'data-ciphers', cipher)
                elif isinstance(value, str) and value:
                    self.generate(*enc_base_path, 'data-ciphers', value)
            elif key in ('cipher', 'data-ciphers-fallback') and value:
                self.generate(*enc_base_path, key, value)

    def _process_keep_alive_config(self, base_path, keep_alive_config):
        ka_base_path = base_path + ['keep-alive']
        for key, value in keep_alive_config.items():
            if has_value(value):
                self.generate(*ka_base_path, key, value)

if __name__ == "__main__":
    pass
