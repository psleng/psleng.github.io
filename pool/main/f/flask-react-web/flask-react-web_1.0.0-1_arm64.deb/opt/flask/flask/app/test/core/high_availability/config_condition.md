# CONFIG CONDITION:

- Member VRRP group must not have health check when sync-group health is defined
- Always version 3 if IPV6 is used
- Password must be equal or less than 8 characters
- VRID is required
