import threading
from queue import Queue
from flask import Flask, session
from flask_socketio import SocketIO
from functools import wraps
from uuid import uuid4
from app.log.logger import logger
from app.config import global_config
from app.config.scheduler_constants import JOB_CONFIGS
from datetime import datetime, timedelta

class SocketManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        self.connected_clients = {}
        self.connected_guests = {}
        self.client_queue = Queue()
        self.socketio = None
        self.app = None
        self.socket_to_user = {}
        self.socket_to_web_session = {}
        
    def _clear_state(self):
        self.connected_clients = {}
        self.connected_guests = {}
        self.client_queue = Queue()
        self.socket_to_user = {}
        self.socket_to_web_session = {}

    def init_app(self, app, socketio):
        self.app = app
        self.socketio = socketio
        self._start_background_thread()

    def _start_background_thread(self):
        """Start the background thread for processing client messages"""
        def background_task():
            while True:
                try:
                    if not self.client_queue.empty():
                        sid, event, data = self.client_queue.get()
                        
                        try:
                            with self.app.app_context():
                                self.socketio.emit(event, data, room=sid)
                        except Exception as e:
                            logger.error(f"Error emitting to {sid}")
                            logger.error(str(e))
                        
                        self.client_queue.task_done()
                    
                    threading.Event().wait(0.1)
                except Exception as e:
                    logger.error("Background task error")
                    logger.error(str(e))

        thread = threading.Thread(target=background_task, daemon=True)
        thread.start()


    def register_client(self, sid, user_token, web_session_id=None):
        logger.debug("Register client")
        logger.debug(sid)
        logger.debug(user_token)
        
        was_empty = len(self.connected_clients) == 0
        
        # Ensure user's socket sessions are tracked
        if user_token not in self.connected_clients:
            self.connected_clients[user_token] = set()
        
        self.connected_clients[user_token].add(sid)
        self.socket_to_user[sid] = user_token
        if web_session_id:
            self.socket_to_web_session[sid] = web_session_id
            self.socketio.server.enter_room(sid, "web-authenticated", namespace="/")
            self.socketio.server.enter_room(sid, f"web-session:{web_session_id}", namespace="/")
            self.socketio.emit("aaa_sessions_changed", {}, to="web-authenticated")

        # Check software update (when login/open authorized page) 
        # --> socket is initialized or reconnected
        self._check_software_update_available()
        
        # Clients: 0 to 1, restore normal intervals and run jobs
        if was_empty and len(self.connected_clients) > 0:
            self._handle_first_client_connected()
        
        logger.debug("Registered client")
        logger.debug(user_token)
        logger.debug(sid)

    def _check_software_update_available(self):
        try:
            from app.event.jobs.system.software_update import check_software_update_available

            check_software_update_available(self.app.app_context())
        except Exception as e:
            logger.error(
                f"Failed to check software updates after socket connection: {str(e)}"
            )

    def remove_client(self, sid):
        """Remove a client from connected clients"""
        logger.debug("Remove client")
        logger.debug(sid)
        logger.debug("Socket to user")
        logger.debug(self.socket_to_user)
        # print("Connected clients", self.connected_clients)
        web_session_id = self.socket_to_web_session.pop(sid, None)
        if web_session_id and self.socketio:
            self.socketio.emit("aaa_sessions_changed", {}, to="web-authenticated")
        if sid in self.socket_to_user:
            user_token = self.socket_to_user[sid]
            
            if user_token in self.connected_clients:
                self.connected_clients[user_token].discard(sid)
                
                if not self.connected_clients[user_token]:
                    del self.connected_clients[user_token]
            
            del self.socket_to_user[sid]
            
            # Clients: 1 to 0, increase job intervals
            if len(self.connected_clients) == 0:
                self._handle_no_clients_connected()

    def web_session_connection_count(self, session_id):
        return sum(value == session_id for value in list(self.socket_to_web_session.values()))

    def disconnect_web_session(self, session_id):
        if not self.socketio:
            return
        self.socketio.emit(
            "session_revoked",
            {"message": "Your web session has ended. Please log in again."},
            to=f"web-session:{session_id}",
        )
        sockets = [sid for sid, value in list(self.socket_to_web_session.items()) if value == session_id]
        for sid in sockets:
            self.socketio.server.disconnect(sid, namespace="/")

    def emit_to_user(self, user_token, event, data):
        logger.debug("Connected clients")
        logger.debug(self.connected_clients)
        if user_token in self.connected_clients:
            logger.debug("All SID")
            logger.debug(self.connected_clients[user_token])
            for sid in self.connected_clients[user_token]:
                self.client_queue.put((sid, event, data))

    def emit_to_all(self, event, data):
        # Emit to all authenticated users
        # Do not emit to guests
        for user_token, sids in (self.connected_clients or {}).items():
            for sid in sids:
                self.client_queue.put((sid, event, data))

    def register_guest(self, sid):
        logger.debug("Register guest")
        logger.debug(sid)
        # Ensure user's socket sessions are tracked
        if sid not in self.connected_guests:
            self.connected_guests[sid] = {"SSID": sid}
        
        self.connected_guests[sid].update({"SSID": sid})


    def remove_guest(self, sid):
        logger.debug("Remove guest")
        logger.debug(sid)
        if sid in self.connected_guests:
            del self.connected_guests[sid]

    def emit_to_guest(self, ssid, event, data):
        logger.debug("Connected guests")
        logger.debug(self.connected_guests)
        for sid, v in self.connected_guests.items():
            if sid == ssid:
                self.client_queue.put((sid, event, data))


    def emit_test(self, sid, event, data):
        try:
            logger.debug("=== Emit Test ===")
            self.client_queue.put((sid, event, data))
        except Exception as e:
            logger.error("Emit test error")
            logger.error(str(e))

    def emit_to_client(self, sid, event, data):
        """Queue a message to a specific client socket session"""
        if sid:
            self.client_queue.put((sid, event, data))

    def _executor_for_job_id(self, job_id: str) -> str:
        if job_id == 'fetch_load_average_history':
            return 'fetch_system_health'
        if job_id == 'check_vyos_http_api':
            return 'fetch_system_health'
        elif job_id == 'fetch_storage':
            return 'fetch_system_health'
        elif job_id == 'save_recent_config':
            return 'config_save'
        return 'main'

    def clear(self):
        self._clear_state()

    def get_connected_clients(self):
        return self.connected_clients

    def get_connected_guests(self):
        return self.connected_guests

    def _get_scheduler_backend(self, scheduler):
        backend = scheduler
        if not hasattr(backend, 'reschedule_job') and hasattr(scheduler, 'scheduler'):
            backend = scheduler.scheduler
        return backend

    def _handle_first_client_connected(self):
        logger.debug("First client connected - restoring normal job intervals and running jobs")
        try:
            if hasattr(global_config, 'app_scheduler') and global_config.app_scheduler is not None:
                scheduler = global_config.app_scheduler
                backend = self._get_scheduler_backend(scheduler)
                
                # Restore normal intervals and run jobs once
                for job_id, original_interval in JOB_CONFIGS.items():
                    job = scheduler.get_job(job_id)
                    if job:
                        executor = self._executor_for_job_id(job_id)
                        try:
                            backend.reschedule_job(
                                job_id,
                                trigger="interval",
                                seconds=original_interval,
                            )
                        except Exception as e:
                            logger.error(f"Failed to reschedule job {job_id}: {str(e)}")
                            scheduler.remove_job(job_id)
                            scheduler.add_job(
                                id=job_id,
                                func=job.func,
                                args=job.args,
                                trigger="interval",
                                seconds=original_interval,
                                executor=executor,
                                replace_existing=True,
                            )
                        logger.debug(f"Restored job {job_id} interval to {original_interval} seconds")

                        try:
                            immediate_job_id = f"{job_id}__immediate"
                            backend.add_job(
                                id=immediate_job_id,
                                func=job.func,
                                args=job.args,
                                trigger="date",
                                run_date=datetime.now() + timedelta(seconds=1),
                                misfire_grace_time=10,
                                coalesce=True,
                                max_instances=1,
                                executor=executor,
                                replace_existing=True,
                            )
                            logger.debug(f"Triggered immediate run of job {job_id}")
                        except Exception as e:
                            logger.error(f"Failed to schedule immediate run for job {job_id}: {str(e)}")
                    else:
                        logger.warning(f"Job {job_id} not found in scheduler")
        except Exception as e:
            logger.error(f"Error handling first client connection: {str(e)}")

    def _handle_no_clients_connected(self):
        logger.debug("No clients connected - increasing job intervals by 3 hours")
        try:
            if hasattr(global_config, 'app_scheduler') and global_config.app_scheduler is not None:
                scheduler = global_config.app_scheduler
                backend = self._get_scheduler_backend(scheduler)
                
                # Add 10800 seconds (3 hours) to each job interval
                for job_id, original_interval in JOB_CONFIGS.items():
                    job = scheduler.get_job(job_id)
                    if job:
                        new_interval = original_interval + 10800
                        executor = self._executor_for_job_id(job_id)
                        try:
                            backend.reschedule_job(
                                job_id,
                                trigger="interval",
                                seconds=new_interval,
                            )
                        except Exception as e:
                            logger.error(f"Failed to reschedule job {job_id}: {str(e)}")
                            scheduler.remove_job(job_id)
                            scheduler.add_job(
                                id=job_id,
                                func=job.func,
                                args=job.args,
                                trigger="interval",
                                seconds=new_interval,
                                executor=executor,
                                replace_existing=True,
                            )
                        logger.debug(f"Increased job {job_id} interval from {original_interval} to {new_interval} seconds")
                    else:
                        logger.warning(f"Job {job_id} not found in scheduler")
        except Exception as e:
            logger.error(f"Error handling no clients connected: {str(e)}")
        
socket_manager = SocketManager()
