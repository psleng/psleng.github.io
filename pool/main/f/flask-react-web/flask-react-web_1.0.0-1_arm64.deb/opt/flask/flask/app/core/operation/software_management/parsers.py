from urllib.parse import urlparse


def parse_to_vyos_config(data):
    url = data.get("url", "").strip()
    if url:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ValueError("Enter a valid HTTP or HTTPS URL")

    config = {}
    if data.get("autoCheck"):
        config["auto-check"] = {}
    if url:
        config["url"] = url
    return config
