from app.log.logger import logger

def is_not_empty_str(value):
    return isinstance(value, str) and value.strip() != ""

def parse_to_wireguard_config(data):
    config = {}

    if 'name' in data and is_not_empty_str(data['name']):
        config['name'] = data['name']
    if 'description' in data and is_not_empty_str(data['description']):
        config['description'] = data['description']
    if 'address' in data and isinstance(data['address'], list):
        config['address'] = []
        for addr in data['address']:
            if is_not_empty_str(addr):
                config['address'].append(addr.strip())
    if 'listen_port' in data:
        config['port'] = data['listen_port']
    if 'private_key' in data:
        config['private-key'] = data['private_key']
    if 'public_key' in data:
        config['public-key'] = data['public_key']
    if 'dns_retry' in data and data['dns_retry'] and isinstance(int(data['dns_retry']), int) and int(data['dns_retry']) >= 1 and int(data['dns_retry']) <= 15:
        config['max-dns-retry'] = data['dns_retry']
    if 'mtu' in data and data['mtu'] and isinstance(int(data['mtu']), int) and int(data['mtu']) >= 68 and int(data['mtu']) <= 16000:
        config['mtu'] = data['mtu']
    if 'disable' in data:
        config['disable'] = data['disable']
    if 'peer' in data and data['peer'] is not None:
        config['peer'] = {}
        for peer_data in data['peer']:
            if peer_data is None:
                continue
            if 'name' not in peer_data or not is_not_empty_str(peer_data['name']):
                continue
            
            peer_config = {}
            if 'description' in peer_data and is_not_empty_str(peer_data['description']):
                peer_config['description'] = peer_data['description']
            if 'address' in peer_data and is_not_empty_str(peer_data['address']):
                peer_config['address'] = peer_data['address']
            if 'allowed_ips' in peer_data and isinstance(peer_data['allowed_ips'], list):
                peer_config['allowed-ips'] = peer_data['allowed_ips']
            if 'host_name' in peer_data and is_not_empty_str(peer_data['host_name']):
                peer_config['host-name'] = peer_data['host_name']
            if 'public_key' in peer_data and is_not_empty_str(peer_data['public_key']):
                peer_config['public-key'] = peer_data['public_key']
            if 'persistent_keepalive' in peer_data and is_not_empty_str(peer_data['persistent_keepalive']):
                peer_config['persistent-keepalive'] = peer_data['persistent_keepalive']
            if 'port' in peer_data and isinstance(peer_data['port'], int) and peer_data['port'] >= 1 and peer_data['port'] <= 65535:
                peer_config['port'] = peer_data['port']
            if 'preshared_key' in peer_data and is_not_empty_str(peer_data['preshared_key']):
                peer_config['preshared-key'] = peer_data['preshared_key']
            config['peer'][peer_data['name']] = peer_config

    return config


def parse_current_wireguard_interface_config(os_config, name):
    wireguard_config = os_config.get('interfaces', {}).get('wireguard', {}).get(name, {})
    logger.debug("Current wireguard config: ")
    logger.debug(wireguard_config)
    return wireguard_config


def parse_current_all_wireguard_interfaces_config(interface_config: dict):
    config = {}
    if not interface_config:
        return config
    wireguard_section = interface_config.get('interfaces', {}).get('wireguard', {})
    if not isinstance(wireguard_section, dict):
        return config

    for interface, interface_conf in wireguard_section.items():
        if not isinstance(interface_conf, dict):
            continue
        entry = dict(interface_conf)
        config[interface] = entry

    return config


def parse_to_wireguard_bulk_config(interfaces_data) -> dict:
    bulk_config: dict = {'interfaces': {'wireguard': {}}}
    if not interfaces_data:
        return bulk_config

    for iface in interfaces_data:
        if iface is None:
            continue
        if hasattr(iface, 'model_dump'):
            iface_dict = iface.model_dump()
        elif isinstance(iface, dict):
            iface_dict = iface
        else:
            continue

        name = iface_dict.get('name')
        if not name:
            continue

        parsed = parse_to_wireguard_config(iface_dict)
        bulk_config['interfaces']['wireguard'][name] = parsed

    return bulk_config


def parse_wireguard_key_pair(data):
    """
    Sample data: 
    "data": "Private key: <private_key>\nPublic key: <public_key>\n\n"
    """
    result = {
        "public_key": '',
        "private_key": ''
    }
    lines = data.strip().split('\n')
    for line in lines:
        if line.startswith('Private key:'):
            result['private_key'] = line.split(':', 1)[1].strip()
        elif line.startswith('Public key:'):
            result['public_key'] = line.split(':', 1)[1].strip()
    return result

def parse_wireguard_pre_shared_key(data):
    """
    Sample data: 
    "data": "Pre-shared key: <pre_shared_key>\n"
    """

    result = {
        "preshared_key": ''
    }
    lines = data.strip().split('\n')
    for line in lines:
        if line.startswith('Pre-shared key:'):
            result['preshared_key'] = line.split(':', 1)[1].strip()
    return result


def parse_wireguard_monitor_info(data):
    logger.debug("Wireguard monitor info: ")
    logger.debug(data)

    result = []
    if not data or 'ShowWireguardInterfacesWireguardQuery' not in data or \
        not data['ShowWireguardInterfacesWireguardQuery']:
        return result

    interfaces = data['ShowWireguardInterfacesWireguardQuery'].get('data', {}).get('result', [])
    for iface in interfaces:
        if not iface:
            continue

        ifname = iface.get('ifname')
        flags = iface.get('flags', [])
        mtu = iface.get('mtu')

        local_addresses = []
        for addr in iface.get('addr_info', []):
            local_addresses.append(f"{addr.get('local')}/{addr.get('prefixlen')}")

        stats = iface.get('stats', {})
        rx_bytes = stats.get('rx_bytes')
        rx_packets = stats.get('rx_packets')
        rx_errors = stats.get('rx_errors')
        tx_bytes = stats.get('tx_bytes')
        tx_packets = stats.get('tx_packets')
        tx_errors = stats.get('tx_errors')

        # Peers
        peers_info = []
        if 'wireguard' in iface and iface['wireguard'] and 'peers' in iface['wireguard']:
            for peer in iface['wireguard']['peers']:
                peers_info.append({
                    'peer_address': peer.get('peer'),
                    'listening_port': iface.get('wireguard', {}).get('listening_port'),
                    'endpoint': peer.get('endpoint'),
                    'allowed_ips': peer.get('allowed_ips', []),
                    'public_key': iface.get('wireguard', {}).get('public_key'),
                    'sent': peer.get('transfer_tx'),
                    'received': peer.get('transfer_rx')
                })

        result.append({
            'ifname': ifname,
            'flags': flags,
            'mtu': mtu,
            'local_addresses': local_addresses,
            'rx_bytes': rx_bytes,
            'rx_packets': rx_packets,
            'rx_errors': rx_errors,
            'tx_bytes': tx_bytes,
            'tx_packets': tx_packets,
            'tx_errors': tx_errors,
            'peers': peers_info
        })

    return result