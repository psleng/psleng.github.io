from app.core.operation.openvpn.command_openvpn import OpenvpnCommand
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_OPENVPN_GENERATE_SHARED_SECRET
from app.core.operation.openvpn.parser import parse_openvpn_shared_secret, parse_current_all_openvpn_interfaces_config
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
import pprint
from flask import session
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from app.core.models import InterfaceConfig
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig
from app.db.database import db

def normalize_openvpn_refresh_config(name, config):
    if not isinstance(config, dict):
        return {}

    if isinstance(config.get('interfaces'), dict):
        interfaces_config = config['interfaces']
        if isinstance(interfaces_config.get('openvpn'), dict):
            return interfaces_config.get('openvpn', {})

    if isinstance(config.get('openvpn'), dict):
        return config.get('openvpn', {})

    if name in config and isinstance(config.get(name), dict):
        return config

    return {name: config}


def create_openvpn_shared_secret(provider, data):
    res = provider.http_service.send_request(action=Action.GENERATE, data=SHOW_OPENVPN_GENERATE_SHARED_SECRET, verify=False)
    return parse_openvpn_shared_secret(res.json().get('data', ''))


def fetch_openvpn(provider, data):
    try:
        response = provider.http_service.show_all_configs()
        config = response.json().get('data', {}) if response and hasattr(response, 'json') else {}
    except Exception:
        config = {}
    if not isinstance(config, dict):
        return {}
    parsed = parse_current_all_openvpn_interfaces_config(config)
    return {'interfaces': {'openvpn': parsed}}

def verify_openvpn(provider, data):
    print("Verify openvpn:")
    print(pprint.pformat(data, indent=2, width=80))
    name = data.get('name')
    config = data.get('config')
    
    iface_cmd = OpenvpnCommand(operator='set', resource='interfaces', name=name)
    iface_cmd.generate_commands(data={name: config})
    commands = iface_cmd.get_commands()
    
    processed = process_commands(commands)
    normalized_config = (processed.get('interfaces') or {}).get('openvpn', {}).get(name, {})

    pki = provider.verify_service.call_get_config("pki")
    normalized_config['pki'] = pki
    normalized_config['ifname'] = name

    verify = provider.verify_service.call_verify_interface("openvpn", name, normalized_config)
    return verify

def create_openvpn_interface(provider, data):
    print("Create openvpn:")
    print(data)
    username = session['username']
    name = data.get('name')
    config = data.get('config')
    set_cmds = []
    iface_set_cmd = OpenvpnCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands(data={name: config})
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    
    # Validate configs
    service = "openvpn"
    merged_config = merge_dicts_set({}, new_set_configs.get('interfaces', {}))    

    verify = None
    if merged_config and merged_config.get('openvpn', {}).get(name, None):
        pki = provider.verify_service.call_get_config("pki")
        merged_config['openvpn'][name]['pki'] = pki
        merged_config['openvpn'][name]['ifname'] = name
        verify = provider.verify_service.call_verify(
            service, 
            merged_config.get('openvpn', {}).get(name, None)
        )
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    r = []
    cmds = set_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    if any(item.get('success') is not True for item in r):
        return r

    InterfaceConfig.upsert({
        'openvpn': {
            name: config
        }
    })

    OpenVPNInterfaceConfig.upsert({name: config})

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Create OpenVPN",
                "content": "OpenVPN is successfully updated"
            }
    )
    
    return r


def update_openvpn(provider, data):
    print("Update openvpn (bulk):")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    new_config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}

    if not isinstance(new_config, dict):
        new_config = {}
    if not isinstance(current_config, dict):
        current_config = {}
    if not isinstance(diff, dict):
        diff = {}

    new_openvpn = (new_config.get('interfaces') or {}).get('openvpn') or {}
    current_openvpn = (current_config.get('interfaces') or {}).get('openvpn') or {}
    diff_created = ((diff.get('created') or {}).get('interfaces') or {}).get('openvpn') or {}
    diff_deleted = ((diff.get('deleted') or {}).get('interfaces') or {}).get('openvpn') or {}

    if not isinstance(new_openvpn, dict):
        new_openvpn = {}
    if not isinstance(current_openvpn, dict):
        current_openvpn = {}
    if not isinstance(diff_created, dict):
        diff_created = {}
    if not isinstance(diff_deleted, dict):
        diff_deleted = {}

    all_set_cmds: list = []
    all_delete_cmds: list = []
    sc: list = []
    dc: list = []
    new_set_configs: dict = {}
    new_delete_configs: dict = {}

    for name, iface_config in new_openvpn.items():
        iface_created = diff_created.get(name, iface_config) or {}
        iface_current = current_openvpn.get(name, {}) or {}
        iface_set_cmd = OpenvpnCommand(operator='set', resource='interfaces', name=name)
        _set_cmds = iface_set_cmd.generate_commands(
            data={name: iface_created},
            current_config=iface_current,
            new_config=new_openvpn,
        )
        all_set_cmds.extend(_set_cmds)
        sc.extend(iface_set_cmd.get_commands())

    if sc:
        processed = process_commands(sc)
        new_set_configs = merge_dicts_set(new_set_configs, processed)

    for name, iface_deleted in diff_deleted.items():
        iface_current = current_openvpn.get(name, {}) or {}
        iface_delete_cmd = OpenvpnCommand(operator='delete', resource='interfaces', name=name)
        _del_cmds = iface_delete_cmd.generate_commands(
            data={name: iface_deleted},
            current_config=iface_current,
            new_config=new_openvpn,
        )
        all_delete_cmds.extend(_del_cmds)
        dc.extend(iface_delete_cmd.get_commands())

    if dc:
        processed = process_commands(dc)
        new_delete_configs = merge_dicts_delete(new_delete_configs, processed, aggressive=True)
                
    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "openvpn"
    curr_configs = {
        "interfaces": {
            "openvpn": {}
        }
    }
    for openvpn_name in current_openvpn:
        curr_config = provider.verify_service.query_interface_config(service, openvpn_name)
        curr_configs["interfaces"]["openvpn"][openvpn_name] = curr_config

    print("Current interfaces configs: ")
    print(pprint.pformat(curr_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        curr_configs, new_delete_configs, clean_empty=False, remove_values=True,
    )
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    print("Merged config:")
    print(pprint.pformat(merged_config, indent=2, width=80))

    # Get PKI config once for all interfaces
    pki = provider.verify_service.call_get_config("pki")

    verify = {}
    openvpn_configs = (merged_config.get('interfaces') or {}).get('openvpn') or {}
    for iface_name, iface_config in openvpn_configs.items():
        if not iface_config or not isinstance(iface_config, dict):
            continue
        # Add pki and ifname to each interface config for verification
        iface_config['pki'] = pki
        iface_config['ifname'] = iface_name
        verify_result = provider.verify_service.query_interface_verify(
            service, 
            iface_name,
            iface_config
        )
        if verify_result and str(verify_result) != "None" and str(verify_result) != "":
            verify[iface_name] = verify_result

    print("Verify:")
    print(pprint.pformat(verify, indent=2, width=80))

    excecuted_cmds = list(set(all_delete_cmds)) + list(set(all_set_cmds))

    if any(str(v) != "None" and str(v) != "" and v != {} for v in verify.values()):
        return [{"success": False, "error": verify, "cmd": excecuted_cmds}]


    r: list = []
    print("Commands:")
    print(pprint.pformat(excecuted_cmds, indent=2, width=80))

    if len(excecuted_cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=excecuted_cmds, verify=False).json()
        r.append({"cmd": excecuted_cmds, "success": res.get('success'), "error": res.get('error')})

    if any(item.get('success') is not True for item in r):
        return r

    new_interfaces_section = (new_config.get('interfaces') or {})
    normalized = normalize_openvpn_refresh_config(None, new_interfaces_section)
    InterfaceConfig.upsert({'openvpn': normalized})
    OpenVPNInterfaceConfig.refresh(normalized)

    # A deleted field in the diff does not mean its interface was removed.
    deleted_names = [name for name in diff_deleted if name not in new_openvpn]
    if deleted_names:
        InterfaceConfig.query.filter(
            InterfaceConfig.interface.in_(deleted_names),
            InterfaceConfig.interface_type.in_(['openvpn', 'OpenVPN'])
        ).delete(synchronize_session=False)
        db.session.commit()

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update OpenVPN",
            "content": "OpenVPN is successfully updated",
        },
    )

    return r


def update_openvpn_by_name(provider, data):
    print("Update openvpn by name")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    name = data.get('name')
    
    set_cmds = []
    iface_set_cmd = OpenvpnCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, {name: new_config})
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = OpenvpnCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, {name: new_config})
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "openvpn"
    curr_config = provider.verify_service.query_interface_config(service, name)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        current_config, new_delete_configs.get('interfaces', {}).get('openvpn', {}).get(name, {}),
        clean_empty=False, remove_values=True,
    )
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}).get('openvpn', {}).get(name, {}))    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "":
        return [{
            "success": False, 
            "error": str(verify), 
            "cmd": list(set(delete_cmds)) + list(set(set_cmds))
        }]

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    r = []
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    if any(item.get('success') is not True for item in r):
        return r

    normalized_config = normalize_openvpn_refresh_config(name, new_config)

    InterfaceConfig.upsert({
        'openvpn': normalized_config
    })

    OpenVPNInterfaceConfig.upsert(normalized_config)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update OpenVPN",
                "content": "OpenVPN is successfully updated"
            }
    )
    
    return r
