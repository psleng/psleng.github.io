from datetime import datetime
import json
import os
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET
from typing import Any


VYOS_REPOSITORY_URL = "https://github.com/psleng/vyos-1x.git"
VYOS_BRANCH = "psl-master"
INTERFACE_DEFINITIONS_PATH = "interface-definitions"
DEFAULT_OUTPUT_FILE = pathlib.Path(__file__).with_name("default_values.json")
DEFAULT_OVERRIDE_FILE = pathlib.Path(__file__).with_name("default_values_override.json")


def _repo_root() -> pathlib.Path:
    current_file = pathlib.Path(__file__).resolve()

    for parent in current_file.parents:
        if (parent / "flask").exists() and (parent / "react").exists():
            return parent

    raise RuntimeError(f"Unable to find repository root from {current_file}")


FRONTEND_MINIFIED_OUTPUT_FILE = _repo_root() / "react" / "src" / "constants" / "default_values.min.json"


def _default_checkout_directory() -> pathlib.Path:
    return _repo_root() / "vyos" / "vyos-1x"


def _run_git(args: list[str], cwd: pathlib.Path | None = None) -> None:
    subprocess.run(["git", *args], cwd=cwd, check=True)


def pull_latest_interface_definitions(
    checkout_directory: str | pathlib.Path | None = None,
) -> pathlib.Path:
    """
    Clone or update the VyOS repository and return its interface-definitions path.

    The checkout is sparse, so only interface-definitions is downloaded.
    """
    checkout_path = pathlib.Path(checkout_directory or _default_checkout_directory()).resolve()

    if not (checkout_path / ".git").exists():
        checkout_path.parent.mkdir(parents=True, exist_ok=True)
        _run_git(
            [
                "clone",
                "--depth",
                "1",
                "--branch",
                VYOS_BRANCH,
                "--filter=blob:none",
                "--sparse",
                VYOS_REPOSITORY_URL,
                str(checkout_path),
            ]
        )
    else:
        _run_git(["fetch", "--depth", "1", "origin", VYOS_BRANCH], cwd=checkout_path)
        _run_git(["checkout", VYOS_BRANCH], cwd=checkout_path)
        _run_git(["pull", "--ff-only", "origin", VYOS_BRANCH], cwd=checkout_path)

    _run_git(["sparse-checkout", "set", INTERFACE_DEFINITIONS_PATH], cwd=checkout_path)
    return checkout_path / INTERFACE_DEFINITIONS_PATH


INCLUDE_PATTERN = re.compile(r"^(?P<indent>\s*)#include\s+<(?P<path>[^>]+)>\s*$", re.MULTILINE)


def _xml_text_with_expanded_includes(
    file_path: pathlib.Path,
    interface_definitions_path: pathlib.Path,
    include_stack: tuple[pathlib.Path, ...] = (),
) -> str:
    content = file_path.read_text(encoding="utf-8")

    def replace_include(match: re.Match[str]) -> str:
        include_path = (interface_definitions_path / match.group("path")).resolve()
        if include_path in include_stack or not include_path.exists():
            return ""

        expanded = _xml_text_with_expanded_includes(
            include_path,
            interface_definitions_path,
            (*include_stack, include_path),
        )
        indent = match.group("indent")
        return "\n".join(f"{indent}{line}" if line else line for line in expanded.splitlines())

    return INCLUDE_PATTERN.sub(replace_include, content)


def _child_default_value(element: ET.Element) -> str | None:
    for child in element:
        if child.tag == "defaultValue" and child.text is not None:
            return child.text.strip()

    return None


def _set_nested_default(target: dict[str, Any], path: list[str], default_value: str) -> None:
    current = target

    for name in path[:-1]:
        existing = current.get(name)
        if not isinstance(existing, dict):
            existing = {}
            current[name] = existing
        current = existing

    leaf_name = path[-1]
    current[leaf_name] = default_value


def _collect_default_values(element: ET.Element, path: list[str], target: dict[str, Any]) -> None:
    cli_path = path
    if element.tag in {"node", "tagNode", "leafNode"}:
        name = element.attrib.get("name")
        if name:
            cli_path = [*path, name]

    default_value = _child_default_value(element)
    if default_value is not None and cli_path:
        _set_nested_default(target, cli_path, default_value)

    for child in element:
        _collect_default_values(child, cli_path, target)


def extract_default_values_from_xml_in(root_directory: str | pathlib.Path) -> str:
    """
    Recursively find all *.xml.in files in root_directory and extract leafNode
    defaultValue tags into nested JSON that preserves their parent CLI nodes.

    Returns: JSON string format.
    """
    root_path = pathlib.Path(root_directory).resolve()
    results: dict[str, Any] = {}

    if not root_path.exists():
        return json.dumps({"error": f"Directory {root_directory} does not exist."}, indent=4)

    for file_path in sorted(root_path.rglob("*.xml.in")):
        try:
            document = ET.fromstring(_xml_text_with_expanded_includes(file_path, root_path))
            file_data: dict[str, Any] = {}
            _collect_default_values(document, [], file_data)

            if file_data:
                display_path = os.path.relpath(file_path.resolve(), root_path)
                results[display_path] = file_data

        except Exception:
            continue

    return json.dumps(results, indent=4)


def generate_default_values_json(
    output_file: str | pathlib.Path = DEFAULT_OUTPUT_FILE,
    checkout_directory: str | pathlib.Path | None = None,
) -> pathlib.Path:
    interface_definitions = pull_latest_interface_definitions(checkout_directory)
    json_output = extract_default_values_from_xml_in(interface_definitions)

    output_path = pathlib.Path(output_file).resolve()
    output_path.write_text(f"{json_output}\n", encoding="utf-8")
    generate_default_values_ini(output_path)
    return output_path


def generate_default_values_ini(
    default_values_file: str | pathlib.Path = DEFAULT_OUTPUT_FILE,
    generated_date: str | None = None,
) -> pathlib.Path:
    default_values_path = pathlib.Path(default_values_file).resolve()
    generated_date = generated_date or datetime.now().date().isoformat()
    metadata_path = default_values_path.with_name("default_values.ini")

    metadata_path.write_text(
        "[default_values]\n"
        f"generated_date = {generated_date}\n",
        encoding="utf-8",
    )
    return metadata_path


def _merge_default_value_overrides(default_values: Any, overrides: Any) -> Any:
    if isinstance(default_values, dict) and isinstance(overrides, dict):
        merged = dict(default_values)

        for key, override_value in overrides.items():
            merged[key] = _merge_default_value_overrides(merged.get(key), override_value)

        return merged

    return overrides


def apply_default_values_override(
    input_file: str | pathlib.Path = DEFAULT_OUTPUT_FILE,
    override_file: str | pathlib.Path = DEFAULT_OVERRIDE_FILE,
) -> pathlib.Path:
    input_path = pathlib.Path(input_file).resolve()
    override_path = pathlib.Path(override_file).resolve()

    if not override_path.exists():
        return input_path

    default_values = json.loads(input_path.read_text(encoding="utf-8"))
    overrides = json.loads(override_path.read_text(encoding="utf-8"))
    merged_default_values = _merge_default_value_overrides(default_values, overrides)

    input_path.write_text(
        f"{json.dumps(merged_default_values, indent=4)}\n",
        encoding="utf-8",
    )
    return input_path


def generate_minified_default_values_json(
    input_file: str | pathlib.Path = DEFAULT_OUTPUT_FILE,
    output_file: str | pathlib.Path = FRONTEND_MINIFIED_OUTPUT_FILE,
) -> pathlib.Path:
    input_path = pathlib.Path(input_file).resolve()
    default_values = json.loads(input_path.read_text(encoding="utf-8"))

    minified_output_path = pathlib.Path(output_file).resolve()
    minified_output_path.parent.mkdir(parents=True, exist_ok=True)
    minified_output_path.write_text(
        json.dumps(default_values, separators=(",", ":")),
        encoding="utf-8",
    )
    return minified_output_path


if __name__ == "__main__":
    backend_path = generate_default_values_json()
    backend_path = apply_default_values_override(backend_path)
    frontend_path = generate_minified_default_values_json(backend_path)
    print(f"Backend path: {backend_path}")
    print(f"Backend metadata path: {backend_path.with_name('default_values.ini')}")
    print(f"Frontend path: {frontend_path}")
