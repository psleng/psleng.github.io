from typing import Any, Dict, List


def _clean(value: Any) -> str:
    if value is None:
        return ''
    return str(value).strip()


def _as_bool(value: Any) -> bool:
    return value in (True, 'true', 'True', 'enable', 'enabled', 1, '1')


def parse_to_ndp_proxy_config(data: Dict[str, Any]) -> Dict[str, Any]:
    if not data or not isinstance(data, dict):
        return {}

    result: Dict[str, Any] = {}
    route_refresh = _clean(data.get('route_refresh'))
    if route_refresh:
        result['route-refresh'] = route_refresh

    interfaces_out: Dict[str, Any] = {}
    interfaces = data.get('interfaces') or []
    if not isinstance(interfaces, list):
        interfaces = []

    for intf in interfaces:
        if not isinstance(intf, dict):
            continue
        name = _clean(intf.get('name') or intf.get('interface'))
        if not name:
            continue

        intf_out: Dict[str, Any] = {}
        if intf.get('enabled') is False:
            intf_out['disable'] = {}
        if _as_bool(intf.get('enable_router_bit')):
            intf_out['enable-router-bit'] = {}

        timeout = _clean(intf.get('timeout'))
        if timeout:
            intf_out['timeout'] = timeout

        ttl = _clean(intf.get('ttl'))
        if ttl:
            intf_out['ttl'] = ttl

        prefixes_out: Dict[str, Any] = {}
        prefixes = intf.get('prefixes') or []
        if not isinstance(prefixes, list):
            prefixes = []

        for prefix in prefixes:
            if not isinstance(prefix, dict):
                continue
            value = _clean(prefix.get('value') or prefix.get('prefix'))
            if not value:
                continue

            prefix_out: Dict[str, Any] = {}
            if prefix.get('enabled') is False:
                prefix_out['disable'] = {}

            mode = _clean(prefix.get('mode'))
            if mode:
                prefix_out['mode'] = mode

            proxy_interface = _clean(prefix.get('interface'))
            if proxy_interface:
                prefix_out['interface'] = proxy_interface

            prefixes_out[value] = prefix_out

        if prefixes_out:
            intf_out['prefix'] = prefixes_out

        interfaces_out[name] = intf_out

    if interfaces_out:
        result['interface'] = interfaces_out

    return result


def parse_ndp_proxy_config(config: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(config, dict):
        return {'route_refresh': '', 'interfaces': []}

    interfaces: List[Dict[str, Any]] = []
    raw_interfaces = config.get('interface') or {}
    if isinstance(raw_interfaces, dict):
        for name, intf_cfg in raw_interfaces.items():
            if not isinstance(intf_cfg, dict):
                intf_cfg = {}

            prefixes: List[Dict[str, Any]] = []
            raw_prefixes = intf_cfg.get('prefix') or {}
            if isinstance(raw_prefixes, dict):
                for value, prefix_cfg in raw_prefixes.items():
                    if not isinstance(prefix_cfg, dict):
                        prefix_cfg = {}
                    prefixes.append({
                        'value': str(value),
                        'enabled': 'disable' not in prefix_cfg,
                        'mode': prefix_cfg.get('mode') or '',
                        'interface': prefix_cfg.get('interface') or '',
                    })

            interfaces.append({
                'name': str(name),
                'enabled': 'disable' not in intf_cfg,
                'enable_router_bit': 'enable-router-bit' in intf_cfg,
                'timeout': intf_cfg.get('timeout') or '',
                'ttl': intf_cfg.get('ttl') or '',
                'prefixes': prefixes,
            })

    return {
        'route_refresh': config.get('route-refresh') or '',
        'interfaces': interfaces,
    }
