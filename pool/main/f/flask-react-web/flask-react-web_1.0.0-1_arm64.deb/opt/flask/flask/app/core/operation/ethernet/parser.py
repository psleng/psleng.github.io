from app.log.logger import logger
from app.core.operation.ip_options.parser import parse_to_ip_options_vyos_config
from app.core.operation.dhcp_options.parser import parse_to_dhcp_options_vyos_config

def parse_to_ethernet_config(data: dict):

    if not data:
        return {}

    result = {}

    # Process general settings
    if 'general' in data:
        general = data['general']
        if 'description' in general:
            result['description'] = general['description']
        if 'disabled' in general and general['disabled']:
            result['disable'] = {}
        if 'hwId' in general:
            result['hw-id'] = general['hwId']

    # Process link settings
    if 'link' in data:
        link = data['link']
        if 'disableFlowControl' in link and link['disableFlowControl']:
            result['disable-flow-control'] = {}
        if 'disableLinkDetect' in link and link['disableLinkDetect']:
            result['disable-link-detect'] = {}
        if 'speed' in link:
            result['speed'] = link['speed']
        if 'duplex' in link:
            result['duplex'] = link['duplex']
        if 'mtu' in link:
            result['mtu'] = str(link['mtu'])

    # Process network settings
    if 'network' in data:
        network = data['network']
        
        if 'bridgeMode' in network and network['bridgeMode']:
            result['bridge'] = {}
            if 'bridgeInterface' in network and network['bridgeInterface']:
                result['bridge']['interface'] = network['bridgeInterface']
        
        if 'ipv4' in network and network['ipv4']:
            ipv4_config = network['ipv4']
            if not result.get('address'):
                result['address'] = []
            
            if ipv4_config.get('mode') == 'dhcp':
                result['address'].append('dhcp')
            elif ipv4_config.get('mode') == 'static' and ipv4_config.get('static'):
                static_config = ipv4_config['static']
                if static_config.get('address'):
                    result['address'].append(static_config['address'])
        
        if 'ipv6' in network and network['ipv6']:
            ipv6_config = network['ipv6']
            if not result.get('address'):
                result['address'] = []
            
            if ipv6_config.get('mode') == 'dhcpv6':
                result['address'].append('dhcpv6')
            elif ipv6_config.get('mode') == 'static' and ipv6_config.get('static'):
                static_config = ipv6_config['static']
                if static_config.get('address'):
                    result['address'].append(static_config['address'])
            elif ipv6_config.get('mode') == 'autoconf':
                if not result.get('ipv6'):
                    result['ipv6'] = {}
                if not result['ipv6'].get('address'):
                    result['ipv6']['address'] = {}
                result['ipv6']['address']['autoconf'] = {}
            elif ipv6_config.get('mode') == 'delegated':
                if not result.get('ipv6'):
                    result['ipv6'] = {}
                if not result['ipv6'].get('address'):
                    result['ipv6']['address'] = {}
                result['ipv6']['address']['dhcpv6'] = {}

    if 'ip' in data:
        ip_result, ipv6_result = parse_to_ip_options_vyos_config(data['ip'])
        
        if ip_result:
            result['ip'] = ip_result
        if ipv6_result:
            result['ipv6'] = ipv6_result
    
    if 'dhcp' in data:
        dhcp_result, dhcpv6_result = parse_to_dhcp_options_vyos_config(data['dhcp'])
        
        if dhcp_result:
            result['dhcp-options'] = dhcp_result
        if dhcpv6_result:
            result['dhcpv6-options'] = dhcpv6_result
    
    # Add default offload settings
    result['offload'] = {
        'gro': {},
        'gso': {},
        'sg': {},
        'tso': {}
    }

    return result


def parse_ethernet_config(data: dict):
    return data


def parse_current_ethernet_interface_config(os_config: dict, ethernet_name: str):
    """
    Parse current ethernet interface configuration from OS config
    """
    try:
        ethernet_interfaces = os_config.get('interfaces', {}).get('ethernet', {})
        if ethernet_name in ethernet_interfaces:
            return {ethernet_name: ethernet_interfaces[ethernet_name]}
        return {}
    except Exception as e:
        logger.error(f"Error parsing current ethernet config: {e}")
        return {}

def parse_all_bridge_interfaces_config(os_config: dict):
    try:
        bridge_interfaces = os_config.get('interfaces', {}).get('bridge', {})
        return bridge_interfaces
    except Exception as e:
        logger.error(f"Error parsing all bridge interfaces config: {e}")
        return {}