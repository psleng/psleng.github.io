from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
from app.core.operation.ip_options.command_ip_options import IPOptionCommand
from app.core.operation.dhcp_options.command_dhcp_options import DHCPOptionCommand
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']

def format_description(description: str) -> str:
    return description.replace(' ', '_')

class BridgeCommand(IfaceCommand):
    """
    Bridge command class:

    - set/delete interfaces bridge <bridge-name>
    - set/delete interfaces bridge <bridge-name> address {x.x.x.x/n | h:h:h:h:h:h:h:h/x | dhcp | dhcpv6}
    - set/delete interfaces bridge <bridge-name> description <text>
    - set/delete interfaces bridge <bridge-name> disable
    - set/delete interfaces bridge <bridge-name> mtu <68-16000>
    
    - set/delete interfaces bridge <bridge-name> aging {0 | <10-1000000>}
    - set/delete interfaces bridge <bridge-name> disable-link-detect
    - set/delete interfaces bridge <bridge-name> member interface <interface>

    Extra:
    - IP options
    - DHCP options
    
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'bridge'),
                name=kwargs.get('name', None)
            )
            self.attributes = {
                'interfaces': {
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Bridge command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
    
    def get_all_commands(self):
        all_cmds = self.cmds.copy()
        return all_cmds
    
    def get_all_vyos_commands(self):
        all_vyos_cmds = self.vyos_cmds.copy()
        return all_vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            for bridge_name, config in data.items():
                self._process_bridge_interface(bridge_name, config, current_config, new_config)

            return self.get_all_commands()

        except Exception as e:
            print(f"Error generating Bridge commands: {e}")
            return []

    
    def _process_bridge_interface(self, bridge_name, bridge_config, current_config, new_config):
        base = ['interfaces', 'bridge', bridge_name]
        
        if 'address' in bridge_config:
            addresses = bridge_config['address']
            if not isinstance(addresses, list):
                addresses = [addresses]
            for addr in addresses:
                self.generate(*base, 'address', str(addr))
                addr_lower = str(addr).lower()
                if addr_lower == 'dhcp' or addr_lower == 'dhcpv6':
                    system_base = ['system', 'name-server', bridge_name]
                    if self.operator == 'set':
                        self.generate(*system_base)
                    elif self.operator == 'delete':
                        self.generate(*system_base)
        
        if 'description' in bridge_config:
            desc = format_description(bridge_config['description'])
            if is_str_not_empty(desc):
                self.generate(*base, 'description', desc)
        
        if 'disable' in bridge_config:
            self.generate(*base, 'disable')
        
        if 'mtu' in bridge_config:
            mtu = bridge_config['mtu']
            if is_str_not_empty(mtu):
                self.generate(*base, 'mtu', str(mtu))

        if 'aging' in bridge_config:
            aging = bridge_config['aging']
            if is_str_not_empty(aging):
                self.generate(*base, 'aging', str(aging))

        if 'disable-link-detect' in bridge_config:
            self.generate(*base, 'disable-link-detect')

        members = []
        if 'member' in bridge_config and bridge_config['member'] is not None:
            member_data = bridge_config['member']
            if isinstance(member_data, dict) and 'interface' in member_data:
                members = list(member_data['interface'].keys())
            elif isinstance(member_data, list):
                members = member_data
            else:
                members = [member_data]

        for member in members:
            if is_str_not_empty(member):
                self.generate(*base, 'member', 'interface', member)

        
        if 'dhcp-options' in bridge_config or 'dhcpv6-options' in bridge_config:
            dhcp_cmd = DHCPOptionCommand(
                operator=self.operator,
                intf_type="bridge",
                intf_name=bridge_name
            )
            dhcp_data = {}
            if 'dhcp-options' in bridge_config:
                dhcp_data['dhcp-options'] = bridge_config['dhcp-options']
            if 'dhcpv6-options' in bridge_config:
                dhcp_data['dhcpv6-options'] = bridge_config['dhcpv6-options']
            
            dhcp_cmd.generate_commands(data=dhcp_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(dhcp_cmd.cmds)
            self.vyos_cmds.extend(dhcp_cmd.vyos_cmds)
        
        if 'ip' in bridge_config or 'ipv6' in bridge_config:
            ip_cmd = IPOptionCommand(
                operator=self.operator,
                intf_type="bridge",
                intf_name=bridge_name
            )
            ip_data = {}
            if 'ip' in bridge_config:
                ip_data['ip'] = bridge_config['ip']
            if 'ipv6' in bridge_config:
                ip_data['ipv6'] = bridge_config['ipv6']
            ip_cmd.generate_commands(data=ip_data, current_config=current_config, new_config=new_config)
            self.cmds.extend(ip_cmd.cmds)
            self.vyos_cmds.extend(ip_cmd.vyos_cmds)
    
