import pytest
import json
import requests
from app.core.api.http.http_request import Action
import pprint

class TestOpenVPNEndpointCreate:

    @classmethod
    def setup_class(cls):
        """Run once before all tests - register test user"""
        register_url = "http://localhost/webapi/auth/register"
        register_data = {
            "username": "test",
            "password": "test"
        }
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
            if response.status_code == 200:
                print("Test user registered successfully")
            else:
                print(f"Registration response: {response.text}")
        except Exception as e:
            print(f"Registration error (user may already exist): {e}")

    def _delete_and_login(self, test_service_provider):

        DELETE_OPENVPN = '{"op": "delete", "path": ["interfaces", "openvpn"]}'
        delete_response = test_service_provider.http_service.send_request(
            action=Action.CONFIGURE, 
            data=DELETE_OPENVPN, 
            verify=False
        )
        print(f"Delete response: {delete_response.json()}")
        
        login_url = "http://localhost/webapi/auth/login"
        login_data = {
            "username": "test",
            "password": "test",
            "ssid": ""
        }
        login_response = requests.post(login_url, json=login_data)
        print(f"Login response: {login_response.status_code}")
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        
        return login_response.cookies

    def test_create_endpoint_1_site_to_site(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        
        print("\n=== Test Case 1: Site-to-Site OpenVPN ===")
        cookies = self._delete_and_login(test_service_provider)
        
        site_to_site_data = {
            "general": {
                "name": "vtun0",
                "mode": "site-to-site",
                "description": "Site to Site VPN Test",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localAddress": "10.0.0.1",
                "localHost": ["192.168.1.1"],
                "localPort": 1194,
                "protocol": "udp",
                "remoteAddress": "10.0.0.2",
                "remoteHost": ["203.0.113.1"],
                "remotePort": 1194,
                "server": {
                    "clientIpPool": {
                        "disabled": False,
                        "start": "10.8.0.100",
                        "stop": "10.8.0.200",
                        "subnetMask": "255.255.255.0"
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": True,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ['testCA'],
                    "certificate": ['testCert'],
                    "cryptKey": [],
                    "dhParams": "",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "",
                    "dataCiphers": []
                },
                "hash": {
                    "algorithm": "sha256"
                },
                "sharedSecretKey": "vpn-secret"
            }
        }
        
        response = requests.post(openvpn_url, json=site_to_site_data, cookies=cookies)
        print("Test 1 response: ")
        print(response.json())
        
        assert response.status_code == 200, f"Failed to create site-to-site VPN: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Command failed:")
                print(f"  CMD: ")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print(f"Site-to-site creation result: All commands succeeded")

    def test_create_endpoint_2_server_mode(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        
        print("\n=== Test Case 2: Server Mode OpenVPN ===")
        cookies = self._delete_and_login(test_service_provider)
        
        server_data = {
            "general": {
                "name": "vtun1",
                "mode": "server",
                "description": "OpenVPN Server Test",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localPort": 1194,
                "protocol": "udp",
                "server": {
                    "subnet": "10.8.0.0/24",
                    "topology": "subnet",
                    "domainName": "example.com",
                    "maxConnections": 100,
                    "nameServer": ["8.8.8.8", "8.8.4.4"],
                    "clientIpPool": {
                        "start": "10.8.0.100",
                        "stop": "10.8.0.200",
                        "subnetMask": "255.255.255.0",
                        "disabled": False
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": False,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ["testCA"],
                    "certificate": ["testCert"],
                    "cryptKey": [],
                    "dhParams": "test-dh",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "aes256",
                    "dataCiphers": ["aes256", "aes128"]
                },
                "hash": {
                    "algorithm": "sha256"
                },
                "sharedSecretKey": ""
            }
        }
        
        response = requests.post(openvpn_url, json=server_data, cookies=cookies)
        
        assert response.status_code == 200, f"Failed to create server VPN: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Command failed:")
                print(f"  CMD: ")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print(f"Server creation result: All commands succeeded")

    def test_create_endpoint_3_client_mode(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        
        print("\n=== Test Case 3: Client Mode OpenVPN ===")
        cookies = self._delete_and_login(test_service_provider)
        
        client_data = {
            "general": {
                "name": "vtun2",
                "mode": "client",
                "description": "OpenVPN Client Test",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "protocol": "tcp-active",
                "remoteHost": ["vpn.example.com"],
                "remotePort": 443,
                "server": {
                    "clientIpPool": {
                        "disabled": True,
                        "start": "10.8.0.100",
                        "stop": "10.8.0.200",
                        "subnetMask": "255.255.255.0"
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": False,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ["testCA"],
                    "certificate": ["testCert"],
                    "cryptKey": [],
                    "dhParams": "",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "aes256",
                    "dataCiphers": ["aes256", "aes128"]
                },
                "hash": {
                    "algorithm": "sha256"
                },
                "sharedSecretKey": ""
            }
        }
        
        response = requests.post(openvpn_url, json=client_data, cookies=cookies)
        
        assert response.status_code == 200, f"Failed to create client VPN: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Command failed:")
                print(f"  CMD: ")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print(f"Client creation result: All commands succeeded")

    def test_create_endpoint_4_invalid_data(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        
        print("\n=== Test Case 4: Invalid Data (Missing Mode) ===")
        cookies = self._delete_and_login(test_service_provider)
        
        invalid_data = {
            "general": {
                "name": "vtun3",
                # Missing mode
            },
            "openvpn": {},
            "security": {}
        }
        
        response = requests.post(openvpn_url, json=invalid_data, cookies=cookies)

        assert response.status_code == 400, "Should fail with invalid data"
        print(f"Invalid data test passed: {response.status_code}")

    def test_create_endpoint_5_duplicate_interface(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        
        print("\n=== Test Case 5: Duplicate Interface Name ===")
        cookies = self._delete_and_login(test_service_provider)
        
        site_to_site_data = {
            "general": {
                "name": "vtun0",
                "mode": "site-to-site",
                "description": "Site to Site VPN Test",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localAddress": "10.0.0.1",
                "localHost": ["192.168.1.1"],
                "localPort": 1194,
                "protocol": "udp",
                "remoteAddress": "10.0.0.2",
                "remoteHost": ["203.0.113.1"],
                "remotePort": 1194,
                "server": {
                    "clientIpPool": {
                        "disabled": False,
                        "start": "10.8.0.100",
                        "stop": "10.8.0.200",
                        "subnetMask": "255.255.255.0"
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": True,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ['testCA'],
                    "certificate": ['testCert'],
                    "cryptKey": [],
                    "dhParams": "",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "",
                    "dataCiphers": []
                },
                "hash": {
                    "algorithm": "sha256"
                },
                "sharedSecretKey": "vpn-secret"
            }
        }
        
        response = requests.post(openvpn_url, json=site_to_site_data, cookies=cookies)
        
        assert response.status_code == 200, f"Failed to create first vtun0: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Command failed:")
                print(f"  CMD: ")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print(f"First vtun0 created successfully")
        
        import copy
        duplicate_data = copy.deepcopy(site_to_site_data)
        duplicate_data["general"]["name"] = "vtun0"
        
        response = requests.post(openvpn_url, json=duplicate_data, cookies=cookies)
        print(f"Duplicate interface test result: {response.status_code}")
