from typing import Any, Dict, List, Optional


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else ([] if value is None else [value])


def parse_failover_routes_config(config: dict) -> List[dict]:

    if not config or not isinstance(config, dict):
        return []

    rows: List[dict] = []

    for route_prefix, route_data in config.items():
        if not isinstance(route_data, dict):
            continue

        # next-hop
        next_hops = route_data.get('next-hop')
        if isinstance(next_hops, dict):
            for nh_ip, nh_opts in next_hops.items():
                nh_opts = _as_dict(nh_opts)
                row = {
                    'route_prefix': str(route_prefix),
                    'path_type': 'next-hop',
                    'path_value': str(nh_ip),
                    'interface': nh_opts.get('interface') or '',
                    'metric': nh_opts.get('metric') or '',
                    'onlink': True if 'onlink' in nh_opts and nh_opts.get('onlink') != 'disable' else False,
                    'check': {},
                }

                check = _as_dict(nh_opts.get('check'))
                if check:
                    row['check'] = {
                        'policy': check.get('policy') or '',
                        'port': check.get('port') or '',
                        'timeout': check.get('timeout') or '',
                        'type': check.get('type') or '',
                        'targets': []
                    }
                    targets = check.get('target')
                    if isinstance(targets, dict):
                        for target_ip, target_opts in targets.items():
                            target_opts = _as_dict(target_opts)
                            row['check']['targets'].append({
                                'target': str(target_ip),
                                'interface': target_opts.get('interface') or ''
                            })
                rows.append(row)

        # dhcp-interface
        dhcp_interfaces = route_data.get('dhcp-interface')
        if isinstance(dhcp_interfaces, dict):
            for dhcp_name, dhcp_opts in dhcp_interfaces.items():
                dhcp_opts = _as_dict(dhcp_opts)
                row = {
                    'route_prefix': str(route_prefix),
                    'path_type': 'dhcp-interface',
                    'path_value': str(dhcp_name),
                    'interface': dhcp_opts.get('interface') or '',
                    'metric': dhcp_opts.get('metric') or '',
                    'onlink': True if 'onlink' in dhcp_opts and dhcp_opts.get('onlink') != 'disable' else False,
                    'check': {},
                }

                check = _as_dict(dhcp_opts.get('check'))
                if check:
                    row['check'] = {
                        'policy': check.get('policy') or '',
                        'port': check.get('port') or '',
                        'timeout': check.get('timeout') or '',
                        'type': check.get('type') or '',
                        'targets': []
                    }
                    targets = check.get('target')
                    if isinstance(targets, dict):
                        for target_ip, target_opts in targets.items():
                            target_opts = _as_dict(target_opts)
                            row['check']['targets'].append({
                                'target': str(target_ip),
                                'interface': target_opts.get('interface') or ''
                            })
                rows.append(row)

    return rows


def parse_to_failover_routes_config(data: dict) -> dict:
    routes = data.get('routes') if isinstance(data, dict) else None
    if not isinstance(routes, list):
        return {}

    config: Dict[str, Any] = {}

    for row in routes:
        if not isinstance(row, dict):
            continue

        route_prefix = str(row.get('route_prefix') or '').strip()
        path_type = str(row.get('path_type') or '').strip()
        path_value = str(row.get('path_value') or '').strip()

        if path_type == 'dhcp-interface' and not path_value:
            path_value = str(row.get('interface') or '').strip()

        if not route_prefix or not path_type or not path_value:
            continue

        route_node = config.setdefault(route_prefix, {})

        if path_type == 'next-hop':
            nh_node = route_node.setdefault('next-hop', {})
            entry = nh_node.setdefault(path_value, {})
        elif path_type == 'dhcp-interface':
            dhcp_node = route_node.setdefault('dhcp-interface', {})
            entry = dhcp_node.setdefault(path_value, {})
        else:
            continue

        interface = str(row.get('interface') or '').strip()
        metric = str(row.get('metric') or '').strip()
        onlink = row.get('onlink')

        if interface:
            entry['interface'] = interface
        if metric:
            entry['metric'] = metric
        if onlink is True:
            entry['onlink'] = {}

        check = row.get('check')
        if isinstance(check, dict):
            check_obj: Dict[str, Any] = {}
            policy = str(check.get('policy') or '').strip()
            port = str(check.get('port') or '').strip()
            timeout = str(check.get('timeout') or '').strip()
            ctype = str(check.get('type') or '').strip()

            if policy:
                check_obj['policy'] = policy
            if port:
                check_obj['port'] = port
            if timeout:
                check_obj['timeout'] = timeout
            if ctype:
                check_obj['type'] = ctype

            targets = check.get('targets')
            if isinstance(targets, list) and targets:
                target_obj: Dict[str, Any] = {}
                for t in targets:
                    if not isinstance(t, dict):
                        continue
                    target_ip = str(t.get('target') or '').strip()
                    if not target_ip:
                        continue
                    t_opts: Dict[str, Any] = {}
                    t_intf = str(t.get('interface') or '').strip()
                    if t_intf:
                        t_opts['interface'] = t_intf
                    target_obj[target_ip] = t_opts if t_opts else {}
                if target_obj:
                    check_obj['target'] = target_obj

            if check_obj:
                entry['check'] = check_obj

    return config
