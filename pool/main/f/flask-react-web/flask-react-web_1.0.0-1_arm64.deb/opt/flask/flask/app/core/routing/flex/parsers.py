from typing import Any, Dict, List


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def parse_failover_routes_config(config: dict, route_type='route') -> List[dict]:

    if not config or not isinstance(config, dict):
        return []

    if 'route' in config or 'route6' in config:
        config = _as_dict(config.get(route_type))

    rows: List[dict] = []
    for route_prefix, route_data in config.items():
        for path_type in ('next-hop', 'dhcp-interface', 'interface'):
            for path_value, options in _as_dict(_as_dict(route_data).get(path_type)).items():
                options = _as_dict(options)
                check = _as_dict(options.get('check'))
                row_check = {}
                if check:
                    row_check = {
                        key: check.get(key) or ''
                        for key in ('policy', 'port', 'timeout', 'type', 'failure-count', 'success-count')
                    }
                    row_check['targets'] = [
                        {'target': str(target), 'interface': _as_dict(opts).get('interface') or ''}
                        for target, opts in _as_dict(check.get('target')).items()
                    ]
                rows.append({
                    'route_prefix': str(route_prefix),
                    'path_type': path_type,
                    'path_value': str(path_value),
                    'interface': options.get('interface') or (str(path_value) if path_type != 'next-hop' else ''),
                    'metric': options.get('metric') or '',
                    'onlink': 'onlink' in options and options.get('onlink') != 'disable',
                    'check': row_check,
                })
    return rows


def parse_to_failover_routes_config(data: dict) -> dict:
    routes = data.get('routes') if isinstance(data, dict) else None
    if not isinstance(routes, list):
        return {}

    config: Dict[str, Any] = {}

    for row in routes:
        if not isinstance(row, dict):
            continue

        route_prefix = str(row.get('route_prefix') or '').strip()
        path_type = str(row.get('path_type') or '').strip()
        path_value = str(row.get('path_value') or '').strip()

        if path_type in ('dhcp-interface', 'interface') and not path_value:
            path_value = str(row.get('interface') or '').strip()

        if not route_prefix or not path_type or not path_value:
            continue

        route_node = config.setdefault(route_prefix, {})

        if path_type not in ('next-hop', 'dhcp-interface', 'interface'):
            continue
        entry = route_node.setdefault(path_type, {}).setdefault(path_value, {})

        interface = path_value if path_type != 'next-hop' else str(row.get('interface') or '').strip()
        metric = str(row.get('metric') or '').strip()
        onlink = row.get('onlink')

        if interface:
            entry['interface'] = interface
        if metric:
            entry['metric'] = metric
        if onlink is True:
            entry['onlink'] = {}

        check = row.get('check')
        if isinstance(check, dict):
            check_obj: Dict[str, Any] = {}
            policy = str(check.get('policy') or '').strip()
            port = str(check.get('port') or '').strip()
            timeout = str(check.get('timeout') or '').strip()
            ctype = str(check.get('type') or '').strip()

            if policy:
                check_obj['policy'] = policy
            if port:
                check_obj['port'] = port
            if timeout:
                check_obj['timeout'] = timeout
            if ctype:
                check_obj['type'] = ctype

            for count in ('failure-count', 'success-count'):
                value = str(check.get(count) or '').strip()
                if value:
                    check_obj[count] = value

            targets = check.get('targets')
            if isinstance(targets, list) and targets:
                target_obj: Dict[str, Any] = {}
                for t in targets:
                    if not isinstance(t, dict):
                        continue
                    target_ip = str(t.get('target') or '').strip()
                    if not target_ip:
                        continue
                    t_opts: Dict[str, Any] = {}
                    t_intf = (interface if data.get('route_ver') == 'ipv6' else
                              path_value if path_type != 'next-hop' else str(t.get('interface') or '').strip())
                    if t_intf:
                        t_opts['interface'] = t_intf
                    target_obj[target_ip] = t_opts if t_opts else {}
                if target_obj:
                    check_obj['target'] = target_obj

            if check_obj:
                entry['check'] = check_obj

    return config
