from typing import Any, Dict, List


def parse_to_arp_config(data: Dict[str, Any]) -> Dict[str, Any]:
    if not data or not isinstance(data, dict):
        return {}

    entries = data.get('entries') or []
    if not isinstance(entries, list):
        return {}

    out: Dict[str, Any] = {}
    interfaces: Dict[str, Any] = {}

    for item in entries:
        if not isinstance(item, dict):
            continue
        interface = item.get('interface')
        address = item.get('address')
        mac = item.get('mac')
        if interface is None or str(interface).strip() == "":
            continue
        if address is None or str(address).strip() == "":
            continue
        if mac is None or str(mac).strip() == "":
            continue

        ifname = str(interface).strip()
        ip = str(address).strip()
        mac_s = str(mac).strip()

        if ifname not in interfaces:
            interfaces[ifname] = {'address': {}}
        if 'address' not in interfaces[ifname] or not isinstance(interfaces[ifname].get('address'), dict):
            interfaces[ifname]['address'] = {}
        interfaces[ifname]['address'][ip] = {'mac': mac_s}

    if interfaces:
        out['interface'] = interfaces

    return out
