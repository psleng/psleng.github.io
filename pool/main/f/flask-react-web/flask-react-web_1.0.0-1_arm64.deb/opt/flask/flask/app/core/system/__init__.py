from flask import Blueprint

vyos_system_bp = Blueprint('system', __name__)

from . import routes