from uuid import uuid4

from flask import session

from app.core.api.http.cmd.command import SHOW_NDP_PROXY
from app.core.api.http.http_request import Action
from app.core.network.ndp_proxy.command_ndp_proxy import NDPProxyCommand
from app.core.network.ndp_proxy.models import NDPProxyConfig
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set, process_commands
from app.socket.socket_manager import socket_manager


def fetch_ndp_proxy_config(provider, params=None):
    response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_NDP_PROXY, verify=False)
    data = response.json().get('data')
    return data or {}


def update_ndp_proxy(provider, data):
    username = session.get('username')
    diff = data.get('diff') or {}
    current_config = data.get('current') or {}
    new_config = data.get('new') or {}

    set_cmd = NDPProxyCommand(operator='set', resource='service')
    set_cmds = set_cmd.generate_commands(diff.get('created') or {}, current_config, new_config)
    new_set_configs = process_commands(set_cmd.get_commands())

    del_cmd = NDPProxyCommand(operator='delete', resource='service')
    delete_cmds = del_cmd.generate_commands(diff.get('deleted') or {}, current_config, new_config)
    new_del_configs = process_commands(del_cmd.get_commands())

    service = 'service_ndp_proxy'
    try:
        curr_config = provider.verify_service.call_get_config(service)
    except Exception:
        curr_config = {}

    current_raw = curr_config if curr_config else {}
    merged_deleted = merge_dicts_delete(
        current_raw,
        new_del_configs.get('service', {}).get('ndp-proxy', {})
    )
    merged_config = merge_dicts_set(
        merged_deleted,
        new_set_configs.get('service', {}).get('ndp-proxy', {})
    )

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)

    if str(verify) not in ('None', '', 'null') and verify is not None and verify != {}:
        return Exception(verify)

    NDPProxyConfig.refresh(new_config)

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update IPv6 NDP Proxy',
            'content': 'IPv6 NDP Proxy is successfully updated',
        }
    )

    executed_cmds = list(dict.fromkeys(set_cmds + delete_cmds))
    if not executed_cmds:
        return []

    res = provider.http_service.send_request(action=Action.CONFIGURE, data=executed_cmds, verify=False).json()
    return [{'cmd': executed_cmds, 'success': res.get('success'), 'error': res.get('error')}]


def verify_ndp_proxy(provider, data):
    return provider.verify_service.call_verify('service_ndp_proxy', data)
