class DHCPOptionCommand:
    """
    DHCP options command, used to attach to individual interfaces:

    - set/delete interfaces <intf-type> <intf-name> dhcp-options client-id <text>
    - set/delete interfaces <intf-type> <intf-name> dhcp-options default-route-distance <1-255>
    - set/delete interfaces <intf-type> <intf-name> dhcp-options host-name <text>
    - set/delete interfaces <intf-type> <intf-name> dhcp-options mtu
    - set/delete interfaces <intf-type> <intf-name> dhcp-options no-default-route
    - set/delete interfaces <intf-type> <intf-name> dhcp-options user-class <text>
    - set/delete interfaces <intf-type> <intf-name> dhcp-options vendor-class-id <text>
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options duid <h:h:…:h>
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options no-release
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options parameters-only
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options rapid-commit
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options temporary
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <0-65535>
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <instance-id> interface <intf-name> 
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <instance-id> interface <intf-name> address <0-65535>
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <instance-id> interface <intf-name> sla-length <0-16> 
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <instance-id> interface <intf-name> sla-id <0-65535>
    - set/delete interfaces <intf-type> <intf-name> dhcpv6-options pd <instance-id> length <48-64>


    if vlan_id is not None, the commands will become:
        - set/delete interfaces <intf-type> <intf-name> vif <vlan-id> dhcp-options ...
        - set/delete interfaces <intf-type> <intf-name> vif <vlan-id> dhcpv6-options ...
        
    """
    def __init__(self, **kwargs):
        try:
            self.operator = kwargs.get('operator', 'set')
            self.intf_type = kwargs.get('intf_type', '')
            self.intf_name = kwargs.get('intf_name', '')
            self.vlan_id = kwargs.get('vlan_id', None)
            self.attributes = {
                'dhcp-options': {
                },
                'dhcpv6-options': {
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing DHCP options cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            if self.vlan_id is not None:
                base = ['interfaces', self.intf_type, self.intf_name, 'vif', str(self.vlan_id)]
            else:
                base = ['interfaces', self.intf_type, self.intf_name]
            
            if 'dhcp-options' in data and isinstance(data['dhcp-options'], dict):
                self._process_dhcp_options(base, data['dhcp-options'])
            
            if 'dhcpv6-options' in data and isinstance(data['dhcpv6-options'], dict):
                self._process_dhcpv6_options(base, data['dhcpv6-options'], current_config, new_config)
            
            return self.cmds
        
        except Exception as e:
            print(f"Error generating DHCP options commands: {e}")
            return []
    
    def _process_dhcp_options(self, base, dhcp_config):
        dhcp_base = base + ['dhcp-options']
        
        if 'client-id' in dhcp_config:
            value = dhcp_config['client-id']
            if value:
                self.generate(*dhcp_base, 'client-id', str(value))
        
        if 'default-route-distance' in dhcp_config:
            value = dhcp_config['default-route-distance']
            if value:
                self.generate(*dhcp_base, 'default-route-distance', str(value))
        
        if 'host-name' in dhcp_config:
            value = dhcp_config['host-name']
            if value:
                self.generate(*dhcp_base, 'host-name', str(value))
        
        if 'mtu' in dhcp_config:
            self.generate(*dhcp_base, 'mtu')
        
        if 'no-default-route' in dhcp_config:
            self.generate(*dhcp_base, 'no-default-route')
        
        if 'user-class' in dhcp_config:
            value = dhcp_config['user-class']
            if value:
                self.generate(*dhcp_base, 'user-class', str(value))
        
        if 'vendor-class-id' in dhcp_config:
            value = dhcp_config['vendor-class-id']
            if value:
                self.generate(*dhcp_base, 'vendor-class-id', str(value))
    
    def _process_dhcpv6_options(self, base, dhcpv6_config, current_config=None, new_config=None):
        dhcpv6_base = base + ['dhcpv6-options']
        
        if 'duid' in dhcpv6_config:
            value = dhcpv6_config['duid']
            if value:
                self.generate(*dhcpv6_base, 'duid', str(value))
        
        if 'no-release' in dhcpv6_config:
            self.generate(*dhcpv6_base, 'no-release')
        
        if 'parameters-only' in dhcpv6_config:
            self.generate(*dhcpv6_base, 'parameters-only')
        
        if 'rapid-commit' in dhcpv6_config:
            self.generate(*dhcpv6_base, 'rapid-commit')
        
        if 'temporary' in dhcpv6_config:
            self.generate(*dhcpv6_base, 'temporary')
        
        if 'pd' in dhcpv6_config and isinstance(dhcpv6_config['pd'], dict):
            for instance_id, pd_config in dhcpv6_config['pd'].items():
                self._process_pd_config(dhcpv6_base, instance_id, pd_config, current_config, new_config)
    
    def _process_pd_config(self, dhcpv6_base, instance_id, pd_config, current_config=None, new_config=None):
        pd_base = dhcpv6_base + ['pd', str(instance_id)]
        
        if (self.operator == 'delete' and new_config and 
            str(instance_id) not in new_config.get('dhcpv6-options', {}).get('pd', {})):
            self.generate(*pd_base)
            return

        if 'length' in pd_config:
            value = pd_config['length']
            if value:
                self.generate(*pd_base, 'length', str(value))
        
        if 'interface' in pd_config and isinstance(pd_config['interface'], dict):
            for intf_name, intf_config in pd_config['interface'].items():
                intf_base = pd_base + ['interface', str(intf_name)]
                
                if 'address' in intf_config:
                    value = intf_config['address']
                    if value is not None:
                        self.generate(*intf_base, 'address', str(value))
                
                if 'sla-length' in intf_config:
                    value = intf_config['sla-length']
                    if value is not None:
                        self.generate(*intf_base, 'sla-length', str(value))
                
                if 'sla-id' in intf_config:
                    value = intf_config['sla-id']
                    if value is not None:
                        self.generate(*intf_base, 'sla-id', str(value))