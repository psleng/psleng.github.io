import re

from pydantic import BaseModel, ConfigDict, IPvAnyAddress, StrictStr, field_validator
from sqlalchemy import Column, String

from app.db.database import db
from app.core.network.dns.hostname_mapping.parser import parse_hostname_mappings


class HostnameMappingDTO(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    hostname: StrictStr
    inet: IPvAnyAddress
    alias: StrictStr = ''

    @field_validator('hostname', 'alias')
    @classmethod
    def validate_hostname(cls, value, info):
        if info.field_name == 'alias' and not value:
            return value
        name = value.removesuffix('.')
        labels = name.split('.')
        if (not name or len(name) > 253
                or all(label.isdigit() for label in labels)
                or not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', label)
                           for label in labels)):
            raise ValueError(f'Enter a valid {info.field_name}.')
        return value

    @field_validator('inet', mode='before')
    @classmethod
    def validate_address_input(cls, value):
        if not isinstance(value, str):
            raise ValueError('IP address must be a single string value.')
        value = value.strip()
        if '%' in value:
            raise ValueError('Enter an IPv4 or IPv6 address without a scope identifier.')
        return value


class UpdateHostnameMappingsDTO(BaseModel):
    mappings: list[HostnameMappingDTO]

    @field_validator('mappings')
    @classmethod
    def validate_unique_hostnames(cls, mappings):
        names = set()
        for mapping in mappings:
            key = mapping.hostname.lower().rstrip('.')
            if key in names:
                raise ValueError(f'Duplicate hostname: {mapping.hostname}.')
            names.add(key)
        return mappings


class HostnameMappingConfig(db.Model):
    __tablename__ = 'vyos_hostname_mapping'

    hostname = Column(String(253), primary_key=True)
    inet = Column(String(64), nullable=False, default='')
    alias = Column(String(253), nullable=False, default='')

    def serialize(self):
        return {'hostname': self.hostname, 'inet': self.inet, 'alias': self.alias}

    @classmethod
    def refresh(cls, system_config):
        try:
            mappings = parse_hostname_mappings(system_config)
            db.session.query(cls).delete()
            db.session.add_all([cls(**mapping) for mapping in mappings])
            db.session.commit()
        except Exception:
            print("Exception: Refresh hostname mapping.")

    @classmethod
    def get_config(cls):
        return {'mappings': [entry.serialize() for entry in cls.query.order_by(cls.hostname).all()]}
