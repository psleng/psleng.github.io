from app.core.operation.ipsec.command_ipsec import IpsecCommand, remove_deleted_vti_psk_references
from app.core.api.http.cmd.compare import compare_configs
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
from app.core.api.http.http_request import Action
import json
import pprint
import copy
from app.core.api.http.cmd.command import SHOW_INTERFACE_VTI_CONFIGS
from app.core.operation.vti.parser import get_highest_vti_number
from app.log.logger import logger
from app.core.operation.ipsec.models import IPsecConfig


def remove_vti_bindings_from_config(config):
    if not config:
        return config
    
    for key in ['site-to-site', 'site_to_site']:
        if key in config and 'peer' in config[key]:
            for peer_name, peer_config in config[key]['peer'].items():
                if isinstance(peer_config, dict) and 'vti' in peer_config and 'bind' in peer_config['vti']:
                    del peer_config['vti']['bind']

    for key in ['remote-access', 'remote_access']:
        if key in config and 'connection' in config[key]:
            for conn_name, conn_config in config[key]['connection'].items():
                if isinstance(conn_config, dict) and 'bind' in conn_config:
                    del conn_config['bind']
    
    return config


def _normalize_ipsec_verify_config(config):
    if not isinstance(config, dict):
        return config

    if isinstance(config.get('interface'), str):
        config['interface'] = [config['interface']]

    options = config.get('options')
    if isinstance(options, dict) and isinstance(options.get('interface'), str):
        options['interface'] = [options['interface']]

    psk_config = config.get('authentication', {}).get('psk')
    if isinstance(psk_config, dict):
        for psk_data in psk_config.values():
            if isinstance(psk_data, dict) and 'dhcp_interface' in psk_data and 'dhcp-interface' not in psk_data:
                psk_data['dhcp-interface'] = psk_data.pop('dhcp_interface')

    return config


def update_ipsec(provider, data):
    logger.info("Update ipsec:")
    logger.info(data)
    username = session['username']
    current_config = data.get('current') or {}
    vti_interfaces = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_VTI_CONFIGS, verify=False)
    vti_data = vti_interfaces.json()['data']
    configured_vtis = vti_data.get('vti') or {}
    config = remove_deleted_vti_psk_references(current_config, data.get('new') or {}, configured_vtis)
    diff = compare_configs(config, current_config)
    print("Diff config: ")
    print(pprint.pformat(diff, indent=2, width=80))
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))
    # Extract the current vti interface
    current_vti = get_highest_vti_number(vti_data)
    logger.info("Current highest VTI: ")
    logger.info(pprint.pformat(current_vti, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = IpsecCommand(operator='set', resource='interfaces', base_vti=current_vti)
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = IpsecCommand(operator='delete', resource='interfaces', base_vti=current_vti)
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "ipsec"
    curr_config = provider.verify_service.call_get_config(service)
    current_raw_config = curr_config if curr_config else {}
    print("Current raw config:")
    print(pprint.pformat(current_raw_config, indent=2, width=80))
    merged_del_config = merge_dicts_delete(
        current_raw_config,
        new_delete_configs.get('vpn', {}).get('ipsec', {}),
        remove_values=True,
        clean_empty=False,
    )
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('vpn', {}).get('ipsec', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    # Remove VTI bindings before verification to prevent validation errors
    merged_config_for_verify = remove_vti_bindings_from_config(copy.deepcopy(merged_config) if merged_config else {})
    merged_config_for_verify = _normalize_ipsec_verify_config(merged_config_for_verify)
    
    print("Merged config for verification (VTI bindings removed): ")
    print(pprint.pformat(merged_config_for_verify, indent=2, width=80))
    
    verify = None
    if merged_config_for_verify:
        pki = provider.verify_service.call_get_config("pki")
        merged_config_for_verify['pki'] = pki
        # Append preset in verify dict to avoid missing keys error
        if 'dhcp_interfaces' not in merged_config_for_verify:
            merged_config_for_verify['dhcp_interfaces'] = set()
        if 'enabled_vti_interfaces' not in merged_config_for_verify:
            merged_config_for_verify['enabled_vti_interfaces'] = set()
        if 'persistent_vti_interfaces' not in merged_config_for_verify:
            merged_config_for_verify['persistent_vti_interfaces'] = set()
        if 'dhcp_no_address' not in merged_config_for_verify:
            merged_config_for_verify['dhcp_no_address'] = {}
        verify = provider.verify_service.call_verify(service, merged_config_for_verify)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = []
    for command in dict.fromkeys(delete_cmds + set_cmds):
        parsed = json.loads(command)
        path = parsed['path']
        
        if (parsed['op'] == 'delete' and len(path) == 3
                and path[:2] == ['interfaces', 'vti'] and path[2] not in configured_vtis):
            continue
        cmds.append(command)
    if str(verify) != "None" and str(verify) != "" and "Failed to get address from dhcp-interface" not in str(verify):
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    r = []
    if cmds:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
        if not res['success']:
            return r

    # Update DB:
    IPsecConfig.refresh(merged_config)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update IPsec",
                "content": "IPsec is successfully updated"
            }
    )
    
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    return r


def verify_ipsec(provider, data):
    pass

def create_ipsec(provider, data):
    logger.info("Create ipsec:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))
    # Extract the current vti interface
    vti_interfaces = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_VTI_CONFIGS, verify=False)
    current_vti = get_highest_vti_number(vti_interfaces.json()['data'])
    logger.info("Current highest VTI: ")
    logger.info(pprint.pformat(current_vti, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = IpsecCommand(operator='set', resource='interfaces', base_vti=current_vti, mode='CREATE')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = IpsecCommand(operator='delete', resource='interfaces', base_vti=current_vti, mode='CREATE')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "ipsec"
    merged_config = merge_dicts_set({}, new_set_configs.get('vpn', {}).get('ipsec', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config and merged_config.get('vpn', {}).get('ipsec', None):
        merged_config['vpn']['ipsec'] = _normalize_ipsec_verify_config(merged_config['vpn']['ipsec'])
        verify = provider.verify_service.call_verify(
            service, 
            merged_config['vpn']['ipsec']
        )
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update IPsec",
                "content": "IPsec is successfully updated"
            }
    )
    
    r = []
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def fetch_ipsec(data):
    pass

def fetch_ipsec_stats(provider, params=None):
    connections = fetch_ipsec_connections(provider)
    sa_details = fetch_ipsec_sa_detail(provider)
    data = {
        "connections": connections,
        "sa_details": sa_details
    }
    return data

def fetch_ipsec_connections(provider, params=None):
    ipsec_connections = provider.graphql_service.send_request(function_name='ShowConnectionsIpsec', data={}, verify=False)
    data = ipsec_connections.json().get('data', {})
    return data


def fetch_ipsec_sa_detail(provider, params=None):
    ipsec_sa_detail = provider.graphql_service.send_request(function_name='ShowSaDetailIpsec', data={}, verify=False)
    data = ipsec_sa_detail.json().get('data', {})
    return data


def restart_ipsec(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartServiceRestartServiceMutation',
        data={"name": "ipsec"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}


def reset_ipsec_remote_access_all(provider, data=None):
    payload = {
        "op": "reset",
        "path": ["vpn", "ipsec", "remote-access", "all"]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()


def reset_ipsec_site_to_site_all(provider, data=None):
    payload = {
        "op": "reset",
        "path": ["vpn", "ipsec", "site-to-site", "all"]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()


def reset_ipsec_site_to_site_peer(provider, data=None):
    peer_name = (data or {}).get('peer_name', None)
    if not peer_name:
        return []
    payload = {
        "op": "reset",
        "path": ["vpn", "ipsec", "site-to-site", "peer", peer_name]
    }
    req = provider.http_service.send_request(action=Action.RESET, data=json.dumps(payload), verify=False)
    return req.json()
