from optparse import Option
from app.core.operation.password_policy import PasswordPolicyDTO
from pydantic import BaseModel, RootModel, field_validator, Field
from typing import Optional, List, DefaultDict, Dict, Any, Union, Literal
from app.core.operation.validate import validate_ipv4, validate_ipv6, validate_ip_range
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, text, Text, DateTime, JSON
from datetime import datetime
from app.log.logger import logger


class SoftwareUpdateJob(db.Model):
    __tablename__ = "software_update_jobs"

    id = Column(String(36), primary_key=True)
    user_id = Column(String, nullable=False, index=True)
    state = Column(String(16), nullable=False, default="queued", index=True)
    source = Column(Text, nullable=False)
    temporary_path = Column(Text, nullable=True)
    original_filename = Column(String, nullable=True)
    message = Column(Text, nullable=True)
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)

    def serialize(self):
        return {
            "id": self.id,
            "state": self.state,
            "original_filename": self.original_filename,
            "message": self.message,
            "error": self.error,
            "created_at": self.created_at.isoformat() + "Z" if self.created_at else None,
            "started_at": self.started_at.isoformat() + "Z" if self.started_at else None,
            "finished_at": self.finished_at.isoformat() + "Z" if self.finished_at else None,
        }

class UserManagement(db.Model):

    __tablename__ = "vyos_user"
    id = Column(Integer, primary_key=True)
    user_name = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    status = Column(Boolean, default=True)
    role = Column(String, nullable=False)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, users: list, app_context=None):
        try:
            logger.debug(f"Refresh users: {users}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for user_data in users:
                if not isinstance(user_data, dict):
                    continue

                new_user = UserManagement(
                    user_name=user_data.get('user-name'),
                    full_name=user_data.get('full-name'),
                    status=not user_data.get('disable', False),
                    role=user_data.get('type', 'administrator')
                )

                if app_context:
                    with app_context:
                        db.session.add(new_user)
                else:
                    db.session.add(new_user)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing users: {e}")

    @classmethod
    def serialize(cls, user):
        return {
            "user_name": user.user_name,
            "status": user.status,
            "full_name": user.full_name,
            "role": user.role
        }

    @classmethod
    def get_user_permission(cls, user_name):
        user = cls.query.filter_by(user_name=user_name).first()
        if user and user.role and user.role.lower() in ["administrator", "operator", "operator+"]:
            return user.role.lower()
        return None

class UserVerifyDTO(BaseModel):
    user_name: str
    full_name: Optional[str] = None
    password: Optional[str] = None
    disabled: bool
    role: str
    expiry_time: Optional[str] = None


class UpdateUserDTO(BaseModel):
    users: list[UserVerifyDTO]

class CreateInterfaceDTO(BaseModel):
    intf_type: str
    name: str
    address: str
    subnet: str
    desc: Optional[str] = None

    @field_validator('address')
    def validate_ip_address(cls, v):
        if not validate_ipv4(v) and not validate_ipv6(v):
            raise ValueError('Invalid IP address format')
        return v

    @field_validator('subnet')
    def validate_subnet(cls, v, info):
        try:
            # First check if subnet is a valid number
            if not v.isdigit():
                raise ValueError('Subnet must be a valid number')

            # Get the address value from the data
            address = info.data.get('address')
            if address:
                is_ipv6 = validate_ipv6(address)
                if not validate_ip_range(v, is_ipv6):
                    max_range = "128" if is_ipv6 else "32"
                    raise ValueError(f'Invalid subnet range (0-{max_range})')
            return v
        except ValueError as e:
            raise ValueError(str(e))


class OpenVPNSharedSecretKey(db.Model):
    __tablename__ = "vyos_openvpn_shared_secret_key"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    key = Column(Text, nullable=True)
    version = Column(String, nullable=True)


    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, ssk: list, app_context=None):
        try:
            logger.debug(f"Refresh shared secret key: {ssk}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for shared_key in ssk:
                if not isinstance(shared_key, dict):
                    continue

                new_key = OpenVPNSharedSecretKey(
                    name=shared_key.get('name', ''),
                    key=shared_key.get('key', ''),
                    version=shared_key.get('version', '1')
                )

                if app_context:
                    with app_context:
                        db.session.add(new_key)
                else:
                    db.session.add(new_key)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing shared secret key: {e}")
    
    def serialize(self):
        return {
            'name': self.name,
            'key': self.key,
            'version': self.version
        }


class PKIDH(db.Model):
    __tablename__ = "vyos_pki_dh"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    parameters = Column(Text, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, dh_items: list, app_context=None):
        try:
            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for item in dh_items:
                if not isinstance(item, dict):
                    continue

                new_item = PKIDH(
                    name=item.get('name', ''),
                    parameters=item.get('parameters', '')
                )

                if app_context:
                    with app_context:
                        db.session.add(new_item)
                else:
                    db.session.add(new_item)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing DH: {e}")

    def serialize(self):
        return {
            'name': self.name,
            'parameters': self.parameters
        }

class PKICaCertificate(db.Model):
    __tablename__ = "vyos_pki_ca_certificate"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    certificate = Column(Text, nullable=True)
    private_key = Column(Text, nullable=True)
    crl = Column(JSON, nullable=True)
    description = Column(Text, nullable=True)
    revoke = Column(Boolean, default=False, nullable=False)
    system_install = Column(Boolean, default=False, nullable=False)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    
    @classmethod
    def refresh(cls, ca_certificates: list, app_context=None):
        try:
            # logger.debug(f"Refresh ca_certificates: {ca_certificates}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for ca_data in ca_certificates:
                if not isinstance(ca_data, dict):
                    continue

                new_ca = PKICaCertificate(
                    name=ca_data.get('name', ''),
                    certificate=ca_data.get('certificate', ''),
                    private_key=ca_data.get('private_key', ''),
                    crl=ca_data.get('crl', []),
                    description=ca_data.get('description', ''),
                    revoke=ca_data.get('revoke', False),
                    system_install=ca_data.get('system_install', False)
                )

                if app_context:
                    with app_context:
                        db.session.add(new_ca)
                else:
                    db.session.add(new_ca)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing ca_certificates: {e}")

    def serialize(self):
        return {
            'name': self.name,
            'certificate': self.certificate,
            'private_key': self.private_key,
            'crl': self.crl or [],
            'description': self.description or '',
            'revoke': bool(self.revoke),
            'system_install': bool(self.system_install)
        }


class PKICertificate(db.Model):
    __tablename__ = "vyos_pki_certificate"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    certificate = Column(Text, nullable=True)
    private_key = Column(Text, nullable=True)
    acme = Column(JSON, nullable=True)
    description = Column(Text, nullable=True)
    revoke = Column(Boolean, default=False, nullable=False)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, certificates: list, app_context=None):
        try:
            # logger.debug(f"Refresh certificates: {certificates}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for cert_data in certificates:
                if not isinstance(cert_data, dict):
                    continue

                new_cert = PKICertificate(
                    name=cert_data.get('name', ''),
                    certificate=cert_data.get('certificate', ''),
                    private_key=cert_data.get('private_key', ''),
                    acme=cert_data.get('acme'),
                    description=cert_data.get('description', ''),
                    revoke=cert_data.get('revoke', False)
                )

                if app_context:
                    with app_context:
                        db.session.add(new_cert)
                else:
                    db.session.add(new_cert)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing certificates: {e}")

    def serialize(self):
        return {
            'name': self.name,
            'certificate': self.certificate,
            'private_key': self.private_key,
            'acme': self.acme,
            'description': self.description or '',
            'revoke': bool(self.revoke)
        }

class KeyPair(db.Model):
    __tablename__ = "vyos_pki_keypair"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    private_key = Column(Text, nullable=True)
    public_key = Column(Text, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, keypair: list, app_context=None):
        try:
            # logger.debug(f"Refresh keypair: {keypair}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for key_data in keypair:
                if not isinstance(key_data, dict):
                    continue

                new_cert = KeyPair(
                    name=key_data.get('name', ''),
                    private_key=key_data.get('private_key', ''),
                    public_key=key_data.get('public_key', '')
                )

                if app_context:
                    with app_context:
                        db.session.add(new_cert)
                else:
                    db.session.add(new_cert)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing keypair: {e}")

    def serialize(self):
        return {
            'name': self.name,
            'public_key': self.public_key,
            'private_key': self.private_key
        }


class PKIOpenSSHKey(db.Model):
    __tablename__ = "vyos_pki_openssh_key"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    private_key = Column(Text, nullable=True)
    public_key = Column(Text, nullable=True)
    public_key_type = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, keys: list, app_context=None):
        try:
            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for key_data in keys:
                if not isinstance(key_data, dict):
                    continue

                key = PKIOpenSSHKey(
                    name=key_data.get('name', ''),
                    private_key=key_data.get('private_key', ''),
                    public_key=key_data.get('public_key', ''),
                    public_key_type=key_data.get('public_key_type', ''),
                )

                if app_context:
                    with app_context:
                        db.session.add(key)
                else:
                    db.session.add(key)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing OpenSSH keys: {e}")

    def serialize(self):
        return {
            'name': self.name,
            'public_key': self.public_key,
            'public_key_type': self.public_key_type,
            'private_key': self.private_key,
        }


class InterfaceAddressDHCP(db.Model):
    __tablename__ = "vyos_interface_dhcp"
    id = Column(Integer, primary_key=True)
    interface_name = Column(String, nullable=False)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))


    @classmethod
    def refresh(cls, data: any):
        try:
            cls.truncate()

            allowed_intf_types = ['ethernet', 'bridge', 'wireless']

            if not data or not isinstance(data, dict):
                db.session.commit()
                return

            interface_names: set[str] = set()

            def _has_dhcp_address(address_val: any) -> bool:
                if not address_val:
                    return False
                if isinstance(address_val, str):
                    return address_val == 'dhcp'
                if isinstance(address_val, list):
                    return 'dhcp' in address_val
                return False

            def _process_interface_block(interface_type_block: dict):
                if not isinstance(interface_type_block, dict):
                    return
                for ifname, ifcfg in interface_type_block.items():
                    if not isinstance(ifcfg, dict):
                        continue
                    if _has_dhcp_address(ifcfg.get('address')):
                        interface_names.add(ifname)

            interfaces = data.get('interfaces') if 'interfaces' in data else data
            if not isinstance(interfaces, dict):
                db.session.commit()
                return

            for if_type in allowed_intf_types:
                if if_type in interfaces:
                    _process_interface_block(interfaces.get(if_type, {}))

            ethernet_block = interfaces.get('ethernet')
            if isinstance(ethernet_block, dict):
                for parent_ifname, parent_cfg in ethernet_block.items():
                    if not isinstance(parent_cfg, dict):
                        continue
                    vif_block = parent_cfg.get('vif')
                    if not isinstance(vif_block, dict):
                        continue
                    for vlan_id, vif_cfg in vif_block.items():
                        if not isinstance(vif_cfg, dict):
                            continue
                        if _has_dhcp_address(vif_cfg.get('address')):
                            interface_names.add(f"{parent_ifname}.{vlan_id}")

            for ifname in sorted(interface_names):
                db.session.add(cls(interface_name=ifname))

            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            logger.error(f"Error refreshing InterfaceAddressDHCP: {e}")


class UpdateInterfaceDTO(BaseModel):
    name: str
    intf_type: str
    desc: Optional[str] = None
    address: Optional[str] = None


class UpdateInterfaceByNameGeneralDTO(BaseModel):
    desc: Optional[str] = None

class UpdateInterfaceByNameLinkDTO(BaseModel):
    speed: Optional[str] = None
    duplex: Optional[str] = None
    

class GeneralDTO(BaseModel):
    enabled: Optional[bool] = None
    description: Optional[str] = None
    hwId: Optional[str] = None


class EthernetGeneralDTO(BaseModel):
    disabled: Optional[bool] = None
    description: Optional[str] = None
    hwId: Optional[str] = None


class LinkDTO(BaseModel):
    autoNegotiation: Optional[bool] = None
    speed: Optional[str] = None
    duplex: Optional[str] = None
    mtu: Optional[int] = None
    macTimeout: Optional[int] = None
    disableFlowControl: Optional[bool] = None
    disableLinkDetect: Optional[bool] = None

    @field_validator('mtu', 'macTimeout', mode='before')
    @classmethod
    def empty_string_to_none(cls, value):
        if isinstance(value, str) and value.strip() == "":
            return None
        return value

    
class IPv4StaticDTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    prefixLength: Optional[str|int] = None

class IPv4DHCPOptionsDTO(BaseModel):
    clientId: Optional[str] = None
    defaultRouteDistance: Optional[int] = None
    hostname: Optional[str] = None
    mtu: Optional[int] = None
    dontInstallDefaultRoute: Optional[bool] = None
    reject: Optional[bool] = None
    userClass: Optional[str] = None
    vendorClass: Optional[str] = None

    @field_validator('defaultRouteDistance', 'mtu', mode='before')
    @classmethod
    def empty_string_to_none(cls, value):
        if isinstance(value, str) and value.strip() == "":
            return None
        return value

class IPv4DHCPDTO(BaseModel):
    enabled: Optional[bool] = None
    options: IPv4DHCPOptionsDTO

class IPv4DTO(BaseModel):
    mode: Optional[str] = None
    static: IPv4StaticDTO
    dhcp: IPv4DHCPDTO

class IPv6StaticDTO(BaseModel):
    address: Optional[str] = None
    prefix: Optional[str|int] = None

class IPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    dontSendRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    pd: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class IPv6DHCPv6DTO(BaseModel):
    enabled: Optional[bool] = None
    requestPrefixDelegation: Optional[bool] = None
    options: IPv6DHCPv6OptionsDTO

class IPv6AutoconfDTO(BaseModel):
    enabled: Optional[bool] = None

class IPv6DelegatedDTO(BaseModel):
    enabled: Optional[bool] = None

class IPv6DTO(BaseModel):
    mode: Optional[str] = None
    static: IPv6StaticDTO
    dhcpv6: IPv6DHCPv6DTO
    autoconf: IPv6AutoconfDTO
    delegated: IPv6DelegatedDTO


class NetworkDTO(BaseModel):
    bridgeMode: Optional[bool] = None
    bridgeInterface: Optional[str] = None
    ipv4: IPv4DTO
    ipv6: IPv6DTO

class EthernetNetworkDTO(BaseModel):
    bridgeMode: Optional[bool] = None
    bridgeInterface: Optional[str] = None
    ipv4: Optional[IPv4DTO] = None
    ipv6: Optional[IPv6DTO] = None


class WifiSecurityDTO(BaseModel):
    type: Optional[str] = None
    encryption: Optional[str|list] = None


class ModeChannelWidthDTO(BaseModel):
    channelWidth: Optional[str] = None


class ModeChannelWidthMultipleDTO(BaseModel):
    channelWidth: Optional[list] = None


class WifiAdvancedDTO(BaseModel):
    hiddenSSID: Optional[bool] = None
    preventBridging: Optional[bool] = None
    managementFrameProtection: Optional[str] = None
    maxClients: Optional[int] = None
    beaconProtection: Optional[bool] = None
    disassociateOnFailures: Optional[bool] = None
    dedicatedThreadPerClient: Optional[bool] = None
    mode: Optional[str] = None
    acMode: Optional[ModeChannelWidthDTO] = None
    axMode: Optional[ModeChannelWidthDTO] = None
    nMode: Optional[ModeChannelWidthMultipleDTO] = None

class WifiIPv4StaticDTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    prefixLength: Optional[int] = None

class WifiIPv4DHCPOptionsDTO(BaseModel):
    clientId: str
    defaultRouteDistance: int
    hostname: str
    mtu: int
    dontInstallDefaultRoute: Optional[bool] = None
    reject: Optional[bool] = None
    userClass: Optional[str] = None
    vendorClass: Optional[str] = None

class WifiIPv4DHCPDTO(BaseModel):
    enabled: Optional[bool] = None
    options: WifiIPv4DHCPOptionsDTO

class WifiIPv4DTO(BaseModel):
    static: WifiIPv4StaticDTO
    dhcp: WifiIPv4DHCPDTO

class WifiIPv6StaticDTO(BaseModel):
    address: Optional[str] = None
    prefix: Optional[int] = None

class WifiIPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    dontSendRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    pd: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class WifiIPv6DHCPv6DTO(BaseModel):
    enabled: bool
    options: WifiIPv6DHCPv6OptionsDTO

class WifiIPv6DTO(BaseModel):
    mode: str
    static: WifiIPv6StaticDTO
    dhcpv6: WifiIPv6DHCPv6DTO

class WifiNetworkDTO(BaseModel):
    bridgeMode: Optional[bool] = None
    bridgeInterface: Optional[str] = None
    ipMode: Optional[str] = None
    ipv4: Optional[WifiIPv4DTO] = None
    ipv6: Optional[WifiIPv6DTO] = None

class DefaultRouteDTO(BaseModel):
    GHz5: Optional[str] = None
    GHz24: Optional[str] = None

class WifiClientIPv4DHCPOPTIONSDTO(BaseModel):
    defaultRoute: DefaultRouteDTO


class WifiClientIPv4DTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    dhcpOptions: Optional[WifiClientIPv4DHCPOPTIONSDTO] = None

class WifiClientIPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    noRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class WifiClientIPv6DTO(BaseModel):
    mode: Optional[Literal['static', 'dhcpv6', 'autoconf']] = None
    address: Optional[str] = None
    prefix: Optional[int] = None
    dhcpv6Options: Optional[WifiClientIPv6DHCPv6OptionsDTO] = None

class WifiClientNetworkDTO(BaseModel):
    ipConfig: Optional[str] = None
    ipv4: Optional[WifiClientIPv4DTO] = None
    ipv6: Optional[WifiClientIPv6DTO] = None

class WifiClientDTO(BaseModel):
    enabled: Optional[bool] = None
    enabled5: Optional[bool] = None
    enabled24: Optional[bool] = None
    ssid: Optional[str] = None
    password: Optional[str] = None
    security: Optional[str] = None
    network: Optional[WifiClientNetworkDTO] = None

class AccessControlDTO(BaseModel):
    enabled: Optional[bool] = None
    acceptList: Optional[List[str]] = None
    denyList: Optional[List[str]] = None
    mode: Optional[str] = None

class WifiInterfaceDTO(BaseModel):
    enabled: bool
    enabled5: bool
    enabled24: bool
    description: str
    ssid: str
    security: WifiSecurityDTO
    password: str
    advanced: WifiAdvancedDTO
    network: WifiNetworkDTO
    client: WifiClientDTO
    accessControl: AccessControlDTO
    countryCode: Optional[str] = None


class SystemDTO(BaseModel):
    countryCode: Optional[str] = None


class PoolDTO(BaseModel):
    description: Optional[str] = None
    dhcp_type: Optional[str] = None
    enabled: Optional[bool] = None
    range_end: str
    range_start: str
    interface: Optional[str] = None
    lease_time: Optional[str] = None
    subnet: str
    dhcp_name: str
    subnet_id: str
    default_router: Optional[str] = None
    name_server: Optional[str] = None
    domain_name: Optional[str] = None
    ip_range_type: Optional[str] = None
    boot_file: Optional[str] = None
    authoritative: Optional[bool] = None


class UpdateWifiInterfaceByNameDTO(BaseModel):
    wifi: WifiInterfaceDTO
    dhcp: PoolDTO
    system: SystemDTO


class CreateOpenVPNGeneralDTO(BaseModel):
    enabled: bool
    description: Optional[str] = None
    mode: Optional[str] = None
    name: str


class OpenVPNGeneralDTO(BaseModel):
    enabled: bool
    description: Optional[str] = None
    mode: Optional[str] = None

class OpenVPNClientIpPoolDTO(BaseModel):
    disabled: bool
    start: str
    stop: str
    subnetMask: str

class OpenVPNClientIpv6PoolDTO(BaseModel):
    disabled: bool
    base: str

class OpenVPNClientOverridesDTO(BaseModel):
    name: str
    ip: str
    pushRoute: List[str]
    subnet: List[str]

class OpenVPNServerDTO(BaseModel):
    bridge: Optional[str] = None
    clientIpPool: Optional[OpenVPNClientIpPoolDTO] = None
    clientIpv6Pool: Optional[OpenVPNClientIpv6PoolDTO] = None
    clients: Optional[List[OpenVPNClientOverridesDTO]] = None
    domainName: Optional[str] = None
    maxConnections: Optional[int] = None
    nameServer: Optional[List[str]] = None
    pushRoutes: Optional[List[str]] = None
    rejectUnconfiguredClients: bool
    subnet: Optional[str] = None
    topology: Optional[str] = None

class OpenVPNKeepAliveDTO(BaseModel):
    failureCount: Optional[Union[int, str]] = None
    interval: Optional[Union[int, str]] = None

class OpenVPNAdvancedDTO(BaseModel):
    ipVersion: str
    keepAlive: OpenVPNKeepAliveDTO
    persistentTunnel: bool
    useLzoCompression: bool
    replaceDefaultRoute: bool

class OpenVPNDTO(BaseModel):
    deviceType: Optional[str] = None
    localAddress: Optional[str] = None
    localHost: Optional[List[str]] = None
    localPort: Optional[Union[int, str]] = None
    protocol: str
    remoteAddress: Optional[str] = None
    remoteHost: Optional[List[str]] = None
    remotePort: Optional[Union[int, str]] = None
    server: OpenVPNServerDTO
    advanced: OpenVPNAdvancedDTO

class OpenVPNTlsDTO(BaseModel):
    authKey: Optional[List[str]] = None
    caCert: str
    certificate: str
    cryptKey: Optional[List[str]] = None
    dhParams: Optional[str] = None
    peerFingerprint: Optional[List[str]] = None
    role: Optional[str] = None
    tlsVersionMin: Optional[str] = None

class OpenVPNEncryptionDTO(BaseModel):
    cipher: Optional[str] = None
    dataCiphersFallback: Optional[str] = None
    dataCiphers: List[str]

class OpenVPNHashDTO(BaseModel):
    algorithm: Optional[str] = None

class OpenVPNSecurityDTO(BaseModel):
    tls: OpenVPNTlsDTO
    encryption: OpenVPNEncryptionDTO
    hash: OpenVPNHashDTO
    sharedSecretKey: Optional[str] = None

class CreateOpenvpnInterfaceDTO(BaseModel):
    general: CreateOpenVPNGeneralDTO
    openvpn: OpenVPNDTO
    security: OpenVPNSecurityDTO

class UpdateOpenVPNInterfaceByNameDTO(BaseModel):
    general: OpenVPNGeneralDTO
    openvpn: OpenVPNDTO
    security: OpenVPNSecurityDTO

class UpdateAllOpenvpnInterfacesDTO(BaseModel):
    interfaces: List['CreateOpenvpnInterfaceDTO']

class DeleteInterfaceDTO(BaseModel):
    name: str
    intf_type: str

class DeleteInterfaceListDTO(RootModel):
    root: List[DeleteInterfaceDTO]
    
    def __iter__(self):
        return iter(self.root)

    def __getitem__(self, item):
        return self.root[item]

class DeleteInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    address: str


class UpdateInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    current_address: str
    new_address: str


class CreateInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    address: str

class UpdateSystemDatetimeDTO(BaseModel):
    date: str
    time: str
    timezone: str

class UpdateSystemInfoDTO(BaseModel):
    systemName: Optional[str] = None
    domainName: Optional[str] = None
    dateTime: Optional[str] = None
    timezone: Optional[str] = None
    ipv4: Optional[bool] = None
    ipv6: Optional[bool] = None
    password_policy: Optional[PasswordPolicyDTO] = None


class OnboardingConfigurationDTO(BaseModel):
    timezone: str = Field(min_length=1)
    dateTime: Optional[str] = None
    password: str = Field(min_length=1)
    enhancedSecurity: bool = False
    minlen: int = Field(default=9, ge=9, le=20)
    ucredit: int = Field(default=1, ge=1, le=8)
    dcredit: int = Field(default=1, ge=1, le=8)
    ocredit: int = Field(default=1, ge=1, le=8)

    @field_validator('timezone')
    @classmethod
    def validate_timezone(cls, value):
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        timezone = value.strip()
        try:
            ZoneInfo(timezone)
        except (ValueError, ZoneInfoNotFoundError):
            raise ValueError('Invalid timezone')
        return timezone

    @field_validator('dateTime')
    @classmethod
    def validate_datetime(cls, value):
        if value is None:
            return None
        if 'T' not in value:
            raise ValueError('Invalid date and time')
        try:
            datetime.fromisoformat(value)
        except ValueError:
            raise ValueError('Invalid date and time')
        return value

class WireguardPeerDTO(BaseModel):
    name: str
    public_key: str
    description: Optional[str] = None
    allowed_ips: List[str]
    preshared_key: Optional[str] = None
    host_name: Optional[str] = None
    persistent_keepalive: Optional[Union[int, str]] = None
    address: Optional[str] = None
    port: Optional[Union[int, str]] = None

    @field_validator('public_key')
    def blank_public_key(value, field):
        if value == "":
            return None
        return value

    @field_validator('allowed_ips')
    def empty_allowed_ips(value, field):
        if isinstance(value, list) and len(value) == 0:
            return None
        return value

class UpdateWireguardInterfaceByNameDTO(BaseModel):
    enabled: Optional[bool] = None
    description: Optional[str] = None
    address: Optional[List[str]] = None
    listen_port: Optional[int] = None
    private_key: str
    peer: Optional[List[WireguardPeerDTO]] = None
    mtu: Optional[int] = None
    dns_retry: Optional[int] = None
    
    @field_validator('private_key')
    def blank_private_key(value, field):
        if value == "":
            return None
        return value    
    
    @field_validator('mtu')
    def blank_mtu(value, field):
        if value == "":
            return None
        return value

    @field_validator('listen_port')
    def validate_listen_port(value, field):
        if value in (None, ""):
            return None
        if value < 1 or value > 65535:
            raise ValueError('listen_port must be between 1 and 65535')
        return value

    @field_validator('dns_retry')
    def validate_dns_retry(value, field):
        if value in (None, ""):
            return None
        if value < 1 or value > 15:
            raise ValueError('dns_retry must be between 1 and 15')
        return value

    @field_validator('mtu')
    def validate_mtu(value, field):
        if value in (None, ""):
            return None
        if value < 68 or value > 16000:
            raise ValueError('mtu must be between 68 and 16000')
        return value

class CreateWireguardInterfaceDTO(BaseModel):
    name: str
    enabled: bool
    description: Optional[str] = None
    address: List[str]
    listen_port: int
    private_key: str
    peer: List[WireguardPeerDTO] = []
    mtu: Optional[int] = None
    dns_retry: Optional[int] = None

    @field_validator('listen_port')
    def validate_create_listen_port(value, field):
        if value < 1 or value > 65535:
            raise ValueError('listen_port must be between 1 and 65535')
        return value

    @field_validator('dns_retry', mode='before')
    def validate_create_dns_retry(value, field):
        if value in (None, ""):
            return None
        if value < 1 or value > 15:
            raise ValueError('dns_retry must be between 1 and 15')
        return value

    @field_validator('mtu', mode='before')
    def validate_create_mtu(value, field):
        if value in (None, ""):
            return None
        if value < 68 or value > 16000:
            raise ValueError('mtu must be between 68 and 16000')
        return value


class UpdateAllWireguardInterfacesDTO(BaseModel):
    interfaces: List['CreateWireguardInterfaceDTO']


class OpenVPNMonitorDTO(BaseModel):
    openvpn_type: str

class IPConfigurationDTO(BaseModel):
    adjustMss: Optional[str] = None
    arpCacheTimeout: Optional[str] = None
    disableArpFilter: Optional[bool] = None
    disableForwarding: Optional[bool] = None
    enableArpAccept: Optional[bool] = None
    enableArpAnnounce: Optional[bool] = None
    enableArpIgnore: Optional[bool] = None
    enableDirectedBroadcast: Optional[bool] = None
    enableProxyArp: Optional[bool] = None
    proxyArpPvlan: Optional[bool] = None
    sourceValidation: Optional[str] = None
    # IPv6 options
    ipv6AddressAutoconf: Optional[bool] = None
    ipv6DisableForwarding: Optional[bool] = None
    ipv6DupAddrDetectTransmits: Optional[str] = None
    ipv6AcceptDad: Optional[str] = None
    ipv6AdjustMss: Optional[str] = None
    ipv6BaseReachableTime: Optional[str] = None
    ipv6SourceValidation: Optional[str] = None
    ipv6AddressEui64: Optional[str] = None
    ipv6InterfaceIdentifier: Optional[str] = None
    ipv6AddressNoDefaultLinkLocal: Optional[bool] = None
    # Add alternative fields
    acceptDad: Optional[str] = None
    baseReachableTime: Optional[str] = None
    dupAddrDetectTransmits: Optional[str] = None
    addressAutoconf: Optional[bool] = None
    addressEui64: Optional[str] = None
    interfaceIdentifier: Optional[str] = None
    addressNoDefaultLinkLocal: Optional[bool] = None

class DHCPConfigurationDTO(BaseModel):
    dhcpClientId: Optional[str] = None
    dhcpDefaultRouteDistance: Optional[str] = None
    dhcpHostName: Optional[str] = None
    dhcpMtu: Optional[bool] = None
    dhcpNoDefaultRoute: Optional[bool] = None
    dhcpUserClass: Optional[str] = None
    dhcpVendorClassId: Optional[str] = None
    dhcpv6Duid: Optional[str] = None
    dhcpv6NoRelease: Optional[bool] = None
    dhcpv6ParametersOnly: Optional[bool] = None
    dhcpv6NoRequestDomainName: Optional[bool] = None
    dhcpv6NoRequestDns: Optional[bool] = None
    dhcpv6RapidCommit: Optional[bool] = None
    dhcpv6Temporary: Optional[bool] = None
    dhcpv6Pd: Optional[dict] = None

class VlanMemberDTO(BaseModel):
    interfaceName: str
    vlanId: str
    ipv4Address: Optional[str] = None
    ipv6Address: Optional[str] = None
    ipv4Mode: Optional[str] = None
    ipv6Mode: Optional[str] = None
    address: Optional[Union[str, List[str]]] = None
    # address: Optional[str] = None
    description: Optional[str] = None
    mtu: Optional[str] = None
    disabled: Optional[bool] = None
    ip: Optional[IPConfigurationDTO] = None
    dhcp: Optional[DHCPConfigurationDTO] = None

class VlanGroupDTO(BaseModel):
    id: str
    name: str
    members: List[VlanMemberDTO] = []

class UpdateVlanInterfaceDTO(BaseModel):
    groups: List[VlanGroupDTO] = []

class UpdateEthernetInterfaceByNameDTO(BaseModel):
    general: EthernetGeneralDTO
    link: LinkDTO
    network: EthernetNetworkDTO
    ip: Optional[IPConfigurationDTO] = None
    dhcp: Optional[DHCPConfigurationDTO] = None

class CreateBridgeInterfaceDTO(BaseModel):
    name: str
    general: Optional[GeneralDTO] = None
    link: Optional[LinkDTO] = None
    network: Optional[NetworkDTO] = None
    description: Optional[str] = None
    disabled: Optional[bool] = None
    mtu: Optional[str] = None
    aging: Optional[str] = None
    disableLinkDetect: Optional[bool] = None
    addresses: Optional[List[str]] = None
    members: Optional[List[str]] = None
    # Add alternative field names
    ipv4Mode: Optional[str] = None
    ipv6Mode: Optional[str] = None
    ipv4Address: Optional[str] = None
    ipv6Address: Optional[str] = None
    member: Optional[dict] = None
    ip: Optional[IPConfigurationDTO] = None
    dhcp: Optional[DHCPConfigurationDTO] = None

class UpdateBridgeInterfaceDTO(BaseModel):
    name: str
    general: Optional[GeneralDTO] = None
    link: Optional[LinkDTO] = None
    network: Optional[NetworkDTO] = None
    description: Optional[str] = None
    disabled: Optional[bool] = None
    mtu: Optional[str] = None
    aging: Optional[str] = None
    disableLinkDetect: Optional[bool] = None
    addresses: Optional[List[str]] = None
    members: Optional[List[str]] = None
    # Add alternative field names
    ipv4Mode: Optional[str] = None
    ipv6Mode: Optional[str] = None
    ipv4Address: Optional[str] = None
    ipv6Address: Optional[str] = None
    member: Optional[dict] = None
    ip: Optional[IPConfigurationDTO] = None
    dhcp: Optional[DHCPConfigurationDTO] = None

class SysLogDTO(BaseModel):
    count: Optional[int] = None
    minutes: Optional[int] = None
    keyword: Optional[str] = None
    syslog_identifier: Optional[str] = None
    priority: Optional[int] = None
    unit: Optional[str] = None
    protocol: Optional[str] = None

class IPSecRSAAuthDTO(BaseModel):
    localKey: Optional[str] = None
    remoteKey: Optional[str] = None
    passphrase: Optional[str] = None

class IPSecX509AuthDTO(BaseModel):
    caCertificate: List[str] = []
    certificate: Optional[str] = None
    passphrase: Optional[str] = None

class IPSecAuthenticationDTO(BaseModel):
    localId: Optional[str] = None
    mode: str = "pre-shared-secret"
    remoteId: Optional[str] = None
    useX509Id: bool = False
    rsa: IPSecRSAAuthDTO = IPSecRSAAuthDTO()
    x509: IPSecX509AuthDTO = IPSecX509AuthDTO()

class IPSecTunnelLocalDTO(BaseModel):
    prefix: List[str] = []
    port: Optional[int] = None
    priority: Optional[int] = None
    protocol: Optional[str] = None

class IPSecTunnelRemoteDTO(BaseModel):
    prefix: List[str] = []
    port: Optional[int] = None

class IPSecTunnelDTO(BaseModel):
    id: Union[str, int]
    enabled: bool = True
    espGroup: Optional[str] = None
    local: IPSecTunnelLocalDTO = IPSecTunnelLocalDTO()
    remote: IPSecTunnelRemoteDTO = IPSecTunnelRemoteDTO()
    
    @field_validator('id')
    @classmethod
    def convert_id_to_string(cls, v):
        return str(v) if v is not None else v

class IPSecPeerDTO(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = True
    authentication: IPSecAuthenticationDTO = IPSecAuthenticationDTO()
    connectionType: Optional[str] = None
    defaultEspGroup: Optional[str] = None
    espGroup: Optional[str] = None
    dhcpInterface: Optional[str] = None
    forceUdpEncapsulation: bool = False
    ikeGroup: Optional[str] = None
    ikev2Reauth: Optional[Union[bool, str]] = None
    localAddress: Optional[str] = None
    remoteAddress: List[str] = []
    replayWindow: Optional[Union[str, int]] = None
    tunnels: List[IPSecTunnelDTO] = []
    virtualAddress: List[str] = []
    vti: Optional[str] = None
    vtiAddress: Optional[str] = None
    trafficSelectorLocalPrefix: List[str] = []
    trafficSelectorRemotePrefix: List[str] = []

class IPSecSiteToSiteDTO(BaseModel):
    peers: List[IPSecPeerDTO] = []

class IPSecLocalUserDTO(BaseModel):
    username: str
    enabled: bool = True
    password: Optional[str] = None

class IPSecConnectionLocalDTO(BaseModel):
    port: Optional[int] = None
    prefix: List[str] = []
    address: Optional[str] = None

    @field_validator('port', mode='before')
    @classmethod
    def empty_port_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecConnectionPoolsDTO(BaseModel):
    name: List[str] = []
    dhcp: Optional[str] = None
    radius: Optional[str] = None

class IPSecConnectionAuthenticationDTO(BaseModel):
    clientMode: Optional[str] = None
    eapId: Optional[str] = "any"
    localId: Optional[str] = None
    localUsers: List[IPSecLocalUserDTO] = []
    preSharedSecret: Optional[str] = None
    serverMode: str = "x509"
    x509: IPSecX509AuthDTO = IPSecX509AuthDTO()

class IPSecRemoteAccessConnectionDTO(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = True
    bind: Optional[str] = None
    vtiAddress: Optional[str] = None
    dhcpInterface: Optional[str] = None
    ikeGroup: Optional[str] = None
    espGroup: Optional[str] = None
    local: IPSecConnectionLocalDTO = IPSecConnectionLocalDTO()
    pools: IPSecConnectionPoolsDTO = IPSecConnectionPoolsDTO()
    replayWindow: Optional[Union[str, int]] = None
    timeout: int = 28800
    unique: str = "never"
    authentication: IPSecConnectionAuthenticationDTO = IPSecConnectionAuthenticationDTO()

class IPSecDHCPDTO(BaseModel):
    interface: Optional[str] = None
    server: Optional[str] = None

class IPSecPoolRangeDTO(BaseModel):
    start: Optional[str] = None
    stop: Optional[str] = None

class IPSecPoolDTO(BaseModel):
    name: str
    exclude: List[str] = []
    nameServer: List[str] = []
    prefix: Optional[str] = None
    range: IPSecPoolRangeDTO = IPSecPoolRangeDTO()

class IPSecRadiusServerDTO(BaseModel):
    address: str
    enabled: bool = True
    disableAccounting: bool = False
    port: Optional[int] = None
    key: Optional[str] = None

    @field_validator('port', mode='before')
    @classmethod
    def empty_port_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecRadiusDTO(BaseModel):
    nasIdentifier: Optional[str] = None
    timeout: Optional[int] = None
    servers: List[IPSecRadiusServerDTO] = []

    @field_validator('nasIdentifier', 'timeout', mode='before')
    @classmethod
    def empty_radius_field_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecRemoteAccessDTO(BaseModel):
    connections: List[IPSecRemoteAccessConnectionDTO] = []
    dhcp: IPSecDHCPDTO = IPSecDHCPDTO()
    pools: List[IPSecPoolDTO] = []
    radius: IPSecRadiusDTO = IPSecRadiusDTO()

class IPSecOptionsDTO(BaseModel):
    interface: Optional[str] = None
    disableRouteAutoinstall: bool = False
    flexvpn: bool = False
    virtualIp: Optional[str] = None
    disableUniqreqids: bool = False

class IPSecRetransmissionDTO(BaseModel):
    attempt: int = 5
    base: float = 1.0
    timeout: int = 4

class IPSecGeneralDTO(BaseModel):
    siteToSite: IPSecSiteToSiteDTO = IPSecSiteToSiteDTO()
    remoteAccess: IPSecRemoteAccessDTO = IPSecRemoteAccessDTO()
    options: IPSecOptionsDTO = IPSecOptionsDTO()
    retransmission: IPSecRetransmissionDTO = IPSecRetransmissionDTO()

class IPSecPresharedKeyDTO(BaseModel):
    name: str
    id: Optional[str] = None
    secret: Optional[str] = None
    secretType: str = "plaintext"

class IPSecDeadPeerDetectionDTO(BaseModel):
    action: Optional[str] = None
    interval: int = 30
    timeout: int = 120

class IPSecIKEAdvancedDTO(BaseModel):
    closeAction: str = "none"
    deadPeerDetection: IPSecDeadPeerDetectionDTO = IPSecDeadPeerDetectionDTO()
    disableMobike: bool = False
    ikev2Reauth: bool = False
    keyExchange: str = "ikev2"
    lifetime: int = 28800
    mode: str = "main"

class IPSecProposalDTO(BaseModel):
    number: Optional[Union[str, int]] = None
    dhGroup: Optional[Union[str, int]] = None
    encryption: Optional[str] = None
    hash: Optional[str] = None
    prf: Optional[str] = None
    
    @field_validator('number', 'dhGroup')
    @classmethod
    def convert_to_string(cls, v):
        return str(v) if v is not None else v

class IPSecIKEGroupDTO(BaseModel):
    name: str
    advanced: IPSecIKEAdvancedDTO = IPSecIKEAdvancedDTO()
    proposals: List[IPSecProposalDTO] = []

class IPSecESPGroupDTO(BaseModel):
    name: str
    compression: bool = False
    disableRekey: bool = False
    lifeBytes: Optional[int] = None
    lifePackets: Optional[int] = None
    lifetime: Optional[int] = None
    mode: str = "tunnel"
    pfs: str = "enable"
    proposals: List[IPSecProposalDTO] = []

class IPSecSecurityDTO(BaseModel):
    presharedKeys: List[IPSecPresharedKeyDTO] = []
    ikeGroups: List[IPSecIKEGroupDTO] = []
    espGroups: List[IPSecESPGroupDTO] = []

class CreateIPsecInterfaceDTO(BaseModel):
    name: Optional[str] = None
    type: str = "ipsec"
    general: IPSecGeneralDTO = IPSecGeneralDTO()
    security: IPSecSecurityDTO = IPSecSecurityDTO()
    interface: Optional[str] = None
    disableUniqreqids: bool = False

class UpdateIPsecInterfaceDTO(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = "ipsec"
    general: Optional[IPSecGeneralDTO] = None
    security: Optional[IPSecSecurityDTO] = None
    interface: Optional[str] = None
    disableUniqreqids: Optional[bool] = None


class CreateIPTunnelInterfaceDTO(BaseModel):
    tunnel_name: str
    tunnel_type: str = "gre"  # gre, ipip, sit, vti
    description: str = ""
    disable: bool = False
    source_address: str = ""
    remote_address: str = ""
    ttl: Optional[int] = None
    tos: str = ""
    mtu: Optional[int] = None
    multicast: bool = False
    gre_key: str = ""
    gre_checksum: bool = False
    sit_6rd_prefix: str = ""
    sit_6rd_relay_prefix: str = ""
    ipv4_addresses: List[str] = []
    ipv6_addresses: List[str] = []
    ipv6_eui64_prefix: str = ""


class UpdateIPTunnelInterfaceDTO(BaseModel):
    tunnel_name: Optional[str] = None
    tunnel_type: Optional[str] = "gre"
    description: Optional[str] = ""
    disable: Optional[bool] = False
    source_address: Optional[str] = ""
    remote_address: Optional[str] = ""
    ttl: Optional[int] = None
    tos: Optional[str] = ""
    mtu: Optional[int] = None
    multicast: Optional[bool] = False
    disable_link_detect: Optional[bool] = False
    # IP General Options
    ip_arp_cache_timeout: Optional[int] = None
    ip_adjust_mss: Optional[str] = ""
    ip_enable_arp_accept: Optional[bool] = False
    ip_enable_arp_announce: Optional[bool] = False
    ip_disable_arp_filter: Optional[bool] = False
    ip_enable_arp_ignore: Optional[bool] = False
    ip_enable_directed_broadcast: Optional[bool] = False
    ip_disable_forwarding: Optional[bool] = False
    ip_enable_proxy_arp: Optional[bool] = False
    ip_enable_proxy_arp_pvlan: Optional[bool] = False
    ip_source_validation: Optional[str] = ""
    gre_key: Optional[str] = ""
    gre_checksum: Optional[bool] = False
    sit_6rd_prefix: Optional[str] = ""
    sit_6rd_relay_prefix: Optional[str] = ""
    ipv4_addresses: Optional[List[str]] = []
    ipv6_addresses: Optional[List[str]] = []
    ipv6_eui64_prefix: Optional[str] = ""
    ipv6_accept_dad: Optional[int] = None
    ipv6_dup_addr_detect_transmits: Optional[int] = None
    ipv6_base_reachable_time: Optional[int] = None
    ipv6_address_autoconf: Optional[bool] = False
    ipv6_adjust_mss: Optional[str] = ""
    ipv6_disable_forwarding: Optional[bool] = False
    ipv6_source_validation: Optional[str] = ""
    ipv6_no_default_link_local: Optional[bool] = False
    erspan_direction: Optional[str] = ""
    
