
from app.core.vpn.pptp.command_pptp import PPTPCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_PPTP
from app.core.vpn.pptp.models import PPTPConfig

def update_pptp(provider, data):

    logger.info("Update PPTP:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    if not config or config == {}:
        print("Empty config detected - deleting entire PPTP configuration")
        delete_cmd = '{"op": "delete", "path": ["vpn", "pptp"]}'
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_cmd,
            verify=False,
        )

        res_json = res.json()

        if res_json.get('success'):
            print("PPTP configuration deleted successfully")
            PPTPConfig.truncate()
        else:
            print("Failed to delete PPTP configuration")
            return [{
                "success": False,
                "error": res_json.get('error'),
                "cmd": delete_cmd
        }]
        
        socket_manager.emit_to_user(
            username, 
            event='notification', 
            data={
                "id": str(uuid4()),
                "type": "success",
                "title": "Success: Delete PPTP",
                "content": "PPTP configuration deleted successfully"
            }
        )
        
        return [{"success": True, "cmd": delete_cmd}]

    set_cmds = []
    iface_set_cmd = PPTPCommand(operator='set', resource='vpn')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = PPTPCommand(operator='delete', resource='vpn')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "pptp"
    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('vpn', {}).get('pptp', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('vpn', {}).get('pptp', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB:
    PPTPConfig.refresh(config)
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update PPTP",
                "content": "PPTP is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_pptp(provider, data):
    config_to_verify = data
    verify = provider.verify_service.call_verify("pptp", config_to_verify)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify

def fetch_pptp_sessions(provider, params=None):
    pptp_sessions = provider.graphql_service.send_request(function_name="ShowPptpServerSessionsPerlePptpServerQuery", data={}, verify=False)
    data = pptp_sessions.json().get('data', {})
    return data

def fetch_pptp_statistics(provider, params=None):
    pptp_statistics = provider.graphql_service.send_request(function_name="ShowPptpServerStatisticsPerlePptpServerQuery", data={}, verify=False)
    data = pptp_statistics.json().get('data', {})
    return data

def fetch_pptp(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_PPTP, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data
