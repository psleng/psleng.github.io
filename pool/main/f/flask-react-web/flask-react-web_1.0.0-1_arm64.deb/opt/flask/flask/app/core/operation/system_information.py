import re
import string
from datetime import datetime
import pytz
import pprint

def parse_datetime(data):
    """Parse date and time from VyOS output."""
    try:
        # VyOS returns date in format: Mon Mar  3 02:04:06 PM EST 2025
        pattern = r'(\w+)\s+(\w+)\s+(\d+)\s+(\d+):(\d+):(\d+)\s+([AP]M)\s+(\w+)\s+(\d{4})'
        match = re.match(pattern, data.strip())
        
        if not match:
            raise ValueError(f"Could not parse datetime string: {data}")
            
        weekday, month, day, hour, minute, second, ampm, tz, year = match.groups()
        
        hour = int(hour)
        if ampm == 'PM' and hour != 12:
            hour += 12
        elif ampm == 'AM' and hour == 12:
            hour = 0
            
        return f"{year}-{datetime.strptime(month, '%b').month:02d}-{int(day):02d}T{hour:02d}:{minute}:{second}"
            
    except Exception as e:
        print(f"Error parsing datetime: {str(e)}")
        return ""

def parse_timezone(data):
    try:
        if isinstance(data, dict) and 'time-zone' in data:
            return data['time-zone']
        return ""
    except Exception as e:
        print(f"Error parsing timezone: {str(e)}")
        return ""

def parse_boot_img(text):
    try:
        lines = text.strip().split('\n')
        if len(lines) > 2:
            boot_images = []
            for i in range(2, len(lines)):
                if not lines[i].strip():
                    continue
                
                parts = lines[i].split()
                if len(parts) >= 3:
                    image = {
                        "name": parts[0],
                        "default_boot": parts[1] == "Yes",
                        "running": parts[2] == "Yes"
                    }
                    boot_images.append(image)
                    if image["running"]:
                        return image
                elif len(parts) >= 1:
                    image = {
                        "name": parts[0],
                        "default_boot": False,
                        "running": False
                    }
                    boot_images.append(image)
            
            if boot_images:
                return boot_images[0]
        
        return {
            "name": "",
            "default_boot": False,
            "running": False
        }
    except Exception as e:
        print(f"Error parsing boot image: {str(e)}")
        return {
            "name": "",
            "default_boot": False,
            "running": False
        }

def parse_boot_images(text):
    try:
        boot_images = []
        for line in text.strip().split('\n')[2:]:
            if not line.strip():
                continue

            parts = line.split()
            if len(parts) < 1:
                continue

            boot_images.append({
                "name": parts[0],
                "default_boot": len(parts) >= 2 and parts[1] == "Yes",
                "running": len(parts) >= 3 and parts[2] == "Yes"
            })

        return boot_images
    except Exception as e:
        print(f"Error parsing boot images: {str(e)}")
        return []

def parse_system_version(text):
    try:
        for line in text.strip().split('\n'):
            if line.startswith('Version:'):
                match = re.search(r'VyOS\s+([^\s]+)', line)
                if match:
                    return match.group(1)
        return ""
    except Exception as e:
        print(f"Error parsing system version: {str(e)}")
        return ""

def parse_commits(text):
    """Parse the commits information."""
    commits = []
    for line in text.strip().split('\n'):
        match = re.match(r'(\d+)\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+by\s+(\w+)\s+via\s+(.+)', line)
        if match:
            commits.append({
                "index": int(match.group(1)),
                "date": match.group(2),
                "user": match.group(3),
                "method": match.group(4)
            })
    return commits

def parse_date(text):
    """ Parse date data """
    return text.split('\n')[0]

def parse_hostname(text):
    """ Parse hostname """
    try:
        return text.split('\n')[0]
    except:
        return ""

def parse_domainname(text):
    """ Parse domain-name """
    try:
        return text.split('\n')[0]
    except:
        return ""

def parse_wireless_country_code(data):
    try:
        return data.get('wireless', {}).get('country-code', "")
    except:
        return ""

def parse_system_info_gql(data):
    try:
        result = data.get('SystemStatus', {}).get('data', {}).get('result', {})
        
        if not result:
            return {}
        
        ram_data = result.get('ram', {})
        ram_free = ram_data.get('free', 0)
        ram_used = ram_data.get('used', 0)
        ram_total = ram_data.get('total', 0)
        
        uptime_data = result.get('uptime', {})
        uptime = uptime_data.get('uptime', '')
        load_average = uptime_data.get('load_average', {})
        
        version_data = result.get('version', {})
        version = version_data.get('version', '')
        hardware_model = str(version_data.get('hardware_model') or '').strip()
        hardware_serial = str(version_data.get('hardware_serial') or '').strip()

        if hardware_serial.casefold() in {'', 'unknown', 'n/a', 'none', 'null'}:
            model_prefix = []

            for character in hardware_model:
                if character not in string.printable or not character.isprintable():
                    break
                model_prefix.append(character)

            hardware_serial = ''.join(model_prefix).rstrip(
                string.punctuation + string.whitespace
            )
        
        host_name = result.get('host_name', '')
        
        parsed_data = {
            'host_name': host_name,
            'hardware_model': hardware_model,
            'hardware_serial': hardware_serial,
            'uptime': {
                'uptime': uptime,
                'load_average': {
                    '1': load_average.get('1', 0.0),
                    '5': load_average.get('5', 0.0),
                    '15': load_average.get('15', 0.0)
                }
            },
            'version': {
                'version': version,
                'built_by': version_data.get('built_by', ''),
                'built_on': version_data.get('built_on', ''),
            }
        }
        
        return parsed_data
        
    except Exception as e:
        print(f"Error parsing system info GraphQL data: {e}")
        return {}


def parse_timedatectl(data):
    try:
        if not data or not isinstance(data, str):
            return {}
        
        lines = data.strip().split('\n')
        parsed_data = {'local_time': '', 'timezone': ''}
        
        for line in lines:
            line = line.strip()
            
            if line.startswith('Local time:'):
                local_time_part = line.split('Local time:', 1)[1].strip()
                parsed_data['local_time'] = local_time_part
                
            elif line.startswith('Time zone:'):
                timezone_part = line.split('Time zone:', 1)[1].strip()
                if '(' in timezone_part:
                    timezone_name = timezone_part.split('(')[0].strip()
                    parsed_data['timezone'] = timezone_name
                else:
                    parsed_data['timezone'] = timezone_part
        
        return parsed_data
        
    except Exception as e:
        print(f"Error parsing timedatectl data: {e}")
        return {}
