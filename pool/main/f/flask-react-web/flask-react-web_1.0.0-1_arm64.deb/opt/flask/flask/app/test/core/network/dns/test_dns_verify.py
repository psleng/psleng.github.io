import pytest
from app.test.conftest import test_service_provider
from copy import deepcopy
from app.test.core.network.dns.test_cases._test_case_verify import test_verify_failed, test_verify_success
from app.test.core.base import TestVerify

class TestDNSVerification(TestVerify):
    __test__ = False # Skip verify test cases
    
    @pytest.fixture(scope='session')
    def service(self):
        return 'dns'

    @pytest.fixture(scope='session')
    def test_get_current_config(self, test_service_provider, service):
        config = test_service_provider.verify_service.call_get_config(service=service) 
        assert isinstance(config, dict) == True
        return config
    
    def test_verify_current_config(self, success_verification, test_service_provider, test_get_current_config, service):
        verification = test_service_provider.verify_service.call_verify(service=service, config=test_get_current_config)
        assert verification in success_verification
    
    @pytest.mark.parametrize("test_data", test_verify_failed)
    def test_verify_failed(self, success_verification, test_service_provider, service, test_data):
        super().test_verify_failed(
            test_service_provider=test_service_provider,
            success_verification=success_verification, 
            service=service,
            test_data=test_data
        )
    
    @pytest.mark.parametrize("test_data", test_verify_success)
    def test_verify_success(self, success_verification, test_service_provider, service, test_data):
        super().test_verify_success(
            test_service_provider=test_service_provider,
            success_verification=success_verification, 
            service=service,
            test_data=test_data
        )