from typing import List, Optional

from pydantic import BaseModel
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text, text
from sqlalchemy.orm import relationship

from app.db.database import db


class InterfaceHealthTestDTO(BaseModel):
    testNumber: str
    respTime: Optional[str] = ""
    target: Optional[str] = ""
    ttlLimit: Optional[str] = ""
    type: Optional[str] = ""
    testScript: Optional[str] = ""


class InterfaceHealthDTO(BaseModel):
    interfaceName: str
    nexthop: str
    failureCount: Optional[str] = ""
    successCount: Optional[str] = ""
    tests: List[InterfaceHealthTestDTO] = []


class RuleInterfaceDTO(BaseModel):
    interfaceName: str
    weight: Optional[str] = ""


class RuleEndpointDTO(BaseModel):
    address: Optional[str] = ""
    port: Optional[str] = ""


class WanRuleDTO(BaseModel):
    ruleNumber: str
    description: Optional[str] = ""
    inboundInterface: Optional[str] = ""
    interfaces: List[RuleInterfaceDTO] = []
    exclude: bool = False
    failover: bool = False
    perPacketBalancing: bool = False
    protocol: Optional[str] = ""
    source: RuleEndpointDTO = RuleEndpointDTO()
    destination: RuleEndpointDTO = RuleEndpointDTO()


class WanGlobalOptionsDTO(BaseModel):
    disableSourceNat: bool = False
    enableLocalTraffic: bool = False
    flushConnections: bool = False
    stickyConnectionsInbound: bool = False


class UpdateWanLoadBalancingDTO(BaseModel):
    interfaceHealth: List[InterfaceHealthDTO] = []
    rules: List[WanRuleDTO] = []
    globalOptions: WanGlobalOptionsDTO = WanGlobalOptionsDTO()


class VerifyWanLoadBalancingDTO(UpdateWanLoadBalancingDTO):
    verify_type: Optional[str] = "all"


class WanLoadBalancingConfig(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing"

    id = Column(Integer, primary_key=True)

    global_options = relationship(
        "WanLoadBalancingGlobalOptions",
        back_populates="config",
        cascade="all, delete-orphan",
        uselist=False,
    )
    interface_health = relationship(
        "WanLoadBalancingInterfaceHealth",
        back_populates="config",
        cascade="all, delete-orphan",
        order_by="WanLoadBalancingInterfaceHealth.interface_name",
    )
    rules = relationship(
        "WanLoadBalancingRule",
        back_populates="config",
        cascade="all, delete-orphan",
        order_by="WanLoadBalancingRule.rule_number",
    )

    def serialize(self):
        return {
            "id": self.id,
            "interface_health": [item.serialize() for item in self.interface_health],
            "rules": [rule.serialize() for rule in self.rules],
            "global_options": self.global_options.serialize() if self.global_options else _empty_global_options(),
        }

    @classmethod
    def truncate(cls):
        tables_to_clear = [
            "vyos_config_wan_load_balancing_rule_interface",
            "vyos_config_wan_load_balancing_rule",
            "vyos_config_wan_load_balancing_interface_health_test",
            "vyos_config_wan_load_balancing_interface_health",
            "vyos_config_wan_load_balancing_global_options",
            "vyos_config_wan_load_balancing",
        ]
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()

    @classmethod
    def refresh(cls, data):
        cls.truncate()
        config = cls()
        config.global_options = WanLoadBalancingGlobalOptions(**_global_options_from_vyos(data))

        for item in _interface_health_from_vyos(data.get("interface-health") or {}):
            health = WanLoadBalancingInterfaceHealth(
                interface_name=item["interfaceName"],
                nexthop=item.get("nexthop", ""),
                failure_count=item.get("failureCount", ""),
                success_count=item.get("successCount", ""),
            )
            for test in item.get("tests") or []:
                health.tests.append(WanLoadBalancingInterfaceHealthTest(
                    test_number=test.get("testNumber", ""),
                    resp_time=test.get("respTime", ""),
                    target=test.get("target", ""),
                    ttl_limit=test.get("ttlLimit", ""),
                    test_type=test.get("type", ""),
                ))
            config.interface_health.append(health)

        for item in _rules_from_vyos(data.get("rule") or {}):
            rule = WanLoadBalancingRule(
                rule_number=item["ruleNumber"],
                description=item.get("description", ""),
                inbound_interface=item.get("inboundInterface", ""),
                exclude=item.get("exclude", False),
                failover=item.get("failover", False),
                per_packet_balancing=item.get("perPacketBalancing", False),
                protocol=item.get("protocol", ""),
                source_address=(item.get("source") or {}).get("address", ""),
                source_port=(item.get("source") or {}).get("port", ""),
                destination_address=(item.get("destination") or {}).get("address", ""),
                destination_port=(item.get("destination") or {}).get("port", ""),
            )
            for intf in item.get("interfaces") or []:
                rule.interfaces.append(WanLoadBalancingRuleInterface(
                    interface_name=intf.get("interfaceName", ""),
                    weight=intf.get("weight", ""),
                ))
            config.rules.append(rule)

        db.session.add(config)
        db.session.commit()


class WanLoadBalancingGlobalOptions(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing_global_options"

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey("vyos_config_wan_load_balancing.id"), nullable=False)
    disable_source_nat = Column(Boolean, default=False)
    enable_local_traffic = Column(Boolean, default=False)
    flush_connections = Column(Boolean, default=False)
    sticky_connections_inbound = Column(Boolean, default=False)

    config = relationship("WanLoadBalancingConfig", back_populates="global_options")

    def serialize(self):
        return {
            "disableSourceNat": bool(self.disable_source_nat),
            "enableLocalTraffic": bool(self.enable_local_traffic),
            "flushConnections": bool(self.flush_connections),
            "stickyConnectionsInbound": bool(self.sticky_connections_inbound),
        }


class WanLoadBalancingInterfaceHealth(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing_interface_health"

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey("vyos_config_wan_load_balancing.id"), nullable=False)
    interface_name = Column(String, nullable=False)
    nexthop = Column(String, nullable=False, default="")
    failure_count = Column(String, nullable=True)
    success_count = Column(String, nullable=True)

    config = relationship("WanLoadBalancingConfig", back_populates="interface_health")
    tests = relationship(
        "WanLoadBalancingInterfaceHealthTest",
        back_populates="interface_health",
        cascade="all, delete-orphan",
        order_by="WanLoadBalancingInterfaceHealthTest.test_number",
    )

    def serialize(self):
        return {
            "interfaceName": self.interface_name,
            "nexthop": self.nexthop or "",
            "failureCount": self.failure_count or "",
            "successCount": self.success_count or "",
            "tests": [test.serialize() for test in self.tests],
        }


class WanLoadBalancingInterfaceHealthTest(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing_interface_health_test"

    id = Column(Integer, primary_key=True)
    interface_health_id = Column(Integer, ForeignKey("vyos_config_wan_load_balancing_interface_health.id"), nullable=False)
    test_number = Column(String, nullable=False)
    resp_time = Column(String, nullable=True)
    target = Column(String, nullable=True)
    ttl_limit = Column(String, nullable=True)
    test_type = Column(String, nullable=True)

    interface_health = relationship("WanLoadBalancingInterfaceHealth", back_populates="tests")

    def serialize(self):
        return {
            "testNumber": self.test_number,
            "respTime": self.resp_time or "",
            "target": self.target or "",
            "ttlLimit": self.ttl_limit or "",
            "type": self.test_type or "",
        }


class WanLoadBalancingRule(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing_rule"

    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey("vyos_config_wan_load_balancing.id"), nullable=False)
    rule_number = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    inbound_interface = Column(String, nullable=False, default="")
    exclude = Column(Boolean, default=False)
    failover = Column(Boolean, default=False)
    per_packet_balancing = Column(Boolean, default=False)
    protocol = Column(String, nullable=True)
    source_address = Column(String, nullable=True)
    source_port = Column(String, nullable=True)
    destination_address = Column(String, nullable=True)
    destination_port = Column(String, nullable=True)

    config = relationship("WanLoadBalancingConfig", back_populates="rules")
    interfaces = relationship(
        "WanLoadBalancingRuleInterface",
        back_populates="rule",
        cascade="all, delete-orphan",
        order_by="WanLoadBalancingRuleInterface.interface_name",
    )

    def serialize(self):
        return {
            "ruleNumber": self.rule_number,
            "description": self.description or "",
            "inboundInterface": self.inbound_interface or "",
            "interfaces": [intf.serialize() for intf in self.interfaces],
            "exclude": bool(self.exclude),
            "failover": bool(self.failover),
            "perPacketBalancing": bool(self.per_packet_balancing),
            "protocol": self.protocol or "",
            "source": {
                "address": self.source_address or "",
                "port": self.source_port or "",
            },
            "destination": {
                "address": self.destination_address or "",
                "port": self.destination_port or "",
            },
        }


class WanLoadBalancingRuleInterface(db.Model):
    __tablename__ = "vyos_config_wan_load_balancing_rule_interface"

    id = Column(Integer, primary_key=True)
    rule_id = Column(Integer, ForeignKey("vyos_config_wan_load_balancing_rule.id"), nullable=False)
    interface_name = Column(String, nullable=False)
    weight = Column(String, nullable=True)

    rule = relationship("WanLoadBalancingRule", back_populates="interfaces")

    def serialize(self):
        return {
            "interfaceName": self.interface_name,
            "weight": self.weight or "",
        }


def _to_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return list(value.keys())
    return [value]


def _text_value(value):
    if value in [None, {}]:
        return ""
    if isinstance(value, dict):
        parts = []

        def collect(item):
            if isinstance(item, dict):
                for key, child in item.items():
                    parts.append(str(key).strip("'\""))
                    collect(child)
            elif item not in [None, ""]:
                parts.append(str(item).strip("'\""))

        collect(value)
        return " ".join(parts)
    return str(value)


def _interface_health_from_vyos(data):
    rows = []
    for name, cfg in data.items():
        tests = []
        for test_number, test_cfg in (cfg.get("test") or {}).items():
            tests.append({
                "testNumber": str(test_number),
                "respTime": str(test_cfg.get("resp-time", "")),
                "target": test_cfg.get("target", ""),
                "ttlLimit": str(test_cfg.get("ttl-limit", "")),
                "type": test_cfg.get("type", ""),
            })

        rows.append({
            "interfaceName": name,
            "nexthop": cfg.get("nexthop", ""),
            "failureCount": str(cfg.get("failure-count", "")),
            "successCount": str(cfg.get("success-count", "")),
            "tests": tests,
        })
    return rows


def _rules_from_vyos(data):
    rows = []
    for rule_number, cfg in data.items():
        interfaces = []
        for name, intf_cfg in (cfg.get("interface") or {}).items():
            interfaces.append({
                "interfaceName": name,
                "weight": str(intf_cfg.get("weight", "")),
            })

        rows.append({
            "ruleNumber": str(rule_number),
            "description": _text_value(cfg.get("description", "")),
            "inboundInterface": _text_value(cfg.get("inbound-interface", "")),
            "interfaces": interfaces,
            "exclude": "exclude" in cfg,
            "failover": "failover" in cfg,
            "perPacketBalancing": "per-packet-balancing" in cfg,
            "protocol": _text_value(cfg.get("protocol", "")),
            "source": cfg.get("source", {}),
            "destination": cfg.get("destination", {}),
        })
    return rows


def _global_options_from_vyos(data):
    return {
        "disable_source_nat": "disable-source-nat" in data,
        "enable_local_traffic": "enable-local-traffic" in data,
        "flush_connections": "flush-connections" in data,
        "sticky_connections_inbound": (data.get("sticky-connections") or {}).get("inbound") == {},
    }


def _empty_global_options():
    return {
        "disableSourceNat": False,
        "enableLocalTraffic": False,
        "flushConnections": False,
        "stickyConnectionsInbound": False,
    }


WanLoadBalancing = WanLoadBalancingConfig
