from app.core.operation.validate import validate_ipv4, validate_ipv6
from typing import Dict, List, Optional, Any

def parse_dns_config(data):
    if not data:
        return {}
    return {
        "forwarding": parse_dns_forward(data),
        "dynamic": parse_dns_dynamic(data)
    }

def parse_dns_servers(d):
    """Parse DNS servers from VyOS response"""
    if d is None:
        return []
    data = d

    try:
        servers = []
        values = [data] if isinstance(data, str) else data

        for value in values:
            if validate_ipv4(value):
                value_type = "ipv4"
            elif validate_ipv6(value):
                value_type = "ipv6"
            else:
                value_type = "interface"

            servers.append({
                "ip_address": value,
                "ip_address_type": value_type
            })
        
        return servers
    except Exception as e:
        print("Error parsing DNS server data:", e)
        return []

def parse_dns_forward(data):
    try:
        if not data or 'forwarding' not in data:
            return {}

        forwarding = data['forwarding']
        result = {
            'allow_from': [],
            # 'cache_size': 10000,
            'dhcp_interfaces': [],
            'domains': [],
            'ignore_hosts_file': False,
            'listen_addresses': [],
            'name_servers': [],
            # 'negative_ttl': 3600
        }

        # Parse allow-from
        if 'allow-from' in forwarding:
            if isinstance(forwarding['allow-from'], list):
                result['allow_from'] = forwarding['allow-from']
            else:
                result['allow_from'] = [forwarding['allow-from']]

        # Parse cache-size
        if 'cache-size' in forwarding:
            result['cache_size'] = int(forwarding['cache-size'])

        # Parse DHCP interfaces
        if 'dhcp' in forwarding:
            if isinstance(forwarding['dhcp'], list):
                result['dhcp_interfaces'] = forwarding['dhcp']
            else:
                result['dhcp_interfaces'] = [forwarding['dhcp']]

        # Parse domains
        if 'domain' in forwarding:
            for domain_name, domain_data in forwarding['domain'].items():
                domain = {
                    'name': domain_name,
                    'name_servers': []
                }
                if 'name-server' in domain_data:
                    for ns in domain_data['name-server'].keys():
                        domain['name_servers'].append(ns)
                result['domains'].append(domain)

        # Parse ignore-hosts-file
        if 'ignore-hosts-file' in forwarding:
            result['ignore_hosts_file'] = True

        # Parse listen-address
        if 'listen-address' in forwarding:
            if isinstance(forwarding['listen-address'], list):
                result['listen_addresses'] = forwarding['listen-address']
            else:
                result['listen_addresses'] = [forwarding['listen-address']]

        # Parse name-servers
        if 'name-server' in forwarding:
            for ns, ns_data in forwarding['name-server'].items():
                server = {'address': ns}
                if ns_data and 'port' in ns_data:
                    server['port'] = int(ns_data['port'])
                result['name_servers'].append(server)

        # Parse negative-ttl
        if 'negative-ttl' in forwarding:
            result['negative_ttl'] = int(forwarding['negative-ttl'])

        return result

    except Exception as e:
        print(f"Error parsing DNS forwarding configuration: {e}")
        return {}

def parse_dns_dynamic(data):
    try:
        if not data or not isinstance(data, dict) or 'dynamic' not in data:
            return {}

        return data['dynamic']

    except Exception as e:
        print(f"Error parsing DNS dynamic configuration: {e}")
        return {}


def parse_to_dns_dynamic_config(data):
    try:
        if not data or not isinstance(data, list):
            return {}

        result = {"name": {}}
        
        for interface in data:
            if not interface.get("name"):
                continue
                
            name = interface["name"]
            config = {
                "address": {},
                "host-name": interface.get("hostname"),
                "password": interface.get("password"),
                "protocol": interface.get("protocol"),
                "server": interface.get("server"),
                "username": interface.get("login"),
                "zone": interface.get("zone"),
                'ip-version': 'ipv4'
            }
            
            # Add address interface if present
            if interface.get("address", {}).get("interface"):
                config["address"]["interface"] = interface["address"]["interface"]
            
            # Add web config if present
            web_config = interface.get("address", {}).get("web", {})
            if web_config.get("skip") or web_config.get("url"):
                config["address"]["web"] = {
                    "skip": web_config.get("skip"),
                    "url": web_config.get("url")
                }
            
            # Remove None values
            config = {k: v for k, v in config.items() if v is not None}
            if not config["address"]:
                del config["address"]
                
            result["name"][name] = config
            
        return result

    except Exception as e:
        print(f"Error parsing DNS dynamic configuration: {e}")
        return {}

if __name__ == "__main__":
    test_data = {'name-server': ['8.8.8.8', '2001:db8:3333:4444:CCCC:DDDD:EEEE:FFFF']}
    print(parse_dns_servers(test_data))

    # Test DNS forwarding parser
    test_forward_data = {
        'forwarding': {
            'allow-from': '255.255.0.0/16',
            'cache-size': '12000',
            'dhcp': ['eth1', 'eth0', 'eth2', 'dum1'],
            'domain': {
                'google.com': {
                    'name-server': {
                        '8.8.8.8': {}
                    }
                }
            },
            'ignore-hosts-file': {},
            'listen-address': ['127.0.0.2', '1.1.1.2', '3.3.3.3'],
            'name-server': {
                '1.1.1.1': {
                    'port': '53'
                }
            },
            'negative-ttl': '3200'
        }
    }
    print("\nTesting DNS forwarding parser:")
    print(parse_dns_forward(test_forward_data))


    # Modify the parse_dns_dynamic function to return the expected result
    test_dynamic_data = {'name': {'ddns1': {'address': {'web': {'skip': '100', 'url': 'http://example.com'}}, 'host-name': 'example.com', 'password': 'pass', 'protocol': 'duckdns', 'server': '8.8.5.5', 'username': 'user'}, 'ddns2': {'address': {'interface': 'eth2'}, 'host-name': 'example.com', 'password': 'pass', 'protocol': 'cloudflare', 'server': '8.8.2.2', 'username': 'user', 'zone': 'zone2'}}}
    print("\nTesting DNS dynamic parser:")
