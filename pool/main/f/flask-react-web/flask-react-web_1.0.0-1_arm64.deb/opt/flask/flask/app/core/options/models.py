import json

from sqlalchemy import Column, Integer, String, Text, UniqueConstraint

from app.db.database import db


class OptionDefinition(db.Model):
    __tablename__ = "vyos_option_definition"

    id = Column(Integer, primary_key=True)
    namespace = Column(String(64), nullable=False)
    name = Column(String(128), nullable=False)
    value_type = Column(String(32))
    help_text = Column(Text)
    is_multi = Column(db.Boolean, nullable=False, default=False)
    values_json = Column(Text, nullable=False, default="[]")

    __table_args__ = (
        UniqueConstraint("namespace", "name", name="uq_vyos_option_namespace_name"),
    )

    @property
    def values(self):
        try:
            values = json.loads(self.values_json or "[]")
            return values if isinstance(values, list) else []
        except (TypeError, json.JSONDecodeError):
            return []

    @values.setter
    def values(self, values):
        self.values_json = json.dumps(list(values or []))

    def serialize(self):
        return {
            "name": self.name,
            "type": self.value_type,
            "help": self.help_text,
            "multi": self.is_multi,
            "values": self.values,
        }
