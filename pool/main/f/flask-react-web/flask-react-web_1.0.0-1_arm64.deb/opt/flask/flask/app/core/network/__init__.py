from flask import Blueprint

vyos_network_bp = Blueprint('network', __name__)

from . import routes
from .nat66 import routes as nat66_routes
