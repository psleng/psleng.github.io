import pprint
from flask import session
from uuid import uuid4

from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_ARP_CONFIG
from app.core.network.arp.command_arp import ARPCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.socket.socket_manager import socket_manager
from app.core.network.arp.models import ARPEntry


SHOW_ARP_NEIGHBORS_RAW_QUERY = 'ShowArpNeighborsRawPerleArpQuery'
RESET_IPV6_NEIGHBORS_ADDRESS_MUTATION = 'ResetIpvsixNeighborsAddressPerleArpMutation'
RESET_IPV6_NEIGHBORS_INTERFACE_MUTATION = 'ResetIpvsixNeighborsInterfacePerleArpMutation'


def _extract_arp_neighbors(response):
    payload = response.json()
    query_data = payload.get('data', {}).get(SHOW_ARP_NEIGHBORS_RAW_QUERY, {})

    if not query_data.get('success', False):
        errors = query_data.get('errors') or payload.get('errors') or 'Failed to load ARP neighbors'
        raise Exception(errors)

    result = query_data.get('data', {}).get('result', [])
    return result if isinstance(result, list) else []


def _extract_neighbor_reset(response, mutation_name):
    payload = response.json()
    mutation_data = payload.get('data', {}).get(mutation_name, {})

    if not mutation_data.get('success', False):
        errors = mutation_data.get('errors') or payload.get('errors') or 'Failed to reset IPv6 neighbors'
        if isinstance(errors, list):
            errors = '; '.join(str(error) for error in errors)
        raise Exception(errors)

    result = mutation_data.get('data', {}).get('result')
    return result if result is not None else {}


def fetch_arp_config(provider, params=None):
    arp_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ARP_CONFIG, verify=False)
    data = arp_response.json().get('data')
    parsed = data or {}
    return parsed


def fetch_arp_monitor_ipv4(provider, params=None):
    response = provider.graphql_service.send_request(
        function_name=SHOW_ARP_NEIGHBORS_RAW_QUERY,
        data={'ipv4': 'true'},
        verify=False
    )
    return _extract_arp_neighbors(response)


def fetch_arp_monitor_ipv6(provider, params=None):
    response = provider.graphql_service.send_request(
        function_name=SHOW_ARP_NEIGHBORS_RAW_QUERY,
        data={'ipv6': 'true'},
        verify=False
    )
    return _extract_arp_neighbors(response)


def _reset_arp(provider, mutation_name, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name=mutation_name,
        data=data or {},
        verify=False
    )
    payload = response.json()
    response_data = payload.get('data') or {}
    mutation = response_data.get(mutation_name) or {}

    if not mutation.get('success', False):
        errors = mutation.get('errors') or payload.get('errors') or f'{mutation_name} failed'
        raise Exception(errors)

    mutation_data = mutation.get('data') or {}
    return {'result': mutation_data.get('result')}


def reset_arp_table(provider, data=None):
    return _reset_arp(provider, 'ResetIpArpTablePerleArpMutation')


def reset_arp_address(provider, data=None):
    address = (data or {}).get('address')
    if not address:
        raise ValueError('Address is required')
    return _reset_arp(
        provider,
        'ResetIpArpAddressPerleArpMutation',
        {'address': address}
    )


def reset_arp_interface(provider, data=None):
    interface = (data or {}).get('interface')
    if not interface:
        raise ValueError('Interface is required')
    return _reset_arp(
        provider,
        'ResetIpArpInterfacePerleArpMutation',
        {'interface': interface}
    )
def reset_ipv6_neighbor_address(provider, data):
    address = str((data or {}).get('address') or '').strip()
    if not address:
        raise ValueError('IPv6 address is required.')

    response = provider.graphql_service.send_simple_mutation_request(
        function_name=RESET_IPV6_NEIGHBORS_ADDRESS_MUTATION,
        data={'address': address},
        verify=False,
    )
    return _extract_neighbor_reset(response, RESET_IPV6_NEIGHBORS_ADDRESS_MUTATION)


def reset_ipv6_neighbors_interface(provider, data):
    interface = str((data or {}).get('interface') or '').strip()
    if not interface:
        raise ValueError('Interface name is required.')

    response = provider.graphql_service.send_simple_mutation_request(
        function_name=RESET_IPV6_NEIGHBORS_INTERFACE_MUTATION,
        data={'interface': interface},
        verify=False,
    )
    return _extract_neighbor_reset(response, RESET_IPV6_NEIGHBORS_INTERFACE_MUTATION)


def update_arp(provider, data):
    username = session.get('username')
    diff = data.get('diff')
    current_arp = data.get('current')
    new_arp = data.get('new')

    print('ARP Diff data:')
    print(pprint.pformat(diff, indent=2, width=80))

    r = []

    arp_set_cmd = ARPCommand(operator='set', resource='protocols')
    set_cmds = arp_set_cmd.generate_commands((diff or {}).get('created') or {}, current_arp, new_arp)
    sc = arp_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    arp_del_cmd = ARPCommand(operator='delete', resource='protocols')
    delete_cmds = arp_del_cmd.generate_commands((diff or {}).get('deleted') or {}, current_arp, new_arp)
    dc = arp_del_cmd.get_commands()
    new_del_configs = process_commands(dc)

    service = 'arp'
    curr_config = {}
    try:
        curr_config = provider.verify_service.call_get_config(service)
    except Exception as e:
        print('Error getting current arp config:')
        print(str(e))
        curr_config = {}

    current_raw_config = curr_config if curr_config else {}

    merged_del_config = merge_dicts_delete(
        current_raw_config,
        new_del_configs.get('protocols', {}).get('static', {}).get('arp', {})
    )
    merged_config = merge_dicts_set(
        merged_del_config,
        new_set_configs.get('protocols', {}).get('static', {}).get('arp', {})
    )

    verify = None

    if merged_config and merged_config.get('protocols', {}).get('static', {}).get('arp', None):
        verify = provider.verify_service.call_verify(service, merged_config['protocols']['static']['arp'])

    if str(verify) not in ('None', '', 'null') and verify is not None and verify != {}:
        return Exception(verify)

    # Refresh db:
    ARPEntry.refresh(new_arp)

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update ARP',
            'content': 'ARP is successfully updated'
        }
    )

    executed_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    if len(executed_cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=executed_cmds, verify=False).json()
        r.append({'cmd': executed_cmds, 'success': res.get('success'), 'error': res.get('error')})

    return r


def verify_arp(provider, data):
    service = 'arp'
    verify = provider.verify_service.call_verify(service, data)
    return verify
