from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None', 'null'] and value is not None

def format_description(description: str) -> str:
    # Return description as-is - JSON format handles quoting properly
    return description

class IPTunnelCommand(IfaceCommand):
    """
    Command class for IP Tunnel Interface:
    
    - set/delete interfaces tunnel tun0 description <text>
    - set/delete interfaces tunnel tun0 disable
    - set/delete interfaces tunnel tun0 source-address <IPv4|IPv6>
    - set/delete interfaces tunnel tun0 remote <IPv4|IPv6>
    - set/delete interfaces tunnel tun0 encapsulation {gre|ipip|sit|gre-bridge}
    - set/delete interfaces tunnel tun0 ttl <0-255>
    - set/delete interfaces tunnel tun0 tos <0-99>
    - set/delete interfaces tunnel tun0 mtu <68-16000>
    - set/delete interfaces tunnel tun0 multicast
    - set/delete interfaces tunnel tun0 address <IPv4|IPv6>
    
    # GRE specific
    - set/delete interfaces tunnel tun0 parameters ip key <key>
    - set/delete interfaces tunnel tun0 parameters ip checksum
    
    # SIT specific
    - set/delete interfaces tunnel tun0 6rd-prefix <IPv6-prefix>
    - set/delete interfaces tunnel tun0 6rd-relay-prefix <IPv4-prefix>
    """
    
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            self._mode = kwargs.get('mode', 'UPDATE')  # _mode: CREATE or UPDATE

            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'tunnel'),
                name=self.name
            )
            self.attributes = {
                'interfaces': {
                    'tunnel': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing IP tunnel command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        # In create mode (modal), DO NOT generate delete commands unless necessary
        if self._mode == 'CREATE' and self.operator == 'delete':
            return
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []
        
        curr_config = deepcopy(current_config) if current_config else deepcopy(data)
        
        # Process different tunnel types
        tunnel_types = ['gre', 'ipip', 'sit', 'vti']
        
        for tunnel_type in tunnel_types:
            if tunnel_type in data:
                self._process_tunnel_type_config(tunnel_type, data[tunnel_type])
        
        print(f"Generated IP Tunnel commands: {self.cmds}")
        return self.cmds

    def _process_tunnel_type_config(self, tunnel_type, tunnels_config):
        """Process tunnels of a specific type"""
        # Safety check: if tunnels_config is not a dict, it might be malformed
        # This can happen when process_commands() returns a string for flag-type deletes
        if not isinstance(tunnels_config, dict):
            print(f"Warning: tunnels_config is not a dict, got {type(tunnels_config)}: {tunnels_config}")
            return
            
        for tunnel_name, tunnel_config in tunnels_config.items():
            base_path = ['interfaces', 'tunnel', tunnel_name]
            
            # Set encapsulation type
            if tunnel_type == 'gre':
                self.generate(*base_path, 'encapsulation', 'gre')
            elif tunnel_type == 'ipip':
                self.generate(*base_path, 'encapsulation', 'ipip')
            elif tunnel_type == 'sit':
                self.generate(*base_path, 'encapsulation', 'sit')
            elif tunnel_type == 'vti':
                # VTI tunnels are handled separately in IPsec
                continue
            
            # Common tunnel parameters
            if 'description' in tunnel_config and is_str_not_empty(tunnel_config['description']):
                self.generate(*base_path, 'description', format_description(tunnel_config['description']))
            
            # Only add disable flag if it's explicitly True
            if tunnel_config.get('disable') is True or tunnel_config.get('disable') == {}:
                self.generate(*base_path, 'disable')
            
            if 'source-address' in tunnel_config and is_str_not_empty(tunnel_config['source-address']):
                self.generate(*base_path, 'source-address', tunnel_config['source-address'])
            
            if 'remote' in tunnel_config and is_str_not_empty(tunnel_config['remote']):
                self.generate(*base_path, 'remote', tunnel_config['remote'])
            
            if 'ttl' in tunnel_config and is_str_not_empty(tunnel_config['ttl']):
                self.generate(*base_path, 'ttl', str(tunnel_config['ttl']))
            
            if 'tos' in tunnel_config and is_str_not_empty(tunnel_config['tos']):
                self.generate(*base_path, 'tos', str(tunnel_config['tos']))
            
            if 'mtu' in tunnel_config and is_str_not_empty(tunnel_config['mtu']):
                self.generate(*base_path, 'mtu', str(tunnel_config['mtu']))
            
            if 'enable-multicast' in tunnel_config:
                self.generate(*base_path, 'enable-multicast')
            
            if 'disable-link-detect' in tunnel_config:
                self.generate(*base_path, 'disable-link-detect')
            
            # IP General Options
            if 'ip' in tunnel_config:
                ip_config = tunnel_config['ip']
                
                # Numeric option
                if 'arp-cache-timeout' in ip_config and is_str_not_empty(ip_config['arp-cache-timeout']):
                    self.generate(*base_path, 'ip', 'arp-cache-timeout', str(ip_config['arp-cache-timeout']))
                
                # String option
                if 'adjust-mss' in ip_config and is_str_not_empty(ip_config['adjust-mss']):
                    self.generate(*base_path, 'ip', 'adjust-mss', str(ip_config['adjust-mss']))
                
                # Flag options
                if 'enable-arp-accept' in ip_config:
                    self.generate(*base_path, 'ip', 'enable-arp-accept')
                
                if 'enable-arp-announce' in ip_config:
                    self.generate(*base_path, 'ip', 'enable-arp-announce')
                
                if 'disable-arp-filter' in ip_config:
                    self.generate(*base_path, 'ip', 'disable-arp-filter')
                
                if 'enable-arp-ignore' in ip_config:
                    self.generate(*base_path, 'ip', 'enable-arp-ignore')
                
                if 'enable-directed-broadcast' in ip_config:
                    self.generate(*base_path, 'ip', 'enable-directed-broadcast')
                
                if 'disable-forwarding' in ip_config:
                    self.generate(*base_path, 'ip', 'disable-forwarding')
                
                if 'enable-proxy-arp' in ip_config:
                    self.generate(*base_path, 'ip', 'enable-proxy-arp')
                
                if 'proxy-arp-pvlan' in ip_config:
                    self.generate(*base_path, 'ip', 'proxy-arp-pvlan')
                
                # Source validation (value-based)
                if 'source-validation' in ip_config and is_str_not_empty(ip_config['source-validation']):
                    self.generate(*base_path, 'ip', 'source-validation', ip_config['source-validation'])
            
            # IP addresses
            if 'address' in tunnel_config:
                addresses = tunnel_config['address']
                if isinstance(addresses, list):
                    for address in addresses:
                        if is_str_not_empty(address):
                            self.generate(*base_path, 'address', address)
                elif is_str_not_empty(addresses):
                    self.generate(*base_path, 'address', addresses)
            
            # IPv6 options
            if 'ipv6' in tunnel_config:
                ipv6_config = tunnel_config['ipv6']
                
                # IPv6 address options (under ipv6 > address)
                if 'address' in ipv6_config and isinstance(ipv6_config['address'], dict):
                    address_config = ipv6_config['address']
                    
                    # EUI-64 address
                    if 'eui64' in address_config and is_str_not_empty(address_config['eui64']):
                        self.generate(*base_path, 'ipv6', 'address', 'eui64', address_config['eui64'])
                    
                    # Autoconf (flag)
                    if 'autoconf' in address_config:
                        self.generate(*base_path, 'ipv6', 'address', 'autoconf')
                    
                    # No default link-local (flag)
                    if 'no-default-link-local' in address_config:
                        self.generate(*base_path, 'ipv6', 'address', 'no-default-link-local')
                
                # Accept DAD (directly under ipv6)
                if 'accept-dad' in ipv6_config and is_str_not_empty(ipv6_config['accept-dad']):
                    self.generate(*base_path, 'ipv6', 'accept-dad', ipv6_config['accept-dad'])
                
                # DAD transmits (directly under ipv6)
                if 'dup-addr-detect-transmits' in ipv6_config and is_str_not_empty(ipv6_config['dup-addr-detect-transmits']):
                    self.generate(*base_path, 'ipv6', 'dup-addr-detect-transmits', ipv6_config['dup-addr-detect-transmits'])
                
                # Base reachable time (directly under ipv6)
                if 'base-reachable-time' in ipv6_config and is_str_not_empty(ipv6_config['base-reachable-time']):
                    self.generate(*base_path, 'ipv6', 'base-reachable-time', ipv6_config['base-reachable-time'])
                
                # Adjust MSS (directly under ipv6)
                if 'adjust-mss' in ipv6_config and is_str_not_empty(ipv6_config['adjust-mss']):
                    self.generate(*base_path, 'ipv6', 'adjust-mss', ipv6_config['adjust-mss'])
                
                # Disable forwarding (flag - directly under ipv6)
                if 'disable-forwarding' in ipv6_config:
                    self.generate(*base_path, 'ipv6', 'disable-forwarding')
                
                # Source validation (directly under ipv6)
                if 'source-validation' in ipv6_config and is_str_not_empty(ipv6_config['source-validation']):
                    self.generate(*base_path, 'ipv6', 'source-validation', ipv6_config['source-validation'])
            
            # Type specific parameters
            if tunnel_type == 'gre':
                self._process_gre_specific(base_path, tunnel_config)
            elif tunnel_type == 'sit':
                self._process_sit_specific(base_path, tunnel_config)
            elif tunnel_type == 'erspan':
                self._process_erspan_specific(base_path, tunnel_config)

    def _process_gre_specific(self, base_path, tunnel_config):
        """Process GRE specific parameters"""
        if 'key' in tunnel_config and is_str_not_empty(tunnel_config['key']):
            self.generate(*base_path, 'parameters', 'ip', 'key', tunnel_config['key'])
        
        if 'checksum' in tunnel_config:
            self.generate(*base_path, 'parameters', 'ip', 'checksum')

    def _process_sit_specific(self, base_path, tunnel_config):
        """Process SIT specific parameters"""
        if '6rd-prefix' in tunnel_config and is_str_not_empty(tunnel_config['6rd-prefix']):
            self.generate(*base_path, '6rd-prefix', tunnel_config['6rd-prefix'])
        
        if '6rd-relay-prefix' in tunnel_config and is_str_not_empty(tunnel_config['6rd-relay-prefix']):
            self.generate(*base_path, '6rd-relay-prefix', tunnel_config['6rd-relay-prefix'])

    def _process_erspan_specific(self, base_path, tunnel_config):
        """Process ERSPAN specific parameters"""
        parameters_config = tunnel_config.get('parameters', {})
        erspan_config = parameters_config.get('erspan', {})
        
        if 'direction' in erspan_config and is_str_not_empty(erspan_config['direction']):
            self.generate(*base_path, 'parameters', 'erspan', 'direction', erspan_config['direction'])


if __name__ == "__main__":
    pass