from ipaddress import ip_address
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator
from sqlalchemy import Boolean, Column, Integer

from app.db.database import db


class AMPServer(BaseModel):
    model_config = ConfigDict(extra='forbid')
    port: StrictInt | None = Field(default=None, ge=1, le=65535)


class AMPConfigDTO(BaseModel):
    model_config = ConfigDict(extra='forbid', populate_by_name=True)
    owamp_server: AMPServer | None = Field(default=None, alias='owamp-server')
    twamp_server: AMPServer | None = Field(default=None, alias='twamp-server')

    def to_config(self):
        return self.model_dump(by_alias=True, exclude_none=True)


class AMPConfig(db.Model):
    __tablename__ = 'vyos_config_amp'

    id = Column(Integer, primary_key=True)
    owamp_server_enabled = Column(Boolean, nullable=False, default=False)
    owamp_server_port = Column(Integer, nullable=True)
    twamp_server_enabled = Column(Boolean, nullable=False, default=False)
    twamp_server_port = Column(Integer, nullable=True)

    def serialize(self):
        config = {}
        for name in ('owamp', 'twamp'):
            if getattr(self, f'{name}_server_enabled'):
                port = getattr(self, f'{name}_server_port')
                config[f'{name}-server'] = {} if port is None else {'port': port}
        return config

    @classmethod
    def get_config(cls):
        config = cls.query.first()
        return config.serialize() if config else {}

    @classmethod
    def truncate(cls):
        try:
            db.session.query(cls).delete()
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

    @classmethod
    def refresh(cls, data):

        values = {}
        for name in ('owamp', 'twamp'):
            key = f'{name}-server'
            enabled = key in (data or {})
            node = (data or {}).get(key) or {}
            port = node.get('port')
            values[f'{name}_server_enabled'] = enabled
            values[f'{name}_server_port'] = int(port) if enabled and port is not None else None

        try:
            db.session.query(cls).delete()
            if values['owamp_server_enabled'] or values['twamp_server_enabled']:
                db.session.add(cls(id=1, **values))
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise


class AMPMonitor(BaseModel):
    model_config = ConfigDict(extra='forbid')
    tool: Literal['owping', 'twping']
    target: str

    @field_validator('target')
    @classmethod
    def validate_target(cls, value):
        host, separator, port = value.strip().rpartition(':')
        if not separator or not port.isascii() or not port.isdecimal() or not 1 <= int(port) <= 65535:
            raise ValueError('Enter an IPv4 or IPv6 address and a port from 1 to 65535.')
        if host.startswith('[') and host.endswith(']'):
            host = host[1:-1]
        if '%' in host:
            raise ValueError('Enter an IPv4 or IPv6 address without a zone identifier.')
        address = ip_address(host)
        host = f'[{address}]' if address.version == 6 else str(address)
        return f'{host}:{int(port)}'
