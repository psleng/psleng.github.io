def parse_to_ip_options_vyos_config(ip_config):
    
    if not ip_config:
        return None, None
    
    # IPv4 section
    ip_section = {}
    
    if ip_config.get('adjustMss'):
        ip_section['adjust-mss'] = ip_config['adjustMss']
    
    if ip_config.get('arpCacheTimeout'):
        ip_section['arp-cache-timeout'] = ip_config['arpCacheTimeout']
    
    if ip_config.get('disableArpFilter') is True:
        ip_section['disable-arp-filter'] = {}
    
    if ip_config.get('disableForwarding') is True:
        ip_section['disable-forwarding'] = {}
    
    if ip_config.get('enableArpAccept') is True:
        ip_section['enable-arp-accept'] = {}
    
    if ip_config.get('enableArpAnnounce') is True:
        ip_section['enable-arp-announce'] = {}
    
    if ip_config.get('enableArpIgnore') is True:
        ip_section['enable-arp-ignore'] = {}
    
    if ip_config.get('enableDirectedBroadcast') is True:
        ip_section['enable-directed-broadcast'] = {}
    
    if ip_config.get('enableProxyArp') is True:
        ip_section['enable-proxy-arp'] = {}
    
    if ip_config.get('proxyArpPvlan') is True:
        ip_section['proxy-arp-pvlan'] = {}
    
    if ip_config.get('sourceValidation'):
        ip_section['source-validation'] = ip_config['sourceValidation']
    
    # IPv6 section
    ipv6_section = {}
    
    if ip_config.get('acceptDad') or ip_config.get('ipv6AcceptDad'):
        ipv6_section['accept-dad'] = ip_config.get('acceptDad') or ip_config.get('ipv6AcceptDad')
    
    if ip_config.get('ipv6AdjustMss'):
        ipv6_section['adjust-mss'] = ip_config['ipv6AdjustMss']
    
    if ip_config.get('baseReachableTime') or ip_config.get('ipv6BaseReachableTime'):
        ipv6_section['base-reachable-time'] = ip_config.get('baseReachableTime') or ip_config.get('ipv6BaseReachableTime')
    
    if ip_config.get('dupAddrDetectTransmits') or ip_config.get('ipv6DupAddrDetectTransmits'):
        ipv6_section['dup-addr-detect-transmits'] = (
            ip_config.get('dupAddrDetectTransmits') or 
            ip_config.get('ipv6DupAddrDetectTransmits')
        )
    
    if ip_config.get('ipv6DisableForwarding') is True:
        ipv6_section['disable-forwarding'] = {}

    if ip_config.get('ipv6SourceValidation'):
        ipv6_section['source-validation'] = ip_config['ipv6SourceValidation']
    
    # Address sub-options
    address_config = {}
    
    if ip_config.get('addressAutoconf') is True or ip_config.get('ipv6AddressAutoconf') is True:
        address_config['autoconf'] = {}
    
    if ip_config.get('addressEui64') or ip_config.get('ipv6AddressEui64'):
        address_config['eui64'] = ip_config.get('addressEui64') or ip_config.get('ipv6AddressEui64')
    
    if ip_config.get('interfaceIdentifier') or ip_config.get('ipv6InterfaceIdentifier'):
        address_config['interface-identifier'] = ip_config.get('interfaceIdentifier') or ip_config.get('ipv6InterfaceIdentifier')
    
    if ip_config.get('addressNoDefaultLinkLocal') is True or ip_config.get('ipv6AddressNoDefaultLinkLocal') is True:
        address_config['no-default-link-local'] = {}
    
    if address_config:
        ipv6_section['address'] = address_config
    
    return (ip_section if ip_section else None, ipv6_section if ipv6_section else None)
