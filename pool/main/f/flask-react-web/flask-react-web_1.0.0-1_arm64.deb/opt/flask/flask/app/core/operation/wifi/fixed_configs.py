fixed_wifi_configs = {
    "fixed_configs": {
        "interfaces": {
            "wireless": {
                "wlan0": {
                    "capabilities": {
                        "ht": {
                            "channel-set-width": [
                                "ht40+",
                                "ht40-",
                                "ht20"
                            ],
                            "ldpc": {}
                        },
                        "vht": {
                            "channel-set-width": "0",
                            "ldpc": {}
                        }
                    },
                    "channel": "0",
                    "max-stations": "16",
                    "mode": "ac",
                    "stationary-ap": {},
                    "isolate-stations": {},
                    "type": "access-point",
                },
                "wlan1": {
                    "capabilities": {
                        "ht": {
                            "channel-set-width": [
                                "ht40+",
                                "ht40-",
                                "ht20"
                            ],
                            "ldpc": {}
                        },
                        "vht": {
                            "channel-set-width": "1",
                            "ldpc": {}
                        }
                    },
                    "channel": "0",
                    "max-stations": "16",
                    "mode": "n",
                    "stationary-ap": {},
                    "isolate-stations": {},
                    "physical-device": "phy1",
                    "type": "access-point",
                },
                "wlan2": {
                    "type": "station",
                    "mode": "ac",
                    "address": "dhcp"
                },
                "wlan3": {
                    "type": "station",
                    "mode": "n",
                    "address": "dhcp",
                    "physical-device": "phy1"
                }
            }
        }
    }
}