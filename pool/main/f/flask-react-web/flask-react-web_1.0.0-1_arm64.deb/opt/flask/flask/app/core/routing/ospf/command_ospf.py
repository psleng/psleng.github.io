import pprint
from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

class OSPFCommand(Command):
    """Command class for OSPF commands
    
    - set/delete protocols ospf area <area-number 0-4294967295> network <x.x.x.x/>
    - set/delete protocols ospf area <area-num> authentication {plaintext-password | md5}
    - set/delete protocols ospf area <area-num> range <x.x.x.x/n>
    - set/delete protocols ospf area <area-num> range <x.x.x.x/n> cost <0-16777215>
    - set/delete protocols ospf area <area-num> range <x.x.x.x/n> not-advertise
    - set/delete protocols ospf area <area-num> range <x.x.x.x/n> substitute <x.x.x.x/n>
    - set/delete protocols ospf area <area-num> area-type normal
    - set/delete protocols ospf area <area-num> area-type nssa default-cost <0-16777215>
    - set/delete protocols ospf area <area-num> area-type nssa no-summary 
    - set/delete protocols ospf area <area-num> area-type nssa translate {always | candidate | never}
    - set/delete protocols ospf area <area-num> area-type stub default-cost <0-16777215>
    - set/delete protocols ospf area <area-num> area-type stub no-summary
    - set/delete protocols ospf interface <intf-name>
    - set/delete protocols ospf interface <intf-name> area <0-4294967295>
    - set/delete protocols ospf interface <intf-name> bandwidth <1-100000>
    - set/delete protocols ospf interface <intf-name> cost <1-65535>
    - set/delete protocols ospf interface <intf-name> dead-interval <1-65535>
    - set/delete protocols ospf interface <intf-name> hello-interval <1-65535>
    - set/delete protocols ospf interface <intf-name> hello-multiplier <1-10>
    - set/delete protocols ospf interface <intf-name> mtu-ignore
    - set/delete protocols ospf interface <intf-name> network {broadcast | non-broadcast | point-to-multipoint | point-to-point}
    - set/delete protocols ospf interface <intf-name> passive disable
    - set/delete protocols ospf interface <intf-name> priority <0-255>
    - set/delete protocols ospf interface <intf-name> retransmit-interval <1-65535>
    - set/delete protocols ospf interface <intf-name> retransmit-window <20-1000>
    - set/delete protocols ospf interface <intf-name> transmit-delay <1-65535>
    - set/delete protocols ospf interface <intf-name> authentication md5 key-id <id> md5-key <text-max-16-chars>
    - set/delete protocols ospf interface <intf-name> authentication  plaintext-password <password>
    - set/delete protocols ospf redistribute connected
    - set/delete protocols ospf redistribute connected metric <0-16777214>
    - set/delete protocols ospf redistribute connected metric-type {1 | 2}
    - set/delete protocols ospf redistribute kernel
    - set/delete protocols ospf redistribute kernel metric <0-16777214>
    - set/delete protocols ospf redistribute kernel metric-type {1 | 2}
    - set/delete protocols ospf redistribute static
    - set/delete protocols ospf redistribute static metric <0-16777214>
    - set/delete protocols ospf redistribute static metric-type {1 | 2}
    - set/delete protocols ospf neighbor <x.x.x.x>
    - set/delete protocols ospf neighbor <x.x.x.x> poll-interval <1-65535>
    - set/delete protocols ospf neighbor <x.x.x.x> priority <0-255>
    - set/delete protocols ospf summary-address <x.x.x.x/n>
    - set/delete protocols ospf summary-address <x.x.x.x/n> no-advertise
    - set/delete protocols ospf aggregation timer <5-1800>
    - set/delete protocols ospf auto-cost reference-bandwidth <1-4294967>
    - set/delete protocols ospf default-metric <0-16777214>
    - set/delete protocols ospf capability opaque
    - set/delete protocols ospf log-adjacency-changes detail
    - set/delete protocols ospf maximum-paths <1-64>
    - set/delete protocols ospf passive-interface default
    - set/delete protocols ospf refresh timers <10-1800>
    - set/delete protocols ospf max-metric administrative
    - set/delete protocols ospf max-metric on-shutdown <5-100>
    - set/delete protocols ospf max-metric on-startup <5-100>
    - set/delete protocols ospf parameters abr-type {cisco | ibm | shortcut | standard}
    - set/delete protocols ospf parameters opaque-lsa
    - set/delete protocols ospf parameters rfc1583-compatibility
    - set/delete protocols ospf parameters router-id <x.x.x.x>
    - set/delete protocols ospf timers throttle spf  delay <0-600000>
    - set/delete protocols ospf timers throttle spf initial-holdtime <0-600000>
    - set/delete protocols ospf timers throttle spf max-holdtime <0-600000>
    - set/delete protocols ospf default-information originate always
    - set/delete protocols ospf default-information originate metric <0-16777214> 
    - set/delete protocols ospf default-information originate metric-type <1 | 2>
    - set/delete protocols ospf distance global <1-255>
    - set/delete protocols ospf distance ospf external <1-255>
    - set/delete protocols ospf distance ospf inter-area <1-255>
    - set/delete protocols ospf distance ospf intra-area <1-255>
    - set/delete protocols ospf graceful-restart
    - set/delete protocols ospf graceful-restart grace-period <1-1800>
    - set/delete protocols ospf max-metric router-lsa administrative
    - set/delete protocols ospf max-metric router-lsa on-shutdown <5-100>
    - set/delete protocols ospf max-metric router-lsa on-startup <5-100>

    
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'ospf'))
            self.attributes = {
                'protocols': {
                    'ospf': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing OSPF cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.attributes['protocols']['ospf'] = data
            
            if 'area' in data:
                self._process_area_config(data['area'], current_config, new_config)
            
            if 'interface' in data:
                self._process_interface_config(data['interface'], data.get('area', {}), current_config, new_config)
            
            if 'redistribute' in data:
                self._process_redistribute_config(data['redistribute'], current_config, new_config)
            
            if 'neighbor' in data:
                self._process_neighbor_config(data['neighbor'], current_config, new_config)
            
            if 'summary-address' in data:
                self._process_summary_address_config(data['summary-address'])
            
            self._process_global_parameters(data)
            
            if 'parameters' in data:
                self._process_parameters_config(data['parameters'])
            
            if 'timers' in data:
                self._process_timers_config(data['timers'])
            
            if 'default-information' in data:
                self._process_default_information_config(data['default-information'])
            
            if 'distance' in data:
                self._process_distance_config(data['distance'])
            
            if 'graceful-restart' in data:
                self._process_graceful_restart_config(data['graceful-restart'])
            
            if 'max-metric' in data:
                self._process_max_metric_config(data['max-metric'])
            
            print(f"Generated OSPF commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating OSPF commands: {e}")
            return []
    
    def _process_area_config(self, area_config, current_config, new_config):
        for area_num, area_data in area_config.items():
            base_path = ['protocols', 'ospf', 'area', str(area_num)]

            if self.operator == 'delete' and area_num not in new_config.get('area', {}):
                self.generate(*base_path)
                continue

            if not isinstance(area_data, dict):
                self.generate(*base_path)
                continue
            
            if 'network' in area_data:
                if isinstance(area_data['network'], list):
                    for network in area_data['network']:
                        if is_str_not_empty(network):
                            self.generate(*base_path, 'network', network)
                elif is_str_not_empty(area_data['network']):
                    self.generate(*base_path, 'network', area_data['network'])
            
            if 'authentication' in area_data and is_str_not_empty(area_data['authentication']):
                self.generate(*base_path, 'authentication', area_data['authentication'])
            
            if 'range' in area_data:
                self._process_area_range_config(base_path, area_data['range'], current_config, new_config)
            
            if 'area-type' in area_data:
                self._process_area_type_config(base_path, area_data['area-type'])
    
    def _process_area_range_config(self, base_path, range_config, current_config, new_config):
        for range_prefix, range_data in range_config.items():
            range_path = base_path + ['range', range_prefix]

            if self.operator == 'delete' and \
                range_prefix not in new_config.get('area', {}).get(base_path[-1], {}).get('range', {}):
                self.generate(*range_path)
                continue

            if not isinstance(range_data, dict):
                range_data = {}

            self.generate(*range_path)
            
            if 'cost' in range_data and is_str_not_empty(range_data['cost']):
                self.generate(*range_path, 'cost', str(range_data['cost']))
            
            if 'not-advertise' in range_data:
                self.generate(*range_path, 'not-advertise')
            
            if 'substitute' in range_data and is_str_not_empty(range_data['substitute']):
                self.generate(*range_path, 'substitute', range_data['substitute'])
    
    def _process_area_type_config(self, base_path, area_type_config):
        area_type_path = base_path + ['area-type']
        
        if not isinstance(area_type_config, dict):
            if isinstance(area_type_config, str) and is_str_not_empty(area_type_config):
                self.generate(*area_type_path, area_type_config)
            return
        
        if 'normal' in area_type_config:
            self.generate(*area_type_path, 'normal')
        
        if 'nssa' in area_type_config:
            nssa_path = area_type_path + ['nssa']
            nssa_data = area_type_config['nssa']
            
            if 'default-cost' in nssa_data and is_str_not_empty(nssa_data['default-cost']):
                self.generate(*nssa_path, 'default-cost', str(nssa_data['default-cost']))
            
            if 'no-summary' in nssa_data:
                self.generate(*nssa_path, 'no-summary')
            
            if 'translate' in nssa_data and is_str_not_empty(nssa_data['translate']):
                self.generate(*nssa_path, 'translate', nssa_data['translate'])
        
        if 'stub' in area_type_config:
            stub_path = area_type_path + ['stub']
            stub_data = area_type_config['stub']
            
            if 'default-cost' in stub_data and is_str_not_empty(stub_data['default-cost']):
                self.generate(*stub_path, 'default-cost', str(stub_data['default-cost']))
            
            if 'no-summary' in stub_data:
                self.generate(*stub_path, 'no-summary')
    
    def _process_interface_config(self, interface_config, area_config, current_config, new_config):
        for intf_name, intf_data in interface_config.items():
            base_path = ['protocols', 'ospf', 'interface', intf_name]

            if self.operator == 'delete' and intf_name not in new_config.get('interface', {}):
                self.generate(*base_path)
                continue
            if self.operator == 'set':
                self.generate(*base_path)

            if not isinstance(intf_data, dict):
                continue
            
            if 'area' in intf_data and is_str_not_empty(intf_data['area']) and isinstance(area_config, dict) and len(area_config.keys()) == 0:
                self.generate(*base_path, 'area', str(intf_data['area']))
            
            if 'bandwidth' in intf_data and is_str_not_empty(intf_data['bandwidth']):
                self.generate(*base_path, 'bandwidth', str(intf_data['bandwidth']))
            
            if 'cost' in intf_data and is_str_not_empty(intf_data['cost']):
                self.generate(*base_path, 'cost', str(intf_data['cost']))
            
            if 'dead-interval' in intf_data and is_str_not_empty(intf_data['dead-interval']):
                self.generate(*base_path, 'dead-interval', str(intf_data['dead-interval']))
            
            if 'hello-interval' in intf_data and is_str_not_empty(intf_data['hello-interval']):
                self.generate(*base_path, 'hello-interval', str(intf_data['hello-interval']))
            
            if 'hello-multiplier' in intf_data and is_str_not_empty(intf_data['hello-multiplier']):
                self.generate(*base_path, 'hello-multiplier', str(intf_data['hello-multiplier']))
            
            if 'mtu-ignore' in intf_data:
                self.generate(*base_path, 'mtu-ignore')
            
            if 'network' in intf_data and is_str_not_empty(intf_data['network']):
                self.generate(*base_path, 'network', intf_data['network'])
            
            if 'passive' in intf_data:
                if 'disable' in intf_data['passive']:
                    self.generate(*base_path, 'passive', 'disable')
            
            if 'priority' in intf_data and is_str_not_empty(intf_data['priority']):
                self.generate(*base_path, 'priority', str(intf_data['priority']))
            
            if 'retransmit-interval' in intf_data and is_str_not_empty(intf_data['retransmit-interval']):
                self.generate(*base_path, 'retransmit-interval', str(intf_data['retransmit-interval']))
            
            if 'retransmit-window' in intf_data and is_str_not_empty(intf_data['retransmit-window']):
                self.generate(*base_path, 'retransmit-window', str(intf_data['retransmit-window']))
            
            if 'transmit-delay' in intf_data and is_str_not_empty(intf_data['transmit-delay']):
                self.generate(*base_path, 'transmit-delay', str(intf_data['transmit-delay']))
            
            # Process authentication
            if 'authentication' in intf_data:
                self._process_interface_authentication(base_path, intf_data['authentication'])
    
    def _process_interface_authentication(self, base_path, auth_config):
        auth_path = base_path + ['authentication']
        
        if not isinstance(auth_config, dict):
            if isinstance(auth_config, str) and is_str_not_empty(auth_config):
                self.generate(*auth_path, auth_config)
            return
        
        if 'md5' in auth_config:
            md5_config = auth_config['md5']
            if 'key-id' in md5_config:
                for key_id, key_data in md5_config['key-id'].items():
                    if 'md5-key' in key_data and is_str_not_empty(key_data['md5-key']):
                        self.generate(*auth_path, 'md5', 'key-id', str(key_id), 'md5-key', key_data['md5-key'])
        
        if 'plaintext-password' in auth_config and is_str_not_empty(auth_config['plaintext-password']):
            self.generate(*auth_path, 'plaintext-password', auth_config['plaintext-password'])
    
    def _process_redistribute_config(self, redistribute_config, current_config, new_config):
        for protocol, protocol_data in redistribute_config.items():
            base_path = ['protocols', 'ospf', 'redistribute', protocol]

            if self.operator == 'delete' and protocol not in new_config.get('redistribute', {}):
                self.generate(*base_path)
                continue
            
            if not isinstance(protocol_data, dict) or not protocol_data or protocol_data == {}:
                self.generate(*base_path)
                continue
            
            if 'metric' in protocol_data and is_str_not_empty(protocol_data['metric']):
                self.generate(*base_path, 'metric', str(protocol_data['metric']))
            
            if 'metric-type' in protocol_data and is_str_not_empty(protocol_data['metric-type']):
                self.generate(*base_path, 'metric-type', str(protocol_data['metric-type']))
    
    def _process_neighbor_config(self, neighbor_config, current_config, new_config):
        for neighbor_ip, neighbor_data in neighbor_config.items():
            base_path = ['protocols', 'ospf', 'neighbor', neighbor_ip]

            if self.operator == 'delete' and neighbor_ip not in new_config.get('neighbor', {}):
                self.generate(*base_path)
                continue
            
            if not neighbor_data or neighbor_data == {}:
                self.generate(*base_path)
                continue
            
            if 'poll-interval' in neighbor_data and is_str_not_empty(neighbor_data['poll-interval']):
                self.generate(*base_path, 'poll-interval', str(neighbor_data['poll-interval']))
            
            if 'priority' in neighbor_data and is_str_not_empty(neighbor_data['priority']):
                self.generate(*base_path, 'priority', str(neighbor_data['priority']))
    
    def _process_summary_address_config(self, summary_config):
        for summary_prefix, summary_data in summary_config.items():
            base_path = ['protocols', 'ospf', 'summary-address', summary_prefix]
            
            if not summary_data or summary_data == {}:
                self.generate(*base_path)
                continue
            
            if 'no-advertise' in summary_data:
                self.generate(*base_path, 'no-advertise')
    
    def _process_global_parameters(self, data):
        base_path = ['protocols', 'ospf']
        
        if 'aggregation' in data and 'timer' in data['aggregation']:
            if is_str_not_empty(data['aggregation']['timer']):
                self.generate(*base_path, 'aggregation', 'timer', str(data['aggregation']['timer']))
        
        if 'auto-cost' in data and 'reference-bandwidth' in data['auto-cost']:
            if is_str_not_empty(data['auto-cost']['reference-bandwidth']):
                self.generate(*base_path, 'auto-cost', 'reference-bandwidth', str(data['auto-cost']['reference-bandwidth']))
        
        if 'default-metric' in data and is_str_not_empty(data['default-metric']):
            self.generate(*base_path, 'default-metric', str(data['default-metric']))
        
        if 'capability' in data and 'opaque' in data['capability']:
            self.generate(*base_path, 'capability', 'opaque')
        
        if 'log-adjacency-changes' in data:
            if 'detail' in data['log-adjacency-changes']:
                self.generate(*base_path, 'log-adjacency-changes', 'detail')
        
        if 'maximum-paths' in data and is_str_not_empty(data['maximum-paths']):
            self.generate(*base_path, 'maximum-paths', str(data['maximum-paths']))
        
        if 'passive-interface' in data:
            if 'default' in data['passive-interface']:
                self.generate(*base_path, 'passive-interface', 'default')
        
        if 'refresh' in data and 'timers' in data['refresh']:
            if is_str_not_empty(data['refresh']['timers']):
                self.generate(*base_path, 'refresh', 'timers', str(data['refresh']['timers']))
    
    def _process_max_metric_config(self, max_metric_config):
        base_path = ['protocols', 'ospf', 'max-metric', 'router-lsa']
        
        if 'administrative' in max_metric_config:
            self.generate(*base_path, 'administrative')
        
        if 'on-shutdown' in max_metric_config and is_str_not_empty(max_metric_config['on-shutdown']):
            self.generate(*base_path, 'on-shutdown', str(max_metric_config['on-shutdown']))
        
        if 'on-startup' in max_metric_config and is_str_not_empty(max_metric_config['on-startup']):
            self.generate(*base_path, 'on-startup', str(max_metric_config['on-startup']))
    
    def _process_parameters_config(self, parameters_config):
        base_path = ['protocols', 'ospf', 'parameters']
        
        if 'abr-type' in parameters_config and is_str_not_empty(parameters_config['abr-type']):
            self.generate(*base_path, 'abr-type', parameters_config['abr-type'])
        
        if 'opaque-lsa' in parameters_config:
            self.generate(*base_path, 'opaque-lsa')
        
        if 'rfc1583-compatibility' in parameters_config:
            self.generate(*base_path, 'rfc1583-compatibility')
        
        if 'router-id' in parameters_config and is_str_not_empty(parameters_config['router-id']):
            self.generate(*base_path, 'router-id', parameters_config['router-id'])
    
    def _process_timers_config(self, timers_config):
        if 'throttle' in timers_config and 'spf' in timers_config['throttle']:
            spf_config = timers_config['throttle']['spf']
            base_path = ['protocols', 'ospf', 'timers', 'throttle', 'spf']
            
            if 'delay' in spf_config and is_str_not_empty(spf_config['delay']):
                self.generate(*base_path, 'delay', str(spf_config['delay']))
            
            if 'initial-holdtime' in spf_config and is_str_not_empty(spf_config['initial-holdtime']):
                self.generate(*base_path, 'initial-holdtime', str(spf_config['initial-holdtime']))
            
            if 'max-holdtime' in spf_config and is_str_not_empty(spf_config['max-holdtime']):
                self.generate(*base_path, 'max-holdtime', str(spf_config['max-holdtime']))
    
    def _process_default_information_config(self, default_info_config):
        base_path = ['protocols', 'ospf', 'default-information', 'originate']
        
        if 'always' in default_info_config:
            self.generate(*base_path, 'always')
        
        if 'metric' in default_info_config and is_str_not_empty(default_info_config['metric']):
            self.generate(*base_path, 'metric', str(default_info_config['metric']))
        
        if 'metric-type' in default_info_config and is_str_not_empty(default_info_config['metric-type']):
            self.generate(*base_path, 'metric-type', str(default_info_config['metric-type']))
    
    def _process_distance_config(self, distance_config):
        base_path = ['protocols', 'ospf', 'distance']
        
        if 'global' in distance_config and is_str_not_empty(distance_config['global']):
            self.generate(*base_path, 'global', str(distance_config['global']))
        
        if 'ospf' in distance_config:
            ospf_distance = distance_config['ospf']
            ospf_path = base_path + ['ospf']
            
            if 'external' in ospf_distance and is_str_not_empty(ospf_distance['external']):
                self.generate(*ospf_path, 'external', str(ospf_distance['external']))
            
            if 'inter-area' in ospf_distance and is_str_not_empty(ospf_distance['inter-area']):
                self.generate(*ospf_path, 'inter-area', str(ospf_distance['inter-area']))
            
            if 'intra-area' in ospf_distance and is_str_not_empty(ospf_distance['intra-area']):
                self.generate(*ospf_path, 'intra-area', str(ospf_distance['intra-area']))
    
    def _process_graceful_restart_config(self, graceful_restart_config):
        base_path = ['protocols', 'ospf', 'graceful-restart']
        
        if not graceful_restart_config or graceful_restart_config == {} or graceful_restart_config is True:
            self.generate(*base_path)
            return
        
        if 'grace-period' in graceful_restart_config and is_str_not_empty(graceful_restart_config['grace-period']):
            self.generate(*base_path, 'grace-period', str(graceful_restart_config['grace-period']))
