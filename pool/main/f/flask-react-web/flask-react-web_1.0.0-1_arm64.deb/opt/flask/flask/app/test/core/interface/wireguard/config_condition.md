## Config conditions
- public-key is required each peer
- address/host-name are mutually exclusive
- allowed-ips is required each peer