import ipaddress
import re
from functools import partial
from typing import Annotated

from pydantic import AfterValidator, StrictStr


def validate_name(name, minimum=None, maximum=None):
    if not isinstance(name, str) or not re.fullmatch(r'[^\s/\x00-\x1f]+', name) or len(name) > 255:
        raise ValueError('Entry names must be 1–255 characters without spaces or slashes')
    if minimum is not None and (not name.isdecimal() or not minimum <= int(name) <= maximum):
        raise ValueError(f'Entry ID must be between {minimum} and {maximum}')


def validate_integer(value, minimum, maximum, special):
    if value not in special and (not value.isdecimal() or not minimum <= int(value) <= maximum):
        raise ValueError(f'Enter an integer between {minimum} and {maximum}')
    return value


def integer_text(minimum, maximum, special=()):
    return Annotated[StrictStr, AfterValidator(partial(validate_integer, minimum=minimum, maximum=maximum, special=special))]


def validate_hex(value):
    if not re.fullmatch(r'(0[xX])?[0-9a-fA-F]+', value):
        raise ValueError('Enter a hexadecimal value')
    return value


def validate_uid_range(value):
    ends = value.split('-')
    if len(ends) > 2 or not all(end.isdecimal() and 1 <= int(end) <= 247 for end in ends) or int(ends[0]) > int(ends[-1]):
        raise ValueError('Enter a UID or ascending range between 1 and 247')
    return value


def validate_address(value, hostname=False):
    try:
        ipaddress.ip_address(value)
    except ValueError:
        if not hostname or len(value) > 253 or not all(re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?', label) for label in value.rstrip('.').split('.')) or all(label.isdecimal() for label in value.split('.')):
            raise ValueError('Invalid address or hostname')
    return value


HexText = Annotated[StrictStr, AfterValidator(validate_hex)]
UidRangeText = Annotated[StrictStr, AfterValidator(validate_uid_range)]
AddressText = Annotated[StrictStr, AfterValidator(validate_address)]
HostText = Annotated[StrictStr, AfterValidator(partial(validate_address, hostname=True))]


def validate_ipv4_interface(value):
    try:
        if not re.fullmatch(r'[^/]+/(?:[0-9]|[12][0-9]|3[0-2])', value):
            raise ValueError
        ipaddress.IPv4Interface(value)
    except ValueError:
        raise ValueError('Enter a valid IPv4 address with a prefix length (0–32), e.g. 192.168.1.3/24')
    return value


IPv4InterfaceText = Annotated[StrictStr, AfterValidator(validate_ipv4_interface)]


def validate_ppp_remote_address(value):
    return value if value == 'negotiation' else validate_ipv4_interface(value)


def validate_ipv6_interface(value):
    try:
        if not re.fullmatch(r'[^/]+/(?:[0-9]|[1-9][0-9]|1[01][0-9]|12[0-8])', value):
            raise ValueError
        ipaddress.IPv6Interface(value)
    except ValueError:
        raise ValueError('Enter an IPv6 address with a prefix length (0–128)')
    return value


def validate_ppp_ipv6_identifier(value):
    if not re.fullmatch(r'::(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*)?', value):
        raise ValueError('Enter an IPv6 interface identifier starting with ::, e.g. ::1:2:3:4')
    return value


PppRemoteAddressText = Annotated[StrictStr, AfterValidator(validate_ppp_remote_address)]
IPv6InterfaceText = Annotated[StrictStr, AfterValidator(validate_ipv6_interface)]
PppIpv6IdentifierText = Annotated[StrictStr, AfterValidator(validate_ppp_ipv6_identifier)]
