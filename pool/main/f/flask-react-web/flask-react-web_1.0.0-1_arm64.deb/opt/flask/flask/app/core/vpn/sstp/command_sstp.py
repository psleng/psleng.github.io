def is_str_not_empty(value):
    return isinstance(value, str) and value.strip() != ''


class SSTPCommand:
    """
    SSTPCommand class is used to generate commands for SSTP configuration:
    
    - set/delete vpn sstp authentication mode {local | radius | noauth}
    - set/delete vpn sstp authentication protocols { pap | chap | mschap | mschapv2}
    - set/delete vpn sstp authentication local-users <username> disable
    - set/delete vpn sstp authentication local-users <username> password <passwd>
    - set/delete vpn sstp authentication local-users <username> static-ip <IPv4>
    - set/delete vpn sstp authentication radius server <IPv4>
    - set/delete vpn sstp authentication radius server <IPv4> disable
    - set/delete vpn sstp authentication radius server <IPv4> key <key-in-text>
    - set/delete vpn sstp authentication radius server <IPv4> port <1-65535>
    - set/delete vpn sstp authentication radius server <IPv4> priority <1-255>
    - set/delete vpn sstp authentication radius server <IPv4> acct-port
    - set/delete vpn sstp authentication radius server <IPv4> backup
    - set/delete vpn sstp authentication radius server <IPv4> disable-accounting
    - set/delete vpn sstp authentication radius server <IPv4> fail-time <0-600>
    - set/delete vpn sstp authentication radius source-address <IPv4>
    - set/delete vpn sstp authentication radius nas-identifier  <text>
    - set/delete vpn sstp authentication radius nas-ip-address <IPv4>
    - set/delete vpn sstp authentication radius timeout <1-60>
    - set/delete vpn sstp authentication radius acct-timeout <0-60>
    - set/delete vpn sstp authentication radius max-try <1-20>
    - set/delete vpn sstp default-ipv6-pool <pool-name>
    - set/delete vpn sstp default-pool <pool-name>
    - set/delete vpn sstp description <text>
    - set/delete vpn sstp gateway-address <IPv4>
    - set/delete vpn sstp ssl ca-certificate <ca-cert>
    - set/delete vpn sstp ssl certificate <cert>
    - set/delete vpn sstp host-name <hostname>
    - set/delete vpn sstp mtu <128-16384>
    - set/delete vpn sstp name-server  <IPv4 | IPv6>
    - set/delete vpn sstp port <1-65535>
    - set/delete vpn sstp log level <0-5>
    - set/delete vpn sstp wins-server <IPv4>
    - set/delete vpn sstp ppp-options disable-ccp
    - set/delete vpn sstp ppp-options interface-cache <1-256000>
    - set/delete vpn sstp ppp-options ipv4 {deny | allow | prefer | require}
    - set/delete vpn sstp ppp-options ipv6-accept-peer-interface-id 
    - set/delete vpn sstp ppp-options ipv6-peer-interface-id 
    - set/delete vpn sstp ppp-options ipv6-interface-id {x:x:x:x | random}
    - set/delete vpn sstp ppp-options ipv6-peer-interface-id {x:x:x:x | random | ipv4-addr | calling-sid}
    - set/delete vpn sstp ppp-options lcp-echo-failure <value>
    - set/delete vpn sstp ppp-options lcp-echo-interval <value>
    - set/delete vpn sstp ppp-options lcp-echo-timeout <value>
    - set/delete vpn sstp ppp-options min-mtu <68-65535>
    - set/delete vpn sstp ppp-options mppe {require | prefer | deny}
    - set/delete vpn sstp ppp-options mru <68-65535>
    - set/delete vpn sstp client-ip-pool <pool-name> range <x.x.x.x/n | x.x.x.x/24-y.y.y.y/24>
    - set/delete vpn sstp client-ipv6-pool <pool-name> prefix <h:h:h:h:h:h:h:h/x>

    """
    def __init__(self, operator='set', config=None, resource='sstp'):
        self.operator = operator
        self.resource = resource
        self.config = config or {}
        self.cmds = []
        self.vyos_cmds = []

    def generate_commands(self, data, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            sstp_config = data.get('sstp', data) if 'sstp' in data else data
            
            if not sstp_config:
                return []
            
            if 'authentication' in sstp_config:
                self._process_authentication(sstp_config['authentication'], current_config, new_config)
            
            self._process_general_settings(sstp_config, current_config, new_config)
            
            if 'ssl' in sstp_config:
                self._process_ssl(sstp_config['ssl'])
            
            if 'ppp-options' in sstp_config:
                self._process_ppp_options(sstp_config['ppp-options'])
            
            if 'client-ip-pool' in sstp_config:
                self._process_client_ip_pools(sstp_config['client-ip-pool'], current_config, new_config)
            
            if 'client-ipv6-pool' in sstp_config:
                self._process_client_ipv6_pools(sstp_config['client-ipv6-pool'], current_config, new_config)

            return self.cmds
        except Exception as e:
            print(f"Error generating SSTP commands: {e}")
            import traceback
            traceback.print_exc()
            return []

    def _process_authentication(self, auth_config, current_config=None, new_config=None):
        base_path = ['vpn', 'sstp', 'authentication']
        
        if 'protocols' in auth_config:
            protocols = auth_config['protocols']
            if isinstance(protocols, list):
                for protocol in protocols:
                    if is_str_not_empty(protocol):
                        self.generate(*base_path, 'protocols', protocol)
            elif is_str_not_empty(protocols):
                self.generate(*base_path, 'protocols', protocols)
        
        if 'local-users' in auth_config and 'username' in auth_config['local-users']:
            for username, user_config in auth_config['local-users']['username'].items():
                user_path = base_path + ['local-users', 'username', username]
                
                if self.operator == 'delete':
                    if username not in new_config.get('authentication', {}).get('local-users', {}).get('username', {}):
                        self.generate(*user_path)
                        continue
                
                if 'disable' in user_config:
                    self.generate(*user_path, 'disable')
                
                if 'password' in user_config and is_str_not_empty(user_config['password']):
                    self.generate(*user_path, 'password', user_config['password'])
                
                if 'static-ip' in user_config and is_str_not_empty(user_config['static-ip']):
                    self.generate(*user_path, 'static-ip', user_config['static-ip'])
        
        if 'radius' in auth_config:
            self._process_radius(auth_config['radius'], current_config, new_config)
        
        if 'mode' in auth_config and is_str_not_empty(auth_config['mode']) and self.operator != 'delete':
            self.generate(*base_path, 'mode', auth_config['mode'])

    def _process_radius(self, radius_config, current_config=None, new_config=None):
        base_path = ['vpn', 'sstp', 'authentication', 'radius']
        
        if 'server' in radius_config:
            for server_ip, server_config in radius_config['server'].items():
                server_path = base_path + ['server', server_ip]
                
                if self.operator == 'delete':
                    new_servers = new_config.get('authentication', {}).get('radius', {}).get('server', {})
                    if server_ip not in new_servers:
                        self.generate(*server_path)
                        continue
                
                if 'disable' in server_config:
                    self.generate(*server_path, 'disable')
                
                if 'key' in server_config and is_str_not_empty(server_config['key']):
                    self.generate(*server_path, 'key', server_config['key'])
                
                if 'port' in server_config and is_str_not_empty(str(server_config['port'])):
                    self.generate(*server_path, 'port', str(server_config['port']))
                
                if 'priority' in server_config and is_str_not_empty(str(server_config['priority'])):
                    self.generate(*server_path, 'priority', str(server_config['priority']))
                
                if 'acct-port' in server_config and is_str_not_empty(str(server_config['acct-port'])):
                    self.generate(*server_path, 'acct-port', str(server_config['acct-port']))
                
                if 'backup' in server_config:
                    self.generate(*server_path, 'backup')
                
                if 'disable-accounting' in server_config:
                    self.generate(*server_path, 'disable-accounting')
                
                if 'fail-time' in server_config and is_str_not_empty(str(server_config['fail-time'])):
                    self.generate(*server_path, 'fail-time', str(server_config['fail-time']))
        
        if 'source-address' in radius_config and is_str_not_empty(radius_config['source-address']):
            self.generate(*base_path, 'source-address', radius_config['source-address'])
        
        if 'nas-identifier' in radius_config and is_str_not_empty(radius_config['nas-identifier']):
            self.generate(*base_path, 'nas-identifier', radius_config['nas-identifier'])
        
        if 'nas-ip-address' in radius_config and is_str_not_empty(radius_config['nas-ip-address']):
            self.generate(*base_path, 'nas-ip-address', radius_config['nas-ip-address'])
        
        if 'timeout' in radius_config and is_str_not_empty(str(radius_config['timeout'])):
            self.generate(*base_path, 'timeout', str(radius_config['timeout']))
        
        if 'acct-timeout' in radius_config and is_str_not_empty(str(radius_config['acct-timeout'])):
            self.generate(*base_path, 'acct-timeout', str(radius_config['acct-timeout']))
        
        if 'max-try' in radius_config and is_str_not_empty(str(radius_config['max-try'])):
            self.generate(*base_path, 'max-try', str(radius_config['max-try']))

    def _process_general_settings(self, sstp_config, current_config=None, new_config=None):
        base_path = ['vpn', 'sstp']
        
        if 'description' in sstp_config and is_str_not_empty(sstp_config['description']):
            self.generate(*base_path, 'description', sstp_config['description'])
        
        if 'default-pool' in sstp_config and is_str_not_empty(sstp_config['default-pool']):
            self.generate(*base_path, 'default-pool', sstp_config['default-pool'])
        
        if 'default-ipv6-pool' in sstp_config and is_str_not_empty(sstp_config['default-ipv6-pool']):
            self.generate(*base_path, 'default-ipv6-pool', sstp_config['default-ipv6-pool'])
        
        if 'gateway-address' in sstp_config and is_str_not_empty(sstp_config['gateway-address']):
            self.generate(*base_path, 'gateway-address', sstp_config['gateway-address'])
        
        if 'host-name' in sstp_config and is_str_not_empty(sstp_config['host-name']):
            self.generate(*base_path, 'host-name', sstp_config['host-name'])
        
        if 'port' in sstp_config and is_str_not_empty(str(sstp_config['port'])):
            self.generate(*base_path, 'port', str(sstp_config['port']))
        
        if 'mtu' in sstp_config and is_str_not_empty(str(sstp_config['mtu'])):
            self.generate(*base_path, 'mtu', str(sstp_config['mtu']))
        
        if 'name-server' in sstp_config:
            name_servers = sstp_config['name-server']
            if isinstance(name_servers, list):
                for ns in name_servers:
                    if is_str_not_empty(ns):
                        self.generate(*base_path, 'name-server', ns)
            elif is_str_not_empty(name_servers):
                self.generate(*base_path, 'name-server', name_servers)
        
        if 'wins-server' in sstp_config:
            wins_servers = sstp_config['wins-server']
            if isinstance(wins_servers, list):
                for ws in wins_servers:
                    if is_str_not_empty(ws):
                        self.generate(*base_path, 'wins-server', ws)
            elif is_str_not_empty(wins_servers):
                self.generate(*base_path, 'wins-server', wins_servers)
        
        if 'log' in sstp_config and 'level' in sstp_config['log']:
            self.generate(*base_path, 'log', 'level', str(sstp_config['log']['level']))

    def _process_ssl(self, ssl_config):
        base_path = ['vpn', 'sstp', 'ssl']
        
        if 'ca-certificate' in ssl_config and is_str_not_empty(ssl_config['ca-certificate']):
            self.generate(*base_path, 'ca-certificate', ssl_config['ca-certificate'])
        
        if 'certificate' in ssl_config and is_str_not_empty(ssl_config['certificate']):
            self.generate(*base_path, 'certificate', ssl_config['certificate'])

    def _process_ppp_options(self, ppp_config):
        base_path = ['vpn', 'sstp', 'ppp-options']
        
        if 'disable-ccp' in ppp_config:
            self.generate(*base_path, 'disable-ccp')
        
        if 'interface-cache' in ppp_config and is_str_not_empty(str(ppp_config['interface-cache'])):
            self.generate(*base_path, 'interface-cache', str(ppp_config['interface-cache']))
        
        if 'ipv4' in ppp_config and is_str_not_empty(ppp_config['ipv4']):
            self.generate(*base_path, 'ipv4', ppp_config['ipv4'])
        
        if 'ipv6' in ppp_config and is_str_not_empty(ppp_config['ipv6']):
            self.generate(*base_path, 'ipv6', ppp_config['ipv6'])
        
        if 'ipv6-accept-peer-interface-id' in ppp_config:
            self.generate(*base_path, 'ipv6-accept-peer-interface-id')
        
        if 'ipv6-interface-id' in ppp_config and is_str_not_empty(ppp_config['ipv6-interface-id']):
            self.generate(*base_path, 'ipv6-interface-id', ppp_config['ipv6-interface-id'])
        
        if 'ipv6-peer-interface-id' in ppp_config and is_str_not_empty(ppp_config['ipv6-peer-interface-id']):
            self.generate(*base_path, 'ipv6-peer-interface-id', ppp_config['ipv6-peer-interface-id'])
        
        if 'lcp-echo-failure' in ppp_config and is_str_not_empty(str(ppp_config['lcp-echo-failure'])):
            self.generate(*base_path, 'lcp-echo-failure', str(ppp_config['lcp-echo-failure']))
        
        if 'lcp-echo-interval' in ppp_config and is_str_not_empty(str(ppp_config['lcp-echo-interval'])):
            self.generate(*base_path, 'lcp-echo-interval', str(ppp_config['lcp-echo-interval']))
        
        if 'lcp-echo-timeout' in ppp_config and is_str_not_empty(str(ppp_config['lcp-echo-timeout'])):
            self.generate(*base_path, 'lcp-echo-timeout', str(ppp_config['lcp-echo-timeout']))
        
        if 'min-mtu' in ppp_config and is_str_not_empty(str(ppp_config['min-mtu'])):
            self.generate(*base_path, 'min-mtu', str(ppp_config['min-mtu']))
        
        if 'mppe' in ppp_config and is_str_not_empty(ppp_config['mppe']):
            self.generate(*base_path, 'mppe', ppp_config['mppe'])
        
        if 'mru' in ppp_config and is_str_not_empty(str(ppp_config['mru'])):
            self.generate(*base_path, 'mru', str(ppp_config['mru']))

    def _process_client_ip_pools(self, ip_pools, current_config=None, new_config=None):
        base_path = ['vpn', 'sstp', 'client-ip-pool']
        
        for pool_name, pool_config in ip_pools.items():
            pool_path = base_path + [pool_name]
            
            if self.operator == 'delete':
                new_pools = new_config.get('client-ip-pool', {})
                if pool_name not in new_pools:
                    self.generate(*pool_path)
                    continue
            
            if 'range' in pool_config and is_str_not_empty(pool_config['range']):
                self.generate(*pool_path, 'range', pool_config['range'])

    def _process_client_ipv6_pools(self, ipv6_pools, current_config=None, new_config=None):
        base_path = ['vpn', 'sstp', 'client-ipv6-pool']
        
        for pool_name, pool_config in ipv6_pools.items():
            pool_path = base_path + [pool_name]
            
            if self.operator == 'delete':
                new_pools = new_config.get('client-ipv6-pool', {})
                if pool_name not in new_pools:
                    self.generate(*pool_path)
                    continue
            
            if 'prefix' in pool_config:
                prefixes = pool_config['prefix']
                if isinstance(prefixes, dict):
                    for prefix in prefixes.keys():
                        if is_str_not_empty(prefix):
                            self.generate(*pool_path, 'prefix', prefix)
                elif is_str_not_empty(prefixes):
                    self.generate(*pool_path, 'prefix', prefixes)

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
