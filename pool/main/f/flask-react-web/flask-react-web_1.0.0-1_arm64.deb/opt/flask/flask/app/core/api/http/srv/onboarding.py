from datetime import datetime

from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.api.http.http_request import Action
from app.core.login.db_models import SystemLoginOptions
from app.core.models import System
from app.log.logger import logger


class OnboardingConfigurationError(Exception):
    pass


class OnboardingValidationError(OnboardingConfigurationError):
    pass


def configure_onboarding(provider, data):
    field = 'SetIgosOnboardingPerleIgosOnboardingMutation'
    mutation_data = {
        'password': data['password'],
        'timezone': data['timezone'],
        'enhanced_policy': data.get('enhancedSecurity', False),
        'minimum_length': data['minlen'],
        'minimum_uppercase': data['ucredit'],
        'minimum_digit': data['dcredit'],
        'minimum_special': data['ocredit'],
    }
    if data.get('dateTime'):
        mutation_data['date_time'] = datetime.fromisoformat(data['dateTime']).strftime('%Y-%m-%d %H:%M:%S')

    response = provider.graphql_service.send_mutation_request(
        function_name=field,
        mutation_name=field,
        input_name=f'{field}Input',
        data=mutation_data,
        verify=False,
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict) or payload.get('errors'):
        raise OnboardingConfigurationError('Unable to apply the device onboarding configuration.')

    mutation = (payload.get('data') or {}).get(field)
    if not isinstance(mutation, dict) or mutation.get('success') is not True or mutation.get('errors'):
        raise OnboardingConfigurationError('The device rejected the onboarding configuration.')

    result = (mutation.get('data') or {}).get('result')
    if (not isinstance(result, dict) or result.get('success') is not True
            or not isinstance(result.get('saved'), bool)
            or not isinstance(result.get('already_completed'), bool)):
        raise OnboardingConfigurationError('The device returned an unsuccessful onboarding result.')

    warnings = [result['warning']] if result.get('warning') else []
    if not result['saved'] and not result['already_completed'] and not warnings:
        warnings.append('The onboarding configuration is active but could not be saved.')

    try:
        response = provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=SHOW_ALL_CONFIGS,
            verify=False,
        )
        response.raise_for_status()
        current_config = response.json()['data']['system']
        SystemLoginOptions.refresh(current_config.get('login', {}))
        System.set_timezone(current_config.get('time-zone'))
    except Exception as error:
        logger.error('Failed to refresh the local onboarding configuration: %s', error)
        warnings.append('Device setup is complete, but the local configuration could not be refreshed.')

    response_data = {**result, 'required': False, 'warning': ' '.join(warnings)}
    return response_data
