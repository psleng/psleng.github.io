from pydantic import BaseModel
from typing import Optional, List
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship


class SSTPGeneralDTO(BaseModel):
    description: Optional[str] = ''
    defaultIPPool: Optional[str] = ''
    defaultIPv6Pool: Optional[str] = ''
    gatewayAddress: Optional[str] = ''
    hostName: Optional[str] = ''
    port: Optional[int] = None


class SSTPPPDTO(BaseModel):
    controlProtocol: Optional[bool] = None
    interfaceCaching: Optional[int] = None
    IPv4Negotiation: Optional[str] = None
    IPv6Negotiation: Optional[str] = None
    acceptPeerInterfaceID: Optional[bool] = None
    IPv6InterfaceID: Optional[str] = None
    IPv6PeerInterface: Optional[str] = None
    LCPEchoFailure: Optional[int] = None
    LCPEchoInterval: Optional[int] = None
    LCPEchoTimeout: Optional[int] = None
    minMTU: Optional[int] = None
    MPPE: Optional[str] = None
    MRU: Optional[int] = None


class SSTPAdvancedDTO(BaseModel):
    MTU: Optional[int] = None
    nameServers: Optional[List[str]] = []
    log: Optional[int] = None
    WINS: Optional[List[str]] = []
    PPP: Optional[SSTPPPDTO] = None


class SSTPSLDTO(BaseModel):
    caCertificate: Optional[str] = ''
    certificate: Optional[str] = ''

class SSTPClientIPPoolDTO(BaseModel):
    name: Optional[str] = ''
    subnet: Optional[str] = ''


class SSTPClientIPPoolsDTO(BaseModel):
    pools: Optional[List[SSTPClientIPPoolDTO]] = []


class SSTPClientIPv6PoolDTO(BaseModel):
    name: Optional[str] = ''
    prefix: Optional[str] = ''


class SSTPClientIPv6PoolsDTO(BaseModel):
    IPv6Pools: Optional[List[SSTPClientIPv6PoolDTO]] = []

class SSTPConnectionDTO(BaseModel):
    general: Optional[SSTPGeneralDTO] = None
    advanced: Optional[SSTPAdvancedDTO] = None
    ssl: Optional[SSTPSLDTO] = None
    clientIPPools: Optional[SSTPClientIPPoolsDTO] = None
    clientIPv6Pools: Optional[SSTPClientIPv6PoolsDTO] = None



class SSTPLocalUserDTO(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = ''
    staticIP: Optional[str] = ''
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True


class SSTPLocalUsersDTO(BaseModel):
    users: Optional[List[SSTPLocalUserDTO]] = []


class SSTPRadiusServerDTO(BaseModel):
    address: Optional[str] = ''
    port: Optional[int] = 1812
    key: Optional[str] = None
    secret: Optional[str] = None
    priority: Optional[int] = 1
    accountingPort: Optional[int] = 1813
    failTimePenalty: Optional[int] = 0
    disableAccounting: Optional[bool] = False
    backup: Optional[bool] = False
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True


class SSTPRadiusOptionsDTO(BaseModel):
    sourceAddress: Optional[str] = None
    NASIdentifier: Optional[str] = None
    NASIPAddress: Optional[str] = None
    timeout: Optional[int] = None
    maxTry: Optional[int] = None
    acctTimeout: Optional[int] = None


class SSTPRadiusDTO(BaseModel):
    servers: Optional[List[SSTPRadiusServerDTO]] = []
    options: Optional[SSTPRadiusOptionsDTO] = None


class SSTPSecurityDTO(BaseModel):
    protocol: Optional[List[str]] = []
    mode: Optional[str] = ''
    localUsers: Optional[SSTPLocalUsersDTO] = None
    radius: Optional[SSTPRadiusDTO] = None


class UpdateSSTPDTO(BaseModel):
    connection: Optional[SSTPConnectionDTO] = None
    security: Optional[SSTPSecurityDTO] = None


class SSTPConfig(db.Model):
    __tablename__ = 'vyos_config_sstp'
    
    id = Column(Integer, primary_key=True)
    description = Column(String(255))
    default_pool = Column(String(100))
    default_ipv6_pool = Column(String(100))
    gateway_address = Column(String(50))
    host_name = Column(String(255))
    port = Column(Integer, default=443)
    mtu = Column(Integer)
    log_level = Column(Integer)
    
    # SSL Configuration
    ssl_ca_certificate = Column(String(255))
    ssl_certificate = Column(String(255))
    
    auth_mode = Column(String(50))
    auth_protocols = Column(Text)
    
    radius_source_address = Column(String(50))
    radius_nas_identifier = Column(String(100))
    radius_nas_ip_address = Column(String(50))
    radius_timeout = Column(Integer)
    radius_acct_timeout = Column(Integer)
    radius_max_try = Column(Integer)
    
    ppp_disable_ccp = Column(Boolean, default=False)
    ppp_interface_cache = Column(Integer)
    ppp_ipv4 = Column(String(20))
    ppp_ipv6 = Column(String(20))
    ppp_ipv6_accept_peer_interface_id = Column(Boolean, default=False)
    ppp_ipv6_interface_id = Column(String(50))
    ppp_ipv6_peer_interface_id = Column(String(50))
    ppp_lcp_echo_failure = Column(Integer)
    ppp_lcp_echo_interval = Column(Integer)
    ppp_lcp_echo_timeout = Column(Integer)
    ppp_min_mtu = Column(Integer)
    ppp_mppe = Column(String(20))
    ppp_mru = Column(Integer)
    
    name_servers = Column(Text)
    wins_servers = Column(Text)
    
    local_users = relationship('SSTPLocalUser', back_populates='config', cascade='all, delete-orphan')
    radius_servers = relationship('SSTPRadiusServer', back_populates='config', cascade='all, delete-orphan')
    ip_pools = relationship('SSTPIPPool', back_populates='config', cascade='all, delete-orphan')
    ipv6_pools = relationship('SSTPIPv6Pool', back_populates='config', cascade='all, delete-orphan')

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_sstp_ipv6_pool',
            'vyos_config_sstp_ip_pool',
            'vyos_config_sstp_radius_server',
            'vyos_config_sstp_local_user',
            'vyos_config_sstp'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config):
        cls.truncate()
        
        if not config:
            return
        
        sstp_config = cls()
        
        sstp_config.description = config.get('description', '')
        sstp_config.default_pool = config.get('default-pool', '')
        sstp_config.default_ipv6_pool = config.get('default-ipv6-pool', '')
        sstp_config.gateway_address = config.get('gateway-address', '')
        sstp_config.host_name = config.get('host-name', '')
        sstp_config.port = int(config.get('port', 0)) if config.get('port') else None
        sstp_config.mtu = int(config.get('mtu', 0)) if config.get('mtu') else None
        
        if 'log' in config and 'level' in config['log']:
            sstp_config.log_level = int(config['log']['level'])
        
        # SSL Configuration
        if 'ssl' in config:
            ssl = config['ssl']
            sstp_config.ssl_ca_certificate = ssl.get('ca-certificate', '')
            sstp_config.ssl_certificate = ssl.get('certificate', '')
        
        if isinstance(config.get('name-server'), list):
            sstp_config.name_servers = ','.join(config['name-server'])
        elif config.get('name-server'):
            sstp_config.name_servers = config['name-server']
        
        if isinstance(config.get('wins-server'), list):
            sstp_config.wins_servers = ','.join(config['wins-server'])
        elif config.get('wins-server'):
            sstp_config.wins_servers = config['wins-server']
        
        if 'authentication' in config:
            auth = config['authentication']
            sstp_config.auth_mode = auth.get('mode', '')
            
            if 'protocols' in auth:
                if isinstance(auth['protocols'], list):
                    sstp_config.auth_protocols = ','.join(auth['protocols'])
                else:
                    sstp_config.auth_protocols = auth['protocols']
            
            if 'local-users' in auth and 'username' in auth['local-users']:
                for username, user_data in auth['local-users']['username'].items():
                    local_user = SSTPLocalUser(
                        username=username,
                        password=user_data.get('password', ''),
                        static_ip=user_data.get('static-ip', ''),
                        disabled='disable' in user_data
                    )
                    sstp_config.local_users.append(local_user)
            
            if 'radius' in auth:
                radius = auth['radius']
                sstp_config.radius_source_address = radius.get('source-address', '')
                sstp_config.radius_nas_identifier = radius.get('nas-identifier', '')
                sstp_config.radius_nas_ip_address = radius.get('nas-ip-address', '')
                sstp_config.radius_timeout = int(radius.get('timeout', 0)) if radius.get('timeout') else None
                sstp_config.radius_acct_timeout = int(radius.get('acct-timeout', 0)) if radius.get('acct-timeout') else None
                sstp_config.radius_max_try = int(radius.get('max-try', 0)) if radius.get('max-try') else None
                
                if 'server' in radius:
                    for server_ip, server_data in radius['server'].items():
                        radius_server = SSTPRadiusServer(
                            address=server_ip,
                            port=int(server_data.get('port', 1812)) if server_data.get('port') else 1812,
                            acct_port=int(server_data.get('acct-port', 1813)) if server_data.get('acct-port') else None,
                            key=server_data.get('key', ''),
                            priority=int(server_data.get('priority', 1)) if server_data.get('priority') else 1,
                            disabled='disable' in server_data,
                            backup='backup' in server_data,
                            disable_accounting='disable-accounting' in server_data,
                            fail_time=int(server_data.get('fail-time', 0)) if server_data.get('fail-time') else None
                        )
                        sstp_config.radius_servers.append(radius_server)
        
        if 'ppp-options' in config:
            ppp = config['ppp-options']
            sstp_config.ppp_disable_ccp = 'disable-ccp' in ppp
            sstp_config.ppp_interface_cache = int(ppp.get('interface-cache', 0)) if ppp.get('interface-cache') else None
            sstp_config.ppp_ipv4 = ppp.get('ipv4', '')
            sstp_config.ppp_ipv6 = ppp.get('ipv6', '')
            sstp_config.ppp_ipv6_accept_peer_interface_id = 'ipv6-accept-peer-interface-id' in ppp
            sstp_config.ppp_ipv6_interface_id = ppp.get('ipv6-interface-id', '')
            sstp_config.ppp_ipv6_peer_interface_id = ppp.get('ipv6-peer-interface-id', '')
            sstp_config.ppp_lcp_echo_failure = int(ppp.get('lcp-echo-failure', 0)) if ppp.get('lcp-echo-failure') else None
            sstp_config.ppp_lcp_echo_interval = int(ppp.get('lcp-echo-interval', 0)) if ppp.get('lcp-echo-interval') else None
            sstp_config.ppp_lcp_echo_timeout = int(ppp.get('lcp-echo-timeout', 0)) if ppp.get('lcp-echo-timeout') else None
            sstp_config.ppp_min_mtu = int(ppp.get('min-mtu', 0)) if ppp.get('min-mtu') else None
            sstp_config.ppp_mppe = ppp.get('mppe', '')
            sstp_config.ppp_mru = int(ppp.get('mru', 0)) if ppp.get('mru') else None
        
        if 'client-ip-pool' in config:
            for pool_name, pool_data in config['client-ip-pool'].items():
                ip_pool = SSTPIPPool(
                    name=pool_name,
                    range=pool_data.get('range', '')
                )
                sstp_config.ip_pools.append(ip_pool)
        
        if 'client-ipv6-pool' in config:
            for pool_name, pool_data in config['client-ipv6-pool'].items():
                if 'prefix' in pool_data:
                    if isinstance(pool_data['prefix'], dict):
                        prefixes = ','.join(pool_data['prefix'].keys())
                    else:
                        prefixes = pool_data['prefix']
                    
                    ipv6_pool = SSTPIPv6Pool(
                        name=pool_name,
                        prefix=prefixes
                    )
                    sstp_config.ipv6_pools.append(ipv6_pool)
        
        db.session.add(sstp_config)
        db.session.commit()

    def serialize(self):
        result = {}
        
        if self.description:
            result['description'] = self.description
        if self.default_pool:
            result['default-pool'] = self.default_pool
        if self.default_ipv6_pool:
            result['default-ipv6-pool'] = self.default_ipv6_pool
        if self.gateway_address:
            result['gateway-address'] = self.gateway_address
        if self.host_name:
            result['host-name'] = self.host_name
        if self.port:
            result['port'] = str(self.port)
        if self.mtu:
            result['mtu'] = str(self.mtu)
        
        if self.log_level is not None:
            result['log'] = {'level': str(self.log_level)}
        
        # SSL Configuration
        if self.ssl_ca_certificate or self.ssl_certificate:
            ssl = {}
            if self.ssl_ca_certificate:
                ssl['ca-certificate'] = self.ssl_ca_certificate
            if self.ssl_certificate:
                ssl['certificate'] = self.ssl_certificate
            result['ssl'] = ssl
        
        if self.name_servers:
            result['name-server'] = self.name_servers.split(',') if ',' in self.name_servers else self.name_servers
        
        if self.wins_servers:
            result['wins-server'] = self.wins_servers.split(',') if ',' in self.wins_servers else self.wins_servers
        
        auth = {}
        if self.auth_mode:
            auth['mode'] = self.auth_mode
        if self.auth_protocols:
            auth['protocols'] = self.auth_protocols.split(',') if ',' in self.auth_protocols else [self.auth_protocols]
        
        if self.local_users:
            auth['local-users'] = {'username': {}}
            for user in self.local_users:
                auth['local-users']['username'][user.username] = user.serialize()
        
        if self.radius_servers or self.radius_source_address or self.radius_nas_identifier:
            radius = {}
            if self.radius_source_address:
                radius['source-address'] = self.radius_source_address
            if self.radius_nas_identifier:
                radius['nas-identifier'] = self.radius_nas_identifier
            if self.radius_nas_ip_address:
                radius['nas-ip-address'] = self.radius_nas_ip_address
            if self.radius_timeout is not None:
                radius['timeout'] = str(self.radius_timeout)
            if self.radius_acct_timeout is not None:
                radius['acct-timeout'] = str(self.radius_acct_timeout)
            if self.radius_max_try is not None:
                radius['max-try'] = str(self.radius_max_try)
            
            if self.radius_servers:
                radius['server'] = {}
                for server in self.radius_servers:
                    radius['server'][server.address] = server.serialize()
            
            auth['radius'] = radius
        
        if auth:
            result['authentication'] = auth
        
        ppp = {}
        if self.ppp_disable_ccp:
            ppp['disable-ccp'] = {}
        if self.ppp_interface_cache is not None:
            ppp['interface-cache'] = str(self.ppp_interface_cache)
        if self.ppp_ipv4:
            ppp['ipv4'] = self.ppp_ipv4
        if self.ppp_ipv6:
            ppp['ipv6'] = self.ppp_ipv6
        if self.ppp_ipv6_accept_peer_interface_id:
            ppp['ipv6-accept-peer-interface-id'] = {}
        if self.ppp_ipv6_interface_id:
            ppp['ipv6-interface-id'] = self.ppp_ipv6_interface_id
        if self.ppp_ipv6_peer_interface_id:
            ppp['ipv6-peer-interface-id'] = self.ppp_ipv6_peer_interface_id
        if self.ppp_lcp_echo_failure is not None:
            ppp['lcp-echo-failure'] = str(self.ppp_lcp_echo_failure)
        if self.ppp_lcp_echo_interval is not None:
            ppp['lcp-echo-interval'] = str(self.ppp_lcp_echo_interval)
        if self.ppp_lcp_echo_timeout is not None:
            ppp['lcp-echo-timeout'] = str(self.ppp_lcp_echo_timeout)
        if self.ppp_min_mtu is not None:
            ppp['min-mtu'] = str(self.ppp_min_mtu)
        if self.ppp_mppe:
            ppp['mppe'] = self.ppp_mppe
        if self.ppp_mru is not None:
            ppp['mru'] = str(self.ppp_mru)
        
        if ppp:
            result['ppp-options'] = ppp
        
        if self.ip_pools:
            result['client-ip-pool'] = {}
            for pool in self.ip_pools:
                result['client-ip-pool'][pool.name] = pool.serialize()
        
        if self.ipv6_pools:
            result['client-ipv6-pool'] = {}
            for pool in self.ipv6_pools:
                result['client-ipv6-pool'][pool.name] = pool.serialize()
        
        return result


class SSTPLocalUser(db.Model):
    __tablename__ = 'vyos_config_sstp_local_user'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_sstp.id'), nullable=False)
    username = Column(String(100), nullable=False)
    password = Column(String(255))
    static_ip = Column(String(50))
    disabled = Column(Boolean, default=False)
    
    config = relationship('SSTPConfig', back_populates='local_users')

    def serialize(self):
        result = {}
        if self.password:
            result['password'] = self.password
        if self.static_ip:
            result['static-ip'] = self.static_ip
        if self.disabled:
            result['disable'] = {}
        return result


class SSTPRadiusServer(db.Model):
    __tablename__ = 'vyos_config_sstp_radius_server'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_sstp.id'), nullable=False)
    address = Column(String(50), nullable=False)
    port = Column(Integer, default=1812)
    acct_port = Column(Integer)
    key = Column(String(255))
    priority = Column(Integer, default=1)
    disabled = Column(Boolean, default=False)
    backup = Column(Boolean, default=False)
    disable_accounting = Column(Boolean, default=False)
    fail_time = Column(Integer)
    
    config = relationship('SSTPConfig', back_populates='radius_servers')

    def serialize(self):
        result = {}
        if self.port:
            result['port'] = str(self.port)
        if self.acct_port:
            result['acct-port'] = str(self.acct_port)
        if self.key:
            result['key'] = self.key
        if self.priority:
            result['priority'] = str(self.priority)
        if self.disabled:
            result['disable'] = {}
        if self.backup:
            result['backup'] = {}
        if self.disable_accounting:
            result['disable-accounting'] = {}
        if self.fail_time:
            result['fail-time'] = str(self.fail_time)
        return result


class SSTPIPPool(db.Model):
    __tablename__ = 'vyos_config_sstp_ip_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_sstp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    range = Column(String(100))
    
    config = relationship('SSTPConfig', back_populates='ip_pools')

    def serialize(self):
        result = {}
        if self.range:
            result['range'] = self.range
        return result


class SSTPIPv6Pool(db.Model):
    __tablename__ = 'vyos_config_sstp_ipv6_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_sstp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    prefix = Column(Text)
    
    config = relationship('SSTPConfig', back_populates='ipv6_pools')

    def serialize(self):
        result = {}
        if self.prefix:
            prefixes = self.prefix.split(',') if ',' in self.prefix else [self.prefix]
            result['prefix'] = {p: {} for p in prefixes}
        return result
