from pydantic import BaseModel
from typing import Optional, List
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship


class L2TPGeneralDTO(BaseModel):
    description: Optional[str] = ''
    defaultIPPool: Optional[str] = ''
    defaultIPv6Pool: Optional[str] = ''
    gatewayAddress: Optional[str] = ''
    outsideAddress: Optional[str] = ''


class L2TPPPDTO(BaseModel):
    controlProtocol: Optional[bool] = None
    interfaceCaching: Optional[int] = None
    IPv4Negotiation: Optional[str] = None
    IPv6Negotiation: Optional[str] = None
    acceptPeerInterfaceID: Optional[bool] = None
    IPv6InterfaceID: Optional[str] = None
    IPv6PeerInterface: Optional[str] = None
    LCPEchoFailure: Optional[int] = None
    LCPEchoInterval: Optional[int] = None
    LCPEchoTimeout: Optional[int] = None
    minMTU: Optional[int] = None
    MPPE: Optional[str] = None
    MRU: Optional[int] = None


class L2TPAdvancedDTO(BaseModel):
    MTU: Optional[int] = None
    nameServers: Optional[List[str]] = []
    log: Optional[int] = 3
    WINS: Optional[List[str]] = []
    PPP: Optional[L2TPPPDTO] = None


class L2TPIPSecAuthenticationDTO(BaseModel):
    mode: Optional[str] = ''
    preSharedSecret: Optional[str] = ''
    x509CaCertificate: Optional[str] = ''
    x509Certificate: Optional[str] = ''
    x509Passphrase: Optional[str] = ''


class L2TPIPSecSettingsDTO(BaseModel):
    espGroup: Optional[str] = ''
    ikeGroup: Optional[str] = ''
    lifetime: Optional[int] = None
    authentication: Optional[L2TPIPSecAuthenticationDTO] = None


class L2TPLNSDTO(BaseModel):
    hostName: Optional[str] = ''
    sharedSecret: Optional[str] = ''


class L2TPClientIPPoolDTO(BaseModel):
    name: Optional[str] = ''
    subnet: Optional[str] = ''


class L2TPClientIPPoolsDTO(BaseModel):
    pools: Optional[List[L2TPClientIPPoolDTO]] = []


class L2TPClientIPv6PoolDTO(BaseModel):
    name: Optional[str] = ''
    prefix: Optional[str] = ''


class L2TPClientIPv6PoolsDTO(BaseModel):
    IPv6Pools: Optional[List[L2TPClientIPv6PoolDTO]] = []


class L2TPConnectionDTO(BaseModel):
    general: Optional[L2TPGeneralDTO] = None
    advanced: Optional[L2TPAdvancedDTO] = None
    ipsecSettings: Optional[L2TPIPSecSettingsDTO] = None
    lns: Optional[L2TPLNSDTO] = None
    clientIPPools: Optional[L2TPClientIPPoolsDTO] = None
    clientIPv6Pools: Optional[L2TPClientIPv6PoolsDTO] = None


class L2TPLocalUserDTO(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = ''
    staticIP: Optional[str] = ''
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True


class L2TPLocalUsersDTO(BaseModel):
    users: Optional[List[L2TPLocalUserDTO]] = []


class L2TPRadiusServerDTO(BaseModel):
    address: Optional[str] = ''
    port: Optional[int] = 1812
    key: Optional[str] = None
    secret: Optional[str] = None
    priority: Optional[int] = 1
    accountingPort: Optional[int] = 1813
    failTimePenalty: Optional[int] = 0
    disableAccounting: Optional[bool] = False
    backup: Optional[bool] = False
    disabled: Optional[bool] = False
    enabled: Optional[bool] = True


class L2TPRadiusOptionsDTO(BaseModel):
    sourceAddress: Optional[str] = None
    NASIdentifier: Optional[str] = None
    NASIPAddress: Optional[str] = None
    timeout: Optional[int] = None
    maxTry: Optional[int] = None


class L2TPRadiusDTO(BaseModel):
    servers: Optional[List[L2TPRadiusServerDTO]] = []
    options: Optional[L2TPRadiusOptionsDTO] = None


class L2TPSecurityDTO(BaseModel):
    mode: Optional[str] = 'local'
    protocol: Optional[List[str]] = []
    localUsers: Optional[L2TPLocalUsersDTO] = None
    radius: Optional[L2TPRadiusDTO] = None


class UpdateL2TPDTO(BaseModel):
    connection: Optional[L2TPConnectionDTO] = None
    security: Optional[L2TPSecurityDTO] = None


class L2TPConfig(db.Model):
    __tablename__ = 'vyos_config_l2tp'
    
    id = Column(Integer, primary_key=True)
    description = Column(String(255))
    default_pool = Column(String(100))
    default_ipv6_pool = Column(String(100))
    gateway_address = Column(String(50))
    outside_address = Column(String(50))
    mtu = Column(Integer)
    log_level = Column(Integer)
    name_servers = Column(Text)
    wins_servers = Column(Text)
    
    auth_mode = Column(String(50))
    auth_protocols = Column(String(255))
    
    radius_source_address = Column(String(50))
    radius_nas_identifier = Column(String(255))
    radius_nas_ip_address = Column(String(50))
    radius_timeout = Column(Integer)
    radius_max_try = Column(Integer)
    
    ipsec_esp_group = Column(String(100))
    ipsec_ike_group = Column(String(100))
    ipsec_lifetime = Column(Integer)
    ipsec_auth_mode = Column(String(50))
    ipsec_pre_shared_secret = Column(String(255))
    ipsec_x509_ca_certificate = Column(String(255))
    ipsec_x509_certificate = Column(String(255))
    ipsec_x509_passphrase = Column(String(255))
    
    lns_host_name = Column(String(255))
    lns_shared_secret = Column(String(255))
    
    ppp_disable_ccp = Column(Boolean, default=False)
    ppp_interface_cache = Column(Integer)
    ppp_ipv4 = Column(String(50))
    ppp_ipv6 = Column(String(50))
    ppp_ipv6_accept_peer_interface_id = Column(Boolean, default=False)
    ppp_ipv6_interface_id = Column(String(100))
    ppp_ipv6_peer_interface_id = Column(String(100))
    ppp_lcp_echo_failure = Column(Integer)
    ppp_lcp_echo_interval = Column(Integer)
    ppp_lcp_echo_timeout = Column(Integer)
    ppp_min_mtu = Column(Integer)
    ppp_mppe = Column(String(50))
    ppp_mru = Column(Integer)
    
    local_users = relationship('L2TPLocalUser', back_populates='config', cascade='all, delete-orphan')
    radius_servers = relationship('L2TPRadiusServer', back_populates='config', cascade='all, delete-orphan')
    ip_pools = relationship('L2TPIPPool', back_populates='config', cascade='all, delete-orphan')
    ipv6_pools = relationship('L2TPIPv6Pool', back_populates='config', cascade='all, delete-orphan')

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        tables = [
            'vyos_config_l2tp_ipv6_pool',
            'vyos_config_l2tp_ip_pool',
            'vyos_config_l2tp_radius_server',
            'vyos_config_l2tp_local_user',
            'vyos_config_l2tp'
        ]
        for table in tables:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config):
        if 'remote-access' in config:
            config = config['remote-access']
        
        cls.truncate()
        
        if not config:
            return
        
        l2tp_config = cls()
        
        l2tp_config.description = config.get('description', '')
        l2tp_config.default_pool = config.get('default-pool', '')
        l2tp_config.default_ipv6_pool = config.get('default-ipv6-pool', '')
        l2tp_config.gateway_address = config.get('gateway-address', '')
        l2tp_config.outside_address = config.get('outside-address', '')
        l2tp_config.mtu = int(config.get('mtu', 0)) if config.get('mtu') else None
        
        if 'log' in config and 'level' in config['log']:
            l2tp_config.log_level = int(config['log']['level'])
        
        if isinstance(config.get('name-server'), list):
            l2tp_config.name_servers = ','.join(config['name-server'])
        elif config.get('name-server'):
            l2tp_config.name_servers = config['name-server']
        
        if isinstance(config.get('wins-server'), list):
            l2tp_config.wins_servers = ','.join(config['wins-server'])
        elif config.get('wins-server'):
            l2tp_config.wins_servers = config['wins-server']
        
        if 'ipsec-settings' in config:
            ipsec = config['ipsec-settings']
            l2tp_config.ipsec_esp_group = ipsec.get('esp-group', '')
            l2tp_config.ipsec_ike_group = ipsec.get('ike-group', '')
            l2tp_config.ipsec_lifetime = int(ipsec.get('lifetime', 0)) if ipsec.get('lifetime') else None
            
            if 'authentication' in ipsec:
                ipsec_auth = ipsec['authentication']
                l2tp_config.ipsec_auth_mode = ipsec_auth.get('mode', '')
                l2tp_config.ipsec_pre_shared_secret = ipsec_auth.get('pre-shared-secret', '')
                
                if 'x509' in ipsec_auth:
                    x509 = ipsec_auth['x509']
                    l2tp_config.ipsec_x509_ca_certificate = x509.get('ca-certificate', '')
                    l2tp_config.ipsec_x509_certificate = x509.get('certificate', '')
                    l2tp_config.ipsec_x509_passphrase = x509.get('passphrase', '')
        
        if 'lns' in config:
            lns = config['lns']
            l2tp_config.lns_host_name = lns.get('host-name', '')
            l2tp_config.lns_shared_secret = lns.get('shared-secret', '')
        
        if 'authentication' in config:
            auth = config['authentication']
            l2tp_config.auth_mode = auth.get('mode', '')
            
            if 'protocols' in auth:
                if isinstance(auth['protocols'], list):
                    l2tp_config.auth_protocols = ','.join(auth['protocols'])
                else:
                    l2tp_config.auth_protocols = auth['protocols']
            
            if 'local-users' in auth and 'username' in auth['local-users']:
                for username, user_data in auth['local-users']['username'].items():
                    local_user = L2TPLocalUser(
                        username=username,
                        password=user_data.get('password', ''),
                        static_ip=user_data.get('static-ip', ''),
                        disabled='disable' in user_data
                    )
                    l2tp_config.local_users.append(local_user)
            
            if 'radius' in auth:
                radius = auth['radius']
                l2tp_config.radius_source_address = radius.get('source-address', '')
                l2tp_config.radius_nas_identifier = radius.get('nas-identifier', '')
                l2tp_config.radius_nas_ip_address = radius.get('nas-ip-address', '')
                l2tp_config.radius_timeout = int(radius.get('timeout', 0)) if radius.get('timeout') else None
                l2tp_config.radius_max_try = int(radius.get('max-try', 0)) if radius.get('max-try') else None
                
                if 'server' in radius:
                    for server_ip, server_data in radius['server'].items():
                        radius_server = L2TPRadiusServer(
                            address=server_ip,
                            port=int(server_data.get('port', 1812)) if server_data.get('port') else 1812,
                            acct_port=int(server_data.get('acct-port', 1813)) if server_data.get('acct-port') else None,
                            key=server_data.get('key', ''),
                            priority=int(server_data.get('priority', 1)) if server_data.get('priority') else 1,
                            disabled='disable' in server_data,
                            backup='backup' in server_data,
                            disable_accounting='disable-accounting' in server_data,
                            fail_time=int(server_data.get('fail-time', 0)) if server_data.get('fail-time') else None
                        )
                        l2tp_config.radius_servers.append(radius_server)
        
        if 'ppp-options' in config:
            ppp = config['ppp-options']
            l2tp_config.ppp_disable_ccp = 'disable-ccp' in ppp
            l2tp_config.ppp_interface_cache = int(ppp.get('interface-cache', 0)) if ppp.get('interface-cache') else None
            l2tp_config.ppp_ipv4 = ppp.get('ipv4', '')
            l2tp_config.ppp_ipv6 = ppp.get('ipv6', '')
            l2tp_config.ppp_ipv6_accept_peer_interface_id = 'ipv6-accept-peer-interface-id' in ppp
            l2tp_config.ppp_ipv6_interface_id = ppp.get('ipv6-interface-id', '')
            l2tp_config.ppp_ipv6_peer_interface_id = ppp.get('ipv6-peer-interface-id', '')
            l2tp_config.ppp_lcp_echo_failure = int(ppp.get('lcp-echo-failure', 0)) if ppp.get('lcp-echo-failure') else None
            l2tp_config.ppp_lcp_echo_interval = int(ppp.get('lcp-echo-interval', 0)) if ppp.get('lcp-echo-interval') else None
            l2tp_config.ppp_lcp_echo_timeout = int(ppp.get('lcp-echo-timeout', 0)) if ppp.get('lcp-echo-timeout') else None
            l2tp_config.ppp_min_mtu = int(ppp.get('min-mtu', 0)) if ppp.get('min-mtu') else None
            l2tp_config.ppp_mppe = ppp.get('mppe', '')
            l2tp_config.ppp_mru = int(ppp.get('mru', 0)) if ppp.get('mru') else None
        
        if 'client-ip-pool' in config:
            for pool_name, pool_data in config['client-ip-pool'].items():
                ip_pool = L2TPIPPool(
                    name=pool_name,
                    range=pool_data.get('range', '')
                )
                l2tp_config.ip_pools.append(ip_pool)
        
        if 'client-ipv6-pool' in config:
            for pool_name, pool_data in config['client-ipv6-pool'].items():
                if 'prefix' in pool_data:
                    if isinstance(pool_data['prefix'], dict):
                        prefixes = ','.join(pool_data['prefix'].keys())
                    else:
                        prefixes = pool_data['prefix']
                    
                    ipv6_pool = L2TPIPv6Pool(
                        name=pool_name,
                        prefix=prefixes
                    )
                    l2tp_config.ipv6_pools.append(ipv6_pool)
        
        db.session.add(l2tp_config)
        db.session.commit()

    def serialize(self):
        result = {}
        
        if self.description:
            result['description'] = self.description
        if self.default_pool:
            result['default-pool'] = self.default_pool
        if self.default_ipv6_pool:
            result['default-ipv6-pool'] = self.default_ipv6_pool
        if self.gateway_address:
            result['gateway-address'] = self.gateway_address
        if self.outside_address:
            result['outside-address'] = self.outside_address
        if self.mtu:
            result['mtu'] = str(self.mtu)
        
        if self.log_level is not None:
            result['log'] = {'level': str(self.log_level)}
        
        if self.name_servers:
            servers = self.name_servers.split(',')
            result['name-server'] = servers if len(servers) > 1 else servers[0]
        
        if self.wins_servers:
            servers = self.wins_servers.split(',')
            result['wins-server'] = servers if len(servers) > 1 else servers[0]
        
        if self.ipsec_esp_group or self.ipsec_ike_group or self.ipsec_lifetime or self.ipsec_auth_mode:
            ipsec = {}
            if self.ipsec_esp_group:
                ipsec['esp-group'] = self.ipsec_esp_group
            if self.ipsec_ike_group:
                ipsec['ike-group'] = self.ipsec_ike_group
            if self.ipsec_lifetime:
                ipsec['lifetime'] = str(self.ipsec_lifetime)
            
            if self.ipsec_auth_mode:
                ipsec_auth = {'mode': self.ipsec_auth_mode}
                if self.ipsec_pre_shared_secret:
                    ipsec_auth['pre-shared-secret'] = self.ipsec_pre_shared_secret
                
                if self.ipsec_x509_ca_certificate or self.ipsec_x509_certificate or self.ipsec_x509_passphrase:
                    x509 = {}
                    if self.ipsec_x509_ca_certificate:
                        x509['ca-certificate'] = self.ipsec_x509_ca_certificate
                    if self.ipsec_x509_certificate:
                        x509['certificate'] = self.ipsec_x509_certificate
                    if self.ipsec_x509_passphrase:
                        x509['passphrase'] = self.ipsec_x509_passphrase
                    ipsec_auth['x509'] = x509
                
                ipsec['authentication'] = ipsec_auth
            
            result['ipsec-settings'] = ipsec
        
        if self.lns_host_name or self.lns_shared_secret:
            lns = {}
            if self.lns_host_name:
                lns['host-name'] = self.lns_host_name
            if self.lns_shared_secret:
                lns['shared-secret'] = self.lns_shared_secret
            result['lns'] = lns
        
        auth = {}
        if self.auth_mode:
            auth['mode'] = self.auth_mode
        
        if self.auth_protocols:
            protocols = self.auth_protocols.split(',')
            auth['protocols'] = protocols
        
        if self.local_users:
            auth['local-users'] = {'username': {}}
            for user in self.local_users:
                auth['local-users']['username'][user.username] = user.serialize()
        
        if self.radius_servers or self.radius_source_address or self.radius_nas_identifier:
            radius = {}
            if self.radius_source_address:
                radius['source-address'] = self.radius_source_address
            if self.radius_nas_identifier:
                radius['nas-identifier'] = self.radius_nas_identifier
            if self.radius_nas_ip_address:
                radius['nas-ip-address'] = self.radius_nas_ip_address
            if self.radius_timeout:
                radius['timeout'] = str(self.radius_timeout)
            if self.radius_max_try:
                radius['max-try'] = str(self.radius_max_try)
            
            if self.radius_servers:
                radius['server'] = {}
                for server in self.radius_servers:
                    radius['server'][server.address] = server.serialize()
            
            auth['radius'] = radius
        
        if auth:
            result['authentication'] = auth
        
        ppp = {}
        if self.ppp_disable_ccp:
            ppp['disable-ccp'] = {}
        if self.ppp_interface_cache is not None:
            ppp['interface-cache'] = str(self.ppp_interface_cache)
        if self.ppp_ipv4:
            ppp['ipv4'] = self.ppp_ipv4
        if self.ppp_ipv6:
            ppp['ipv6'] = self.ppp_ipv6
        if self.ppp_ipv6_accept_peer_interface_id:
            ppp['ipv6-accept-peer-interface-id'] = {}
        if self.ppp_ipv6_interface_id:
            ppp['ipv6-interface-id'] = self.ppp_ipv6_interface_id
        if self.ppp_ipv6_peer_interface_id:
            ppp['ipv6-peer-interface-id'] = self.ppp_ipv6_peer_interface_id
        if self.ppp_lcp_echo_failure is not None:
            ppp['lcp-echo-failure'] = str(self.ppp_lcp_echo_failure)
        if self.ppp_lcp_echo_interval is not None:
            ppp['lcp-echo-interval'] = str(self.ppp_lcp_echo_interval)
        if self.ppp_lcp_echo_timeout is not None:
            ppp['lcp-echo-timeout'] = str(self.ppp_lcp_echo_timeout)
        if self.ppp_min_mtu is not None:
            ppp['min-mtu'] = str(self.ppp_min_mtu)
        if self.ppp_mppe:
            ppp['mppe'] = self.ppp_mppe
        if self.ppp_mru is not None:
            ppp['mru'] = str(self.ppp_mru)
        
        if ppp:
            result['ppp-options'] = ppp
        
        if self.ip_pools:
            result['client-ip-pool'] = {}
            for pool in self.ip_pools:
                result['client-ip-pool'][pool.name] = pool.serialize()
        
        if self.ipv6_pools:
            result['client-ipv6-pool'] = {}
            for pool in self.ipv6_pools:
                result['client-ipv6-pool'][pool.name] = pool.serialize()
        
        return result


class L2TPLocalUser(db.Model):
    __tablename__ = 'vyos_config_l2tp_local_user'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_l2tp.id'), nullable=False)
    username = Column(String(100), nullable=False)
    password = Column(String(255))
    static_ip = Column(String(50))
    disabled = Column(Boolean, default=False)
    
    config = relationship('L2TPConfig', back_populates='local_users')

    def serialize(self):
        result = {}
        if self.password:
            result['password'] = self.password
        if self.static_ip:
            result['static-ip'] = self.static_ip
        if self.disabled:
            result['disable'] = {}
        return result


class L2TPRadiusServer(db.Model):
    __tablename__ = 'vyos_config_l2tp_radius_server'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_l2tp.id'), nullable=False)
    address = Column(String(50), nullable=False)
    port = Column(Integer, default=1812)
    acct_port = Column(Integer)
    key = Column(String(255))
    priority = Column(Integer, default=1)
    disabled = Column(Boolean, default=False)
    backup = Column(Boolean, default=False)
    disable_accounting = Column(Boolean, default=False)
    fail_time = Column(Integer)
    
    config = relationship('L2TPConfig', back_populates='radius_servers')

    def serialize(self):
        result = {}
        if self.port:
            result['port'] = str(self.port)
        if self.acct_port:
            result['acct-port'] = str(self.acct_port)
        if self.key:
            result['key'] = self.key
        if self.priority:
            result['priority'] = str(self.priority)
        if self.disabled:
            result['disable'] = {}
        if self.backup:
            result['backup'] = {}
        if self.disable_accounting:
            result['disable-accounting'] = {}
        if self.fail_time:
            result['fail-time'] = str(self.fail_time)
        return result


class L2TPIPPool(db.Model):
    __tablename__ = 'vyos_config_l2tp_ip_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_l2tp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    range = Column(String(100))
    
    config = relationship('L2TPConfig', back_populates='ip_pools')

    def serialize(self):
        result = {}
        if self.range:
            result['range'] = self.range
        return result


class L2TPIPv6Pool(db.Model):
    __tablename__ = 'vyos_config_l2tp_ipv6_pool'
    
    id = Column(Integer, primary_key=True)
    config_id = Column(Integer, ForeignKey('vyos_config_l2tp.id'), nullable=False)
    name = Column(String(100), nullable=False)
    prefix = Column(Text)
    
    config = relationship('L2TPConfig', back_populates='ipv6_pools')

    def serialize(self):
        result = {}
        if self.prefix:
            prefixes = self.prefix.split(',') if ',' in self.prefix else [self.prefix]
            result['prefix'] = {p: {} for p in prefixes}
        return result
