from flask import Blueprint

vyos_ha_bp = Blueprint('high-availability', __name__)

from . import routes