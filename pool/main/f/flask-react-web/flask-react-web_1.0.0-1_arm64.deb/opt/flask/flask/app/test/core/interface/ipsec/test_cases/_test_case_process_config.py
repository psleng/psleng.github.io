import pytest

test_set = [
    pytest.param(
        {
            "current_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            }
                        }
                    }
                }
            },
            "set_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            },
                            "ike-group": "ike-group-1"
                        }
                    }
                }
            },
            "expected_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            },
                            "ike-group": "ike-group-1"
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_1"
    ),
    pytest.param(
        {
            "current_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "key-exchange": "ikev2"
                    }
                }
            },
            "set_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "key-exchange": "ikev2",
                        "lifetime": "28800",
                        "proposal": {
                            "1": {
                                "dh-group": "14"
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "key-exchange": "ikev2",
                        "lifetime": "28800",
                        "proposal": {
                            "1": {
                                "dh-group": "14"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_ike_group"
    ),
    pytest.param(
        {
            "current_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "ike-group": "ike-grp-1"
                        }
                    }
                }
            },
            "set_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "ike-group": "ike-grp-1",
                            "esp-group": "esp-grp-1",
                            "pool": ["pool-1"]
                        }
                    }
                }
            },
            "expected_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "ike-group": "ike-grp-1",
                            "esp-group": "esp-grp-1",
                            "pool": ["pool-1"]
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_remote_access"
    ),
    pytest.param(
        {
            "current_config": {},
            "set_config": {
                "authentication": {
                    "psk": {
                        "psk-1": {
                            "id": "id-1",
                            "secret": "secret-1"
                        }
                    }
                }
            },
            "expected_config": {
                "authentication": {
                    "psk": {
                        "psk-1": {
                            "id": "id-1",
                            "secret": "secret-1"
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_psk"
    )
]

test_delete = [
    pytest.param(
        {
            "current_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            },
                            "ike-group": "ike-group-1"
                        }
                    }
                }
            },
            "delete_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "ike-group": {}
                        }
                    }
                }
            },
            "expected_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_delete_1"
    ),
    pytest.param(
        {
            "current_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "tunnel": {
                                "1": {
                                    "esp-group": "esp-grp-1"
                                },
                                "2": {
                                    "esp-group": "esp-grp-2"
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "tunnel": {
                                "2": {}
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "tunnel": {
                                "1": {
                                    "esp-group": "esp-grp-1"
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_delete_tunnel"
    ),
    pytest.param(
        {
            "current_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "proposal": {
                            "1": {
                                "dh-group": "14"
                            },
                            "2": {
                                "dh-group": "15"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "proposal": {
                            "2": {}
                        }
                    }
                }
            },
            "expected_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "proposal": {
                            "1": {
                                "dh-group": "14"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_delete_ike_proposal"
    ),
    pytest.param(
        {
            "current_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "authentication": {
                                "local-users": {
                                    "username": {
                                        "user1": {
                                            "password": "pass1"
                                        },
                                        "user2": {
                                            "password": "pass2"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "authentication": {
                                "local-users": {
                                    "username": {
                                        "user2": {}
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "remote-access": {
                    "connection": {
                        "conn-1": {
                            "authentication": {
                                "local-users": {
                                    "username": {
                                        "user1": {
                                            "password": "pass1"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_delete_local_user"
    )
]

test_set_delete = [
    pytest.param(
        {
            "current_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            }
                        }
                    }
                }
            },
            "set_config": {
                "site-to-site": {
                    "peer": {
                        "peer-2": {
                            "authentication": {
                                "mode": "x509"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {}
                    }
                }
            },
            "expected_config": {
                "site-to-site": {
                    "peer": {
                        "peer-2": {
                            "authentication": {
                                "mode": "x509"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_delete_1"
    ),
    pytest.param(
        {
            "current_config": {
                "ike-group": {
                    "ike-grp-1": {
                        "key-exchange": "ikev1"
                    }
                },
                "esp-group": {
                    "esp-grp-1": {
                        "mode": "tunnel"
                    }
                }
            },
            "set_config": {
                "ike-group": {
                    "ike-grp-2": {
                        "key-exchange": "ikev2"
                    }
                },
                "esp-group": {
                    "esp-grp-2": {
                        "mode": "transport"
                    }
                }
            },
            "delete_config": {
                "ike-group": {
                    "ike-grp-1": {}
                },
                "esp-group": {
                    "esp-grp-1": {}
                }
            },
            "expected_config": {
                "ike-group": {
                    "ike-grp-2": {
                        "key-exchange": "ikev2"
                    }
                },
                "esp-group": {
                    "esp-grp-2": {
                        "mode": "transport"
                    }
                }
            }
        },
        id="test_process_ipsec_set_delete_security_groups"
    ),
    pytest.param(
        {
            "current_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "pre-shared-secret"
                            },
                            "tunnel": {
                                "1": {
                                    "esp-group": "esp-grp-1"
                                }
                            }
                        }
                    }
                }
            },
            "set_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "x509"
                            },
                            "tunnel": {
                                "2": {
                                    "esp-group": "esp-grp-2"
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "tunnel": {
                                "1": {}
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "site-to-site": {
                    "peer": {
                        "peer-1": {
                            "authentication": {
                                "mode": "x509"
                            },
                            "tunnel": {
                                "2": {
                                    "esp-group": "esp-grp-2"
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_process_ipsec_set_delete_peer_tunnels"
    )
]
