
import hashlib
import hmac
import json
import os
import time

from flask import jsonify, request

from . import callback_bp
from app.core.system.event_handler.models import AlarmCallbackEvent
from app.log.logger import logger
from app.socket.socket_manager import socket_manager

CALLBACK_LOG_PATH = '/var/log/flask-react-web/callback.log'
CALLBACK_MAX_AGE_SECONDS = 300


def is_valid_signature(timestamp: str, signature: str) -> bool:
    if timestamp == '' or signature == '':
        return False

    try:
        callback_time = int(timestamp)
    except ValueError:
        return False
    if abs(int(time.time()) - callback_time) > CALLBACK_MAX_AGE_SECONDS:
        return False

    secret = os.environ.get('CALLBACK_SECRET', 'secret').encode()
    expected_signature = hmac.new(secret, timestamp.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected_signature, signature)


@callback_bp.route('', methods=['GET'])
@callback_bp.route('/', methods=['GET'])
def callback_healthcheck():
    return jsonify({'success': True, 'message': 'Callback endpoint is available'})


def append_callback_log(payload):
    try:
        os.makedirs(os.path.dirname(CALLBACK_LOG_PATH), exist_ok=True)
        with open(CALLBACK_LOG_PATH, 'a', encoding='utf-8') as log_file:
            log_file.write(json.dumps(payload, ensure_ascii=False) + '\n')
    except OSError as exc:
        logger.warning(f'Unable to append callback audit log: {exc}')


def save_callback_event(payload):
    return AlarmCallbackEvent.get_or_create_from_payload(payload)


def notify_all_users(callback_event: AlarmCallbackEvent):
    if callback_event.event != 'notify_users' or str(callback_event.message or '').strip() == '':
        return

    socket_manager.emit_to_all(
        event='notification',
        data=callback_event.serialize_notification(),
    )


def send_event_email(callback_event: AlarmCallbackEvent):
    message = str(callback_event.message or '')
    if message.strip() == '':
        return

    from app.core.api.api import API_ACTION, API_TARGET
    from app.core.api.manager import api_manager

    result = api_manager.call(
        action=API_ACTION.GENERATE,
        target=API_TARGET.EMAIL_TEST,
        data={'message': message},
    )
    if isinstance(result, Exception):
        raise result
    if not isinstance(result, dict) or result.get('success') is not True:
        raise RuntimeError(str(result))


@callback_bp.route('', methods=['POST'])
@callback_bp.route('/', methods=['POST'])
def handle_callback():
    timestamp = str(request.headers.get('X-Timestamp') or '')
    signature = str(request.headers.get('X-Signature') or '')

    if not is_valid_signature(timestamp, signature):
        return jsonify({'success': False, 'message': 'Invalid signature'}), 401

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({'success': False, 'message': 'JSON object payload is required'}), 400

    append_callback_log(payload)
    try:
        callback_event, created = save_callback_event(payload)
    except Exception as exc:
        logger.error(f'Callback event persistence failed: {exc}')
        return jsonify({'success': False, 'message': 'Event persistence failed'}), 503

    if created:
        try:
            notify_all_users(callback_event)
        except Exception as exc:
            logger.error(
                f'Notification broadcast failed for event id={callback_event.id}: {exc}'
            )
        if payload.get('email_enabled') is True:
            try:
                send_event_email(callback_event)
            except Exception as exc:
                logger.error(f'Email delivery failed for event id={callback_event.id}: {exc}')

    return jsonify({
        'success': True,
        'created': created,
        'event': callback_event.serialize_notification(),
    })
