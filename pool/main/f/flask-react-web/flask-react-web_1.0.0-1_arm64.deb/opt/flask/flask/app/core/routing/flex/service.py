import pprint
from logging import getLogger, DEBUG
from flask import session

from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_FLEX_ROUTING, SHOW_FLEX_ROUTING_V6
from app.core.routing.flex.command_flexrouting import FlexRoutingCommand
from app.core.routing.flex.models import FlexRoutingConfig
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from uuid import uuid4
from app.log.logger import logger


def fetch_flex_routing(provider, data: dict):
    logger.info("Fetching flex routing configuration...")
    route_type = 'route6' if (data or {}).get('route_ver') == 'ipv6' else 'route'
    command = SHOW_FLEX_ROUTING_V6 if route_type == 'route6' else SHOW_FLEX_ROUTING
    resp = provider.http_service.send_request(action=Action.RETRIEVE, data=command, verify=False)
    cfg = resp.json().get('data')
    if not cfg:
        return {}
    if isinstance(cfg, dict) and ('route' in cfg or 'route6' in cfg):
        return cfg.get(route_type) or {}
    return cfg if isinstance(cfg, dict) else {}


def update_flex_routing(provider, data: dict):
    
    logger.info("Update Flex Routing:")
    logger.info(data)

    username = session.get('username', '')
    route_type = 'route6' if data.get('route_ver') == 'ipv6' else 'route'
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')

    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = FlexRoutingCommand(operator='set', resource='failover', route_type=route_type)
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = FlexRoutingCommand(operator='delete', resource='failover', route_type=route_type)
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "failover"
    curr_config = {}
    try:
        curr_config = provider.verify_service.call_get_config(service)
    except Exception as e:
        print("Error getting current flex routing config:")
        print(str(e))
        curr_config = {}

    current_raw_config = curr_config if curr_config else {}
    print("Current raw config:")
    print(pprint.pformat(current_raw_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(
        current_raw_config,
        new_delete_configs.get('protocols', {}).get('failover', {}),
        clean_empty=False
    )
    merged_config = merge_dicts_set(
        merged_del_config,
        new_set_configs.get('protocols', {}).get('failover', {})
    )

    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    try:
        if merged_config:
            verify = provider.verify_service.call_verify(service, merged_config)
    except Exception as e:
        print("Flex Routing verify skipped:")
        print(str(e))

    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]


    r = []
    if cmds:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
        if not res['success']:
            return r

    FlexRoutingConfig.refresh(config, route_type=route_type)
    if username:
        socket_manager.emit_to_user(
            username,
            event='notification',
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Flex Routing",
                "content": "Flex Routing is successfully updated"
            }
        )

    return r
