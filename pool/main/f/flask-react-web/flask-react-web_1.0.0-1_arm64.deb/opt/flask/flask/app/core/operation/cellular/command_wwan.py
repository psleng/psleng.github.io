import json

from app.core.api.http.cmd.command import Command
from app.core.operation.ip_options.command_ip_options import IPOptionCommand


def is_str_not_empty(value):
    return str(value) not in ['', 'None']


def format_description(description: str) -> str:
    return str(description)


class WWANCommand(Command):
    """
    Command class for WWAN interface configuration.

    Set/delete commands under:
    - interfaces wwan <intf-name>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'interfaces')
            )
            self.attributes = {
                'interfaces': {
                    'wwan': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []

            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing WWAN command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        return json.dumps({
            "op": self.operator,
            "path": list(path_elements),
        })

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _key(self, data, key):
        if not isinstance(data, dict):
            return None
        if key in data:
            return key
        normalized = key.replace('-', '_')
        if normalized in data:
            return normalized
        denormalized = key.replace('_', '-')
        if denormalized in data:
            return denormalized
        return None

    def _get(self, data, key, default=None):
        actual_key = self._key(data, key)
        if actual_key is None:
            return default
        return data[actual_key]

    def _has(self, data, key):
        return self._key(data, key) is not None

    def _is_value(self, value):
        return value is not None and not isinstance(value, dict) and is_str_not_empty(value)

    def _is_leaf_enabled(self, value):
        if self.operator == 'delete':
            return value is not None
        if isinstance(value, dict):
            return True
        if isinstance(value, bool):
            return value
        return value is not None and is_str_not_empty(value)

    def _iter_values(self, value):
        if value is None:
            return []
        if isinstance(value, list):
            return value
        if isinstance(value, dict):
            return list(value.keys())
        return [value]

    def _generate_value(self, base_path, config, key):
        value = self._get(config, key)
        if self._is_value(value):
            self.generate(*base_path, key, str(value))

    def _generate_leaf(self, base_path, config, key):
        if self._has(config, key) and self._is_leaf_enabled(self._get(config, key)):
            self.generate(*base_path, key)

    def _generate_multi(self, base_path, config, key, command_key=None):
        if not self._has(config, key):
            return

        for value in self._iter_values(self._get(config, key)):
            if is_str_not_empty(value):
                self.generate(*base_path, command_key or key, str(value))

    def _generate_signal_threshold(self, base_path, config):
        threshold = self._get(config, 'signal-threshold')
        if not isinstance(threshold, dict):
            return

        threshold_path = base_path + ['signal-threshold']
        if self._has(threshold, 'rssi'):
            self._generate_value(threshold_path, threshold, 'rssi')
        if self._has(threshold, 'rsrp'):
            self._generate_value(threshold_path, threshold, 'rsrp')

    def _generate_nested_config(self, base_path, config):
        if not isinstance(config, dict):
            return

        for key, value in config.items():
            path = base_path + [str(key)]
            if isinstance(value, dict):
                if value:
                    self._generate_nested_config(path, value)
                else:
                    self.generate(*path)
            elif isinstance(value, list):
                for item in value:
                    if is_str_not_empty(item):
                        self.generate(*path, str(item))
            elif self._is_value(value):
                self.generate(*path, str(value))

    def _extract_wwan_config(self, data):
        if not isinstance(data, dict):
            return {}

        interfaces = self._get(data, 'interfaces')
        if isinstance(interfaces, dict):
            wwan = self._get(interfaces, 'wwan')
            if isinstance(wwan, dict):
                return wwan

        wwan = self._get(data, 'wwan')
        if isinstance(wwan, dict):
            return wwan

        return data

    def _process_sim_slot_config(self, sim_base_path, sim_config):
        slot_config = self._get(sim_config, 'slot')
        if not isinstance(slot_config, dict):
            return

        for slot_num, slot_data in slot_config.items():
            slot_path = sim_base_path + ['slot', str(slot_num)]
            if not isinstance(slot_data, dict):
                slot_data = {}

            if self._has(slot_data, 'disable'):
                self._generate_leaf(slot_path, slot_data, 'disable')

            if self._has(slot_data, 'iccid'):
                self._generate_value(slot_path, slot_data, 'iccid')

            if self._has(slot_data, 'apn'):
                self._generate_value(slot_path, slot_data, 'apn')

            if self._has(slot_data, 'username'):
                self._generate_value(slot_path, slot_data, 'username')

            if self._has(slot_data, 'password'):
                self._generate_value(slot_path, slot_data, 'password')

            if self._has(slot_data, 'auth-type'):
                self._generate_value(slot_path, slot_data, 'auth-type')

            if self._has(slot_data, 'pdp-type'):
                self._generate_value(slot_path, slot_data, 'pdp-type')

            if self._has(slot_data, 'disable-roaming'):
                self._generate_leaf(slot_path, slot_data, 'disable-roaming')

            if self._has(slot_data, 'pin'):
                self._generate_value(slot_path, slot_data, 'pin')

            if self._has(slot_data, 'puk'):
                self._generate_value(slot_path, slot_data, 'puk')

            if self._has(slot_data, 'supported-bands'):
                self._generate_multi(slot_path, slot_data, 'supported-bands')

            if self._has(slot_data, 'preferred-carrier'):
                self._generate_value(slot_path, slot_data, 'preferred-carrier')

            if self._has(slot_data, 'enable-network-scan'):
                self._generate_leaf(slot_path, slot_data, 'enable-network-scan')

            if self._has(slot_data, 'mtu'):
                self._generate_value(slot_path, slot_data, 'mtu')

            if self._has(slot_data, 'warning'):
                self._generate_value(slot_path, slot_data, 'warning')

            data_limit = self._get(slot_data, 'data-limit')
            if isinstance(data_limit, dict):
                data_limit_path = slot_path + ['data-limit']
                if self._has(data_limit, 'size'):
                    self._generate_value(data_limit_path, data_limit, 'size')
                if self._has(data_limit, 'action'):
                    self._generate_value(data_limit_path, data_limit, 'action')
                if self._has(data_limit, 'billing-date'):
                    self._generate_value(data_limit_path, data_limit, 'billing-date')
                if self._has(data_limit, 'warning'):
                    self._generate_multi(data_limit_path, data_limit, 'warning')

    def _process_sim_failback_config(self, sim_base_path, sim_config):
        failback_config = self._get(sim_config, 'sim-failback')
        if not isinstance(failback_config, dict):
            return

        failback_path = sim_base_path + ['sim-failback']
        if self._has(failback_config, 'disable'):
            self._generate_leaf(failback_path, failback_config, 'disable')
        if self._has(failback_config, 'check-interval'):
            self._generate_value(failback_path, failback_config, 'check-interval')
        if self._has(failback_config, 'stability-time'):
            self._generate_value(failback_path, failback_config, 'stability-time')

    def _process_sim_failover_config(self, sim_base_path, sim_config):
        failover_config = self._get(sim_config, 'sim-failover')
        if not isinstance(failover_config, dict):
            return

        failover_path = sim_base_path + ['sim-failover']
        if self._has(failover_config, 'disable'):
            self._generate_leaf(failover_path, failover_config, 'disable')
        if self._has(failover_config, 'connect-retries'):
            self._generate_value(failover_path, failover_config, 'connect-retries')
        if self._has(failover_config, 'revert-timer'):
            self._generate_value(failover_path, failover_config, 'revert-timer')
        if self._has(failover_config, 'signal-loss-timer'):
            self._generate_value(failover_path, failover_config, 'signal-loss-timer')
        if self._has(failover_config, 'signal-threshold'):
            self._generate_signal_threshold(failover_path, failover_config)

    def _process_sim_config(self, base_path, intf_config):
        sim_config = self._get(intf_config, 'sim')
        if not isinstance(sim_config, dict):
            return

        sim_base_path = base_path + ['sim']
        if self._has(sim_config, 'primary-slot'):
            self._generate_value(sim_base_path, sim_config, 'primary-slot')

        self._process_sim_slot_config(sim_base_path, sim_config)
        self._process_sim_failback_config(sim_base_path, sim_config)
        self._process_sim_failover_config(sim_base_path, sim_config)

    def _process_apn_discovery_config(self, base_path, intf_config):
        apn_discovery_config = self._get(intf_config, 'apn-discovery')
        if not isinstance(apn_discovery_config, dict):
            return

        if self._has(apn_discovery_config, 'disable'):
            self._generate_leaf(base_path + ['apn-discovery'], apn_discovery_config, 'disable')

    def _process_reconnection_config(self, base_path, intf_config):
        reconnection_config = self._get(intf_config, 'reconnection')
        if not isinstance(reconnection_config, dict):
            return

        reconnection_path = base_path + ['reconnection']
        if self._has(reconnection_config, 'disable-enhanced'):
            self._generate_leaf(reconnection_path, reconnection_config, 'disable-enhanced')
        if self._has(reconnection_config, 'signal-threshold'):
            self._generate_signal_threshold(reconnection_path, reconnection_config)

        retry_interval = self._get(reconnection_config, 'retry-interval')
        if isinstance(retry_interval, dict):
            retry_path = reconnection_path + ['retry-interval']
            if self._has(retry_interval, 'good-signal'):
                self._generate_value(retry_path, retry_interval, 'good-signal')
            if self._has(retry_interval, 'poor-signal'):
                self._generate_value(retry_path, retry_interval, 'poor-signal')

        if self._has(reconnection_config, 'max-wait-for-signal'):
            self._generate_value(reconnection_path, reconnection_config, 'max-wait-for-signal')
        if self._has(reconnection_config, 'signal-check-interval'):
            self._generate_value(reconnection_path, reconnection_config, 'signal-check-interval')
        if self._has(reconnection_config, 'signal-strength-buffer'):
            self._generate_value(reconnection_path, reconnection_config, 'signal-strength-buffer')

    def _process_interface_management_config(self, base_path, intf_config):
        management_config = self._get(intf_config, 'interface-management')
        if not isinstance(management_config, dict):
            return

        management_path = base_path + ['interface-management']
        if self._has(management_config, 'disable'):
            self._generate_leaf(management_path, management_config, 'disable')
        if self._has(management_config, 'bearer-disconnect-delay'):
            self._generate_value(management_path, management_config, 'bearer-disconnect-delay')
        if self._has(management_config, 'registration-recovery-delay'):
            self._generate_value(management_path, management_config, 'registration-recovery-delay')
        if self._has(management_config, 'registration-flap-count'):
            self._generate_value(management_path, management_config, 'registration-flap-count')
        if self._has(management_config, 'registration-flap-window'):
            self._generate_value(management_path, management_config, 'registration-flap-window')
        if self._has(management_config, 'ip-change-delay'):
            self._generate_value(management_path, management_config, 'ip-change-delay')
        if self._has(management_config, 'disable-ensure-link-up-on-connect'):
            self._generate_leaf(management_path, management_config, 'disable-ensure-link-up-on-connect')
        if self._has(management_config, 'disable-monitor-bearer-state'):
            self._generate_leaf(management_path, management_config, 'disable-monitor-bearer-state')
        if self._has(management_config, 'disable-monitor-ip-changes'):
            self._generate_leaf(management_path, management_config, 'disable-monitor-ip-changes')
        if self._has(management_config, 'interface-up-timeout'):
            self._generate_value(management_path, management_config, 'interface-up-timeout')

    def _process_connectivity_monitoring_config(self, base_path, intf_config):
        monitoring_config = self._get(intf_config, 'connectivity-monitoring')
        if not isinstance(monitoring_config, dict):
            return

        monitoring_path = base_path + ['connectivity-monitoring']
        if self._has(monitoring_config, 'disable'):
            self._generate_leaf(monitoring_path, monitoring_config, 'disable')
        if self._has(monitoring_config, 'interval'):
            self._generate_value(monitoring_path, monitoring_config, 'interval')
        if self._has(monitoring_config, 'timeout'):
            self._generate_value(monitoring_path, monitoring_config, 'timeout')
        if self._has(monitoring_config, 'retry-count'):
            self._generate_value(monitoring_path, monitoring_config, 'retry-count')
        if self._has(monitoring_config, 'failure-threshold'):
            self._generate_value(monitoring_path, monitoring_config, 'failure-threshold')
        if self._has(monitoring_config, 'disable-test-ipv4'):
            self._generate_leaf(monitoring_path, monitoring_config, 'disable-test-ipv4')
        if self._has(monitoring_config, 'test-ipv6'):
            self._generate_leaf(monitoring_path, monitoring_config, 'test-ipv6')
        if self._has(monitoring_config, 'require-both'):
            self._generate_leaf(monitoring_path, monitoring_config, 'require-both')
        if self._has(monitoring_config, 'ipv4-targets'):
            self._generate_multi(monitoring_path, monitoring_config, 'ipv4-targets')
        if self._has(monitoring_config, 'ipv6-targets'):
            self._generate_multi(monitoring_path, monitoring_config, 'ipv6-targets')

    def _process_data_usage_config(self, base_path, intf_config):
        data_usage_config = self._get(intf_config, 'data-usage')
        if not isinstance(data_usage_config, dict):
            return

        data_usage_path = base_path + ['data-usage']
        if self._has(data_usage_config, 'monitoring-interval'):
            self._generate_value(data_usage_path, data_usage_config, 'monitoring-interval')
        if self._has(data_usage_config, 'warning-thresholds'):
            self._generate_multi(data_usage_path, data_usage_config, 'warning-thresholds', 'warning')
        if self._has(data_usage_config, 'warning'):
            self._generate_multi(data_usage_path, data_usage_config, 'warning')

        if self._has(data_usage_config, 'size'):
            self._generate_value(data_usage_path, data_usage_config, 'size')
        if self._has(data_usage_config, 'action'):
            self._generate_value(data_usage_path, data_usage_config, 'action')
        if self._has(data_usage_config, 'billing-date'):
            self._generate_value(data_usage_path, data_usage_config, 'billing-date')

        default_limit = self._get(data_usage_config, 'default-limit')
        if isinstance(default_limit, dict):
            default_limit_path = data_usage_path
            if self._has(default_limit, 'size'):
                self._generate_value(default_limit_path, default_limit, 'size')
            if self._has(default_limit, 'action'):
                self._generate_value(default_limit_path, default_limit, 'action')
            if self._has(default_limit, 'billing-date'):
                self._generate_value(default_limit_path, default_limit, 'billing-date')

    def _process_hardware_reset_config(self, base_path, intf_config):
        reset_config = self._get(intf_config, 'hardware-reset')
        if not isinstance(reset_config, dict):
            return

        reset_path = base_path + ['hardware-reset']
        if self._has(reset_config, 'disable'):
            self._generate_leaf(reset_path, reset_config, 'disable')
        if self._has(reset_config, 'max-attempts'):
            self._generate_value(reset_path, reset_config, 'max-attempts')
        if self._has(reset_config, 'cooldown'):
            self._generate_value(reset_path, reset_config, 'cooldown')

    def _process_failed_retry_config(self, base_path, intf_config):
        retry_config = self._get(intf_config, 'failed-retry')
        if not isinstance(retry_config, dict):
            return

        retry_path = base_path + ['failed-retry']
        if self._has(retry_config, 'disable'):
            self._generate_leaf(retry_path, retry_config, 'disable')
        if self._has(retry_config, 'intervals'):
            self._generate_multi(retry_path, retry_config, 'intervals')
        if self._has(retry_config, 'max-interval'):
            self._generate_value(retry_path, retry_config, 'max-interval')
        if self._has(retry_config, 'escalation-threshold'):
            self._generate_value(retry_path, retry_config, 'escalation-threshold')

    def _process_network_scan_config(self, base_path, intf_config):
        scan_config = self._get(intf_config, 'network-scan')
        if not isinstance(scan_config, dict):
            return

        scan_path = base_path + ['network-scan']
        if self._has(scan_config, 'timeout'):
            self._generate_value(scan_path, scan_config, 'timeout')

    def _process_timeouts_config(self, base_path, intf_config):
        timeouts_config = self._get(intf_config, 'timeouts')
        if not isinstance(timeouts_config, dict):
            return

        timeouts_path = base_path + ['timeouts']
        if self._has(timeouts_config, 'connection'):
            self._generate_value(timeouts_path, timeouts_config, 'connection')
        if self._has(timeouts_config, 'registration'):
            self._generate_value(timeouts_path, timeouts_config, 'registration')
        if self._has(timeouts_config, 'normal-monitoring-interval'):
            self._generate_value(timeouts_path, timeouts_config, 'normal-monitoring-interval')

    def _process_logging_config(self, base_path, intf_config):
        logging_config = self._get(intf_config, 'logging')
        if not isinstance(logging_config, dict):
            return

        logging_path = base_path + ['logging']
        if self._has(logging_config, 'level'):
            self._generate_value(logging_path, logging_config, 'level')
        if self._has(logging_config, 'sink'):
            self._generate_value(logging_path, logging_config, 'sink')
        if self._has(logging_config, 'disable-verbose'):
            self._generate_leaf(logging_path, logging_config, 'disable-verbose')
        if self._has(logging_config, 'disable-snmp-monitoring'):
            self._generate_leaf(logging_path, logging_config, 'disable-snmp-monitoring')
        if self._has(logging_config, 'disable-detailed-status'):
            self._generate_leaf(logging_path, logging_config, 'disable-detailed-status')
        if self._has(logging_config, 'health-check-interval'):
            self._generate_value(logging_path, logging_config, 'health-check-interval')

    def _process_ip_config(self, base_path, intf_config):
        ip_config = self._get(intf_config, 'ip')
        if not isinstance(ip_config, dict):
            return

        ip_command = IPOptionCommand(
            operator=self.operator,
            intf_type='wwan',
            intf_name=str(base_path[-1]),
        )
        ip_command.generate_commands(data={'ip': ip_config})
        self.cmds.extend(ip_command.cmds)
        self.vyos_cmds.extend(ip_command.vyos_cmds)

    def _process_ipv6_config(self, base_path, intf_config):
        ipv6_config = self._get(intf_config, 'ipv6')
        if not isinstance(ipv6_config, dict):
            return

        ip_command = IPOptionCommand(
            operator=self.operator,
            intf_type='wwan',
            intf_name=str(base_path[-1]),
        )
        ip_command.generate_commands(data={'ipv6': ipv6_config})
        self.cmds.extend(ip_command.cmds)
        self.vyos_cmds.extend(ip_command.vyos_cmds)

        ipv6_path = base_path + ['ipv6']
        management_config = self._get(ipv6_config, 'management-address')
        if isinstance(management_config, dict):
            management_path = ipv6_path + ['management-address']
            if not management_config:
                self.generate(*management_path)
                return

            if self._has(management_config, 'disable-default-https'):
                self._generate_leaf(management_path, management_config, 'disable-default-https')
            if self._has(management_config, 'host-id'):
                self._generate_value(management_path, management_config, 'host-id')
            if self._has(management_config, 'permit-tcp'):
                self._generate_multi(management_path, management_config, 'permit-tcp')
            if self._has(management_config, 'permit-udp'):
                self._generate_multi(management_path, management_config, 'permit-udp')
            if self._has(management_config, 'permit-source'):
                self._generate_multi(management_path, management_config, 'permit-source')

    def _process_router_advert_config(self, base_path, config, new_config=None):
        router_advert = self._get(config, 'router-advert')
        if not isinstance(router_advert, dict):
            return

        ra_path = base_path + ['router-advert']
        removing_block = (
            self.operator == 'delete'
            and isinstance(new_config, dict)
            and not self._has(new_config, 'router-advert')
        )
        if removing_block or not router_advert:
            self.generate(*ra_path)
        else:
            self._generate_nested_config(ra_path, router_advert)

    def _process_ipv6_bridging_config(self, base_path, intf_config, new_intf_config=None):
        bridging_config = self._get(intf_config, 'ipv6-bridging')
        if not isinstance(bridging_config, dict):
            return

        bridging_path = base_path + ['ipv6-bridging']
        if isinstance(new_intf_config, dict) and not self._has(new_intf_config, 'ipv6-bridging'):
            if self.operator == 'delete':
                self.generate(*bridging_path)
            return

        if self._has(bridging_config, 'interface'):
            self._generate_value(bridging_path, bridging_config, 'interface')
        if self._has(bridging_config, 'reconciliation-interval'):
            self._generate_value(bridging_path, bridging_config, 'reconciliation-interval')
        if self._has(bridging_config, 'translate-prefix'):
            self._generate_value(bridging_path, bridging_config, 'translate-prefix')
        self._process_router_advert_config(
            bridging_path, bridging_config, self._get(new_intf_config, 'ipv6-bridging')
        )

    def _process_pd_config(self, base_path, intf_config):
        pd_config = self._get(intf_config, 'pd')
        if not isinstance(pd_config, dict):
            return

        for instance, instance_config in pd_config.items():
            if not isinstance(instance_config, dict):
                continue

            interface_config = self._get(instance_config, 'interface')
            if not isinstance(interface_config, dict):
                continue

            for interface_name, interface_data in interface_config.items():
                if not isinstance(interface_data, dict):
                    continue

                pd_path = base_path + ['pd', str(instance), 'interface', str(interface_name)]
                if self._has(interface_data, 'address'):
                    self._generate_value(pd_path, interface_data, 'address')
                if self._has(interface_data, 'sla-id'):
                    self._generate_value(pd_path, interface_data, 'sla-id')
                if self._has(interface_data, 'sla-len'):
                    self._generate_value(pd_path, interface_data, 'sla-len')

    def _process_ip_passthrough_config(self, base_path, intf_config, new_intf_config):
        passthrough_config = self._get(intf_config, 'ip-passthrough')
        if not isinstance(passthrough_config, dict):
            return

        passthrough_path = base_path + ['ip-passthrough']
        if isinstance(new_intf_config, dict) and not self._has(new_intf_config, 'ip-passthrough'):
            if self.operator == 'delete':
                self.generate(*passthrough_path)
            return

        if not passthrough_config:
            self.generate(*passthrough_path)
            return

        for key in [
            'interface',
            'mac',
            'lease-time',
            'passthrough-management-address',
            'passthrough-management-address-ipv6',
        ]:
            if self._has(passthrough_config, key):
                self._generate_value(passthrough_path, passthrough_config, key)

        if self._has(passthrough_config, 'dns-server'):
            self._generate_multi(passthrough_path, passthrough_config, 'dns-server')
        if self._has(passthrough_config, 'disable-mss-clamp'):
            self._generate_leaf(passthrough_path, passthrough_config, 'disable-mss-clamp')
        if self._has(passthrough_config, 'legacy-dhcpv4-compat'):
            self._generate_leaf(passthrough_path, passthrough_config, 'legacy-dhcpv4-compat')
        self._process_router_advert_config(
            passthrough_path, passthrough_config, self._get(new_intf_config, 'ip-passthrough')
        )

        if self.operator == 'delete':
            for key in ['management-address', 'management-address-ipv6']:
                if self._has(passthrough_config, key):
                    self._generate_value(passthrough_path, passthrough_config, key)

    def _process_mirror_config(self, base_path, intf_config):
        mirror_config = self._get(intf_config, 'mirror')
        if not isinstance(mirror_config, dict):
            return

        mirror_path = base_path + ['mirror']
        if self._has(mirror_config, 'ingress'):
            self._generate_value(mirror_path, mirror_config, 'ingress')
        if self._has(mirror_config, 'egress'):
            self._generate_value(mirror_path, mirror_config, 'egress')

    def _process_dhcp_options_config(self, base_path, intf_config):
        dhcp_config = self._get(intf_config, 'dhcp-options')
        if isinstance(dhcp_config, dict):
            self._generate_nested_config(base_path + ['dhcp-options'], dhcp_config)

        dhcpv6_config = self._get(intf_config, 'dhcpv6-options')
        if isinstance(dhcpv6_config, dict):
            self._generate_nested_config(base_path + ['dhcpv6-options'], dhcpv6_config)

    def _process_interface_config(self, intf_name, intf_config, new_intf_config=None):
        base_path = ['interfaces', 'wwan', str(intf_name)]

        if intf_config == 'all' or not isinstance(intf_config, dict):
            self.generate(*base_path)
            return

        if self._has(intf_config, 'address'):
            self._generate_multi(base_path, intf_config, 'address')

        if self._has(intf_config, 'connection-mode'):
            self._generate_value(base_path, intf_config, 'connection-mode')

        if self._has(intf_config, 'network-mode'):
            self._generate_value(base_path, intf_config, 'network-mode')

        if self._has(intf_config, 'network-time'):
            network_time = self._get(intf_config, 'network-time')
            removing_feature = (
                self.operator == 'delete'
                and isinstance(new_intf_config, dict)
                and not self._has(new_intf_config, 'network-time')
            )
            if removing_feature or not isinstance(network_time, dict) or not network_time:
                self._generate_leaf(base_path, intf_config, 'network-time')
            elif self._has(network_time, 'update-interval'):
                self._generate_value(base_path + ['network-time'], network_time, 'update-interval')

        if self._has(intf_config, 'default-route-metric'):
            self._generate_value(base_path, intf_config, 'default-route-metric')

        if self._has(intf_config, 'description') and is_str_not_empty(self._get(intf_config, 'description')):
            self.generate(*base_path, 'description', format_description(str(self._get(intf_config, 'description'))))

        if self._has(intf_config, 'disable'):
            self._generate_leaf(base_path, intf_config, 'disable')

        if self._has(intf_config, 'mtu'):
            self._generate_value(base_path, intf_config, 'mtu')

        if self._has(intf_config, 'vrf'):
            self._generate_value(base_path, intf_config, 'vrf')

        if self._has(intf_config, 'redirect'):
            self._generate_value(base_path, intf_config, 'redirect')

        if self._has(intf_config, 'pd-reconciliation-interval'):
            self._generate_value(base_path, intf_config, 'pd-reconciliation-interval')

        self._process_ip_config(base_path, intf_config)
        self._process_ipv6_config(base_path, intf_config)
        self._process_ipv6_bridging_config(base_path, intf_config, new_intf_config)
        self._process_pd_config(base_path, intf_config)
        self._process_ip_passthrough_config(base_path, intf_config, new_intf_config)
        self._process_mirror_config(base_path, intf_config)
        self._process_dhcp_options_config(base_path, intf_config)
        self._process_sim_config(base_path, intf_config)
        self._process_apn_discovery_config(base_path, intf_config)
        self._process_reconnection_config(base_path, intf_config)
        self._process_interface_management_config(base_path, intf_config)
        self._process_connectivity_monitoring_config(base_path, intf_config)
        self._process_data_usage_config(base_path, intf_config)
        self._process_hardware_reset_config(base_path, intf_config)
        self._process_failed_retry_config(base_path, intf_config)
        self._process_network_scan_config(base_path, intf_config)
        self._process_timeouts_config(base_path, intf_config)
        self._process_logging_config(base_path, intf_config)

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            wwan_config = self._extract_wwan_config(data)
            self.attributes['interfaces']['wwan'] = wwan_config

            new_wwan_config = self._extract_wwan_config(new_config) if new_config else {}
            current_wwan_config = self._extract_wwan_config(current_config) if current_config else {}

            for intf_name, intf_config in wwan_config.items():
                base_path = ['interfaces', 'wwan', str(intf_name)]

                if self.operator == 'delete' and new_config and intf_name not in new_wwan_config:
                    self.generate(*base_path)
                    continue

                new_intf_config = new_wwan_config.get(intf_name) if new_config else None
                self._process_interface_config(intf_name, intf_config, new_intf_config)

                if self.operator == 'set' and isinstance(new_intf_config, dict):
                    current_time = self._get(current_wwan_config.get(intf_name), 'network-time')
                    if self._get(new_intf_config, 'network-time') == {} and isinstance(current_time, dict) and current_time:
                        self.generate(*base_path, 'network-time')
                    for parent in ['ip-passthrough', 'ipv6-bridging']:
                        current_ra = self._get(self._get(current_wwan_config.get(intf_name), parent), 'router-advert')
                        new_ra = self._get(self._get(new_intf_config, parent), 'router-advert')
                        if new_ra == {} and isinstance(current_ra, dict) and current_ra:
                            self.generate(*base_path, parent, 'router-advert')

            return self.cmds
        except Exception as e:
            print(f"Error generating WWAN commands: {e}")
            return []
