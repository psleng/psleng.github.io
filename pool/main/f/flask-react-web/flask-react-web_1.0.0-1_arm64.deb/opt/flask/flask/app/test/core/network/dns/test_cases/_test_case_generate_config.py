import pytest

test_set = [
    pytest.param(
        ({
            "dns": {
                "forwarding": {
                    "domain": {
                        "dns.example.com": {
                            "name-server": [
                                "198.51.100.0",
                                "203.0.113.0"
                            ]
                        },
                        "dns.example9.com": {
                            "name-server": {
                                "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            }
        },
        [
            "set service dns forwarding domain dns.example.com name-server 198.51.100.0",
            "set service dns forwarding domain dns.example.com name-server 203.0.113.0",
            "set service dns forwarding domain dns.example9.com name-server 2001:db8:abcd:12::1"
        ]),
        id="test_dns_forwarding_set_1"
    )
]

test_delete = [
    pytest.param(
        ({
            "dns": {
                "forwarding": {
                    "domain": {
                        "dns.example.com": {
                            "name-server": [
                                {"198.51.100.0": {"port": "53"}},
                                "203.0.113.0"
                            ]
                        },
                        "dns.example9.com": {
                            "name-server": {
                                "2001:db8:abcd:12::1": {"port": "53"}
                            }
                        }
                    }
                }
            }
        },
        [
            "delete service dns forwarding domain dns.example.com name-server 198.51.100.0",
            "delete service dns forwarding domain dns.example.com name-server 203.0.113.0",
            "delete service dns forwarding domain dns.example9.com name-server 2001:db8:abcd:12::1"
        ]),
        id="test_dns_forwarding_delete_1"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                "set service dns forwarding domain dns.example.com name-server 198.51.100.0",
                "set service dns forwarding domain dns.example.com name-server 203.0.113.0",
                "set service dns forwarding domain dns.example9.com name-server 2001:db8:abcd:12::1"
            ],
            {
                "service": {
                    "dns": {
                        "forwarding": {
                            "domain": {
                                "dns.example.com": {
                                    "name-server": [
                                        "198.51.100.0",
                                        "203.0.113.0"
                                    ]
                                },
                                "dns.example9.com": {
                                    "name-server": "2001:db8:abcd:12::1"
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_dns_forwarding"
    )
]
