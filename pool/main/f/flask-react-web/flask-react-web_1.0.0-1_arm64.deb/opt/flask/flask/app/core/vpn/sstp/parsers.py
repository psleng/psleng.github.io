def parse_to_vyos_config(data):
    
    if not data:
        return None

    result = {}
    sstp = result
    
    connection = data.get('connection', {})
    security = data.get('security', {})
    
    general = connection.get('general', {})
    if general:
        if general.get('description'):
            sstp['description'] = general['description']
        if general.get('defaultIPPool'):
            sstp['default-pool'] = general['defaultIPPool']
        if general.get('defaultIPv6Pool'):
            sstp['default-ipv6-pool'] = general['defaultIPv6Pool']
        if general.get('gatewayAddress'):
            sstp['gateway-address'] = general['gatewayAddress']
        if general.get('hostName'):
            sstp['host-name'] = general['hostName']
        if general.get('port') not in (None, ''):
            sstp['port'] = str(general['port'])
    
    advanced = connection.get('advanced', {})
    if advanced:
        if advanced.get('MTU') not in (None, ''):
            sstp['mtu'] = str(advanced['MTU'])
        
        name_servers = advanced.get('nameServers', [])
        if isinstance(name_servers, list) and len(name_servers) > 0:
            sstp['name-server'] = name_servers
        
        if advanced.get('log') not in (None, ''):
            sstp['log'] = {'level': str(advanced['log'])}
        
        wins_servers = advanced.get('WINS', [])
        if isinstance(wins_servers, list) and len(wins_servers) > 0:
            sstp['wins-server'] = wins_servers
        
        ppp = advanced.get('PPP', {})
        if ppp:
            ppp_options = {}
            
            if ppp.get('controlProtocol'):
                ppp_options['disable-ccp'] = {}
            
            if ppp.get('interfaceCaching') is not None and ppp.get('interfaceCaching') > 0:
                ppp_options['interface-cache'] = str(ppp['interfaceCaching'])
            
            if ppp.get('IPv4Negotiation'):
                ppp_options['ipv4'] = ppp['IPv4Negotiation']
            
            if ppp.get('IPv6Negotiation'):
                ppp_options['ipv6'] = ppp['IPv6Negotiation']
            
            if ppp.get('acceptPeerInterfaceID'):
                ppp_options['ipv6-accept-peer-interface-id'] = {}
            
            if ppp.get('IPv6InterfaceID'):
                ppp_options['ipv6-interface-id'] = ppp['IPv6InterfaceID']
            
            if ppp.get('IPv6PeerInterface'):
                ppp_options['ipv6-peer-interface-id'] = ppp['IPv6PeerInterface']
            
            if ppp.get('LCPEchoFailure') not in (None, ''):
                ppp_options['lcp-echo-failure'] = str(ppp['LCPEchoFailure'])
            
            if ppp.get('LCPEchoInterval') not in (None, ''):
                ppp_options['lcp-echo-interval'] = str(ppp['LCPEchoInterval'])
            
            if ppp.get('LCPEchoTimeout') not in (None, ''):
                ppp_options['lcp-echo-timeout'] = str(ppp['LCPEchoTimeout'])
            
            if ppp.get('minMTU') not in (None, '') and ppp.get('minMTU') >= 68:
                ppp_options['min-mtu'] = str(ppp['minMTU'])
            
            if ppp.get('MPPE'):
                ppp_options['mppe'] = ppp['MPPE']
            
            if ppp.get('MRU') not in (None, ''):
                ppp_options['mru'] = str(ppp['MRU'])
            
            if ppp_options:
                sstp['ppp-options'] = ppp_options
    
    ssl = connection.get('ssl', {})
    if ssl:
        ssl_config = {}
        if ssl.get('caCertificate'):
            ssl_config['ca-certificate'] = ssl['caCertificate']
        if ssl.get('certificate'):
            ssl_config['certificate'] = ssl['certificate']
        if ssl_config:
            sstp['ssl'] = ssl_config
    
    client_ip_pools = connection.get('clientIPPools', {}).get('pools', [])
    if client_ip_pools:
        sstp['client-ip-pool'] = {}
        for pool in client_ip_pools:
            pool_name = pool.get('name')
            subnet = pool.get('subnet', '')
            if pool_name and subnet:
                sstp['client-ip-pool'][pool_name] = {'range': subnet}
    
    client_ipv6_pools = connection.get('clientIPv6Pools', {}).get('IPv6Pools', [])
    if client_ipv6_pools:
        sstp['client-ipv6-pool'] = {}
        for pool in client_ipv6_pools:
            pool_name = pool.get('name')
            prefix = pool.get('prefix')
            if pool_name and prefix:
                sstp['client-ipv6-pool'][pool_name] = {
                    'prefix': {prefix: {}}
                }
    
    authentication = {}
    
    if security.get('mode'):
        authentication['mode'] = security['mode']
    
    protocols = security.get('protocol', [])
    if isinstance(protocols, list) and len(protocols) > 0:
        authentication['protocols'] = protocols
    
    local_users = security.get('localUsers', {}).get('users', [])
    if local_users:
        authentication['local-users'] = {'username': {}}
        for user in local_users:
            username = user.get('name') or user.get('username')
            if username:
                user_config = {}
                if user.get('password'):
                    user_config['password'] = user['password']
                if user.get('staticIP'):
                    user_config['static-ip'] = user['staticIP']
                
                is_disabled = user.get('disabled', False)
                is_enabled = user.get('enabled', True)
                if is_disabled or not is_enabled:
                    user_config['disable'] = {}
                
                authentication['local-users']['username'][username] = user_config
    
    radius_config = security.get('radius', {})
    if radius_config:
        radius = {}
        
        radius_options = radius_config.get('options', {})
        if radius_options:
            if radius_options.get('sourceAddress'):
                radius['source-address'] = radius_options['sourceAddress']
            
            if radius_options.get('NASIdentifier'):
                radius['nas-identifier'] = radius_options['NASIdentifier']
            
            if radius_options.get('NASIPAddress'):
                radius['nas-ip-address'] = radius_options['NASIPAddress']
            
            timeout = radius_options.get('timeout')
            if timeout is not None and timeout != '':
                radius['timeout'] = str(timeout)
            
            max_try = radius_options.get('maxTry')
            if max_try is not None and max_try != '':
                radius['max-try'] = str(max_try)
            
            acct_timeout = radius_options.get('acctTimeout')
            if acct_timeout is not None and acct_timeout != '':
                radius['acct-timeout'] = str(acct_timeout)
        
        radius_servers = radius_config.get('servers', [])
        if radius_servers:
            radius['server'] = {}
            for server in radius_servers:
                address = server.get('address')
                if address:
                    server_config = {}
                    
                    if server.get('port') is not None:
                        server_config['port'] = str(server['port'])
                    
                    key = server.get('key') or server.get('secret')
                    if key:
                        server_config['key'] = key
                    
                    if server.get('priority') is not None:
                        server_config['priority'] = str(server['priority'])
                    
                    is_disabled = server.get('disabled', False)
                    is_enabled = server.get('enabled', True)
                    if is_disabled or not is_enabled:
                        server_config['disable'] = {}
                    
                    if server.get('accountingPort') is not None:
                        server_config['acct-port'] = str(server['accountingPort'])
                    
                    if server.get('failTimePenalty') is not None:
                        server_config['fail-time'] = str(server['failTimePenalty'])
                    
                    if server.get('disableAccounting'):
                        server_config['disable-accounting'] = {}
                    
                    if server.get('backup'):
                        server_config['backup'] = {}
                    
                    radius['server'][address] = server_config
        
        if radius:
            authentication['radius'] = radius
    
    if authentication:
        sstp['authentication'] = authentication
    
    return result
