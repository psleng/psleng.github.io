import pprint
from logging import getLogger, DEBUG
from uuid import uuid4

from flask import session

from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_SYSLOG
from app.core.system.syslog.command_syslog import SyslogCommand
from app.core.system.syslog.models import SyslogConfig
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager

logger = getLogger(__name__)
logger.setLevel(DEBUG)


def fetch_syslog(provider, data: dict):
    resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSLOG, verify=False)
    cfg = resp.json().get('data')
    if not isinstance(cfg, dict):
        return {}
    for k in ['console', 'local', 'marker']:
        if k in cfg and cfg.get(k) is not None and not isinstance(cfg.get(k), dict):
            cfg[k] = {}
    if 'remote' in cfg and cfg.get('remote') is not None and not isinstance(cfg.get('remote'), dict):
        cfg['remote'] = {}
    return cfg


def update_syslog(provider, data: dict):
    logger.info("Update syslog:")
    logger.info(data)

    username = session.get('username', '')
    diff = data.get('diff') or {}
    current_config = data.get('current') or {}
    config = data.get('new') or {}

    print("Diff config: ")
    print(pprint.pformat(diff, indent=2, width=80))
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = SyslogCommand(operator='set', resource='system')
    set_cmds = iface_set_cmd.generate_commands(data=diff.get('created') or {}, current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = SyslogCommand(operator='delete', resource='system')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff.get('deleted') or {}, current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Normalize process_commands result:
    # {'syslog': 'marker'} instead of {'syslog': {'marker': {}}}.
    _delete_config = new_delete_configs.get('system', {}).get('syslog')
    if isinstance(_delete_config, str):
        new_delete_configs.setdefault('system', {})['syslog'] = {_delete_config: {}}

    merged_del_config = merge_dicts_delete(
        current_config,
        new_delete_configs.get('system', {}).get('syslog', {}),
        clean_empty=False,
    )
    merged_config = merge_dicts_set(
        merged_del_config,
        new_set_configs.get('system', {}).get('syslog', {}),
    )

    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    try:
        service = 'syslog'
        if hasattr(provider, 'verify_service') and provider.verify_service is not None and merged_config:
            if hasattr(provider.verify_service, 'call_verify'):
                verify = provider.verify_service.call_verify(service, merged_config)
    except Exception as e:
        print("Syslog verify skipped (validator may not support syslog):")
        print(str(e))
        verify = None

    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify).replace("\n", "") not in ["", "{}"]:
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB:
    SyslogConfig.refresh(config)

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update Syslog",
            "content": "Syslog is successfully updated",
        },
    )

    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res.get('success'), "error": res.get('error')})

    return r


def verify_syslog(provider, data: dict):
    try:
        if hasattr(provider, 'verify_service') and provider.verify_service is not None:
            if hasattr(provider.verify_service, 'call_verify'):
                return provider.verify_service.call_verify('syslog', data)
    except Exception as e:
        print("Syslog verify skipped (validator may not support syslog):")
        print(str(e))
    return ""
