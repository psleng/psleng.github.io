from flask import jsonify, request
from pydantic import ValidationError

from app.auth.utils import login_required
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.http.cmd.compare import compare_configs
from app.core.api.manager import api_manager
from app.core.network import vyos_network_bp
from app.core.network.lldp.config import LLDPConfig as LLDPConfigDTO, LLDPInterface, build_config
from app.core.network.lldp.models import LLDPConfig
from app.core.utils.decorator.route_decorator import Pipeline
from app.core.utils.validate.verify_parser import format_verify

admin = Pipeline.admin(vyos_network_bp)


def call(action, target, data=None):
    result = api_manager.call(action=action, target=target, data=data)
    if isinstance(result, Exception):
        raise result
    return result


@vyos_network_bp.route('/lldp', methods=['GET'])
@login_required
def get_lldp():
    try:
        config = LLDPConfig.query.first()
        return jsonify(config.serialize() if config else LLDPConfigDTO().model_dump())
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@admin.route('/lldp', methods=['PUT'])
def update_lldp():
    try:
        data = LLDPConfigDTO.model_validate_json(request.data)
        current_config = call(API_ACTION.READ, API_TARGET.LLDP)
        new_config = build_config(current_config, data)
        result = call(API_ACTION.UPDATE, API_TARGET.LLDP, {
            'current': current_config,
            'new': new_config,
            'diff': compare_configs(new_config, current_config),
        })
        failures = [item for item in result if item.get('success') is False]
        if failures:
            return jsonify({'error': '\n\n'.join(str(item.get('error') or 'Failed to update LLDP configuration') for item in failures)}), 400
        return jsonify({'success': True})
    except ValidationError as error:
        return jsonify({'error': '; '.join(item['msg'] for item in error.errors())}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@admin.route('/lldp/verify', methods=['POST'], pause_scheduler=False)
def verify_lldp():
    try:
        data = LLDPConfigDTO.model_validate_json(request.data)
        current_config = call(API_ACTION.READ, API_TARGET.LLDP)
        config = build_config(current_config, data)
        result = call(API_ACTION.VERIFY, API_TARGET.LLDP, config)
        error = '' if result in (None, {}, '', 'None', 'null') else format_verify(str(result))
        if error:
            return jsonify({'error': error}), 400
        return jsonify({'success': True})
    except ValidationError as error:
        return jsonify({'error': '; '.join(item['msg'] for item in error.errors())}), 400
    except Exception as error:
        return jsonify({'error': str(error)}), 400


@vyos_network_bp.route('/lldp/monitor', methods=['GET'])
@login_required
def monitor_lldp():
    try:
        interface = request.args.get('interface', '').strip()
        if interface:
            LLDPInterface(name=interface)
        return jsonify(call(API_ACTION.MONITOR, API_TARGET.LLDP_NEIGHBORS, {'interface': interface}))
    except Exception as error:
        return jsonify({'error': str(error)}), 400
