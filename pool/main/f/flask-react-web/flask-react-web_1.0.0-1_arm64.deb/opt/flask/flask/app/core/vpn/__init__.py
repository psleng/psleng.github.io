from flask import Blueprint

vyos_vpn_bp = Blueprint('vpn', __name__)

from . import routes