from app.db.database import db
from sqlalchemy import Column, Integer, String
from pydantic import BaseModel
from typing import Dict, List, Optional


class ARPEntryDTO(BaseModel):
    interface: Optional[str] = None
    address: Optional[str] = None
    mac: Optional[str] = None


class ARPDTO(BaseModel):
    entries: Optional[List[ARPEntryDTO]] = None


class ARPEntry(db.Model):
    __tablename__ = "vyos_arp_entry"

    id = Column(Integer, primary_key=True)
    interface = Column(String(64), nullable=True)
    address = Column(String(64), nullable=True)
    mac = Column(String(64), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @staticmethod
    def _parse_arp_config_to_entries(config: Dict) -> List[Dict[str, str]]:
        entries: List[Dict[str, str]] = []
        if not isinstance(config, dict):
            return entries

        interfaces = config.get('interface')
        if not isinstance(interfaces, dict):
            return entries

        for ifname, ifcfg in interfaces.items():
            if not isinstance(ifcfg, dict):
                continue
            addresses = ifcfg.get('address')
            if not isinstance(addresses, dict):
                continue
            for ip, ipcfg in addresses.items():
                if not isinstance(ipcfg, dict):
                    continue
                mac = ipcfg.get('mac')
                if mac is None or str(mac).strip() == "":
                    continue
                entries.append({'interface': str(ifname), 'address': str(ip), 'mac': str(mac)})

        return entries

    @classmethod
    def refresh(cls, data: dict):
        cls.truncate()
        entries = None
        if isinstance(data, dict):
            if isinstance(data.get('entries'), list):
                entries = data.get('entries')
            elif isinstance(data.get('interface'), dict):
                entries = cls._parse_arp_config_to_entries(data)
            else:
                arp_cfg = (
                    data
                    .get('protocols', {})
                    .get('static', {})
                    .get('arp')
                )
                if isinstance(arp_cfg, dict) and isinstance(arp_cfg.get('interface'), dict):
                    entries = cls._parse_arp_config_to_entries(arp_cfg)

        if not isinstance(entries, list):
            return

        for e in entries:
            if not isinstance(e, dict):
                continue
            interface = e.get('interface')
            address = e.get('address')
            mac = e.get('mac')
            if interface is None or str(interface).strip() == "":
                continue
            if address is None or str(address).strip() == "":
                continue
            if mac is None or str(mac).strip() == "":
                continue

            db.session.add(cls(
                interface=str(interface).strip(),
                address=str(address).strip(),
                mac=str(mac).strip()
            ))

        db.session.commit()

    def serialize(self):
        return {
            'interface': self.interface,
            'address': self.address,
            'mac': self.mac
        }
