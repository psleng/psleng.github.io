from app.core.api.http.cmd.command import Command
import json
import shlex


class KeyCertCommand(Command):
    """
    Command class for KeyCert:
    Certificate commands:
        set/delete pki ca <ca-name> certificate <content-in-text>
        set/delete pki ca <ca-name> private key <content-in-text>
        set/delete pki ca <ca-name> crl <text-in-pem-format>
        set/delete pki ca <ca-name> description <text>
        set/delete pki ca <ca-name> revoke
        set/delete pki ca <ca-name> system-install
        set/delete pki certificate <cert-name> certificate <content-in-text>
        set/delete pki certificate <cert-name> private key <content-in-text>
        set/delete pki certificate <cert-name> private password-protected
        set/delete pki certificate <cert-name> acme domain-name <domain-name>
        set/delete pki certificate <cert-name> acme email <email-address-in-text>
        set/delete pki certificate <cert-name> acme listen-address <IPv4-or-IPv6>
        set/delete pki certificate <cert-name> acme rsa-key-size <2048-or-3072-or-4096>
        set/delete pki certificate <cert-name> acme url <url-text>
        set/delete pki certificate <cert-name> description <text>
        set/delete pki certificate <cert-name> revoke
        set/delete pki crl <crl-name> <content-in-text>

    Key commands:
        set/delete pki key-pair <key-name> private key <key-value>
        set/delete pki key-pair <key-name> public key <key-value>
        set/delete pki openvpn shared-secret <key-name> key <key-value>
        set/delete pki openvpn shared-secret <key-name> version <number>
        
    DH commands:
        set/delete pki dh <dh-name> parameters <key-value>
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'keycert'))
            self.attributes = {
                'ca': {},
                'certificate': {},
                'crl': {},
                'key_pair': {},
                'openvpn': {},
                'ssh': {},
                'wireguard': {},
                'dh': {}
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing KeyCert command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        return json.dumps({'op': self.operator, 'path': list(path_elements)})

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(shlex.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _process_ca(self, ca_name, ca_config, current_config, new_config):
        base = ['pki', 'ca', ca_name]

        if self.operator == 'delete' and ca_name not in (new_config.get('ca') or {}):
            self.generate(*base)
            return
        
        if 'certificate' in ca_config and ca_config['certificate']:
            self.generate(*base, 'certificate', ca_config['certificate'])
        
        if 'private' in ca_config and 'key' in ca_config['private']:
            self.generate(*base, 'private', 'key', ca_config['private']['key'])

        crls = ca_config.get('crl') or []
        if isinstance(crls, str):
            crls = [crls]
        for crl in crls:
            self.generate(*base, 'crl', crl)

        if ca_config.get('description'):
            self.generate(*base, 'description', ca_config['description'])

        for flag in ('revoke', 'system-install'):
            normalized_flag = flag.replace('-', '_')
            if flag in ca_config or normalized_flag in ca_config:
                value = ca_config.get(flag, ca_config.get(normalized_flag))
                if value is not False and value is not None:
                    self.generate(*base, flag)

    def _process_certificate(self, cert_name, cert_config, current_config, new_config):
        base = ['pki', 'certificate', cert_name]
        
        if self.operator == 'delete' and cert_name not in (new_config.get('certificate') or {}):
            self.generate(*base)
            return
        
        if 'certificate' in cert_config and cert_config['certificate']:
            self.generate(*base, 'certificate', cert_config['certificate'])

        if cert_config.get('description'):
            self.generate(*base, 'description', cert_config['description'])
        if 'revoke' in cert_config and cert_config['revoke'] is not False and cert_config['revoke'] is not None:
            self.generate(*base, 'revoke')

        if 'acme' in cert_config:
            for field in ('domain-name', 'email', 'listen-address', 'rsa-key-size', 'url'):
                value = cert_config['acme'].get(field, cert_config['acme'].get(field.replace('-', '_')))
                if value is not None and str(value).strip():
                    self.generate(*base, 'acme', field, str(value))
        
        if 'private' in cert_config:
            if 'key' in cert_config['private']:
                self.generate(*base, 'private', 'key', cert_config['private']['key'])
            if 'password_protected' in cert_config['private'] and cert_config['private']['password_protected']:
                self.generate(*base, 'private', 'password-protected')

    def _process_crl(self, crl_name, crl_config):
        base = ['pki', 'crl', crl_name]
        
        if 'content' in crl_config and crl_config['content']:
            self.generate(*base, crl_config['content'])

    def _process_key_pair(self, key_name, key_config, current_config, new_config):
        base = ['pki', 'key-pair', key_name]
        
        if self.operator == 'delete' and key_name not in (new_config.get('key_pair') or {}):
            self.generate(*base)
            return
        
        if 'private' in key_config and 'key' in key_config['private']:
            self.generate(*base, 'private', 'key', key_config['private']['key'])
        
        if 'public' in key_config and 'key' in key_config['public']:
            self.generate(*base, 'public', 'key', key_config['public']['key'])

    def _process_openvpn(self, secret_name, openvpn_config, current_config, new_config):
        base = ['pki', 'openvpn', 'shared-secret', secret_name]
        
        if self.operator == 'delete' and secret_name not in (new_config.get('openvpn') or {}):
            self.generate(*base)
            return
        
        if 'key' in openvpn_config and openvpn_config['key']:
            key_value = str(openvpn_config['key'])
            key_value = key_value.replace('\r', '').replace('\n', '')
            self.generate(*base, 'key', key_value)
        
        if 'version' in openvpn_config and openvpn_config['version']:
            self.generate(*base, 'version', str(openvpn_config['version']))

    def _process_ssh_keys(self, ssh_config):
        if 'users' not in ssh_config:
            return
            
        for username, user_config in ssh_config['users'].items():
            if 'public_keys' not in user_config:
                continue
                
            for key_name, key_config in user_config['public_keys'].items():
                base = ['system', 'login', 'user', username, 'authentication', 'public-keys', key_name]
                
                if 'key' in key_config and key_config['key']:
                    self.generate(*base, 'key', key_config['key'])
                
                if 'type' in key_config and key_config['type']:
                    self.generate(*base, 'type', key_config['type'])

    def _process_wireguard(self, wg_config):
        if 'interfaces' not in wg_config:
            return
            
        for interface_name, interface_config in wg_config['interfaces'].items():
            base = ['interfaces', 'wireguard', interface_name]
            
            if 'private_key' in interface_config and interface_config['private_key']:
                self.generate(*base, 'private-key', interface_config['private_key'])
            
            if 'peers' in interface_config:
                for peer_name, peer_config in interface_config['peers'].items():
                    peer_base = [*base, 'peer', peer_name]
                    
                    if 'public_key' in peer_config and peer_config['public_key']:
                        self.generate(*peer_base, 'public-key', peer_config['public_key'])

    def _process_dh(self, dh_name, dh_config, current_config, new_config):
        base = ['pki', 'dh', dh_name]
        
        if self.operator == 'delete' and dh_name not in (new_config.get('dh') or {}):
            self.generate(*base)
            return
        
        if 'parameters' in dh_config and dh_config['parameters']:
            self.generate(*base, 'parameters', dh_config['parameters'])

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.cmds = []
            self.vyos_cmds = []

            def _normalize_config(cfg):
                if not cfg or not isinstance(cfg, dict):
                    return {}

                normalized = dict(cfg)

                if 'key_pair' not in normalized and 'key-pair' in normalized:
                    normalized['key_pair'] = normalized.get('key-pair') or {}

                if 'openvpn' in normalized and isinstance(normalized.get('openvpn'), dict):
                    ovpn = normalized.get('openvpn') or {}
                    if 'shared-secret' in ovpn:
                        normalized['openvpn'] = ovpn.get('shared-secret') or {}
                    elif 'shared_secret' in ovpn:
                        normalized['openvpn'] = ovpn.get('shared_secret') or {}

                return normalized

            data = _normalize_config(data)
            current_config = _normalize_config(current_config)
            new_config = _normalize_config(new_config)
            
            if 'ca' in data:
                for ca_name, ca_config in data['ca'].items():
                    self._process_ca(ca_name, ca_config, current_config, new_config)
            
            if 'certificate' in data:
                for cert_name, cert_config in data['certificate'].items():
                    self._process_certificate(cert_name, cert_config, current_config, new_config)
            
            if 'crl' in data:
                for crl_name, crl_config in data['crl'].items():
                    self._process_crl(crl_name, crl_config)
            
            if 'key_pair' in data:
                for key_name, key_config in data['key_pair'].items():
                    self._process_key_pair(key_name, key_config, current_config, new_config)
            
            if 'openvpn' in data:
                for secret_name, openvpn_config in data['openvpn'].items():
                    self._process_openvpn(secret_name, openvpn_config, current_config, new_config)
            
            if 'ssh' in data:
                self._process_ssh_keys(data['ssh'])
            
            if 'wireguard' in data:
                self._process_wireguard(data['wireguard'])
            
            if 'dh' in data:
                for dh_name, dh_config in data['dh'].items():
                    self._process_dh(dh_name, dh_config, current_config, new_config)
            
            return self.cmds

        except Exception as e:
            print(f"Error generating KeyCert commands: {e}")
            return []
