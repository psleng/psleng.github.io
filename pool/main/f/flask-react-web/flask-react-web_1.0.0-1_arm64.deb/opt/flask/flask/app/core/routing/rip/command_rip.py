from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

class RIPCommand(Command):
    """Command class for RIP commands
    
    - set/delete protocols rip default-distance <1-255>
    - set/delete protocols rip default-information originate
    - set/delete protocols rip default-metric <1-16>
    - set/delete protocols rip neighbor <x.x.x.x>
    - set/delete protocols rip passive-interface <intf-name>
    - set/delete protocols rip route <x.x.x.x/n>
    - set/delete protocols rip timers garbage-collection <5-2147483647>
    - set/delete protocols rip timers timeout <5-2147483647>
    - set/delete protocols rip timers update <5-2147483647>
    - set/delete protocols rip version <1 | 2>
    - set/delete protocols rip network <x.x.x.x/n>
    - set/delete protocols rip network-distance <x.x.x.x/n>
    - set/delete protocols rip interface <intf-name>
    - set/delete protocols rip interface <intf-name> authentication plaintext-password <text>
    - set/delete protocols rip interface <intf-name> receive version {1 | 2}
    - set/delete protocols rip interface <intf-name> send version {1 | 2}
    - set/delete protocols rip interface <intf-name> split-horizon
    - set/delete protocols rip interface <intf-name> split-horizon disable
    - set/delete protocols rip interface <intf-name> split-horizon poison-reverse
    - set/delete protocols rip redistribute {connected | kernel | ospf | static}
    - set/delete protocols rip redistribute {connected | kernel | ospf | static} metric <1-16>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'rip'))
            self.attributes = {
                'protocols': {
                    'rip': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing RIP cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.attributes['protocols']['rip'] = data
            
            self._process_global_parameters(data)
            
            if 'timers' in data:
                self._process_timers_config(data['timers'])
            
            if 'neighbor' in data:
                self._process_neighbor_config(data['neighbor'])
            
            if 'passive-interface' in data:
                self._process_passive_interface_config(data['passive-interface'])
            
            if 'route' in data:
                self._process_route_config(data['route'], current_config, new_config)

            if 'network' in data:
                self._process_network_config(data['network'], current_config, new_config)
            
            if 'network-distance' in data:
                self._process_network_distance_config(data['network-distance'], current_config, new_config)
            
            if 'interface' in data:
                self._process_interface_config(data['interface'], current_config, new_config)
            
            if 'redistribute' in data:
                self._process_redistribute_config(data['redistribute'], current_config, new_config)
            
            print(f"Generated RIP commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating RIP commands: {e}")
            return []

    def _process_network_config(self, network_config, current_config, new_config):
        base_path = ['protocols', 'rip', 'network']

        if isinstance(network_config, str):
            if is_str_not_empty(network_config):
                self.generate(*base_path, network_config)
            return

        if isinstance(network_config, list):
            for item in network_config:
                if isinstance(item, dict):
                    for network in item.keys():
                        if is_str_not_empty(network):
                            if self.operator == 'delete' and network not in new_config.get('network', {}):
                                self.generate(*base_path, network)
                                continue
                            self.generate(*base_path, network)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(network_config, dict):
            for network in network_config.keys():
                if is_str_not_empty(network):
                    if self.operator == 'delete' and network not in new_config.get('network', {}):
                        self.generate(*base_path, network)
                        continue
                    self.generate(*base_path, network)
    
    def _process_global_parameters(self, data):
        base_path = ['protocols', 'rip']
        
        if 'default-distance' in data and is_str_not_empty(data['default-distance']):
            self.generate(*base_path, 'default-distance', str(data['default-distance']))
        
        if 'default-information' in data:
            if 'originate' in data['default-information']:
                self.generate(*base_path, 'default-information', 'originate')
        
        if 'default-metric' in data and is_str_not_empty(data['default-metric']):
            self.generate(*base_path, 'default-metric', str(data['default-metric']))
        
        if 'version' in data and is_str_not_empty(data['version']):
            self.generate(*base_path, 'version', str(data['version']))
    
    def _process_timers_config(self, timers_config):
        base_path = ['protocols', 'rip', 'timers']
        
        if 'garbage-collection' in timers_config and is_str_not_empty(timers_config['garbage-collection']):
            self.generate(*base_path, 'garbage-collection', str(timers_config['garbage-collection']))
        
        if 'timeout' in timers_config and is_str_not_empty(timers_config['timeout']):
            self.generate(*base_path, 'timeout', str(timers_config['timeout']))
        
        if 'update' in timers_config and is_str_not_empty(timers_config['update']):
            self.generate(*base_path, 'update', str(timers_config['update']))
    
    def _process_neighbor_config(self, neighbor_config):
        base_path = ['protocols', 'rip', 'neighbor']

        if isinstance(neighbor_config, str):
            if is_str_not_empty(neighbor_config):
                self.generate(*base_path, neighbor_config)
            return
        
        if isinstance(neighbor_config, list):
            for item in neighbor_config:
                if isinstance(item, dict):
                    for neighbor_ip in item.keys():
                        if is_str_not_empty(neighbor_ip):
                            self.generate(*base_path, neighbor_ip)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(neighbor_config, dict):
            for neighbor_ip in neighbor_config.keys():
                if is_str_not_empty(neighbor_ip):
                    self.generate(*base_path, neighbor_ip)
    
    def _process_passive_interface_config(self, passive_config):
        base_path = ['protocols', 'rip', 'passive-interface']

        if isinstance(passive_config, str):
            if is_str_not_empty(passive_config):
                self.generate(*base_path, passive_config)
            return
        
        if isinstance(passive_config, list):
            for item in passive_config:
                if isinstance(item, dict):
                    for intf_name in item.keys():
                        if is_str_not_empty(intf_name):
                            self.generate(*base_path, intf_name)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(passive_config, dict):
            for intf_name in passive_config.keys():
                if is_str_not_empty(intf_name):
                    self.generate(*base_path, intf_name)
    
    def _process_route_config(self, route_config, current_config, new_config):
        base_path = ['protocols', 'rip', 'route']

        if isinstance(route_config, str):
            if is_str_not_empty(route_config):
                self.generate(*base_path, route_config)
            return
        
        if isinstance(route_config, list):
            for item in route_config:
                if isinstance(item, dict):
                    for route in item.keys():
                        if self.operator == 'delete' and route not in new_config.get('route', {}):
                            self.generate(*base_path, route)
                            continue
                        if is_str_not_empty(route):
                            self.generate(*base_path, route)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(route_config, dict):
            for route in route_config.keys():
                if self.operator == 'delete' and route not in new_config.get('route', {}):
                    self.generate(*base_path, route)
                    continue
                if is_str_not_empty(route):
                    self.generate(*base_path, route)
    
    def _process_network_distance_config(self, network_distance_config, current_config, new_config):
        base_path = ['protocols', 'rip', 'network-distance']

        if isinstance(network_distance_config, str):
            if is_str_not_empty(network_distance_config):
                self.generate(*base_path, network_distance_config)
            return
        
        if isinstance(network_distance_config, list):
            for item in network_distance_config:
                if isinstance(item, dict):
                    for network in item.keys():
                        if self.operator == 'delete' and network not in new_config.get('network-distance', {}):
                            self.generate(*base_path, network)
                            continue
                        if is_str_not_empty(network):
                            self.generate(*base_path, network)
                            if isinstance(item[network], dict) and 'distance' in item[network]:
                                distance = item[network]['distance']
                                if is_str_not_empty(distance):
                                    self.generate(*base_path, network, 'distance', str(distance))
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(network_distance_config, dict):
            for network, network_data in network_distance_config.items():
                if self.operator == 'delete' and network not in new_config.get('network-distance', {}):
                    self.generate(*base_path, network)
                    continue
                if is_str_not_empty(network):
                    self.generate(*base_path, network)
                    if isinstance(network_data, dict) and 'distance' in network_data:
                        distance = network_data['distance']
                        if is_str_not_empty(distance):
                            self.generate(*base_path, network, 'distance', str(distance))
    
    def _process_interface_config(self, interface_config, current_config, new_config):
        for intf_name, intf_data in interface_config.items():
            base_path = ['protocols', 'rip', 'interface', intf_name]
            
            if not intf_data or intf_data == {}:
                self.generate(*base_path)
                continue

            if self.operator == 'delete' and intf_name not in new_config.get('interface', {}):
                self.generate(*base_path)
                continue
            
            if 'authentication' in intf_data:
                if 'plaintext-password' in intf_data['authentication']:
                    if is_str_not_empty(intf_data['authentication']['plaintext-password']):
                        self.generate(*base_path, 'authentication', 'plaintext-password', 
                                    intf_data['authentication']['plaintext-password'])
            
            if 'receive' in intf_data:
                if 'version' in intf_data['receive'] and is_str_not_empty(intf_data['receive']['version']):
                    self.generate(*base_path, 'receive', 'version', str(intf_data['receive']['version']))
            
            if 'send' in intf_data:
                if 'version' in intf_data['send'] and is_str_not_empty(intf_data['send']['version']):
                    self.generate(*base_path, 'send', 'version', str(intf_data['send']['version']))
            
            if 'split-horizon' in intf_data:
                split_horizon_data = intf_data['split-horizon']
                
                if split_horizon_data == {} or split_horizon_data is True:
                    self.generate(*base_path, 'split-horizon')
                elif isinstance(split_horizon_data, dict):
                    if 'disable' in split_horizon_data:
                        self.generate(*base_path, 'split-horizon', 'disable')
                    elif 'poison-reverse' in split_horizon_data:
                        self.generate(*base_path, 'split-horizon', 'poison-reverse')
    
    def _process_redistribute_config(self, redistribute_config, current_config, new_config):
        for protocol, protocol_data in redistribute_config.items():
            base_path = ['protocols', 'rip', 'redistribute', protocol]

            if self.operator == 'delete' and protocol not in new_config.get('redistribute', {}):
                self.generate(*base_path)
                continue
            
            if not protocol_data or protocol_data == {}:
                self.generate(*base_path)
                continue
            
            if 'metric' in protocol_data and is_str_not_empty(protocol_data['metric']):
                self.generate(*base_path, 'metric', str(protocol_data['metric']))
