from app.log.logger import logger


def _parse_areas_to_vyos_config(data):
    areas = {}
    for area in data['areas']:
        if not area.get('areaNumber'):
            continue
        
        area_config = {}
        
        if area.get('areaType') and area['areaType'] != 'normal':
            area_type = area['areaType']
            area_type_config = {}
            
            if area.get('areaTypeConfig'):
                type_config = area['areaTypeConfig']
                if type_config.get('defaultInformationOriginate'):
                    area_type_config['default-information-originate'] = {}
                if type_config.get('noSummary'):
                    area_type_config['no-summary'] = {}
            
            area_config['area-type'] = {area_type: area_type_config}
        
        if area.get('ranges'):
            ranges = {}
            for range_item in area['ranges']:
                if range_item.get('prefix'):
                    range_config = {}
                    if range_item.get('advertise'):
                        range_config['advertise'] = {}
                    ranges[range_item['prefix']] = range_config
            if ranges:
                area_config['range'] = ranges
        
        areas[area['areaNumber']] = area_config
    return areas


def _parse_interfaces_to_vyos_config(data):
    interfaces = {}
    for intf in data['interfaces']:
        if not intf.get('name'):
            continue
        
        intf_config = {}
        
        if intf.get('area'):
            intf_config['area'] = intf['area']
        
        if intf.get('cost'):
            intf_config['cost'] = intf['cost']
        if intf.get('deadInterval'):
            intf_config['dead-interval'] = intf['deadInterval']
        if intf.get('helloInterval'):
            intf_config['hello-interval'] = intf['helloInterval']
        if intf.get('ifmtu'):
            intf_config['ifmtu'] = intf['ifmtu']
        if intf.get('instanceId'):
            intf_config['instance-id'] = intf['instanceId']
        if intf.get('mtuIgnore'):
            intf_config['mtu-ignore'] = {}
        if intf.get('network'):
            intf_config['network'] = intf['network']
        if intf.get('passive'):
            intf_config['passive'] = {}
        if intf.get('priority'):
            intf_config['priority'] = intf['priority']
        if intf.get('retransmitInterval'):
            intf_config['retransmit-interval'] = intf['retransmitInterval']
        if intf.get('transmitDelay'):
            intf_config['transmit-delay'] = intf['transmitDelay']
        
        interfaces[intf['name']] = intf_config
    return interfaces
        

def parse_to_vyos_config(data):
    vyos_config = {}
    
    if 'advanced' in data:
        advanced = data['advanced']
        
        if advanced.get('autoCostReferenceBandwidth'):
            vyos_config['auto-cost'] = {'reference-bandwidth': advanced['autoCostReferenceBandwidth']}
        
        if advanced.get('logAdjacencyChanges'):
            vyos_config['log-adjacency-changes'] = {'detail': {}}
        
        if advanced.get('routerId'):
            vyos_config['parameters'] = {'router-id': advanced['routerId']}
        
        default_info = {}
        if advanced.get('defaultInformationAlways'):
            default_info['always'] = {}
        if advanced.get('defaultInformationMetric'):
            default_info['metric'] = advanced['defaultInformationMetric']
        if advanced.get('defaultInformationMetricType'):
            default_info['metric-type'] = advanced['defaultInformationMetricType']
        if default_info:
            vyos_config['default-information'] = default_info
        
        distance = {}
        if advanced.get('distanceGlobal'):
            distance['global'] = advanced['distanceGlobal']
        
        ospf_distance = {}
        if advanced.get('distanceOspfExternal'):
            ospf_distance['external'] = advanced['distanceOspfExternal']
        if advanced.get('distanceOspfInterArea'):
            ospf_distance['inter-area'] = advanced['distanceOspfInterArea']
        if advanced.get('distanceOspfIntraArea'):
            ospf_distance['intra-area'] = advanced['distanceOspfIntraArea']
        if ospf_distance:
            distance['ospf'] = ospf_distance
        if distance:
            vyos_config['distance'] = distance
        
        if advanced.get('gracefulRestart'):
            gr = {}
            if advanced.get('gracefulRestartGracePeriod'):
                gr['grace-period'] = advanced['gracefulRestartGracePeriod']
            vyos_config['graceful-restart'] = gr if gr else {}
    
    if 'areas' in data and data['areas']:
        areas = _parse_areas_to_vyos_config(data)
        if areas:
            vyos_config['area'] = areas
    
    if 'interfaces' in data and data['interfaces']:
        interfaces = _parse_interfaces_to_vyos_config(data)
        if interfaces:
            vyos_config['interface'] = interfaces
    
    if 'redistribution' in data:
        redist = data['redistribution']
        redistribute = {}
        
        for protocol in ['connected', 'kernel', 'static']:
            if redist.get(protocol) and redist[protocol].get('enabled'):
                proto_config = {}
                if redist[protocol].get('metric'):
                    proto_config['metric'] = redist[protocol]['metric']
                if redist[protocol].get('metricType'):
                    proto_config['metric-type'] = redist[protocol]['metricType']
                redistribute[protocol] = proto_config
        
        if redistribute:
            vyos_config['redistribute'] = redistribute
    
    return vyos_config


def parse_to_vyos_config_verify(data):
    verify_type = data.get('verify_type')
    if verify_type == 'area':
        return {"area": _parse_areas_to_vyos_config(data)}
    elif verify_type == 'interface':
        return {"interface": _parse_interfaces_to_vyos_config(data)}
    return {}
