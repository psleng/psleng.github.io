import pytest

test_set = [
    # Empty security groups
    pytest.param(
        {
            "ike-group": {
                "ike-empty": {}
            },
            "esp-group": {
                "esp-empty": {}
            }
        },
        [
            "set vpn ipsec ike-group ike-empty",
            "set vpn ipsec esp-group esp-empty"
        ],
        id="test_ipsec_set_empty_security_groups"
    ),
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-1": {
                        "authentication": {
                            "mode": "pre-shared-secret",
                            "local-id": "local-id",
                            "remote-id": "remote-id"
                        },
                        "ike-group": "ike-group-1",
                        "local-address": "192.168.1.1",
                        "remote-address": "192.168.2.1"
                    }
                }
            }
        },
        [
            "set vpn ipsec site-to-site peer peer-1 authentication mode pre-shared-secret",
            "set vpn ipsec site-to-site peer peer-1 authentication local-id local-id",
            "set vpn ipsec site-to-site peer peer-1 authentication remote-id remote-id",
            "set vpn ipsec site-to-site peer peer-1 ike-group ike-group-1",
            "set vpn ipsec site-to-site peer peer-1 local-address 192.168.1.1",
            "set vpn ipsec site-to-site peer peer-1 remote-address 192.168.2.1"
        ],
        id="test_ipsec_set_peer_basic"
    ),
    # RSA Authentication
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-rsa": {
                        "authentication": {
                            "mode": "rsa",
                            "rsa": {
                                "local-key": "local-rsa-key",
                                "remote-key": "remote-rsa-key",
                                "passphrase": "rsa-pass"
                            }
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec site-to-site peer peer-rsa authentication mode rsa",
            "set vpn ipsec site-to-site peer peer-rsa authentication rsa local-key local-rsa-key",
            "set vpn ipsec site-to-site peer peer-rsa authentication rsa remote-key remote-rsa-key",
            "set vpn ipsec site-to-site peer peer-rsa authentication rsa passphrase rsa-pass"
        ],
        id="test_ipsec_set_peer_rsa_auth"
    ),
    # X.509 Authentication
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-x509": {
                        "authentication": {
                            "mode": "x509",
                            "use-x509-id": {},
                            "x509": {
                                "ca-certificate": "ca-cert-1",
                                "certificate": "cert-1",
                                "passphrase": "x509-pass"
                            }
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec site-to-site peer peer-x509 authentication mode x509",
            "set vpn ipsec site-to-site peer peer-x509 authentication use-x509-id",
            "set vpn ipsec site-to-site peer peer-x509 authentication x509 ca-certificate ca-cert-1",
            "set vpn ipsec site-to-site peer peer-x509 authentication x509 certificate cert-1",
            "set vpn ipsec site-to-site peer peer-x509 authentication x509 passphrase x509-pass"
        ],
        id="test_ipsec_set_peer_x509_auth"
    ),
    # Peer with Tunnels
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-tunnel": {
                        "tunnel": {
                            "1": {
                                "esp-group": "esp-grp-1",
                                "local": {
                                    "prefix": ["10.0.0.0/24", "10.0.1.0/24"],
                                    "port": "500"
                                },
                                "remote": {
                                    "prefix": ["10.0.2.0/24"],
                                    "port": "500"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 esp-group esp-grp-1",
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 local prefix 10.0.0.0/24",
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 local prefix 10.0.1.0/24",
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 local port 500",
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 remote prefix 10.0.2.0/24",
            "set vpn ipsec site-to-site peer peer-tunnel tunnel 1 remote port 500"
        ],
        id="test_ipsec_set_peer_tunnels"
    ),
    # Remote Access Connection
    pytest.param(
        {
            "remote-access": {
                "connection": {
                    "conn-1": {
                        "description": "Remote Connection",
                        "ike-group": "ike-grp-1",
                        "esp-group": "esp-grp-1",
                        "local-address": "any",
                        "pool": ["pool-1", "pool-2"]
                    }
                }
            }
        },
        [
            "set vpn ipsec remote-access connection conn-1 description Remote_Connection",
            "set vpn ipsec remote-access connection conn-1 ike-group ike-grp-1",
            "set vpn ipsec remote-access connection conn-1 esp-group esp-grp-1",
            "set vpn ipsec remote-access connection conn-1 local-address any",
            "set vpn ipsec remote-access connection conn-1 pool pool-1",
            "set vpn ipsec remote-access connection conn-1 pool pool-2"
        ],
        id="test_ipsec_set_remote_access_connection"
    ),
    # IKE Group
    pytest.param(
        {
            "ike-group": {
                "ike-grp-1": {
                    "close-action": "trap",
                    "key-exchange": "ikev2",
                    "lifetime": "28800",
                    "mode": "main",
                    "proposal": {
                        "1": {
                            "dh-group": "14",
                            "encryption": "aes256",
                            "hash": "sha256"
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec ike-group ike-grp-1 close-action trap",
            "set vpn ipsec ike-group ike-grp-1 key-exchange ikev2",
            "set vpn ipsec ike-group ike-grp-1 lifetime 28800",
            "set vpn ipsec ike-group ike-grp-1 mode main",
            "set vpn ipsec ike-group ike-grp-1 proposal 1 dh-group 14",
            "set vpn ipsec ike-group ike-grp-1 proposal 1 encryption aes256",
            "set vpn ipsec ike-group ike-grp-1 proposal 1 hash sha256"
        ],
        id="test_ipsec_set_ike_group"
    ),
    # ESP Group
    pytest.param(
        {
            "esp-group": {
                "esp-grp-1": {
                    "compression": {},
                    "lifetime": "3600",
                    "mode": "tunnel",
                    "pfs": "dh-group14",
                    "proposal": {
                        "1": {
                            "encryption": "aes256",
                            "hash": "sha256"
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec esp-group esp-grp-1 compression",
            "set vpn ipsec esp-group esp-grp-1 lifetime 3600",
            "set vpn ipsec esp-group esp-grp-1 mode tunnel",
            "set vpn ipsec esp-grp-1 pfs dh-group14",
            "set vpn ipsec esp-group esp-grp-1 proposal 1 encryption aes256",
            "set vpn ipsec esp-group esp-grp-1 proposal 1 hash sha256"
        ],
        id="test_ipsec_set_esp_group"
    ),
    # PSK Authentication
    pytest.param(
        {
            "authentication": {
                "psk": {
                    "psk-1": {
                        "id": "id-1",
                        "secret": "my-secret",
                        "secret-type": "plaintext"
                    }
                }
            }
        },
        [
            "set vpn ipsec authentication psk psk-1 id id-1",
            "set vpn ipsec authentication psk psk-1 secret my-secret",
            "set vpn ipsec authentication psk psk-1 secret-type plaintext"
        ],
        id="test_ipsec_set_psk"
    ),
    # Remote Access Pool
    pytest.param(
        {
            "remote-access": {
                "pool": {
                    "pool-1": {
                        "exclude": ["10.0.0.1/32", "10.0.0.2/32"],
                        "name-server": ["8.8.8.8", "8.8.4.4"],
                        "prefix": "10.0.0.0/24"
                    }
                }
            }
        },
        [
            "set vpn ipsec remote-access pool pool-1 exclude 10.0.0.1/32",
            "set vpn ipsec remote-access pool pool-1 exclude 10.0.0.2/32",
            "set vpn ipsec remote-access pool pool-1 name-server 8.8.8.8",
            "set vpn ipsec remote-access pool pool-1 name-server 8.8.4.4",
            "set vpn ipsec remote-access pool pool-1 prefix 10.0.0.0/24"
        ],
        id="test_ipsec_set_remote_access_pool"
    ),
    # Options with Retransmission
    pytest.param(
        {
            "options": {
                "interface": "eth0",
                "disable-route-autoinstall": {},
                "retransmission": {
                    "attempt": "5",
                    "base": "2.5",
                    "timeout": "30"
                }
            }
        },
        [
            "set vpn ipsec options interface eth0",
            "set vpn ipsec options disable-route-autoinstall",
            "set vpn ipsec options retransmission attempt 5",
            "set vpn ipsec options retransmission base 2.5",
            "set vpn ipsec options retransmission timeout 30"
        ],
        id="test_ipsec_set_options"
    ),
    # IKE Group with Dead Peer Detection
    pytest.param(
        {
            "ike-group": {
                "ike-grp-dpd": {
                    "dead-peer-detection": {
                        "action": "restart",
                        "interval": "30",
                        "timeout": "120"
                    },
                    "disable-mobike": {},
                    "ikev2-reauth": {}
                }
            }
        },
        [
            "set vpn ipsec ike-group ike-grp-dpd dead-peer-detection action restart",
            "set vpn ipsec ike-group ike-grp-dpd dead-peer-detection interval 30",
            "set vpn ipsec ike-group ike-grp-dpd dead-peer-detection timeout 120",
            "set vpn ipsec ike-group ike-grp-dpd disable-mobike",
            "set vpn ipsec ike-group ike-grp-dpd ikev2-reauth"
        ],
        id="test_ipsec_set_ike_group_dpd"
    ),
    # Remote Access Authentication with Local Users
    pytest.param(
        {
            "remote-access": {
                "connection": {
                    "conn-users": {
                        "authentication": {
                            "client-mode": "eap-mschapv2",
                            "server-mode": "pre-shared-secret",
                            "local-users": {
                                "username": {
                                    "user1": {
                                        "password": "pass1"
                                    },
                                    "user2": {
                                        "password": "pass2",
                                        "disable": {}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec remote-access connection conn-users authentication client-mode eap-mschapv2",
            "set vpn ipsec remote-access connection conn-users authentication server-mode pre-shared-secret",
            "set vpn ipsec remote-access connection conn-users authentication local-users username user1 password pass1",
            "set vpn ipsec remote-access connection conn-users authentication local-users username user2 password pass2",
            "set vpn ipsec remote-access connection conn-users authentication local-users username user2 disable"
        ],
        id="test_ipsec_set_remote_access_local_users"
    ),
    # RADIUS Configuration
    pytest.param(
        {
            "remote-access": {
                "radius": {
                    "nas-identifier": "nas-1",
                    "timeout": "30",
                    "server": {
                        "192.168.1.10": {
                            "port": "1812",
                            "key": "radius-secret"
                        },
                        "192.168.1.11": {
                            "disable": {},
                            "disable-accounting": {}
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec remote-access radius nas-identifier nas-1",
            "set vpn ipsec remote-access radius timeout 30",
            "set vpn ipsec remote-access radius server 192.168.1.10 port 1812",
            "set vpn ipsec remote-access radius server 192.168.1.10 key radius-secret",
            "set vpn ipsec remote-access radius server 192.168.1.11 disable",
            "set vpn ipsec remote-access radius server 192.168.1.11 disable-accounting"
        ],
        id="test_ipsec_set_radius"
    ),
    # VTI Binding
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-vti": {
                        "vti": {
                            "bind": "vti0"
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec site-to-site peer peer-vti vti bind vti0"
        ],
        id="test_ipsec_set_peer_vti"
    ),
    # Multiple IKE Proposals
    pytest.param(
        {
            "ike-group": {
                "ike-multi-proposal": {
                    "proposal": {
                        "1": {
                            "dh-group": "14",
                            "encryption": "aes256",
                            "hash": "sha256"
                        },
                        "2": {
                            "dh-group": "15",
                            "encryption": "aes128",
                            "hash": "sha1",
                            "prf": "sha256"
                        }
                    }
                }
            }
        },
        [
            "set vpn ipsec ike-group ike-multi-proposal proposal 1 dh-group 14",
            "set vpn ipsec ike-group ike-multi-proposal proposal 1 encryption aes256",
            "set vpn ipsec ike-group ike-multi-proposal proposal 1 hash sha256",
            "set vpn ipsec ike-group ike-multi-proposal proposal 2 dh-group 15",
            "set vpn ipsec ike-group ike-multi-proposal proposal 2 encryption aes128",
            "set vpn ipsec ike-group ike-multi-proposal proposal 2 hash sha1",
            "set vpn ipsec ike-group ike-multi-proposal proposal 2 prf sha256"
        ],
        id="test_ipsec_set_ike_multi_proposals"
    ),
    # ESP Group Advanced Options
    pytest.param(
        {
            "esp-group": {
                "esp-advanced": {
                    "disable-rekey": {},
                    "life-bytes": "1048576",
                    "life-packets": "1000000",
                    "mode": "transport"
                }
            }
        },
        [
            "set vpn ipsec esp-group esp-advanced disable-rekey",
            "set vpn ipsec esp-group esp-advanced life-bytes 1048576",
            "set vpn ipsec esp-group esp-advanced life-packets 1000000",
            "set vpn ipsec esp-group esp-advanced mode transport"
        ],
        id="test_ipsec_set_esp_advanced"
    )
]

test_delete = [
    pytest.param(
        {
            "site-to-site": {
                "peer": {
                    "peer-1": {}
                }
            }
        },
        [
            "delete vpn ipsec site-to-site peer peer-1"
        ],
        id="test_ipsec_delete_peer"
    ),
    pytest.param(
        {
            "remote-access": {
                "connection": {
                    "conn-delete": {}
                }
            }
        },
        [
            "delete vpn ipsec remote-access connection conn-delete"
        ],
        id="test_ipsec_delete_remote_access_connection"
    ),
    pytest.param(
        {
            "ike-group": {
                "ike-delete": {}
            }
        },
        [
            "delete vpn ipsec ike-group ike-delete"
        ],
        id="test_ipsec_delete_ike_group"
    ),
    pytest.param(
        {
            "esp-group": {
                "esp-delete": {}
            }
        },
        [
            "delete vpn ipsec esp-group esp-delete"
        ],
        id="test_ipsec_delete_esp_group"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                "set vpn ipsec site-to-site peer peer-1 authentication mode pre-shared-secret",
                "set vpn ipsec site-to-site peer peer-1 ike-group ike-group-1"
            ],
            {
                "vpn": {
                    "ipsec": {
                        "site-to-site": {
                            "peer": {
                                "peer-1": {
                                    "authentication": {
                                        "mode": "pre-shared-secret"
                                    },
                                    "ike-group": "ike-group-1"
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_ipsec"
    )
]
