from app.log.logger import logger
from app.core.operation.ip_options.parser import parse_to_ip_options_vyos_config
from app.core.operation.dhcp_options.parser import parse_to_dhcp_options_vyos_config

def has_value(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']

def parse_to_bridge_config(data: dict):

    if not data:
        return {}
    
    bridge_name = data.get('name')
    
    if not bridge_name:
        logger.error("Bridge name is required")
        return {}
    
    config = {}
    
    general = data.get('general') if isinstance(data.get('general'), dict) else {}
    if general:
        if general.get('description'):
            config['description'] = general['description']
        if general.get('enabled') is False:
            config['disable'] = {}

    if data.get('description'):
        config['description'] = data['description']
    if data.get('disabled'):
        config['disable'] = {}

    link = data.get('link') if isinstance(data.get('link'), dict) else {}
    if link:
        if has_value(link.get('mtu')):
            config['mtu'] = str(link['mtu'])
        if link.get('disableLinkDetect'):
            config['disable-link-detect'] = {}

    if has_value(data.get('mtu')):
        config['mtu'] = str(data['mtu'])
    if has_value(data.get('aging')):
        config['aging'] = str(data['aging'])
    elif has_value(link.get('macTimeout')):
        config['aging'] = str(link['macTimeout'])
    if data.get('disableLinkDetect'):
        config['disable-link-detect'] = {}

    network = data.get('network') if isinstance(data.get('network'), dict) else {}
    addresses = []
    if network:
        ipv4_config = network.get('ipv4') if isinstance(network.get('ipv4'), dict) else {}
        ipv6_config = network.get('ipv6') if isinstance(network.get('ipv6'), dict) else {}

        if ipv4_config:
            if ipv4_config.get('mode') == 'dhcp':
                addresses.append('dhcp')
            elif ipv4_config.get('mode') == 'static' and isinstance(ipv4_config.get('static'), dict):
                static_config = ipv4_config['static']
                if static_config.get('address'):
                    addresses.append(static_config['address'])

        if ipv6_config:
            if ipv6_config.get('mode') == 'dhcpv6':
                addresses.append('dhcpv6')
            elif ipv6_config.get('mode') == 'static' and isinstance(ipv6_config.get('static'), dict):
                static_config = ipv6_config['static']
                if static_config.get('address'):
                    addresses.append(static_config['address'])
            elif ipv6_config.get('mode') == 'autoconf':
                config.setdefault('ipv6', {}).setdefault('address', {})['autoconf'] = {}
            elif ipv6_config.get('mode') == 'delegated':
                config.setdefault('ipv6', {}).setdefault('address', {})['dhcpv6'] = {}

    # payload fallback
    ipv4_mode = data.get('ipv4Mode')
    ipv6_mode = data.get('ipv6Mode')

    if ipv4_mode == 'dhcp' and 'dhcp' not in addresses:
        addresses.append('dhcp')
    elif ipv4_mode == 'static':
        addr = data.get('ipv4Address')
        if addr and addr not in addresses:
            addresses.append(addr)

    if ipv6_mode == 'dhcpv6' and 'dhcpv6' not in addresses:
        addresses.append('dhcpv6')
    elif ipv6_mode == 'static':
        addr = data.get('ipv6Address')
        if addr and addr not in addresses:
            addresses.append(addr)
    elif ipv6_mode == 'autoconf':
        config.setdefault('ipv6', {}).setdefault('address', {})['autoconf'] = {}
    elif ipv6_mode == 'delegated':
        config.setdefault('ipv6', {}).setdefault('address', {})['dhcpv6'] = {}

    if data.get('addresses'):
        flat_addresses = data['addresses'] if isinstance(data['addresses'], list) else [data['addresses']]
        for addr in flat_addresses:
            if addr and addr not in addresses:
                addresses.append(addr)
        logger.debug(f"Found addresses field: {flat_addresses}")
    if data.get('ipv4Address'):
        addr = data['ipv4Address']
        logger.debug(f"Found ipv4Address field: {addr}")
        if addr and addr not in addresses:
            addresses.append(addr)
    if data.get('ipv6Address'):
        addr = data['ipv6Address']
        logger.debug(f"Found ipv6Address field: {addr}")
        if addr and addr not in addresses:
            addresses.append(addr)
    
    logger.debug(f"Final addresses list: {addresses}")
    if addresses:
        config['address'] = addresses
    
    # Handle members - support both 'members' list and 'member.members' structure
    members = []
    if data.get('members'):
        members = data['members'] if isinstance(data['members'], list) else [data['members']]
    elif data.get('member'):
        member_data = data['member']
        if isinstance(member_data, dict) and 'members' in member_data:
            members = member_data['members'] if isinstance(member_data['members'], list) else [member_data['members']]
        elif isinstance(member_data, list):
            members = member_data
    
    if members:
        config['member'] = {
            'interface': {member: {} for member in members}
        }
    
    if data.get('ip'):
        ip_result, ipv6_result = parse_to_ip_options_vyos_config(data['ip'])
        
        if ip_result:
            config['ip'] = ip_result
        if ipv6_result:
            config['ipv6'] = ipv6_result
    
    if data.get('dhcp'):
        dhcp_result, dhcpv6_result = parse_to_dhcp_options_vyos_config(data['dhcp'])
        
        if dhcp_result:
            config['dhcp-options'] = dhcp_result
        if dhcpv6_result:
            config['dhcpv6-options'] = dhcpv6_result
    
    result = {bridge_name: config}
    logger.debug(f"Parsed bridge config: {result}")
    return result


def parse_current_bridge_interface_config(os_config: dict, bridge_name: str):

    try:
        bridges = os_config.get('interfaces', {}).get('bridge', {})
        if bridge_name in bridges:
            return {bridge_name: bridges[bridge_name]}
        return {}
    except Exception as e:
        logger.error(f"Error parsing current bridge config: {e}")
        return {}
