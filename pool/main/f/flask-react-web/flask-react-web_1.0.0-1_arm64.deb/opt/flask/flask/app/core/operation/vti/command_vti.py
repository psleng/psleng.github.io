from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

def format_description(description: str) -> str:
    return description.replace(' ', '_')

class VTICommand(IfaceCommand):
    """
    Command class for VTI Interface:
    set/delete interfaces vti <interface_name>

    """
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'vti'),
                name=self.name
            )
            self.attributes = {
                'interfaces': {
                    'vti': {
                        self.name: {}
                    }
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing VTI command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []
        
        self.attributes['interfaces']['vti'] = data

        for iface_name, iface_config in self.attributes['interfaces']['vti'].items():
            base_path = ['interfaces', 'vti', iface_name]
            self.generate(*base_path)

        print(f"Generated commands: {self.cmds}")
        return self.cmds
    
    def delete_vti_interface(self, interface_name):
        self.generate('interfaces', 'vti', interface_name)

if __name__ == "__main__":
    pass