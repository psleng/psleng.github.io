import pytest
import json
import requests
from app.core.api.http.http_request import Action
import pprint

class TestOpenVPNEndpointUpdate_2:
    

    @classmethod
    def setup_class(cls):

        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as e:
            print(f"Registration error (user may already exist): {e}")

    def _delete_and_login(self, test_service_provider):
        
        DELETE_OPENVPN = '{"op": "delete", "path": ["interfaces", "openvpn"]}'
        delete_response = test_service_provider.http_service.send_request(
            action=Action.CONFIGURE, data=DELETE_OPENVPN, verify=False
        )
        
        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def _get_base_config(self):

        return {
            "general": {
                "name": "vtun0",
                "description": "Initial Description",
                "mode": "site-to-site",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localHost": ["192.168.1.1"],
                "localPort": "1194",
                "localAddress": "10.0.0.1",
                "remoteHost": ["203.0.113.1"],
                "remotePort": "1194",
                "remoteAddress": "10.0.0.2",
                "protocol": "udp",
                "server": {
                    "bridge": "",
                    "subnet": "",
                    "topology": "subnet",
                    "domainName": "",
                    "maxConnections": None,
                    "nameServer": [],
                    "clients": [],
                    "clientIpPool": {
                        "disabled": True,
                        "start": "",
                        "stop": "",
                        "subnetMask": ""
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": True,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ['testCA'],
                    "certificate": ['testCert'],
                    "cryptKey": [],
                    "dhParams": "",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "",
                    "dataCiphers": []
                },
                "hash": {
                    "algorithm": "sha256"
                },
                "sharedSecretKey": "vpn-secret"
            }
        }

    def test_update_endpoint_4_modify_keepalive(self, test_service_provider):

        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["advanced"]["keepAlive"]["interval"] = 20
        updated_config["openvpn"]["advanced"]["keepAlive"]["failureCount"] = 5
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert vtun0_config['keep-alive']['interval'] == '20'
        assert vtun0_config['keep-alive']['failure-count'] == '5'
        print("Keepalive update verification successful")

    def test_update_endpoint_5_modify_addresses(self, test_service_provider):

        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["localAddress"] = "10.0.0.10"
        updated_config["openvpn"]["remoteAddress"] = "10.0.0.20"
        updated_config["openvpn"]["localHost"] = ["192.168.1.10"]
        updated_config["openvpn"]["remoteHost"] = ["203.0.113.10"]
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        print("\n=== Update Commands for Address Changes ===")
        for item in response_data:
            print(f"Command: {item.get('cmd', 'N/A')}")
            print(f"Success: {item.get('success', False)}")
            if not item.get('success', False):
                print(f"Update failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        print("\n=== Fetched Config ===")
        pprint.pprint(vtun0_config)
        
        assert '10.0.0.10' in vtun0_config['local-address'], \
            f"Expected '10.0.0.10' in local-address, got: {vtun0_config['local-address']}"
        assert vtun0_config['remote-address'] == '10.0.0.20', \
            f"Expected remote-address '10.0.0.20', got: {vtun0_config['remote-address']}"
        assert vtun0_config['local-host'] == '192.168.1.10', \
            f"Expected local-host '192.168.1.10', got: {vtun0_config['local-host']}"
        assert vtun0_config['remote-host'] == '203.0.113.10', \
            f"Expected remote-host '203.0.113.10', got: {vtun0_config['remote-host']}"
        print("Address update verification successful")

    def test_update_endpoint_6_modify_protocol(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["protocol"] = "tcp-active"
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert vtun0_config['protocol'] == 'tcp-active'
        print("Protocol update verification successful")

    def test_update_endpoint_7_modify_compression(self, test_service_provider):

        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["advanced"]["useLzoCompression"] = False
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert 'use-lzo-compression' not in vtun0_config
        print("Compression update verification successful")

    def test_update_endpoint_8_modify_multiple_fields(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        # Update multiple fields
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["general"]["description"] = "Multi Field Update Test"
        updated_config["openvpn"]["localPort"] = "1195"
        updated_config["openvpn"]["remotePort"] = "1195"
        updated_config["security"]["hash"]["algorithm"] = "sha512"
        updated_config["openvpn"]["advanced"]["keepAlive"]["interval"] = 15
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        # Verify all changes
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert vtun0_config['description'] == 'Multi_Field_Update_Test'
        assert vtun0_config['local-port'] == '1195'
        assert vtun0_config['remote-port'] == '1195'
        assert vtun0_config['hash'] == 'sha512'
        assert vtun0_config['keep-alive']['interval'] == '15'
        print("Multiple field update verification successful")

    def test_update_endpoint_9_modify_device_type(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["deviceType"] = "tap"
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert vtun0_config['device-type'] == 'tap'
        print("Device type update verification successful")

    def test_update_endpoint_10_modify_persistent_tunnel(self, test_service_provider):

        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_base_config()
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        import copy
        updated_config = copy.deepcopy(initial_config)
        updated_config["openvpn"]["advanced"]["persistentTunnel"] = False
        
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200
        
        # Verify
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, data=FETCH_OPENVPN, verify=False
        )
        vtun0_config = fetch_response.json()['data']['openvpn']['vtun0']
        
        assert 'persistent-tunnel' not in vtun0_config
        print("Persistent tunnel update verification successful")
