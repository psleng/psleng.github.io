from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
from app.core.operation.ip_options.command_ip_options import IPOptionCommand
import json
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

def has_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ''
    return True

class L2TPv3Command(IfaceCommand):
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'l2tpv3'),
                name=self.name
            )
            self.attributes = {
                'interfaces': {
                    'l2tpv3': {
                        self.name: {}
                    }
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing L2TPv3 command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        command = {
            "op": self.operator,
            "path": list(path_elements)
        }
        return json.dumps(command)

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []
        curr_config = deepcopy(current_config) if current_config else deepcopy(data)
        
        self.attributes['interfaces']['l2tpv3'] = data

        for iface_name, iface_config in self.attributes['interfaces']['l2tpv3'].items():
            base_path = ['interfaces', 'l2tpv3', iface_name]

            if self.operator == 'delete' and (not isinstance(new_config, dict) or iface_name not in new_config):
                self.generate(*base_path)
                continue

            if 'disable' in iface_config and iface_config.get('disable') is not False:
                self.generate(*base_path, 'disable')
            
            if 'description' in iface_config and has_value(iface_config['description']):
                self.generate(*base_path, 'description', iface_config['description'])
            
            if 'address' in iface_config and isinstance(iface_config['address'], dict):
                for ip_addr in iface_config['address'].keys():
                    self.generate(*base_path, 'address', ip_addr)
            
            if 'peer-session-id' in iface_config and is_str_not_empty(iface_config['peer-session-id']):
                self.generate(*base_path, 'peer-session-id', iface_config['peer-session-id'])
            
            if 'peer-tunnel-id' in iface_config and is_str_not_empty(iface_config['peer-tunnel-id']):
                self.generate(*base_path, 'peer-tunnel-id', iface_config['peer-tunnel-id'])
            
            if 'remote' in iface_config and is_str_not_empty(iface_config['remote']):
                self.generate(*base_path, 'remote', iface_config['remote'])
            
            if 'session-id' in iface_config and is_str_not_empty(iface_config['session-id']):
                self.generate(*base_path, 'session-id', iface_config['session-id'])
            
            if 'source-address' in iface_config and is_str_not_empty(iface_config['source-address']):
                self.generate(*base_path, 'source-address', iface_config['source-address'])
            
            if 'tunnel-id' in iface_config and is_str_not_empty(iface_config['tunnel-id']):
                self.generate(*base_path, 'tunnel-id', iface_config['tunnel-id'])
            
            if 'source-port' in iface_config and is_str_not_empty(iface_config['source-port']):
                self.generate(*base_path, 'source-port', iface_config['source-port'])
            
            if 'destination-port' in iface_config and is_str_not_empty(iface_config['destination-port']):
                self.generate(*base_path, 'destination-port', iface_config['destination-port'])
            
            if 'encapsulation' in iface_config and is_str_not_empty(iface_config['encapsulation']):
                self.generate(*base_path, 'encapsulation', iface_config['encapsulation'])
            
            if 'mtu' in iface_config and is_str_not_empty(iface_config['mtu']):
                self.generate(*base_path, 'mtu', iface_config['mtu'])
            
            if 'ip' in iface_config or 'ipv6' in iface_config:
                ip_cmd = IPOptionCommand(
                    operator=self.operator,
                    intf_type='l2tpv3',
                    intf_name=iface_name
                )
                ip_cmds = ip_cmd.generate_commands(data={'ip': iface_config.get('ip', {}), 'ipv6': iface_config.get('ipv6', {})})
                self.cmds.extend(ip_cmds)
                self.vyos_cmds.extend(ip_cmd.get_commands())

        return self.cmds
