import json

from app.core.api.http.cmd.command import Command


class PasswordPolicyCommand(Command):

    _parameters = {
        'minimum-length': (9, 20),
        'minimum-digit': (1, 8),
        'minimum-uppercase': (1, 8),
        'minimum-special': (1, 8),
    }

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource='system',
        )
        self.attributes = {}
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        return json.dumps(
            {'op': self.operator, 'path': list(path_elements)},
            separators=(',', ':'),
        )

    def generate(self, *args):
        if not args:
            return
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    @staticmethod
    def _get_password_policy(data):
        login = data.get('login', {})
        enhanced_policy = (
            login.get('enhanced-policy')
            or login.get('enhanced_policy')
            or {}
        )
        return enhanced_policy.get('password')

    def _process_password_policy(self, password_policy):
        base_path = [
            'system',
            'login',
            'enhanced-policy',
            'password',
        ]

        for cli_name, (minimum, maximum) in self._parameters.items():
            value = password_policy.get(
                cli_name,
                password_policy.get(cli_name.replace('-', '_')),
            )
            if value is None:
                continue

            if self.operator == 'set':
                value = int(value)
                if not minimum <= value <= maximum:
                    raise ValueError(
                        f'{cli_name} must be between {minimum} and {maximum}'
                    )
                self.generate(*base_path, cli_name, str(value))
            elif self.operator == 'delete':
                self.cmds.append(self._build_command(*base_path, cli_name))
                self.vyos_cmds.append(
                    ' '.join(map(str, (*base_path, cli_name, value)))
                )
            else:
                raise ValueError(
                    'Password policy operator must be set or delete'
                )

    def generate_commands(
        self,
        data=None,
        current_config=None,
        new_config=None,
    ):
        if not data or 'login' not in data:
            return []

        password_policy = self._get_password_policy(data)
        if not isinstance(password_policy, dict):
            return []

        self._process_password_policy(password_policy)
        return self.cmds
