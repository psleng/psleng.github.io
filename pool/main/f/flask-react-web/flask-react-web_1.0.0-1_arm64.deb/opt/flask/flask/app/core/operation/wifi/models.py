from app.db.database import db
from pydantic import BaseModel
from sqlalchemy import Boolean, Column, Integer, String
import pprint
from app.core.operation.wifi.parser import parse_wifi_config


class WiFiInterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_wifi_interface'

    id = Column(Integer, primary_key=True)
    ap_enable = Column(Boolean, default=True)
    ap_enable5 = Column(Boolean, default=True)
    ap_enable24 = Column(Boolean, default=True)
    ap_description = Column(String, nullable=True)
    ap_ssid = Column(String, nullable=True)
    ap_password = Column(String, nullable=True)
    ap_security = Column(String, nullable=True)
    ap_encryption = Column(String, nullable=True)
    ap_hidden_ssid = Column(Boolean, default=False)
    ap_prevent_low = Column(Boolean, default=False)
    ap_management_frame = Column(String, nullable=True)
    ap_mode = Column(String, nullable=True)

    ap_bridge_mode = Column(Boolean, default=True)
    ap_ipv4_mode = Column(String, nullable=True)
    ap_ipv4_address = Column(String, nullable=True)
    ap_ipv4_length = Column(String, nullable=True)
    ap_ipv4_bridge = Column(String, nullable=True)

    ap_ipv6_mode = Column(String, nullable=True)
    ap_ipv6_address = Column(String, nullable=True)
    ap_ipv6_length = Column(String, nullable=True)

    ap_acl_mode = Column(String, nullable=True)
    ap_acl_accept = Column(String, nullable=True)
    ap_acl_deny = Column(String, nullable=True)

    ap_ac_channel_width = Column(String, nullable=True)
    ap_ax_channel_width = Column(String, nullable=True)
    ap_n_channel_width = Column(String, nullable=True)

    client_enable = Column(Boolean, default=True)
    client_enable5 = Column(Boolean, default=True)
    client_enable24 = Column(Boolean, default=True)
    client_ssid = Column(String, nullable=True)
    client_password = Column(String, nullable=True)
    client_security = Column(String, nullable=True)

    client_default_route_distance_5 = Column(String, nullable=True)
    client_default_route_distance_24 = Column(String, nullable=True)

    client_bridge_mode = Column(Boolean, default=True)
    client_ipv4_mode = Column(String, nullable=True)
    client_ipv4_address = Column(String, nullable=True)
    client_ipv4_length = Column(String, nullable=True)

    client_ipv6_mode = Column(String, nullable=True)
    client_ipv6_address = Column(String, nullable=True)
    client_ipv6_length = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def get_ssid(cls):
        ap_ssid = getattr(cls, 'ap_ssid')
        client_ssid = getattr(cls, 'client_ssid')
        return db.session.query(ap_ssid, client_ssid).first()
    
    @classmethod
    def refresh(cls, data: dict, conf_data: dict, config_type: str):
        try:
            print("Refresh WiFi interface data")
            fixed_bridge = "br1"
            if config_type == "api":
                if hasattr(conf_data, "json") and callable(conf_data.json):
                    conf_data = conf_data.json()['data']
                conf = parse_wifi_config(conf_data, fixed_bridge)
            elif config_type == "full":
                conf = conf_data

            ap_prevent_low = conf.get('ap_prevent_low')
            if isinstance(ap_prevent_low, dict):
                ap_prevent_low = True
            else:
                ap_prevent_low = bool(ap_prevent_low)

            encryption = conf.get('ap_encryption')
            if isinstance(encryption, list):
                encryption = ','.join(encryption)

            acl_accept = conf.get('ap_acl_accept')
            if isinstance(acl_accept, list):
                acl_accept = ','.join(acl_accept)
            
            acl_deny = conf.get('ap_acl_deny')
            if isinstance(acl_deny, list):
                acl_deny = ','.join(acl_deny)

            n_channel_width = conf.get('ap_n_channel_width')
            if isinstance(n_channel_width, list):
                n_channel_width = ','.join(n_channel_width)

            cls.truncate()
            new_data = cls(
                ap_enable=conf.get('ap_enable'),
                ap_enable5=conf.get('ap_enable5'),
                ap_enable24=conf.get('ap_enable24'),
                ap_description=conf.get('ap_description'),
                ap_ssid=conf.get('ap_ssid'),
                ap_password=conf.get('ap_password'),
                ap_security=conf.get('ap_security'),
                ap_mode=conf.get('ap_mode'),
                ap_encryption=encryption,
                ap_hidden_ssid=conf.get('ap_hidden_ssid'),
                ap_prevent_low=ap_prevent_low,
                ap_management_frame=conf.get('ap_management_frame'),
                ap_bridge_mode=conf.get('ap_bridge_mode'),
                ap_ipv4_mode=conf.get('ap_ipv4_mode'),
                ap_ipv4_address=conf.get('ap_ipv4_address'),
                ap_ipv4_length=conf.get('ap_ipv4_length'),
                ap_ipv4_bridge=fixed_bridge,
                ap_ipv6_mode=conf.get('ap_ipv6_mode'),
                ap_ipv6_address=conf.get('ap_ipv6_address'),
                ap_ipv6_length=conf.get('ap_ipv6_length'),
                ap_acl_accept=acl_accept,
                ap_acl_deny=acl_deny,
                ap_acl_mode=conf.get('ap_acl_mode'),
                ap_ac_channel_width=conf.get('ap_ac_channel_width'),
                ap_ax_channel_width=conf.get('ap_ax_channel_width'),
                ap_n_channel_width=n_channel_width,
                client_enable=conf.get('client_enable'),
                client_enable5=conf.get('client_enable5'),
                client_enable24=conf.get('client_enable24'),
                client_ssid=conf.get('client_ssid'),
                client_password=conf.get('client_password'),
                client_security=conf.get('client_security'),
                client_bridge_mode=conf.get('client_bridge_mode'),
                client_ipv4_mode=conf.get('client_ipv4_mode'),
                client_ipv4_address=conf.get('client_ipv4_address'),
                client_ipv4_length=conf.get('client_ipv4_length'),
                client_ipv6_mode=conf.get('client_ipv6_mode'),
                client_ipv6_address=conf.get('client_ipv6_address'),
                client_ipv6_length=conf.get('client_ipv6_length'),
                client_default_route_distance_5=conf.get('client_default_route_distance_5'),
                client_default_route_distance_24=conf.get('client_default_route_distance_24')
            )
            db.session.add(new_data)
            db.session.commit()
        except Exception as e:
            print("Error refreshing WiFi interface data:", str(e))
            raise e
        
    def serialize(self):
        # Split encryption string and filter out empty strings
        encryption = [e for e in self.ap_encryption.split(',') if e.strip() != ""] if self.ap_encryption else []
        acl_accept = [a for a in self.ap_acl_accept.split(',') if a.strip() != ""] if self.ap_acl_accept else []
        acl_deny = [d for d in self.ap_acl_deny.split(',') if d.strip() != ""] if self.ap_acl_deny else []
        n_channel_width = [c for c in self.ap_n_channel_width.split(',') if c.strip() != ""] if self.ap_n_channel_width else []
        return {
            "ap_enable": self.ap_enable,
            "ap_enable5": self.ap_enable5,
            "ap_enable24": self.ap_enable24,
            "ap_description": self.ap_description,
            "ap_ssid": self.ap_ssid,
            "ap_password": self.ap_password,
            "ap_security": self.ap_security,
            "ap_mode": self.ap_mode,
            "ap_encryption": encryption,
            "ap_hidden_ssid": self.ap_hidden_ssid,
            "ap_prevent_low": self.ap_prevent_low,
            "ap_management_frame": self.ap_management_frame,
            "ap_bridge_mode": self.ap_bridge_mode,
            "ap_ipv4_mode": self.ap_ipv4_mode,
            "ap_ipv4_address": self.ap_ipv4_address,
            "ap_ipv4_length": self.ap_ipv4_length,
            "ap_ipv4_bridge": self.ap_ipv4_bridge,
            "ap_ipv6_mode": self.ap_ipv6_mode,
            "ap_ipv6_address": self.ap_ipv6_address,
            "ap_ipv6_length": self.ap_ipv6_length,
            "ap_acl_accept": acl_accept,
            "ap_acl_deny": acl_deny,
            "ap_acl_mode": self.ap_acl_mode,
            "ap_ac_channel_width": self.ap_ac_channel_width,
            "ap_ax_channel_width": self.ap_ax_channel_width,
            "ap_n_channel_width": n_channel_width,
            "client_enable": self.client_enable,
            "client_enable5": self.client_enable5,
            "client_enable24": self.client_enable24,
            "client_ssid": self.client_ssid,
            "client_password": self.client_password,
            "client_security": self.client_security,
            "client_bridge_mode": self.client_bridge_mode,
            "client_ipv4_mode": self.client_ipv4_mode,
            "client_ipv4_address": self.client_ipv4_address,
            "client_ipv4_length": self.client_ipv4_length,
            "client_ipv6_mode": self.client_ipv6_mode,
            "client_ipv6_address": self.client_ipv6_address,
            "client_ipv6_length": self.client_ipv6_length,
            "client_default_route_distance_5": self.client_default_route_distance_5,
            "client_default_route_distance_24": self.client_default_route_distance_24
        }