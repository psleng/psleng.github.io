from __future__ import annotations

import ast
import re
from datetime import datetime, timezone, tzinfo
from typing import Any, Dict, List, Optional, Sequence, Union

_COMMIT_LINE = re.compile(
    r"""^\s*(?P<rev>\d+)\s+
         (?P<time>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})\s+
         by\s+(?P<user>\S+)\s+
         via\s+(?P<via>\S+)
         (?:\s+(?P<comment>.*\S))?\s*$""",
    re.VERBOSE,
)

_LOOSE_COMMIT_LINE = re.compile(
    r"^\s*(?P<rev>\d+)\s+(?P<rest>\S.*\S)\s*$",
)


def _as_int(value: Any) -> Optional[int]:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def format_commit_timestamp(value: Any, tz: Optional[tzinfo] = None) -> str:
    if value in (None, ''):
        return ''

    seconds = _as_int(value)
    if seconds is None:
        return str(value)

    try:
        return datetime.fromtimestamp(seconds, tz=tz or timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    except (OverflowError, OSError, ValueError):
        return str(value)


def _row_from_entry(
    entry: Dict[str, Any], index: int, raw: str, tz: Optional[tzinfo] = None
) -> Dict[str, Any]:
    rev = _as_int(entry.get('rev'))
    if rev is None:
        rev = index

    timestamp = entry.get('timestamp')
    return {
        'rev': rev,
        'time': format_commit_timestamp(timestamp, tz),
        'timestamp': _as_int(timestamp),
        'user': str(entry.get('user') or ''),
        'via': str(entry.get('commit_via') or entry.get('via') or ''),
        'comment': str(entry.get('commit_comment') or entry.get('comment') or ''),
        'raw': raw,
    }


def _row_from_line(line: str, index: int, tz: Optional[tzinfo] = None) -> Dict[str, Any]:
    text = line.rstrip()

    stripped = text.strip()
    if stripped.startswith('{'):
        try:
            entry = ast.literal_eval(stripped)
        except (ValueError, SyntaxError):
            entry = None
        if isinstance(entry, dict):
            return _row_from_entry(entry, index, text, tz)

    match = _COMMIT_LINE.match(text)
    if match:
        return {
            'rev': int(match.group('rev')),
            'time': match.group('time'),
            'timestamp': None,
            'user': match.group('user'),
            'via': match.group('via'),
            'comment': match.group('comment') or '',
            'raw': text,
        }

    loose = _LOOSE_COMMIT_LINE.match(text)
    if loose:
        return {
            'rev': int(loose.group('rev')),
            'time': '',
            'timestamp': None,
            'user': '',
            'via': '',
            'comment': loose.group('rest'),
            'raw': text,
        }

    return {
        'rev': None,
        'time': '',
        'timestamp': None,
        'user': '',
        'via': '',
        'comment': '',
        'raw': text,
    }


def parse_commit_log(
    raw: Union[str, Sequence[Any], None], tz: Optional[tzinfo] = None
) -> List[Dict[str, Any]]:

    if raw is None or raw == '':
        return []

    if isinstance(raw, dict):
        return [_row_from_entry(raw, 0, str(raw), tz)]

    if isinstance(raw, (list, tuple)):
        rows: List[Dict[str, Any]] = []
        for entry in raw:
            if isinstance(entry, dict):
                rows.append(_row_from_entry(entry, len(rows), str(entry), tz))
            elif isinstance(entry, str) and entry.strip():
                rows.append(_row_from_line(entry, len(rows), tz))
        return rows

    rows = []
    for line in str(raw).splitlines():
        if not line.strip():
            continue
        rows.append(_row_from_line(line, len(rows), tz))
    return rows


def _mapping_from_repr(text: str) -> Optional[Dict[str, Any]]:
    stripped = text.strip()
    if not (stripped.startswith('{') and stripped.endswith('}')):
        return None
    try:
        value = ast.literal_eval(stripped)
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        return None
    return value if isinstance(value, dict) else None


def extract_config_text(result: Any, rev: Optional[int] = None) -> str:

    if result is None:
        return ''

    if isinstance(result, dict):
        if not result:
            return ''

        if rev is not None:
            preferred = result.get(f'config_revision_{rev}')
            if preferred is not None:
                return extract_config_text(preferred)

        for key in result:
            if str(key).startswith('config_revision') or str(key).startswith('config_diff'):
                return extract_config_text(result[key])

        if len(result) == 1:
            return extract_config_text(next(iter(result.values())))

        return '\n'.join(
            extract_config_text(result[key]) for key in sorted(result, key=str)
        )

    if isinstance(result, (list, tuple)):
        return '\n'.join(extract_config_text(item) for item in result)

    text = str(result)
    mapping = _mapping_from_repr(text)
    if mapping is not None:
        return extract_config_text(mapping, rev)
    return text


def parse_commit_revisions(config_subtree: Any) -> Optional[int]:

    if not isinstance(config_subtree, dict):
        return None

    value = config_subtree.get('commit-revisions')
    if isinstance(value, list):
        value = value[0] if value else None
    if value in (None, ''):
        return None

    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def parse_diff_commands(raw: Optional[str]) -> List[str]:

    if not raw:
        return []

    commands: List[str] = []
    for line in str(raw).splitlines():
        command = line.strip()
        if not command:
            continue
        if not (command.startswith('set ') or command.startswith('delete ')):
            continue
        commands.append(command)

    return list(dict.fromkeys(commands))


def command_to_configure_op(command: str) -> Dict[str, Any]:
    parts = command.split()
    if not parts:
        raise ValueError('Cannot convert an empty command')

    operator = parts[0].lower()
    if operator not in ('set', 'delete'):
        raise ValueError(f'Unsupported command operator: {operator}')

    path: List[str] = []
    for token in parts[1:]:
        path.append(token.strip("'\""))

    return {'op': operator, 'path': path}
