SERIAL_TRANSPORTS = ('login', 'modbus-gateway', 'nine-bits', 'ppp', 'remote-printer', 'serial-tunnel', 'slip', 'ssh', 'tcp', 'telnet', 'trueport', 'udp', 'virtual-modem')

SERIAL_TAG_PATHS = (
    ['device'],
    ['profile', 'tty-profile'],
    ['global-parameters', 'tls', 'template'],
    ['global-parameters', 'tls', 'template', '*', 'cipher-options'],
    ['global-parameters', 'virtual-modem', 'directory-entry'],
    ['device', '*', 'modbus-gateway', 'master', 'slave-mapping-list', 'entry'],
    ['device', '*', 'modbus-gateway', 'slave', 'remap-uid-list', 'entry'],
    ['device', '*', 'tcp', 'client', 'remote', 'multi-host', 'entry'],
    ['device', '*', 'trueport', 'client', 'remote', 'multi-host', 'entry'],
    ['device', '*', 'udp', 'rule'],
    ['profile', 'tty-profile', '*', 'modbus-gateway', 'master', 'slave-mapping-list', 'entry'],
    ['profile', 'tty-profile', '*', 'tcp', 'client', 'remote', 'multi-host', 'entry'],
    ['profile', 'tty-profile', '*', 'trueport', 'client', 'remote', 'multi-host', 'entry'],
    ['profile', 'tty-profile', '*', 'udp', 'rule'],
)
