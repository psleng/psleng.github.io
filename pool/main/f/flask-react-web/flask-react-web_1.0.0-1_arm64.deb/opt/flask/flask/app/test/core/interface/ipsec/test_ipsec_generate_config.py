import pytest
from app.test.core.base import TestGenerateConfig
from app.core.operation.ipsec.command_ipsec import IpsecCommand
from app.core.utils.process_config import process_commands

from app.test.core.interface.ipsec.test_cases._test_case_generate_config import (
    test_set,
    test_delete,
    test_process_commands
)

test_set_params = [
    pytest.param(
        (test_case.values[0], test_case.values[1]),
        id=test_case.id
    ) for test_case in test_set
]

test_delete_params = [
    pytest.param(
        (test_case.values[0], test_case.values[1]),
        id=test_case.id
    ) for test_case in test_delete
]

test_process = [
    pytest.param(
        commands, dict_config,
        id=test_case.id
    ) for test_case in test_process_commands
    for commands, dict_config in [test_case.values[0]]
]


class TestIPSecCommand(TestGenerateConfig):
    __test__ = True

    @pytest.fixture
    def cmd_class(self):
        return IpsecCommand

    @pytest.fixture
    def resource(self):
        return 'ipsec'

    @pytest.fixture
    def cmd(self):
        return IpsecCommand()
    
    @pytest.fixture
    def cmd_set(self):
        return IpsecCommand(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return IpsecCommand(operator='delete')
    
    def test_ipsec_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    
    def test_ipsec_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)
    
    @pytest.mark.parametrize("test_data", test_set_params)
    def test_generate_commands_set(self, cmd_set, test_data):
        super().test_generate_commands_set(cmd_set, test_data)
    
    @pytest.mark.parametrize("test_data", test_delete_params)
    def test_generate_commands_delete(self, cmd_delete, test_data):
        super().test_generate_commands_delete(cmd_delete, test_data)
    
    @pytest.mark.parametrize("commands,dict_config", test_process)
    def test_process_commands(self, commands, dict_config):
        """Test process_commands functionality"""
        config = process_commands(commands)
        assert config == dict_config
    
    def test_get_commands_empty(self):
        super().test_get_commands_empty(IpsecCommand)
