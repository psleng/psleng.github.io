import json
from typing import Any, Dict, List, Optional

from app.core.api.http.cmd.command import Command


class EmailCommand(Command):
    
    PROFILE_FIELDS = (
        'authentication', 'ca-file', 'from-email', 'password', 'port',
        'security', 'smtp-host', 'username',
    )
    OAUTH2_FIELDS = ('client-id', 'client-secret', 'refresh-token', 'scope', 'token-url')

    def __init__(self, operator: str = 'set', config: Optional[dict] = None):
        super().__init__(operator=operator, resource='email')
        self.config = config or {}
        self.cmds: List[str] = []
        self.vyos_cmds: List[str] = []

    def _build_command(self, *path_elements: str) -> str:
        return json.dumps({'op': self.operator, 'path': list(path_elements)})

    def generate(self, *path_elements: str):
        self.cmds.append(self._build_command(*path_elements))
        self.vyos_cmds.append(' '.join(map(str, path_elements)))

    def get_commands(self) -> List[str]:
        return self.vyos_cmds

    @staticmethod
    def generate_test_email(message: str) -> str:
        return json.dumps({
            'op': 'generate',
            'path': ['test-email', 'message', message],
        })

    def generate_commands(
        self,
        data: Optional[Dict[str, Any]] = None,
        current_config: Optional[Dict[str, Any]] = None,
        new_config: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        del current_config
        config = data if isinstance(data, dict) else {}
        next_config = new_config if isinstance(new_config, dict) else {}
        if self.operator == 'delete':
            self._process_active_profile(config)
            self._process_profiles(config.get('profile'), next_config.get('profile'))
        else:
            self._process_profiles(config.get('profile'), next_config.get('profile'))
            self._process_active_profile(config)
        self._process_recipients(config.get('recipient'), next_config.get('recipient'))
        return self.cmds

    def _process_profiles(self, profiles: Any, new_profiles: Any):
        if not isinstance(profiles, dict):
            return
        next_profiles = new_profiles if isinstance(new_profiles, dict) else {}
        for name, profile_data in profiles.items():
            base_path = ['system', 'email', 'profile', str(name)]
            if self.operator == 'delete' and name not in next_profiles:
                self.generate(*base_path)
                continue
            if not isinstance(profile_data, dict) or not profile_data:
                self.generate(*base_path)
                continue
            for field in self.PROFILE_FIELDS:
                if field in profile_data:
                    self._process_value(base_path + [field], profile_data.get(field))
            if 'no-validate-cert' in profile_data:
                self._process_flag(base_path + ['no-validate-cert'], profile_data.get('no-validate-cert'))
            oauth2 = profile_data.get('oauth2')
            if isinstance(oauth2, dict):
                for field in self.OAUTH2_FIELDS:
                    if field in oauth2:
                        self._process_value(base_path + ['oauth2', field], oauth2.get(field))

    def _process_active_profile(self, config: Dict[str, Any]):
        if 'active-profile' not in config:
            return
        self._process_value(['system', 'email', 'active-profile'], config.get('active-profile'))

    def _process_recipients(self, recipients: Any, new_recipients: Any):
        if not isinstance(recipients, dict):
            return
        next_recipients = new_recipients if isinstance(new_recipients, dict) else {}
        for name, recipient_data in recipients.items():
            base_path = ['system', 'email', 'recipient', str(name)]
            if self.operator == 'delete' and name not in next_recipients:
                self.generate(*base_path)
                continue
            if not isinstance(recipient_data, dict) or not recipient_data:
                self.generate(*base_path)
                continue
            for field in ('email', 'subject'):
                if field in recipient_data:
                    self._process_value(base_path + [field], recipient_data.get(field))
            if 'enable' in recipient_data:
                self._process_flag(base_path + ['enable'], recipient_data.get('enable'))

    def _process_value(self, path: List[str], value: Any):
        if self.operator == 'delete':
            self.generate(*path)
        elif value is not None and str(value) != '':
            self.generate(*(path + [str(value)]))

    def _process_flag(self, path: List[str], value: Any):
        if self.operator == 'delete':
            self.generate(*path)
        elif value is not False and value is not None:
            self.generate(*path)
