JOB_INTERVALS = {
    "realtime": 5,
    "quick": 10,
    "normal": 30,
    "slow": 60,
    "nslow": 120,
    "xslow": 300,
    "xxslow": 600,
    "xxxslow": 900,
    "storage": 120,
}

JOB_CONFIGS = {
    'fetch_init_service_stat': JOB_INTERVALS['xslow'],   
    'fetch_interfaces_operation': JOB_INTERVALS['xxxslow'],
    'fetch_memory': JOB_INTERVALS['slow'],           
    'fetch_system_info': JOB_INTERVALS['xxxslow'],
    'fetch_firewall_opr': JOB_INTERVALS['xslow'],             
    'fetch_firewall_opr_log': JOB_INTERVALS['xslow'],         
    'fetch_os_config': JOB_INTERVALS['xslow'],                
    'fetch_service_stat': JOB_INTERVALS['xxxslow'],
    'check_vyos_http_api': JOB_INTERVALS['normal'],
    'check_software_update_available': JOB_INTERVALS['xxslow'],
    'save_recent_config': JOB_INTERVALS['xxxslow'],
    "refresh_cloud_sessions": JOB_INTERVALS["realtime"],
}
