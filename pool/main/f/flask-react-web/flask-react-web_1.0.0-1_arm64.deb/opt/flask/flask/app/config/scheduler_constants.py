JOB_INTERVALS = {
    "realtime": 5,
    "quick": 10,
    "normal": 30,
    "slow": 60,
    "nslow": 120,
    "xslow": 300,
    "xxslow": 600,
    "storage": 120,
}

JOB_CONFIGS = {
    'fetch_init_service_stat': JOB_INTERVALS['xslow'],   
    'fetch_interfaces_operation': JOB_INTERVALS['xslow'],     
    'fetch_memory': JOB_INTERVALS['slow'],                    
    'fetch_storage': JOB_INTERVALS['storage'],
    'fetch_system_info': JOB_INTERVALS['xslow'],              
    'fetch_firewall_opr': JOB_INTERVALS['xslow'],             
    'fetch_firewall_opr_log': JOB_INTERVALS['xslow'],         
    'fetch_os_config': JOB_INTERVALS['nslow'],                
    'fetch_service_stat': JOB_INTERVALS['xslow'],         
    'fetch_load_average_history': JOB_INTERVALS['realtime'],
    'check_vyos_http_api': JOB_INTERVALS['quick'],
    'check_software_update_available': JOB_INTERVALS['xxslow'],
    'save_recent_config': JOB_INTERVALS['xslow'],
    "refresh_cloud_sessions": JOB_INTERVALS["realtime"],
}
