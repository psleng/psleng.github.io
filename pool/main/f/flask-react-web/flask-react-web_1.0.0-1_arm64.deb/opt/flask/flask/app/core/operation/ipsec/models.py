from pydantic import BaseModel
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.utils.format_str import decode_description
import json

from pydantic import BaseModel, RootModel, field_validator, Field, AliasChoices
from typing import Optional, List, DefaultDict, Dict, Any, Union


def _scalar(value):
    if isinstance(value, list):
        return value[0] if value else None
    return value


def _csv(value):
    if value is None:
        return None
    if isinstance(value, list):
        return ','.join([str(v) for v in value if v is not None])
    return str(value)

def _as_list(value):
    if value is None or value == '':
        return []
    if isinstance(value, list):
        return [v for v in value if v not in (None, '')]
    if isinstance(value, dict):
        return list(value.keys())
    return [value]

def _json_list(value):
    values = _as_list(value)
    return json.dumps(values) if len(values) != 1 else str(values[0])

def _stored_list(value):
    if value is None or value == '':
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except (TypeError, ValueError):
            pass
    return [value]


def _to_int_or_none(value):
    if value in (None, ''):
        return None
    return int(value)

class IPsecConfig(db.Model):
    __tablename__ = 'vyos_config_ipsec'

    id = Column(Integer, primary_key=True)
    
    disable_route_autoinstall = Column(Boolean, default=False)
    flexvpn = Column(Boolean, default=False)
    virtual_ip = Column(Boolean, default=False)
    interface_binding = Column(String(255))
    disable_uniqreqids = Column(Boolean, default=False)
    
    psk_configs = relationship("IPsecPSKConfig", back_populates="ipsec_config", cascade="all, delete-orphan")
    esp_groups = relationship("IPsecESPGroup", back_populates="ipsec_config", cascade="all, delete-orphan")
    ike_groups = relationship("IPsecIKEGroup", back_populates="ipsec_config", cascade="all, delete-orphan")
    interfaces = relationship("IPsecInterface", back_populates="ipsec_config", cascade="all, delete-orphan")
    site_to_site_peers = relationship("IPsecSiteToSitePeer", back_populates="ipsec_config", cascade="all, delete-orphan")
    remote_access_connections = relationship("IPsecRemoteAccessConnection", back_populates="ipsec_config", cascade="all, delete-orphan")
    remote_access_pools = relationship("IPsecRemoteAccessPool", back_populates="ipsec_config", cascade="all, delete-orphan")
    remote_access_radius_servers = relationship("IPsecRemoteAccessRadiusServer", back_populates="ipsec_config", cascade="all, delete-orphan")
    remote_access_dhcp = relationship("IPsecRemoteAccessDHCP", back_populates="ipsec_config", cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_ipsec_connection_local_prefix',
            'vyos_config_ipsec_pool_exclude_address',
            'vyos_config_ipsec_pool_name_server',
            'vyos_config_ipsec_remote_access_local_user',
            'vyos_config_ipsec_remote_access_connection', 
            'vyos_config_ipsec_remote_access_dhcp',
            'vyos_config_ipsec_remote_access_pool',
            'vyos_config_ipsec_remote_access_radius_server',
            'vyos_config_ipsec_tunnel_local_prefix',
            'vyos_config_ipsec_tunnel_remote_prefix',
            'vyos_config_ipsec_site_to_site_tunnel',
            'vyos_config_ipsec_peer_remote_address',
            'vyos_config_ipsec_peer_virtual_address',
            'vyos_config_ipsec_peer_x509_ca_cert',
            'vyos_config_ipsec_peer_ts_local_prefix',
            'vyos_config_ipsec_peer_ts_remote_prefix',
            'vyos_config_ipsec_site_to_site_peer',
            'vyos_config_ipsec_esp_proposal',
            'vyos_config_ipsec_esp_group',
            'vyos_config_ipsec_ike_proposal', 
            'vyos_config_ipsec_ike_group',
            'vyos_config_ipsec_interface_binding',
            'vyos_config_ipsec_psk',
            'vyos_config_ipsec'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            
            ipsec_config = cls()        
            ipsec_config.disable_uniqreqids = 'disable-uniqreqids' in config
            if 'options' in config:
                options = config['options']
                ipsec_config.disable_route_autoinstall = 'disable-route-autoinstall' in options
                ipsec_config.flexvpn = 'flexvpn' in options
                ipsec_config.virtual_ip = 'virtual-ip' in options
                ipsec_config.interface_binding = options.get('interface', '')
            
            db.session.add(ipsec_config)
            db.session.flush()  # Get the ID
            
            if 'authentication' in config and 'psk' in config['authentication']:
                for psk_name, psk_data in config['authentication']['psk'].items():
                    psk_config = IPsecPSKConfig(
                        ipsec_config_id=ipsec_config.id,
                        name=psk_name,
                        psk_id=_json_list(psk_data.get('id')),
                        dhcp_interface=_json_list(psk_data.get('dhcp-interface') or psk_data.get('dhcp_interface')),
                        secret=_scalar(psk_data.get('secret')),
                        secret_type=_scalar(psk_data.get('secret-type'))
                    )
                    db.session.add(psk_config)
            
            if 'esp-group' in config:
                for group_name, group_data in config['esp-group'].items():
                    esp_group = IPsecESPGroup(
                        ipsec_config_id=ipsec_config.id,
                        name=group_name,
                        compression='compression' in group_data,
                        disable_rekey='disable-rekey' in group_data,
                        life_bytes=group_data.get('life-bytes'),
                        life_packets=group_data.get('life-packets'),
                        lifetime=group_data.get('lifetime'),
                        mode=group_data.get('mode'),
                        pfs=group_data.get('pfs')
                    )
                    db.session.add(esp_group)
                    db.session.flush()
                    
                    if 'proposal' in group_data:
                        for prop_num, prop_data in group_data['proposal'].items():
                            proposal = IPsecESPProposal(
                                esp_group_id=esp_group.id,
                                proposal_number=prop_num,
                                encryption=prop_data.get('encryption'),
                                hash_algorithm=prop_data.get('hash')
                            )
                            db.session.add(proposal)
            
            if 'ike-group' in config:
                for group_name, group_data in config['ike-group'].items():
                    dpd_data = group_data.get('dead-peer-detection', {})
                    
                    ike_group = IPsecIKEGroup(
                        ipsec_config_id=ipsec_config.id,
                        name=group_name,
                        close_action=group_data.get('close-action'),
                        disable_mobike='disable-mobike' in group_data,
                        ikev2_reauth='ikev2-reauth' in group_data,
                        key_exchange=group_data.get('key-exchange'),
                        lifetime=_to_int_or_none(group_data.get('lifetime')),
                        mode=group_data.get('mode'),
                        dpd_action=dpd_data.get('action') if dpd_data else None,
                        dpd_interval=_to_int_or_none(dpd_data.get('interval')) if dpd_data else None,
                        dpd_timeout=_to_int_or_none(dpd_data.get('timeout')) if dpd_data else None
                    )
                    db.session.add(ike_group)
                    db.session.flush()
                    
                    if 'proposal' in group_data:
                        for prop_num, prop_data in group_data['proposal'].items():
                            proposal = IPsecIKEProposal(
                                ike_group_id=ike_group.id,
                                proposal_number=prop_num,
                                dh_group=prop_data.get('dh-group'),
                                encryption=prop_data.get('encryption'),
                                hash_algorithm=prop_data.get('hash'),
                                prf=prop_data.get('prf')
                            )
                            db.session.add(proposal)
            
            if 'interface' in config:
                interfaces = config['interface'] if isinstance(config['interface'], list) else [config['interface']]
                for interface_name in interfaces:
                    interface = IPsecInterface(
                        ipsec_config_id=ipsec_config.id,
                        interface_name=interface_name
                    )
                    db.session.add(interface)
            
            if 'site-to-site' in config and 'peer' in config['site-to-site']:
                for peer_name, peer_data in config['site-to-site']['peer'].items():
                    
                    vti_value = peer_data.get('vti')
                    vti_esp_group = peer_data.get('esp-group') or peer_data.get('esp_group')
                    if isinstance(vti_value, dict):
                        vti_bind = vti_value.get('bind')
                        vti_esp_group = vti_value.get('esp-group') or vti_value.get('esp_group') or vti_esp_group
                        
                        vti_traffic_selector = vti_value.get('traffic-selector', {})
                        ts_local = vti_traffic_selector.get('local', {}).get('prefix', [])
                        ts_remote = vti_traffic_selector.get('remote', {}).get('prefix', [])
                    else:
                        vti_bind = vti_value
                        ts_local = peer_data.get('traffic-selector', {}).get('local', {}).get('prefix', [])
                        ts_remote = peer_data.get('traffic-selector', {}).get('remote', {}).get('prefix', [])
                    
                    peer = IPsecSiteToSitePeer(
                        ipsec_config_id=ipsec_config.id,
                        name=peer_name,
                        description=decode_description(peer_data.get('description')),
                        connection_type=peer_data.get('connection-type'),
                        default_esp_group=peer_data.get('default-esp-group'),
                        dhcp_interface=peer_data.get('dhcp-interface'),
                        force_udp_encapsulation='force-udp-encapsulation' in peer_data,
                        auth_local_id=peer_data.get('authentication', {}).get('local-id'),
                        auth_mode=peer_data.get('authentication', {}).get('mode'),
                        auth_remote_id=peer_data.get('authentication', {}).get('remote-id'),
                        use_x509_id='use-x509-id' in peer_data.get('authentication', {}),
                        ike_group=peer_data.get('ike-group'),
                        ikev2_reauth=peer_data.get('ikev2-reauth') == 'yes',
                        local_address=peer_data.get('local-address'),
                        replay_window=_to_int_or_none(peer_data.get('replay-window')),
                        vti=vti_bind,
                        vti_esp_group=vti_esp_group,
                    )
                    db.session.add(peer)
                    db.session.flush()  # Get peer.id for relationships
                    
                    remote_addrs = peer_data.get('remote-address', [])
                    if not isinstance(remote_addrs, list):
                        remote_addrs = [remote_addrs] if remote_addrs else []
                    for addr in remote_addrs:
                        if addr:
                            db.session.add(IPsecPeerRemoteAddress(peer_id=peer.id, address=addr))
                    
                    virtual_addrs = peer_data.get('virtual-address', [])
                    if not isinstance(virtual_addrs, list):
                        virtual_addrs = [virtual_addrs] if virtual_addrs else []
                    for addr in virtual_addrs:
                        if addr:
                            db.session.add(IPsecPeerVirtualAddress(peer_id=peer.id, address=addr))
                    
                    if ts_local:
                        if isinstance(ts_local, str):
                            db.session.add(IPsecPeerTrafficSelectorLocalPrefix(peer_id=peer.id, prefix=ts_local))
                        elif isinstance(ts_local, list):
                            for prefix in ts_local:
                                if prefix:
                                    db.session.add(IPsecPeerTrafficSelectorLocalPrefix(peer_id=peer.id, prefix=prefix))
                    
                    if ts_remote:
                        if isinstance(ts_remote, str):
                            db.session.add(IPsecPeerTrafficSelectorRemotePrefix(peer_id=peer.id, prefix=ts_remote))
                        elif isinstance(ts_remote, list):
                            for prefix in ts_remote:
                                if prefix:
                                    db.session.add(IPsecPeerTrafficSelectorRemotePrefix(peer_id=peer.id, prefix=prefix))
                    
                    if 'rsa' in peer_data.get('authentication', {}):
                        rsa_data = peer_data['authentication']['rsa']
                        peer.rsa_local_key = rsa_data.get('local-key')
                        peer.rsa_remote_key = rsa_data.get('remote-key')
                    
                    if 'x509' in peer_data.get('authentication', {}):
                        x509_data = peer_data['authentication']['x509']
                        
                        ca_certs = x509_data.get('ca-certificate', [])
                        if not isinstance(ca_certs, list):
                            ca_certs = [ca_certs] if ca_certs else []
                        for ca_cert in ca_certs:
                            if ca_cert:
                                db.session.add(IPsecPeerX509CACertificate(peer_id=peer.id, ca_certificate=ca_cert))
                        peer.x509_certificate = x509_data.get('certificate')
                    
                    
                    if 'tunnel' in peer_data:
                        for tunnel_num, tunnel_data in peer_data['tunnel'].items():
                            tunnel = IPsecSiteToSiteTunnel(
                                peer_id=peer.id,
                                tunnel_number=tunnel_num,
                                esp_group=tunnel_data.get('esp-group'),
                                priority=_to_int_or_none(tunnel_data.get('priority')),
                                protocol=tunnel_data.get('protocol'),
                                local_port=_to_int_or_none(tunnel_data.get('local', {}).get('port')),
                                remote_port=_to_int_or_none(tunnel_data.get('remote', {}).get('port'))
                            )
                            db.session.add(tunnel)
                            db.session.flush()  # Get tunnel.id
                            
                            local_prefixes = tunnel_data.get('local', {}).get('prefix', [])
                            if not isinstance(local_prefixes, list):
                                local_prefixes = [local_prefixes] if local_prefixes else []
                            for prefix in local_prefixes:
                                if prefix:
                                    db.session.add(IPsecTunnelLocalPrefix(tunnel_id=tunnel.id, prefix=prefix))
                            
                            remote_prefixes = tunnel_data.get('remote', {}).get('prefix', [])
                            if not isinstance(remote_prefixes, list):
                                remote_prefixes = [remote_prefixes] if remote_prefixes else []
                            for prefix in remote_prefixes:
                                if prefix:
                                    db.session.add(IPsecTunnelRemotePrefix(tunnel_id=tunnel.id, prefix=prefix))
            if 'remote-access' in config:
                remote_access = config['remote-access']
                
                if 'connection' in remote_access:
                    for conn_name, conn_data in remote_access['connection'].items():
                        local_data = conn_data.get('local', {})
                        
                        connection = IPsecRemoteAccessConnection(
                            ipsec_config_id=ipsec_config.id,
                            name=conn_name,
                            description=decode_description(conn_data.get('description')),
                            bind=conn_data.get('bind'),
                            esp_group=conn_data.get('esp-group'),
                            ike_group=conn_data.get('ike-group'),
                            local_address=conn_data.get('local-address'),
                            local_port=_to_int_or_none(local_data.get('port')),
                            pool=_csv(conn_data.get('pool')),
                            replay_window=_to_int_or_none(conn_data.get('replay-window')),
                            timeout=_to_int_or_none(conn_data.get('timeout')),
                            unique=conn_data.get('unique', 'never')
                        )
                        
                        if 'authentication' in conn_data:
                            auth = conn_data['authentication']
                            connection.auth_client_mode = auth.get('client-mode')
                            connection.auth_eap_id = auth.get('eap-id')
                            connection.auth_local_id = auth.get('local-id')
                            connection.auth_pre_shared_secret = auth.get('pre-shared-secret')
                            connection.auth_server_mode = auth.get('server-mode')
                            
                            if 'x509' in auth:
                                x509 = auth['x509']
                                ca_cert = x509.get('ca-certificate')
                                if isinstance(ca_cert, list):
                                    ca_cert = ','.join(ca_cert) if ca_cert else None
                                
                                connection.auth_x509_ca_certificate = ca_cert
                                connection.auth_x509_certificate = x509.get('certificate')
                        
                        db.session.add(connection)
                        db.session.flush()
                        
                        local_prefixes = local_data.get('prefix', [])
                        if not isinstance(local_prefixes, list):
                            local_prefixes = [local_prefixes] if local_prefixes else []
                        for prefix in local_prefixes:
                            if prefix:
                                db.session.add(IPsecConnectionLocalPrefix(connection_id=connection.id, prefix=prefix))
                        
                        if 'authentication' in conn_data and 'local-users' in conn_data['authentication']:
                            local_users = conn_data['authentication']['local-users']
                            if 'username' in local_users:
                                for username, user_data in local_users['username'].items():
                                    local_user = IPsecRemoteAccessLocalUser(
                                        connection_id=connection.id,
                                        username=username,
                                        enabled=not ('disable' in user_data),
                                        password=user_data.get('password')
                                    )
                                    db.session.add(local_user)
                
                if 'pool' in remote_access:
                    for pool_name, pool_data in remote_access['pool'].items():
                        range_data = pool_data.get('range', {})
                        
                        pool = IPsecRemoteAccessPool(
                            ipsec_config_id=ipsec_config.id,
                            name=pool_name,
                            prefix=pool_data.get('prefix'),
                            range_start=range_data.get('start'),
                            range_stop=range_data.get('stop')
                        )
                        db.session.add(pool)
                        db.session.flush()
                        
                        excludes = pool_data.get('exclude', [])
                        if not isinstance(excludes, list):
                            excludes = [excludes] if excludes else []
                        for exclude_addr in excludes:
                            if exclude_addr:
                                db.session.add(IPsecPoolExcludeAddress(pool_id=pool.id, address=exclude_addr))
                        
                        name_servers = pool_data.get('name-server', [])
                        if not isinstance(name_servers, list):
                            name_servers = [name_servers] if name_servers else []
                        for ns in name_servers:
                            if ns:
                                db.session.add(IPsecPoolNameServer(pool_id=pool.id, name_server=ns))
                
                if 'radius' in remote_access and 'server' in remote_access['radius']:
                    for server_addr, server_data in remote_access['radius']['server'].items():
                        radius_server = IPsecRemoteAccessRadiusServer(
                            ipsec_config_id=ipsec_config.id,
                            server_address=server_addr,
                            shared_key=server_data.get('key')
                        )
                        db.session.add(radius_server)
                
                if 'dhcp' in remote_access:
                    dhcp_data = remote_access['dhcp']
                    dhcp = IPsecRemoteAccessDHCP(
                        ipsec_config_id=ipsec_config.id,
                        interface=dhcp_data.get('interface'),
                        server=dhcp_data.get('server')
                    )
                    db.session.add(dhcp)      
            db.session.commit()
            
        except Exception as e:
            print(f"Error refreshing IPsec data: {e}")
            raise e

    def get_full_config(self):
        """Return the full IPSec configuration in VyOS format"""
        config = {}

        if self.disable_uniqreqids:
            config['disable-uniqreqids'] = {}
        
        if self.psk_configs:
            config['authentication'] = {'psk': {}}
            for psk in self.psk_configs:
                ids = _stored_list(psk.psk_id)
                psk_config = {
                    'id': ids if len(ids) != 1 else ids[0],
                    'secret': psk.secret,
                }
                if psk.secret_type:
                    psk_config['secret-type'] = psk.secret_type
                dhcp_interfaces = _stored_list(psk.dhcp_interface)
                if dhcp_interfaces:
                    psk_config['dhcp-interface'] = dhcp_interfaces if len(dhcp_interfaces) != 1 else dhcp_interfaces[0]
                config['authentication']['psk'][psk.name] = psk_config
        
        if self.esp_groups:
            config['esp-group'] = {}
            for esp_group in self.esp_groups:
                group_config = {}
                if esp_group.compression:
                    group_config['compression'] = {}
                if esp_group.disable_rekey:
                    group_config['disable-rekey'] = {}
                if esp_group.life_bytes:
                    group_config['life-bytes'] = esp_group.life_bytes
                if esp_group.life_packets:
                    group_config['life-packets'] = esp_group.life_packets
                if esp_group.lifetime is not None:
                    group_config['lifetime'] = esp_group.lifetime
                if esp_group.mode:
                    group_config['mode'] = esp_group.mode
                if esp_group.pfs:
                    group_config['pfs'] = esp_group.pfs
                
                if esp_group.proposals:
                    group_config['proposal'] = {}
                    for proposal in esp_group.proposals:
                        group_config['proposal'][proposal.proposal_number] = {
                            'encryption': proposal.encryption,
                            'hash': proposal.hash_algorithm
                        }
                
                config['esp-group'][esp_group.name] = group_config
        
        if self.ike_groups:
            config['ike-group'] = {}
            for ike_group in self.ike_groups:
                group_config = {}
                if ike_group.key_exchange:
                    group_config['key-exchange'] = ike_group.key_exchange
                if ike_group.lifetime is not None:
                    group_config['lifetime'] = ike_group.lifetime
                if ike_group.mode:
                    group_config['mode'] = ike_group.mode
                
                if ike_group.close_action:
                    group_config['close-action'] = ike_group.close_action
                
                if ike_group.ikev2_reauth:
                    group_config['ikev2-reauth'] = {}
                
                if ike_group.disable_mobike:
                    group_config['disable-mobike'] = {}
                
                if ike_group.dpd_action or ike_group.dpd_interval or ike_group.dpd_timeout:
                    group_config['dead-peer-detection'] = {}
                    if ike_group.dpd_action:
                        group_config['dead-peer-detection']['action'] = ike_group.dpd_action
                    if ike_group.dpd_interval:
                        group_config['dead-peer-detection']['interval'] = ike_group.dpd_interval
                    if ike_group.dpd_timeout:
                        group_config['dead-peer-detection']['timeout'] = ike_group.dpd_timeout
                
                if ike_group.proposals:
                    group_config['proposal'] = {}
                    for proposal in ike_group.proposals:
                        group_config['proposal'][proposal.proposal_number] = {
                            'dh-group': proposal.dh_group,
                            'encryption': proposal.encryption,
                            'hash': proposal.hash_algorithm,
                            'prf': proposal.prf
                        }
                
                config['ike-group'][ike_group.name] = group_config
        
        if self.interfaces:
            interface_list = [iface.interface_name for iface in self.interfaces]
            config['interface'] = interface_list
        
        options = {}
        if self.disable_route_autoinstall:
            options['disable-route-autoinstall'] = {}
        if self.flexvpn:
            options['flexvpn'] = {}
        if self.virtual_ip:
            options['virtual-ip'] = {}
        if self.interface_binding:
            options['interface'] = self.interface_binding
        if options:
            config['options'] = options
        
        if self.site_to_site_peers:
            config['site-to-site'] = {'peer': {}}
            for peer in self.site_to_site_peers:
                peer_config = {
                    'ike-group': peer.ike_group,
                    'remote-address': [addr.address for addr in peer.remote_addresses]
                }
                if peer.ikev2_reauth:
                    peer_config['ikev2-reauth'] = 'yes'
                auth_config = {}
                if peer.auth_local_id:
                    auth_config['local-id'] = peer.auth_local_id
                if peer.auth_mode:
                    auth_config['mode'] = peer.auth_mode
                if peer.auth_remote_id:
                    auth_config['remote-id'] = peer.auth_remote_id
                if auth_config:
                    peer_config['authentication'] = auth_config
                if peer.local_address:
                    peer_config['local-address'] = peer.local_address
                if peer.replay_window is not None:
                    peer_config['replay-window'] = str(peer.replay_window)
                
                if peer.description:
                    peer_config['description'] = peer.description
                if peer.connection_type:
                    peer_config['connection-type'] = peer.connection_type
                if peer.default_esp_group:
                    peer_config['default-esp-group'] = peer.default_esp_group
                if peer.dhcp_interface:
                    peer_config['dhcp-interface'] = peer.dhcp_interface
                if peer.force_udp_encapsulation:
                    peer_config['force-udp-encapsulation'] = {}
                
                if peer.virtual_addresses:
                    virtual_addrs = [addr.address for addr in peer.virtual_addresses]
                    if virtual_addrs:
                        peer_config['virtual-address'] = virtual_addrs
                
                if peer.vti_esp_group:
                    peer_config['vti'] = {'esp-group': peer.vti_esp_group}
                    if peer.vti:
                        peer_config['vti']['bind'] = peer.vti
                elif peer.vti:
                    peer_config['vti'] = peer.vti
                
                if peer.traffic_selector_local_prefixes or peer.traffic_selector_remote_prefixes:
                    peer_config['traffic-selector'] = {}
                    
                    if peer.traffic_selector_local_prefixes:
                        local_prefixes = [p.prefix for p in peer.traffic_selector_local_prefixes]
                        if local_prefixes:
                            peer_config['traffic-selector']['local'] = {'prefix': local_prefixes}
                    
                    if peer.traffic_selector_remote_prefixes:
                        remote_prefixes = [p.prefix for p in peer.traffic_selector_remote_prefixes]
                        if remote_prefixes:
                            if 'remote' not in peer_config['traffic-selector']:
                                peer_config['traffic-selector']['remote'] = {}
                            peer_config['traffic-selector']['remote']['prefix'] = remote_prefixes
                
                if peer.use_x509_id:
                    peer_config['authentication']['use-x509-id'] = {}
                
                if peer.rsa_local_key or peer.rsa_remote_key:
                    peer_config['authentication']['rsa'] = {}
                    if peer.rsa_local_key:
                        peer_config['authentication']['rsa']['local-key'] = peer.rsa_local_key
                    if peer.rsa_remote_key:
                        peer_config['authentication']['rsa']['remote-key'] = peer.rsa_remote_key
                
                if peer.x509_ca_certificates or peer.x509_certificate:
                    peer_config['authentication']['x509'] = {}
                    if peer.x509_ca_certificates:
                        peer_config['authentication']['x509']['ca-certificate'] = [cert.ca_certificate for cert in peer.x509_ca_certificates]
                    if peer.x509_certificate:
                        peer_config['authentication']['x509']['certificate'] = peer.x509_certificate
                
                if peer.tunnels:
                    peer_config['tunnel'] = {}
                    for tunnel in peer.tunnels:
                        tunnel_config = {
                            'esp-group': tunnel.esp_group,
                            'local': {
                                'prefix': [p.prefix for p in tunnel.local_prefixes]
                            },
                            'remote': {
                                'prefix': [p.prefix for p in tunnel.remote_prefixes]
                            }
                        }
                        if tunnel.local_port:
                            tunnel_config['local']['port'] = tunnel.local_port
                        if tunnel.remote_port:
                            tunnel_config['remote']['port'] = tunnel.remote_port
                        if tunnel.priority is not None:
                            tunnel_config['priority'] = tunnel.priority
                        if tunnel.protocol:
                            tunnel_config['protocol'] = tunnel.protocol
                        
                        peer_config['tunnel'][tunnel.tunnel_number] = tunnel_config
                
                config['site-to-site']['peer'][peer.name] = peer_config
        
        if self.remote_access_connections or self.remote_access_pools or self.remote_access_dhcp or self.remote_access_radius_servers:
            config['remote-access'] = {}
            
            if self.remote_access_connections:
                config['remote-access']['connection'] = {}
                for conn in self.remote_access_connections:
                    conn_config = {
                        'esp-group': conn.esp_group,
                        'ike-group': conn.ike_group,
                        'unique': conn.unique
                    }
                    if conn.local_address:
                        conn_config['local-address'] = conn.local_address
                    if conn.replay_window is not None:
                        conn_config['replay-window'] = conn.replay_window
                    
                    if conn.description:
                        conn_config['description'] = conn.description
                    if conn.timeout:
                        conn_config['timeout'] = conn.timeout
                    if conn.local_port or conn.local_prefixes:
                        conn_config['local'] = {}
                        if conn.local_port:
                            conn_config['local']['port'] = conn.local_port
                        if conn.local_prefixes:
                            prefixes = [p.prefix for p in conn.local_prefixes]
                            if len(prefixes) == 1:
                                conn_config['local']['prefix'] = prefixes[0]
                            else:
                                conn_config['local']['prefix'] = prefixes
                    
                    if conn.bind:
                        conn_config['bind'] = conn.bind
                    
                    if conn.pool:
                        if isinstance(conn.pool, str) and ',' in conn.pool:
                            conn_config['pool'] = [p.strip() for p in conn.pool.split(',') if p.strip()]
                        else:
                            conn_config['pool'] = conn.pool
                    
                    if conn.auth_client_mode or conn.auth_server_mode or conn.auth_eap_id or conn.auth_local_id:
                        conn_config['authentication'] = {}
                        if conn.auth_client_mode:
                            conn_config['authentication']['client-mode'] = conn.auth_client_mode
                        if conn.auth_server_mode:
                            conn_config['authentication']['server-mode'] = conn.auth_server_mode
                        if conn.auth_eap_id:
                            conn_config['authentication']['eap-id'] = conn.auth_eap_id
                        if conn.auth_local_id:
                            conn_config['authentication']['local-id'] = conn.auth_local_id
                        if conn.auth_pre_shared_secret:
                            conn_config['authentication']['pre-shared-secret'] = conn.auth_pre_shared_secret
                        
                        if conn.auth_x509_ca_certificate or conn.auth_x509_certificate:
                            conn_config['authentication']['x509'] = {}
                            if conn.auth_x509_ca_certificate:
                                conn_config['authentication']['x509']['ca-certificate'] = conn.auth_x509_ca_certificate
                            if conn.auth_x509_certificate:
                                conn_config['authentication']['x509']['certificate'] = conn.auth_x509_certificate
                        
                        if conn.local_users:
                            conn_config['authentication']['local-users'] = {'username': {}}
                            for user in conn.local_users:
                                conn_config['authentication']['local-users']['username'][user.username] = {
                                    'password': user.password,
                                    'disable': not user.enabled
                                }
                    
                    config['remote-access']['connection'][conn.name] = conn_config
            
            if self.remote_access_pools:
                config['remote-access']['pool'] = {}
                for pool in self.remote_access_pools:
                    pool_config = {}
                    if pool.prefix:
                        pool_config['prefix'] = pool.prefix
                    if pool.exclude_addresses:
                        excludes = [e.address for e in pool.exclude_addresses]
                        if len(excludes) == 1:
                            pool_config['exclude'] = excludes[0]
                        else:
                            pool_config['exclude'] = excludes
                    if pool.name_servers:
                        name_servers = [ns.name_server for ns in pool.name_servers]
                        if len(name_servers) == 1:
                            pool_config['name-server'] = name_servers[0]
                        else:
                            pool_config['name-server'] = name_servers
                    if pool.range_start or pool.range_stop:
                        pool_config['range'] = {}
                        if pool.range_start:
                            pool_config['range']['start'] = pool.range_start
                        if pool.range_stop:
                            pool_config['range']['stop'] = pool.range_stop
                    config['remote-access']['pool'][pool.name] = pool_config
            
            if self.remote_access_dhcp:
                dhcp = self.remote_access_dhcp[0]
                config['remote-access']['dhcp'] = {
                    'interface': dhcp.interface,
                    'server': dhcp.server
                }
            
            if self.remote_access_radius_servers:
                config['remote-access']['radius'] = {
                    'server': {}
                }
                for server in self.remote_access_radius_servers:
                    config['remote-access']['radius']['server'][server.server_address] = {
                        'key': server.shared_key
                    }
        
        return config

    @classmethod
    def get_current_config(cls):
        record = cls.query.first()
        if record:
            return record.get_full_config()
        return {}


class IPsecPSKConfig(db.Model):
    __tablename__ = 'vyos_config_ipsec_psk'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    psk_id = Column(String(255))
    dhcp_interface = Column(String(255))
    secret = Column(Text)
    secret_type = Column(String(50))
    
    ipsec_config = relationship("IPsecConfig", back_populates="psk_configs")


class IPsecESPGroup(db.Model):
    __tablename__ = 'vyos_config_ipsec_esp_group'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    compression = Column(Boolean, default=False)
    disable_rekey = Column(Boolean, default=False)
    life_bytes = Column(String(50))
    life_packets = Column(String(50))
    lifetime = Column(String(50))
    mode = Column(String(50))
    pfs = Column(String(50))
    
    ipsec_config = relationship("IPsecConfig", back_populates="esp_groups")
    proposals = relationship("IPsecESPProposal", back_populates="esp_group", cascade="all, delete-orphan")


class IPsecESPProposal(db.Model):
    __tablename__ = 'vyos_config_ipsec_esp_proposal'

    id = Column(Integer, primary_key=True)
    esp_group_id = Column(Integer, ForeignKey('vyos_config_ipsec_esp_group.id'), nullable=False)
    
    proposal_number = Column(String(10), nullable=False)
    encryption = Column(String(100))
    hash_algorithm = Column(String(100))
    
    esp_group = relationship("IPsecESPGroup", back_populates="proposals")


class IPsecIKEGroup(db.Model):
    __tablename__ = 'vyos_config_ipsec_ike_group'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    close_action = Column(String(50))
    disable_mobike = Column(Boolean, default=False)
    ikev2_reauth = Column(Boolean, default=False)
    key_exchange = Column(String(50))
    lifetime = Column(Integer)
    mode = Column(String(50), default='main')
    
    # Dead Peer Detection
    dpd_action = Column(String(50))
    dpd_interval = Column(Integer)
    dpd_timeout = Column(Integer)
    
    ipsec_config = relationship("IPsecConfig", back_populates="ike_groups")
    proposals = relationship("IPsecIKEProposal", back_populates="ike_group", cascade="all, delete-orphan")


class IPsecIKEProposal(db.Model):
    __tablename__ = 'vyos_config_ipsec_ike_proposal'

    id = Column(Integer, primary_key=True)
    ike_group_id = Column(Integer, ForeignKey('vyos_config_ipsec_ike_group.id'), nullable=False)
    
    proposal_number = Column(String(10), nullable=False)
    dh_group = Column(String(50))
    encryption = Column(String(100))
    hash_algorithm = Column(String(100))
    prf = Column(String(100))
    
    ike_group = relationship("IPsecIKEGroup", back_populates="proposals")


class IPsecInterface(db.Model):
    __tablename__ = 'vyos_config_ipsec_interface_binding'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    interface_name = Column(String(255), nullable=False)
    
    ipsec_config = relationship("IPsecConfig", back_populates="interfaces")


class IPsecPeerRemoteAddress(db.Model):
    __tablename__ = 'vyos_config_ipsec_peer_remote_address'
    
    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    address = Column(String(255), nullable=False)
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="remote_addresses")


class IPsecPeerVirtualAddress(db.Model):
    __tablename__ = 'vyos_config_ipsec_peer_virtual_address'
    
    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    address = Column(String(255), nullable=False)
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="virtual_addresses")


class IPsecPeerX509CACertificate(db.Model):
    __tablename__ = 'vyos_config_ipsec_peer_x509_ca_cert'
    
    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    ca_certificate = Column(String(255), nullable=False)
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="x509_ca_certificates")


class IPsecPeerTrafficSelectorLocalPrefix(db.Model):
    __tablename__ = 'vyos_config_ipsec_peer_ts_local_prefix'
    
    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    prefix = Column(String(255), nullable=False)
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="traffic_selector_local_prefixes")


class IPsecPeerTrafficSelectorRemotePrefix(db.Model):
    __tablename__ = 'vyos_config_ipsec_peer_ts_remote_prefix'
    
    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    prefix = Column(String(255), nullable=False)
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="traffic_selector_remote_prefixes")


class IPsecTunnelLocalPrefix(db.Model):
    __tablename__ = 'vyos_config_ipsec_tunnel_local_prefix'
    
    id = Column(Integer, primary_key=True)
    tunnel_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_tunnel.id'), nullable=False)
    prefix = Column(String(255), nullable=False)
    
    tunnel = relationship("IPsecSiteToSiteTunnel", back_populates="local_prefixes")


class IPsecTunnelRemotePrefix(db.Model):
    __tablename__ = 'vyos_config_ipsec_tunnel_remote_prefix'
    
    id = Column(Integer, primary_key=True)
    tunnel_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_tunnel.id'), nullable=False)
    prefix = Column(String(255), nullable=False)
    
    tunnel = relationship("IPsecSiteToSiteTunnel", back_populates="remote_prefixes")


class IPsecSiteToSitePeer(db.Model):
    __tablename__ = 'vyos_config_ipsec_site_to_site_peer'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    description = Column(Text)
    connection_type = Column(String(50))
    default_esp_group = Column(String(255))
    dhcp_interface = Column(String(255))
    force_udp_encapsulation = Column(Boolean, default=False)
    
    auth_local_id = Column(String(255))
    auth_mode = Column(String(50))
    auth_remote_id = Column(String(255))
    use_x509_id = Column(Boolean, default=False)
    
    rsa_local_key = Column(String(255))
    rsa_remote_key = Column(String(255))
    
    x509_certificate = Column(String(255))
    
    ike_group = Column(String(255))
    ikev2_reauth = Column(Boolean, default=False)
    local_address = Column(String(255))
    replay_window = Column(Integer)
    vti = Column(String(255))  # VTI interface name
    vti_esp_group = Column(String(255))
    
    ipsec_config = relationship("IPsecConfig", back_populates="site_to_site_peers")
    tunnels = relationship("IPsecSiteToSiteTunnel", back_populates="peer", cascade="all, delete-orphan")
    remote_addresses = relationship("IPsecPeerRemoteAddress", back_populates="peer", cascade="all, delete-orphan")
    virtual_addresses = relationship("IPsecPeerVirtualAddress", back_populates="peer", cascade="all, delete-orphan")
    x509_ca_certificates = relationship("IPsecPeerX509CACertificate", back_populates="peer", cascade="all, delete-orphan")
    traffic_selector_local_prefixes = relationship("IPsecPeerTrafficSelectorLocalPrefix", back_populates="peer", cascade="all, delete-orphan")
    traffic_selector_remote_prefixes = relationship("IPsecPeerTrafficSelectorRemotePrefix", back_populates="peer", cascade="all, delete-orphan")


class IPsecSiteToSiteTunnel(db.Model):
    __tablename__ = 'vyos_config_ipsec_site_to_site_tunnel'

    id = Column(Integer, primary_key=True)
    peer_id = Column(Integer, ForeignKey('vyos_config_ipsec_site_to_site_peer.id'), nullable=False)
    
    tunnel_number = Column(String(10), nullable=False)
    esp_group = Column(String(255))
    local_port = Column(Integer)
    remote_port = Column(Integer)
    priority = Column(Integer)
    protocol = Column(String(50))
    
    peer = relationship("IPsecSiteToSitePeer", back_populates="tunnels")
    local_prefixes = relationship("IPsecTunnelLocalPrefix", back_populates="tunnel", cascade="all, delete-orphan")
    remote_prefixes = relationship("IPsecTunnelRemotePrefix", back_populates="tunnel", cascade="all, delete-orphan")


class IPsecRemoteAccessConnection(db.Model):
    __tablename__ = 'vyos_config_ipsec_remote_access_connection'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    description = Column(Text)
    bind = Column(String(255))
    esp_group = Column(String(255))
    ike_group = Column(String(255))
    local_address = Column(String(255))
    local_port = Column(Integer)
    pool = Column(String(255))
    replay_window = Column(Integer)
    timeout = Column(Integer)
    unique = Column(String(50))
    
    auth_client_mode = Column(String(50))
    auth_server_mode = Column(String(50))
    auth_eap_id = Column(String(255))
    auth_local_id = Column(String(255))
    auth_pre_shared_secret = Column(String(255))
    auth_x509_ca_certificate = Column(String(255))
    auth_x509_certificate = Column(String(255))
    
    ipsec_config = relationship("IPsecConfig", back_populates="remote_access_connections")
    local_users = relationship("IPsecRemoteAccessLocalUser", back_populates="connection", cascade="all, delete-orphan")
    local_prefixes = relationship("IPsecConnectionLocalPrefix", back_populates="connection", cascade="all, delete-orphan")


class IPsecRemoteAccessLocalUser(db.Model):
    __tablename__ = 'vyos_config_ipsec_remote_access_local_user'

    id = Column(Integer, primary_key=True)
    connection_id = Column(Integer, ForeignKey('vyos_config_ipsec_remote_access_connection.id'), nullable=False)
    
    username = Column(String(255), nullable=False)
    password = Column(String(255))
    enabled = Column(Boolean, default=True)
    
    connection = relationship("IPsecRemoteAccessConnection", back_populates="local_users")


class IPsecRemoteAccessPool(db.Model):
    __tablename__ = 'vyos_config_ipsec_remote_access_pool'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    name = Column(String(255), nullable=False)
    prefix = Column(String(255))
    range_start = Column(String(255))
    range_stop = Column(String(255))
    
    ipsec_config = relationship("IPsecConfig", back_populates="remote_access_pools")
    exclude_addresses = relationship("IPsecPoolExcludeAddress", back_populates="pool", cascade="all, delete-orphan")
    name_servers = relationship("IPsecPoolNameServer", back_populates="pool", cascade="all, delete-orphan")


class IPsecRemoteAccessRadiusServer(db.Model):
    __tablename__ = 'vyos_config_ipsec_remote_access_radius_server'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    server_address = Column(String(255), nullable=False)
    shared_key = Column(String(255))
    
    ipsec_config = relationship("IPsecConfig", back_populates="remote_access_radius_servers")


class IPsecRemoteAccessDHCP(db.Model):
    __tablename__ = 'vyos_config_ipsec_remote_access_dhcp'

    id = Column(Integer, primary_key=True)
    ipsec_config_id = Column(Integer, ForeignKey('vyos_config_ipsec.id'), nullable=False)
    
    interface = Column(String(255))
    server = Column(String(255))
    
    ipsec_config = relationship("IPsecConfig")


class IPsecConnectionLocalPrefix(db.Model):
    __tablename__ = 'vyos_config_ipsec_connection_local_prefix'
    
    id = Column(Integer, primary_key=True)
    connection_id = Column(Integer, ForeignKey('vyos_config_ipsec_remote_access_connection.id'), nullable=False)
    prefix = Column(String(255), nullable=False)
    
    connection = relationship("IPsecRemoteAccessConnection", back_populates="local_prefixes")


class IPsecPoolExcludeAddress(db.Model):
    __tablename__ = 'vyos_config_ipsec_pool_exclude_address'
    
    id = Column(Integer, primary_key=True)
    pool_id = Column(Integer, ForeignKey('vyos_config_ipsec_remote_access_pool.id'), nullable=False)
    address = Column(String(255), nullable=False)
    
    pool = relationship("IPsecRemoteAccessPool", back_populates="exclude_addresses")


class IPsecPoolNameServer(db.Model):
    __tablename__ = 'vyos_config_ipsec_pool_name_server'
    
    id = Column(Integer, primary_key=True)
    pool_id = Column(Integer, ForeignKey('vyos_config_ipsec_remote_access_pool.id'), nullable=False)
    name_server = Column(String(255), nullable=False)
    
    pool = relationship("IPsecRemoteAccessPool", back_populates="name_servers")


# IPSec DTOs
class IPSecRSAAuthDTO(BaseModel):
    localKey: Optional[str] = None
    remoteKey: Optional[str] = None
    passphrase: Optional[str] = None

class IPSecX509AuthDTO(BaseModel):
    caCertificate: List[str] = []
    certificate: Optional[str] = None
    passphrase: Optional[str] = None

class IPSecAuthenticationDTO(BaseModel):
    localId: Optional[str] = None
    mode: str = "pre-shared-secret"
    remoteId: Optional[str] = None
    useX509Id: bool = False
    rsa: IPSecRSAAuthDTO = IPSecRSAAuthDTO()
    x509: IPSecX509AuthDTO = IPSecX509AuthDTO()

class IPSecTunnelLocalDTO(BaseModel):
    prefix: List[str] = []
    port: Optional[Union[str, int]] = None
    priority: Optional[Union[str, int]] = None
    protocol: Optional[str] = None

class IPSecTunnelRemoteDTO(BaseModel):
    prefix: List[str] = []
    port: Optional[Union[str, int]] = None

class IPSecTunnelDTO(BaseModel):
    id: Union[str, int]
    enabled: bool = True
    espGroup: Optional[str] = None
    local: IPSecTunnelLocalDTO = IPSecTunnelLocalDTO()
    remote: IPSecTunnelRemoteDTO = IPSecTunnelRemoteDTO()
    priority: Optional[Union[str, int]] = None
    protocol: Optional[str] = None
    
    @field_validator('id')
    @classmethod
    def convert_id_to_string(cls, v):
        return str(v) if v is not None else v

class IPSecPeerDTO(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = True
    authentication: IPSecAuthenticationDTO = IPSecAuthenticationDTO()
    connectionType: Optional[str] = None
    defaultEspGroup: Optional[str] = None
    espGroup: Optional[str] = None
    dhcpInterface: Optional[str] = None
    forceUdpEncapsulation: bool = False
    ikeGroup: Optional[str] = None
    ikev2Reauth: Optional[Union[bool, str]] = None
    localAddress: Optional[str] = None
    remoteAddress: List[str] = []
    replayWindow: Optional[Union[str, int]] = None
    tunnels: List[IPSecTunnelDTO] = []
    virtualAddress: List[str] = []
    vti: Optional[str] = None
    vtiAddress: Optional[str] = None
    trafficSelectorLocalPrefix: List[str] = []
    trafficSelectorRemotePrefix: List[str] = []

    @field_validator('ikev2Reauth', mode='before')
    @classmethod
    def normalize_ikev2_reauth(cls, v):
        if v is None or v == "":
            return None
        if v is True:
            return "yes"
        if v is False:
            return "no"
        if isinstance(v, str):
            v = v.strip().lower()
            if v in {"yes", "no", "inherit"}:
                return v
        return None

class IPSecSiteToSiteDTO(BaseModel):
    peers: List[IPSecPeerDTO] = []

class IPSecLocalUserDTO(BaseModel):
    username: str
    enabled: bool = True
    password: Optional[str] = None

class IPSecConnectionLocalDTO(BaseModel):
    port: Optional[int] = None
    prefix: List[str] = []
    address: Optional[str] = None

    @field_validator('port', mode='before')
    @classmethod
    def empty_port_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecConnectionPoolsDTO(BaseModel):
    name: List[str] = []
    dhcp: Optional[str] = None
    radius: Optional[str] = None

class IPSecConnectionAuthenticationDTO(BaseModel):
    clientMode: Optional[str] = None
    eapId: Optional[str] = None
    localId: Optional[str] = None
    localUsers: List[IPSecLocalUserDTO] = []
    preSharedSecret: Optional[str] = None
    serverMode: str = "x509"
    x509: IPSecX509AuthDTO = IPSecX509AuthDTO()

class IPSecRemoteAccessConnectionDTO(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = True
    bind: Optional[str] = None
    vtiAddress: Optional[str] = None
    dhcpInterface: Optional[str] = None
    ikeGroup: Optional[str] = None
    espGroup: Optional[str] = None
    local: IPSecConnectionLocalDTO = IPSecConnectionLocalDTO()
    pools: IPSecConnectionPoolsDTO = IPSecConnectionPoolsDTO()
    replayWindow: Optional[Union[str, int]] = None
    timeout: Optional[Union[str, int]] = None
    unique: str = "never"
    authentication: IPSecConnectionAuthenticationDTO = IPSecConnectionAuthenticationDTO()

class IPSecDHCPDTO(BaseModel):
    interface: Optional[str] = None
    server: Optional[str] = None

class IPSecPoolRangeDTO(BaseModel):
    start: Optional[str] = None
    stop: Optional[str] = None

class IPSecPoolDTO(BaseModel):
    name: str
    exclude: List[str] = []
    nameServer: List[str] = []
    prefix: Optional[str] = None
    range: IPSecPoolRangeDTO = IPSecPoolRangeDTO()

    @field_validator('exclude', mode='before')
    @classmethod
    def normalize_exclusions(cls, value):
        if value is None or value == '':
            return []
        if isinstance(value, str):
            return [value]
        return value

class IPSecRadiusServerDTO(BaseModel):
    address: str
    enabled: bool = True
    disableAccounting: bool = False
    port: Optional[int] = None
    key: Optional[str] = Field(default=None, validation_alias=AliasChoices('key', 'secret'))

    @field_validator('port', mode='before')
    @classmethod
    def empty_port_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecRadiusDTO(BaseModel):
    nasIdentifier: Optional[str] = None
    timeout: Optional[int] = None
    servers: List[IPSecRadiusServerDTO] = []

    @field_validator('nasIdentifier', 'timeout', mode='before')
    @classmethod
    def empty_radius_field_to_none(cls, v):
        if v == "":
            return None
        return v

class IPSecRemoteAccessDTO(BaseModel):
    connections: List[IPSecRemoteAccessConnectionDTO] = []
    dhcp: IPSecDHCPDTO = IPSecDHCPDTO()
    pools: List[IPSecPoolDTO] = []
    radius: IPSecRadiusDTO = IPSecRadiusDTO()

class IPSecOptionsDTO(BaseModel):
    interface: Optional[str] = None
    disableRouteAutoinstall: bool = False
    flexvpn: bool = False
    virtualIp: bool = False
    disableUniqreqids: bool = False

class IPSecRetransmissionDTO(BaseModel):
    attempt: Optional[str|int] = None
    base: Optional[str|float] = None
    timeout: Optional[str|int] = None

class IPSecGeneralDTO(BaseModel):
    siteToSite: IPSecSiteToSiteDTO = IPSecSiteToSiteDTO()
    remoteAccess: IPSecRemoteAccessDTO = IPSecRemoteAccessDTO()
    options: IPSecOptionsDTO = IPSecOptionsDTO()
    retransmission: IPSecRetransmissionDTO = IPSecRetransmissionDTO()

class IPSecPresharedKeyDTO(BaseModel):
    name: str
    id: Optional[Union[str, List[str]]] = None
    dhcpInterface: Optional[Union[str, List[str]]] = None
    secret: Optional[str] = None
    secretType: Optional[str] = None

class IPSecDeadPeerDetectionDTO(BaseModel):
    action: Optional[str] = None
    interval: Optional[Union[str, int]] = None
    timeout: Optional[Union[str, int]] = None

class IPSecIKEAdvancedDTO(BaseModel):
    closeAction: str = "none"
    deadPeerDetection: IPSecDeadPeerDetectionDTO = IPSecDeadPeerDetectionDTO()
    disableMobike: bool = False
    ikev2Reauth: bool = False
    keyExchange: Optional[str] = None
    lifetime: Optional[Union[str, int]] = None
    mode: Optional[str] = None

class IPSecProposalDTO(BaseModel):
    number: Optional[Union[str, int]] = None
    dhGroup: Optional[Union[str, int]] = None
    encryption: Optional[str] = None
    hash: Optional[str] = None
    prf: Optional[str] = None
    
    @field_validator('number', 'dhGroup')
    @classmethod
    def convert_to_string(cls, v):
        return str(v) if v is not None else v

class IPSecIKEGroupDTO(BaseModel):
    name: str
    advanced: IPSecIKEAdvancedDTO = IPSecIKEAdvancedDTO()
    proposals: List[IPSecProposalDTO] = []

class IPSecESPGroupDTO(BaseModel):
    name: str
    compression: bool = False
    disableRekey: bool = False
    lifeBytes: Optional[Union[str, int]] = None
    lifePackets: Optional[Union[str, int]] = None
    lifetime: Optional[Union[str, int]] = None
    mode: Optional[str] = None
    pfs: Optional[str] = None
    proposals: List[IPSecProposalDTO] = []

class IPSecSecurityDTO(BaseModel):
    presharedKeys: List[IPSecPresharedKeyDTO] = []
    ikeGroups: List[IPSecIKEGroupDTO] = []
    espGroups: List[IPSecESPGroupDTO] = []

class CreateIPsecInterfaceDTO(BaseModel):
    name: Optional[str] = None
    type: str = "ipsec"
    general: IPSecGeneralDTO = IPSecGeneralDTO()
    security: IPSecSecurityDTO = IPSecSecurityDTO()
    interface: Optional[List[str]] = None
    disableUniqreqids: bool = False

class UpdateIPsecInterfaceDTO(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = "ipsec"
    general: Optional[IPSecGeneralDTO] = None
    security: Optional[IPSecSecurityDTO] = None
    interface: Optional[List[str]] = None
    disableUniqreqids: Optional[bool] = None
