import subprocess

from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.api.http.http_request import Action
from app.core.network.amp.command_amp import AMPCommand
from app.core.network.amp.models import AMPConfig


def _response_data(response):
    response.raise_for_status()
    payload = response.json()
    if payload.get('success') is not True:
        raise RuntimeError(payload.get('error') or 'VyOS AMP request failed.')
    return payload.get('data')


def fetch_amp(provider, data=None):
    running_config = _response_data(provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_ALL_CONFIGS,
        verify=False,
    )) or {}
    config = (running_config.get('service') or {}).get('sla') or {}
    return {name: config[name] for name in AMPCommand.SERVERS if name in config}


def verify_amp(provider, data):

    config = dict(provider.verify_service.call_get_config('sla') or {})
    for name, default_port in AMPCommand.SERVERS.items():
        key = name.replace('-', '_')
        config.pop(key, None)
        if name in data:
            config[key] = {**data[name], 'port': str(data[name].get('port', default_port))}
    result = provider.verify_service.call_verify('sla', config)
    if result is not None and str(result).strip() not in ('', 'None', '{}', 'null'):
        raise ValueError(str(result))
    return {'success': True}


def update_amp(provider, data):
    current = fetch_amp(provider)
    verify_amp(provider, data)
    delete_cmd = AMPCommand(operator='delete', resource='amp')
    set_cmd = AMPCommand(operator='set', resource='amp')
    delete_commands = delete_cmd.generate_commands(data=data, current_config=current)
    set_commands = set_cmd.generate_commands(data=data, current_config=current)
    commands = delete_commands + set_commands
    if commands:
        _response_data(provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=commands,
            verify=False,
        ))
    AMPConfig.refresh(data)
    return {'success': True}


def monitor_amp(provider, data):

    command = ['/opt/vyatta/bin/vyatta-op-cmd-wrapper', 'execute', data.tool, data.target]
    try:
        result = subprocess.run(
            command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=60, check=False,
        )
        return {
            'success': result.returncode == 0,
            'output': result.stdout,
            'error': None if result.returncode == 0 else f'{data.tool} exited with status {result.returncode}.',
        }
    except subprocess.TimeoutExpired as error:
        output = error.stdout or ''
        if isinstance(output, bytes):
            output = output.decode(errors='replace')
        return {'success': False, 'output': output, 'error': 'AMP measurement timed out after 60 seconds.'}
    except OSError as error:
        raise RuntimeError('AMP monitoring requires the VyOS CLI on the router.') from error
