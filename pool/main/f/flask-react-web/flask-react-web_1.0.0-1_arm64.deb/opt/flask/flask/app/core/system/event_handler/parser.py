from typing import Any, Dict
from app.config.models import EventHandlerFilePath

EVENT_NAME_ENVIRONMENT_VARIABLE = 'event_name'
DESCRIPTION_ENVIRONMENT_VARIABLE = 'description'
GUI_LEVEL_ENVIRONMENT_VARIABLE = 'gui_level'
SMS_NUMBER_ENVIRONMENT_VARIABLE = 'sms_number'
EMAIL_ENABLED_ENVIRONMENT_VARIABLE = 'email_enabled'


def parse_to_alarm_config(data: Dict[str, Any]) -> Dict[str, Any]:
    result: Dict[str, Any] = {'event': {}}

    events = data.get('events') or []
    if not isinstance(events, list):
        return {}

    for event in events:
        if not isinstance(event, dict):
            continue

        event_name_id = str(event.get('eventNameId') or '').strip()
        if not event_name_id:
            continue

        event_node: Dict[str, Any] = {}

        filter_node: Dict[str, Any] = {}
        pattern = event.get('filterPattern')
        gui_notification = event.get('guiNotification', None)
        sms = event.get('sms', None)
        email = event.get('email', event.get('other', None))
        if pattern is not None and str(pattern).strip() != '':
            filter_node['pattern'] = str(pattern)

        syslog_identifier = event.get('syslogIdentifier')
        if syslog_identifier is not None and str(syslog_identifier).strip() != '':
            filter_node['syslog-identifier'] = str(syslog_identifier)

        if filter_node:
            event_node['filter'] = filter_node
        
        script_node: Dict[str, Any] = {}
        environment_node: Dict[str, Any] = {}
        event_name = event.get('eventName')
        description = event.get('description')
        gui_level = event.get('guiLevel')
        sms_number = event.get('smsNumber')

        if event_name is not None and str(event_name).strip() != '':
            environment_node[EVENT_NAME_ENVIRONMENT_VARIABLE] = {'value': str(event_name).strip()}

        if description is not None and str(description).strip() != '':
            environment_node[DESCRIPTION_ENVIRONMENT_VARIABLE] = {'value': str(description).strip()}

        if gui_level is not None and str(gui_level).strip() != '':
            environment_node[GUI_LEVEL_ENVIRONMENT_VARIABLE] = {'value': str(gui_level).strip()}

        if sms_number is not None and str(sms_number).strip() != '':
            environment_node[SMS_NUMBER_ENVIRONMENT_VARIABLE] = {'value': str(sms_number).strip()}
        if email:
            environment_node[EMAIL_ENABLED_ENVIRONMENT_VARIABLE] = {'value': 'true'}
        
        # TODO: combine scripts
        if gui_notification or email:
            path = EventHandlerFilePath.get_event_handler_script_path('event_gui_notification')
            if path != '':
                script_node['path'] = path
        if environment_node:
            script_node['environment'] = environment_node
        if script_node:
            event_node['script'] = script_node

        result['event'][event_name_id] = event_node

    if not result['event']:
        return {}

    return result
