from __future__ import annotations

from typing import Callable, Optional, Sequence, TypeVar

from app.auth.utils import login_required, permission_required
from app.core.operation.utils import router_pause_scheduler

F = TypeVar('F', bound=Callable[..., object])

class Pipeline:
    """
    Route handler decorator, accept params:
    - blueprint: Flask blueprint to register the route with
    - route_path: URL path for the route
    - methods: HTTP methods (GET, POST, etc.)
    - permissions: Required permissions for access (administrator, operator, super-operator, etc...)
    - pause_scheduler: Whether to pause the scheduler for this route (auto-determined for GET vs non-GET). 
      GET requests do not pause by default; other methods do pause by default.
    """
    def __init__(
        self,
        *,
        blueprint,
        route_path: Optional[str] = None,
        methods: Optional[Sequence[str]] = None,
        permissions: Optional[Sequence[str]] = None,
        pause_scheduler: Optional[bool] = None,
    ):
        self.blueprint = blueprint
        self.route_path = route_path
        self.methods = list(methods) if methods is not None else None
        self.permissions = list(permissions) if permissions is not None else []
        self.pause_scheduler = pause_scheduler

    def with_route(
        self,
        *,
        route: str,
        methods: Optional[Sequence[str]] = None,
        permissions: Optional[Sequence[str]] = None,
        pause_scheduler: Optional[bool] = None,
    ) -> 'Pipeline':
        return Pipeline(
            blueprint=self.blueprint,
            route_path=route,
            methods=methods,
            permissions=self.permissions if permissions is None else permissions,
            pause_scheduler=pause_scheduler,
        )

    def route(
        self,
        route: str,
        *,
        methods: Optional[Sequence[str]] = None,
        permissions: Optional[Sequence[str]] = None,
        pause_scheduler: Optional[bool] = None,
    ) -> Callable[[F], F]:
        return self.with_route(
            route=route,
            methods=methods,
            permissions=permissions,
            pause_scheduler=pause_scheduler,
        )

    @classmethod
    def admin(cls, blueprint) -> 'Pipeline':
        return cls(
            blueprint=blueprint,
            permissions=['administrator'],
        )

    @classmethod
    def operator(cls, blueprint) -> 'Pipeline':
        return cls(
            blueprint=blueprint,
            permissions=['operator'],
        )

    @classmethod
    def super_operator(cls, blueprint) -> 'Pipeline':
        return cls(
            blueprint=blueprint,
            permissions=['super-operator'],
        )

    @classmethod
    def guest(cls, blueprint) -> 'Pipeline':
        return cls(
            blueprint=blueprint,
            permissions=['guest'],
        )

    def __call__(self, func: F) -> F:
        if not self.route_path:
            raise ValueError('Pipeline requires route to be set. Use Pipeline.route(...) or Pipeline.with_route(...)')
        
        wrapped: Callable[..., object] = func
        
        methods = self.methods
        auto_pause_scheduler = not (
            isinstance(methods, list)
            and len(methods) == 1
            and isinstance(methods[0], str)
            and methods[0].upper() == 'GET'
        )
        should_pause_scheduler = auto_pause_scheduler if self.pause_scheduler is None else self.pause_scheduler

        if should_pause_scheduler:
            wrapped = router_pause_scheduler(wrapped)

        is_guest_route = any(str(p).lower() == 'guest' for p in (self.permissions or []))
        if not is_guest_route:
            if self.permissions:
                wrapped = permission_required(permissions=self.permissions)(wrapped)

            wrapped = login_required(wrapped)
        wrapped = self.blueprint.route(self.route_path, methods=self.methods)(wrapped)

        return wrapped

# admin_vpn = Pipeline.admin(vyos_vpn_bp)
# operator_vpn = Pipeline.operator(vyos_vpn_bp)
# @admin_vpn.route('/pptp', methods=['GET'])
# @admin_vpn.route('/pptp', methods=['PUT'])
# @admin_vpn.route('/pptp', methods=['PUT'], pause_scheduler=False)
    