from typing import List, Optional

from pydantic import BaseModel, Field, model_validator
from sqlalchemy import Boolean, Column, Integer, String

from app.db.database import db


class SSHRekeyDTO(BaseModel):
    enabled: bool = False
    data: Optional[int] = Field(default=None, ge=1, le=65535)
    time: Optional[int] = Field(default=None, ge=1, le=65535)

    @model_validator(mode='after')
    def require_data_when_enabled(self):
        if self.enabled and self.data is None:
            raise ValueError('Rekey data is required when rekey is enabled')
        return self


class SSHAccessControlDTO(BaseModel):
    allow_users: List[str] = Field(default_factory=list)
    deny_users: List[str] = Field(default_factory=list)


class SSHDynamicProtectionDTO(BaseModel):
    enabled: bool = False
    allow_from: List[str] = Field(default_factory=list)
    block_time: Optional[int] = Field(default=None, ge=1, le=65535)
    detect_time: Optional[int] = Field(default=None, ge=1, le=65535)
    threshold: Optional[int] = Field(default=None, ge=1, le=65535)


class SSHDTO(BaseModel):
    enabled: bool = False
    client_keepalive_interval: Optional[int] = Field(default=None, ge=1, le=65535)
    disable_host_validation: bool = False
    disable_password_authentication: bool = False
    listen_addresses: List[str] = Field(default_factory=list)
    loglevel: str = ""
    ciphers: List[str] = Field(default_factory=list)
    hostkey_algorithms: List[str] = Field(default_factory=list)
    key_exchanges: List[str] = Field(default_factory=list)
    macs: List[str] = Field(default_factory=list)
    ports: List[int] = Field(default_factory=list)
    pubkey_accepted_algorithms: List[str] = Field(default_factory=list)
    rekey: SSHRekeyDTO = Field(default_factory=SSHRekeyDTO)
    trusted_user_ca: Optional[str] = None
    access_control: SSHAccessControlDTO = Field(default_factory=SSHAccessControlDTO)
    dynamic_protection: SSHDynamicProtectionDTO = Field(default_factory=SSHDynamicProtectionDTO)


class SSHConfig(db.Model):
    __tablename__ = 'vyos_config_ssh'

    id = Column(Integer, primary_key=True)
    client_keepalive_interval = Column(Integer)
    disable_host_validation = Column(Boolean, default=False)
    disable_password_authentication = Column(Boolean, default=False)
    loglevel = Column(String(16))
    rekey_data = Column(Integer)
    rekey_time = Column(Integer)
    trusted_user_ca = Column(String(255))
    dynamic_protection = Column(Boolean, default=False)
    dynamic_protection_block_time = Column(Integer)
    dynamic_protection_detect_time = Column(Integer)
    dynamic_protection_threshold = Column(Integer)

    @classmethod
    def truncate(cls):
        SSHMultiValue.query.delete()
        cls.query.delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        """Replace the persisted SSH configuration with VyOS-shaped data."""
        cls.truncate()
        if data is None:
            return

        rekey = data.get('rekey') or {}
        protection = data.get('dynamic-protection')
        protection_config = protection if isinstance(protection, dict) else {}

        config = cls(
            client_keepalive_interval=_to_int(data.get('client-keepalive-interval')),
            disable_host_validation='disable-host-validation' in data,
            disable_password_authentication='disable-password-authentication' in data,
            loglevel=data.get('loglevel'),
            rekey_data=_to_int(rekey.get('data')),
            rekey_time=_to_int(rekey.get('time')),
            trusted_user_ca=data.get('trusted-user-ca'),
            dynamic_protection=protection is not None,
            dynamic_protection_block_time=_to_int(protection_config.get('block-time')),
            dynamic_protection_detect_time=_to_int(protection_config.get('detect-time')),
            dynamic_protection_threshold=_to_int(protection_config.get('threshold')),
        )
        db.session.add(config)

        for category, values in _multi_values_from_config(data).items():
            for value in values:
                db.session.add(SSHMultiValue(category=category, value=str(value)))

        db.session.commit()

    def serialize(self) -> dict:
        config = {'enabled': True}
        _set_if_present(config, 'loglevel', self.loglevel)
        _set_if_present(config, 'client-keepalive-interval', self.client_keepalive_interval)
        _set_if_present(config, 'trusted-user-ca', self.trusted_user_ca)

        if self.disable_host_validation:
            config['disable-host-validation'] = {}
        if self.disable_password_authentication:
            config['disable-password-authentication'] = {}

        values = SSHMultiValue.query.all()
        grouped = {}
        for item in values:
            grouped.setdefault(item.category, []).append(item.value)

        for category in ('listen-address', 'cipher', 'hostkey-algorithm', 'key-exchange', 'mac', 'pubkey-accepted-algorithm'):
            if grouped.get(category):
                config[category] = grouped[category]
        if grouped.get('port'):
            config['port'] = [int(port) for port in grouped['port']]

        rekey = {}
        _set_if_present(rekey, 'data', self.rekey_data)
        _set_if_present(rekey, 'time', self.rekey_time)
        if rekey:
            config['rekey'] = rekey

        access_control = {}
        if grouped.get('allow-user'):
            access_control['allow'] = {'user': grouped['allow-user']}
        if grouped.get('deny-user'):
            access_control['deny'] = {'user': grouped['deny-user']}
        if access_control:
            config['access-control'] = access_control

        if self.dynamic_protection:
            protection = {}
            if grouped.get('dynamic-allow-from'):
                protection['allow-from'] = grouped['dynamic-allow-from']
            _set_if_present(protection, 'block-time', self.dynamic_protection_block_time)
            _set_if_present(protection, 'detect-time', self.dynamic_protection_detect_time)
            _set_if_present(protection, 'threshold', self.dynamic_protection_threshold)
            config['dynamic-protection'] = protection

        return config


class SSHMultiValue(db.Model):
    __tablename__ = 'vyos_config_ssh_multi_value'

    id = Column(Integer, primary_key=True)
    category = Column(String(64), nullable=False)
    value = Column(String(255), nullable=False)


def _to_int(value):
    if value in (None, ''):
        return None
    return int(value)


def _as_list(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _set_if_present(config, key, value):
    if value is not None and value != '':
        config[key] = value


def _multi_values_from_config(data):
    values = {
        category: _as_list(data.get(category))
        for category in (
            'listen-address', 'cipher', 'hostkey-algorithm', 'key-exchange',
            'mac', 'port', 'pubkey-accepted-algorithm',
        )
    }
    access_control = data.get('access-control') or {}
    values['allow-user'] = _as_list((access_control.get('allow') or {}).get('user'))
    values['deny-user'] = _as_list((access_control.get('deny') or {}).get('user'))
    protection = data.get('dynamic-protection') or {}
    values['dynamic-allow-from'] = _as_list(protection.get('allow-from'))
    return values
