import pytest
from app.core.network.dns.models import DNSForwardingDTO
from app.core.network.dns.parser import parse_dns_config
from app.test.core.network.dns.test_cases._test_case_parse_input import (
    test_case_valid,
    test_case_invalid,
    test_case_minimal,
    test_case_comparison
)
from app.test.core.base import TestParseInput   

class TestDNSParseConfig(TestParseInput):
    __test__ = True
    
    @pytest.mark.parametrize("test_data", test_case_valid)
    def test_model_validate_json_valid(self, test_data):
        super().test_model_validate_json_valid(test_data, DNSForwardingDTO)
    
    @pytest.mark.parametrize("test_data", test_case_invalid)
    def test_model_validate_json_invalid(self, test_data):
        super().test_model_validate_json_invalid(test_data, DNSForwardingDTO)
    
    @pytest.mark.parametrize("test_data", test_case_minimal)
    def test_model_validate_minimal_json(self, test_data):
        super().test_model_validate_minimal_json(test_data, DNSForwardingDTO)
        
    @pytest.mark.parametrize("test_data", test_case_comparison)
    def test_compare_configs_additions(self, test_data):
        super().test_compare_configs_additions(test_data)