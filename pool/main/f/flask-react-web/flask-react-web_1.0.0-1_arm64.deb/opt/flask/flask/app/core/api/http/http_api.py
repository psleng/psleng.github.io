from app.core.api.api import API, ServiceProvider, API_RESOLVER
from app.log.logger import logger
from app.core.operation.utils import measure_time, pause_scheduler
from app.core.api.api import API_ACTION, API_TARGET

class HTTP_API(API):
    def __init__(self, app, provider: ServiceProvider):
        super().__init__()
        self.config = app.config
        self.context = app.app_context()    
        self._actions = None
        self.provider = provider

    @property
    def actions(self):
        if self._actions is None:
            self._actions = API_RESOLVER().actions()
        return self._actions

    @measure_time(log_level='INFO')
    @pause_scheduler(do_pause=True, pause_actions=['UPDATE', 'CREATE', 'DELETE'])
    def call(self, action: API_ACTION, target: API_TARGET, data: dict = {}):
        """
        Call API by action and target.

        :param action: API_ACTION
        :param target: API_TARGET
        :param data: Data for query
        """
        try:
            logger.debug(f"HTTP API call: {action}, {target}, {data} \n")
            return self.actions[action][target](self.provider, data)
        except Exception as e:
            logger.error(f"Action: {action}, Target: {target}, Data: {data}")
            logger.error(f"Error in HTTP API call: {str(e)}")
            return e

    def get_api_type(self):
        return "HTTP"
