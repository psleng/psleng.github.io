from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_NTP_CONFIG, SHOW_NTP_SYSTEM, SHOW_NTP_SOURCE
import pprint
import logging
from flask import session
from app.core.network.ntp.command_ntp import NTPCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from app.core.network.ntp.parser import parse_ntp_config, parse_to_ntp_config, parse_ntp_source, \
    parse_ntp_system, parse_ntp_system_gql, parsed_ntp_source_gql
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_ntp_config(provider, params=None):
    """Fetch NTP configuration."""
    
    logger.debug("Fetching NTP config...")
    print("Fetching NTP config...")
    ntp_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_NTP_CONFIG, verify=False)
    data = ntp_response.json()['data']
    return data
    # return parsed_data
    

def update_ntp(provider, data):
    """Update NTP configuration."""
    username = session['username']
    diff = data.get('diff')
    current_ntp = data.get('current')
    new_ntp = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    print("Current NTP: ")
    print(pprint.pformat(current_ntp, indent=2, width=80))

    r = []
    ## Generate set commands
    set_cmds = []
    ntp_set_cmd = NTPCommand(operator='set', resource='ntp')
    set_cmds = ntp_set_cmd.generate_commands(diff['created'], current_ntp, new_ntp)
    sc = ntp_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc, tag_object=True)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    ## Generate delete commands
    delete_cmds = []
    ntp_del_cmd = NTPCommand(operator='delete', resource='ntp')
    delete_cmds = ntp_del_cmd.generate_commands(diff['deleted'], current_ntp, new_ntp)
    dc = ntp_del_cmd.get_commands()
    new_del_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    ## Validate commands
    service = "ntp"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete({"service": {"ntp": current_config}}, new_del_configs, clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config.get('service', {}).get('ntp', {}))
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)


    parse_ntp_conf = parse_to_ntp_config({"ntp": merged_config})
    print("Parsed NTP config to update:")
    print(pprint.pformat(parse_ntp_conf, indent=2, width=80))

    # Update DB

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update NTP",
                "content": "NTP is successfully updated"
            }
    )

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r


def verify_ntp(provider, data):
    """Verify NTP configuration."""
    
    logger.debug("Verifying NTP config...")
    print("Verifying NTP config...")
    
    service = "ntp"
    verify = provider.verify_service.call_verify(service, data)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify

def fetch_ntp_system(provider, params=None):

    logger.debug("Fetching NTP system config...")
    print("Fetching NTP system config...")
    ntp_response = provider.http_service.send_request(action=Action.SHOW, data=SHOW_NTP_SYSTEM, verify=False)
    data = ntp_response.json()['data']
    print("NTP System: ")
    print(data)
    return parse_ntp_system(data)

def fetch_ntp_source(provider, params=None):
    logger.debug("Fetching NTP source config...")
    print("Fetching NTP source config...")
    ntp_response = provider.http_service.send_request(action=Action.SHOW, data=SHOW_NTP_SOURCE, verify=False)
    data = ntp_response.json()['data']
    print("NTP Source: ")

    print(data)
    return parse_ntp_source(data)


def fetch_ntp_source_gql(provider, params=None):
    
    ntp_source = provider.graphql_service.send_request(function_name='ShowSourcesNtpQuery', data={}, verify=False) 
    ntp_source_stat = provider.graphql_service.send_request(function_name='ShowSourcestatsNtpQuery ', data={}, verify=False)
    parsed_ntp = parsed_ntp_source_gql(ntp_source.json()['data'], ntp_source_stat.json()['data'])
    return parsed_ntp


def fetch_ntp_system_gql(provider, params=None):
    
    ntp_system = provider.graphql_service.send_request(function_name='ShowSystemNtpQuery', data={}, verify=False) 
    parsed_ntp = parse_ntp_system_gql(ntp_system.json()['data'])
    return parsed_ntp


def restart_ntp(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartServiceRestartServiceMutation',
        data={"name": "ntp"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}
