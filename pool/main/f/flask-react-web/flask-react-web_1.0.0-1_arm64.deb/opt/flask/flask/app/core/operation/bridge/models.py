from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.log.logger import logger


class BridgeAddress(db.Model):
    __tablename__ = "vyos_config_bridge_address"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    bridge_config_id = Column(Integer, ForeignKey('vyos_config_bridge.id', ondelete='CASCADE'), nullable=False)
    address = Column(String, nullable=False)
    
    bridge_config = relationship("BridgeInterfaceConfig", back_populates="addresses")


class BridgeMemberInterface(db.Model):
    __tablename__ = "vyos_config_bridge_member"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    bridge_config_id = Column(Integer, ForeignKey('vyos_config_bridge.id', ondelete='CASCADE'), nullable=False)
    interface_name = Column(String, nullable=False)
    
    bridge_config = relationship("BridgeInterfaceConfig", back_populates="member_interfaces")


class BridgeInterfaceConfig(db.Model):
    __tablename__ = "vyos_config_bridge"

    id = Column(Integer, primary_key=True, autoincrement=True)
    interface_name = Column(String, nullable=False, unique=True)
    description = Column(String, nullable=True)
    disabled = Column(Boolean, default=False)
    mtu = Column(String, nullable=True)
    aging = Column(String, nullable=True)
    disable_link_detect = Column(Boolean, default=False)
    
    addresses = relationship("BridgeAddress", back_populates="bridge_config", cascade="all, delete-orphan")
    member_interfaces = relationship("BridgeMemberInterface", back_populates="bridge_config", cascade="all, delete-orphan")
    
    @classmethod
    def truncate(cls):
        try:
            db.session.query(BridgeMemberInterface).delete()
            db.session.query(BridgeAddress).delete()
            db.session.query(cls).delete()
            db.session.commit()
        except Exception as e:
            # db.session.rollback()
            logger.error(f"Error truncating Bridge config: {e}")

    @classmethod
    def upsert(cls, data: dict, app_context=None):
        if not data or not isinstance(data, dict):
            return

        existing_data = {
            bridge.interface_name: bridge.serialize()
            for bridge in cls.query.all()
            if bridge.interface_name not in data
        }
        existing_data.update(data)
        cls.refresh(existing_data, app_context)
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        try:
            logger.debug(f"Refreshing Bridge config with data: {data}")
            
            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()
            
            if not data or not isinstance(data, dict):
                logger.warning("No Bridge data to refresh")
                return
            
            for interface_name, config in data.items():
                if not isinstance(config, dict):
                    continue

                # clean up old IP/DHCP options for this interface before creating new ones
                from app.core.operation.ip_options.models import IPv4OptionConfig, IPv6OptionConfig
                from app.core.operation.dhcp_options.models import DHCPv4OptionConfig, DHCPv6OptionConfig
                
                IPv4OptionConfig.query.filter_by(interface_name=interface_name, interface_type='bridge', vlan_id=None).delete()
                IPv6OptionConfig.query.filter_by(interface_name=interface_name, interface_type='bridge', vlan_id=None).delete()
                DHCPv4OptionConfig.query.filter_by(interface_name=interface_name, interface_type='bridge', vlan_id=None).delete()
                DHCPv6OptionConfig.query.filter_by(interface_name=interface_name, interface_type='bridge', vlan_id=None).delete()
                
                addresses = config.get('address')
                description = config.get('description')
                disabled = 'disable' in config
                
                mtu_value = config.get('mtu')
                if isinstance(mtu_value, dict):
                    mtu = None
                else:
                    mtu = str(mtu_value) if mtu_value else None
                
                aging_value = config.get('aging')
                aging = str(aging_value) if aging_value and not isinstance(aging_value, dict) else None
                
                disable_link_detect = 'disable-link-detect' in config
                
                new_bridge = cls(
                    interface_name=interface_name,
                    description=description,
                    disabled=disabled,
                    mtu=mtu,
                    aging=aging,
                    disable_link_detect=disable_link_detect
                )
                
                if app_context:
                    with app_context:
                        db.session.add(new_bridge)
                        db.session.flush()
                else:
                    db.session.add(new_bridge)
                    db.session.flush()
                
                if addresses:
                    if not isinstance(addresses, list):
                        addresses = [addresses]
                    
                    for addr in addresses:
                        if addr:
                            addr_record = BridgeAddress(
                                bridge_config_id=new_bridge.id,
                                address=str(addr)
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(addr_record)
                            else:
                                db.session.add(addr_record)
                
                if 'member' in config and 'interface' in config['member']:
                    member_intfs = config['member']['interface']
                    if isinstance(member_intfs, dict):
                        for member_name in member_intfs.keys():
                            member_record = BridgeMemberInterface(
                                bridge_config_id=new_bridge.id,
                                interface_name=member_name
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(member_record)
                            else:
                                db.session.add(member_record)
                
                if 'ip' in config:
                    from app.core.operation.ip_options.models import IPv4OptionConfig
                    ip_config = config['ip']
                    
                    adjust_mss = ip_config.get('adjust-mss') or ip_config.get('adjust_mss')
                    arp_cache_key = 'arp-cache-timeout' if 'arp-cache-timeout' in ip_config else 'arp_cache_timeout'
                    arp_cache_timeout = ip_config.get(arp_cache_key)
                    source_val = ip_config.get('source-validation') or ip_config.get('source_validation')
                    
                    ipv4_option = IPv4OptionConfig(
                        interface_type='bridge',
                        interface_name=interface_name,
                        vlan_id=None,
                        adjust_mss=adjust_mss,
                        arp_cache_timeout=int(arp_cache_timeout) if arp_cache_timeout and not isinstance(arp_cache_timeout, dict) else None,
                        disable_arp_filter='disable-arp-filter' in ip_config or 'disable_arp_filter' in ip_config,
                        disable_forwarding='disable-forwarding' in ip_config or 'disable_forwarding' in ip_config,
                        enable_arp_accept='enable-arp-accept' in ip_config or 'enable_arp_accept' in ip_config,
                        enable_arp_announce='enable-arp-announce' in ip_config or 'enable_arp_announce' in ip_config,
                        enable_arp_ignore='enable-arp-ignore' in ip_config or 'enable_arp_ignore' in ip_config,
                        enable_directed_broadcast='enable-directed-broadcast' in ip_config or 'enable_directed_broadcast' in ip_config,
                        enable_proxy_arp='enable-proxy-arp' in ip_config or 'enable_proxy_arp' in ip_config,
                        proxy_arp_pvlan='proxy-arp-pvlan' in ip_config or 'proxy_arp_pvlan' in ip_config,
                        source_validation=source_val
                    )
                    if app_context:
                        with app_context:
                            db.session.add(ipv4_option)
                    else:
                        db.session.add(ipv4_option)
                
                if 'ipv6' in config:
                    from app.core.operation.ip_options.models import IPv6OptionConfig
                    ipv6_config = config['ipv6']
                    
                    accept_dad = None
                    address_autoconf = False
                    address_eui64 = None
                    address_no_default_link_local = False
                    
                    if 'address' in ipv6_config:
                        addr_config = ipv6_config['address']
                        if isinstance(addr_config, dict):
                            address_autoconf = 'autoconf' in addr_config
                            # eui64 can be a string or a list
                            eui64_value = addr_config.get('eui64')
                            if isinstance(eui64_value, list):
                                address_eui64 = eui64_value[0] if eui64_value else None
                            else:
                                address_eui64 = eui64_value
                            address_no_default_link_local = 'no-default-link-local' in addr_config or 'no_default_link_local' in addr_config
                    
                    accept_dad_key = 'accept-dad' if 'accept-dad' in ipv6_config else 'accept_dad'
                    accept_dad_val = ipv6_config.get(accept_dad_key)
                    if accept_dad_val and not isinstance(accept_dad_val, dict):
                        accept_dad = int(accept_dad_val)
                    
                    adjust_mss_v6 = ipv6_config.get('adjust-mss') or ipv6_config.get('adjust_mss')
                    base_reach_key = 'base-reachable-time' if 'base-reachable-time' in ipv6_config else 'base_reachable_time'
                    base_reach_val = ipv6_config.get(base_reach_key)
                    dup_addr_key = 'dup-addr-detect-transmits' if 'dup-addr-detect-transmits' in ipv6_config else 'dup_addr_detect_transmits'
                    dup_addr_val = ipv6_config.get(dup_addr_key)
                    source_val_v6 = ipv6_config.get('source-validation') or ipv6_config.get('source_validation')
                    
                    ipv6_option = IPv6OptionConfig(
                        interface_type='bridge',
                        interface_name=interface_name,
                        vlan_id=None,
                        accept_dad=accept_dad,
                        address_autoconf=address_autoconf,
                        address_eui64=address_eui64,
                        address_no_default_link_local=address_no_default_link_local,
                        adjust_mss=adjust_mss_v6,
                        base_reachable_time=int(base_reach_val) if base_reach_val and not isinstance(base_reach_val, dict) else None,
                        disable_forwarding='disable-forwarding' in ipv6_config or 'disable_forwarding' in ipv6_config,
                        dup_addr_detect_transmits=int(dup_addr_val) if dup_addr_val and not isinstance(dup_addr_val, dict) else None,
                        source_validation=source_val_v6
                    )
                    if app_context:
                        with app_context:
                            db.session.add(ipv6_option)
                    else:
                        db.session.add(ipv6_option)
                
                dhcp_key = 'dhcp-options' if 'dhcp-options' in config else 'dhcp_options'
                if dhcp_key in config:
                    from app.core.operation.dhcp_options.models import DHCPv4OptionConfig
                    dhcp_config = config[dhcp_key]
                    
                    if not isinstance(dhcp_config, dict):
                        logger.warning(f"DHCP config is not a dict: {dhcp_config}, skipping")
                        dhcp_config = {}
                    
                    client_id = dhcp_config.get('client-id') or dhcp_config.get('client_id')
                    default_route_dist_key = 'default-route-distance' if 'default-route-distance' in dhcp_config else 'default_route_distance'
                    default_route_dist = dhcp_config.get(default_route_dist_key)
                    host_name = dhcp_config.get('host-name') or dhcp_config.get('host_name')
                    user_class = dhcp_config.get('user-class') or dhcp_config.get('user_class')
                    vendor_class = dhcp_config.get('vendor-class-id') or dhcp_config.get('vendor_class_id')
                    
                    dhcpv4_option = DHCPv4OptionConfig(
                        interface_type='bridge',
                        interface_name=interface_name,
                        vlan_id=None,
                        client_id=client_id,
                        default_route_distance=int(default_route_dist) if default_route_dist and not isinstance(default_route_dist, dict) else None,
                        host_name=host_name,
                        mtu='mtu' in dhcp_config,
                        no_default_route='no-default-route' in dhcp_config or 'no_default_route' in dhcp_config,
                        user_class=user_class,
                        vendor_class_id=vendor_class
                    )
                    if app_context:
                        with app_context:
                            db.session.add(dhcpv4_option)
                    else:
                        db.session.add(dhcpv4_option)
                
                if 'dhcpv6-options' in config:
                    from app.core.operation.dhcp_options.models import (
                        DHCPv6OptionConfig, 
                        DHCPv6PrefixDelegation, 
                        DHCPv6PDInterface
                    )
                    dhcpv6_config = config['dhcpv6-options']
                    
                    if not isinstance(dhcpv6_config, dict):
                        logger.warning(f"DHCPv6 config is not a dict: {dhcpv6_config}, skipping")
                        dhcpv6_config = {}
                    
                    dhcpv6_option = DHCPv6OptionConfig(
                        interface_type='bridge',
                        interface_name=interface_name,
                        vlan_id=None,
                        duid=dhcpv6_config.get('duid'),
                        no_release='no-release' in dhcpv6_config,
                        parameters_only='parameters-only' in dhcpv6_config,
                        rapid_commit='rapid-commit' in dhcpv6_config,
                        temporary='temporary' in dhcpv6_config
                    )
                    if app_context:
                        with app_context:
                            db.session.add(dhcpv6_option)
                            db.session.flush()
                    else:
                        db.session.add(dhcpv6_option)
                        db.session.flush()
                    
                    if 'pd' in dhcpv6_config:
                        for instance_id, pd_config in dhcpv6_config['pd'].items():
                            pd_entry = DHCPv6PrefixDelegation(
                                dhcpv6_config_id=dhcpv6_option.id,
                                instance_id=instance_id,
                                length=int(pd_config['length']) if 'length' in pd_config else None
                            )
                            if app_context:
                                with app_context:
                                    db.session.add(pd_entry)
                                    db.session.flush()
                            else:
                                db.session.add(pd_entry)
                                db.session.flush()
                            
                            if 'interface' in pd_config:
                                for intf_name, intf_config in pd_config['interface'].items():
                                    pd_intf = DHCPv6PDInterface(
                                        pd_id=pd_entry.id,
                                        interface_name=intf_name,
                                        address=int(intf_config['address']) if 'address' in intf_config else None,
                                        sla_id=int(intf_config['sla-id']) if 'sla-id' in intf_config else None,
                                        sla_length=int(intf_config['sla-length']) if 'sla-length' in intf_config else None
                                    )
                                    if app_context:
                                        with app_context:
                                            db.session.add(pd_intf)
                                    else:
                                        db.session.add(pd_intf)
            
            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
        except Exception as e:
            # db.session.rollback()
            logger.error(f"Error refreshing Bridge data: {e}")
            raise e

    def serialize(self):
        result = {}
        
        if self.interface_name:
            result['interface-name'] = self.interface_name
        
        if self.addresses:
            addr_list = [addr.address for addr in self.addresses]
            if len(addr_list) == 1:
                result['address'] = addr_list[0]
            elif len(addr_list) > 1:
                result['address'] = addr_list
        
        if self.description:
            result['description'] = self.description
        
        if self.disabled:
            result['disable'] = {}
        
        if self.mtu:
            result['mtu'] = self.mtu
        
        if self.aging:
            result['aging'] = self.aging
        
        if self.disable_link_detect:
            result['disable-link-detect'] = {}
        
        if self.member_interfaces:
            result['member'] = {
                'interface': {member.interface_name: {} for member in self.member_interfaces}
            }
        
        from app.core.operation.ip_options.models import IPv4OptionConfig
        ipv4_config = IPv4OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            interface_type='bridge',
            vlan_id=None
        ).first()
        
        if ipv4_config:
            ip_result = ipv4_config.to_vyos_format()
            if ip_result:
                result['ip'] = ip_result
        
        from app.core.operation.ip_options.models import IPv6OptionConfig
        ipv6_config = IPv6OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            interface_type='bridge',
            vlan_id=None
        ).first()
            
        if ipv6_config:
            ipv6_result = ipv6_config.to_vyos_format()
            if ipv6_result:
                result['ipv6'] = ipv6_result
        
        from app.core.operation.dhcp_options.models import DHCPv4OptionConfig
        dhcpv4_config = DHCPv4OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            interface_type='bridge',
            vlan_id=None
        ).first()
        
        if dhcpv4_config:
            dhcp_result = dhcpv4_config.to_vyos_format()
            if dhcp_result:
                result['dhcp-options'] = dhcp_result
        
        from app.core.operation.dhcp_options.models import DHCPv6OptionConfig
        dhcpv6_config = DHCPv6OptionConfig.query.filter_by(
            interface_name=self.interface_name,
            interface_type='bridge',
            vlan_id=None
        ).first()
        
        if dhcpv6_config:
            dhcpv6_result = dhcpv6_config.to_vyos_format()
            if dhcpv6_result:
                result['dhcpv6-options'] = dhcpv6_result
        
        return result
