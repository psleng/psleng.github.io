import pprint
import logging

logger = logging.getLogger(__name__)

def parse_ipv6_ra_config(config):
    logger.debug(f"Parsing IPv6 RA config: {pprint.pformat(config, indent=2, width=80)}")
    
    result = []
    
    if not config or not isinstance(config, dict):
        return result
    
    if 'interfaces' not in config:
        return result
    
    interfaces_data = config['interfaces']
    if not isinstance(interfaces_data, dict):
        return result
    
    for interface_name, intf_config in interfaces_data.items():
        if not isinstance(intf_config, dict):
            continue
        
        interface_data = {
            'interface_name': interface_name,
            'auto_ignore_prefixes': [],
            'default_lifetime': None,
            'default_preference': None,
            'hop_limit': None,
            'interval_max': None,
            'interval_min': None,
            'link_mtu': None,
            'managed_flag': False,
            'name_servers': [],
            'name_server_lifetime': None,
            'no_send_advert': False,
            'no_send_interval': False,
            'other_config_flag': False,
            'prefixes': [],
            'reachable_time': None,
            'retrans_timer': None,
            'source_addresses': [],
            'routes': []
        }
        
        if 'auto-ignore' in intf_config:
            auto_ignore = intf_config['auto-ignore']
            if isinstance(auto_ignore, list):
                interface_data['auto_ignore_prefixes'] = auto_ignore
            elif auto_ignore:
                interface_data['auto_ignore_prefixes'] = [auto_ignore]
        
        if 'default-lifetime' in intf_config:
            interface_data['default_lifetime'] = intf_config['default-lifetime']
        
        if 'default-preference' in intf_config:
            interface_data['default_preference'] = intf_config['default-preference']
        
        if 'hop-limit' in intf_config:
            interface_data['hop_limit'] = intf_config['hop-limit']
        
        if 'interval' in intf_config and isinstance(intf_config['interval'], dict):
            if 'max' in intf_config['interval']:
                interface_data['interval_max'] = intf_config['interval']['max']
            if 'min' in intf_config['interval']:
                interface_data['interval_min'] = intf_config['interval']['min']
        
        if 'link-mtu' in intf_config:
            interface_data['link_mtu'] = intf_config['link-mtu']
        
        if 'name-server-lifetime' in intf_config:
            interface_data['name_server_lifetime'] = intf_config['name-server-lifetime']
        
        if 'reachable-time' in intf_config:
            interface_data['reachable_time'] = intf_config['reachable-time']
        
        if 'retrans-timer' in intf_config:
            interface_data['retrans_timer'] = intf_config['retrans-timer']
        
        interface_data['managed_flag'] = 'managed-flag' in intf_config
        interface_data['no_send_advert'] = 'no-send-advert' in intf_config
        interface_data['no_send_interval'] = 'no-send-interval' in intf_config
        interface_data['other_config_flag'] = 'other-config-flag' in intf_config
        
        if 'name-server' in intf_config:
            name_servers = intf_config['name-server']
            if isinstance(name_servers, list):
                interface_data['name_servers'] = name_servers
            elif name_servers:
                interface_data['name_servers'] = [name_servers]
        
        if 'prefix' in intf_config:
            prefixes = intf_config['prefix']
            if isinstance(prefixes, dict):
                for prefix_key, prefix_config in prefixes.items():
                    prefix_data = {
                        'prefix': prefix_key,
                        'decrement_lifetime': 'decrement-lifetime' in prefix_config if isinstance(prefix_config, dict) else False,
                        'deprecate_prefix': 'deprecate-prefix' in prefix_config if isinstance(prefix_config, dict) else False,
                        'no_autonomous_flag': 'no-autonomous-flag' in prefix_config if isinstance(prefix_config, dict) else False,
                        'no_on_link_flag': 'no-on-link-flag' in prefix_config if isinstance(prefix_config, dict) else False,
                        'preferred_lifetime': prefix_config.get('preferred-lifetime') if isinstance(prefix_config, dict) else None,
                        'valid_lifetime': prefix_config.get('valid-lifetime') if isinstance(prefix_config, dict) else None
                    }
                    interface_data['prefixes'].append(prefix_data)
            elif isinstance(prefixes, list):
                for prefix_str in prefixes:
                    interface_data['prefixes'].append({
                        'prefix': prefix_str,
                        'decrement_lifetime': False,
                        'deprecate_prefix': False,
                        'no_autonomous_flag': False,
                        'no_on_link_flag': False,
                        'preferred_lifetime': None,
                        'valid_lifetime': None
                    })
            elif prefixes:
                interface_data['prefixes'].append({
                    'prefix': prefixes,
                    'decrement_lifetime': False,
                    'deprecate_prefix': False,
                    'no_autonomous_flag': False,
                    'no_on_link_flag': False,
                    'preferred_lifetime': None,
                    'valid_lifetime': None
                })
        
        if 'source-address' in intf_config:
            source_addrs = intf_config['source-address']
            if isinstance(source_addrs, list):
                interface_data['source_addresses'] = source_addrs
            elif source_addrs:
                interface_data['source_addresses'] = [source_addrs]
        
        if 'route' in intf_config and isinstance(intf_config['route'], dict):
            for route_prefix, route_config in intf_config['route'].items():
                if not isinstance(route_config, dict):
                    route_config = {}
                
                route_data = {
                    'prefix': route_prefix,
                    'no_remove_route': 'no-remove-route' in route_config,
                    'route_preference': route_config.get('route-preference'),
                    'valid_lifetime': route_config.get('valid-lifetime')
                }
                interface_data['routes'].append(route_data)
        
        result.append(interface_data)
    
    logger.debug(f"Parsed IPv6 RA config: {pprint.pformat(result, indent=2, width=80)}")
    return result


def parse_to_ipv6_ra_config(data: dict):

    result = {'interface': {}}
    
    if not data or 'interfaces' not in data:
        return result
    
    interfaces = data['interfaces']
    if not isinstance(interfaces, list):
        return result
    
    for intf_data in interfaces:
        if not isinstance(intf_data, dict) or 'interface_name' not in intf_data:
            continue
        
        interface_name = intf_data['interface_name']
        intf_config = {}
        
        if intf_data.get('auto_ignore_prefixes'):
            prefixes = intf_data['auto_ignore_prefixes']
            if len(prefixes) == 1:
                intf_config['auto-ignore'] = prefixes[0]
            elif len(prefixes) > 1:
                intf_config['auto-ignore'] = prefixes
        
        if intf_data.get('default_lifetime'):
            intf_config['default-lifetime'] = str(intf_data['default_lifetime'])
        
        if intf_data.get('default_preference'):
            intf_config['default-preference'] = intf_data['default_preference']
        
        if intf_data.get('hop_limit'):
            intf_config['hop-limit'] = str(intf_data['hop_limit'])
        
        if intf_data.get('interval_max') or intf_data.get('interval_min'):
            intf_config['interval'] = {}
            if intf_data.get('interval_max'):
                intf_config['interval']['max'] = str(intf_data['interval_max'])
            if intf_data.get('interval_min'):
                intf_config['interval']['min'] = str(intf_data['interval_min'])
        
        if intf_data.get('link_mtu'):
            intf_config['link-mtu'] = str(intf_data['link_mtu'])
        
        if intf_data.get('name_server_lifetime'):
            intf_config['name-server-lifetime'] = str(intf_data['name_server_lifetime'])
        
        if intf_data.get('reachable_time'):
            intf_config['reachable-time'] = str(intf_data['reachable_time'])
        
        if intf_data.get('retrans_timer'):
            intf_config['retrans-timer'] = str(intf_data['retrans_timer'])
        
        if intf_data.get('managed_flag'):
            intf_config['managed-flag'] = {}
        
        if intf_data.get('no_send_advert'):
            intf_config['no-send-advert'] = {}
        
        if intf_data.get('no_send_interval'):
            intf_config['no-send-interval'] = {}
        
        if intf_data.get('other_config_flag'):
            intf_config['other-config-flag'] = {}
        
        if intf_data.get('name_servers'):
            servers = intf_data['name_servers']
            if len(servers) == 1:
                intf_config['name-server'] = servers[0]
            elif len(servers) > 1:
                intf_config['name-server'] = servers
        
        if intf_data.get('prefixes'):
            intf_config['prefix'] = {}
            for prefix_item in intf_data['prefixes']:
                if isinstance(prefix_item, dict):
                    prefix_key = prefix_item.get('prefix')
                    if prefix_key:
                        prefix_config = {}
                        if prefix_item.get('decrement_lifetime'):
                            prefix_config['decrement-lifetime'] = {}
                        if prefix_item.get('deprecate_prefix'):
                            prefix_config['deprecate-prefix'] = {}
                        if prefix_item.get('no_autonomous_flag'):
                            prefix_config['no-autonomous-flag'] = {}
                        if prefix_item.get('no_on_link_flag'):
                            prefix_config['no-on-link-flag'] = {}
                        if prefix_item.get('preferred_lifetime'):
                            prefix_config['preferred-lifetime'] = str(prefix_item['preferred_lifetime'])
                        if prefix_item.get('valid_lifetime'):
                            prefix_config['valid-lifetime'] = str(prefix_item['valid_lifetime'])
                        intf_config['prefix'][prefix_key] = prefix_config
                elif isinstance(prefix_item, str):
                    intf_config['prefix'][prefix_item] = {}
        
        if intf_data.get('source_addresses'):
            addrs = intf_data['source_addresses']
            if len(addrs) == 1:
                intf_config['source-address'] = addrs[0]
            elif len(addrs) > 1:
                intf_config['source-address'] = addrs
        
        if intf_data.get('routes'):
            intf_config['route'] = {}
            for route in intf_data['routes']:
                if not isinstance(route, dict) or 'prefix' not in route:
                    continue
                
                route_prefix = route['prefix']
                route_config = {}
                
                if route.get('no_remove_route'):
                    route_config['no-remove-route'] = {}
                
                if route.get('route_preference'):
                    route_config['route-preference'] = route['route_preference']
                
                if route.get('valid_lifetime'):
                    route_config['valid-lifetime'] = str(route['valid_lifetime'])
                
                intf_config['route'][route_prefix] = route_config
        
        result['interface'][interface_name] = intf_config
    
    logger.debug(f"Converted IPv6 RA config: {pprint.pformat(result, indent=2, width=80)}")
    return result
