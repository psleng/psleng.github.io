from datetime import datetime, timezone
from hashlib import sha256
from ipaddress import ip_address, ip_network
from uuid import uuid4

from flask import current_app, request, session
from flask_socketio import ConnectionRefusedError
from sqlalchemy import inspect, text
from werkzeug.exceptions import ServiceUnavailable

from app.db.database import db


class WebSession(db.Model):
    __tablename__ = "web_sessions"

    id = db.Column(db.String(36), primary_key=True)
    username = db.Column(db.String(150), nullable=False)
    permission = db.Column(db.String(32), nullable=False)
    auth_source = db.Column(db.String(16), nullable=False)
    cloud_sid = db.Column(db.String(255), nullable=True, index=True)
    ip_address = db.Column(db.String(64), nullable=False)
    device = db.Column(db.String(16), nullable=False, default="unknown", server_default="unknown")
    authenticated_at = db.Column(db.DateTime, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    revoked_at = db.Column(db.DateTime, nullable=True)


def ensure_web_session_schema():
    columns = {column["name"] for column in inspect(db.engine).get_columns("web_sessions")}
    if "device" not in columns:
        db.session.execute(text(
            "ALTER TABLE web_sessions ADD COLUMN device VARCHAR(16) NOT NULL DEFAULT 'unknown'"
        ))
        db.session.commit()


def detect_device(user_agent):
    agent = (user_agent or "").lower()
    if "iphone" in agent:
        return "iphone"
    if "android" in agent:
        return "android"
    if any(token in agent for token in ("edg/", "edge/", "edga/", "edgios/")):
        return "edge"
    if any(token in agent for token in ("firefox/", "fxios/")):
        return "firefox"
    if any(token in agent for token in ("opr/", "opera/", "opera ", "opios/")):
        return "opera"
    if "samsungbrowser/" in agent:
        return "unknown"
    if any(token in agent for token in ("chrome/", "crios/")):
        return "chrome"
    if "safari/" in agent and "version/" in agent:
        return "safari"
    return "unknown"


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def client_ip_address():
    try:
        peer = ip_address(request.remote_addr or "")
    except ValueError:
        return ""

    configured = current_app.config.get("TRUSTED_PROXY_CIDRS", ("127.0.0.0/8", "::1/128"))
    if isinstance(configured, str):
        configured = configured.split(",")
    networks = []
    for cidr in configured:
        try:
            networks.append(ip_network(cidr.strip(), strict=False))
        except ValueError:
            continue

    def is_trusted(address):
        return any(address in network for network in networks)

    if not is_trusted(peer):
        return str(peer)

    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        address = peer
        for value in reversed(forwarded.split(",")):
            if not is_trusted(address):
                return str(address)
            try:
                address = ip_address(value.strip())
            except ValueError:
                break
        else:
            return str(address)

    try:
        return str(ip_address(request.headers.get("X-Real-IP", "").strip()))
    except ValueError:
        return str(peer)


def is_loopback_address(value):
    try:
        return ip_address(value).is_loopback
    except ValueError:
        return False


def notify_sessions_changed():
    from app.socket.socket_manager import socket_manager

    if socket_manager.socketio:
        socket_manager.socketio.emit("aaa_sessions_changed", {}, to="web-authenticated")


def start_web_session(auth_source):
    old_id = session.pop("web_session_id", None)
    if old_id:
        revoke_web_session(old_id)

    if auth_source != "cloud":
        session.pop("cloud_sid", None)
    session["auth_source"] = auth_source
    session.pop("web_session_rejected", None)
    WebSession.query.filter(WebSession.expires_at < utcnow()).delete(synchronize_session=False)
    expires_at = session.get("expires_at")
    if expires_at:
        expiry = datetime.fromisoformat(expires_at)
        if expiry.tzinfo is None:
            import pytz

            expiry = pytz.timezone("America/Toronto").localize(expiry)
        expiry = expiry.astimezone(timezone.utc).replace(tzinfo=None)
    else:
        expiry = utcnow() + current_app.permanent_session_lifetime
        session["expires_at"] = expiry.replace(tzinfo=timezone.utc).isoformat()

    record = WebSession(
        id=str(uuid4()),
        username=session["username"],
        permission=session["permission"],
        auth_source=auth_source,
        cloud_sid=session.get("cloud_sid"),
        ip_address=client_ip_address(),
        device=detect_device(request.headers.get("User-Agent")),
        authenticated_at=utcnow(),
        expires_at=expiry,
    )
    db.session.add(record)
    db.session.commit()
    session["web_session_id"] = record.id
    notify_sessions_changed()
    return record


def cloud_session_was_revoked(cloud_sid):
    return WebSession.query.filter(
        WebSession.cloud_sid == cloud_sid,
        WebSession.revoked_at.isnot(None),
    ).first() is not None


def web_session_is_active():
    session_id = session.get("web_session_id")
    record = db.session.get(WebSession, session_id) if session_id else None
    active = bool(
        record
        and record.revoked_at is None
        and record.expires_at > utcnow()
        and record.username == session.get("username")
    )
    
    if active:
        changed = False
        if record.device == "unknown":
            device = detect_device(request.headers.get("User-Agent"))
            if device != "unknown":
                record.device = device
                changed = True
        if not record.ip_address or is_loopback_address(record.ip_address):
            address = client_ip_address()
            if address and address != record.ip_address and not is_loopback_address(address):
                record.ip_address = address
                changed = True
        if changed:
            db.session.commit()
            notify_sessions_changed()
    return active


def reject_web_session():
    session_id = session.get("web_session_id")
    if session_id:
        revoke_web_session(session_id)
    clear_web_session()


def cloud_cookie_fingerprint():
    return sha256(request.cookies.get("IGOS_CLOUD_SESSION", "").encode()).hexdigest()


def clear_web_session():
    session.clear()
    session["web_session_rejected"] = cloud_cookie_fingerprint()


def register_web_socket(sid):
    from app.auth.cloud_auth import cloud_session_is_active
    from app.socket.socket_manager import socket_manager

    if session.get("user_id"):
        if not web_session_is_active():
            reject_web_session()
            return False
        try:
            cloud_active = cloud_session_is_active()
        except ServiceUnavailable as error:
            raise ConnectionRefusedError({"code": "authentication_unavailable", "message": error.description}) from error
        if not cloud_active:
            reject_web_session()
            return False
        socket_manager.register_client(sid, session["username"], session["web_session_id"])
    else:
        socket_manager.register_guest(sid)
    return True


def revoke_web_session(session_id):
    from app.socket.socket_manager import socket_manager

    record = db.session.get(WebSession, session_id)
    if not record:
        return False
    if record.revoked_at is None:
        record.revoked_at = utcnow()
        db.session.commit()

    socket_manager.disconnect_web_session(session_id)
    notify_sessions_changed()
    return True


def list_web_sessions():
    from app.socket.socket_manager import socket_manager

    records = WebSession.query.filter(
        WebSession.revoked_at.is_(None), WebSession.expires_at > utcnow()
    ).order_by(WebSession.authenticated_at.desc()).all()
    return [
        {
            "id": record.id,
            "username": record.username,
            "device": record.device,
            "permission": record.permission,
            "auth_source": record.auth_source,
            "ip_address": record.ip_address,
            "authenticated_at": record.authenticated_at.replace(tzinfo=timezone.utc).isoformat(),
            "expires_at": record.expires_at.replace(tzinfo=timezone.utc).isoformat(),
            "connection_count": socket_manager.web_session_connection_count(record.id),
            "is_current": record.id == session.get("web_session_id"),
        }
        for record in records
    ]
