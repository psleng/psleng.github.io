from app.core.operation.l2tpv3.command_l2tpv3 import L2TPv3Command
from app.core.api.http.http_request import Action
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
import pprint
from flask import session
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from app.core.models import InterfaceConfig
from app.core.operation.l2tpv3.models import L2TPv3InterfaceConfig
from app.db.database import db


def validate_unique_l2tpv3_identifiers(configs):
    if not isinstance(configs, dict):
        return None

    seen_tunnel_ids = {}
    seen_session_ids = {}
    seen_udp_source_ports = {}

    for name, config in configs.items():
        if not isinstance(config, dict):
            continue

        tunnel_id = config.get('tunnel-id') or config.get('tunnel_id')
        session_id = config.get('session-id') or config.get('session_id')
        encapsulation = config.get('encapsulation') or 'udp'
        source_address = config.get('source-address') or config.get('source_address') or ''
        source_port = config.get('source-port') or config.get('source_port')

        if tunnel_id not in (None, ''):
            tunnel_id = str(tunnel_id)
            if tunnel_id in seen_tunnel_ids:
                return (
                    f'L2TPv3 tunnel-id {tunnel_id} is already used by '
                    f'{seen_tunnel_ids[tunnel_id]}; choose a unique tunnel-id for {name}.'
                )
            seen_tunnel_ids[tunnel_id] = name

        if session_id not in (None, ''):
            session_id = str(session_id)
            if session_id in seen_session_ids:
                return (
                    f'L2TPv3 session-id {session_id} is already used by '
                    f'{seen_session_ids[session_id]}; choose a unique session-id for {name}.'
                )
            seen_session_ids[session_id] = name

        if encapsulation == 'udp' and source_port not in (None, ''):
            source_port_key = (str(source_address), str(source_port))
            if source_port_key in seen_udp_source_ports:
                return (
                    f'L2TPv3 source-port {source_port} on source-address '
                    f'{source_address or "default"} is already used by '
                    f'{seen_udp_source_ports[source_port_key]}; choose a distinct UDP source-port for {name}.'
                )
            seen_udp_source_ports[source_port_key] = name

    return None


def get_l2tpv3_db_configs(exclude_name=None):
    configs = {}
    for interface in L2TPv3InterfaceConfig.query.all():
        if exclude_name and interface.name == exclude_name:
            continue

        configs[interface.name] = {
            'tunnel-id': interface.tunnel_id,
            'session-id': interface.session_id,
            'source-address': interface.source_address,
            'source-port': interface.source_port,
            'encapsulation': interface.encapsulation or 'udp',
        }

    return configs


def normalize_l2tpv3_refresh_config(name, config):
    if not isinstance(config, dict):
        return {}

    if isinstance(config.get('interfaces'), dict):
        interfaces_config = config['interfaces']
        if isinstance(interfaces_config.get('l2tpv3'), dict):
            return interfaces_config.get('l2tpv3', {})

    if isinstance(config.get('l2tpv3'), dict):
        return config.get('l2tpv3', {})

    if name in config and isinstance(config.get(name), dict):
        return config

    return {name: config}


def fetch_l2tpv3(provider, data):
    try:
        response = provider.http_service.show_all_configs()
        config = response.json().get('data', {}) if response and hasattr(response, 'json') else {}
    except Exception:
        config = {}
    if not isinstance(config, dict):
        return {}
    
    l2tpv3_section = config.get('interfaces', {}).get('l2tpv3', {})
    return {'interfaces': {'l2tpv3': l2tpv3_section}}


def verify_l2tpv3(provider, data):
    print("Verify l2tpv3:")
    print(pprint.pformat(data, indent=2, width=80))
    name = data.get('name')
    config = data.get('config')
    
    iface_cmd = L2TPv3Command(operator='set', resource='interfaces', name=name)
    iface_cmd.generate_commands(data={name: config})
    commands = iface_cmd.get_commands()
    
    processed = process_commands(commands)
    normalized_config = (processed.get('interfaces') or {}).get('l2tpv3', {}).get(name, {})

    normalized_config['ifname'] = name
    identifier_error = validate_unique_l2tpv3_identifiers({
        **get_l2tpv3_db_configs(exclude_name=name),
        name: normalized_config,
    })
    if identifier_error:
        return identifier_error

    verify = provider.verify_service.call_verify_interface("l2tpv3", name, normalized_config)
    return verify


def create_l2tpv3_interface(provider, data):
    print("Create l2tpv3:")
    print(data)
    username = session['username']
    name = data.get('name')
    config = data.get('config')
    set_cmds = []
    iface_set_cmd = L2TPv3Command(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands(data={name: config})
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    
    # Validate configs
    service = "l2tpv3"
    merged_config = merge_dicts_set({}, new_set_configs.get('interfaces', {}))    

    verify = None
    if merged_config and merged_config.get('l2tpv3', {}).get(name, None):
        merged_config['l2tpv3'][name]['ifname'] = name
        identifier_error = validate_unique_l2tpv3_identifiers({
            **get_l2tpv3_db_configs(exclude_name=name),
            name: merged_config['l2tpv3'][name],
        })
        if identifier_error:
            return [{"success": False, "error": identifier_error, "cmd": set_cmds}]
        verify = provider.verify_service.call_verify(
            service, 
            merged_config.get('l2tpv3', {}).get(name, None)
        )
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": set_cmds}]

    InterfaceConfig.upsert({
        'l2tpv3': {
            name: config
        }
    })

    L2TPv3InterfaceConfig.upsert({name: config})

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Create L2TPv3",
                "content": "L2TPv3 is successfully created"
            }
    )
    
    r = []
    cmds = set_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_l2tpv3(provider, data):
    print("Update l2tpv3 (bulk):")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    new_config = data.get('new') or {}
    current_config = data.get('current') or {}
    diff = data.get('diff') or {}

    if not isinstance(new_config, dict):
        new_config = {}
    if not isinstance(current_config, dict):
        current_config = {}
    if not isinstance(diff, dict):
        diff = {}

    new_l2tpv3 = (new_config.get('interfaces') or {}).get('l2tpv3') or {}
    current_l2tpv3 = (current_config.get('interfaces') or {}).get('l2tpv3') or {}
    diff_created = ((diff.get('created') or {}).get('interfaces') or {}).get('l2tpv3') or {}
    diff_deleted = ((diff.get('deleted') or {}).get('interfaces') or {}).get('l2tpv3') or {}

    if not isinstance(new_l2tpv3, dict):
        new_l2tpv3 = {}
    if not isinstance(current_l2tpv3, dict):
        current_l2tpv3 = {}
    if not isinstance(diff_created, dict):
        diff_created = {}
    if not isinstance(diff_deleted, dict):
        diff_deleted = {}

    identifier_error = validate_unique_l2tpv3_identifiers(new_l2tpv3)
    if identifier_error:
        return [{"success": False, "error": identifier_error, "cmd": []}]

    all_set_cmds: list = []
    all_delete_cmds: list = []
    sc: list = []
    dc: list = []
    new_set_configs: dict = {}
    new_delete_configs: dict = {}

    for name, iface_config in new_l2tpv3.items():
        if name in diff_created:
            iface_to_apply = diff_created.get(name) or {}
        elif name not in current_l2tpv3:
            iface_to_apply = iface_config
        else:
            continue
        iface_current = current_l2tpv3.get(name, {}) or {}
        iface_set_cmd = L2TPv3Command(operator='set', resource='interfaces', name=name)
        _set_cmds = iface_set_cmd.generate_commands(
            data={name: iface_to_apply},
            current_config=iface_current,
            new_config=iface_config,
        )
        all_set_cmds.extend(_set_cmds)
        sc.extend(iface_set_cmd.get_commands())

    if sc:
        processed = process_commands(sc)
        new_set_configs = merge_dicts_set(new_set_configs, processed)

    for name, iface_deleted in diff_deleted.items():
        iface_current = current_l2tpv3.get(name, {}) or {}
        iface_delete_cmd = L2TPv3Command(operator='delete', resource='interfaces', name=name)
        _del_cmds = iface_delete_cmd.generate_commands(
            data={name: iface_deleted},
            current_config=iface_current,
            new_config=new_l2tpv3,
        )
        all_delete_cmds.extend(_del_cmds)
        dc.extend(iface_delete_cmd.get_commands())

    if dc:
        processed = process_commands(dc)
        new_delete_configs = merge_dicts_delete(new_delete_configs, processed, aggressive=True)
                
    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "l2tpv3"
    curr_configs = {
        "interfaces": {
            "l2tpv3": {}
        }
    }
    for l2tpv3_name in current_l2tpv3:
        curr_config = provider.verify_service.query_interface_config(service, l2tpv3_name)
        curr_configs["interfaces"]["l2tpv3"][l2tpv3_name] = curr_config

    print("Current interfaces configs: ")
    print(pprint.pformat(curr_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(curr_configs, new_delete_configs, aggressive=True)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    print("Merged config:")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = {}
    l2tpv3_configs = (merged_config.get('interfaces') or {}).get('l2tpv3') or {}
    for iface_name, iface_config in l2tpv3_configs.items():
        if not iface_config or not isinstance(iface_config, dict):
            continue
        # Add ifname to each interface config for verification
        iface_config['ifname'] = iface_name
        verify_result = provider.verify_service.query_interface_verify(
            service, 
            iface_name,
            iface_config
        )
        if verify_result and str(verify_result) != "None" and str(verify_result) != "":
            verify[iface_name] = verify_result

    print("Verify:")
    print(pprint.pformat(verify, indent=2, width=80))

    excecuted_cmds = list(set(all_delete_cmds)) + list(set(all_set_cmds))

    if any(str(v) != "None" and str(v) != "" and v != {} for v in verify.values()):
        return [{"success": False, "error": verify, "cmd": excecuted_cmds}]

    new_interfaces_section = (new_config.get('interfaces') or {})
    normalized = normalize_l2tpv3_refresh_config(None, new_interfaces_section)
    InterfaceConfig.upsert({'l2tpv3': normalized})
    L2TPv3InterfaceConfig.refresh(normalized)

    # Delete removed interfaces from InterfaceConfig
    if diff_deleted:
        deleted_names = list(diff_deleted.keys())
        InterfaceConfig.query.filter(
            InterfaceConfig.interface.in_(deleted_names),
            InterfaceConfig.interface_type.in_(['l2tpv3', 'L2TPv3'])
        ).delete(synchronize_session=False)
        db.session.commit()

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update L2TPv3",
            "content": "L2TPv3 is successfully updated",
        },
    )

    r: list = []
    print("Commands:")
    print(pprint.pformat(excecuted_cmds, indent=2, width=80))

    if len(excecuted_cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=excecuted_cmds, verify=False).json()
        r.append({"cmd": excecuted_cmds, "success": res.get('success'), "error": res.get('error')})

    return r


def update_l2tpv3_by_name(provider, data):
    print("Update l2tpv3 by name")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    name = data.get('name')
    
    set_cmds = []
    iface_set_cmd = L2TPv3Command(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: new_config}, current_config, {name: new_config})
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = L2TPv3Command(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, {name: new_config})
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "l2tpv3"
    curr_config = provider.verify_service.query_interface_config(service, name)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}).get('l2tpv3', {}).get(name, {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}).get('l2tpv3', {}).get(name, {}))    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    verify = None
    if merged_config:
        identifier_error = validate_unique_l2tpv3_identifiers({
            **get_l2tpv3_db_configs(exclude_name=name),
            name: merged_config,
        })
        if identifier_error:
            return [{
                "success": False,
                "error": identifier_error,
                "cmd": list(set(delete_cmds)) + list(set(set_cmds))
            }]
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    if str(verify) != "None" and str(verify) != "":
        return [{
            "success": False, 
            "error": str(verify), 
            "cmd": list(set(delete_cmds)) + list(set(set_cmds))
        }]

    normalized_config = normalize_l2tpv3_refresh_config(name, new_config)

    InterfaceConfig.upsert({
        'l2tpv3': normalized_config
    })

    L2TPv3InterfaceConfig.upsert(normalized_config)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update L2TPv3",
                "content": "L2TPv3 is successfully updated"
            }
    )
    
    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    r = []
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r
