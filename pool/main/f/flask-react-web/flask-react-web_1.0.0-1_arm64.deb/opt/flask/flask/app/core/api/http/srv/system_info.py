from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_SYSTEMS_TIMEZONE,SHOW_SYSTEMS_BOOT_IMG, \
    SHOW_SYSTEM, SHOW_SYSTEMS_VERSION, SHOW_SYSTEM_DOMAIN, SHOW_SYSTEMS_DATE, \
        SHOW_SYSTEMS_UPTIME, SHOW_SYSTEMS_NAME, SHOW_ALL_CONFIGS
from app.core.operation.system_information import parse_system_info_gql, parse_timedatectl, parse_boot_img, parse_date, parse_hostname, parse_wireless_country_code, parse_domainname, parse_datetime, parse_system_version, parse_timezone
from app.core.operation.system_performance import load_system_cpu_json
from logging import getLogger, INFO, DEBUG
from app.core.api.http.cmd.command_system import SystemCommand
from app.core.api.http.cmd.command_password_policy import PasswordPolicyCommand
from app.core.operation.password_policy import apply_password_policy, parse_password_policy
import pprint
import os 
from app.core.utils.cmd_linux import run_linux_cmd
from app.config.models import SubPageFeature
from app.core.utils.datetime.convert import convert_datetime
from app.core.utils.check_os import is_linux
from datetime import datetime
import pytz
import traceback
from app.core.api.http.cmd.compare import compare_configs
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set

tz = "America/Toronto"

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_system_info(provider, params):
    """Fetch all system information."""
    system_date = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_DATE, verify=False)
    # system_boot_img = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_BOOT_IMG, verify=False)
    system_version = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_VERSION, verify=False)
    system_name = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_NAME, verify=False)
    system_domain = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEM_DOMAIN, verify=False)
    system_uptime = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_UPTIME, verify=False)
    system = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEM, verify=False)

    # boot_img = parse_boot_img(system_boot_img.json()['data'])
    boot_img = parse_system_version(system_version.json()['data'])

    wireless_country_code = parse_wireless_country_code(system.json()['data'])

    r = {
        "datetime": parse_date(system_date.json()['data']),
        "boot_img_name": boot_img,
        "boot_img_running": True,
        "boot_img_default": True,
        "name": parse_hostname(system_name.json()['data']),
        "domain_name": parse_domainname(system_domain.json()['data']),
        "uptime": load_system_cpu_json(system_uptime.json()['data']).get('uptime'),
        "wireless_country_code": wireless_country_code
    }
    return r


def fetch_system_info_gql(provider, params):
    system_info = provider.graphql_service.send_request(function_name='SystemStatus', data=None, verify=False)
    system = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEM, verify=False)
    datetimectl = {}
    if is_linux():
        timedatectl_out, timedatectl_err = run_linux_cmd('timedatectl')
        if timedatectl_err:
            logger.debug(f"timedatectl error: {timedatectl_err}")
        logger.debug(f"timedatectl output: {timedatectl_out}")
        datetimectl = parse_timedatectl(timedatectl_out)
        logger.debug(f"timedatectl parsed: {datetimectl}")
        if 'local_time' not in datetimectl or not datetimectl.get('local_time'):
            now = datetime.now(pytz.timezone(tz))
            datetimectl['local_time'] = now.strftime("%a %Y-%m-%d %H:%M:%S %Z")
    else:
        now = datetime.now(pytz.timezone(tz))
        datetimectl = {
            "local_time": now.strftime("%a %Y-%m-%d %H:%M:%S %Z"),
            "timezone": tz
        }

    wireless_country_code = ""
    try:
        if system is not None and system.json() is not None:
            sys_data = system.json().get('data', {})
            sys_obj = sys_data.get('system') if isinstance(sys_data.get('system'), dict) else sys_data
            wireless_country_code = parse_wireless_country_code(sys_obj)
    except Exception:
        wireless_country_code = ""

    return {
        "system": parse_system_info_gql(system_info.json()['data']),
        "datetime": datetimectl,
        "wireless_country_code": wireless_country_code
    }


def fetch_datetime(provider, params=None):
    """Fetch system datetime information."""
    try:
        logger.debug("Fetching datetime...")
        datetime_response = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_DATE, verify=False)
        timezone_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEMS_TIMEZONE, verify=False)
        
        if not datetime_response or not datetime_response.json() or 'data' not in datetime_response.json():
            logger.error("Invalid datetime response")
            return {"error": "Invalid datetime response"}
            
        data = datetime_response.json()['data']
        logger.debug(f"Raw datetime data: {data}")
        
        parsed = parse_datetime(data)
        logger.debug(f"Parsed datetime: {parsed}")
        
        return {
            "datetime": parsed,
            "timezone": parse_timezone(timezone_response.json()['data'])
        }
    except Exception as e:
        logger.error(f"Error fetching datetime: {str(e)}")
        return {"error": str(e)}

def update_system(provider, data):
    try:
        print("[update_system] ENTER", flush=True)
        print("[update_system] Raw input data type:", flush=True)
        print(type(data), flush=True)
        print("[update_system] Raw input data:", flush=True)
        print(pprint.pformat(data, indent=2, width=80), flush=True)

        from app.core.security.service.firewall import FirewallCommand
        from app.core.models import System
        
        system_name = data.get('systemName', None)
        domain_name = data.get('domainName', None)
        date_time = data.get('dateTime', None)
        system_timezone = data.get('timezone', None)
        ipv6_enabled = data.get('ipv6', None)
        password_policy = data.get('password_policy')

        print("[update_system] Parsed fields:", flush=True)
        print(pprint.pformat({
            "system_name": system_name,
            "domain_name": domain_name,
            "date_time": date_time,
            "system_timezone": system_timezone,
            "ipv6_enabled": ipv6_enabled,
        }, indent=2, width=80), flush=True)

        current_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ALL_CONFIGS, verify=False)
        print("[update_system] current_resp is None:", flush=True)
        print(current_resp is None, flush=True)

        current_system_config = {}
        try:
            if current_resp is not None and current_resp.json() is not None:
                current_system_config = current_resp.json().get('data', {}).get('system', {}) or {}
        except Exception:
            current_system_config = {}

        policy_cmds = []
        updated_login_config = None
        if password_policy is not None:
            current_payload = current_resp.json() if current_resp is not None else None
            if (
                not isinstance(current_payload, dict)
                or current_payload.get('success') is not True
                or not isinstance(current_payload.get('data', {}).get('system'), dict)
            ):
                raise ValueError('Unable to read the current password policy.')
            current_login = current_system_config.get('login', {})
            current_policy = parse_password_policy(current_login)
            remove_enhanced_policy = not password_policy['enabled'] and (
                'enhanced-policy' in current_login or 'enhanced_policy' in current_login
            )
            if (password_policy['enabled'] and current_policy != password_policy) or remove_enhanced_policy:
                updated_login_config = apply_password_policy(current_login, password_policy)
                if password_policy['enabled']:
                    policy_command = PasswordPolicyCommand(operator='set')
                    policy_cmds = policy_command.generate_commands({'login': updated_login_config})
                else:
                    policy_command = PasswordPolicyCommand(operator='delete')
                    policy_command.generate('system', 'login', 'enhanced-policy')
                    policy_cmds = policy_command.cmds

        desired_system_config = {}
        current_managed_system_config = {}
        submitted_system_fields = {
            'host-name': system_name,
            'domain-name': domain_name,
            'time-zone': system_timezone,
        }
        for config_key, submitted_value in submitted_system_fields.items():
            if submitted_value is None:
                continue
            if config_key in current_system_config:
                current_managed_system_config[config_key] = current_system_config[config_key]
            if str(submitted_value).strip() != "":
                desired_system_config[config_key] = submitted_value

        system_diff = compare_configs(
            desired_system_config,
            current_managed_system_config,
        )

        system_created = system_diff.get('created', {}) or {}
        system_deleted = system_diff.get('deleted', {}) or {}

        # Generate commands:

        system_set_cmds = []
        system_set_cmd_obj = SystemCommand(
            operator='set',
            resource='system',
            host_name=system_created.get('host-name'),
            domain_name=system_created.get('domain-name'),
            timezone=system_created.get('time-zone')
        )
        system_set_cmds = system_set_cmd_obj.generate_commands(diff=system_created, current_config=None, new_config=None)
        system_set_vyos_cmds = system_set_cmd_obj.get_commands()
        system_set_config = process_commands(system_set_vyos_cmds) if system_set_vyos_cmds else {}

        system_delete_cmds = []
        system_delete_cmd_obj = SystemCommand(
            operator='delete',
            resource='system',
            host_name='1' if ('host-name' in system_deleted and 'host-name' not in system_created) else None,
            domain_name='1' if ('domain-name' in system_deleted and 'domain-name' not in system_created) else None,
            timezone='1' if ('time-zone' in system_deleted and 'time-zone' not in system_created) else None
        )

        system_delete_cmds = system_delete_cmd_obj.generate_commands(diff=system_deleted, current_config=current_system_config, new_config=None)
        system_delete_vyos_cmds = system_delete_cmd_obj.get_commands()
        system_delete_config = {}

        if system_deleted:
            system_delete_config = {"system": {}}
            if 'domain-name' in system_deleted and 'domain-name' not in system_created:
                if 'domain-name' in current_system_config:
                    system_delete_config["system"]["domain-name"] = current_system_config.get('domain-name')
            if 'host-name' in system_deleted and 'host-name' not in system_created:
                if 'host-name' in current_system_config:
                    system_delete_config["system"]["host-name"] = current_system_config.get('host-name')
            if 'time-zone' in system_deleted and 'time-zone' not in system_created:
                if 'time-zone' in current_system_config:
                    system_delete_config["system"]["time-zone"] = current_system_config.get('time-zone')

        system_merged_del_config = merge_dicts_delete(
            current_system_config,
            system_delete_config.get('system', {}),
            clean_empty=False
        )

        system_merged_config = merge_dicts_set(
            system_merged_del_config,
            system_set_config.get('system', {})
        )
        if updated_login_config is not None:
            system_merged_config['login'] = updated_login_config

        firewall_set_cmds = []
        firewall_delete_cmds = []
        firewall_cmds = []

        print("IPv6 input: ", flush=True)
        print(pprint.pformat(ipv6_enabled, indent=2, width=80), flush=True)

        # IPv6 global block toggle (firewall ipv6 block)
        # Diff current firewall.ipv6.block vs desired state, then generate set/delete commands.
        if ipv6_enabled is not None:
            current_firewall_config = current_resp.json().get('data', {}).get('firewall', {}) if (current_resp and current_resp.json()) else {}
            current_ipv6_firewall_config = current_firewall_config.get('ipv6', {}) if isinstance(current_firewall_config, dict) else {}
            current_ipv6_block_config = {}
            if isinstance(current_ipv6_firewall_config, dict) and 'block' in current_ipv6_firewall_config:
                current_ipv6_block_config = {'block': {}}

            desired_ipv6_block_config = {'block': {}} if ipv6_enabled is False else {}

            firewall_ipv6_diff = compare_configs(desired_ipv6_block_config, current_ipv6_block_config)
            firewall_ipv6_created = firewall_ipv6_diff.get('created', {}) or {}
            firewall_ipv6_deleted = firewall_ipv6_diff.get('deleted', {}) or {}

            print("Firewall ipv6 diff: ", flush=True)
            print(pprint.pformat(firewall_ipv6_diff, indent=2, width=80), flush=True)

            if firewall_ipv6_created:
                fw_set = FirewallCommand(operator='set')
                firewall_set_cmds = fw_set.generate_commands(data={'ipv6': firewall_ipv6_created})

            if firewall_ipv6_deleted:
                fw_del = FirewallCommand(operator='delete')
                firewall_delete_cmds = fw_del.generate_commands(data={'ipv6': firewall_ipv6_deleted})

            firewall_cmds = list(set(firewall_delete_cmds)) + list(set(firewall_set_cmds))

            print("Firewall ipv6 commands: ", flush=True)
            print(pprint.pformat(firewall_cmds, indent=2, width=80), flush=True)

            if ipv6_enabled is False:
                SubPageFeature.set_v6_features_status(status=False)
                System.set_ipv6_status(data={'ipv6': {'block': {}}})
            elif ipv6_enabled is True:
                SubPageFeature.set_v6_features_status(status=True)
                System.set_ipv6_status(data={'ipv6': {}})
        

        if is_linux() and date_time:
            # Linux command to change date and time
            converted_datetime = convert_datetime(date_time)
            datetime_cmd = f"date -s '{converted_datetime}'"
            datetime_output, datetime_error = run_linux_cmd(datetime_cmd)
            logger.debug(f"Datetime command: {datetime_cmd}")
            logger.debug(f"Datetime output: {datetime_output}")
            logger.debug(f"Datetime error: {datetime_error}")
        
        cmds = list(set(system_delete_cmds)) + list(set(system_set_cmds)) + list(set(firewall_cmds)) + policy_cmds
        r = []
        if len(cmds) > 0:
            res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
            if res.get('success') is True and updated_login_config is not None:
                # Import after API initialization; the login package loads routes.
                from app.core.login.db_models import SystemLoginOptions
                SystemLoginOptions.refresh(updated_login_config)
            r.append({
                "cmd": cmds,
                "success": res.get('success'),
                "error": res.get('error'),
                "merged": system_merged_config
            })

        return r

    except Exception as e:
        print("[update_system] EXCEPTION", flush=True)
        print(str(e), flush=True)
        print("[update_system] TRACEBACK", flush=True)
        print(traceback.format_exc(), flush=True)
        return [{"cmd": [], "success": False, "error": str(e)}]
