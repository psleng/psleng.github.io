from typing import Any, Dict

from app.core.api.http.cmd.command import Command


def _is_str_not_empty(value: Any) -> bool:
    return value is not None and str(value).strip() not in ('', 'None', 'null')


class ARPCommand(Command):
    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data or not isinstance(data, dict):
            return []

        base = ['protocols', 'static', 'arp']

        interfaces = data.get('interface')
        if not isinstance(interfaces, dict):
            return []

        for ifname, ifcfg in interfaces.items():
            if not _is_str_not_empty(ifname) or not isinstance(ifcfg, dict):
                continue
            
            if self.operator == 'delete' and str(ifname).strip() not in new_config.get('interface', {}):
                self.generate(*base, 'interface', str(ifname))
                continue

            addresses = ifcfg.get('address')
            if not isinstance(addresses, dict):
                continue

            for ip, ipcfg in addresses.items():
                if not _is_str_not_empty(ip):
                    continue

                mac = None
                if isinstance(ipcfg, dict):
                    mac = ipcfg.get('mac')
                if _is_str_not_empty(mac):
                    self.generate(*base, 'interface', str(ifname), 'address', str(ip), 'mac', str(mac))

        return self.cmds
