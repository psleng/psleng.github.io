from copy import deepcopy
from typing import Dict, Any, List


def has_l2tpv3_value(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ''
    return True


def normalize_l2tpv3_address(address):
    if isinstance(address, dict):
        if 'ip' in address:
            ip = str(address.get('ip', '')).strip()
            return {ip: {}} if ip else {}
        return address

    if isinstance(address, list):
        normalized = {}
        for addr in address:
            if isinstance(addr, dict) and 'ip' in addr:
                ip = str(addr.get('ip', '')).strip()
            else:
                ip = str(addr).strip()
            if ip:
                normalized[ip] = {}
        return normalized

    if isinstance(address, str):
        ip = address.strip()
        return {ip: {}} if ip else {}

    return {}


def normalize_current_l2tpv3_config(config: dict) -> dict:
    normalized_config = deepcopy(config) if isinstance(config, dict) else {}
    l2tpv3_config = (normalized_config.get('interfaces') or {}).get('l2tpv3') or {}

    if not isinstance(l2tpv3_config, dict):
        return normalized_config

    for iface_config in l2tpv3_config.values():
        if isinstance(iface_config, dict) and 'address' in iface_config:
            iface_config['address'] = normalize_l2tpv3_address(iface_config.get('address'))

    return normalized_config

def parse_to_l2tpv3_config(data: dict, current_config: dict = None) -> dict:
    config = {}
    general = data.get('general', {})
    
    if 'enabled' in general and general['enabled'] is False:
        config['disable'] = {}
    if 'description' in general and general['description']:
        config['description'] = general['description']
    if 'address' in general:
        config['address'] = normalize_l2tpv3_address(general['address'])
    if 'peer_session_id' in general:
        config['peer-session-id'] = str(general['peer_session_id'])
    if 'peer_tunnel_id' in general:
        config['peer-tunnel-id'] = str(general['peer_tunnel_id'])
    if 'remote' in general:
        config['remote'] = general['remote']
    if 'session_id' in general:
        config['session-id'] = str(general['session_id'])
    if 'source_address' in general:
        config['source-address'] = general['source_address']
    if 'tunnel_id' in general:
        config['tunnel-id'] = str(general['tunnel_id'])
    
    advanced = general.get('advanced', {})
    if advanced:
        encapsulation = advanced.get('encapsulation')
        if has_l2tpv3_value(advanced.get('source_port')):
            config['source-port'] = str(advanced['source_port'])

        if has_l2tpv3_value(advanced.get('destination_port')):
            config['destination-port'] = str(advanced['destination_port'])

        if encapsulation:
            config['encapsulation'] = encapsulation

        if has_l2tpv3_value(advanced.get('mtu')):
            config['mtu'] = str(advanced['mtu'])

        if 'ip' in advanced:
            config['ip'] = {}
            if advanced['ip'].get('adjust_mss'):
                config['ip']['adjust-mss'] = advanced['ip']['adjust_mss']
            if advanced['ip'].get('arp_cache_timeout'):
                config['ip']['arp-cache-timeout'] = str(advanced['ip']['arp_cache_timeout'])
            if advanced['ip'].get('disable_arp_filter'):
                config['ip']['disable-arp-filter'] = {}
            if advanced['ip'].get('disable_forwarding'):
                config['ip']['disable-forwarding'] = {}
            if advanced['ip'].get('enable_arp_accept'):
                config['ip']['enable-arp-accept'] = {}
            if advanced['ip'].get('enable_arp_announce'):
                config['ip']['enable-arp-announce'] = {}
            if advanced['ip'].get('enable_arp_ignore'):
                config['ip']['enable-arp-ignore'] = {}
            if advanced['ip'].get('enable_directed_broadcast'):
                config['ip']['enable-directed-broadcast'] = {}
            if advanced['ip'].get('enable_proxy_arp'):
                config['ip']['enable-proxy-arp'] = {}
            if advanced['ip'].get('proxy_arp_pvlan'):
                config['ip']['proxy-arp-pvlan'] = {}
            if advanced['ip'].get('source_validation'):
                config['ip']['source-validation'] = advanced['ip']['source_validation']
        if 'ipv6' in advanced:
            config['ipv6'] = {}
            if advanced['ipv6'].get('accept_dad') is not None:
                config['ipv6']['accept-dad'] = str(advanced['ipv6']['accept_dad'])
            if advanced['ipv6'].get('address_autoconf'):
                config['ipv6']['address'] = {'autoconf': {}}
            if advanced['ipv6'].get('address_eui64'):
                if 'address' not in config['ipv6']:
                    config['ipv6']['address'] = {}
                config['ipv6']['address']['eui64'] = advanced['ipv6']['address_eui64']
            if advanced['ipv6'].get('address_interface_identifier'):
                if 'address' not in config['ipv6']:
                    config['ipv6']['address'] = {}
                config['ipv6']['address']['interface-identifier'] = advanced['ipv6']['address_interface_identifier']
            if advanced['ipv6'].get('address_no_default_link_local'):
                if 'address' not in config['ipv6']:
                    config['ipv6']['address'] = {}
                config['ipv6']['address']['no-default-link-local'] = {}
            if advanced['ipv6'].get('adjust_mss'):
                config['ipv6']['adjust-mss'] = advanced['ipv6']['adjust_mss']
            if advanced['ipv6'].get('base_reachable_time'):
                config['ipv6']['base-reachable-time'] = str(advanced['ipv6']['base_reachable_time'])
            if advanced['ipv6'].get('disable_forwarding'):
                config['ipv6']['disable-forwarding'] = {}
            if advanced['ipv6'].get('dup_addr_detect_transmits') is not None:
                config['ipv6']['dup-addr-detect-transmits'] = str(advanced['ipv6']['dup_addr_detect_transmits'])
            if advanced['ipv6'].get('source_validation'):
                config['ipv6']['source-validation'] = advanced['ipv6']['source_validation']
    
    return config

def parse_current_l2tpv3_interface_config(interface_config: dict, name: str) -> dict:
    if not interface_config.get('interfaces', {}).get('l2tpv3', {}):
        return {}
    
    for interface, interface_conf in interface_config.get('interfaces', {}).get('l2tpv3', {}).items():
        if interface == name:
            current_config = deepcopy(interface_conf) if isinstance(interface_conf, dict) else {}
            if 'address' in current_config:
                current_config['address'] = normalize_l2tpv3_address(current_config.get('address'))
            return current_config
    return {}

def parse_to_l2tpv3_bulk_config(interfaces_data) -> dict:
    bulk_config: dict = {'interfaces': {'l2tpv3': {}}}
    for iface in interfaces_data:
        iface_dict = iface.model_dump() if hasattr(iface, 'model_dump') else iface
        name = iface_dict.get('general', {}).get('name')
        if name:
            parsed = parse_to_l2tpv3_config(iface_dict)
            bulk_config['interfaces']['l2tpv3'][name] = parsed
    return bulk_config
