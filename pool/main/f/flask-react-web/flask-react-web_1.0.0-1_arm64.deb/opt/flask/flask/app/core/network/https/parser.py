
from typing import Any, Dict, List


def _as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]

def parse_to_https_config(data: Dict[str, Any]) -> Dict[str, Any]:
    if not data or not isinstance(data, dict):
        return {}

    result: Dict[str, Any] = {}

    allow_clients = data.get('allow_clients') or []
    allow_addrs = []
    for item in allow_clients:
        addr = (item or {}).get('address') if isinstance(item, dict) else None
        if addr is None:
            continue
        s = str(addr).strip()
        if s:
            allow_addrs.append(s)
    if allow_addrs:
        result['allow-client'] = {'address': allow_addrs}

    if data.get('enable_http_redirect'):
        result['enable-http-redirect'] = {}

    listen_addresses = [str(a).strip() for a in (data.get('listen_addresses') or []) if a is not None and str(a).strip()]
    if listen_addresses:
        result['listen-address'] = listen_addresses

    if data.get('port') is not None:
        result['port'] = str(data.get('port'))

    if data.get('request_body_size_limit') is not None:
        result['request-body-size-limit'] = str(data.get('request_body_size_limit'))

    tls_versions = [str(v).strip() for v in (data.get('tls_versions') or []) if v is not None and str(v).strip()]
    if tls_versions:
        result['tls-version'] = tls_versions

    api_in = data.get('api') or {}
    api_out: Dict[str, Any] = {}
    if isinstance(api_in, dict):
        if api_in.get('rest'):
            api_out['rest'] = {}
            if api_in.get('rest_debug'):
                api_out['rest']['debug'] = {}
            if api_in.get('rest_strict'):
                api_out['rest']['strict'] = {}

        graphql_in = api_in.get('graphql') or {}
        auth_in = (graphql_in.get('authentication') or {}) if isinstance(graphql_in, dict) else {}
        graphql_out: Dict[str, Any] = {}
        auth_out: Dict[str, Any] = {}
        if isinstance(auth_in, dict):
            expiration = auth_in.get('expiration')
            if expiration is not None and str(expiration).strip() != '':
                auth_out['expiration'] = str(expiration).strip()
            secret_length = auth_in.get('secret_length')
            if secret_length is not None and str(secret_length).strip() != '':
                auth_out['secret-length'] = str(secret_length).strip()
            if auth_in.get('type'):
                auth_out['type'] = str(auth_in.get('type'))
        if auth_out:
            graphql_out['authentication'] = auth_out
        if graphql_out:
            api_out['graphql'] = graphql_out

        keys_in = api_in.get('keys') or []
        ids: Dict[str, Any] = {}
        for k in keys_in:
            if not isinstance(k, dict):
                continue
            key_id = k.get('id')
            if not key_id:
                continue
            key_cfg: Dict[str, Any] = {}
            if k.get('key') not in (None, ''):
                key_cfg['key'] = str(k.get('key'))
            ids[str(key_id)] = key_cfg
        if ids:
            api_out['keys'] = {'id': ids}

    if api_out:
        result['api'] = api_out

    certs_out: Dict[str, Any] = {}
    if data.get('ca_certificate'):
        certs_out['ca-certificate'] = str(data.get('ca_certificate'))
    if data.get('certificate'):
        certs_out['certificate'] = str(data.get('certificate'))
    if data.get('dh_params'):
        certs_out['dh-params'] = str(data.get('dh_params'))
    result['certificates'] = certs_out

    return result
