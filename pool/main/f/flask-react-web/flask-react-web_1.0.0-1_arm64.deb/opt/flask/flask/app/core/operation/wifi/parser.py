from copy import deepcopy
import pprint
from app.core.utils.debug.debug_log import debug_log
from app.core.operation.wifi.fixed_configs import fixed_wifi_configs
from app.core.utils.process_config import normalize_config, merge_dicts_set, merge_dicts_delete


EDITABLE_FIELDS = (
    'disable', 'description', 'ssid', 'disable-broadcast-ssid',
    'isolate-stations', 'mgmt-frame-protection', 'enable-bf-protection',
    'address', 'dhcp-options',
)
SECURITY_PATHS = (
    ('wpa', 'mode'), ('wpa', 'passphrase'), ('wpa', 'cipher'),
    ('station-address', 'mode'), ('station-address', 'accept', 'mac'),
    ('station-address', 'deny', 'mac'),
)


# @debug_log
def parse_to_wifi_config(data: dict, current_config: dict = None):
    """
    'network': {'ipConfig': 'dhcp',
                'ipv4': {'address': '',
                        'dhcpOptions': {'clientId': '',
                                        'defaultRouteDistance': 1,
                                        'hostName': '',
                                        'noDefaultRoute': False,
                                        'userClass': '',
                                        'vendorClassId': ''},
                        'gateway': '',
                        'netmask': ''},
                'ipv6': {'address': '',
                        'dhcpv6Options': {'duid': '',
                                        'noRelease': False,
                                        'parametersOnly': False,
                                        'rapidCommit': False,
                                        'temporaryAddress': False},
                        'prefix': 64}},
                'password': '',
                'security': 'WPA2',
                'ssid': ''},
        'description': '',
        'enabled': True,
        'network': {'bridgeInterface': '',
                        'bridgeMode': False,
                        'ipMode': 'static',
                        'ipv4': {'dhcp': {'enabled': False,
                                        'options': {'clientId': '',
                                                'defaultRouteDistance': 1,
                                                'dontInstallDefaultRoute': False,
                                                'hostname': '',
                                                'mtu': 1500,
                                                'reject': False,
                                                'userClass': '',
                                                'vendorClass': ''}},
                                'static': {'address': '',
                                        'gateway': '',
                                        'netmask': '',
                                        'prefixLength': 24}},
                        'ipv6': {'dhcpv6': {'enabled': False,
                                        'options': {'dontSendRelease': False,
                                                        'duid': '',
                                                        'parametersOnly': False,
                                                        'pd': False,
                                                        'rapidCommit': False,
                                                        'temporaryAddress': False}},
                                'mode': 'static',
                                'static': {'address': '', 'prefix': 64}}},
        'password': '',
        'security': {'encryption': 'AES', 'type': 'WPA2'},
        'advanced': {'countryCode': 'US'},
        'ssid': ''}



        Sample output:
        'wlan0', 'wlan1' (ap)
        'wlan2', 'wlan3' (client)

        {
            "ap": { 
                    'disable': {},
                    'description': 'Here is the description',
                    'disable-broadcast-ssid': {},
                    'isolate-stations': {},
                    'mgmt-frame-protection': 'optional',
                    'mode': 'ac',
                    'security': { 'wpa': { 'cipher': [ 'GCMP',
                                                    'CCMP',
                                                    'GCMP-256',
                                                    'CCMP-256',
                                                    'TKIP'],
                                            'mode': 'wpa2',
                                            'passphrase': '123perle456'}},
                    'ssid': 'duc123',
                    'type': 'access-point'
                    },
            "client": { 'security': { 'wpa': { 'cipher': [ 'GCMP-256',
                                                            'GCMP',
                                                            'CCMP',
                                                            'CCMP-256',
                                                            'TKIP'],
                                            'passphrase': 'password1'}}
        }


    
    """
    # print("parse_to_wifi_config input data")
    # print(pprint.pformat(data))
    
    # Transform the new-style WiFi config into VyOS-style AP/client config dicts


    result = {}

    # --- ACCESS POINT (AP) ---
    ap = {}
    # Mode
    if data.get('mode'):
        ap['mode'] = data['mode']
    # Description
    if data.get('description'):
        ap['description'] = data['description']
    # SSID
    if data.get('ssid'):
        ap['ssid'] = data['ssid']
    # Security
    sec = data.get('security', {})
    if sec.get('type', '').lower().startswith('wpa'):
        wpa_mode = sec.get('type', '').lower()
        _cipher = []
        if isinstance(sec.get('encryption'), str):
            _cipher = sec.get('encryption')
        elif isinstance(sec.get('encryption'), list):
            encryption_list = sec.get('encryption')
            if len(encryption_list) == 1:
                _cipher = encryption_list[0]
            elif len(encryption_list) > 1:
                _cipher = sec.get('encryption', [])
        ap['security'] = {
            'wpa': {
                'mode': wpa_mode,
                'cipher': _cipher,
                'passphrase': data.get('password', '')
            }
        }
    # Access Control
    access_control = data.get('accessControl', {})
    mode = access_control.get('mode', None)
    accept_list = access_control.get('acceptList', [])
    deny_list = access_control.get('denyList', []) 
    if mode == 'deny' or mode == 'accept':
        station_address = {}
        station_address['mode'] = mode

        if len(accept_list) > 0:
            ap['security'] = ap.get('security', {})
            station_address['accept'] = {
                "mac": accept_list if len(accept_list) > 1 else accept_list[0]
            }
        
        if len(deny_list) > 0:
            ap['security'] = ap.get('security', {})
            station_address['deny'] = {
                "mac": deny_list if len(deny_list) > 1 else deny_list[0]
            }
            
        
        ap['security'] = ap.get('security', {})
        ap['security']['station-address'] = deepcopy(station_address)
    
    # Advanced
    adv = data.get('advanced', {})
    if 'hiddenSSID' in adv and adv['hiddenSSID'] is True:
        ap['disable-broadcast-ssid'] = {}
    if adv.get('preventBridging'):
        ap['isolate-stations'] = {}
    if adv.get('managementFrameProtection') and adv['managementFrameProtection'] != 'disabled':
        ap['mgmt-frame-protection'] = adv['managementFrameProtection']
    if 'mode' in adv:
        ap['mode'] = adv['mode']

    if 'capabilities' not in ap:
        ap['capabilities'] = {}
        
    if adv.get('acMode') and adv['acMode'].get('channelWidth'):
        if 'vht' not in ap['capabilities']:
            ap['capabilities']['vht'] = {}
        ap['capabilities']['vht']['channel-set-width'] = adv['acMode']['channelWidth']

    if adv.get('axMode') and adv['axMode'].get('channelWidth'):
        if 'he' not in ap['capabilities']:
            ap['capabilities']['he'] = {}
        ap['capabilities']['he']['channel-set-width'] = adv['axMode']['channelWidth']

    if adv.get('nMode') and adv['nMode'].get('channelWidth'):
        if 'ht' not in ap['capabilities']:
            ap['capabilities']['ht'] = {}
        ap['capabilities']['ht']['channel-set-width'] = adv['nMode']['channelWidth']

    # Max stations is preset
    # if adv.get('maxClients'):
    #     ap['max-stations'] = adv['maxClients']
    
    if adv.get('beaconProtection'):
        ap['beacon-protection'] = {}
    if adv.get('disassociateOnFailures'):
        ap['disassociate-on-failures'] = {}
    if adv.get('dedicatedThreadPerClient'):
        ap['dedicated-thread-per-client'] = {}

    # Country code
    if data.get('countryCode') and data.get('countryCode') != '':
        ap['country-code'] = data.get('countryCode')
    
    # Type is preset
    # ap['type'] = 'access-point'

    # --- NETWORK ---
    net = data.get('network', {})
    if net.get('bridgeMode'):
        ap['bridge'] = {'interface': net.get('bridgeInterface', '')}

    if not net.get('bridgeMode'):
        # IPv4
        ipv4 = net.get('ipv4', {})
        if net.get('ipMode') == 'dhcp':
            ap['address'] = ['dhcp']
        elif net.get('ipMode') == 'static' and 'static' in ipv4:
            static = ipv4['static']
            if static.get('address'):
                prefix = static.get('prefixLength', 24)
                ap['address'] = [f"{static['address']}/{prefix}"]
                if static.get('gateway'):
                    ap['gateway'] = static['gateway']
        # IPv6
        ipv6 = net.get('ipv6', {})
        if ipv6.get('mode') == 'dhcpv6':
            ap.setdefault('address', []).append('dhcpv6')
        elif ipv6.get('mode') == 'static' and 'static' in ipv6:
            static6 = ipv6['static']
            if static6.get('address'):
                prefix = static6.get('prefix', 64)
                ap.setdefault('address', []).append(f"{static6['address']}/{prefix}")

    result['wlan0'] = ap.copy()
    result['wlan1'] = ap.copy()

    # Disable/enable
    if not data.get('enabled5', False):
        result['wlan0']['disable'] = {}
    
    if not data.get('enabled24', False):
        result['wlan1']['disable'] = {}

    # --- CLIENT ---
    client_in = data.get('client', {})
    client = {}

    if client_in.get('ssid'):
        client['ssid'] = client_in['ssid']
    if client_in.get('password'):
        client['security'] = {
            'wpa': {
                'mode': 'wpa2',
                'passphrase': client_in['password']
            }
        }
    if client_in.get('security'):
        client['security'] = {
            'wpa': {
                'mode': client_in['security'],
                'passphrase': client_in.get('password', '')
            }
        }
    # Network config for client
    cnet = client_in.get('network', {})
    if cnet.get('ipConfig') == 'dhcp':
        client['address'] = ['dhcp']
    elif cnet.get('ipConfig') == 'static':
        ipv4 = cnet.get('ipv4', {})
        if ipv4.get('address'):
            prefix = 24
            client['address'] = [f"{ipv4['address']}/{prefix}"]
            if ipv4.get('gateway'):
                client['gateway'] = ipv4['gateway']
    # IPv6 for client
    ipv6 = cnet.get('ipv6', {})
    ipv6_mode = ipv6.get('mode') or 'static'
    if ipv6_mode == 'dhcpv6':
        client.setdefault('address', []).append('dhcpv6')
    elif ipv6_mode == 'autoconf':
        client['ipv6'] = {'address': {'autoconf': {}}}
    elif ipv6_mode == 'static' and ipv6.get('address'):
        prefix = ipv6.get('prefix', 64)
        client.setdefault('address', []).append(f"{ipv6['address']}/{prefix}")
    
    result['wlan2'] = client.copy()
    result['wlan3'] = client.copy()

    if not client_in.get('enabled5', False):
        result['wlan2']['disable'] = {}
    if not client_in.get('enabled24', False):
        result['wlan3']['disable'] = {}
    
    if cnet.get('ipv4', None) and cnet['ipv4'].get('dhcpOptions', None) and cnet['ipv4']['dhcpOptions'].get('defaultRoute', None):
        defaultRoutes = cnet['ipv4']['dhcpOptions']['defaultRoute']
        if 'GHz5' in defaultRoutes:
            result['wlan2']['dhcp-options'] = {
                'default-route-distance': defaultRoutes['GHz5']
            }
        if 'GHz24' in defaultRoutes:
            result['wlan3']['dhcp-options'] = {
                'default-route-distance': defaultRoutes['GHz24']
            }
    
    if current_config is None:
        return result

    # Prepare the complete desired config using the shared merge utilities.
    current = normalize_config(current_config or {}, hyphenated=True, stringify_numbers=True)
    requested = normalize_config(result, hyphenated=True, stringify_numbers=True)
    fixed = fixed_wifi_configs['fixed_configs']['interfaces']['wireless']
    desired = deepcopy(current)

    for name, defaults in fixed.items():
        # Existing adjustable radio settings take precedence over defaults.
        interface = merge_dicts_set(
            defaults, current.get(name) or {}, replace_lists=True,
            base_path=['interfaces', 'wireless', name],
        )
        interface = normalize_config(interface, hyphenated=True)
        # These settings are fixed by the device, rather than by the GUI.
        for key in ('type', 'channel', 'max-stations', 'stationary-ap', 'physical-device'):
            if key in defaults:
                interface[key] = deepcopy(defaults[key])
        if name != 'wlan0':
            interface['mode'] = defaults['mode']

        if name in requested:
            edits = requested[name]
            for key in EDITABLE_FIELDS:
                if key in edits:
                    interface[key] = deepcopy(edits[key])
                else:
                    interface.pop(key, None)

            if name in ('wlan2', 'wlan3'):
                mode_deletes = {'ipv6': {'address': {'autoconf': {}}}}
                interface = normalize_config(merge_dicts_delete(
                    interface, mode_deletes, clean_empty=False, remove_values=True,
                ), hyphenated=True)
                if ipv6_mode == 'autoconf':
                    interface.setdefault('ipv6', {}).setdefault('address', {})['autoconf'] = {}

            security_deletes = {}
            for path in SECURITY_PATHS:
                node = security_deletes
                for key in path[:-1]:
                    node = node.setdefault(key, {})
                node[path[-1]] = {}
            security = merge_dicts_delete(
                interface.get('security', {}), security_deletes,
                clean_empty=False, remove_values=True,
            )
            interface['security'] = security
            requested_security = edits.get('security', {})
            # Preserve security settings the form cannot edit.
            for path in SECURITY_PATHS:
                value = requested_security
                for key in path:
                    if not isinstance(value, dict) or key not in value:
                        break
                    value = value[key]
                else:
                    if value in (None, '', []):
                        continue
                    node = security
                    for key in path[:-1]:
                        node = node.setdefault(key, {})
                    node[path[-1]] = deepcopy(value)
            if not security:
                interface.pop('security', None)

            if name == 'wlan0' and edits.get('mode') in ('ac', 'ax'):
                interface['mode'] = edits['mode']
            for capability in ('ht', 'vht'):
                width = edits.get('capabilities', {}).get(capability, {})
                if 'channel-set-width' in width:
                    interface.setdefault('capabilities', {}).setdefault(capability, {})[
                        'channel-set-width'
                    ] = deepcopy(width['channel-set-width'])
            # HE width remains unmanaged: the generator deliberately disables
            # this setting because enabling it makes the system unstable.

        desired[name] = interface
    return normalize_config(desired, hyphenated=True, stringify_numbers=True)


# @debug_log
def parse_wifi_config(data: dict, bridge_name: str) -> dict:
    """
    Parse VyOS WiFi configuration into a format suitable for WiFiInterfaceConfig.refresh
    
    Args:
        data: VyOS configuration data containing wireless interfaces
        
    Returns:
        Dictionary with WiFi interface configuration data formatted for WiFiInterfaceConfig model
    """
    result = {
        # Access Point defaults
        'ap_enable': False,
        'ap_enable5': False,
        'ap_enable24': False,
        'ap_description': '',
        'ap_ssid': '',
        'ap_password': '',
        'ap_mode': 'ac',
        'ap_security': '',
        'ap_encryption': [],
        'ap_hidden_ssid': False,
        'ap_prevent_low': False,
        'ap_management_frame': 'disabled',
        'ap_bridge_mode': True,
        'ap_ipv4_mode': 'static',
        'ap_ipv4_address': '',
        'ap_ipv4_length': '',
        'ap_ipv6_mode': 'static',
        'ap_ipv6_address': '',
        'ap_ipv6_length': '',
        'ap_acl_mode': 'deny',
        'ap_acl_accept': [],
        'ap_acl_deny': [],
        'ap_ac_channel_width': '',
        'ap_ax_channel_width': '',
        'ap_n_channel_width': [],
        
        # Client defaults
        'client_enable': False,
        'client_enable5': False,
        'client_enable24': False,
        'client_ssid': '',
        'client_password': '',
        'client_security': '',
        'client_bridge_mode': True,
        'client_ipv4_mode': 'static',
        'client_ipv4_address': '',
        'client_ipv4_length': '',
        'client_ipv6_mode': 'static',
        'client_ipv6_address': '',
        'client_ipv6_length': '',
        'client_default_route_distance_5': '',
        'client_default_route_distance_24': ''
    }
    
    if not data or 'wireless' not in data:
        return result

    ap_ifnames = ['wlan0', 'wlan1']
    client_ifnames = ['wlan2', 'wlan3']
    
    bridges = data.get('bridge') or {}
    # TODO: Handle multiple IPs of bridge if happened?

    if bridge_name in bridges:
        ap_ip = bridges[bridge_name].get('address', '')
        if isinstance(ap_ip, list):
            ap_ip = ap_ip[0] if ap_ip else ''
        ap_ip = ap_ip if isinstance(ap_ip, str) else ''
        ap_address, _, ap_length = ap_ip.partition('/')
        result['ap_ipv4_address'] = ap_address
        result['ap_ipv4_length'] = ap_length

    wireless = normalize_config(data['wireless'], hyphenated=True, stringify_numbers=True)
    
    is_ap_5_disable = False
    is_ap_24_disable = False
    is_client_5_disable = False
    is_client_24_disable = False
    
    for ifname, ifconfig in wireless.items():
        if not isinstance(ifconfig, dict):
            continue
        
        if ifname == 'wlan0':
            is_ap_5_disable = 'disable' in ifconfig
        elif ifname == 'wlan1':
            is_ap_24_disable = 'disable' in ifconfig
        elif ifname == 'wlan2':
            is_client_5_disable = 'disable' in ifconfig
        elif ifname == 'wlan3':
            is_client_24_disable = 'disable' in ifconfig
        
        is_disabled = 'disable' in ifconfig
        
        if ifname in ap_ifnames and 'description' in ifconfig:
            result['ap_description'] = ifconfig['description']
        
        if_type = ifconfig.get('type', '').lower()
        
        if 'mode' in ifconfig and ifname == 'wlan0':
            result['ap_mode'] = ifconfig['mode']

        if ifname in ap_ifnames and 'capabilities' in ifconfig:
            capabilities = ifconfig['capabilities']
            if 'vht' in capabilities:
                vht = capabilities['vht']
                result['ap_ac_channel_width'] = vht.get('channel-set-width', '')
            if 'he' in capabilities:
                he = capabilities['he']
                result['ap_ax_channel_width'] = he.get('channel-set-width', '')
            if 'ht' in capabilities:
                ht = capabilities['ht']
                result['ap_n_channel_width'] = ht.get('channel-set-width', [])
        
        if if_type == 'access-point' or ifname in ap_ifnames:
            result['ap_enable'] = not is_disabled
            result['ap_ssid'] = ifconfig.get('ssid', '')
            
            if 'security' in ifconfig: 
                if 'wpa' in ifconfig['security']:
                    wpa_config = ifconfig['security']['wpa']
                    result['ap_security'] = wpa_config.get('mode', '')
                    
                    result['ap_password'] = wpa_config.get('passphrase', '')
                    
                    ciphers = wpa_config.get('cipher')
                    if isinstance(ciphers, list) and ciphers:
                        result['ap_encryption'] = ciphers
                    elif isinstance(ciphers, str):
                        result['ap_encryption'] = [ciphers]
                if 'station-address' in ifconfig['security']:
                    station_address = ifconfig['security']['station-address']
                    result['ap_acl_mode'] = station_address.get('mode', '')
                    acl_accept = station_address.get('accept', None)
                    if acl_accept and acl_accept.get('mac', None):
                        accept_macs = acl_accept['mac']
                        if isinstance(accept_macs, list):
                            result['ap_acl_accept'] = accept_macs
                        elif isinstance(accept_macs, str):
                            result['ap_acl_accept'] = [accept_macs]
                            
                    acl_deny = station_address.get('deny', None)
                    if acl_deny and acl_deny.get('mac', None):
                        deny_macs = acl_deny['mac']
                        if isinstance(deny_macs, list):
                            result['ap_acl_deny'] = deny_macs
                        elif isinstance(deny_macs, str):
                            result['ap_acl_deny'] = [deny_macs]
            
            result['ap_hidden_ssid'] = 'disable-broadcast-ssid' in ifconfig
            
            if 'mgmt-frame-protection' in ifconfig:
                result['ap_management_frame'] = ifconfig.get('mgmt-frame-protection', '')

            if 'isolate-stations' in ifconfig:
                result['ap_prevent_low'] = True
            
            if 'address' in ifconfig:
                addresses = ifconfig['address']
                if isinstance(addresses, list):
                    for addr in addresses:
                        if ':' in addr:  # IPv6
                            ip, prefix = addr.split('/')
                            result['ap_ipv6_address'] = ip
                            result['ap_ipv6_length'] = prefix
                elif isinstance(addresses, str):
                    addr = addresses
                    if ':' in addr:  # IPv6
                        if '/' in addr:
                            ip, prefix = addr.split('/')
                            result['ap_ipv6_address'] = ip
                            result['ap_ipv6_length'] = prefix
                        else:
                            result['ap_ipv6_address'] = addr
        
        # Process Client interfaces
        elif if_type == 'station' or ifname in client_ifnames:  # Client mode
            result['client_enable'] = not is_disabled
            result['client_ssid'] = ifconfig.get('ssid', '')
            
            if 'security' in ifconfig and 'wpa' in ifconfig['security']:
                wpa_config = ifconfig['security']['wpa']
                result['client_security'] = wpa_config.get('mode', '')
                result['client_password'] = wpa_config.get('passphrase', '')
            
            addresses = ifconfig.get('address', [])
            addr_list = addresses if isinstance(addresses, list) else [addresses]
            addr_list = [a for a in addr_list if isinstance(a, str)]

            if any(a.strip().lower() == 'dhcp' for a in addr_list):
                result['client_ipv4_mode'] = 'dhcp'
                result['client_ipv4_address'] = ''
                result['client_ipv4_length'] = ''
            else:
                for addr in addr_list:
                    if '.' in addr:  # IPv4
                        ip, _, prefix = addr.partition('/')
                        result['client_ipv4_address'] = ip
                        result['client_ipv4_length'] = prefix
                        result['client_ipv4_mode'] = 'static'

            result['client_ipv6_mode'] = 'static'
            result['client_ipv6_address'] = ''
            result['client_ipv6_length'] = ''
            address_options = ifconfig.get('ipv6', {}).get('address', {})
            if any(a.strip().lower() == 'dhcpv6' for a in addr_list):
                result['client_ipv6_mode'] = 'dhcpv6'
            elif 'autoconf' in address_options:
                result['client_ipv6_mode'] = 'autoconf'
            else:
                for addr in addr_list:
                    if ':' in addr:
                        ip, _, prefix = addr.partition('/')
                        result['client_ipv6_address'] = ip
                        result['client_ipv6_length'] = prefix
            
            if 'dhcp-options' in ifconfig:
                if 'default-route-distance' in ifconfig['dhcp-options']:
                    if ifname == 'wlan2':
                        result['client_default_route_distance_5'] = ifconfig['dhcp-options']['default-route-distance']
                    if ifname == 'wlan3':
                        result['client_default_route_distance_24'] = ifconfig['dhcp-options']['default-route-distance']
    
    result['ap_enable5'] = not is_ap_5_disable
    result['ap_enable24'] = not is_ap_24_disable
    result['client_enable5'] = not is_client_5_disable
    result['client_enable24'] = not is_client_24_disable
    result['ap_enable'] = result['ap_enable5'] or result['ap_enable24']
    result['client_enable'] = result['client_enable5'] or result['client_enable24']
    
    return result


def parse_wifi(data: dict, bridge: dict) -> dict:
    """Reuse the running-config parser for the merged configuration saved to DB."""
    if not data or 'wireless' not in data:
        return {}
    return parse_wifi_config({**data, 'bridge': bridge or {}}, 'br1')
