def _match_key(direction):

    return 'prefix' if direction == 'source' else 'address'


def _rule_to_config(rule, direction):
    config = {'protocol': rule.get('protocol') or 'all'}
    for flag in ('disable', 'exclude', 'log'):
        if rule.get(flag): config[flag] = {}
    if rule.get('description'): config['description'] = rule['description']
    interface = rule.get('outbound_interface' if direction == 'source' else 'inbound_interface')
    if interface: config[f'{"outbound" if direction == "source" else "inbound"}-interface'] = {'name': interface}
    match_key = _match_key(direction)
    if rule.get('source_address') or rule.get('source_port'):
        config['source'] = {}
        if rule.get('source_address'): config['source'][match_key] = rule['source_address']
        if rule.get('source_port'): config['source']['port'] = rule['source_port']
    for section in ('destination', 'translation'):
        address, port = rule.get(f'{section}_address'), rule.get(f'{section}_port')
        if address or port:
            config[section] = {}
            if address:
                config[section][match_key if section == 'destination' else 'address'] = address
            if port: config[section]['port'] = port
    return config

def parse_nat66_input(data):
    result = {'source': {'rule': {}}, 'destination': {'rule': {}}}
    for direction in ('source', 'destination'):
        for rule in data['NATv6'][direction]:
            result[direction]['rule'][rule['rule_id']] = _rule_to_config(rule, direction)
    return result

def serialize_nat66(config):
    result = []
    for direction in ('source', 'destination'):
        for rule_id, rule in config.get(direction, {}).get('rule', {}).items():
            result.append({'rule_id': rule_id, 'rule_type': direction,
                'description': rule.get('description', ''), 'protocol': rule.get('protocol', 'all'),
                'disable': 'disable' in rule, 'exclude': 'exclude' in rule, 'log': 'log' in rule,
                'outbound_interface': rule.get('outbound-interface', {}).get('name', ''),
                'inbound_interface': rule.get('inbound-interface', {}).get('name', ''),
                'source_address': rule.get('source', {}).get(_match_key(direction), ''),
                'source_port': rule.get('source', {}).get('port', ''),
                'destination_address': rule.get('destination', {}).get(_match_key(direction), ''),
                'destination_port': rule.get('destination', {}).get('port', ''),
                'translation_address': rule.get('translation', {}).get('address', ''),
                'translation_port': rule.get('translation', {}).get('port', '')})
    return result
