from app.core.system import vyos_system_bp
from flask import jsonify, request, session
from app.core.operation.models import PKICaCertificate, PKICertificate, KeyPair, OpenVPNSharedSecretKey, PKIDH
from app.auth.utils import login_required, permission_required

from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, DEBUG
from app.core.system.keycert.models import CreateKeyCertDTO, UpdateKeyCertDTO, VerifyKeyCertDTO
import pprint
from app.core.system.keycert.parser import parse_to_keycert_config
from app.core.api.http.cmd.compare import compare_configs
from app.core.system.syslog.models import SyslogConfig, UpdateSyslogDTO, VerifySyslogDTO
from app.core.system.syslog.parser import parse_to_syslog_config
from app.core.system.event_handler.models import (
    AlarmCallbackEvent,
    AlarmConfig,
    AlarmNotificationUserState,
    UpdateAlarmDTO,
    VerifyAlarmDTO,
)
from app.db.database import db
from app.core.system.event_handler.parser import parse_to_alarm_config
from app.core.system.email.models import EmailConfig, EmailProfileDTO, TestEmailDTO, UpdateEmailDTO
from app.core.system.email.parser import (
    parse_to_vyos_config as parse_to_email_vyos_config,
    parse_to_vyos_config_verify as parse_to_email_verify_config,
)

from app.core.utils.decorator.route_decorator import Pipeline
from app.core.utils.check_os import is_linux
from app.core.system.cloud import get_cloud_status, set_cloud_connection
import subprocess

admin_system = Pipeline.admin(vyos_system_bp)

logger = getLogger(__name__)
logger.setLevel(DEBUG)


@vyos_system_bp.route('/cloud/status', methods=['GET'])
@login_required
def cloud_status():
    response = jsonify(get_cloud_status())
    response.headers['Cache-Control'] = 'no-store'
    return response, 200


@vyos_system_bp.route('/cloud/connection', methods=['POST'])
@permission_required(permissions=['administrator'])
def cloud_connection():
    payload = request.get_json(silent=True)
    action = payload.get('action') if isinstance(payload, dict) else None
    if not isinstance(action, str) or action not in ('connect', 'disconnect'):
        return jsonify({'error': 'Action must be connect or disconnect'}), 400

    if not is_linux():
        return jsonify({'error': 'Cloud connection control requires Linux'}), 400

    try:
        set_cloud_connection(action)
        message = 'Cloud service started' if action == 'connect' else 'Cloud service stopped'
        return jsonify({'message': message}), 200
    except subprocess.TimeoutExpired:
        logger.error('Cloud %s timed out', action)
        return jsonify({'error': f'Cloud {action} timed out. Refresh the status before retrying.'}), 504
    except (OSError, subprocess.SubprocessError):
        logger.exception('Unable to %s cloud service', action)
        return jsonify({'error': f'Unable to {action} cloud service'}), 500


@vyos_system_bp.route('/keycert', methods=['GET'])
@login_required
def get_keycert():
    try:
        ca_certificates = PKICaCertificate.query.all()
        certificates = PKICertificate.query.all()
        key_pairs = KeyPair.query.all()
        openvpn_shared_secret_keys = OpenVPNSharedSecretKey.query.all()
        dh_items = PKIDH.query.all()
        certificates = {
            'ca': [ca.serialize() for ca in ca_certificates],
            'certificate': [cert.serialize() for cert in certificates],
            'crl': []
        }
        keys = {
            'key_pair': [kp.serialize() for kp in key_pairs],
            'openvpn': [ovk.serialize() for ovk in openvpn_shared_secret_keys],
            'ssh': [],
            'wireguard': [],
            'dh': [d.serialize() for d in dh_items]
        }
        return jsonify({
            'certificates': certificates,
            'keys': keys
        }), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/keycert/monitor', methods=['POST'])
@login_required
def get_keycert_monitor():
    try:
        payload = request.get_json(silent=True) or {}
        resource = str(payload.get('resource', '')).strip().lower()
        include_authorities = bool(payload.get('authorities')) or resource in ('authority', 'authorities', 'all')
        include_certificates = bool(payload.get('certificates')) or resource in ('certificate', 'certificates', 'all')

        if not include_authorities and not include_certificates:
            return jsonify({"error": "resource must be one of: authorities, certificates, all"}), 400

        authority_data = {'authorities': [], 'success': True, 'errors': None}
        certificate_data = {'certificates': [], 'success': True, 'errors': None}

        if include_authorities:
            authority_data = api_manager.call(action=API_ACTION.READ, target=API_TARGET.KEYCERT_AUTHORITY_MONITOR)
            if isinstance(authority_data, Exception):
                return jsonify({"error": str(authority_data)}), 400

        if include_certificates:
            certificate_data = api_manager.call(action=API_ACTION.READ, target=API_TARGET.KEYCERT_CERTIFICATE_MONITOR)
            if isinstance(certificate_data, Exception):
                return jsonify({"error": str(certificate_data)}), 400

        return jsonify({
            'authorities': authority_data.get('authorities', []),
            'certificates': certificate_data.get('certificates', []),
            'success': authority_data.get('success') and certificate_data.get('success'),
            'errors': {
                'authorities': authority_data.get('errors'),
                'certificates': certificate_data.get('errors'),
            }
        }), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400
    

@vyos_system_bp.route('/keycert', methods=['PUT'])
@permission_required(permissions=['administrator'])
def update_keycert():
    try:
        data = UpdateKeyCertDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.KEYCERT)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))

        new_config = parse_to_keycert_config(data.model_dump())
        print("New config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.KEYCERT, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        # Refresh OS config to update keycert
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
    
        return jsonify({'message': 'Success', 'data': res}), 200
    
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/keycert/verify', methods=['POST'])
@permission_required(permissions=['administrator'])
def verify_keycert():
    try:
        data = VerifyKeyCertDTO.model_validate_json(request.data)
        logger.info("Unparsed config:")
        logger.info(pprint.pformat(data.model_dump(), indent=2, width=80))
        
        new_config = parse_to_keycert_config(data.model_dump(), verify=True)
        logger.info("New config: ")
        logger.info(pprint.pformat(new_config, indent=2, width=80))
        
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.KEYCERT, data=new_config)
        
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/alarm/verify', methods=['POST'])
def verify_alarm():
    try:
        data = VerifyAlarmDTO.model_validate_json(request.data)
        new_config = parse_to_alarm_config(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.ALARM, data=new_config)

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200

        return jsonify({"verify": verify}), 400
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/service/vyos-http-api/restart', methods=['POST'])
@login_required
def restart_vyos_http_api():
    try:
        if not is_linux():
            return jsonify({'error': 'not_supported'}), 400

        proc = subprocess.run(
            ['systemctl', 'restart', 'vyos-http-api'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        if proc.returncode != 0:
            return jsonify({'error': 'restart_failed', 'detail': (proc.stderr or proc.stdout or '').strip()}), 500

        return jsonify({'message': 'Success'}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/keycert/generate', methods=['POST'])
@login_required
def generate_keycert():
    try:
        data = CreateKeyCertDTO.model_validate_json(request.data)
        logger.info(f"Generating PKI key type: {data.pki_key_type}")
        
        key = None
        if data.pki_key_type == 'ca':
            key = api_manager.call(action=API_ACTION.GENERATE, target=API_TARGET.PKI_CA, data=data)
        elif data.pki_key_type == 'certificate':
            key = api_manager.call(action=API_ACTION.GENERATE, target=API_TARGET.PKI_CERTIFICATE, data=data)
        elif data.pki_key_type == 'crl':
            key = api_manager.call(action=API_ACTION.GENERATE, target=API_TARGET.PKI_CRL, data=data)
        elif data.pki_key_type == 'dh':
            key = api_manager.call(action=API_ACTION.GENERATE, target=API_TARGET.PKI_DH, data=data)
        elif data.pki_key_type == 'key_pair':
            key = api_manager.call(action=API_ACTION.GENERATE, target=API_TARGET.PKI_KEY_PAIR, data=data)
        else:
            logger.error(f"Unknown pki_key_type: {data.pki_key_type}")
            return jsonify({"error": f"Unknown pki_key_type: {data.pki_key_type}"}), 400

        if isinstance(key, Exception):
            print(f"Key generation failed: {str(key)}")
            return jsonify({"error": str(key)}), 400

        if key is None:
            logger.error("Key generation returned None")
            return jsonify({"error": "Key generation failed"}), 500

        logger.info(f"Generated key response: {key}")
        return jsonify(key), 200
    
    except Exception as e:
        logger.error(f"Error generating keycert: {str(e)}")
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/syslog', methods=['GET'])
@login_required
def get_syslog():
    try:
        row = SyslogConfig.query.first()
        if row is None:
            return jsonify(SyslogConfig.empty_frontend()), 200

        return jsonify(row.serialize()), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/alarm', methods=['GET'])
@login_required
def get_alarm():
    try:
        row = AlarmConfig.query.first()
        if row is None:
            return jsonify(AlarmConfig.empty_frontend()), 200

        return jsonify(row.serialize()), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/alarm/monitor', methods=['GET'])
@login_required
def get_alarm_monitor_events():
    try:
        return jsonify({'events': AlarmCallbackEvent.list_serialized()}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@vyos_system_bp.route('/alarm/email', methods=['GET'])
@login_required
def get_alarm_email():
    try:
        row = EmailConfig.query.first()
        if row is None:
            return jsonify(EmailConfig.empty_frontend()), 200

        return jsonify(row.serialize()), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


def _notification_username():
    return str(session.get('username') or '').strip()


@vyos_system_bp.route('/notifications', methods=['GET'])
@login_required
def get_notifications():
    try:
        username = _notification_username()
        if username == '':
            return jsonify({'message': 'Authenticated username is required'}), 401

        try:
            limit = min(max(int(request.args.get('limit', 100)), 1), 200)
            after_id_value = request.args.get('after_id')
            after_id = int(after_id_value) if after_id_value not in [None, ''] else None
        except (TypeError, ValueError):
            return jsonify({'message': 'Invalid pagination parameters'}), 400

        events, unread_counts = AlarmCallbackEvent.list_for_user(
            username=username,
            after_id=after_id,
            limit=limit,
        )
        event_ids = [int(event['id']) for event in events]
        return jsonify({
            'events': events,
            'nextCursor': max(event_ids) if event_ids else after_id,
            'unreadCounts': unread_counts,
        }), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/notifications/<int:event_id>/read', methods=['PATCH'])
@login_required
def mark_notification_read(event_id):
    username = _notification_username()
    if username == '':
        return jsonify({'message': 'Authenticated username is required'}), 401
    event = db.session.get(AlarmCallbackEvent, event_id)
    if event is None:
        return jsonify({'message': 'Notification not found'}), 404

    try:
        AlarmNotificationUserState.mark_read(event_id, username)
        db.session.commit()
        return jsonify({'event': event.serialize_notification(is_read=True)}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/notifications/<int:event_id>', methods=['DELETE'])
@login_required
def dismiss_notification(event_id):
    username = _notification_username()
    if username == '':
        return jsonify({'message': 'Authenticated username is required'}), 401
    event = db.session.get(AlarmCallbackEvent, event_id)
    if event is None:
        return jsonify({'message': 'Notification not found'}), 404

    try:
        AlarmNotificationUserState.dismiss(event_id, username)
        db.session.commit()
        return jsonify({'success': True, 'id': str(event_id)}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/notifications/read-all', methods=['POST'])
@login_required
def mark_all_notifications_read():
    username = _notification_username()
    if username == '':
        return jsonify({'message': 'Authenticated username is required'}), 401
    try:
        dismissed_ids = {
            state.event_id
            for state in AlarmNotificationUserState.query.filter(
                AlarmNotificationUserState.username == username,
                AlarmNotificationUserState.dismissed_at.is_not(None),
            ).all()
        }
        for event in AlarmCallbackEvent.query.all():
            if event.id not in dismissed_ids:
                AlarmNotificationUserState.mark_read(event.id, username)
        db.session.commit()
        return jsonify({'success': True}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/notifications/dismiss-read', methods=['POST'])
@login_required
def dismiss_read_notifications():
    username = _notification_username()
    if username == '':
        return jsonify({'message': 'Authenticated username is required'}), 401
    try:
        states = AlarmNotificationUserState.query.filter(
            AlarmNotificationUserState.username == username,
            AlarmNotificationUserState.read_at.is_not(None),
            AlarmNotificationUserState.dismissed_at.is_(None),
        ).all()
        dismissed_ids = []
        for state in states:
            AlarmNotificationUserState.dismiss(state.event_id, username)
            dismissed_ids.append(str(state.event_id))
        db.session.commit()
        return jsonify({'success': True, 'ids': dismissed_ids}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/syslog', methods=['PUT'])
def update_syslog():
    try:
        data = UpdateSyslogDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSLOG_CONFIG)
        if not isinstance(current_config, dict):
            current_config = {}

        new_config = parse_to_syslog_config(data.model_dump())
        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SYSLOG_CONFIG,
            data={"current": current_config, "new": new_config, "diff": diff}
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400

        return jsonify(res), 200

    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@admin_system.route('/alarm', methods=['PUT'])
def update_alarm():
    try:
        data = UpdateAlarmDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.ALARM)
        if not isinstance(current_config, dict):
            current_config = {}
        print("New config from frontend: ")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_config = parse_to_alarm_config(data.model_dump())
        print("New parsed config: ")
        print(pprint.pformat(new_config, indent=2, width=80))
        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.ALARM,
            data={"current": current_config, "new": new_config, "diff": diff}
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400

        return jsonify(res), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@admin_system.route('/alarm/email', methods=['PUT'])
def update_alarm_email():
    try:
        raw_data = request.data

        try:
            data = UpdateEmailDTO.model_validate_json(raw_data)
            if not isinstance(data, UpdateEmailDTO):
                raise TypeError("Invalid email configuration payload")
        except Exception as validation_error:
            return jsonify({"error": f"Validation error: {validation_error}"}), 400

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.EMAIL)
        if isinstance(current_config, Exception):
            raise current_config

        if not isinstance(current_config, dict):
            current_config = {}

        new_config = parse_to_email_vyos_config(data.model_dump())
        diff_config = compare_configs(new_config, current_config)

        result = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.EMAIL,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config,
            },
        )

        if isinstance(result, Exception):
            raise result

        api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.OS_CONFIG,
            data={"refresh": True},
        )

        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400


@admin_system.route('/alarm/email/verify', methods=['POST'])
def verify_alarm_email_profile():
    try:
        profile = EmailProfileDTO.model_validate_json(request.data)
        verify_config = parse_to_email_verify_config({
            'activeProfile': '',
            'profiles': [profile.model_dump()],
            'recipients': [],
        })
        verify = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.EMAIL,
            data=verify_config,
        )

        if isinstance(verify, Exception):
            raise verify
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200

        return jsonify({"verify": str(verify)}), 400
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/alarm/email/test', methods=['POST'])
@login_required
def send_alarm_test_email():
    try:
        data = TestEmailDTO.model_validate_json(request.data)
        result = api_manager.call(
            action=API_ACTION.GENERATE,
            target=API_TARGET.EMAIL_TEST,
            data=data.model_dump(),
        )
        if isinstance(result, Exception):
            raise result

        status_code = 200 if result.get('success') is True else 400
        return jsonify(result), status_code
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/syslog/verify', methods=['POST'])
def verify_syslog():
    try:
        data = VerifySyslogDTO.model_validate_json(request.data)
        new_config = parse_to_syslog_config(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.SYSLOG_CONFIG, data=new_config)

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200

        return jsonify({"verify": verify}), 400

    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400
