from app.core.api.http.cmd.command import Command
import pprint
class DNSDynamicCommand(Command):
    """
    Class for generating DNS dynamic commands
    Supports the following VyOS commands:
    set/delete service dns dynamic name <service-name> address interface <intf-name>
    set/delete service dns dynamic name <service-name> address web url <url>
    set/delete service dns dynamic name <service-name> address web skip <text>
    set/delete service dns dynamic name <service-name> protocol <protocol-name>
    set/delete service dns dynamic name <service-name> username <user-name>
    set/delete service dns dynamic name <service-name> password <password>
    set/delete service dns dynamic name <service-name> host-name <host-name>
    set/delete service dns dynamic name <service-name> zone <zone-name>

    Sample params for generate_commands():
    {'interfaces': [{'id': 'b1eb9d7d-72f6-437c-9a0b-8f277963e7d3', 'hostname': 'test.com', 
                    'interface': '', 'url': 'example.com', 'skip': '100', 'service': 'dyndns', 
                    'login': 'admin', 'password': 'admin', 'registered_service': 'Host'}]}
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
            self.attributes = {
                'name': None,
                'username': None,
                'password': None,
                'host_name': None,
                'protocol': None,
                'zone': None,
                'address': {
                    'interface': None,
                    'web': {
                        'url': None,
                        'skip': None
                    }
                },
                "ip-version": "ipv4",
                'all': None
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    if key == 'address' and isinstance(value, dict):
                        if 'interface' in value:
                            self.attributes['address']['interface'] = value['interface']
                        if 'web' in value and isinstance(value['web'], dict):
                            if 'url' in value['web']:
                                self.attributes['address']['web']['url'] = value['web']['url']
                            if 'skip' in value['web']:
                                self.attributes['address']['web']['skip'] = value['web']['skip']
                    else:
                        self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing DNS dynamic cmd: {e}")


    def _build_command(self, *path_elements: str) -> str:
        """Build a cmd string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        # Convert tuple to list of strings
        self.vyos_cmds.append(' '.join(map(str, args)))


    def get_commands(self):
        return self.vyos_cmds


    def generate_commands(self, data=None, current_config=None, new_config=None):
        """
        Generate VyOS commands for DNS dynamic configuration
        
        Input format:
        {
            'name': {
                'ddns1': {
                    'address': {
                        'web': {'skip': '100', 'url': 'http://example.com'}
                    },
                    'host-name': 'test.com',
                    'password': 'password',
                    'protocol': 'digitalocean',
                    'server': '8.8.8.8',
                    'username': 'admin',
                    'zone': 'zone1'
                }
            }
        }
        
        For delete operations, if data contains {'all': True}, delete all DNS dynamic configurations
        """
        try:
            if not data:
                return []

            base_path = ['service', 'dns', 'dynamic']

            # Handle delete all case
            if self.operator == 'delete' and isinstance(data, dict) and data.get('all'):
                self.generate(*base_path)
                return self.get_commands()

            if not isinstance(data, dict) or 'name' not in data:
                return []

            for name, config in data['name'].items():
                name_path = [*base_path, 'name', name]
                
                if self.operator == 'delete':
                    # For delete, just remove the entire name configuration
                    self.generate(*name_path)
                else:
                    # Set address configuration
                    if 'address' in config:
                        if 'interface' in config['address'] and config['address']['interface'].strip() != '':
                            self.generate(*name_path, 'address', 'interface', config['address']['interface'])
                        if 'web' in config['address']:
                            web = config['address']['web']
                            if 'skip' in web and web['skip'].strip() != '':
                                self.generate(*name_path, 'address', 'web', 'skip', web['skip'])
                            if 'url' in web and web['url'].strip() != '':
                                self.generate(*name_path, 'address', 'web', 'url', web['url'])

                    # Set basic configuration
                    if 'host-name' in config and config['host-name'].strip() != '':
                        self.generate(*name_path, 'host-name', config['host-name'])
                    if 'password' in config and config['password'].strip() != '':
                        self.generate(*name_path, 'password', config['password'])
                    if 'protocol' in config and config['protocol'].strip() != '':
                        self.generate(*name_path, 'protocol', config['protocol'])
                    if 'server' in config and config['server'].strip() != '':
                        self.generate(*name_path, 'server', config['server'])
                    if 'username' in config and config['username'].strip() != '':
                        self.generate(*name_path, 'username', config['username'])
                    if 'zone' in config and config['zone'].strip() != '':
                        self.generate(*name_path, 'zone', config['zone'])
                    if 'ip-version' in config and config['ip-version'].strip() != '':
                        self.generate(*name_path, 'ip-version', config['ip-version'])

            return self.cmds

        except Exception as e:
            print(f"Error generating DNS dynamic commands: {str(e)}")
            return []


class DNSForwardingCommand(Command):
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
            self.attributes = {
                'domains': None,
                'name_servers': None,
                'listen_addresses': None,
                'allow_from': None,
                'cache_size': None,
                'negative_ttl': None,
                'ignore_hosts_file': None,
                'dhcp_interfaces': None,
                'all': None
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing DNS cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a cmd string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        # Convert tuple to list of strings
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def get_validation_commands(self):
        system_command = 'service dns forwarding system'
        return [command for command in self.vyos_cmds if command != system_command]

    def generate_commands(self, data=None, current_config=None, new_config=None) -> list[str]:
        """Generate DNS commands based on the provided data"""
        try:
            if data:
                for key, value in data.items():
                    self.attributes[key] = value

            cmds = []
            base_path = ['service', 'dns', 'forwarding']

            if self.operator == "delete" and self.attributes['all']:
                self.generate(*base_path)
                return self.cmds

            if self.operator == "set" and new_config:
                self.generate(*base_path, 'system')
            
            if self.attributes['domains']:
                if self.operator == "set":
                    for domain in self.attributes['domains']:
                        for server in domain['name_servers']:
                            self.generate(*base_path, 'domain', domain['name'], 'name-server', server)
                elif self.operator == "delete":
                    for domain in self.attributes['domains']:
                        for server in domain['name_servers']:
                            self.generate(*base_path, 'domain', domain['name'], 'name-server', server)
                        
                        current_domain_config = None
                        if current_config and 'domains' in current_config:
                            for current_domain in current_config['domains']:
                                if current_domain.get('name') == domain['name']:
                                    current_domain_config = current_domain
                                    break
                        
                        current_name_servers = current_domain_config.get('name_servers', []) if current_domain_config else []
                        
                        if len(domain['name_servers']) == len(current_name_servers):
                            self.generate(*base_path, 'domain', domain['name'])

            if self.attributes['name_servers']:
                for server in self.attributes['name_servers']:
                    path = [*base_path, 'name-server', server['address']]
                    self.generate(*path)

            if self.attributes['listen_addresses']:
                for address in self.attributes['listen_addresses']:
                    self.generate(*base_path, 'listen-address', address)
            
            if self.attributes['allow_from']:
                for network in self.attributes['allow_from']:
                    self.generate(*base_path, 'allow-from', network)

            if self.attributes['cache_size'] is not None:
                self.generate(*base_path, 'cache-size', str(self.attributes['cache_size']))

            if self.attributes['negative_ttl'] is not None:
                self.generate(*base_path, 'negative-ttl', str(self.attributes['negative_ttl']))

            if self.attributes['ignore_hosts_file']:
                self.generate(*base_path, 'ignore-hosts-file')

            if self.attributes['dhcp_interfaces']:
                for interface in self.attributes['dhcp_interfaces']:
                    self.generate(*base_path, 'dhcp', interface)
            
            return self.cmds

        except Exception as e:
            print(f"Error generating DNS commands: {e}")
            return []

if __name__ == "__main__":
    test_data = {
        'domains': [
            {
                'name': 'example.com',
                'name_servers': ['192.0.2.254', '2001:db8:cafe::1']
            }
        ],
        'name_servers': [
            {'address': '192.0.2.1'},
            {'address': '192.0.2.2'},
            {'address': '192.0.2.3', 'port': 853},
            {'address': '2001:db8::1:ffff'},
            {'address': '2001:db8::2:ffff'},
            {'address': '2001:db8::3:ffff', 'port': 8053}
        ],
        'listen_addresses': [
            '192.168.1.254',
            '2001:db8::ffff'
        ],
        'allow_from': [
            '192.168.1.0/24',
            '2001:db8::/64'
        ],
        'cache_size': 10000,
        'negative_ttl': 3600,
        'ignore_hosts_file': True,
        'dhcp_interfaces': [
            'eth0',
            'eth1',
            'eth2',
            'dum1'
        ]
    }

    print("Test DNS commands:")
    print("\n1. Setting DNS forwarding configuration:")
    dns_set = DNSForwardingCommand(operator='set', resource='service')
    set_commands = dns_set.generate_commands(test_data)
    for cmd in set_commands:
        print(cmd)

    print("\n2. Deleting DNS forwarding configuration:")
    dns_delete = DNSForwardingCommand(operator='delete', resource='service')
    delete_commands = dns_delete.generate_commands(test_data)
    for cmd in delete_commands:
        print(cmd)

    # test_ddns_data = {'interfaces': [{'id': 'b1eb9d7d-72f6-437c-9a0b-8f277963e7d3', 'hostname': 'test.com', 
    #                 'interface': '', 'url': 'example.com', 'skip': '100', 'service': 'dyndns', 
    #                 'login': 'admin', 'password': 'admin', 'registered_service': 'Host'}]}

    test_ddns_data = {'name': {'1d94f50a-4641-493e-8021-a0cd8e2de289': {'address': {'web': {'skip': '100', 'url': 'http://example.com'}}, 'host-name': 'test.com', 'password': 'password', 'protocol': 'digitalocean', 'server': '8.8.8.8', 'username': 'admin', 'zone': 'zone1'}, '10058f82-a49b-4167-ae05-045e23b78eaf': {'address': {'interface': 'eth1'}, 'host-name': 'test2.com', 'password': 'admin', 'protocol': 'dyndns2', 'server': '8.8.8.8', 'username': 'admin', 'zone': 'zone3'}}}

    print("\n3. Setting DNS dynamic configuration:")

    dns_dynamic_set = DNSDynamicCommand(operator='set', resource='service')
    set_commands = dns_dynamic_set.generate_commands(test_ddns_data)
    for cmd in set_commands:
        print(cmd)

    print("\n4. Deleting DNS dynamic configuration:")
    dns_dynamic_delete = DNSDynamicCommand(operator='delete', resource='service')
    delete_commands = dns_dynamic_delete.generate_commands(test_ddns_data)
    for cmd in delete_commands:
        print(cmd)