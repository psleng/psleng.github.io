import os 
import importlib
import importlib.util
import requests
from typing import Dict, Any
import os
from dotenv import load_dotenv
from abc import ABC, abstractmethod
import subprocess
import ast
import pprint
from app.log.logger import logger
from app.core.utils.check_os import is_linux
from app.core.utils.validate.verify_parser import extract_config_error_message

load_dotenv()
_host = os.environ.get("VYOS_HOSTNAME")
_port = os.environ.get("VYOS_PORT")
hostname = f"https://{_host}"
port = f"{_port}"
linux_root_path = "/usr/libexec/vyos"

location = {
    "system_host_name": "/conf_mode/system_host-name.py",
    "service_dns_forwarding": "/conf_mode/service_dns_forwarding.py",
    "service_dns_dynamic": "/conf_mode/service_dns_dynamic.py",
    "firewall": "/conf_mode/firewall.py",
    "nat": "/conf_mode/nat.py",
    "nat66": "/conf_mode/nat66.py",
    "dhcp_server": "/conf_mode/service_dhcp-server.py",
    "dhcpv6_server": "/conf_mode/service_dhcpv6-server.py",
    "dhcp_relay": "/conf_mode/service_dhcp-relay.py",
    "ntp": "/conf_mode/service_ntp.py",
    "service_https": "/conf_mode/service_https.py",
    "wireless": "/conf_mode/interfaces_wireless.py",
    "bridge": "/conf_mode/interfaces_bridge.py",
    "ethernet": "/conf_mode/interfaces_ethernet.py",
    "openvpn": "/conf_mode/interfaces_openvpn.py",
    "cellular": "/conf_mode/interfaces_wwan.py",
    "wireguard": "/conf_mode/interfaces_wireguard.py",
    "l2tpv3": "/conf_mode/interfaces_l2tpv3.py",
    "general_routing": "/conf_mode/protocols_static.py",
    "system_login": "/conf_mode/system_login.py",
    "pki": "/conf_mode/pki.py",
    "vrrp": "/conf_mode/high-availability.py",
    "load-balancing_wan": "/conf_mode/load-balancing_wan.py",
    "ipsec": "/conf_mode/vpn_ipsec.py",
    "ospf": "/conf_mode/protocols_ospf.py",
    "ospfv3": "/conf_mode/protocols_ospfv3.py",
    "router_advert": "/conf_mode/service_router-advert.py",
    "snmp": "/conf_mode/service_snmp.py",
    "service_ndp_proxy": "/conf_mode/service_ndp-proxy.py",
    "service_ssh": "/conf_mode/service_ssh.py",
    "syslog": "/conf_mode/system-syslog.py",
    "failover": "/conf_mode/protocols_failover.py",
    "arp": "/conf_mode/protocol_static_arp.py",
    "alarm": "/conf_mode/service_event-handler.py",
    "email": "/conf_mode/system_email.py",
}

class AbtractValidator(ABC):

    @abstractmethod
    def call_get_config():
        return None

    @abstractmethod
    def call_verify():
        return None

class Validator(AbtractValidator):

    def __init__(self):
        self._locations = location
        self._hostname = hostname
        self._port = port
        self._root_path = linux_root_path

    
    def call_get_config(self, service: str) -> Dict[str, Any]:
        try:
            if not is_linux():
                # Make API call to linux box
                logger.log("Calling API Get Config")
                r = requests.post(url=f"{self._hostname}:{self._port}/webapi/vyos/configs/get-config", json={"service": service}, verify=False)
                if r.status_code != 200:
                    return {}
                return r.json()
            else:
                result = self.call_get_config_vyos(service)
                return result
        except Exception as e:
            logger.error(f"Error reading config {service}: {str(e)}")
            return {}


    def call_get_interface_config(self, service: str, ifname: str) -> Dict[str, Any]:
        try:
            file_path = linux_root_path + location[service]
            if not os.path.exists(file_path):
                logger.error(f"Service {service} not found at {file_path}")
                return {}

            dir_path = os.path.dirname(file_path)
            module_name = os.path.splitext(os.path.basename(file_path))[0]
            
            # Python command that imports the module, sets the environment variable, and calls get_config()
            python_cmd = f"""import os, sys, importlib.util

# Set the environment variable
os.environ['VYOS_TAGNODE_VALUE'] = '{ifname}'

# Add the directory to the Python path
sys.path.append('{dir_path}')

# Load the module
spec = importlib.util.spec_from_file_location('{module_name}', '{file_path}')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# Call get_config and print the result
print(module.get_config())"""

            result = subprocess.run(
                ["sudo", "/usr/bin/python3", "-c", python_cmd],
                capture_output=True,
                text=True,
                check=True
            )
            
            try:
                return ast.literal_eval(result.stdout.strip())
            except (ValueError, SyntaxError) as e:
                logger.error(f"Error parsing config output: {str(e)}")
                logger.error(f"Raw output was: {result.stdout}")
                return {}

        except subprocess.CalledProcessError as e:
            logger.error(f"Error executing get_config for {service} with interface {ifname}: {str(e)}")
            logger.error(f"stderr: {e.stderr}")
            return {}
        except Exception as e:
            logger.error(f"Error in call_get_interface_config for service {service} with interface {ifname}: {str(e)}")
            return {}


    def call_verify_interface(self, service: str, ifname: str, config: Dict[str, Any]) -> str:
        try:
            file_path = linux_root_path + location[service]
            if not os.path.exists(file_path):
                logger.error(f"Service {service} not found at {file_path}")
                return ""

            dir_path = os.path.dirname(file_path)
            module_name = os.path.splitext(os.path.basename(file_path))[0]
            
            # Python command that imports the module, sets the environment variable, and calls verify(config)
            python_cmd = f"""import os, sys, importlib.util, json

# Set the environment variable
os.environ['VYOS_TAGNODE_VALUE'] = '{ifname}'

# Add the directory to the Python path
sys.path.append('{dir_path}')

# Load the module
spec = importlib.util.spec_from_file_location('{module_name}', '{file_path}')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# Parse the config parameter
config = {config}

# Call verify and print the result
result = module.verify(config)
print(result if result else '')"""

            result = subprocess.run(
                ["sudo", "/usr/bin/python3", "-c", python_cmd],
                capture_output=True,
                text=True,
                check=True
            )
            
            return result.stdout.strip()

        except subprocess.CalledProcessError as e:
            logger.error(f"Error executing verify for {service} with interface {ifname}: {str(e)}")
            logger.error(f"stderr: {e.stderr}")
            config_error = extract_config_error_message(e.stderr)
            if config_error:
                return config_error
            return e.stderr
        except Exception as e:
            logger.error(f"Error in call_verify_interface_config for service {service} with interface {ifname}: {str(e)}")
            return str(e)


    def query_interface_config(self, service: str, ifname: str) -> Dict[str, Any]:
        try:
            if not is_linux():
                # Make API call to linux box
                logger.log("Calling API Get Config")
                r = requests.post(url=f"{self._hostname}:{self._port}/webapi/vyos/configs/get-config", json={"service": service, "ifname": ifname}, verify=False)
                if r.status_code != 200:
                    return {}
                return r.json()
            else:
                result = self.call_get_interface_config(service, ifname)
                return result
        except Exception as e:
            logger.error(f"Error reading config {service}: {str(e)}")
            return {}


    def query_interface_verify(self, service: str, ifname: str, config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            if not is_linux():
                # Make API call to linux box
                logger.log("Calling API Get Config")
                r = requests.post(url=f"{self._hostname}:{self._port}/webapi/vyos/configs/verify", json={"service": service, "ifname": ifname}, verify=False)
                if r.status_code != 200:
                    return {}
                return r.json()
            else:
                result = self.call_verify_interface(service, ifname, config)
                return result
        except Exception as e:
            logger.error(f"Error reading config {service}: {str(e)}")
            return {}



    def call_verify(self, service: str, config: Dict[str, Any]) -> str:
        try:
            logger.log("CALLING VERIFY:")
            logger.log(service)
            logger.log("Config data:")
            logger.log(config)
            if not is_linux():
                # Make API call to linux box
                r = requests.post(
                    url=f"{self._hostname}:{self._port}/webapi/vyos/configs/verify",
                    json={"service": service, "config": config},
                    verify=False
                )

                if (
                    service == "ipsec"
                    and isinstance(r.text, str)
                    and "KeyError" in r.text
                    and "vpp_ipsec_exists" in r.text
                ):
                    logger.error("Ignoring known VyOS IPSec verify crash: KeyError vpp_ipsec_exists")
                    return ""

                return r.text
            else:
                verify = self.call_verify_vyos(service, config)
                if (
                    service == "service_https" 
                    and isinstance(verify, str)
                    and "self-signed" in verify
                ):
                    logger.error("Ignoring self-signed certificate warning")
                    return ""
                
                return verify
        except Exception as e:
            logger.error(f"Error verifying {service}: {str(e)}")
            return ""

    def call_get_config_vyos(self, service: str) -> Dict[str, Any]:
        try:
            file_path = linux_root_path + location[service]
            if not os.path.exists(file_path):
                logger.error(f"Service {service} not found at {file_path}")
                return {}

            module_name = os.path.splitext(os.path.basename(file_path))[0]
            python_cmd = f"import sys, importlib; sys.path.append('{os.path.dirname(file_path)}'); m = importlib.import_module('{module_name}'); print(m.get_config())"

            result = subprocess.run(
                ["sudo", "/usr/bin/python3", "-c", python_cmd],
                capture_output=True,
                text=True,
                check=True
            )
            try:
                return ast.literal_eval(result.stdout.strip())
            except (ValueError, SyntaxError) as e:
                logger.error(f"Error parsing config output: {str(e)}")
                logger.error(f"Raw output was: {result.stdout}")
                return {}

        except subprocess.CalledProcessError as e:
            logger.error(f"Error executing get_config for {service}: {str(e)}")
            logger.error(f"stderr: {e.stderr}")
            return {}
        except Exception as e:
            logger.error(f"Error in call_get_config_vyos for {service}: {str(e)}")
            return {}

    def call_verify_vyos(self, service: str, config: Dict[str, Any]) -> str:
        """
        Verify config from VyOS using subprocess to execute the config script
        Returns a string indicating the result of the verification
        """
        try:
            file_path = linux_root_path + location[service]
            if not os.path.exists(file_path):
                logger.error(f"Service {service} not found at {file_path}")
                return {}

            module_name = os.path.splitext(os.path.basename(file_path))[0]
            python_cmd = f"import sys, importlib; sys.path.append('{os.path.dirname(file_path)}'); m = importlib.import_module('{module_name}'); print(m.verify({config}))"

            result = subprocess.run(
                ["sudo", "/usr/bin/python3", "-c", python_cmd],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()

        except subprocess.CalledProcessError as e:
            stderr = e.stderr.strip()
            error_msg = extract_config_error_message(stderr) or stderr
            # logger.error(f"Error executing verify for {service}: {error_msg}")
            return error_msg
