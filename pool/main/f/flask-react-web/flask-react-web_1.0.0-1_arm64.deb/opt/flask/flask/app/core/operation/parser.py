from app.core.operation.ethernet.parser import parse_to_ethernet_config
from app.core.operation.wifi.parser import parse_to_wifi_config


def parse_to_interface_config(intf_type: str, data: dict, current_config: dict = None):
    if intf_type == "ethernet":
        return parse_to_ethernet_config(data)
    elif intf_type == "wireless":
        return parse_to_wifi_config(data, current_config)
    else:
        return data

def parse_interface_config(data: dict):

    return data


def parse_all_interface_config(data: dict):
    print("parse_all_interface_config")
    print(data)

    def _normalize_status(config: dict):
        if not isinstance(config, dict):
            return 'unknown'
        return 'disabled' if 'disable' in config else 'enabled'

    def _normalize_addresses(address_value):
        if address_value in [None, '', {}]:
            return []

        if isinstance(address_value, dict):
            if all(isinstance(key, str) for key in address_value.keys()):
                return [str(key) for key in address_value.keys() if str(key).strip()]
            return []

        if isinstance(address_value, list):
            return [str(item) for item in address_value if item not in [None, '']]

        return [str(address_value)]

    def _append_interface_record(records: list, interface: str, interface_type: str, config: dict = None, ip_address=None, mac_address=None):
        if not interface:
            return

        iface_config = config if isinstance(config, dict) else {}
        normalized_ip = _normalize_addresses(ip_address if ip_address is not None else iface_config.get('address'))
        normalized_mac = mac_address if mac_address is not None else iface_config.get('hw-id') or iface_config.get('mac')
        mtu_value = iface_config.get('mtu')
        mtu = None if mtu_value in [None, '', {}] else str(mtu_value)
        speed_value = iface_config.get('speed')
        speed = None if speed_value in [None, '', {}] else str(speed_value)
        duplex_value = iface_config.get('duplex')
        duplex = None if duplex_value in [None, '', {}] else str(duplex_value)

        records.append({
            'interface': interface,
            'interface_type': interface_type,
            'status': _normalize_status(iface_config),
            'ip_address': normalized_ip,
            'mac_address': normalized_mac,
            'mtu': mtu,
            'speed': speed,
            'duplex': duplex
        })

    if not isinstance(data, dict):
        return []

    records = []

    interfaces = data.get('interfaces') if isinstance(data.get('interfaces'), dict) else data
    interfaces = interfaces if isinstance(interfaces, dict) else {}

    ethernet_cfg = interfaces.get('ethernet', {})
    if isinstance(ethernet_cfg, dict):
        for interface, config in ethernet_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'ethernet', config)

            vif_cfg = config.get('vif', {}) if isinstance(config, dict) else {}
            if isinstance(vif_cfg, dict):
                for vlan_id, vlan_config in vif_cfg.items():
                    if isinstance(vlan_config, dict):
                        _append_interface_record(records, f'{interface}.{vlan_id}', 'ethernet', vlan_config)

    bridge_cfg = interfaces.get('bridge', {})
    if isinstance(bridge_cfg, dict):
        for interface, config in bridge_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'bridge', config)

    wifi_cfg = interfaces.get('wireless', {})
    if isinstance(wifi_cfg, dict):
        for interface, config in wifi_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'wifi', config)

    wwan_cfg = interfaces.get('wwan', {})
    if isinstance(wwan_cfg, dict):
        for interface, config in wwan_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'cellular', config)

    wireguard_cfg = interfaces.get('wireguard', {})
    if isinstance(wireguard_cfg, dict):
        for interface, config in wireguard_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'wireguard', config)

    openvpn_cfg = interfaces.get('openvpn', {})
    if isinstance(openvpn_cfg, dict):
        for interface, config in openvpn_cfg.items():
            if isinstance(config, dict):
                local_address = None
                if config.get('mode') == 'site-to-site':
                    local_address = config.get('local-address')
                    if isinstance(local_address, dict):
                        local_address = list(local_address.keys())
                _append_interface_record(records, interface, 'openvpn', config, ip_address=local_address)

    tunnel_cfg = interfaces.get('tunnel', {})
    if isinstance(tunnel_cfg, dict):
        for interface, config in tunnel_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'iptunnel', config)

    l2tpv3_cfg = interfaces.get('l2tpv3', {})
    if isinstance(l2tpv3_cfg, dict):
        for interface, config in l2tpv3_cfg.items():
            if isinstance(config, dict):
                _append_interface_record(records, interface, 'l2tpv3', config)

    vpn_cfg = data.get('vpn', {}) if isinstance(data.get('vpn'), dict) else {}
    ipsec_cfg = vpn_cfg.get('ipsec') if isinstance(vpn_cfg, dict) else None
    if isinstance(ipsec_cfg, dict):
        bound_interfaces = ipsec_cfg.get('interface', [])
        if not isinstance(bound_interfaces, list):
            bound_interfaces = [bound_interfaces] if bound_interfaces not in [None, ''] else []

        if bound_interfaces:
            for interface in bound_interfaces:
                if interface:
                    _append_interface_record(records, str(interface), 'ipsec', ipsec_cfg)
        else:
            _append_interface_record(records, 'ipsec', 'ipsec', ipsec_cfg)

    direct_ipsec_cfg = data.get('ipsec') if isinstance(data.get('ipsec'), dict) else None
    if isinstance(direct_ipsec_cfg, dict) and not ipsec_cfg:
        bound_interfaces = direct_ipsec_cfg.get('interface', [])
        if not isinstance(bound_interfaces, list):
            bound_interfaces = [bound_interfaces] if bound_interfaces not in [None, ''] else []

        if bound_interfaces:
            for interface in bound_interfaces:
                if interface:
                    _append_interface_record(records, str(interface), 'ipsec', direct_ipsec_cfg)
        else:
            _append_interface_record(records, 'ipsec', 'ipsec', direct_ipsec_cfg)

    return records


def parse_to_system_config(data: dict):
    system_config = {
        "wireless": {}
    }
    if data.get("countryCode", None):
        system_config['wireless']['country_code'] = data.get("countryCode")

    return system_config

def parse_system(data: dict):
    system_config = {
        "wireless": {}
    }
    if not data or not isinstance(data, dict):
        return system_config
    if data.get("country-code", None):
        system_config['wireless']['country_code'] = data.get("country-code")

    return system_config

def parse_ca_certificate_config(data: dict):
    
    ca_certificates = []
    for ca_name, ca_data in data.items():
        ca_data = ca_data if isinstance(ca_data, dict) else {}
        crls = ca_data.get('crl') or []
        if isinstance(crls, str):
            crls = [crls]
        ca_cert_obj = {
            'name': ca_name,
            'certificate': ca_data.get('certificate', ''),
            'private_key': ca_data.get('private', {}).get('key', '') if isinstance(ca_data.get('private'), dict) else '',
            'crl': crls,
            'description': ca_data.get('description') or '',
            'revoke': 'revoke' in ca_data,
            'system_install': 'system-install' in ca_data or 'system_install' in ca_data
        }
        ca_certificates.append(ca_cert_obj)
    return ca_certificates

def parse_certificate_config(data: dict):
    certificates = []
    for cert_name, cert_data in data.items():
        cert_data = cert_data if isinstance(cert_data, dict) else {}
        acme = {key.replace('-', '_'): value for key, value in cert_data['acme'].items()} if isinstance(cert_data.get('acme'), dict) else None
        if acme and isinstance(acme.get('domain_name'), list):
            acme['domain_name'] = acme['domain_name'][0] if acme['domain_name'] else ''
        cert_obj = {
            'name': cert_name,
            'certificate': cert_data.get('certificate', ''),
            'private_key': cert_data.get('private', {}).get('key', '') if isinstance(cert_data.get('private'), dict) else '',
            'description': cert_data.get('description') or '',
            'revoke': 'revoke' in cert_data,
            'acme': acme
        }
        certificates.append(cert_obj)
    return certificates


def parse_keypair_config(data: dict):
    keypairs = []
    for name, keypair_data in data.items():
        if isinstance(keypair_data, dict):
            cert_obj = {
                'name': name,
                'private_key': keypair_data.get('private', {}).get('key', '') if isinstance(keypair_data.get('private'), dict) else '',
                'public_key': keypair_data.get('public', {}).get('key', '') if isinstance(keypair_data.get('public'), dict) else ''
            }
        else:
            cert_obj = {
                'name': name,
                'public_key': '',
                'private_key': ''
            }
        keypairs.append(cert_obj)
    return keypairs


def parse_openssh_config(data: dict):
    keys = []
    for name, key_data in data.items():
        if isinstance(key_data, dict):
            private = key_data.get('private', {})
            public = key_data.get('public', {})
            keys.append({
                'name': name,
                'private_key': private.get('key', '') if isinstance(private, dict) else '',
                'public_key': public.get('key', '') if isinstance(public, dict) else '',
                'public_key_type': public.get('type', '') if isinstance(public, dict) else '',
            })
        else:
            keys.append({
                'name': name,
                'private_key': '',
                'public_key': '',
                'public_key_type': '',
            })
    return keys


def parse_openvpn_shared_secret_key(data: dict):
    import pprint
    if not data:
        return []
    if 'shared-secret' not in data:
        return []
    shared_secret = data['shared-secret']
    openvpn_shared_secret_keys = []
    for ssk_name, ssk_data in shared_secret.items():
        if isinstance(ssk_data, dict):
            ssk_obj = {
                'name': ssk_name,
                'key': ssk_data.get('key', ''),
                'version': ssk_data.get('version', '1')
            }
            openvpn_shared_secret_keys.append(ssk_obj)
    print("OpenVPN Shared Secret Key Config: ")
    print(pprint.pformat(openvpn_shared_secret_keys, indent=2, width=80))
    return openvpn_shared_secret_keys


def parse_dh_config(data: dict):
    import pprint
    if not data or not isinstance(data, dict):
        return []

    dh_items = []
    for dh_name, dh_data in data.items():
        if not isinstance(dh_data, dict):
            continue
        dh_items.append({
            'name': dh_name,
            'parameters': dh_data.get('parameters', '')
        })

    print("DH Config: ")
    print(pprint.pformat(dh_items, indent=2, width=80))
    return dh_items


def parse_system_log(data):
    return data
