from app.core.api.http.cmd.command import Command
import json
import shlex

def has_value(value):
    return value is not None and str(value).strip() not in ["", "None", "null", "NaN", "nan"]


class WanLoadBalancingCommand(Command):
    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get("operator", "set"), resource=kwargs.get("resource", "wan-load-balancing"))
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        command = {
            "op": self.operator,
            "path": list(path_elements)
        }
        return json.dumps(command)

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(" ".join(shlex.quote(str(arg)) for arg in args))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data:
            return []

        if "interface-health" in data:
            self._process_interface_health(data["interface-health"], new_config or {})
        if "rule" in data:
            self._process_rules(data["rule"], new_config or {})

        base_path = ["load-balancing", "wan"]
        for key in ("disable-source-nat", "enable-local-traffic", "flush-connections"):
            if key in data:
                self.generate(*base_path, key)

        if "sticky-connections" in data:
            sticky = data.get("sticky-connections") or {}
            if self.operator == "delete":
                self.generate(*base_path, "sticky-connections")
            elif "inbound" in sticky:
                self.generate(*base_path, "sticky-connections", "inbound")

        return self.cmds

    def _process_interface_health(self, data, new_config):
        new_items = new_config.get("interface-health") or {}
        for name, cfg in data.items():
            base_path = ["load-balancing", "wan", "interface-health", name]
            if self.operator == "delete" and name not in new_items:
                self.generate(*base_path)
                continue

            if has_value(cfg.get("nexthop")):
                self.generate(*base_path, "nexthop", str(cfg["nexthop"]))
            if has_value(cfg.get("failure-count")):
                self.generate(*base_path, "failure-count", str(cfg["failure-count"]))
            if has_value(cfg.get("success-count")):
                self.generate(*base_path, "success-count", str(cfg["success-count"]))

            new_tests = (new_items.get(name) or {}).get("test") or {}
            for test_number, test_cfg in (cfg.get("test") or {}).items():
                test_path = base_path + ["test", str(test_number)]
                if self.operator == "delete" and str(test_number) not in new_tests:
                    self.generate(*test_path)
                    continue
                if has_value(test_cfg.get("resp-time")):
                    self.generate(*test_path, "resp-time", str(test_cfg["resp-time"]))
                if has_value(test_cfg.get("target")):
                    self.generate(*test_path, "target", str(test_cfg["target"]))
                if has_value(test_cfg.get("ttl-limit")):
                    self.generate(*test_path, "ttl-limit", str(test_cfg["ttl-limit"]))
                if has_value(test_cfg.get("type")):
                    self.generate(*test_path, "type", str(test_cfg["type"]))
                if has_value(test_cfg.get("test-script")):
                    self.generate(*test_path, "test-script", str(test_cfg["test-script"]))

    def _process_rules(self, data, new_config):
        new_rules = new_config.get("rule") or {}
        for rule_number, cfg in data.items():
            base_path = ["load-balancing", "wan", "rule", str(rule_number)]
            if self.operator == "delete" and str(rule_number) not in new_rules:
                self.generate(*base_path)
                continue

            if has_value(cfg.get("description")):
                self.generate(*base_path, "description", str(cfg["description"]))
            if has_value(cfg.get("inbound-interface")):
                self.generate(*base_path, "inbound-interface", str(cfg["inbound-interface"]))

            new_interfaces = (new_rules.get(str(rule_number)) or {}).get("interface") or {}
            for name, intf_cfg in (cfg.get("interface") or {}).items():
                intf_path = base_path + ["interface", name]
                if self.operator == "delete" and name not in new_interfaces:
                    self.generate(*intf_path)
                    continue
                self.generate(*intf_path)
                if has_value(intf_cfg.get("weight")):
                    self.generate(*intf_path, "weight", str(intf_cfg["weight"]))

            for key in ("exclude", "failover", "per-packet-balancing"):
                if key in cfg:
                    self.generate(*base_path, key)

            if has_value(cfg.get("protocol")):
                self.generate(*base_path, "protocol", str(cfg["protocol"]))

            for endpoint in ("source", "destination"):
                endpoint_cfg = cfg.get(endpoint) or {}
                if has_value(endpoint_cfg.get("address")):
                    self.generate(*base_path, endpoint, "address", str(endpoint_cfg["address"]))
                if has_value(endpoint_cfg.get("port")):
                    self.generate(*base_path, endpoint, "port", str(endpoint_cfg["port"]))
