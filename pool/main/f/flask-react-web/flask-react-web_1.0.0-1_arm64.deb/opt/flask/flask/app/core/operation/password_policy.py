from copy import deepcopy

from pydantic import BaseModel, Field


class PasswordPolicyDTO(BaseModel):
    enabled: bool = False
    min_len: int = Field(default=9, ge=9, le=20)
    min_digits: int = Field(default=1, ge=1, le=8)
    min_uppercase: int = Field(default=1, ge=1, le=8)
    min_special: int = Field(default=1, ge=1, le=8)


POLICY_FIELDS = {
    'min_len': ('minimum-length', 9),
    'min_digits': ('minimum-digit', 1),
    'min_uppercase': ('minimum-uppercase', 1),
    'min_special': ('minimum-special', 1),
}


def parse_password_policy(login_config):
    """Read the device and legacy spellings from a cached login config."""
    login = login_config or {}
    if isinstance(login.get('system'), dict):
        login = login['system'].get('login', {})
    elif isinstance(login.get('login'), dict):
        login = login['login']
    enhanced = login.get('enhanced-policy', login.get('enhanced_policy', {}))
    password = enhanced.get('password') if isinstance(enhanced, dict) else None
    policy = {'enabled': isinstance(password, dict)}
    password = password if isinstance(password, dict) else {}
    for field, (cli_name, default) in POLICY_FIELDS.items():
        aliases = (cli_name, cli_name.replace('-', '_'), field.replace('_', '-'), field)
        policy[field] = next(
            (int(password[key]) for key in aliases if key in password), default
        )
    return policy


def apply_password_policy(login_config, policy):
    """Configure enhanced policy, removing its whole block when disabled."""
    updated = deepcopy(login_config or {})
    enhanced = updated.pop('enhanced-policy', updated.pop('enhanced_policy', {}))
    if not policy['enabled']:
        return updated
    if not isinstance(enhanced, dict):
        enhanced = {}
    enhanced['password'] = {
        cli_name: policy.get(field, default)
        for field, (cli_name, default) in POLICY_FIELDS.items()
    }
    updated['enhanced-policy'] = enhanced
    return updated
