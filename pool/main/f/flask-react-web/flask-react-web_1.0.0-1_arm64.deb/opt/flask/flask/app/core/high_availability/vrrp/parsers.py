import pprint
import re
from app.core.high_availability.vrrp.models import VRRPConfig
from app.db.database import db
from app.log.logger import logger

def has_value(value):
    return value is not None and str(value).strip() not in ['', 'None', 'null', 'NaN', 'nan']

def _parse_garp_to_vyos_config(data):
    garp_config = {}

    if has_value(data.get('interval')):
        garp_config['interval'] = str(data['interval'])
        
    if has_value(data.get('delay')):
        garp_config['master-delay'] = str(data['delay'])

    if has_value(data.get('masterRefresh')):
        garp_config['master-refresh'] = str(data['masterRefresh'])

    if has_value(data.get('masterRefreshRepeat')):
        garp_config['master-refresh-repeat'] = str(data['masterRefreshRepeat'])

    if has_value(data.get('masterRepeat')):
        garp_config['master-repeat'] = str(data['masterRepeat'])

    return garp_config

def _parse_health_check_to_vyos_config(data):
    health_config = {}

    if has_value(data.get('failureCount')):
        health_config['failure-count'] = str(data['failureCount'])
    
    if has_value(data.get('interval')):
        health_config['interval'] = str(data['interval'])

    if data.get('pingTarget'):
        health_config['ping'] = data['pingTarget']

    return health_config

def _parse_group_to_vyos_config(data):
    groups = {}
    #logger.debug(data)
    for group in data['group']:
        group_config = {}

        if group.get('VRRPGeneral'):
            general = group['VRRPGeneral']

            group_name = general.get('groupName')
            if not group_name:
                continue  # skip if no group name

            if general.get('description'):
                group_config['description'] = general['description']

            if general.get('enable') == False:
                group_config['disable'] = {}
                
            if general.get('address'):
                address_list = general['address']
                if isinstance(address_list, list):
                    # Filter out empty strings
                    filtered_addresses = [addr for addr in address_list if addr and addr.strip()]
                    if filtered_addresses:
                        group_config['address'] = {addr: {} for addr in filtered_addresses}
                else:
                    if address_list and str(address_list).strip():
                        group_config['address'] = {address_list: {}}
                    
            if general.get('interface'):
                group_config['interface'] = general['interface']

            if general.get('VRID'):
                group_config['vrid'] = str(general['VRID'])
            
            if group.get('VRRPAdvancedConfig'):
                advanced = group['VRRPAdvancedConfig']

                if has_value(advanced.get('advertiseInterval')):
                    group_config['advertise-interval'] = str(advanced['advertiseInterval'])

                if advanced.get('authenticationPassword'):
                    group_config['authentication'] = {
                            'password': advanced['authenticationPassword'],
                            'type': 'plaintext-password'
                            
                        }
                if advanced.get('excludedAddresses'):
                    exclude_address_list = advanced['excludedAddresses']

                    if isinstance(exclude_address_list, list):
                        group_config['excluded-address'] = {addr: {} for addr in exclude_address_list}
                    else:
                        group_config['excluded-address'] = {exclude_address_list: {}}

                if advanced.get('disableMaster') == True:
                    group_config['no-preempt'] = {}

                if advanced.get('peerAddress'):
                    group_config['peer-address'] = advanced['peerAddress']
                
                if has_value(advanced.get('delay')):
                    group_config['preempt-delay'] = str(advanced['delay'])
                
                if has_value(advanced.get('priority')):
                    group_config['priority'] = str(advanced['priority'])
                
                if advanced.get('RFC3768Compatibility') == True:
                    group_config['rfc3768-compatibility'] = {}

                if advanced.get('GARP'):
                    group_config['garp']= _parse_garp_to_vyos_config(advanced['GARP'])
                
                if advanced.get('healthCheck'):
                    if advanced.get('healthCheck').get('isHealthCheckEnabled') == True:
                        logger.debug("Health Check is enabled")
                        group_config['health-check'] = _parse_health_check_to_vyos_config(advanced['healthCheck'])
                    else:
                        group_config['health-check'] = {}
                        logger.debug("Health Check is disabled")
                if advanced.get('track'):
                    track = advanced['track']
                    track_config = {}
                    if track.get('isTrackEnabled') == True:
                        print("Track is enabled")
                        if track.get('excludeVRRP') == True:
                            track_config['exclude-vrrp-interface'] = {}
                        
                        if track.get('interface'):
                            iface = track.get('interface') or []

                            # Normalize to list[str]
                            if isinstance(iface, str):
                                iface = [iface] if iface.strip() else []
                            elif not isinstance(iface, list):
                                iface = []

                            iface = [i.strip() for i in iface if isinstance(i, str) and i.strip()]

                            track_config['interface'] = iface
                   
                    if track_config:
                        group_config['track'] = track_config

            groups[group_name] = group_config

    return groups

def _parse_sync_group_to_vyos_config(data):
    sync_groups = {}

    for group in data['syncGroup']:
        sync_group_config = {}
        
        group_name = group.get('groupName')
        
        if not group_name:
            continue

        if group.get('member'):
            member_list = group['member']
            sync_group_config['member'] = member_list  # list[str]

        if group.get('healthCheck'):
            sync_group_config['health-check'] = _parse_health_check_to_vyos_config(group['healthCheck'])

        sync_groups[group_name] = sync_group_config
    return sync_groups


def parse_to_vyos_config(data):
    vyos_config = {}
    print("Parsing data for verify:")
    
    print(data)
    if 'globalParameters' in data:
        params = data['globalParameters']
        globalparameters = {}
        if has_value(data['globalParameters'].get('delay')):
            globalparameters['startup-delay'] = str(params['delay'])
        
        if has_value(data['globalParameters'].get('version')):
            globalparameters['version'] = str(params['version'])

       
        if data.get('globalParameters', {}).get('enableSNMP'):
            print("SNMP enabled")
            vyos_config['snmp'] = {}

        if data['globalParameters'].get('GARP'):
            garp_config = _parse_garp_to_vyos_config(params['GARP'])
            if garp_config:
                globalparameters['garp'] = garp_config
    
        if globalparameters:
            vyos_config['global-parameters'] = globalparameters

    if 'connection' in data:
        connection = data['connection']
        if 'group' in connection and connection['group']:
            groups = _parse_group_to_vyos_config(connection)
            if groups:
                vyos_config['group'] = groups
        if 'syncGroup' in connection and connection['syncGroup']:
            sync_groups = _parse_sync_group_to_vyos_config(connection)
            if sync_groups:
                vyos_config['sync-group'] = sync_groups
    
    return vyos_config


def parse_to_vyos_config_verify(data):
    verify_type = data.get('verify_type')
    if verify_type == 'group':
       return {"vrrp": {"group": _parse_group_to_vyos_config(data)}}

    elif verify_type == 'sync-group':
        return {"vrrp": {"sync_group": parse_to_vyos_config(data)}}
    return {}

def parse_vrrp_stats(data):
    print("vrrp statistics:")
    print(pprint.pformat(data, indent=2))
    if 'ShowStatisticsVrrpQuery' in data and 'data' in data['ShowStatisticsVrrpQuery'] and \
        'result' in data['ShowStatisticsVrrpQuery']['data']:
        return data['ShowStatisticsVrrpQuery']['data']['result']
    return []

def parse_vrrp_details(data):
    print("vrrp details:")
    print(pprint.pformat(data, indent=2))
    if 'ShowDetailVrrpQuery' in data and 'data' in data['ShowDetailVrrpQuery'] and \
        'result' in data['ShowDetailVrrpQuery']['data']:
        return data['ShowDetailVrrpQuery']['data']['result']
    return []


def parse_vrrp_summary(data):
    print("vrrp summary:")
    print(pprint.pformat(data, indent=2))
    if 'ShowSummaryVrrpQuery' in data and 'data' in data['ShowSummaryVrrpQuery'] and \
        'result' in data['ShowSummaryVrrpQuery']['data']:
        return data['ShowSummaryVrrpQuery']['data']['result']
    return []

if __name__ == '__main__':

    test_input = {
            "connection": {  
                "group": [
                {
                    "VRRPGeneral": {
                        "groupName": "test",
                        "description": "test description",
                        "enable": True,
                        "address": [
                            "10.10.10.10",
                            "20.20.20.20"
                        ],
                        "interface": "eth0",
                        "VRID": 70
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 60,
                        "authenticationPassword": "password",
                        "excludedAddresses": [
                            "20.20.20.20",
                            "30.30.30.30"
                        ],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 90,
                        "priority": 78,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 40,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 200,
                            "masterRepeat": 5
                        },
                        "track": {
                            "excludeVRRP": True,
                            "interface": ["eth0"]
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test2",
                        "description": "",
                        "enable": True,
                        "address": [
                            "192.0.2.1"
                        ],
                        "interface": "eth0",
                        "VRID": 79
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "5.5.5.5",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "track": {
                            "excludeVRRP": False,
                            "interface": ["br1","br2"]
                        }
                    }
                },
                {
                    "VRRPGeneral": {
                        "groupName": "test3",
                        "description": "asdasd",
                        "enable": True,
                        "address": [
                            "30.30.30.30"
                        ],
                        "interface": "br2",
                        "VRID": 1
                    },
                    "VRRPAdvancedConfig": {
                        "advertiseInterval": 1,
                        "authenticationPassword": "",
                        "excludedAddresses": [],
                        "disableMaster": True,
                        "peerAddress": "",
                        "delay": 0,
                        "priority": 0,
                        "RFC3768Compatibility": False,
                        "GARP": {
                            "interval": 0,
                            "delay": 5,
                            "masterRefresh": 5,
                            "masterRefreshRepeat": 1,
                            "masterRepeat": 5
                        },
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": ""
                        },
                        "track": {
                            "excludeVRRP": False,
                            "interface": ["eth1"]
                        }
                    }
                }
                ],
                "syncGroup": 
                [
                    {
                        "groupName": "test",
                        "member": [],
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "3.3.3.3"
                        }
                    },
                    {
                        "groupName": "test2",
                        "member": [
                            "test2",
                            "test"
                        ],
                        "healthCheck": {
                            "failureCount": 3,
                            "interval": 60,
                            "pingTarget": "5.5.5.5"
                        }
                    }
                ]

            },
            "globalParameters": {
                "delay": 5,
                "version": 2,
                "enableSNMP": True,
                "GARP": {
                    "interval": 100,
                    "masterDelay": 50,
                    "masterRefresh": 5,
                    "masterRefreshRepeat": 1,
                    "masterRepeat": 200
                }
            }
        }
    

    result = parse_to_vyos_config(test_input)
    print("Parsed Result:")
