import json
import re
from typing import Annotated, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr, field_validator, model_validator
from app.db.database import db
from app.core.operation.serial.validation import (
    AddressText, HexText, HostText, UidRangeText, IPv4InterfaceText, IPv6InterfaceText,
    PppRemoteAddressText, PppIpv6IdentifierText, integer_text, validate_name,
)


class SerialDTO(BaseModel):
    model_config = ConfigDict(extra='forbid')

    @field_validator('*', mode='before')
    @classmethod
    def reject_control_characters(cls, value):
        if isinstance(value, str) and any(character in value for character in ('\x00', '\n', '\r')):
            raise ValueError('Control characters are not allowed')
        return value


class SerialGlobalConfigModbusGatewayTlsDTO(SerialDTO):
    template: Optional[StrictStr] = Field(default=None, alias='template')


class SerialGlobalConfigModbusGatewayDTO(SerialDTO):
    allow_broadcast: Optional[StrictBool] = Field(default=None, alias='allow-broadcast')
    character_timeout: Optional[integer_text(10, 10000, ())] = Field(default=None, alias='character-timeout')
    disable_exceptions: Optional[StrictBool] = Field(default=None, alias='disable-exceptions')
    disable_queuing: Optional[StrictBool] = Field(default=None, alias='disable-queuing')
    idle_timeout: Optional[integer_text(0, 300, ())] = Field(default=None, alias='idle-timeout')
    message_timeout: Optional[integer_text(10, 10000, ())] = Field(default=None, alias='message-timeout')
    next_request_delay: Optional[integer_text(0, 1000, ())] = Field(default=None, alias='next-request-delay')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')


class SerialGlobalConfigProcessBreakDTO(SerialDTO):
    ssh_string: Optional[Annotated[StrictStr, Field(max_length=8)]] = Field(default=None, alias='ssh-string')


class SerialGlobalConfigSshTelnetServerLoggingLocalDTO(SerialDTO):
    view_string: Optional[Annotated[StrictStr, Field(max_length=8)]] = Field(default=None, alias='view-string')


class SerialGlobalConfigSshTelnetServerLoggingNfsServerDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    directory: Optional[Annotated[StrictStr, Field(max_length=40)]] = Field(default=None, alias='directory')


class SerialGlobalConfigSshTelnetServerLoggingNfsDTO(SerialDTO):
    server: Optional[SerialGlobalConfigSshTelnetServerLoggingNfsServerDTO] = Field(default=None, alias='server')


class SerialGlobalConfigSshTelnetServerLoggingSyslogDTO(SerialDTO):
    level: Optional[Literal['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug']] = Field(default=None, alias='level')


class SerialGlobalConfigSshTelnetServerLoggingDTO(SerialDTO):
    keystroke_logging: Optional[StrictBool] = Field(default=None, alias='keystroke-logging')
    local: Optional[SerialGlobalConfigSshTelnetServerLoggingLocalDTO] = Field(default=None, alias='local')
    nfs: Optional[SerialGlobalConfigSshTelnetServerLoggingNfsDTO] = Field(default=None, alias='nfs')
    syslog: Optional[SerialGlobalConfigSshTelnetServerLoggingSyslogDTO] = Field(default=None, alias='syslog')
    timestamping: Optional[StrictBool] = Field(default=None, alias='timestamping')


class SerialGlobalConfigTcpKeepAliveDTO(SerialDTO):
    interval: Optional[integer_text(1, 32767, ())] = Field(default=None, alias='interval')
    retry: Optional[integer_text(1, 32767, ())] = Field(default=None, alias='retry')
    retry_timeout: Optional[integer_text(1, 32767, ())] = Field(default=None, alias='retry-timeout')


class SerialGlobalConfigTlsTemplateCipherOptionsDTO(SerialDTO):
    encryption: Optional[Literal['any', 'aes', 'aes-gcm']] = Field(default=None, alias='encryption')
    hmac: Optional[Literal['any', 'sha1', 'md5', 'sha256', 'sha384']] = Field(default=None, alias='hmac')
    key_exchange: Optional[Literal['any', 'rsa', 'edh-rsa', 'edh-dss', 'adh', 'ecdh-ecdsa']] = Field(default=None, alias='key-exchange')
    max_key_size: Optional[Literal['40', '56', '64', '128', '168', '256']] = Field(default=None, alias='max-key-size')
    min_key_size: Optional[Literal['40', '56', '64', '128', '168', '256']] = Field(default=None, alias='min-key-size')


class SerialGlobalConfigTlsTemplatePeerVerificationDTO(SerialDTO):
    common_name: Optional[StrictStr] = Field(default=None, alias='common-name')
    country: Optional[StrictStr] = Field(default=None, alias='country')
    email: Optional[StrictStr] = Field(default=None, alias='email')
    locality: Optional[StrictStr] = Field(default=None, alias='locality')
    organization: Optional[StrictStr] = Field(default=None, alias='organization')
    organization_unit: Optional[StrictStr] = Field(default=None, alias='organization-unit')
    state: Optional[StrictStr] = Field(default=None, alias='state')


class SerialGlobalConfigTlsTemplateDTO(SerialDTO):
    certificate: Optional[StrictStr] = Field(default=None, alias='certificate')
    cipher_options: Optional[Dict[StrictStr, SerialGlobalConfigTlsTemplateCipherOptionsDTO]] = Field(default=None, alias='cipher-options')
    passphrase: Optional[Annotated[StrictStr, Field(max_length=16)]] = Field(default=None, alias='passphrase')
    peer_verification: Optional[SerialGlobalConfigTlsTemplatePeerVerificationDTO] = Field(default=None, alias='peer-verification')
    role: Optional[Literal['client', 'server']] = Field(default=None, alias='role')
    version: Optional[Literal['any', 'tlsv1.2', 'tlsv1.2b', 'tlsv1.3']] = Field(default=None, alias='version')

    @field_validator('cipher_options')
    @classmethod
    def validate_cipher_options(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 5)
        return entries


class SerialGlobalConfigTlsDTO(SerialDTO):
    template: Optional[Dict[StrictStr, SerialGlobalConfigTlsTemplateDTO]] = Field(default=None, alias='template')

    @field_validator('template')
    @classmethod
    def validate_template(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name)
        return entries


class SerialBaudRemapDTO(SerialDTO):
    remap: Optional[integer_text(300, 1843200, ())] = Field(default=None, alias='remap')


class SerialGlobalConfigTrueportSpeedDTO(SerialDTO):
    baud_110: Optional[SerialBaudRemapDTO] = Field(default=None, alias='110')
    baud_1200: Optional[SerialBaudRemapDTO] = Field(default=None, alias='1200')
    baud_134: Optional[SerialBaudRemapDTO] = Field(default=None, alias='134')
    baud_150: Optional[SerialBaudRemapDTO] = Field(default=None, alias='150')
    baud_1800: Optional[SerialBaudRemapDTO] = Field(default=None, alias='1800')
    baud_19200: Optional[SerialBaudRemapDTO] = Field(default=None, alias='19200')
    baud_200: Optional[SerialBaudRemapDTO] = Field(default=None, alias='200')
    baud_2400: Optional[SerialBaudRemapDTO] = Field(default=None, alias='2400')
    baud_300: Optional[SerialBaudRemapDTO] = Field(default=None, alias='300')
    baud_38400: Optional[SerialBaudRemapDTO] = Field(default=None, alias='38400')
    baud_4800: Optional[SerialBaudRemapDTO] = Field(default=None, alias='4800')
    baud_50: Optional[SerialBaudRemapDTO] = Field(default=None, alias='50')
    baud_600: Optional[SerialBaudRemapDTO] = Field(default=None, alias='600')
    baud_75: Optional[SerialBaudRemapDTO] = Field(default=None, alias='75')
    baud_9600: Optional[SerialBaudRemapDTO] = Field(default=None, alias='9600')


class SerialGlobalConfigTrueportDTO(SerialDTO):
    speed: Optional[SerialGlobalConfigTrueportSpeedDTO] = Field(default=None, alias='speed')


class SerialGlobalConfigVirtualModemDirectoryEntryDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    phone_number: Optional[Annotated[StrictStr, Field(max_length=31)]] = Field(default=None, alias='phone-number')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialGlobalConfigVirtualModemDTO(SerialDTO):
    directory_entry: Optional[Dict[StrictStr, SerialGlobalConfigVirtualModemDirectoryEntryDTO]] = Field(default=None, alias='directory-entry')

    @field_validator('directory_entry')
    @classmethod
    def validate_directory_entry(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 8)
        return entries


class SerialGlobalConfigDTO(SerialDTO):
    flush_on_close: Optional[StrictBool] = Field(default=None, alias='flush-on-close')
    modbus_gateway: Optional[SerialGlobalConfigModbusGatewayDTO] = Field(default=None, alias='modbus-gateway')
    process_break: Optional[SerialGlobalConfigProcessBreakDTO] = Field(default=None, alias='process-break')
    ssh_telnet_server_logging: Optional[SerialGlobalConfigSshTelnetServerLoggingDTO] = Field(default=None, alias='ssh-telnet-server-logging')
    tcp_keep_alive: Optional[SerialGlobalConfigTcpKeepAliveDTO] = Field(default=None, alias='tcp-keep-alive')
    tls: Optional[SerialGlobalConfigTlsDTO] = Field(default=None, alias='tls')
    trueport: Optional[SerialGlobalConfigTrueportDTO] = Field(default=None, alias='trueport')
    virtual_modem: Optional[SerialGlobalConfigVirtualModemDTO] = Field(default=None, alias='virtual-modem')

    @model_validator(mode='before')
    @classmethod
    def parse_page_values(cls, values):
        from app.core.operation.serial.form_parser import read_global
        return read_global(values)


class SerialDeviceConfigProtocolRs232RtsToggleDTO(SerialDTO):
    final_delay: Optional[integer_text(0, 1000, ())] = Field(default=None, alias='final-delay')
    initial_delay: Optional[integer_text(0, 1000, ())] = Field(default=None, alias='initial-delay')


class SerialDeviceConfigProtocolRs232DTO(SerialDTO):
    flow_control: Optional[Literal['both', 'none', 'hardware', 'software']] = Field(default=None, alias='flow-control')
    monitor_signal: Optional[List[Literal['dsr', 'dcd']]] = Field(default=None, alias='monitor-signal')
    rts_toggle: Optional[SerialDeviceConfigProtocolRs232RtsToggleDTO] = Field(default=None, alias='rts-toggle')


class SerialDeviceConfigProtocolRs422DTO(SerialDTO):
    flow_control: Optional[Literal['none', 'software']] = Field(default=None, alias='flow-control')
    disable_line_termination: Optional[StrictBool] = Field(default=None, alias='disable-line-termination')


class SerialDeviceConfigProtocolRs485FullDTO(SerialDTO):
    flow_control: Optional[Literal['none', 'software']] = Field(default=None, alias='flow-control')
    disable_line_termination: Optional[StrictBool] = Field(default=None, alias='disable-line-termination')


class SerialDeviceConfigProtocolRs485HalfDTO(SerialDTO):
    flow_control: Optional[Literal['none', 'software']] = Field(default=None, alias='flow-control')
    disable_echo_suppression: Optional[StrictBool] = Field(default=None, alias='disable-echo-suppression')
    disable_line_termination: Optional[StrictBool] = Field(default=None, alias='disable-line-termination')


class SerialDeviceConfigProtocolDTO(SerialDTO):
    rs232: Optional[SerialDeviceConfigProtocolRs232DTO] = Field(default=None, alias='rs232')
    rs422: Optional[SerialDeviceConfigProtocolRs422DTO] = Field(default=None, alias='rs422')
    rs485_full: Optional[SerialDeviceConfigProtocolRs485FullDTO] = Field(default=None, alias='rs485-full')
    rs485_half: Optional[SerialDeviceConfigProtocolRs485HalfDTO] = Field(default=None, alias='rs485-half')


class SerialDeviceConfigLoginModemDialOutDTO(SerialDTO):
    phone_number: Optional[Annotated[StrictStr, Field(max_length=31)]] = Field(default=None, alias='phone-number')
    retry: Optional[integer_text(1, 99, ())] = Field(default=None, alias='retry')
    timeout: Optional[integer_text(1, 99, ())] = Field(default=None, alias='timeout')


class SerialDeviceConfigLoginModemDialDTO(SerialDTO):
    in_: Optional[StrictBool] = Field(default=None, alias='in')
    out: Optional[SerialDeviceConfigLoginModemDialOutDTO] = Field(default=None, alias='out')


class SerialDeviceConfigLoginModemDTO(SerialDTO):
    dial: Optional[SerialDeviceConfigLoginModemDialDTO] = Field(default=None, alias='dial')
    initialization_string: Optional[Annotated[StrictStr, Field(max_length=61)]] = Field(default=None, alias='initialization-string')


class SerialDeviceConfigLoginTransmitStringDTO(SerialDTO):
    at_start: Optional[Annotated[StrictStr, Field(max_length=127)]] = Field(default=None, alias='at-start')
    delay_after_transmit: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay-after-transmit')


class SerialDeviceConfigLoginDTO(SerialDTO):
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    transmit_string: Optional[SerialDeviceConfigLoginTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigModbusGatewayMasterSlaveMappingListEntryDTO(SerialDTO):
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    protocol: Optional[Literal['tcp', 'udp']] = Field(default=None, alias='protocol')
    range_mode: Optional[Literal['host', 'gateway']] = Field(default=None, alias='range-mode')
    slave_ip: Optional[AddressText] = Field(default=None, alias='slave-ip')
    uid: Optional[UidRangeText] = Field(default=None, alias='uid')


class SerialDeviceConfigModbusGatewayMasterSlaveMappingListDTO(SerialDTO):
    entry: Optional[Dict[StrictStr, SerialDeviceConfigModbusGatewayMasterSlaveMappingListEntryDTO]] = Field(default=None, alias='entry')

    @field_validator('entry')
    @classmethod
    def validate_entry(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 16)
        return entries


class SerialDeviceConfigModbusGatewayMasterDTO(SerialDTO):
    slave_mapping_list: Optional[SerialDeviceConfigModbusGatewayMasterSlaveMappingListDTO] = Field(default=None, alias='slave-mapping-list')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')


class SerialDeviceConfigModbusGatewayProtocolAsciiDTO(SerialDTO):
    append_crlf: Optional[StrictBool] = Field(default=None, alias='append-crlf')


class SerialDeviceConfigModbusGatewayProtocolDTO(SerialDTO):
    ascii: Optional[SerialDeviceConfigModbusGatewayProtocolAsciiDTO] = Field(default=None, alias='ascii')
    rtu: Optional[StrictBool] = Field(default=None, alias='rtu')


class SerialDeviceConfigModbusGatewaySlaveRemapUidListEntryDTO(SerialDTO):
    from_: Optional[UidRangeText] = Field(default=None, alias='from')
    to: Optional[UidRangeText] = Field(default=None, alias='to')


class SerialDeviceConfigModbusGatewaySlaveRemapUidListDTO(SerialDTO):
    entry: Optional[Dict[StrictStr, SerialDeviceConfigModbusGatewaySlaveRemapUidListEntryDTO]] = Field(default=None, alias='entry')

    @field_validator('entry')
    @classmethod
    def validate_entry(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 48)
        return entries


class SerialDeviceConfigModbusGatewaySlaveDTO(SerialDTO):
    address: Optional[AddressText] = Field(default=None, alias='address')
    remap_uid_list: Optional[SerialDeviceConfigModbusGatewaySlaveRemapUidListDTO] = Field(default=None, alias='remap-uid-list')
    uid: Optional[UidRangeText] = Field(default=None, alias='uid')


class SerialDeviceConfigModbusGatewayDTO(SerialDTO):
    master: Optional[SerialDeviceConfigModbusGatewayMasterDTO] = Field(default=None, alias='master')
    protocol: Optional[SerialDeviceConfigModbusGatewayProtocolDTO] = Field(default=None, alias='protocol')
    slave: Optional[SerialDeviceConfigModbusGatewaySlaveDTO] = Field(default=None, alias='slave')


class SerialDeviceConfigNineBitsRemoteDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigNineBitsDTO(SerialDTO):
    delay: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay')
    remote: Optional[SerialDeviceConfigNineBitsRemoteDTO] = Field(default=None, alias='remote')


class SerialDeviceConfigPppModemDialBothDTO(SerialDTO):
    phone_number: Optional[Annotated[StrictStr, Field(max_length=31)]] = Field(default=None, alias='phone-number')
    retry: Optional[integer_text(1, 99, ())] = Field(default=None, alias='retry')
    timeout: Optional[integer_text(1, 99, ())] = Field(default=None, alias='timeout')


class SerialDeviceConfigPppModemDialDTO(SerialDTO):
    both: Optional[SerialDeviceConfigPppModemDialBothDTO] = Field(default=None, alias='both')
    in_: Optional[StrictBool] = Field(default=None, alias='in')
    out: Optional[SerialDeviceConfigLoginModemDialOutDTO] = Field(default=None, alias='out')


class SerialDeviceConfigPppModemDTO(SerialDTO):
    dial: Optional[SerialDeviceConfigPppModemDialDTO] = Field(default=None, alias='dial')
    initialization_string: Optional[Annotated[StrictStr, Field(max_length=61)]] = Field(default=None, alias='initialization-string')


class SerialDeviceConfigPppDTO(SerialDTO):
    modem: Optional[SerialDeviceConfigPppModemDTO] = Field(default=None, alias='modem')


class SerialDeviceConfigRemotePrinterDTO(SerialDTO):
    map_cr_to_crlf: Optional[StrictBool] = Field(default=None, alias='map-cr-to-crlf')
    transmit_string: Optional[SerialDeviceConfigLoginTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigSerialTunnelClientDTO(SerialDTO):
    remote: Optional[SerialDeviceConfigNineBitsRemoteDTO] = Field(default=None, alias='remote')


class SerialDeviceConfigSerialTunnelServerDTO(SerialDTO):
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigSerialTunnelDTO(SerialDTO):
    break_length: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='break-length')
    client: Optional[SerialDeviceConfigSerialTunnelClientDTO] = Field(default=None, alias='client')
    delay_after_break: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay-after-break')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialDeviceConfigSerialTunnelServerDTO] = Field(default=None, alias='server')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')


class SerialDeviceConfigSlipDTO(SerialDTO):
    modem: Optional[SerialDeviceConfigPppModemDTO] = Field(default=None, alias='modem')


class SerialDeviceConfigSshClientInitiateDTO(SerialDTO):
    any_character: Optional[StrictBool] = Field(default=None, alias='any-character')
    character: Optional[HexText] = Field(default=None, alias='character')


class SerialDeviceConfigSshClientDTO(SerialDTO):
    initiate: Optional[SerialDeviceConfigSshClientInitiateDTO] = Field(default=None, alias='initiate')
    login_name: Optional[Annotated[StrictStr, Field(max_length=21)]] = Field(default=None, alias='login-name')
    remote: Optional[SerialDeviceConfigNineBitsRemoteDTO] = Field(default=None, alias='remote')
    terminal_type: Optional[Annotated[StrictStr, Field(max_length=17)]] = Field(default=None, alias='terminal-type')


class SerialDeviceConfigSshServerDTO(SerialDTO):
    address: Optional[AddressText] = Field(default=None, alias='address')
    multi_session_limit: Optional[integer_text(0, 16, ())] = Field(default=None, alias='multi-session-limit')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialDeviceConfigSshTransmitStringDTO(SerialDTO):
    at_end: Optional[Annotated[StrictStr, Field(max_length=127)]] = Field(default=None, alias='at-end')
    at_start: Optional[Annotated[StrictStr, Field(max_length=127)]] = Field(default=None, alias='at-start')
    delay_after_transmit: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay-after-transmit')


class SerialDeviceConfigSshDTO(SerialDTO):
    client: Optional[SerialDeviceConfigSshClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialDeviceConfigSshServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigTcpClientRemoteBackupDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigTcpClientRemoteMultiHostEntryDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigTcpClientRemoteMultiHostDTO(SerialDTO):
    entry: Optional[Dict[StrictStr, SerialDeviceConfigTcpClientRemoteMultiHostEntryDTO]] = Field(default=None, alias='entry')

    @field_validator('entry')
    @classmethod
    def validate_entry(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 50)
        return entries


class SerialDeviceConfigTcpClientRemotePrimaryDTO(SerialDTO):
    address: Optional[HostText] = Field(default=None, alias='address')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigTcpClientRemoteDTO(SerialDTO):
    backup: Optional[SerialDeviceConfigTcpClientRemoteBackupDTO] = Field(default=None, alias='backup')
    multi_host: Optional[SerialDeviceConfigTcpClientRemoteMultiHostDTO] = Field(default=None, alias='multi-host')
    primary: Optional[SerialDeviceConfigTcpClientRemotePrimaryDTO] = Field(default=None, alias='primary')


class SerialDeviceConfigTcpClientDTO(SerialDTO):
    initiate: Optional[SerialDeviceConfigSshClientInitiateDTO] = Field(default=None, alias='initiate')
    remote: Optional[SerialDeviceConfigTcpClientRemoteDTO] = Field(default=None, alias='remote')
    send_description_on_connect: Optional[StrictBool] = Field(default=None, alias='send-description-on-connect')


class SerialDeviceConfigTcpServerDTO(SerialDTO):
    address: Optional[AddressText] = Field(default=None, alias='address')
    allow_multiple_connections: Optional[StrictBool] = Field(default=None, alias='allow-multiple-connections')
    authenticate_user: Optional[StrictBool] = Field(default=None, alias='authenticate-user')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialDeviceConfigTcpDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTcpClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    serial_buffering: Optional[StrictBool] = Field(default=None, alias='serial-buffering')
    server: Optional[SerialDeviceConfigTcpServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigTelnetClientDTO(SerialDTO):
    initiate: Optional[SerialDeviceConfigSshClientInitiateDTO] = Field(default=None, alias='initiate')
    map_cr_to_crlf: Optional[StrictBool] = Field(default=None, alias='map-cr-to-crlf')
    remote: Optional[SerialDeviceConfigNineBitsRemoteDTO] = Field(default=None, alias='remote')
    terminal_type: Optional[Annotated[StrictStr, Field(max_length=17)]] = Field(default=None, alias='terminal-type')


class SerialDeviceConfigTelnetServerDTO(SerialDTO):
    address: Optional[AddressText] = Field(default=None, alias='address')
    authenticate_user: Optional[StrictBool] = Field(default=None, alias='authenticate-user')
    multi_session_limit: Optional[integer_text(0, 16, ())] = Field(default=None, alias='multi-session-limit')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialDeviceConfigTelnetDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTelnetClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialDeviceConfigTelnetServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigTrueportClientDTO(SerialDTO):
    remote: Optional[SerialDeviceConfigTcpClientRemoteDTO] = Field(default=None, alias='remote')
    send_description_on_connect: Optional[StrictBool] = Field(default=None, alias='send-description-on-connect')


class SerialDeviceConfigTrueportServerDTO(SerialDTO):
    allow_multiple_connections: Optional[StrictBool] = Field(default=None, alias='allow-multiple-connections')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')


class SerialDeviceConfigTrueportDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTrueportClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    serial_buffering: Optional[StrictBool] = Field(default=None, alias='serial-buffering')
    server: Optional[SerialDeviceConfigTrueportServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    signal_active: Optional[StrictBool] = Field(default=None, alias='signal-active')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigUdpRuleAddressDTO(SerialDTO):
    end: Optional[AddressText] = Field(default=None, alias='end')
    start: Optional[AddressText] = Field(default=None, alias='start')


class SerialDeviceConfigUdpRuleDirectionBothDTO(SerialDTO):
    port: Optional[integer_text(1, 65535, ('auto-learn',))] = Field(default=None, alias='port')


class SerialDeviceConfigUdpRuleDirectionLanSerialDTO(SerialDTO):
    source_port: Optional[integer_text(1, 65535, ('auto-learn', 'any'))] = Field(default=None, alias='source-port')


class SerialDeviceConfigUdpRuleDirectionSerialLanDTO(SerialDTO):
    destination_port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='destination-port')


class SerialDeviceConfigUdpRuleDirectionDTO(SerialDTO):
    both: Optional[SerialDeviceConfigUdpRuleDirectionBothDTO] = Field(default=None, alias='both')
    lan_serial: Optional[SerialDeviceConfigUdpRuleDirectionLanSerialDTO] = Field(default=None, alias='lan-serial')
    serial_lan: Optional[SerialDeviceConfigUdpRuleDirectionSerialLanDTO] = Field(default=None, alias='serial-lan')


class SerialDeviceConfigUdpRuleDTO(SerialDTO):
    address: Optional[SerialDeviceConfigUdpRuleAddressDTO] = Field(default=None, alias='address')
    direction: Optional[SerialDeviceConfigUdpRuleDirectionDTO] = Field(default=None, alias='direction')


class SerialDeviceConfigUdpDTO(SerialDTO):
    multicast_interface: Optional[StrictStr] = Field(default=None, alias='multicast-interface')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    rule: Optional[Dict[StrictStr, SerialDeviceConfigUdpRuleDTO]] = Field(default=None, alias='rule')
    transmit_string: Optional[SerialDeviceConfigLoginTransmitStringDTO] = Field(default=None, alias='transmit-string')

    @field_validator('rule')
    @classmethod
    def validate_rule(cls, entries):
        if entries is not None:
            for name in entries:
                validate_name(name, 1, 10)
        return entries


class SerialDeviceConfigVirtualModemHardwareSignalsDTO(SerialDTO):
    dcd: Optional[Literal['always-on', 'on-when-host-connect']] = Field(default=None, alias='dcd')
    dtr: Optional[Literal['always-on', 'acts-as-dcd', 'acts-as-ri']] = Field(default=None, alias='dtr')
    rts: Optional[Literal['always-on', 'acts-as-dcd', 'acts-as-ri']] = Field(default=None, alias='rts')


class SerialDeviceConfigVirtualModemSendConnectStatusVerboseDTO(SerialDTO):
    failure_string: Optional[Annotated[StrictStr, Field(max_length=30)]] = Field(default=None, alias='failure-string')
    success_string: Optional[Annotated[StrictStr, Field(max_length=40)]] = Field(default=None, alias='success-string')


class SerialDeviceConfigVirtualModemSendConnectStatusDTO(SerialDTO):
    none: Optional[StrictBool] = Field(default=None, alias='none')
    numeric: Optional[StrictBool] = Field(default=None, alias='numeric')
    verbose: Optional[SerialDeviceConfigVirtualModemSendConnectStatusVerboseDTO] = Field(default=None, alias='verbose')


class SerialDeviceConfigVirtualModemDTO(SerialDTO):
    client: Optional[SerialDeviceConfigSerialTunnelClientDTO] = Field(default=None, alias='client')
    disable_echo: Optional[StrictBool] = Field(default=None, alias='disable-echo')
    hardware_signals: Optional[SerialDeviceConfigVirtualModemHardwareSignalsDTO] = Field(default=None, alias='hardware-signals')
    initialization_string: Optional[Annotated[StrictStr, Field(max_length=254)]] = Field(default=None, alias='initialization-string')
    response_delay: Optional[integer_text(0, 999, ())] = Field(default=None, alias='response-delay')
    send_connect_status: Optional[SerialDeviceConfigVirtualModemSendConnectStatusDTO] = Field(default=None, alias='send-connect-status')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialDeviceConfigSerialTunnelServerDTO] = Field(default=None, alias='server')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigLoginTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialDeviceConfigPacketForwardingPreventMessageFragmentationDTO(SerialDTO):
    delay_between_messages: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay-between-messages')


class SerialDeviceConfigPacketForwardingCustomFrameDTO(SerialDTO):
    end_value1: Optional[HexText] = Field(default=None, alias='end-value1')
    end_value2: Optional[HexText] = Field(default=None, alias='end-value2')
    start_value1: Optional[HexText] = Field(default=None, alias='start-value1')
    start_value2: Optional[HexText] = Field(default=None, alias='start-value2')
    transmit_start_characters: Optional[StrictBool] = Field(default=None, alias='transmit-start-characters')


class SerialDeviceConfigPacketForwardingCustomPacketDTO(SerialDTO):
    force_transmit_timer: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='force-transmit-timer')
    idle_timer: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='idle-timer')
    packet_size: Optional[integer_text(0, 1024, ())] = Field(default=None, alias='packet-size')
    trigger_value1: Optional[HexText] = Field(default=None, alias='trigger-value1')
    trigger_value2: Optional[HexText] = Field(default=None, alias='trigger-value2')


class SerialDeviceConfigPacketForwardingCustomDTO(SerialDTO):
    frame: Optional[SerialDeviceConfigPacketForwardingCustomFrameDTO] = Field(default=None, alias='frame')
    packet: Optional[SerialDeviceConfigPacketForwardingCustomPacketDTO] = Field(default=None, alias='packet')
    forwarding_rule: Optional[Literal['strip', 'trigger', 'trigger+1', 'trigger+2']] = Field(default=None, alias='forwarding-rule')


class SerialDeviceConfigPacketForwardingDTO(SerialDTO):
    minimize_latency: Optional[StrictBool] = Field(default=None, alias='minimize-latency')
    optimize_network_throughput: Optional[StrictBool] = Field(default=None, alias='optimize-network-throughput')
    prevent_message_fragmentation: Optional[SerialDeviceConfigPacketForwardingPreventMessageFragmentationDTO] = Field(default=None, alias='prevent-message-fragmentation')
    custom: Optional[SerialDeviceConfigPacketForwardingCustomDTO] = Field(default=None, alias='custom')


class SerialDeviceConfigDTO(SerialDTO):
    disable: Optional[StrictBool] = Field(default=None, alias='disable')
    description: Optional[Annotated[StrictStr, Field(max_length=255)]] = Field(default=None, alias='description')
    profile: Optional[StrictStr] = Field(default=None, alias='profile')
    protocol: Optional[SerialDeviceConfigProtocolDTO] = Field(default=None, alias='protocol')
    speed: Optional[integer_text(300, 1843200, ())] = Field(default=None, alias='speed')
    data_bits: Optional[Literal['5', '6', '7', '8']] = Field(default=None, alias='data-bits')
    parity: Optional[Literal['none', 'odd', 'even', 'mark', 'space']] = Field(default=None, alias='parity')
    stop_bits: Optional[Literal['1', '2']] = Field(default=None, alias='stop-bits')
    discard_chars_rxd_with_errors: Optional[StrictBool] = Field(default=None, alias='discard-chars-rxd-with-errors')
    login: Optional[SerialDeviceConfigLoginDTO] = Field(default=None, alias='login')
    modbus_gateway: Optional[SerialDeviceConfigModbusGatewayDTO] = Field(default=None, alias='modbus-gateway')
    nine_bits: Optional[SerialDeviceConfigNineBitsDTO] = Field(default=None, alias='nine-bits')
    ppp: Optional[SerialDeviceConfigPppDTO] = Field(default=None, alias='ppp')
    remote_printer: Optional[SerialDeviceConfigRemotePrinterDTO] = Field(default=None, alias='remote-printer')
    serial_tunnel: Optional[SerialDeviceConfigSerialTunnelDTO] = Field(default=None, alias='serial-tunnel')
    slip: Optional[SerialDeviceConfigSlipDTO] = Field(default=None, alias='slip')
    ssh: Optional[SerialDeviceConfigSshDTO] = Field(default=None, alias='ssh')
    tcp: Optional[SerialDeviceConfigTcpDTO] = Field(default=None, alias='tcp')
    telnet: Optional[SerialDeviceConfigTelnetDTO] = Field(default=None, alias='telnet')
    trueport: Optional[SerialDeviceConfigTrueportDTO] = Field(default=None, alias='trueport')
    udp: Optional[SerialDeviceConfigUdpDTO] = Field(default=None, alias='udp')
    virtual_modem: Optional[SerialDeviceConfigVirtualModemDTO] = Field(default=None, alias='virtual-modem')
    packet_forwarding: Optional[SerialDeviceConfigPacketForwardingDTO] = Field(default=None, alias='packet-forwarding')

    @model_validator(mode='before')
    @classmethod
    def parse_page_values(cls, values):
        from app.core.operation.serial.form_parser import read_device
        return read_device(values)


class SerialTtyProfileModbusGatewayDTO(SerialDTO):
    master: Optional[SerialDeviceConfigModbusGatewayMasterDTO] = Field(default=None, alias='master')
    protocol: Optional[SerialDeviceConfigModbusGatewayProtocolDTO] = Field(default=None, alias='protocol')


class SerialTtyProfileSerialTunnelDTO(SerialDTO):
    break_length: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='break-length')
    client: Optional[SerialDeviceConfigSerialTunnelClientDTO] = Field(default=None, alias='client')
    delay_after_break: Optional[integer_text(0, 65535, ())] = Field(default=None, alias='delay-after-break')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')


class SerialTtyProfileSshServerDTO(SerialDTO):
    multi_session_limit: Optional[integer_text(0, 16, ())] = Field(default=None, alias='multi-session-limit')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialTtyProfileSshDTO(SerialDTO):
    client: Optional[SerialDeviceConfigSshClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialTtyProfileSshServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialTtyProfileTcpServerDTO(SerialDTO):
    allow_multiple_connections: Optional[StrictBool] = Field(default=None, alias='allow-multiple-connections')
    authenticate_user: Optional[StrictBool] = Field(default=None, alias='authenticate-user')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialTtyProfileTcpDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTcpClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    serial_buffering: Optional[StrictBool] = Field(default=None, alias='serial-buffering')
    server: Optional[SerialTtyProfileTcpServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialTtyProfileTelnetServerDTO(SerialDTO):
    authenticate_user: Optional[StrictBool] = Field(default=None, alias='authenticate-user')
    multi_session_limit: Optional[integer_text(0, 16, ())] = Field(default=None, alias='multi-session-limit')
    port: Optional[integer_text(1, 65535, ())] = Field(default=None, alias='port')
    post_login_banner: Optional[StrictBool] = Field(default=None, alias='post-login-banner')
    pre_login_banner: Optional[StrictBool] = Field(default=None, alias='pre-login-banner')


class SerialTtyProfileTelnetDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTelnetClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    modem: Optional[SerialDeviceConfigLoginModemDTO] = Field(default=None, alias='modem')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    server: Optional[SerialTtyProfileTelnetServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialTtyProfileTrueportServerDTO(SerialDTO):
    allow_multiple_connections: Optional[StrictBool] = Field(default=None, alias='allow-multiple-connections')


class SerialTtyProfileTrueportDTO(SerialDTO):
    client: Optional[SerialDeviceConfigTrueportClientDTO] = Field(default=None, alias='client')
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    serial_buffering: Optional[StrictBool] = Field(default=None, alias='serial-buffering')
    server: Optional[SerialTtyProfileTrueportServerDTO] = Field(default=None, alias='server')
    session_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='session-timeout')
    signal_active: Optional[StrictBool] = Field(default=None, alias='signal-active')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigSshTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialTtyProfileVirtualModemDTO(SerialDTO):
    client: Optional[SerialDeviceConfigSerialTunnelClientDTO] = Field(default=None, alias='client')
    disable_echo: Optional[StrictBool] = Field(default=None, alias='disable-echo')
    hardware_signals: Optional[SerialDeviceConfigVirtualModemHardwareSignalsDTO] = Field(default=None, alias='hardware-signals')
    initialization_string: Optional[Annotated[StrictStr, Field(max_length=254)]] = Field(default=None, alias='initialization-string')
    response_delay: Optional[integer_text(0, 999, ())] = Field(default=None, alias='response-delay')
    send_connect_status: Optional[SerialDeviceConfigVirtualModemSendConnectStatusDTO] = Field(default=None, alias='send-connect-status')
    send_tcp_keepalive: Optional[StrictBool] = Field(default=None, alias='send-tcp-keepalive')
    tls: Optional[SerialGlobalConfigModbusGatewayTlsDTO] = Field(default=None, alias='tls')
    transmit_string: Optional[SerialDeviceConfigLoginTransmitStringDTO] = Field(default=None, alias='transmit-string')


class SerialTtyProfileDTO(SerialDTO):
    protocol: Optional[SerialDeviceConfigProtocolDTO] = Field(default=None, alias='protocol')
    speed: Optional[integer_text(300, 1843200, ())] = Field(default=None, alias='speed')
    data_bits: Optional[Literal['5', '6', '7', '8']] = Field(default=None, alias='data-bits')
    parity: Optional[Literal['none', 'odd', 'even', 'mark', 'space']] = Field(default=None, alias='parity')
    stop_bits: Optional[Literal['1', '2']] = Field(default=None, alias='stop-bits')
    discard_chars_rxd_with_errors: Optional[StrictBool] = Field(default=None, alias='discard-chars-rxd-with-errors')
    login: Optional[SerialDeviceConfigLoginDTO] = Field(default=None, alias='login')
    modbus_gateway: Optional[SerialTtyProfileModbusGatewayDTO] = Field(default=None, alias='modbus-gateway')
    nine_bits: Optional[SerialDeviceConfigNineBitsDTO] = Field(default=None, alias='nine-bits')
    ppp: Optional[SerialDeviceConfigPppDTO] = Field(default=None, alias='ppp')
    remote_printer: Optional[SerialDeviceConfigRemotePrinterDTO] = Field(default=None, alias='remote-printer')
    serial_tunnel: Optional[SerialTtyProfileSerialTunnelDTO] = Field(default=None, alias='serial-tunnel')
    slip: Optional[SerialDeviceConfigSlipDTO] = Field(default=None, alias='slip')
    ssh: Optional[SerialTtyProfileSshDTO] = Field(default=None, alias='ssh')
    tcp: Optional[SerialTtyProfileTcpDTO] = Field(default=None, alias='tcp')
    telnet: Optional[SerialTtyProfileTelnetDTO] = Field(default=None, alias='telnet')
    trueport: Optional[SerialTtyProfileTrueportDTO] = Field(default=None, alias='trueport')
    udp: Optional[SerialDeviceConfigUdpDTO] = Field(default=None, alias='udp')
    virtual_modem: Optional[SerialTtyProfileVirtualModemDTO] = Field(default=None, alias='virtual-modem')
    packet_forwarding: Optional[SerialDeviceConfigPacketForwardingDTO] = Field(default=None, alias='packet-forwarding')

    @model_validator(mode='before')
    @classmethod
    def parse_page_values(cls, values):
        from app.core.operation.serial.form_parser import read_profile
        return read_profile(values)


class SerialSlipInterfaceDTO(SerialDTO):
    description: Optional[Annotated[StrictStr, Field(max_length=255)]] = None
    disable_vj_comp: Optional[StrictBool] = Field(default=None, alias='disable-vj-comp')
    local_address: Optional[IPv4InterfaceText] = Field(default=None, alias='local-address')
    remote_address: Optional[IPv4InterfaceText] = Field(default=None, alias='remote-address')
    mtu: Optional[integer_text(256, 1006, ())] = None

    @model_validator(mode='after')
    def matching_prefix_lengths(self):
        from ipaddress import IPv4Interface
        if self.local_address and self.remote_address and (
            IPv4Interface(self.local_address).network.prefixlen != IPv4Interface(self.remote_address).network.prefixlen
        ):
            raise ValueError('SLIP local-address and remote-address must have the same netmask')
        return self


class SerialPppInterfaceDTO(SerialDTO):
    description: Optional[Annotated[StrictStr, Field(max_length=255)]] = None
    local_address: Optional[IPv4InterfaceText] = Field(default=None, alias='local-address')
    remote_address: Optional[PppRemoteAddressText] = Field(default=None, alias='remote-address')
    accm: Optional[Annotated[StrictStr, Field(pattern=r'^[0-9a-fA-F]{8}$')]] = None
    idle_timeout: Optional[integer_text(0, 4294967, ())] = Field(default=None, alias='idle-timeout')
    mru: Optional[integer_text(64, 1500, ())] = None
    nak_retry: Optional[integer_text(0, 255, ())] = Field(default=None, alias='nak-retry')
    authentication_protocol: Optional[Literal['none', 'chap', 'pap']] = Field(default=None, alias='authentication/protocol')
    authentication_timeout: Optional[integer_text(0, 255, ())] = Field(default=None, alias='authentication/timeout')
    username: Optional[Annotated[StrictStr, Field(max_length=255)]] = Field(default=None, alias='authentication/username')
    password: Optional[Annotated[StrictStr, Field(max_length=17)]] = Field(default=None, alias='authentication/password')
    remote_user: Optional[Annotated[StrictStr, Field(max_length=255)]] = Field(default=None, alias='authentication/remote-user')
    remote_password: Optional[Annotated[StrictStr, Field(max_length=17)]] = Field(default=None, alias='authentication/remote-password')
    challenge_interval: Optional[integer_text(0, 255, ())] = Field(default=None, alias='authentication/challenge-interval')
    disable_address_control_compression: Optional[StrictBool] = Field(default=None, alias='disable-address-control-compression')
    disable_protocol_compression: Optional[StrictBool] = Field(default=None, alias='disable-protocol-compression')
    magic_negotiation: Optional[StrictBool] = Field(default=None, alias='magic-negotiation')
    vj_compression: Optional[StrictBool] = Field(default=None, alias='vj-compression')
    configure_retry: Optional[integer_text(0, 255, ())] = Field(default=None, alias='configure-request/retry')
    configure_timeout: Optional[integer_text(1, 255, ())] = Field(default=None, alias='configure-request/timeout')
    echo_retry: Optional[integer_text(0, 255, ())] = Field(default=None, alias='echo/retry')
    echo_timeout: Optional[integer_text(0, 255, ())] = Field(default=None, alias='echo/timeout')
    terminate_retry: Optional[integer_text(0, 255, ())] = Field(default=None, alias='terminate-request/retry')
    terminate_timeout: Optional[integer_text(1, 255, ())] = Field(default=None, alias='terminate-request/timeout')
    ipv6_prefix: Optional[IPv6InterfaceText] = Field(default=None, alias='ipv6/global-parameters-network-prefix')
    ipv6_local_identifier: Optional[PppIpv6IdentifierText] = Field(default=None, alias='ipv6/local-interface-identifier')
    ipv6_remote_identifier: Optional[PppIpv6IdentifierText] = Field(default=None, alias='ipv6/remote-interface-identifier')

    @model_validator(mode='before')
    @classmethod
    def ignore_inactive_authentication_fields(cls, values):
        if isinstance(values, dict):
            values = dict(values)
            protocol = values.get('authentication/protocol') or 'none'
            if protocol == 'none':
                for field in ('username', 'password', 'remote-user', 'remote-password', 'challenge-interval'):
                    values.pop(f'authentication/{field}', None)
            elif protocol == 'pap':
                values.pop('authentication/challenge-interval', None)
        return values

    @model_validator(mode='after')
    def matching_prefix_lengths(self):
        from ipaddress import IPv4Interface
        if self.local_address and self.remote_address and self.remote_address != 'negotiation' and (
            IPv4Interface(self.local_address).network.prefixlen != IPv4Interface(self.remote_address).network.prefixlen
        ):
            raise ValueError('PPP local-address and remote-address must have the same netmask')
        return self


class UpdateSerialConfigDTO(BaseModel):
    model_config = ConfigDict(extra='forbid')
    global_values: SerialGlobalConfigDTO = Field(alias='global')
    devices: Dict[str, SerialDeviceConfigDTO]
    profiles: Dict[str, SerialTtyProfileDTO]
    revision: str = Field(pattern=r'^[a-f0-9]{64}$')
    slip_interfaces: Optional[Dict[str, SerialSlipInterfaceDTO]] = Field(default=None, alias='slipInterfaces')
    ppp_interfaces: Optional[Dict[str, SerialPppInterfaceDTO]] = Field(default=None, alias='pppInterfaces')

    @field_validator('devices', 'slip_interfaces', 'ppp_interfaces')
    @classmethod
    def validate_devices(cls, entries):
        if entries is None:
            return entries
        for name in entries:
            if not re.fullmatch(r'ttyS\d+', name):
                raise ValueError('Invalid serial device name')
        return entries

    @field_validator('profiles')
    @classmethod
    def validate_profiles(cls, entries):
        for name in entries:
            validate_name(name)
        return entries


class SerialConfig(db.Model):
    __tablename__ = 'vyos_serial_config'
    id = db.Column(db.Integer, primary_key=True)
    config_json = db.Column(db.Text, nullable=False, default='{}')

    @classmethod
    def refresh(cls, config):
        row = cls.query.filter_by(id=1).first()
        if row is None:
            row = cls(id=1)
            db.session.add(row)
        row.config_json = json.dumps(config)
        db.session.commit()

    def raw_config(self):
        return json.loads(self.config_json)

    def serialize(self):
        from app.core.operation.serial.parser import parse_serial_config_to_form
        return parse_serial_config_to_form(self.raw_config())
