from functools import wraps
from .models import User
from .cloud_auth import authenticate_cloud_cookie
from flask import session, jsonify
from .web_sessions import web_session_is_active, reject_web_session, cloud_cookie_fingerprint


def _is_authenticated() -> bool:
    if session.get("user_id"):
        if web_session_is_active():
            return True
        reject_web_session()
        return False
    return bool(
        session.get("web_session_rejected") != cloud_cookie_fingerprint()
        and authenticate_cloud_cookie()
    )


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not _is_authenticated():
            return jsonify({"message": "Unauthorized"}), 401

        return f(*args, **kwargs)

    return decorated_function


def permission_required(permissions: list[str]):
    """
    Decorator to check if the user has the required permission.
    - if not logged in, return 401
    - if not have permission, return 401
    - else, pass through to the function
    """

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not _is_authenticated():
                return jsonify({"message": "Unauthorized"}), 401

            user_permission = session.get("permission")
            if user_permission not in permissions:
                return jsonify({"message": "Unauthorized"}), 401

            return f(*args, **kwargs)

        return decorated_function

    return decorator
