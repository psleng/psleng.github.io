
# CONFIG CONDITIONS:

## TLS:
- when tls role is active, cannot specify dh-params
- either ca-cert or peer-fingerprint must be specified
- cert is required

## Site-to-site: 
- role is required
### encryption: 
- cipher: empty
- dataCiphers: empty

## Server:
- do not specify remote-host
- do not specify tls role

## Client:
- do not specify dh-params
- do not speficy local-port
- do not specify tls role

## Advanced:
- when ip-version is ipv6, cannot specify remote-host
## Cannot specify "local-port" with "tcp-active"
## Only one IPv4 local-address can be specified
