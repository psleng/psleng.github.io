
from flask import Blueprint


callback_bp = Blueprint('callback', __name__)


from . import routes
