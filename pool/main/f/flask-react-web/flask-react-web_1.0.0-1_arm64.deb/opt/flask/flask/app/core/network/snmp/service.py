
from app.core.network.snmp.command_snmp import SNMPCommand
from app.core.network.snmp.models import SNMPConfig
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.core.utils.validate.verify_parser import format_verify
from app.socket.socket_manager import socket_manager
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.api.http.cmd.command import SHOW_SNMP
from app.core.network.snmp.parser import parse_snmp_monitor_community, parse_snmp_monitor_mib, parse_snmp_monitor_v3
from types import SimpleNamespace
def update_snmp(provider, data):
    logger.info("Update snmp:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Diff config: ")
    print(pprint.pformat(diff, indent=2, width=80))
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))
    
    set_cmds = []
    iface_set_cmd = SNMPCommand(operator='set', resource='snmp')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = SNMPCommand(operator='delete', resource='snmp')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "snmp"
    curr_config = provider.verify_service.call_get_config(service)
    current_raw_config = curr_config if curr_config else {}
    
    merged_del_config = merge_dicts_delete(current_raw_config, new_delete_configs.get('service', {}).get('snmp', {}), clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('service', {}).get('snmp', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))    

    verify = format_verify(verify)
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    # Update DB:
    SNMPConfig.refresh(merged_config)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update SNMP",
                "content": "SNMP is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def fetch_snmp(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SNMP, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data


def monitor_snmp(provider, data):
    target = data.target 
    try:
        if target == "community":
            res = provider.graphql_service.send_request(function_name='ShowCommunitiesSnmpQuery', data=None, verify=False) 
            return parse_snmp_monitor_community(res.json()['data'])
        elif target == "mib":
            res = provider.graphql_service.send_request(function_name='ShowIfmibSnmpQuery', data=None, verify=False) 
            return parse_snmp_monitor_mib(res.json()['data'])
        elif target == "v3":
            res = provider.graphql_service.send_request(function_name='ShowSnmpV3SnmpQuery', data=None, verify=False) 
            return parse_snmp_monitor_v3(res.json()['data'])
        else:
            return []
    except Exception as e:
        print("Error getting snmp monitor data:")
        print(str(e))
        return []



def fetch_snmp_stats(provider, params=None):
    t_community = SimpleNamespace(target="community")
    t_v3 = SimpleNamespace(target="v3")

    try:
        community = monitor_snmp(provider, t_community)
    except Exception as e:
        logger.exception("SNMP fetch - Community failed")
        community = {"error": str(e)}

    try:
        v3 = monitor_snmp(provider, t_v3)
    except Exception as e:
        logger.exception("SNMP fetch - v3 failed")
        v3 = {"error": str(e)}

    return {
        "community": community,
        "v3": v3
    }


def restart_snmp(provider, data=None):
    response = provider.graphql_service.send_simple_mutation_request(
        function_name='RestartServiceRestartServiceMutation',
        data={"name": "snmp"},
        verify=False
    )
    try:
        return response.json()
    except Exception as e:
        return {"error": str(e), "status_code": getattr(response, 'status_code', None), "response_text": getattr(response, 'text', None)}
