import os
from logging import DEBUG, getLogger
from uuid import uuid4

from flask import jsonify, request, Response, send_from_directory
from werkzeug.utils import secure_filename

from app.auth.utils import login_required
from app.core.api.api import API_ACTION, API_TARGET
from app.core.api.manager import api_manager
from app.core.system import vyos_system_bp
from app.core.system.config_mgmt.models import (
    ApplyCommitDiffDTO,
    CommitDiffQueryDTO,
    ConfigFilePathDTO,
    UpdateConfigMgmtDTO,
)
from app.core.utils.decorator.route_decorator import Pipeline

admin_system = Pipeline.admin(vyos_system_bp)

logger = getLogger(__name__)
logger.setLevel(DEBUG)


CONFIG_UPLOAD_STORAGE_ROOT = "/var/lib/flask/config-uploads"
CONFIG_UPLOAD_MAX_BYTES = 8 * 1024 * 1024


def _unwrap(result):
    if isinstance(result, Exception):
        raise result
    return result


def _config_attachment(content: str, filename: str):
    return Response(
        content,
        status=200,
        mimetype='text/plain',
        headers={
            'Content-Disposition': f'attachment; filename="{filename}"',
            'Cache-Control': 'no-store',
        },
    )


@vyos_system_bp.route('/config-management', methods=['GET'])
@login_required
def get_config_management():
    try:
        result = _unwrap(api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.CONFIG_MGMT,
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/config-management', methods=['PUT'])
def update_config_management():
    try:
        data = UpdateConfigMgmtDTO.model_validate(request.get_json(silent=True) or {})
        result = _unwrap(api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.CONFIG_MGMT,
            data=data.model_dump(),
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/config-management/commits', methods=['GET'])
@login_required
def get_config_management_commits():
    try:
        result = _unwrap(api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.CONFIG_MGMT_COMMIT_LOG,
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/config-management/commits/<int:rev>/file', methods=['GET'])
@login_required
def get_config_management_commit_file(rev):
    try:
        result = _unwrap(api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.CONFIG_MGMT_COMMIT_FILE,
            data={'rev': rev},
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/config-management/commits/<int:rev>/file/download', methods=['GET'])
@login_required
def download_config_management_commit_file(rev):
    try:
        result = _unwrap(api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.CONFIG_MGMT_COMMIT_FILE,
            data={'rev': rev},
        ))
        return _config_attachment(result.get('content') or '', f'config.boot.{rev}')
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@vyos_system_bp.route('/config-management/diff', methods=['GET'])
@login_required
def get_config_management_diff():
    try:
        rev2_param = request.args.get('rev2')
        data = CommitDiffQueryDTO.model_validate({
            'rev': request.args.get('rev', 0),
            'rev2': rev2_param if rev2_param not in (None, '') else None,
            'commands': str(request.args.get('commands', 'false')).lower() == 'true',
        })
        result = _unwrap(api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.CONFIG_MGMT_COMMIT_DIFF,
            data=data.model_dump(),
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/config-management/apply-diff', methods=['POST'])
def apply_config_management_diff():
    try:
        data = ApplyCommitDiffDTO.model_validate(request.get_json(silent=True) or {})
        result = _unwrap(api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.CONFIG_MGMT_APPLY_DIFF,
            data=data.model_dump(),
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/config-management/revisions/<int:rev>/load', methods=['POST'])
def load_config_management_revision(rev):
    try:
        result = _unwrap(api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.CONFIG_MGMT_LOAD_REVISION,
            data={'rev': rev},
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/config-management/save', methods=['POST'])
def save_config_management_file():
    try:
        data = ConfigFilePathDTO.model_validate(request.get_json(silent=True) or {})
        result = _unwrap(api_manager.call(
            action=API_ACTION.SAVE,
            target=API_TARGET.CONFIG_MGMT_SAVE_FILE,
            data=data.model_dump(),
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


@admin_system.route('/config-management/load', methods=['POST'])
def load_config_management_file():
    try:
        data = ConfigFilePathDTO.model_validate(request.get_json(silent=True) or {})
        result = _unwrap(api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.CONFIG_MGMT_LOAD_FILE,
            data=data.model_dump(),
        ))
        return jsonify(result), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400


def _store_uploaded_config(upload):
    filename = secure_filename(upload.filename or '')
    if not filename:
        raise ValueError('A configuration file is required')

    upload.stream.seek(0, os.SEEK_END)
    size = upload.stream.tell()
    upload.stream.seek(0)
    if size == 0:
        raise ValueError('The uploaded configuration file is empty')
    if size > CONFIG_UPLOAD_MAX_BYTES:
        raise ValueError('The uploaded configuration file is too large')

    token = uuid4().hex
    directory = os.path.join(CONFIG_UPLOAD_STORAGE_ROOT, token)
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, filename)
    upload.save(path)
    return token, filename, path


def _discard_uploaded_config(token, filename):
    try:
        directory = os.path.join(CONFIG_UPLOAD_STORAGE_ROOT, secure_filename(token))
        path = os.path.join(directory, secure_filename(filename))
        if os.path.isfile(path):
            os.remove(path)
        if os.path.isdir(directory) and not os.listdir(directory):
            os.rmdir(directory)
    except Exception as e:
        logger.error(f'Failed to clean up staged configuration upload: {e}')


@vyos_system_bp.route('/config-management/uploaded/<token>/<filename>', methods=['GET'])
def download_staged_config_upload(token, filename):
    try:
        safe_token = secure_filename(token)
        safe_filename = secure_filename(filename)
        if not safe_token or not safe_filename:
            return jsonify({'error': 'Invalid configuration upload path'}), 400
        directory = os.path.join(CONFIG_UPLOAD_STORAGE_ROOT, safe_token)
        return send_from_directory(directory, safe_filename, as_attachment=False)
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 404


@admin_system.route('/config-management/upload', methods=['POST'])
def upload_config_management_file():
    token = None
    filename = None
    try:
        upload = request.files.get('file')
        if upload is None:
            return jsonify({'error': 'A configuration file is required'}), 400

        token, filename, _ = _store_uploaded_config(upload)
        url = f"{request.host_url.rstrip('/')}/webapi/vyos/system/config-management/uploaded/{token}/{filename}"

        result = _unwrap(api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.CONFIG_MGMT_LOAD_FILE,
            data={'path': url},
        ))
        return jsonify({**result, 'filename': filename}), 200
    except Exception as e:
        logger.error(str(e))
        return jsonify({'error': str(e)}), 400
    finally:
        if token and filename:
            _discard_uploaded_config(token, filename)
