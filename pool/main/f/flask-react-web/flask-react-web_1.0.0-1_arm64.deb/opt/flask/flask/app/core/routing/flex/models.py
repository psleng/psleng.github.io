from pydantic import BaseModel
from typing import Optional, List, Literal

from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.log.logger import logger


class FlexRoutingTargetDTO(BaseModel):
    target: str
    interface: Optional[str] = None


class FlexRoutingCheckDTO(BaseModel):
    policy: Optional[str] = None
    port: Optional[str] = None
    timeout: Optional[str] = None
    type: Optional[str] = None
    targets: Optional[List[FlexRoutingTargetDTO]] = None


class FlexRoutingRowDTO(BaseModel):
    route_prefix: str
    path_type: Literal['next-hop', 'dhcp-interface']
    path_value: str
    interface: Optional[str] = None
    metric: Optional[str] = None
    onlink: Optional[bool] = None
    check: Optional[FlexRoutingCheckDTO] = None


class UpdateFlexRoutingDTO(BaseModel):
    routes: List[FlexRoutingRowDTO]


class FlexRoutingConfig(db.Model):
    __tablename__ = 'vyos_config_flex_routing'

    id = Column(Integer, primary_key=True)

    paths = relationship('FlexRoutingPath', back_populates='flex_config', cascade='all, delete-orphan')

    def _build_vyos_config(self):
        config = {"route": {}}

        for p in self.paths:
            route_prefix = p.route_prefix
            path_type = p.path_type
            path_value = p.path_value

            if route_prefix not in config['route']:
                config['route'][route_prefix] = {}
            if path_type not in config['route'][route_prefix]:
                config['route'][route_prefix][path_type] = {}

            entry = {}
            if p.interface:
                entry['interface'] = p.interface
            if p.metric is not None:
                entry['metric'] = str(p.metric)
            if p.onlink:
                entry['onlink'] = {}

            check = {}
            if p.check_policy:
                check['policy'] = p.check_policy
            if p.check_port is not None:
                check['port'] = str(p.check_port)
            if p.check_timeout is not None:
                check['timeout'] = str(p.check_timeout)
            if p.check_type:
                check['type'] = p.check_type
            if len(p.targets) > 0:
                check['target'] = {}
                for t in p.targets:
                    check['target'][t.target_ip] = {}
                    if t.interface:
                        check['target'][t.target_ip]['interface'] = t.interface
                    if t.vrf:
                        check['target'][t.target_ip]['vrf'] = t.vrf

            if check:
                entry['check'] = check

            config['route'][route_prefix][path_type][path_value] = entry

        return config

    def _build_routes_rows(self):
        routes = []

        for p in self.paths:
            row_check = None

            if any([
                p.check_policy,
                p.check_port is not None,
                p.check_timeout is not None,
                p.check_type,
                len(p.targets) > 0
            ]):
                row_targets = []
                for t in p.targets:
                    row_targets.append({
                        'target': t.target_ip,
                        'interface': t.interface or ''
                    })

                row_check = {
                    'policy': p.check_policy or '',
                    'port': str(p.check_port) if p.check_port is not None else '',
                    'timeout': str(p.check_timeout) if p.check_timeout is not None else '',
                    'type': p.check_type or '',
                    'targets': row_targets
                }

            routes.append({
                'route_prefix': p.route_prefix,
                'path_type': p.path_type,
                'path_value': p.path_value,
                'interface': p.interface or '',
                'metric': str(p.metric) if p.metric is not None else '',
                'onlink': True if p.onlink else False,
                'check': row_check or {}
            })

        return routes

    def serialize(self):
        return {
            'id': self.id,
            'config': self._build_vyos_config(),
            'routes': self._build_routes_rows(),
        }


    @classmethod
    def truncate(cls):
        from sqlalchemy import text

        try:
            tables_to_clear = [
                'vyos_config_flex_routing_target',
                'vyos_config_flex_routing_path',
                cls.__tablename__,
            ]
            for table in tables_to_clear:
                db.session.execute(text(f"DELETE FROM {table}"))
            db.session.commit()
        except Exception as e:
            logger.error(f"Error truncating {cls.__tablename__}: {str(e)}")
            db.session.rollback()


    @classmethod
    def refresh(cls, data):
        try:
            cls.truncate()

            route_map = {}
            if isinstance(data, dict):
                if 'route' in data and isinstance(data.get('route'), dict):
                    route_map = data.get('route') or {}
                else:
                    route_map = data

            flex_config = cls()
            db.session.add(flex_config)
            db.session.flush()

            def to_int(value):
                try:
                    if value is None or str(value) == '':
                        return None
                    return int(value)
                except Exception:
                    return None

            def to_bool_onlink(value):
                if value is None:
                    return False
                if value == {}:
                    return True
                if value is True:
                    return True
                if str(value).lower() in ['true', '1', 'yes', 'enabled']:
                    return True
                return False

            for route_prefix, route_data in (route_map or {}).items():
                if not isinstance(route_data, dict):
                    continue

                # next-hop
                next_hops = route_data.get('next-hop')
                if isinstance(next_hops, dict):
                    for nh_ip, nh_opts in next_hops.items():
                        nh_opts = nh_opts if isinstance(nh_opts, dict) else {}
                        path = FlexRoutingPath(
                            flex_config_id=flex_config.id,
                            route_prefix=str(route_prefix),
                            path_type='next-hop',
                            path_value=str(nh_ip),
                            interface=nh_opts.get('interface'),
                            metric=to_int(nh_opts.get('metric')),
                            onlink=to_bool_onlink(nh_opts.get('onlink')),
                        )

                        check = nh_opts.get('check') if isinstance(nh_opts.get('check'), dict) else {}
                        if check:
                            path.check_policy = check.get('policy')
                            path.check_port = to_int(check.get('port'))
                            path.check_timeout = to_int(check.get('timeout'))
                            path.check_type = check.get('type')

                            targets = check.get('target') if isinstance(check.get('target'), dict) else {}
                            for target_ip, target_opts in (targets or {}).items():
                                target_opts = target_opts if isinstance(target_opts, dict) else {}
                                path.targets.append(FlexRoutingTarget(
                                    target_ip=str(target_ip),
                                    interface=target_opts.get('interface'),
                                    vrf=target_opts.get('vrf'),
                                ))

                        db.session.add(path)

                # dhcp-interface
                dhcp_interfaces = route_data.get('dhcp-interface')
                if isinstance(dhcp_interfaces, dict):
                    for dhcp_ifname, dhcp_opts in dhcp_interfaces.items():
                        dhcp_opts = dhcp_opts if isinstance(dhcp_opts, dict) else {}
                        path = FlexRoutingPath(
                            flex_config_id=flex_config.id,
                            route_prefix=str(route_prefix),
                            path_type='dhcp-interface',
                            path_value=str(dhcp_ifname),
                            interface=dhcp_opts.get('interface'),
                            metric=to_int(dhcp_opts.get('metric')),
                            onlink=to_bool_onlink(dhcp_opts.get('onlink')),
                        )

                        check = dhcp_opts.get('check') if isinstance(dhcp_opts.get('check'), dict) else {}
                        if check:
                            path.check_policy = check.get('policy')
                            path.check_port = to_int(check.get('port'))
                            path.check_timeout = to_int(check.get('timeout'))
                            path.check_type = check.get('type')

                            targets = check.get('target') if isinstance(check.get('target'), dict) else {}
                            for target_ip, target_opts in (targets or {}).items():
                                target_opts = target_opts if isinstance(target_opts, dict) else {}
                                path.targets.append(FlexRoutingTarget(
                                    target_ip=str(target_ip),
                                    interface=target_opts.get('interface'),
                                    vrf=target_opts.get('vrf'),
                                ))

                        db.session.add(path)

            db.session.commit()
            return flex_config
        except Exception as e:
            logger.error(f"Error refreshing Flex Routing config: {str(e)}")
            db.session.rollback()
            return None


class FlexRoutingPath(db.Model):
    __tablename__ = 'vyos_config_flex_routing_path'

    id = Column(Integer, primary_key=True)
    flex_config_id = Column(Integer, ForeignKey('vyos_config_flex_routing.id'), nullable=False)

    route_prefix = Column(String(64), nullable=False)
    path_type = Column(String(32), nullable=False)
    path_value = Column(String(128), nullable=False)

    interface = Column(String(64), nullable=True)
    metric = Column(Integer, nullable=True)
    onlink = Column(Boolean, default=False)

    check_policy = Column(String(32), nullable=True)
    check_port = Column(Integer, nullable=True)
    check_timeout = Column(Integer, nullable=True)
    check_type = Column(String(32), nullable=True)

    flex_config = relationship('FlexRoutingConfig', back_populates='paths')
    targets = relationship('FlexRoutingTarget', back_populates='path', cascade='all, delete-orphan')

    def serialize(self):
        return {
            'id': self.id,
            'route_prefix': self.route_prefix,
            'path_type': self.path_type,
            'path_value': self.path_value,
            'interface': self.interface,
            'metric': self.metric,
            'onlink': self.onlink,
            'check': {
                'policy': self.check_policy,
                'port': self.check_port,
                'timeout': self.check_timeout,
                'type': self.check_type,
                'targets': [t.serialize() for t in self.targets],
            } if any([
                self.check_policy,
                self.check_port is not None,
                self.check_timeout is not None,
                self.check_type,
                len(self.targets) > 0
            ]) else None,
        }


class FlexRoutingTarget(db.Model):
    __tablename__ = 'vyos_config_flex_routing_target'

    id = Column(Integer, primary_key=True)
    path_id = Column(Integer, ForeignKey('vyos_config_flex_routing_path.id'), nullable=False)

    target_ip = Column(String(64), nullable=False)
    interface = Column(String(64), nullable=True)
    vrf = Column(String(64), nullable=True)

    path = relationship('FlexRoutingPath', back_populates='targets')

    def serialize(self):
        return {
            'id': self.id,
            'target': self.target_ip,
            'interface': self.interface,
            'vrf': self.vrf,
        }