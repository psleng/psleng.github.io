from pydantic import BaseModel, Field, field_validator, model_validator
from ipaddress import ip_network, ip_address
from typing import Optional, List, Literal

from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.log.logger import logger


class FlexRoutingTargetDTO(BaseModel):
    target: str
    interface: Optional[str] = None


class FlexRoutingCheckDTO(BaseModel):
    policy: Optional[str] = None
    port: Optional[str] = None
    timeout: Optional[str] = None
    type: Optional[str] = None
    failure_count: Optional[str] = Field(None, alias='failure-count')
    success_count: Optional[str] = Field(None, alias='success-count')
    targets: Optional[List[FlexRoutingTargetDTO]] = None

    @field_validator('failure_count', 'success_count', 'timeout', 'port')
    @classmethod
    def validate_number(cls, value, info):
        if value in (None, ''):
            return value
        maximum = {'failure_count': 10, 'success_count': 10, 'timeout': 300, 'port': 65535}[info.field_name]
        if not value.isascii() or not value.isdigit() or not 1 <= int(value) <= maximum:
            raise ValueError(f'{info.field_name} must be an integer between 1 and {maximum}')
        return value

    @model_validator(mode='after')
    def validate_check(self):
        if self.type == 'tcp' and not self.port:
            raise ValueError('Check port is required for TCP')
        if self.policy not in (None, '', 'all-available', 'any-available'):
            raise ValueError('Invalid check policy')
        if self.type not in (None, '', 'arp', 'icmp', 'tcp'):
            raise ValueError('Invalid check type')
        return self


class FlexRoutingRowDTO(BaseModel):
    route_prefix: str
    path_type: Literal['next-hop', 'dhcp-interface', 'interface']
    path_value: str
    interface: Optional[str] = None
    metric: Optional[str] = None
    onlink: Optional[bool] = None
    check: Optional[FlexRoutingCheckDTO] = None

    @model_validator(mode='after')
    def validate_route(self):
        network = ip_network(self.route_prefix, strict=False)
        if '/' not in self.route_prefix:
            raise ValueError('Route prefix must include a prefix length')
        if self.path_type != 'next-hop':
            self.path_value = self.path_value.strip() or (self.interface or '').strip()
            self.interface = self.path_value
        else:
            if ip_address(self.path_value).version != network.version:
                raise ValueError('Next hop must match the route address family')
        if not self.interface or not self.path_value:
            raise ValueError('Interface and path value are required')
        if self.metric not in (None, ''):
            if not self.metric.isascii() or not self.metric.isdigit() or not 1 <= int(self.metric) <= 255:
                raise ValueError('Metric must be an integer between 1 and 255')
        if not self.check or not self.check.targets:
            raise ValueError('At least one check target is required')
        targets = set()
        for target in self.check.targets:
            address = ip_address(target.target)
            if address in targets:
                raise ValueError('Check targets must be unique within each path')
            targets.add(address)
            if self.path_type != 'next-hop':
                target.interface = self.path_value
        return self


class UpdateFlexRoutingDTO(BaseModel):
    routes: List[FlexRoutingRowDTO]
    route_ver: Literal['ipv4', 'ipv6'] = 'ipv4'

    @model_validator(mode='after')
    def validate_unique_paths(self):
        paths = set()
        for row in self.routes:
            network = ip_network(row.route_prefix, strict=False)
            expected_version = 6 if self.route_ver == 'ipv6' else 4
            if network.version != expected_version:
                raise ValueError(f'Route prefix must be {self.route_ver}')
            if self.route_ver == 'ipv6':
                if row.path_type == 'dhcp-interface':
                    raise ValueError('IPv6 failover supports next-hop and interface paths')
                for target in row.check.targets:
                    if ip_address(target.target).version != 6:
                        raise ValueError('IPv6 check targets must be IPv6 addresses')
                    target.interface = row.interface
            key = (ip_network(row.route_prefix, strict=False), row.path_type, row.path_value)
            if key in paths:
                raise ValueError('Each path must be unique within the same route prefix')
            paths.add(key)
        return self


class FlexRoutingConfig(db.Model):
    __tablename__ = 'vyos_config_flex_routing'

    id = Column(Integer, primary_key=True)

    paths = relationship('FlexRoutingPath', back_populates='flex_config', cascade='all, delete-orphan')

    def _build_vyos_config(self, route_type=None):
        config = {route_type or "route": {}}

        for p in self.paths:
            if route_type and p.route_type != route_type:
                continue
            route_node = config.setdefault(p.route_type, {})
            route_prefix = p.route_prefix
            path_type = p.path_type
            path_value = p.path_value

            if route_prefix not in route_node:
                route_node[route_prefix] = {}
            if path_type not in route_node[route_prefix]:
                route_node[route_prefix][path_type] = {}

            entry = {}
            if p.interface:
                entry['interface'] = p.interface
            if p.metric is not None:
                entry['metric'] = str(p.metric)
            if p.onlink:
                entry['onlink'] = {}

            check = {}
            if p.check_policy:
                check['policy'] = p.check_policy
            if p.check_port is not None:
                check['port'] = str(p.check_port)
            if p.check_timeout is not None:
                check['timeout'] = str(p.check_timeout)
            if p.check_type:
                check['type'] = p.check_type
            if p.check_failure_count is not None:
                check['failure-count'] = str(p.check_failure_count)
            if p.check_success_count is not None:
                check['success-count'] = str(p.check_success_count)
            if len(p.targets) > 0:
                check['target'] = {}
                for t in p.targets:
                    check['target'][t.target_ip] = {}
                    if t.interface:
                        check['target'][t.target_ip]['interface'] = t.interface
                    if t.vrf:
                        check['target'][t.target_ip]['vrf'] = t.vrf

            if check:
                entry['check'] = check

            route_node[route_prefix][path_type][path_value] = entry

        return config

    def _build_routes_rows(self, route_type=None):
        routes = []

        for p in self.paths:
            if route_type and p.route_type != route_type:
                continue
            row_check = None

            if any([
                p.check_policy,
                p.check_port is not None,
                p.check_timeout is not None,
                p.check_failure_count is not None,
                p.check_success_count is not None,
                p.check_type,
                len(p.targets) > 0
            ]):
                row_targets = []
                for t in p.targets:
                    row_targets.append({
                        'target': t.target_ip,
                        'interface': t.interface or ''
                    })

                row_check = {
                    'policy': p.check_policy or '',
                    'port': str(p.check_port) if p.check_port is not None else '',
                    'timeout': str(p.check_timeout) if p.check_timeout is not None else '',
                    'type': p.check_type or '',
                    'failure-count': str(p.check_failure_count) if p.check_failure_count is not None else '',
                    'success-count': str(p.check_success_count) if p.check_success_count is not None else '',
                    'targets': row_targets
                }

            routes.append({
                'route_prefix': p.route_prefix,
                'path_type': p.path_type,
                'path_value': p.path_value,
                'interface': p.interface or '',
                'metric': str(p.metric) if p.metric is not None else '',
                'onlink': True if p.onlink else False,
                'check': row_check or {}
            })

        return routes

    def serialize(self, route_type=None):
        return {
            'id': self.id,
            'config': self._build_vyos_config(route_type),
            'routes': self._build_routes_rows(route_type),
        }


    @classmethod
    def truncate(cls):
        from sqlalchemy import text

        try:
            tables_to_clear = [
                'vyos_config_flex_routing_target',
                'vyos_config_flex_routing_path',
                cls.__tablename__,
            ]
            for table in tables_to_clear:
                db.session.execute(text(f"DELETE FROM {table}"))
            db.session.commit()
        except Exception as e:
            logger.error(f"Error truncating {cls.__tablename__}: {str(e)}")
            db.session.rollback()


    @classmethod
    def refresh(cls, data, route_type=None):
        try:
            # A scoped edit replaces one family. Full router refreshes replace both.
            if route_type:
                current = cls.query.order_by(cls.id.desc()).first()
                route_maps = current._build_vyos_config() if current else {}
                route_maps[route_type] = data or {}
            elif isinstance(data, dict) and ('route' in data or 'route6' in data):
                route_maps = {key: data.get(key) or {} for key in ('route', 'route6')}
            else:
                route_maps = {'route': data or {}}
            cls.truncate()

            flex_config = cls()
            db.session.add(flex_config)
            db.session.flush()

            def to_int(value):
                try:
                    if value is None or str(value) == '':
                        return None
                    return int(value)
                except Exception:
                    return None

            def to_bool_onlink(value):
                if value is None:
                    return False
                if value == {}:
                    return True
                if value is True:
                    return True
                if str(value).lower() in ['true', '1', 'yes', 'enabled']:
                    return True
                return False

            for family, route_map in route_maps.items():
                if not isinstance(route_map, dict):
                    continue
                for route_prefix, route_data in route_map.items():
                    if not isinstance(route_data, dict):
                        continue

                    for path_type in ('next-hop', 'dhcp-interface', 'interface'):
                        entries = route_data.get(path_type)
                        if not isinstance(entries, dict):
                            continue
                        for path_value, options in entries.items():
                            options = options if isinstance(options, dict) else {}
                            path = FlexRoutingPath(
                                flex_config_id=flex_config.id,
                                route_prefix=str(route_prefix),
                                route_type=family,
                                path_type=path_type,
                                path_value=str(path_value),
                                interface=options.get('interface') or (str(path_value) if path_type != 'next-hop' else None),
                                metric=to_int(options.get('metric')),
                                onlink=to_bool_onlink(options.get('onlink')),
                            )
                            check = options.get('check') if isinstance(options.get('check'), dict) else {}
                            path.check_policy = check.get('policy')
                            path.check_port = to_int(check.get('port'))
                            path.check_timeout = to_int(check.get('timeout'))
                            path.check_type = check.get('type')
                            path.check_failure_count = to_int(check.get('failure-count'))
                            path.check_success_count = to_int(check.get('success-count'))
                            targets = check.get('target') if isinstance(check.get('target'), dict) else {}
                            for target_ip, target_opts in targets.items():
                                target_opts = target_opts if isinstance(target_opts, dict) else {}
                                path.targets.append(FlexRoutingTarget(
                                    target_ip=str(target_ip),
                                    interface=target_opts.get('interface'),
                                    vrf=target_opts.get('vrf'),
                                ))
                            db.session.add(path)

            db.session.commit()
            return flex_config
        except Exception as e:
            logger.error(f"Error refreshing Flex Routing config: {str(e)}")
            db.session.rollback()
            return None


class FlexRoutingPath(db.Model):
    __tablename__ = 'vyos_config_flex_routing_path'

    id = Column(Integer, primary_key=True)
    flex_config_id = Column(Integer, ForeignKey('vyos_config_flex_routing.id'), nullable=False)

    route_type = Column(String(8), nullable=False, default='route')
    route_prefix = Column(String(64), nullable=False)
    path_type = Column(String(32), nullable=False)
    path_value = Column(String(128), nullable=False)

    interface = Column(String(64), nullable=True)
    metric = Column(Integer, nullable=True)
    onlink = Column(Boolean, default=False)

    check_policy = Column(String(32), nullable=True)
    check_port = Column(Integer, nullable=True)
    check_timeout = Column(Integer, nullable=True)
    check_type = Column(String(32), nullable=True)
    check_failure_count = Column(Integer, nullable=True)
    check_success_count = Column(Integer, nullable=True)

    flex_config = relationship('FlexRoutingConfig', back_populates='paths')
    targets = relationship('FlexRoutingTarget', back_populates='path', cascade='all, delete-orphan')

    def serialize(self):
        return {
            'id': self.id,
            'route_prefix': self.route_prefix,
            'path_type': self.path_type,
            'path_value': self.path_value,
            'interface': self.interface,
            'metric': self.metric,
            'onlink': self.onlink,
            'check': {
                'policy': self.check_policy,
                'port': self.check_port,
                'timeout': self.check_timeout,
                'type': self.check_type,
                'failure-count': self.check_failure_count,
                'success-count': self.check_success_count,
                'targets': [t.serialize() for t in self.targets],
            } if any([
                self.check_policy,
                self.check_port is not None,
                self.check_timeout is not None,
                self.check_failure_count is not None,
                self.check_success_count is not None,
                self.check_type,
                len(self.targets) > 0
            ]) else None,
        }


class FlexRoutingTarget(db.Model):
    __tablename__ = 'vyos_config_flex_routing_target'

    id = Column(Integer, primary_key=True)
    path_id = Column(Integer, ForeignKey('vyos_config_flex_routing_path.id'), nullable=False)

    target_ip = Column(String(64), nullable=False)
    interface = Column(String(64), nullable=True)
    vrf = Column(String(64), nullable=True)

    path = relationship('FlexRoutingPath', back_populates='targets')

    def serialize(self):
        return {
            'id': self.id,
            'target': self.target_ip,
            'interface': self.interface,
            'vrf': self.vrf,
        }