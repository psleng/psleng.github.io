import pytest
import json 

test_final_1 = pytest.param(
    {
        "input_json": json.dumps({
            "type": "ipsec",
            "general": {
                "siteToSite": {
                    "peers": [
                        {
                            "name": "peer-test",
                            "description": "Test peer for final integration",
                            "enabled": True,
                            "authentication": {
                                "mode": "pre-shared-secret",
                                "localId": "test-local",
                                "remoteId": "test-remote"
                            },
                            "ikeGroup": "ike-test",
                            "localAddress": "10.0.0.1",
                            "remoteAddress": ["10.0.0.2"],
                            "tunnels": [
                                {
                                    "id": "1",
                                    "enabled": True,
                                    "espGroup": "esp-test",
                                    "local": {
                                        "prefix": ["192.168.1.0/24"]
                                    },
                                    "remote": {
                                        "prefix": ["192.168.2.0/24"]
                                    }
                                }
                            ]
                        }
                    ]
                }
            },
            "security": {
                "presharedKeys": [
                    {
                        "name": "psk-test",
                        "id": "test-id",
                        "secret": "test-secret",
                        "secretType": "plaintext"
                    }
                ],
                "ikeGroups": [
                    {
                        "name": "ike-test",
                        "proposals": []
                    }
                ],
                "espGroups": [
                    {
                        "name": "esp-test",
                        "proposals": []
                    }
                ]
            }
        }),
        "service": "ipsec"
    },
    id="test_ipsec_final_1"
)


test_final_2 = pytest.param(
    {
        "input_json": json.dumps({
            "type": "ipsec",
            "general": {
                "remoteAccess": {
                    "connections": [
                        {
                            "name": "conn-test",
                            "enabled": True,
                            "ikeGroup": "ike-test",
                            "espGroup": "esp-test",
                            "localAddress": "any",
                            "pools": ["pool-test"],
                            "authentication": {
                                "clientMode": "eap-mschapv2",
                                "serverMode": "pre-shared-secret",
                                "preSharedSecret": "test-secret",
                                "localUsers": [
                                    {
                                        "username": "testuser",
                                        "password": "testpass",
                                        "enabled": True
                                    }
                                ]
                            }
                        }
                    ],
                    "pools": [
                        {
                            "name": "pool-test",
                            "prefix": "10.0.0.0/24",
                            "nameServers": ["8.8.8.8", "8.8.4.4"],
                            "exclude": ["10.0.0.1/32"]
                        }
                    ]
                }
            },
            "security": {
                "ikeGroups": [
                    {
                        "name": "ike-test",
                        "keyExchange": "ikev2",
                        "lifetime": 28800,
                        "proposals": [
                            {
                                "proposal": 1,
                                "dhGroup": 14,
                                "encryption": "aes256",
                                "hash": "sha256"
                            }
                        ]
                    }
                ],
                "espGroups": [
                    {
                        "name": "esp-test",
                        "lifetime": 3600,
                        "mode": "tunnel",
                        "pfs": "dh-group14",
                        "proposals": [
                            {
                                "proposal": 1,
                                "encryption": "aes256",
                                "hash": "sha256"
                            }
                        ]
                    }
                ]
            }
        }),
        "service": "ipsec"
    },
    id="test_ipsec_final_remote_access"
)

test_final_3 = pytest.param(
    {
        "input_json": json.dumps({
            "type": "ipsec",
            "general": {
                "siteToSite": {
                    "peers": [
                        {
                            "name": "peer-x509",
                            "enabled": True,
                            "authentication": {
                                "mode": "x509",
                                "useX509Id": True,
                                "x509": {
                                    "caCertificate": "ca-cert-1",
                                    "certificate": "cert-1",
                                    "passphrase": "x509-pass"
                                }
                            },
                            "ikeGroup": "ike-x509",
                            "espGroup": "esp-x509",
                            "localAddress": "10.0.0.1",
                            "remoteAddress": ["10.0.0.2"],
                            "tunnels": [
                                {
                                    "id": "1",
                                    "enabled": True,
                                    "espGroup": "esp-x509",
                                    "local": {
                                        "prefix": ["192.168.1.0/24", "192.168.2.0/24"]
                                    },
                                    "remote": {
                                        "prefix": ["192.168.3.0/24"]
                                    }
                                },
                                {
                                    "id": "2",
                                    "enabled": True,
                                    "espGroup": "esp-x509",
                                    "local": {
                                        "prefix": ["192.168.10.0/24"]
                                    },
                                    "remote": {
                                        "prefix": ["192.168.20.0/24"]
                                    }
                                }
                            ]
                        }
                    ]
                }
            },
            "security": {
                "ikeGroups": [
                    {
                        "name": "ike-x509",
                        "keyExchange": "ikev2",
                        "proposals": []
                    }
                ],
                "espGroups": [
                    {
                        "name": "esp-x509",
                        "mode": "tunnel",
                        "proposals": []
                    }
                ]
            }
        }),
        "service": "ipsec"
    },
    id="test_ipsec_final_x509_multi_tunnel"
)

test_final_4 = pytest.param(
    {
        "input_json": json.dumps({
            "type": "ipsec",
            "general": {
                "options": {
                    "disableRouteAutoinstall": True,
                    "retransmission": {
                        "attempt": 5,
                        "base": 2.5,
                        "timeout": 30
                    }
                }
            },
            "security": {
                "presharedKeys": [
                    {
                        "name": "psk-test",
                        "id": "test-id",
                        "secret": "test-secret",
                        "secretType": "plaintext"
                    },
                    {
                        "name": "psk-base64",
                        "id": "base64-id",
                        "secret": "dGVzdC1zZWNyZXQ=",
                        "secretType": "base64"
                    }
                ],
                "ikeGroups": [
                    {
                        "name": "ike-multi",
                        "keyExchange": "ikev2",
                        "lifetime": 28800,
                        "proposals": [
                            {
                                "proposal": 1,
                                "dhGroup": 14,
                                "encryption": "aes256",
                                "hash": "sha256"
                            },
                            {
                                "proposal": 2,
                                "dhGroup": 15,
                                "encryption": "aes128",
                                "hash": "sha1",
                                "prf": "sha256"
                            }
                        ],
                        "advanced": {
                            "disableMobike": True,
                            "ikev2Reauth": True,
                            "deadPeerDetection": {
                                "action": "restart",
                                "interval": 30,
                                "timeout": 120
                            }
                        }
                    }
                ],
                "espGroups": [
                    {
                        "name": "esp-advanced",
                        "lifetime": 3600,
                        "mode": "transport",
                        "pfs": "dh-group14",
                        "compression": True,
                        "disableRekey": True,
                        "lifeBytes": 1048576,
                        "lifePackets": 1000000,
                        "proposals": [
                            {
                                "proposal": 1,
                                "encryption": "aes256",
                                "hash": "sha256"
                            },
                            {
                                "proposal": 2,
                                "encryption": "aes128",
                                "hash": "sha1"
                            }
                        ]
                    }
                ]
            }
        }),
        "service": "ipsec"
    },
    id="test_ipsec_final_advanced_security"
)

test_final = [
    test_final_1,
    test_final_2,
    test_final_3,
    test_final_4,
]
