from app.core.routing import routing_bp
from flask import jsonify, request
from app.core.routing.models import AddableGeneralRoutingDTO, GeneralRouting, GeneralRoutingV6, VerifyGeneralRoutingDTO, GeneralRoutingMonitorDTO, UpdateGeneralRoutingDTO
from app.core.routing.parsers import parse_to_route_config, parse_to_route_config_system
from app.core.routing.service import is_route_existed_in_db
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.models import Interface
from app.auth.utils import login_required
from app.core.routing.flex.models import UpdateFlexRoutingDTO, FlexRoutingConfig
from app.core.routing.flex.parsers import parse_failover_routes_config, parse_to_failover_routes_config

from app.core.routing.ospf.models import UpdateOSPFDTO, OSPFConfig, VerifyOSPFDTO
from app.core.routing.ospf.parsers import parse_to_vyos_config, parse_to_vyos_config_verify
from app.core.routing.ospfv3.models import UpdateOSPFv3DTO, OSPFv3Config, VerifyOSPFv3DTO
from app.core.routing.ospfv3.parsers import parse_to_vyos_config as parse_to_vyos_config_v3, parse_to_vyos_config_verify as parse_to_vyos_config_verify_v3
from app.core.routing.rip.models import RIPConfig, UpdateRIPDTO, VerifyRIPDTO
from app.core.routing.rip.parsers import parse_to_vyos_config as parse_to_vyos_config_rip, parse_to_vyos_config_verify as parse_to_vyos_config_verify_rip
from app.core.routing.ripng.models import RIPngConfig, UpdateRIPngDTO, VerifyRIPngDTO
from app.core.routing.ripng.parsers import parse_to_vyos_config as parse_to_vyos_config_ripng, parse_to_vyos_config_verify as parse_to_vyos_config_verify_ripng
import pprint
from app.core.api.http.cmd.compare import compare_configs
from app.core.utils.decorator.route_decorator import Pipeline
admin_routing = Pipeline.admin(routing_bp)

@routing_bp.route('/general', methods=['GET'])
@login_required
def get_general_routing():
    data = GeneralRouting.query.all()
    data6 = GeneralRoutingV6.query.all()
    interfaces = Interface.get_interface_names()
    routes = [item.serialize() for item in data]
    routes6 = [item.serialize() for item in data6]
    return jsonify({
            "routes": routes,
            "routes6": routes6,
            "interfaces": interfaces
        }), 200


@routing_bp.route('/flex', methods=['GET'])
@login_required
def get_flex_routing():
    try:
        version = request.args.get('version', 'ipv4')
        if version not in ('ipv4', 'ipv6'):
            raise ValueError('Version must be ipv4 or ipv6')
        route_type = 'route6' if version == 'ipv6' else 'route'
        flex = FlexRoutingConfig.query.order_by(FlexRoutingConfig.id.desc()).first()
        config = {}
        routes = []
        if flex:
            payload = flex.serialize(route_type=route_type)
            config = payload.get('config') or {}
            routes = payload.get('routes') or []

        interfaces = Interface.get_interface_names()

        return jsonify({
            'routes': routes,
            'config': config,
            'interfaces': interfaces
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/general', methods=['PUT'])
def update_general_routing():
    try:
        data = UpdateGeneralRoutingDTO.model_validate_json(request.data)
        new_config = parse_to_route_config(data.model_dump())
        print("New config:")
        print(pprint.pformat(new_config, indent=2, width=80))

        # Current general routing
        current_config = {}
        if data.route_ver == 'ipv4':
            current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING)
        elif data.route_ver == 'ipv6':
            current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING_V6)
        print("Current general routing:")
        print(pprint.pformat(current_config, indent=2, width=80))

        # Diff new config with current config
        diff = compare_configs(new_config, current_config)

        print("Diff config:")
        print(pprint.pformat(diff, indent=2, width=80))
        
        r = []
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.GENERAL_ROUTING, 
            data={"current": current_config, "new": new_config, "diff": diff, "route_ver": data.route_ver}
        )

        # new_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING)
        # GeneralRouting.refresh(new_config, None)


        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            r.append(res)
            return jsonify(r), 200
        
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/flex', methods=['PUT'])
def update_flex_routing():
    try:
        data = UpdateFlexRoutingDTO.model_validate_json(request.data)
        new_config = parse_to_failover_routes_config(data.model_dump(by_alias=True))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FLEX_ROUTING,
                                          data={'route_ver': data.route_ver})

        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.FLEX_ROUTING,
            data={"current": current_config, "new": new_config, "diff": diff, "route_ver": data.route_ver}
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        
        return jsonify(res), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/general', methods=['DELETE'])
def delete_general_routing():
    return jsonify({'message': 'Success'}), 200


@admin_routing.route('/general/verify', methods=['POST'])
def verify_general_routing():
    from app.pkg.vyos.template import is_v4_dest_prefix, is_v6_dest_prefix, is_v4_nexthop, is_v6_nexthop

    def convert_to_number(value):
        try:
            return int(value)
        except ValueError:
            return False

    try:
        data = VerifyGeneralRoutingDTO.model_validate_json(request.data)
        new_config = data.model_dump()
        route_version = new_config.get("route_ver")
        route_id = new_config.get("route_id")
        all_routes = new_config.get("routes")
        
        verify_route = list(filter(lambda x: x.get("id") == route_id, all_routes))[0]
        
        if verify_route:
            dest_prefix = verify_route.get("dest_prefix")
            nexthop = verify_route.get("nexthop")
            distance_str = verify_route.get("distance")
            distance = convert_to_number(distance_str)
            
            # Check if route config is valid ipv4/ipv6
            if route_version == "v4":
                if dest_prefix and dest_prefix.strip() != "" and (not is_v4_dest_prefix(dest_prefix)):
                    return jsonify({"verify": "Invalid Destination Prefix"}), 400
                if nexthop and nexthop.strip() != "" and (not is_v4_nexthop(nexthop)):
                    return jsonify({"verify": "Invalid Nexthop"}), 400
            elif route_version == "v6":
                if dest_prefix and dest_prefix.strip() != "" and (not is_v6_dest_prefix(dest_prefix)):
                    return jsonify({"verify": "Invalid Destination Prefix"}), 400
                if nexthop and nexthop.strip() != "" and (not is_v6_nexthop(nexthop)):
                    return jsonify({"verify": "Invalid Nexthop"}), 400

            if distance_str.strip() != "" and not distance:
                return jsonify({"verify": "Distance must be between 1 and 255"}), 400
            if distance and (not 1 <= distance <= 255):
                return jsonify({"verify": "Distance must be between 1 and 255"}), 400

        route_config = parse_to_route_config_system(new_config)
        route_ver = new_config.get("route_ver")
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.GENERAL_ROUTING, data={"routes": route_config, "route_ver": route_ver})
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/general/monitor', methods=['POST'])
@login_required
def fetch_general_routing_monitor():
    try:
        data = GeneralRoutingMonitorDTO.model_validate_json(request.data)
        routes = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING_MONITOR, data=data.model_dump())
        return jsonify(routes), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@routing_bp.route('/general/addable', methods=['POST'])
@login_required
def check_if_route_addable():
    try:
        addable_data = AddableGeneralRoutingDTO.model_validate_json(request.data)
        data = addable_data.model_dump()
        existed = is_route_existed_in_db(data.get('route'), data.get('route_ver'))
        if existed is None:
            return jsonify({"id": None, "addable": True}), 200
        return jsonify({"id": existed.id, "addable": False}), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospf', methods=['GET'])
@login_required
def get_ospf():
    try:
        ospf_config = OSPFConfig.query.all()
        ospf = [item.serialize() for item in ospf_config]
        return jsonify(ospf), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@admin_routing.route('/ospf', methods=['PUT'])
def update_ospf():
    try:
        raw_data = request.data
        print("Raw OSPF request data:", raw_data)

        try:
            data = UpdateOSPFDTO.model_validate_json(raw_data)
        except Exception as validation_error:
            print(f"Validation error: {validation_error}")
            print(f"Request data type: {type(raw_data)}")
            print(f"Request data content: {raw_data}")
            return jsonify({'error': f'Validation error: {str(validation_error)}'}), 400

        if not isinstance(data, UpdateOSPFDTO):
            return jsonify({'error': 'Invalid data type after validation'}), 400

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OSPF)
        new_config = parse_to_vyos_config(data.model_dump())
        diff_config = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.OSPF,
            data={
                "current": current_config,
                "new": new_config,
                "diff": diff_config
            }
        )

        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except Exception as e:
        import traceback
        print("Error:", e)
        print("Traceback:", traceback.format_exc())
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/ospf/verify', methods=['POST'])
def verify_ospf():
    try:
        data = VerifyOSPFDTO.model_validate_json(request.data)
        verify_config = parse_to_vyos_config_verify(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.OSPF, data=verify_config)
        return jsonify(verify), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospf/restart', methods=['POST'])
@login_required
def restart_ospfd():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.OSPFD_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospf/monitor', methods=['GET'])
@login_required
def get_ospf_monitor():
    try:
        keyword = request.args.get('keyword').strip().lower()
        valid_keywords = {
            'overview',
            'border-routers',
            'database',
            'interface',
            'neighbor',
            'summary-address',
        }
        print("Keyword: ")
        print(keyword)

        if keyword not in valid_keywords:
            return jsonify({
                'error': f"Invalid OSPF monitor keyword '{keyword}'",
                'valid_keywords': sorted(valid_keywords),
            }), 400

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.OSPF_MONITOR,
            data={'keyword': keyword},
        )
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospfv3', methods=['GET'])
@login_required
def get_ospfv3():
    try:
        ospfv3_config = OSPFv3Config.query.all()
        ospfv3 = [item.serialize() for item in ospfv3_config]
        return jsonify(ospfv3), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@admin_routing.route('/ospfv3', methods=['PUT'])
def update_ospfv3():
    try:
        data = UpdateOSPFv3DTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OSPFv3)
        new_config = parse_to_vyos_config_v3(data.model_dump())
        diff_config = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.OSPFv3, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/ospfv3/verify', methods=['POST'])
def verify_ospfv3():
    try:
        data = VerifyOSPFv3DTO.model_validate_json(request.data)
        verify_config = parse_to_vyos_config_verify_v3(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.OSPFv3, data=verify_config)
        return jsonify(verify), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospfv3/restart', methods=['POST'])
@login_required
def restart_ospf6d():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.OSPF6D_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ospfv3/monitor', methods=['GET'])
@login_required
def get_ospfv3_monitor():
    try:
        keyword = (request.args.get('keyword') or 'overview').strip().lower()
        valid_keywords = {
            'overview',
            'database',
            'interface',
            'neighbor',
        }

        if keyword not in valid_keywords:
            return jsonify({
                'error': f"Invalid OSPFv3 monitor keyword '{keyword}'",
                'valid_keywords': sorted(valid_keywords),
            }), 400

        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.OSPFV3_MONITOR,
            data={'keyword': keyword},
        )
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/rip', methods=['GET'])
@login_required
def get_rip():
    try:
        rip_config = RIPConfig.query.all()
        rip = [item.serialize() for item in rip_config]
        return jsonify(rip), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@admin_routing.route('/rip', methods=['PUT'])
def update_rip():
    try:
        data = UpdateRIPDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.RIP)
        new_config = parse_to_vyos_config_rip(data.model_dump())
        diff_config = compare_configs(new_config, current_config)
        
        rip = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.RIP, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )
        
        # Refresh DB with new interface
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(rip, Exception):
            return jsonify({'error': str(rip)}), 400
        else:
            return jsonify(rip), 200
        
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/rip/verify', methods=['POST'])
def verify_rip():
    try:
        data = VerifyRIPDTO.model_validate_json(request.data)
        verify_config = parse_to_vyos_config_verify_rip(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.RIP, data=verify_config)
        return jsonify(verify), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/rip/restart', methods=['POST'])
@login_required
def restart_ripd():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.RIPD_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ripng', methods=['GET'])
@login_required
def get_ripng():
    try:
        ripng_config = RIPngConfig.query.all()
        ripng = [item.serialize() for item in ripng_config]
        return jsonify(ripng), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@admin_routing.route('/ripng', methods=['PUT'])
def update_ripng():
    try:
        data = UpdateRIPngDTO.model_validate_json(request.data)
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.RIPng)
        new_config = parse_to_vyos_config_ripng(data.model_dump())
        diff_config = compare_configs(new_config, current_config)
        
        ripng = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.RIPng, 
            data={
                "current": current_config, 
                "new": new_config,
                "diff": diff_config
            }
        )

        
        # Refresh DB with new interface
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(ripng, Exception):
            return jsonify({'error': str(ripng)}), 400
        else:
            return jsonify(ripng), 200
        
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@admin_routing.route('/ripng/verify', methods=['POST'])
def verify_ripng():
    try:
        data = VerifyRIPngDTO.model_validate_json(request.data)
        verify_config = parse_to_vyos_config_verify_ripng(data.model_dump())
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.RIPng, data=verify_config)
        return jsonify(verify), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/ripng/restart', methods=['POST'])
@login_required
def restart_ripngd():
    try:
        payload = request.get_json(silent=True) or {}
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.RIPNGD_RESTART, data=payload)
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        return jsonify(res), 200
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400
