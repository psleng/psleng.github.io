from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return str(value) not in ['', 'None']

class OSPFv3Command(Command):
    """Command class for OSPFv3 commands
    
    - set/delete protocols ospfv3 interface <intf-name>
    - set/delete protocols ospfv3 interface <intf-name> area <0-4294967295>
    - set/delete protocols ospfv3 interface <intf-name> cost <1-65535>
    - set/delete protocols ospfv3 interface <intf-name> dead-interval <1-65535>
    - set/delete protocols ospfv3 interface <intf-name> hello-interval <1-65535>
    - set/delete protocols ospfv3 interface <intf-name> ifmtu <1-65535>
    - set/delete protocols ospfv3 interface <intf-name> instance-id <0-255>
    - set/delete protocols ospfv3 interface <intf-name> mtu-ignore
    - set/delete protocols ospfv3 interface <intf-name> network {broadcast | point-to-point}
    - set/delete protocols ospfv3 interface <intf-name> passive
    - set/delete protocols ospfv3 interface <intf-name> priority <0-255>
    - set/delete protocols ospfv3 interface <intf-name> retransmit-interval <1-65535>
    - set/delete protocols ospfv3 interface <intf-name> transmit-delay <1-65535>
    - set/delete protocols ospfv3 redistribute connected
    - set/delete protocols ospfv3 redistribute connected metric <0-16777214>
    - set/delete protocols ospfv3 redistribute connected metric-type {1 | 2}
    - set/delete protocols ospfv3 redistribute kernel
    - set/delete protocols ospfv3 redistribute kernel metric <0-16777214>
    - set/delete protocols ospfv3 redistribute kernel metric-type {1 | 2}
    - set/delete protocols ospfv3 redistribute static
    - set/delete protocols ospfv3 redistribute static metric <0-16777214>
    - set/delete protocols ospfv3 redistribute static metric-type {1 | 2}
    - set/delete protocols ospfv3 auto-cost reference-bandwidth <1-4294967>
    - set/delete protocols ospfv3 default-information originate always
    - set/delete protocols ospfv3 default-information originate metric <0-16777214> 
    - set/delete protocols ospfv3 default-information originate metric-type <1 | 2>
    - set/delete protocols ospfv3 log-adjacency-changes detail
    - set/delete protocols ospfv3 parameters router-id <x.x.x.x>
    - set/delete protocols ospfv3 distance global <1-255>
    - set/delete protocols ospfv3 distance ospfv3 external <1-255>
    - set/delete protocols ospfv3 distance ospfv3 inter-area <1-255>
    - set/delete protocols ospfv3 distance ospfv3 intra-area <1-255>
    - set/delete protocols ospfv3 graceful-restart
    - set/delete protocols ospfv3 graceful-restart grace-period <1-1800>
    - set/delete protocols ospfv3 area <area-num> range <h:h:h:h:h:h:h:h/x>
    - set/delete protocols ospfv3 area <area-num> range <h:h:h:h:h:h:h:h/x> advertise
    - set/delete protocols ospfv3 area <area-num> area-type nssa 
    - set/delete protocols ospfv3 area <area-num> area-type nssa default-information-originate
    - set/delete protocols ospfv3 area <area-num> area-type nssa no-summary 
    - set/delete protocols ospfv3 area <area-num> area-type stub
    - set/delete protocols ospfv3 area <area-num> area-type stub no-summary
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'ospfv3'))
            self.attributes = {
                'protocols': {
                    'ospfv3': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing OSPFv3 cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.attributes['protocols']['ospfv3'] = data
            
            if 'area' in data:
                self._process_area_config(data['area'], current_config, new_config)
            
            if 'interface' in data:
                self._process_interface_config(data['interface'], current_config, new_config)
            
            if 'redistribute' in data:
                self._process_redistribute_config(data['redistribute'], current_config, new_config)
            
            self._process_global_parameters(data)
            
            if 'parameters' in data:
                self._process_parameters_config(data['parameters'])
            
            if 'default-information' in data:
                self._process_default_information_config(data['default-information'])
            
            if 'distance' in data:
                self._process_distance_config(data['distance'])
            
            if 'graceful-restart' in data:
                self._process_graceful_restart_config(data['graceful-restart'])
            
            print(f"Generated OSPFv3 commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating OSPFv3 commands: {e}")
            return []
    
    def _process_area_config(self, area_config, current_config, new_config):
        for area_num, area_data in area_config.items():
            base_path = ['protocols', 'ospfv3', 'area', str(area_num)]

            if self.operator == 'delete' and area_num not in new_config.get('area', {}):
                self.generate(*base_path)
                continue
            
            if 'range' in area_data:
                self._process_area_range_config(base_path, area_data['range'], current_config, new_config, area_num)
            
            if 'area-type' in area_data:
                self._process_area_type_config(base_path, area_data['area-type'])
    
    def _process_area_range_config(self, base_path, range_config, current_config, new_config, area_num):
        for range_prefix, range_data in range_config.items():
            range_path = base_path + ['range', range_prefix]

            if self.operator == 'delete' and \
                range_prefix not in new_config.get('area', {}).get(str(area_num), {}).get('range', {}):
                self.generate(*range_path)
                continue
            
            self.generate(*range_path)
            
            if isinstance(range_data, dict) and 'advertise' in range_data:
                self.generate(*range_path, 'advertise')
    
    def _process_area_type_config(self, base_path, area_type_config):
        area_type_path = base_path + ['area-type']
        
        if 'normal' in area_type_config:
            self.generate(*area_type_path, 'normal')
        
        if 'nssa' in area_type_config:
            nssa_path = area_type_path + ['nssa']
            nssa_data = area_type_config['nssa']
            
            self.generate(*nssa_path)
            
            if isinstance(nssa_data, dict):
                if 'default-information-originate' in nssa_data:
                    self.generate(*nssa_path, 'default-information-originate')
                
                if 'no-summary' in nssa_data:
                    self.generate(*nssa_path, 'no-summary')
        
        if 'stub' in area_type_config:
            stub_path = area_type_path + ['stub']
            stub_data = area_type_config['stub']
            
            self.generate(*stub_path)
            
            if isinstance(stub_data, dict) and 'no-summary' in stub_data:
                self.generate(*stub_path, 'no-summary')
    
    def _process_interface_config(self, interface_config, current_config, new_config):
        for intf_name, intf_data in interface_config.items():
            base_path = ['protocols', 'ospfv3', 'interface', intf_name]

            if self.operator == 'delete' and intf_name not in new_config.get('interface', {}):
                self.generate(*base_path)
                continue
            
            self.generate(*base_path)
            
            if 'area' in intf_data and is_str_not_empty(intf_data['area']):
                self.generate(*base_path, 'area', str(intf_data['area']))
            
            if 'cost' in intf_data and is_str_not_empty(intf_data['cost']):
                self.generate(*base_path, 'cost', str(intf_data['cost']))
            
            if 'dead-interval' in intf_data and is_str_not_empty(intf_data['dead-interval']):
                self.generate(*base_path, 'dead-interval', str(intf_data['dead-interval']))
            
            if 'hello-interval' in intf_data and is_str_not_empty(intf_data['hello-interval']):
                self.generate(*base_path, 'hello-interval', str(intf_data['hello-interval']))
            
            if 'ifmtu' in intf_data and is_str_not_empty(intf_data['ifmtu']):
                self.generate(*base_path, 'ifmtu', str(intf_data['ifmtu']))
            
            if 'instance-id' in intf_data and is_str_not_empty(intf_data['instance-id']):
                self.generate(*base_path, 'instance-id', str(intf_data['instance-id']))
            
            if 'mtu-ignore' in intf_data:
                self.generate(*base_path, 'mtu-ignore')
            
            if 'network' in intf_data and is_str_not_empty(intf_data['network']):
                self.generate(*base_path, 'network', intf_data['network'])
            
            if 'passive' in intf_data:
                self.generate(*base_path, 'passive')
            
            if 'priority' in intf_data and is_str_not_empty(intf_data['priority']):
                self.generate(*base_path, 'priority', str(intf_data['priority']))
            
            if 'retransmit-interval' in intf_data and is_str_not_empty(intf_data['retransmit-interval']):
                self.generate(*base_path, 'retransmit-interval', str(intf_data['retransmit-interval']))
            
            if 'transmit-delay' in intf_data and is_str_not_empty(intf_data['transmit-delay']):
                self.generate(*base_path, 'transmit-delay', str(intf_data['transmit-delay']))
    
    def _process_redistribute_config(self, redistribute_config, current_config, new_config):
        for protocol, protocol_data in redistribute_config.items():
            base_path = ['protocols', 'ospfv3', 'redistribute', protocol]
            
            if self.operator == 'delete' and protocol not in new_config.get('redistribute', {}):
                self.generate(*base_path)
                continue
            
            if not protocol_data or protocol_data == {}:
                self.generate(*base_path)
                continue
            
            if 'metric' in protocol_data and is_str_not_empty(protocol_data['metric']):
                self.generate(*base_path, 'metric', str(protocol_data['metric']))
            
            if 'metric-type' in protocol_data and is_str_not_empty(protocol_data['metric-type']):
                self.generate(*base_path, 'metric-type', str(protocol_data['metric-type']))
    
    def _process_global_parameters(self, data):
        base_path = ['protocols', 'ospfv3']
        
        if 'auto-cost' in data and 'reference-bandwidth' in data['auto-cost']:
            if is_str_not_empty(data['auto-cost']['reference-bandwidth']):
                self.generate(*base_path, 'auto-cost', 'reference-bandwidth', str(data['auto-cost']['reference-bandwidth']))
        
        if 'log-adjacency-changes' in data:
            if 'detail' in data['log-adjacency-changes']:
                self.generate(*base_path, 'log-adjacency-changes', 'detail')
    
    def _process_parameters_config(self, parameters_config):
        base_path = ['protocols', 'ospfv3', 'parameters']
        
        if 'router-id' in parameters_config and is_str_not_empty(parameters_config['router-id']):
            self.generate(*base_path, 'router-id', parameters_config['router-id'])
    
    def _process_default_information_config(self, default_info_config):
        base_path = ['protocols', 'ospfv3', 'default-information', 'originate']
        
        if 'always' in default_info_config:
            self.generate(*base_path, 'always')
        
        if 'metric' in default_info_config and is_str_not_empty(default_info_config['metric']):
            self.generate(*base_path, 'metric', str(default_info_config['metric']))
        
        if 'metric-type' in default_info_config and is_str_not_empty(default_info_config['metric-type']):
            self.generate(*base_path, 'metric-type', str(default_info_config['metric-type']))
    
    def _process_distance_config(self, distance_config):
        base_path = ['protocols', 'ospfv3', 'distance']
        
        if 'global' in distance_config and is_str_not_empty(distance_config['global']):
            self.generate(*base_path, 'global', str(distance_config['global']))
        
        if 'ospf' in distance_config:
            ospf_distance = distance_config['ospf']
            ospf_path = base_path + ['ospfv3']
            
            if 'external' in ospf_distance and is_str_not_empty(ospf_distance['external']):
                self.generate(*ospf_path, 'external', str(ospf_distance['external']))
            
            if 'inter-area' in ospf_distance and is_str_not_empty(ospf_distance['inter-area']):
                self.generate(*ospf_path, 'inter-area', str(ospf_distance['inter-area']))
            
            if 'intra-area' in ospf_distance and is_str_not_empty(ospf_distance['intra-area']):
                self.generate(*ospf_path, 'intra-area', str(ospf_distance['intra-area']))
    
    def _process_graceful_restart_config(self, graceful_restart_config):
        base_path = ['protocols', 'ospfv3', 'graceful-restart']
        
        if not graceful_restart_config or graceful_restart_config == {} or graceful_restart_config is True:
            self.generate(*base_path)
            return
        
        if 'grace-period' in graceful_restart_config and is_str_not_empty(graceful_restart_config['grace-period']):
            self.generate(*base_path, 'grace-period', str(graceful_restart_config['grace-period']))