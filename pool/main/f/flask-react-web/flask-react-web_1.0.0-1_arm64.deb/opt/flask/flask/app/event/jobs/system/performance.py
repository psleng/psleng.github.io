from app.core.operation.system_performance import salt_load_system_memory_json
from app.core.models import Memory, Storage
from app.core.salt.master import get_memory, get_cpu
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.config import global_config


def fetch_memory(app_context):
    try:
        print("[TASK] Fetch Memory")
        refresh_db_memory_operation(app_context=app_context)
    except Exception as e:
        print('Error fetch memory', str(e))


def fetch_storage(app_context):
    try:
        print("[TASK] Fetch Storage")
        refresh_db_storage_operation(app_context=app_context)
    except Exception as e:
        print('Error fetch storage', str(e))


def refresh_db_storage_operation(app_context=None):
    try:
        print("[TASK] Fetch Storage")
        storage = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_STORAGE, data={})
        if isinstance(storage, dict):
            print("[TASK] Update Storage")
            if app_context is not None:
                with app_context:
                    Storage.refresh(storage)
            else:
                Storage.refresh(storage)
        return storage
    except Exception as e:
        print(str(e))
        return None



def refresh_db_memory_operation(app_context=None):
    try:
        if app_context is not None:
            with app_context:
                # Query in VyOS and cached storage table
                print("[TASK] Fetch Memory")
                memory = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_MEMORY, data={})
                print("[TASK] Update Memory")
                Memory.refresh(memory)
        else:
            # Query in VyOS and cached storage table
            print("[TASK] Fetch Memory")
            memory = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_MEMORY, data={})
            print("[TASK] Update Memory")
            Memory.refresh(memory)
        memory = None
        return memory
    except Exception as e:
        print(str(e))
        return None
    
    
def salt_fetch_memory(app_context):
    try:
        print("[TASK] Fetch Memory")
        with app_context:
            salt_refresh_db_memory_operation(minion='hostNameVyOS-1')
    except Exception as e:
        print('Error fetch memory', str(e))



def salt_refresh_db_memory_operation(minion):
    try:
        # Query in VyOS
        data = get_memory(minion)
        memory = salt_load_system_memory_json(minion, data)
        # Update db
        # Memory.refresh(memory)
        return memory
    except Exception as e:
        print(str(e))
        return str(e)
    

def salt_fetch_cpu(minion):
    try:
        cpu = get_cpu(minion).get(minion)
        return cpu
    
    except Exception as e:
        return str(e)
