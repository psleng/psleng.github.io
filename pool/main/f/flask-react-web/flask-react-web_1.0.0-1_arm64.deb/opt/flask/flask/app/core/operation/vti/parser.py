
def get_highest_vti_number(data):
    """
    Get the highest VTI interface number from the VyOS configuration data.
    
    Args:
        data: Dictionary containing VTI interface configuration
              Format: {'vti': {'vti1': {...}, 'vti2': {...}}}
    
    """
    print("VTI Data: ")
    print(data)

    if not data or 'vti' not in data or not data['vti']:
        return "vti0"
    
    vti_interfaces = data['vti']
    highest_num = -1
    highest_vti = "vti0"
    
    for vti_name in vti_interfaces.keys():
        if vti_name.startswith('vti'):
            try:
                num = int(vti_name.replace('vti', ''))
                if num > highest_num:
                    highest_num = num
                    highest_vti = vti_name
            except ValueError:
                continue
    
    return highest_vti

