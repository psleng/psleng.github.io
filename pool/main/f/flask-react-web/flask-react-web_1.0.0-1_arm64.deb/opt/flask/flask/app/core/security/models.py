from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Float, BigInteger, Text, DateTime
from pydantic import BaseModel, RootModel, field_validator, Field, ConfigDict
from typing import Optional
from app.core.security.parser.firewall import convert_to_CIDR
from datetime import datetime

def format_description(desc: str) -> str:
    # Replace underscores with spaces if any
    if not desc:
        return ""
    return desc.replace('_', ' ')

class FirewallOperationLog(db.Model):
    __tablename__ = "vyos_firewall_operation_log"

    id = Column(Integer, primary_key=True)
    ip_version = Column(String(50), nullable=True)
    priority = Column(String(50), nullable=True)
    interface_in = Column(String(50), nullable=True)
    interface_out = Column(String(50), nullable=True)
    source = Column(String(255), nullable=True)
    destination = Column(String(255), nullable=True)
    source_port = Column(String(255), nullable=True)
    destination_port = Column(String(255), nullable=True)
    protocol = Column(String(50), nullable=True)
    bytes = Column(BigInteger, nullable=False, default=0)
    timestamp = Column(DateTime, nullable=True)

    @classmethod
    def truncate(cls):
        """Remove all existing records from the table."""
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        """Refresh Firewall Operation Log data in the database.

        Args:
            data: Dictionary containing firewall log entries with attributes:
                - interface: Interface name
                - source: Source address
                - destination: Destination address
                - protocol: Protocol
                - action: Action
                - rule_number: Rule number
                - packets: Packets count
                - bytes: Bytes count
                - conditions: Additional conditions
        """
        print("Refreshing Firewall Operation Log data")
        cls.truncate()
        
        new_records = []
        for log_entry in data.get('logs', []):
            new_record = cls(
                interface=log_entry.get('interface'),
                source=log_entry.get('source'),
                destination=log_entry.get('destination'),
                protocol=log_entry.get('protocol'),
                action=log_entry.get('action'),
                rule_number=log_entry.get('rule_number'),
                packets=log_entry.get('packets', 0),
                bytes=log_entry.get('bytes', 0),
                conditions=log_entry.get('conditions')
            )
            new_records.append(new_record)

        if new_records:
            db.session.bulk_save_objects(new_records)
            db.session.commit()

    def serialize(self):
        """Serialize the firewall operation log entry to a dictionary."""
        return {
            'id': self.id,
            'interface': self.interface,
            'source': self.source,
            'destination': self.destination,
            'protocol': self.protocol,
            'action': self.action,
            'rule_number': self.rule_number,
            'packets': self.packets,
            'bytes': self.bytes,
            'conditions': self.conditions,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

    @classmethod
    def get_all_serialized(cls):
        """Get all firewall operation log records."""
        records = cls.query.order_by(cls.timestamp.desc()).all()
        return {
            'logs': [record.serialize() for record in records]
        }

class FirewallOperation(db.Model):
    __tablename__ = "vyos_firewall_operation"

    id = Column(Integer, primary_key=True)
    ip_version = Column(String(4), nullable=False)
    ruleset_name = Column(String(255), nullable=False)
    rule_number = Column(String(50), nullable=False)
    action = Column(String(50), nullable=False)
    protocol = Column(String(50), nullable=False)
    packets = Column(BigInteger, nullable=False, default=0)
    bytes = Column(BigInteger, nullable=False, default=0)
    conditions = Column(Text, nullable=True)

    @classmethod
    def truncate(cls):
        """Remove all existing records from the table."""
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        """Refresh the firewall operation data in the database.
        
        Args:
            data (dict): Parsed firewall operation data from parse_firewall_operation
        """
        print("Refreshing Firewall Operation data")
        if app_context is not None:
            with app_context:
                cls.truncate()
        else:
            cls.truncate()
        
        new_records = []
        for ip_version, rulesets in data.items():
            for ruleset_name, ruleset_data in rulesets.items():
                for rule in ruleset_data.get('rules', []):
                    new_record = cls(
                        ip_version=ip_version,
                        ruleset_name=ruleset_name,
                        rule_number=rule['rule_number'],
                        action=rule['action'],
                        protocol=rule['protocol'],
                        packets=rule['packets'],
                        bytes=rule['bytes'],
                        conditions=rule.get('conditions', '')
                    )
                    new_records.append(new_record)
        
        if new_records:
            if app_context is not None:
                with app_context:
                    db.session.bulk_save_objects(new_records)
                    db.session.commit()
            else:
                db.session.bulk_save_objects(new_records)
                db.session.commit()

    def serialize(self):
        """Serialize the firewall operation data to a dictionary."""
        return {
            'id': self.id,
            'ip_version': self.ip_version,
            'ruleset_name': self.ruleset_name,
            'rule_number': self.rule_number,
            'action': self.action,
            'protocol': self.protocol,
            'packets': self.packets,
            'bytes': self.bytes,
            'conditions': self.conditions,
        }

    @classmethod
    def get_all_serialized(cls):
        """Get all firewall operation records in a structured format."""
        records = cls.query.all()
        result = {
            'global-options':{},
            'ipv4': {},
            'ipv6': {}
        }
        
        for record in records:
            ip_version = record.ip_version
            ruleset_name = record.ruleset_name
            
            if ruleset_name not in result[ip_version]:
                result[ip_version][ruleset_name] = {
                    'rules': []
                }
            
            result[ip_version][ruleset_name]['rules'].append({
                'rule_number': record.rule_number,
                'action': record.action,
                'protocol': record.protocol,
                'packets': record.packets,
                'bytes': record.bytes,
                'conditions': record.conditions
            })
            
        return result

class Firewallv4(db.Model):
    __tablename__ = "firewall_v4"

    id = Column(Integer, primary_key=True, autoincrement=True)
    firewall_type = Column(String, nullable=True)  # 'prerouting' or 'output'
    rule_number = Column(Integer, nullable=True)
    action = Column(String, nullable=True)
    enabled = Column(Boolean, nullable=True)
    log_enabled = Column(Boolean, nullable=True)
    description = Column(String, nullable=True)
    protocol = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    source_address = Column(String, nullable=True)
    source_subnet = Column(String, nullable=True)
    source_port = Column(String, nullable=True)
    source_mac = Column(String, nullable=True)
    destination_address = Column(String, nullable=True)
    destination_subnet = Column(String, nullable=True)
    destination_port = Column(String, nullable=True)
    destination_mac = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
            db.session.query(cls).delete()
            db.session.commit()

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        """Refresh the IPv4 firewall rules in the database
        
        Args:
            data (dict): Firewall configuration data
        """
        print("Refreshing IPv4 firewall rules...")

        try:
            # Clear current data
            cls.truncate()

            if not data or 'ipv4' not in data:
                if app_context is not None:
                    with app_context:
                        db.session.commit()
                else:
                    db.session.commit()
                return

            ipv4_data = data['ipv4']
            
            # Process each firewall type (prerouting/output)
            for firewall_type in ipv4_data:
                if 'raw' not in ipv4_data[firewall_type]:
                    continue
                
                raw_config = ipv4_data[firewall_type]['raw']
                
                # Process rules
                if 'rule' in raw_config:
                    for rule_number, rule_data in raw_config['rule'].items():
                        new_rule = cls()
                        new_rule.firewall_type = firewall_type
                        new_rule.rule_number = int(rule_number)
                        new_rule.action = rule_data.get('action')
                        new_rule.enabled = True if 'disable' not in rule_data else False
                        new_rule.log_enabled = True if 'log' in rule_data else False
                        new_rule.description = rule_data.get('description')
                        new_rule.protocol = rule_data.get('protocol')
                        
                        # Process source configuration
                        if 'source' in rule_data:
                            source = rule_data['source']
                            new_rule.source_address = source.get('address')
                            new_rule.source_subnet = convert_to_CIDR(source.get('address-mask'))
                            new_rule.source_port = source.get('port')
                            new_rule.source_mac = source.get('mac-address')
                        
                        # Process destination configuration
                        if 'destination' in rule_data:
                            dest = rule_data['destination']
                            new_rule.destination_address = dest.get('address')
                            new_rule.destination_subnet = convert_to_CIDR(dest.get('address-mask'))
                            new_rule.destination_port = dest.get('port')
                            new_rule.destination_mac = dest.get('mac-address')
                        
                        # Process interface
                        if 'inbound-interface' in rule_data:
                            new_rule.interface = rule_data['inbound-interface'].get('name')

                        if 'outbound-interface' in rule_data:
                            new_rule.interface = rule_data['outbound-interface'].get('name')
                        
                        if app_context is not None:
                            with app_context:
                                db.session.add(new_rule)
                        else:
                            db.session.add(new_rule)
            
            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
        except Exception as e:
            print(f"Error refreshing Firewallv4 data: {e}")

    def serialize(self):
        return {
            "id": self.id,
            "firewall_type": self.firewall_type,
            "rule_number": self.rule_number,
            "action": self.action,
            "enabled": self.enabled,
            "log_enabled": self.log_enabled,
            "description": format_description(self.description) if self.description else "",
            "protocol": self.protocol,
            "interface": self.interface,
            "source_address": self.source_address,
            "source_subnet": self.source_subnet,
            "source_port": self.source_port,
            "source_mac": self.source_mac,
            "destination_address": self.destination_address,
            "destination_subnet": self.destination_subnet,
            "destination_port": self.destination_port,
            "destination_mac": self.destination_mac
        }

class Firewallv6(db.Model):
    __tablename__ = "firewall_v6"

    id = Column(Integer, primary_key=True)
    firewall_type = Column(String, nullable=True)  # 'prerouting' or 'output'
    rule_number = Column(Integer, nullable=True)
    action = Column(String, nullable=True)
    enabled = Column(Boolean, nullable=True)
    log_enabled = Column(Boolean, nullable=True)
    description = Column(String, nullable=True)
    protocol = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    source_address = Column(String, nullable=True)
    source_subnet = Column(String, nullable=True)
    source_port = Column(String, nullable=True)
    source_mac = Column(String, nullable=True)
    destination_address = Column(String, nullable=True)
    destination_subnet = Column(String, nullable=True)
    destination_port = Column(String, nullable=True)
    destination_mac = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        """Refresh the IPv6 firewall rules in the database
        
        Args:
            data (dict): Firewall configuration data
        """
        # Clear current data
        if app_context is not None:
            with app_context:
                cls.truncate()
        else:
            cls.truncate()

        try:
            if not data or 'ipv6' not in data:
                if app_context is not None:
                    with app_context:
                        db.session.commit()
                else:
                    db.session.commit()
                return

            ipv6_data = data['ipv6']
            
            # Process each firewall type (prerouting/output)
            for firewall_type in ipv6_data:
                if 'raw' not in ipv6_data[firewall_type]:
                    continue
                
                raw_config = ipv6_data[firewall_type]['raw']
                
                # Process rules
                if 'rule' in raw_config:
                    for rule_number, rule_data in raw_config['rule'].items():
                        new_rule = cls()
                        new_rule.firewall_type = firewall_type
                        new_rule.rule_number = int(rule_number)
                        new_rule.action = rule_data.get('action')
                        new_rule.enabled = True if 'disable' not in rule_data else False
                        new_rule.log_enabled = True if 'log' in rule_data else False
                        new_rule.description = rule_data.get('description')
                        new_rule.protocol = rule_data.get('protocol')
                        
                        # Process source configuration
                        if 'source' in rule_data:
                            source = rule_data['source']
                            new_rule.source_address = source.get('address')
                            new_rule.source_subnet = source.get('address-mask')
                            new_rule.source_port = source.get('port')
                            new_rule.source_mac = source.get('mac-address')
                        
                        # Process destination configuration
                        if 'destination' in rule_data:
                            dest = rule_data['destination']
                            new_rule.destination_address = dest.get('address')
                            new_rule.destination_subnet = dest.get('address-mask')
                            new_rule.destination_port = dest.get('port')
                            new_rule.destination_mac = dest.get('mac-address')
                        
                        # Process interface
                        if 'inbound-interface' in rule_data:
                            new_rule.interface = rule_data['inbound-interface'].get('name')

                        if 'outbound-interface' in rule_data:
                            new_rule.interface = rule_data['outbound-interface'].get('name')
                        
                        if app_context is not None:
                            with app_context:
                                db.session.add(new_rule)
                        else:
                            db.session.add(new_rule)

            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
        except Exception as e:
            print(f"Error refreshing Firewallv6 data: {e}")

    def serialize(self):
        return {
            "id": self.id,
            "firewall_type": self.firewall_type,
            "rule_number": self.rule_number,
            "action": self.action,
            "enabled": self.enabled,
            "log_enabled": self.log_enabled,
            "description": self.description,
            "protocol": self.protocol,
            "interface": self.interface,
            "source_address": self.source_address,
            "source_subnet": self.source_subnet,
            "source_port": self.source_port,
            "source_mac": self.source_mac,
            "destination_address": self.destination_address,
            "destination_subnet": self.destination_subnet,
            "destination_port": self.destination_port,
            "destination_mac": self.destination_mac
        }

class FirewallSettings(db.Model):
    __tablename__ = "firewall_settings"

    id = Column(Integer, primary_key=True)
    ipv4_ping = Column(String, nullable=True)
    invalid_address = Column(String, nullable=True)
    established = Column(String, nullable=True)
    invalid = Column(String, nullable=True)
    related = Column(String, nullable=True)
    description = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
            db.session.query(cls).delete()
            db.session.commit()

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        """Refresh the advanced settings in the database
        
        Args:
            data (dict): Firewall configuration data
        """
        print("Refreshing advanced settings...")

        try:
            # Clear current data
            cls.truncate()

            global_opts = None
            if isinstance(data.get('firewall'), dict):
                global_opts = data['firewall'].get('global_options') or data['firewall'].get('global-options')
            if not global_opts:
                global_opts = data.get('global-options') or data.get('global_options')

            if not global_opts or not isinstance(global_opts, dict):
                if app_context is not None:
                    with app_context:
                        db.session.commit()
                else:
                    db.session.commit()
                return

            def _get_all_ping(opts):
                # (string): 'enable' / 'disable'
                val = opts.get('all-ping')
                if isinstance(val, str):
                    return "Disabled" if val == 'disable' else "Enabled" if val == 'enable' else ""
                # (nested dict): {'disable': {}} / {'enable': {}}
                val = opts.get('all_ping')
                if isinstance(val, dict):
                    if 'disable' in val:
                        return "Disabled"
                    if 'enable' in val:
                        return "Enabled"
                return ""

            def _get_log_martians(opts):
                # (string): 'enable' / 'disable'
                val = opts.get('log-martians')
                if isinstance(val, str):
                    return "Disabled" if val == 'disable' else "Enabled" if val == 'enable' else ""
                # (nested dict): {'disable': {}} / {'enable': {}}
                val = opts.get('log_martians')
                if isinstance(val, dict):
                    if 'disable' in val:
                        return "Disabled"
                    if 'enable' in val:
                        return "Enabled"
                return ""

            new_settings = cls()
            new_settings.ipv4_ping = _get_all_ping(global_opts)
            new_settings.invalid_address = _get_log_martians(global_opts)

            state_policy = global_opts.get('state-policy') or global_opts.get('state_policy') or {}

            def _get_state_action(sp, key):
                node = sp.get(key) or {}
                if not isinstance(node, dict):
                    return ""
                return (node.get('action') or "").lower()

            new_settings.established = _get_state_action(state_policy, 'established')
            new_settings.invalid = _get_state_action(state_policy, 'invalid')
            new_settings.related = _get_state_action(state_policy, 'related')
            
            if app_context is not None:
                with app_context:
                    db.session.add(new_settings)
            else:
                db.session.add(new_settings)

            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            
            
        except Exception as e:
            print(f"Error refreshing Firewallv4 data: {e}")

    def serialize(self):
        return {
            "packetHandling": {
                "ipv4_ping": self.ipv4_ping or "",
                "invalid_address": self.invalid_address or "",
            },
            "statePolicy": {
                "established": (self.established or "").capitalize(),
                "invalid": (self.invalid or "").capitalize(),
                "related": (self.related or "").capitalize(),
            },
        }


class FirewallRule(BaseModel):
    action: str
    enabled: Optional[bool] = None
    log_enabled: Optional[bool] = None
    description: Optional[str] = None
    protocol: Optional[str] = None
    interface: Optional[str] = None
    source: Optional[str] = None
    destination: Optional[str] = None
    source_address: Optional[str] = None
    source_subnet: Optional[str] = None
    source_port: Optional[str] = None
    source_mac: Optional[str] = None
    destination_address: Optional[str] = None
    destination_subnet: Optional[str] = None
    destination_port: Optional[str] = None
    destination_mac: Optional[str] = None
    rule_number: str | int
    firewall_type: str

class FirewallModel(BaseModel):
    inbound: list[FirewallRule] = []
    outbound: list[FirewallRule] = []

class PacketHandling(BaseModel):
    ipv4_ping: Optional[str] = ""
    invalid_address: Optional[str] = "" 

class StatePolicy(BaseModel):
    established: Optional[str] = ""
    invalid: Optional[str] = "" 
    related: Optional[str] = "" 


class AdvancedSettings(BaseModel):
    packetHandling: PacketHandling
    statePolicy: StatePolicy

class UpdateFirewallDTO(BaseModel):

    firewallv4: FirewallModel
    firewallv6: FirewallModel
    advancedSettings: Optional[AdvancedSettings] = None
    zoneBasedFirewall: Optional[list] = []

class VerifyFirewallDTO(BaseModel):
    firewallv4: FirewallModel
    firewallv6: FirewallModel
