from copy import deepcopy


def parse_hostname_mappings(config):
    mappings = []
    for hostname, entry in (config.get('static-host-mapping', {}).get('host-name', {}) or {}).items():
        mapping = {'hostname': hostname}
        for field in ('inet', 'alias'):
            value = entry.get(field) or ''
            if isinstance(value, list):
                if len(value) > 1:
                    raise ValueError(f'{hostname} has multiple {field} values; this editor supports one per hostname.')
                value = value[0] if value else ''
            mapping[field] = value
        mappings.append(mapping)
    return sorted(mappings, key=lambda mapping: mapping['hostname'])


def parse_to_hostname_mapping_config(mappings):
    return {'host-name': {
        entry['hostname']: {
            field: entry[field] for field in ('inet', 'alias') if entry.get(field)
        }
        for entry in mappings
    }}


def _as_list(value):
    return value if isinstance(value, list) else [value] if value else []


def parse_to_hostname_mapping_verify_config(config, current=None):
    if current is None:
        current = {'hostname': 'vyos', 'nameservers_dhcp_interfaces': {}}
    if not isinstance(current, dict) or not current.get('hostname'):
        raise ValueError('Unable to read the system hostname configuration for verification.')
    result = deepcopy(current)
    result['static_host_mapping'] = {
        hostname: {
            'address': _as_list(entry.get('inet')),
            'aliases': _as_list(entry.get('alias')),
        }
        for hostname, entry in (config.get('host-name') or {}).items()
    }
    return result


def parse_hostname_mapping_command_config(current):
    return {'system': {'static_host_mapping': {'host_name': {
        hostname.replace('-', '_'): {'inet': entry.get('address', []), 'alias': entry.get('aliases', [])}
        for hostname, entry in current.get('static_host_mapping', {}).items()
    }}}}


def parse_merged_hostname_mapping_config(merged, hostnames):
    names = {hostname.replace('-', '_'): hostname for hostname in hostnames}
    entries = merged.get('system', {}).get('static_host_mapping', {}).get('host_name', {})
    return {'host-name': {names.get(hostname, hostname): entry for hostname, entry in entries.items()}}
