from dataclasses import dataclass
from pathlib import Path


DEFINITION_DIR = Path(__file__).resolve().parent / "def"


@dataclass(frozen=True)
class DefinitionSpec:
    namespace: str
    name: str
    filename: str
    reader: str
    source: str


DEFINITIONS = (
    DefinitionSpec("ssh", "cipher", "ssh-cipher.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/service/ssh/cipher/node.def"),
    DefinitionSpec("ssh", "hostkey-algorithm", "ssh-hostkey-algorithm.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/service/ssh/hostkey-algorithm/node.def"),
    DefinitionSpec("ssh", "key-exchange", "ssh-key-exchange.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/service/ssh/key-exchange/node.def"),
    DefinitionSpec("ssh", "mac", "ssh-mac.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/service/ssh/mac/node.def"),
    DefinitionSpec("ssh", "pubkey-accepted-algorithm", "ssh-pubkey-accepted-algorithm.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/service/ssh/pubkey-accepted-algorithm/node.def"),
    DefinitionSpec("aaa", "public-key-type", "aaa-public-key-type.def", "ssh",
                   "/opt/vyatta/share/vyatta-cfg/templates/system/login/user/node.tag/authentication/public-keys/node.tag/type/node.def"),
)
