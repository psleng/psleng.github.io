import os
from dataclasses import dataclass
from enum import Enum, StrEnum
from app.config import global_config
from dotenv import load_dotenv
import requests
from sqlalchemy.cyextension.resultproxy import operator
from typing import overload
import json
from app.core.api.api import API_REQUEST
# from .cmd import SHOW_ALL_CONFIGS
from app.log.logger import logger
from flask import has_app_context, has_request_context, session as sess
from flask import current_app
from typing import Optional
from app.core.api.http.task_queue import vyos_task_queue
from app.event.jobs.system.save_config import record_successful_config_change

SHOW_ALL_CONFIGS = '{"op": "showConfig", "path": []}'
SHOW_INTERFACE_CONFIGS = '{"op": "showConfig", "path": ["interfaces"]}'
SHOW_SAML_CONFIG = '{"op": "showConfig", "path": ["system", "login", "saml"]}'
class Action(Enum):
    RETRIEVE = 1
    RESET = 2
    REBOOT = 3
    POWER_OFF = 4
    IMAGE = 5
    SHOW = 6
    GENERATE = 7
    CONFIGURE = 8
    CONFIG_FILE = 9
    AUTH = 10

class Method(StrEnum):
    POST = "POST"
    PUT = "PUT"
    GET = "GET"
    DELETE = "DELETE"


class HTTPRequest(API_REQUEST):

    @classmethod
    def get_finished_queue(cls):
        return vyos_task_queue.get_finished_queue()

    @classmethod
    def get_task(cls, task_id: str):
        return vyos_task_queue.get_task(task_id)

    def __init__(self, hostname=None, apikey=None, port=None, protocol=None):
        super().__init__()
        load_dotenv()
        self.url = None
        if hostname and apikey and port and protocol:
            self.hostname = hostname
            self.apikey = apikey 
            self.port = port
            self.protocol = protocol
        else:
            if has_app_context():
                self.hostname = current_app.config.get("VYOS_HOSTNAME")
                self.apikey = current_app.config.get("VYOS_APIKEY")
                self.port = current_app.config.get("VYOS_PORT")
                self.protocol = current_app.config.get("VYOS_PROTOCOL")
            else:
                self.hostname = os.environ.get("VYOS_HOSTNAME")
                self.apikey = os.environ.get("VYOS_APIKEY")
                self.port = os.environ.get("VYOS_PORT")
                self.protocol = os.environ.get("VYOS_PROTOCOL")
        self.set_url(protocol=self.protocol, hostname=self.hostname, port=self.port)

    def __enter__(self):
        print("Entering the context")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Exiting the context")
        return False
        
    def set_url(self, protocol, hostname, port):
        self.url = f"{protocol}://{hostname}:{port}/"

    def show_all_configs(self):
        return self.send_request(action=Action.RETRIEVE, data=SHOW_ALL_CONFIGS, verify=False)
        
    def _send_request_direct(self, action: Action, data, verify: bool):
        if isinstance(data, list):
            data = '[' + ', '.join(data) + ']'
        payload = {
            'data': data,
            'key': self.apikey
        }
        headers = {}

        timeout_seconds = os.environ.get('VYOS_HTTP_TIMEOUT_SECONDS')
        try:
            timeout = float(timeout_seconds) if timeout_seconds else 5.0
        except Exception:
            timeout = 5.0
        response = requests.request(
            method=Method.POST.name.lower(),
            url=self.url + action.name.lower(),
            headers=headers,
            data=payload,
            verify=verify,
            # timeout=timeout,
        )
        logger.log("URL: ")
        logger.log(self.url + action.name.lower())
        logger.log("Payload: ")
        logger.log(payload)
        logger.log("Response: ")
        logger.log(response.status_code, response.json())

        # record time of successful changes
        if response.status_code == 200 and action == Action.CONFIGURE:
            try:
                configure_succeeded = response.json().get('success') is True
            except (TypeError, ValueError, AttributeError):
                configure_succeeded = False

            logger.debug(
                f"[config-save] CONFIGURE response evaluated: "
                f"status_code={response.status_code}, success={configure_succeeded}"
            )
            if configure_succeeded:
                logger.debug("[config-save] Recording successful configuration change")
                record_successful_config_change()
        if response.status_code >= 400:
            logger.log(f"Failed to {action.name.lower()} with status code {response.status_code}")
            logger.log(response.json())

        return response

    def send_request(self, action: Action, data, verify: bool, queue: bool = False, user_token: Optional[str] = None):
        if action == Action.CONFIGURE:
            queue = False

        if not queue:
            return self._send_request_direct(action=action, data=data, verify=verify)

        if user_token is None and has_request_context():
            user_token = sess.get('username')

        task_id = vyos_task_queue.enqueue_vyos_task(
            http=self,
            action=action,
            data=data,
            verify=verify,
            user_token=user_token,
        )

        class _QueuedResponse:
            status_code = 202
            def json(self_inner):
                return {
                    'task_id': task_id,
                    'state': 'queued',
                    'success': True,
                    'error': None,
                }

        return _QueuedResponse()

if __name__ == "__main__":
    load_dotenv()
    req = HTTPRequest()
    show_interface_configs = SHOW_INTERFACE_CONFIGS
    show_all_configs = SHOW_ALL_CONFIGS
    res = req.send_request(action=Action.RETRIEVE, data=show_all_configs, verify=False)
    print(res.json())
