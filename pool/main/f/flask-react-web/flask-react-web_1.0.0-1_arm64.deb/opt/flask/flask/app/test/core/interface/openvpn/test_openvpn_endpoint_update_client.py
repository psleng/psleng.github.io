import pytest
import json
import requests
from app.core.api.http.http_request import Action
import pprint

class TestOpenVPNEndpointUpdateClient:

    @classmethod
    def setup_class(cls):
        
        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as e:
            print(f"Registration error (user may already exist): {e}")

    def _delete_and_login(self, test_service_provider):
        
        DELETE_OPENVPN = '{"op": "delete", "path": ["interfaces", "openvpn"]}'
        delete_response = test_service_provider.http_service.send_request(
            action=Action.CONFIGURE, data=DELETE_OPENVPN, verify=False
        )
        
        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def _get_initial_config(self):
        """Returns the initial configuration"""
        return {
            "general": {
                "name": "vtun0",
                "description": "Initial Config",
                "mode": "client",
                "enabled": True
            },
            "openvpn": {
                "deviceType": "tun",
                "localHost": ["192.168.1.1"],
                "localPort": None,
                "localAddress": "10.0.0.1",
                "remoteHost": ["203.0.113.1"],
                "remotePort": "1194",
                "remoteAddress": "10.0.0.2",
                "protocol": "udp",
                "server": {
                    "bridge": "",
                    "subnet": "",
                    "topology": "subnet",
                    "domainName": "",
                    "maxConnections": None,
                    "nameServer": [],
                    "clients": [],
                    "clientIpPool": {
                        "disabled": True,
                        "start": "",
                        "stop": "",
                        "subnetMask": ""
                    },
                    "clientIpv6Pool": {
                        "disabled": True,
                        "base": "::"
                    },
                    "pushRoutes": [],
                    "rejectUnconfiguredClients": False
                },
                "advanced": {
                    "ipVersion": "ipv4",
                    "keepAlive": {
                        "interval": 10,
                        "failureCount": 3
                    },
                    "persistentTunnel": True,
                    "useLzoCompression": True,
                    "replaceDefaultRoute": False
                }
            },
            "security": {
                "tls": {
                    "authKey": [],
                    "caCert": ['testCA'],
                    "certificate": ['testCert'],
                    "cryptKey": [],
                    "dhParams": "",
                    "peerFingerprint": [],
                    "role": "active",
                    "tlsVersionMin": "1.2"
                },
                "encryption": {
                    "cipher": "",
                    "dataCiphers": []
                },
                "hash": {
                    "algorithm": "sha256"
                }
            }
        }

    def test_update_endpoint_modify_all_fields(self, test_service_provider):
        
        openvpn_url = "http://localhost/webapi/vyos/opr/interface/openvpn"
        cookies = self._delete_and_login(test_service_provider)
        
        initial_config = self._get_initial_config()
        print("\n=== Creating Initial Configuration ===")
        response = requests.post(openvpn_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to create initial config: {response.text}"
        
        response_data = response.json()
        for item in response_data:
            if not item.get('success', False):
                print(f"Initial creation failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print("Initial config created successfully")
        
        # Update ALL fields
        import copy
        updated_config = copy.deepcopy(initial_config)
        
        updated_config["general"]["description"] = "Comprehensive Update Test"
        updated_config["general"]["enabled"] = True
        
        # updated_config["openvpn"]["deviceType"] = "tap"
        updated_config["openvpn"]["localHost"] = ["192.168.10.1"]
        # updated_config["openvpn"]["localPort"] = "1195"
        updated_config["openvpn"]["localAddress"] = "10.10.0.1"
        updated_config["openvpn"]["remoteHost"] = ["203.0.113.100"]
        updated_config["openvpn"]["remotePort"] = "1195"
        updated_config["openvpn"]["remoteAddress"] = "10.10.0.2"
        
        updated_config["openvpn"]["server"]["topology"] = "net30"
        updated_config["openvpn"]["server"]["domainName"] = "updated.example.com"
        updated_config["openvpn"]["server"]["maxConnections"] = 500
        updated_config["openvpn"]["server"]["nameServer"] = ["1.1.1.1", "8.8.8.8"]
        
        # updated_config["openvpn"]["advanced"]["ipVersion"] = "ipv6"
        updated_config["openvpn"]["advanced"]["keepAlive"]["interval"] = 20
        updated_config["openvpn"]["advanced"]["keepAlive"]["failureCount"] = 5
        updated_config["openvpn"]["advanced"]["persistentTunnel"] = False
        updated_config["openvpn"]["advanced"]["useLzoCompression"] = False
        updated_config["openvpn"]["advanced"]["replaceDefaultRoute"] = True
        
        updated_config["security"]["tls"]["tlsVersionMin"] = "1.3"
        updated_config["security"]["tls"]["role"] = "passive"
        updated_config["security"]["encryption"]["dataCiphers"] = ["aes256", "aes128"]
        updated_config["security"]["hash"]["algorithm"] = "sha512"
        updated_config["security"]["sharedSecretKey"] = "updated-vpn-secret"
        
        print("\n=== Updating ALL Configuration Fields ===")
        response = requests.put(f"{openvpn_url}/vtun0", json=updated_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to update config: {response.text}"
        
        response_data = response.json()
        print("\n=== Update Commands Generated ===")
        for item in response_data:
            print(f"Command: {item.get('cmd', 'N/A')}")
            print(f"Success: {item.get('success', False)}")
            if not item.get('success', False):
                print(f"Update failed:")
                pprint.pprint(item.get('cmd', 'N/A'), indent=2)
                print(f"  Error: {item.get('error', 'N/A')}")
                assert False, f"Command execution failed: {item.get('error', 'Unknown error')}"
        
        print("\nConfig updated successfully")
        
        print("\n=== Retrieving Updated Configuration ===")
        FETCH_OPENVPN = '{"op": "showConfig", "path": ["interfaces", "openvpn"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE, 
            data=FETCH_OPENVPN, 
            verify=False
        )
        
        fetched_config = fetch_response.json()
        print("\n=== Fetched Configuration ===")
        pprint.pprint(fetched_config)
        
        assert 'data' in fetched_config, "data field not found in response"
        assert 'openvpn' in fetched_config['data'], "openvpn field not found in data"
        assert 'vtun0' in fetched_config['data']['openvpn'], "vtun0 not found in config"
        
        vtun0_config = fetched_config['data']['openvpn']['vtun0']
        
        print("\n=== Verifying All Updated Fields ===")
        
        assert vtun0_config['description'] == 'Comprehensive_Update_Test', \
            f"Description mismatch: {vtun0_config.get('description')}"
        print("+ Description updated")
        
        assert '10.10.0.1' in vtun0_config['local-address'], \
            f"Local address mismatch: {vtun0_config.get('local-address')}"
        print("+ Local address updated")
        
        assert vtun0_config['remote-address'] == '10.10.0.2', \
            f"Remote address mismatch: {vtun0_config.get('remote-address')}"
        print("+ Remote address updated")
        
        assert vtun0_config['remote-host'] == '203.0.113.100', \
            f"Remote host mismatch: {vtun0_config.get('remote-host')}"
        print("+ Remote host updated")
        
        assert vtun0_config['remote-port'] == '1195', \
            f"Remote port mismatch: {vtun0_config.get('remote-port')}"
        print("+ Remote port updated")
        
        assert vtun0_config['server']['topology'] == 'net30', \
            f"Topology mismatch: {vtun0_config['server'].get('topology')}"
        print("+ Topology updated")
        
        assert vtun0_config['server']['domain-name'] == 'updated.example.com', \
            f"Domain name mismatch: {vtun0_config['server'].get('domain-name')}"
        print("+ Domain name updated")
        
        assert vtun0_config['server']['max-connections'] == '500', \
            f"Max connections mismatch: {vtun0_config['server'].get('max-connections')}"
        print("+ Max connections updated")
        
        assert '1.1.1.1' in vtun0_config['server']['name-server'], \
            f"Name server mismatch: {vtun0_config['server'].get('name-server')}"
        print("+ Name servers updated")
        
        assert vtun0_config['keep-alive']['interval'] == '20', \
            f"Keepalive interval mismatch: {vtun0_config['keep-alive'].get('interval')}"
        print("+ Keepalive interval updated")
        
        assert vtun0_config['keep-alive']['failure-count'] == '5', \
            f"Keepalive failure count mismatch: {vtun0_config['keep-alive'].get('failure-count')}"
        print("+ Keepalive failure count updated")
        
        assert 'persistent-tunnel' not in vtun0_config, \
            "Persistent tunnel should be disabled"
        print("+ Persistent tunnel disabled")
        
        assert 'use-lzo-compression' not in vtun0_config, \
            "LZO compression should be disabled"
        print("+ LZO compression disabled")
        
        # assert vtun0_config['ip-version'] == 'ipv6', \
        #     f"IP version mismatch: {vtun0_config.get('ip-version')}"
        # print("+ IP version updated")
        
        assert vtun0_config['hash'] == 'sha512', \
            f"Hash algorithm mismatch: {vtun0_config.get('hash')}"
        print("+ Hash algorithm updated")
        
        assert vtun0_config['tls']['tls-version-min'] == '1.3', \
            f"TLS version mismatch: {vtun0_config['tls'].get('tls-version-min')}"
        print("+ TLS version updated")
        
        print("\n" + "="*50)
        print("ALL FIELDS SUCCESSFULLY UPDATED AND VERIFIED!")
        print("="*50)