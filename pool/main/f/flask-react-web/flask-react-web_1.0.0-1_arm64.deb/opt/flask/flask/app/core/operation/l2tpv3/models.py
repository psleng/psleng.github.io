from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Dict, Any, Union

class L2TPv3InterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_l2tpv3_interface'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), unique=True, nullable=False)
    enabled = Column(Boolean, default=True)
    description = Column(Text)
    address = Column(JSON)
    peer_session_id = Column(Integer)
    peer_tunnel_id = Column(Integer)
    remote = Column(String(255))
    session_id = Column(Integer)
    source_address = Column(String(255))
    tunnel_id = Column(Integer)
    source_port = Column(Integer, nullable=True)
    destination_port = Column(Integer, nullable=True)
    encapsulation = Column(String(50), nullable=True)
    mtu = Column(Integer, nullable=True)
    ip_options = Column(JSON)
    ipv6_options = Column(JSON)

    def serialize(self):
        return {
            'name': self.name,
            'enabled': self.enabled,
            'description': self.description,
            'address': self.address or [],
            'peer_session_id': self.peer_session_id,
            'peer_tunnel_id': self.peer_tunnel_id,
            'remote': self.remote,
            'session_id': self.session_id,
            'source_address': self.source_address,
            'tunnel_id': self.tunnel_id,
            'advanced': {
                'source_port': self.source_port,
                'destination_port': self.destination_port,
                'encapsulation': self.encapsulation,
                'mtu': self.mtu,
                'ip': self.ip_options or {},
                'ipv6': self.ipv6_options or {}
            }
        }

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            for iface_name, iface_config in config.items():
                if not isinstance(iface_config, dict):
                    continue
                
                address_list = []
                if 'address' in iface_config:
                    addr = iface_config['address']
                    if isinstance(addr, dict):
                        address_list = [{'ip': str(ip)} for ip in addr.keys() if ip]
                    elif isinstance(addr, list):
                        address_list = [{'ip': str(ip)} for ip in addr if ip]
                    elif isinstance(addr, str) and addr.strip():
                        address_list = [{'ip': addr.strip()}]
                
                new_iface = cls(
                    name=iface_name,
                    enabled='disable' not in iface_config,
                    description=iface_config.get('description', ''),
                    address=address_list,
                    peer_session_id=int(iface_config.get('peer-session-id', 0)) if iface_config.get('peer-session-id') else None,
                    peer_tunnel_id=int(iface_config.get('peer-tunnel-id', 0)) if iface_config.get('peer-tunnel-id') else None,
                    remote=iface_config.get('remote', ''),
                    session_id=int(iface_config.get('session-id', 0)) if iface_config.get('session-id') else None,
                    source_address=iface_config.get('source-address', ''),
                    tunnel_id=int(iface_config.get('tunnel-id', 0)) if iface_config.get('tunnel-id') else None,
                    source_port=int(iface_config.get('source-port')) if iface_config.get('source-port') else None,
                    destination_port=int(iface_config.get('destination-port')) if iface_config.get('destination-port') else None,
                    encapsulation=iface_config.get('encapsulation') or None,
                    mtu=int(iface_config.get('mtu')) if iface_config.get('mtu') else None,
                    ip_options=iface_config.get('ip', {}),
                    ipv6_options=iface_config.get('ipv6', {})
                )
                db.session.add(new_iface)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            print(f"Error refreshing L2TPv3 config: {e}")

class L2TPv3Address(BaseModel):
    ip: str

class L2TPv3IPOptions(BaseModel):
    model_config = {
        'alias_generator': lambda field_name: field_name.replace('_', '-'),
        'populate_by_name': True
    }
    adjust_mss: Optional[str] = None
    arp_cache_timeout: Optional[int] = None
    disable_arp_filter: Optional[Union[bool, dict]] = None
    disable_forwarding: Optional[Union[bool, dict]] = None
    enable_arp_accept: Optional[Union[bool, dict]] = None
    enable_arp_announce: Optional[Union[bool, dict]] = None
    enable_arp_ignore: Optional[Union[bool, dict]] = None
    enable_directed_broadcast: Optional[Union[bool, dict]] = None
    enable_proxy_arp: Optional[Union[bool, dict]] = None
    proxy_arp_pvlan: Optional[Union[bool, dict]] = None
    source_validation: Optional[str] = None

    @field_validator('disable_arp_filter', 'disable_forwarding', 'enable_arp_accept', 
                     'enable_arp_announce', 'enable_arp_ignore', 'enable_directed_broadcast', 
                     'enable_proxy_arp', 'proxy_arp_pvlan', mode='before')
    @classmethod
    def handle_empty_dict_bool(cls, v):
        if isinstance(v, dict) and not v:
            return True
        return v

class L2TPv3IPv6Options(BaseModel):
    model_config = {
        'alias_generator': lambda field_name: field_name.replace('_', '-'),
        'populate_by_name': True
    }
    accept_dad: Optional[int] = None
    address_autoconf: Optional[Union[bool, dict]] = None
    address_eui64: Optional[str] = None
    address_interface_identifier: Optional[str] = None
    address_no_default_link_local: Optional[Union[bool, dict]] = None
    adjust_mss: Optional[str] = None
    base_reachable_time: Optional[int] = None
    disable_forwarding: Optional[Union[bool, dict]] = None
    dup_addr_detect_transmits: Optional[int] = None
    source_validation: Optional[str] = None

    @field_validator('address_autoconf', 'address_no_default_link_local', 'disable_forwarding', mode='before')
    @classmethod
    def handle_empty_dict_bool_ipv6(cls, v):
        if isinstance(v, dict) and not v:
            return True
        return v

class L2TPv3Advanced(BaseModel):
    source_port: Optional[int] = Field(default=None, ge=1, le=65535)
    destination_port: Optional[int] = Field(default=None, ge=1, le=65535)
    encapsulation: Optional[str] = Field(default=None)
    mtu: Optional[int] = Field(default=None, ge=68, le=16000)
    ip: Optional[L2TPv3IPOptions] = None
    ipv6: Optional[L2TPv3IPv6Options] = None

    @field_validator('source_port', 'destination_port', 'mtu', mode='before')
    @classmethod
    def handle_empty_string_int(cls, v):
        if v == "":
            return None
        return v

    @field_validator('encapsulation', mode='before')
    @classmethod
    def handle_empty_string_str(cls, v):
        if v == "":
            return None
        return v

class L2TPv3InterfaceConfigDTO(BaseModel):
    name: str
    enabled: bool = True
    description: Optional[str] = ""
    address: List[L2TPv3Address] = []
    peer_session_id: int = Field(ge=1, le=429496729)
    peer_tunnel_id: int = Field(ge=1, le=429496729)
    remote: str
    session_id: int = Field(ge=1, le=429496729)
    source_address: str
    tunnel_id: int = Field(ge=1, le=429496729)
    advanced: Optional[L2TPv3Advanced] = None

    @field_validator('address', mode='before')
    @classmethod
    def transform_address(cls, v):
        if isinstance(v, list):
            return [item if isinstance(item, dict) else {"ip": item} for item in v]
        if isinstance(v, str):
            return [{"ip": v}]
        return v

class CreateL2TPv3InterfaceDTO(BaseModel):
    general: L2TPv3InterfaceConfigDTO

class UpdateL2TPv3InterfaceByNameDTO(BaseModel):
    general: L2TPv3InterfaceConfigDTO

class UpdateAllL2TPv3InterfacesDTO(BaseModel):
    interfaces: List[CreateL2TPv3InterfaceDTO]
