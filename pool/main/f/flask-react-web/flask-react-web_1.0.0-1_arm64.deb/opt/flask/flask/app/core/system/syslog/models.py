from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel

from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship


FacilityName = Literal[
    'all',
    'auth',
    'authpriv',
    'cron',
    'daemon',
    'kern',
    'lpr',
    'mail',
    'mark',
    'news',
    'syslog',
    'user',
    'uucp',
    'local0',
    'local1',
    'local2',
    'local3',
    'local4',
    'local5',
    'local6',
    'local7',
]

LevelName = Literal[
    '',
    'emerg',
    'alert',
    'crit',
    'err',
    'warning',
    'notice',
    'info',
    'debug',
    'all',
]

ProtocolName = Literal['udp', 'tcp']

TLSAuthMode = Literal['anon', 'fingerprint', 'certvalid', 'name']


class FacilityLevelDTO(BaseModel):
    facility: FacilityName
    level: Optional[LevelName] = None


class SyslogSectionDTO(BaseModel):
    facilities: List[FacilityLevelDTO] = []


class SyslogRemoteFormatDTO(BaseModel):
    includeTimezone: Optional[bool] = None
    octetCounted: Optional[bool] = None


class SyslogRemoteTLSDTO(BaseModel):
    authMode: Optional[TLSAuthMode] = None
    caCertificate: Optional[str] = None
    certificate: Optional[str] = None
    permittedPeer: Optional[str] = None


class SyslogRemoteDTO(BaseModel):
    host: str
    port: Optional[int] = None
    protocol: Optional[ProtocolName] = None
    sourceAddress: Optional[str] = None
    vrf: Optional[str] = None
    format: Optional[SyslogRemoteFormatDTO] = None
    tls: Optional[SyslogRemoteTLSDTO] = None
    facilities: List[FacilityLevelDTO] = []


class SyslogMarkerDTO(BaseModel):
    disable: Optional[bool] = None
    interval: Optional[int] = None


class UpdateSyslogDTO(BaseModel):
    console: Optional[SyslogSectionDTO] = None
    local: Optional[SyslogSectionDTO] = None
    remote: List[SyslogRemoteDTO] = []
    marker: Optional[SyslogMarkerDTO] = None
    preserveFqdn: Optional[bool] = None


class VerifySyslogDTO(UpdateSyslogDTO):
    pass


class SyslogConfig(db.Model):
    __tablename__ = 'vyos_config_syslog'

    id = Column(Integer, primary_key=True)

    marker_disable = Column(Boolean, default=False)
    marker_interval = Column(Integer)
    preserve_fqdn = Column(Boolean, default=False)

    facilities = relationship('SyslogFacility', back_populates='syslog_config', cascade='all, delete-orphan')
    remotes = relationship('SyslogRemote', back_populates='syslog_config', cascade='all, delete-orphan')

    @classmethod
    def truncate(cls):
        from sqlalchemy import text

        tables_to_clear = [
            'vyos_config_syslog_remote_facility',
            'vyos_config_syslog_remote',
            'vyos_config_syslog_facility',
            'vyos_config_syslog'
        ]

        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))

    @classmethod
    def refresh(cls, config: Dict[str, Any]):
        try:
            cls.truncate()

            cfg = config or {}

            row = cls()
            marker = cfg.get('marker') or {}
            if isinstance(marker, dict):
                row.marker_disable = 'disable' in marker
                interval_val = marker.get('interval')
                if interval_val is not None and str(interval_val).strip() != '':
                    try:
                        row.marker_interval = int(interval_val)
                    except Exception:
                        row.marker_interval = None

            row.preserve_fqdn = isinstance(cfg, dict) and 'preserve-fqdn' in cfg

            db.session.add(row)
            db.session.flush()

            console = cfg.get('console') or {}
            if isinstance(console, dict):
                fac = console.get('facility') or {}
                if isinstance(fac, dict):
                    for facility_name, opts in fac.items():
                        level = None
                        if isinstance(opts, dict):
                            level = opts.get('level')

                        db.session.add(SyslogFacility(
                            syslog_config_id=row.id,
                            section='console',
                            facility=str(facility_name),
                            level=str(level) if level is not None else None
                        ))

            local = cfg.get('local') or {}
            if isinstance(local, dict):
                fac = local.get('facility') or {}
                if isinstance(fac, dict):
                    for facility_name, opts in fac.items():
                        level = None
                        if isinstance(opts, dict):
                            level = opts.get('level')

                        db.session.add(SyslogFacility(
                            syslog_config_id=row.id,
                            section='local',
                            facility=str(facility_name),
                            level=str(level) if level is not None else None
                        ))

            remote = cfg.get('remote') or {}
            if isinstance(remote, dict):
                for host, opts in remote.items():
                    remote_row = SyslogRemote(
                        syslog_config_id=row.id,
                        host=str(host),
                    )

                    if isinstance(opts, dict):
                        if opts.get('port') is not None:
                            try:
                                remote_row.port = int(opts.get('port'))
                            except Exception:
                                remote_row.port = None

                        if opts.get('protocol') is not None:
                            remote_row.protocol = str(opts.get('protocol'))

                        if opts.get('source-address') is not None:
                            remote_row.source_address = str(opts.get('source-address'))

                        if opts.get('vrf') is not None:
                            remote_row.vrf = str(opts.get('vrf'))

                        fmt = opts.get('format') or {}
                        if isinstance(fmt, dict):
                            remote_row.format_include_timezone = 'include-timezone' in fmt
                            remote_row.format_octet_counted = 'octet-counted' in fmt

                        tls = opts.get('tls') or {}
                        if isinstance(tls, dict):
                            if tls.get('auth-mode') is not None:
                                remote_row.tls_auth_mode = str(tls.get('auth-mode'))
                            if tls.get('ca-certificate') is not None:
                                remote_row.tls_ca_certificate = str(tls.get('ca-certificate'))
                            if tls.get('certificate') is not None:
                                remote_row.tls_certificate = str(tls.get('certificate'))
                            if tls.get('permitted-peer') is not None:
                                remote_row.tls_permitted_peer = str(tls.get('permitted-peer'))

                    db.session.add(remote_row)
                    db.session.flush()

                    if isinstance(opts, dict):
                        fac = opts.get('facility') or {}
                        if isinstance(fac, dict):
                            for facility_name, fopts in fac.items():
                                level = None
                                if isinstance(fopts, dict):
                                    level = fopts.get('level')

                                db.session.add(SyslogRemoteFacility(
                                    remote_id=remote_row.id,
                                    facility=str(facility_name),
                                    level=str(level) if level is not None else None
                                ))

            db.session.commit()
            print("Syslog configuration refreshed successfully")
        except Exception as e:
            print(f"Error refreshing Syslog configuration: {str(e)}")
            raise

    @staticmethod
    def empty_frontend() -> Dict[str, Any]:
        return {
            'console': {'facilities': []},
            'local': {'facilities': []},
            'remote': [],
            'marker': {'disable': False},
            'preserveFqdn': False,
        }

    def serialize(self) -> Dict[str, Any]:
        cfg = SyslogConfig.empty_frontend()

        cfg['marker']['disable'] = bool(self.marker_disable)
        if self.marker_interval is not None:
            cfg['marker']['interval'] = int(self.marker_interval)

        cfg['preserveFqdn'] = bool(self.preserve_fqdn)

        for f in self.facilities or []:
            if f.section not in ['console', 'local']:
                continue
            level = str(f.level) if f.level is not None and str(f.level).strip() != '' else ''
            cfg[f.section]['facilities'].append({'facility': str(f.facility), 'level': level})

        for r in self.remotes or []:
            item: Dict[str, Any] = {
                'host': str(r.host),
                'port': int(r.port) if r.port is not None else 514,
                'protocol': str(r.protocol) if r.protocol is not None and str(r.protocol).strip() != '' else 'udp',
                'sourceAddress': str(r.source_address) if r.source_address is not None else '',
                'vrf': str(r.vrf) if r.vrf is not None else '',
                'format': {
                    'includeTimezone': bool(r.format_include_timezone),
                    'octetCounted': bool(r.format_octet_counted),
                },
                'tls': {},
                'facilities': [],
            }

            tls_enabled = False
            if r.tls_auth_mode is not None and str(r.tls_auth_mode).strip() != '':
                tls_enabled = True
            if r.tls_ca_certificate is not None and str(r.tls_ca_certificate).strip() != '':
                tls_enabled = True
            if r.tls_certificate is not None and str(r.tls_certificate).strip() != '':
                tls_enabled = True
            if r.tls_permitted_peer is not None and str(r.tls_permitted_peer).strip() != '':
                tls_enabled = True

            if tls_enabled:
                item['tls'] = {
                    'authMode': str(r.tls_auth_mode) if r.tls_auth_mode is not None and str(r.tls_auth_mode).strip() != '' else 'anon',
                    'caCertificate': str(r.tls_ca_certificate) if r.tls_ca_certificate is not None else '',
                    'certificate': str(r.tls_certificate) if r.tls_certificate is not None else '',
                    'permittedPeer': str(r.tls_permitted_peer) if r.tls_permitted_peer is not None else '',
                }

            for rf in r.facilities or []:
                level = str(rf.level) if rf.level is not None and str(rf.level).strip() != '' else ''
                item['facilities'].append({'facility': str(rf.facility), 'level': level})

            cfg['remote'].append(item)

        return cfg


class SyslogFacility(db.Model):
    __tablename__ = 'vyos_config_syslog_facility'

    id = Column(Integer, primary_key=True)
    syslog_config_id = Column(Integer, ForeignKey('vyos_config_syslog.id'))

    section = Column(String(20))
    facility = Column(String(32))
    level = Column(String(16))

    syslog_config = relationship('SyslogConfig', back_populates='facilities')


class SyslogRemote(db.Model):
    __tablename__ = 'vyos_config_syslog_remote'

    id = Column(Integer, primary_key=True)
    syslog_config_id = Column(Integer, ForeignKey('vyos_config_syslog.id'))

    host = Column(String(255))
    port = Column(Integer)
    protocol = Column(String(8))
    source_address = Column(String(64))
    vrf = Column(String(128))

    format_include_timezone = Column(Boolean, default=False)
    format_octet_counted = Column(Boolean, default=False)

    tls_auth_mode = Column(String(32))
    tls_ca_certificate = Column(String(255))
    tls_certificate = Column(String(255))
    tls_permitted_peer = Column(String(255))

    syslog_config = relationship('SyslogConfig', back_populates='remotes')
    facilities = relationship('SyslogRemoteFacility', back_populates='remote', cascade='all, delete-orphan')


class SyslogRemoteFacility(db.Model):
    __tablename__ = 'vyos_config_syslog_remote_facility'

    id = Column(Integer, primary_key=True)
    remote_id = Column(Integer, ForeignKey('vyos_config_syslog_remote.id'))

    facility = Column(String(32))
    level = Column(String(16))

    remote = relationship('SyslogRemote', back_populates='facilities')
