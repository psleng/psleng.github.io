from app.core.api.http.cmd.command import Command


def format_description(description: str) -> str:
    return description.replace(' ', '_')


def has_config_value(value):
    return value is not None and str(value).strip() not in ('', 'None')


class WireguardCommand(Command):
    """
    Command class for Wireguard Interface
    Support the following VyOS command:

    - set/delete interfaces wireguard <interface-name> disable
    - set/delete interfaces wireguard <interface-name> description <description-text>
    - set/delete interfaces wireguard <interface-name> address <x.x.x.x/n | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces wireguard <interface-name> private-key <private-key-string>
    - set/delete interfaces wireguard <interface-name> public-key <public-key-string>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> description <description-text>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> disable
    - set/delete interfaces wireguard <interface-name> peer <peer-name> address {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces wireguard <interface-name> peer <peer-name> port <1-65535>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> allowed-ips <x.x.x.x/n | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> host-name <hostname-text>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> persistent-keepalive <1-65535>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> preshared-key <passphrase>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> public-key <public-key>
    - set/delete interfaces wireguard <interface-name> max-dns-retry <1-15>
    - set/delete interfaces wireguard <interface-name> mtu <68-16000>
    - set/delete interfaces wireguard <interface-name> port <1-65535>

    """

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'interfaces')
        )
        self.vyos_cmds = []
        self.cmds = []
    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def _generate_cmd(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds


    def generate_commands(self, data, current_config=None, new_config=None, all_config=None):
        if not data:
            return []

        for iface_name, iface_config in data.items():
            base_path = [self.resource, 'wireguard', iface_name]
            import pprint
            print("Wireguard command - All config")
            print(pprint.pformat(all_config, indent=4))

            if self.operator == "delete" and iface_name not in all_config:
                self._generate_cmd(*base_path)
                continue

            simple_keys = ['disable', 'private-key', 'public-key', 'port', 'mtu', 'max-dns-retry']
            for key in simple_keys:
                if key in iface_config:
                    value = iface_config[key]
                    if isinstance(value, bool) and value:
                        self._generate_cmd(*base_path, key)
                    elif not isinstance(value, bool) and has_config_value(value):
                        if self.operator == 'delete' and key in ('mtu', 'max-dns-retry') and isinstance(new_config, dict) and key not in new_config:
                            continue
                        self._generate_cmd(*base_path, key, value)
            if 'description' in iface_config:
                self._generate_cmd(*base_path, 'description', format_description(iface_config['description']))

            if 'address' in iface_config:
                addresses = iface_config['address']
                if isinstance(addresses, str):
                    addresses = [addresses]
                for addr in addresses:
                    if addr:
                        self._generate_cmd(*base_path, 'address', addr.strip())

            if 'peer' in iface_config:
                self._process_peer_config(base_path, iface_config['peer'], current_config, new_config)

        return self.cmds

    def _process_peer_config(self, base_path, peer_config, current_config=None, new_config=None):
        for peer_name, peer_attrs in peer_config.items():
            peer_path = base_path + ['peer', peer_name]

            if self.operator == "delete" and peer_name not in new_config.get('peer', {}):
                self._generate_cmd(*peer_path)
                continue

            simple_keys = ['disable', 'endpoint', 'persistent-keepalive', 'preshared-key', 'public-key']
            for key in simple_keys:
                if key in peer_attrs:
                    value = peer_attrs[key]
                    if isinstance(value, bool) and value:
                        self._generate_cmd(*peer_path, key)
                    elif not isinstance(value, bool) and value:
                        self._generate_cmd(*peer_path, key, value)
            if 'description' in peer_attrs:
                self._generate_cmd(*peer_path, 'description', format_description(peer_attrs['description']))

            if 'allowed-ips' in peer_attrs:
                if isinstance(peer_attrs['allowed-ips'], list):
                    for ip in peer_attrs['allowed-ips']:
                        self._generate_cmd(*peer_path, 'allowed-ips', ip.strip())
                elif isinstance(peer_attrs['allowed-ips'], str):
                    self._generate_cmd(*peer_path, 'allowed-ips', peer_attrs['allowed-ips'].strip())
            
            if 'address' in peer_attrs:
                self._generate_cmd(*peer_path, 'address', peer_attrs['address'])

            if 'port' in peer_attrs:
                self._generate_cmd(*peer_path, 'port', peer_attrs['port'])
            
            if 'host-name' in peer_attrs:
                self._generate_cmd(*peer_path, 'host-name', peer_attrs['host-name'])
            
