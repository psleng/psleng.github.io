from app.core.models import SelectedServices, Services, AdminSelectedService
from flask import jsonify
from app.db.database import db
from app.log.logger import logger
from app.socket.socket_manager import socket_manager
from datetime import datetime, timedelta
from app.event.jobs.system.config import refresh_db_service_stat
import requests

#from flask.app.core.operation.routes import get_services_summary

def _response_json(response):
    if response is None:
        return {}

    try:
        return response.json()
    except Exception:
        return {}


def _extract_graphql_mutation(response_data, mutation_name):
    if not isinstance(response_data, dict):
        return {}

    data = response_data.get('data')
    if not isinstance(data, dict):
        return {}

    mutation_data = data.get(mutation_name)
    return mutation_data if isinstance(mutation_data, dict) else {}


def add_system_image(provider, data):
    payload = data.copy() if isinstance(data, dict) else {'location': data}
    payload = {
        'location': payload.get('location'),
        'username': payload.get('username', ''),
        'password': payload.get('password', ''),
        'no_prompt': payload.get('no_prompt', False),
        'force': payload.get('force', False),
        'proceed_without_signature': payload.get('proceed_without_signature', True),
        'proceed_unsaved_commits': payload.get('proceed_unsaved_commits', True),
        'image_name': payload.get('image_name', ''),
        'set_as_default': payload.get('set_as_default', False),
        'copy_config': payload.get('copy_config', False),
        'copy_ssh_host_keys': payload.get('copy_ssh_host_keys', False),
        'copy_ssh_known_hosts': payload.get('copy_ssh_known_hosts', False),
    }

    mutation_name = 'AddSystemImagePerleImageMutation'
    
    response = provider.graphql_service.send_simple_mutation_request(
        function_name=mutation_name, data=payload, verify=False
    )
    response_data = _response_json(response)
    mutation_data = _extract_graphql_mutation(response_data, 'AddSystemImagePerleImageMutation')

    return {
        'response': response,
        'response_data': response_data,
        'success': mutation_data.get('success'),
        'errors': mutation_data.get('errors') or response_data.get('errors'),
        'result': (mutation_data.get('data') or {}).get('result') if isinstance(mutation_data.get('data'), dict) else None,
    }


def delete_system_image(provider, data):
    name = data.get('name') if isinstance(data, dict) else data

    response = provider.graphql_service.send_mutation_request(
        function_name='DeleteSystemImage',
        mutation_name='DeleteSystemImage',
        input_name='DeleteSystemImageInput',
        data={'name': name},
        verify=False
    )

    response_data = _response_json(response)
    mutation_data = _extract_graphql_mutation(response_data, 'DeleteSystemImage')

    return {
        'response': response,
        'response_data': response_data,
        'success': mutation_data.get('success'),
        'errors': mutation_data.get('errors'),
        'result': (mutation_data.get('data') or {}).get('result') if isinstance(mutation_data.get('data'), dict) else None,
    }


def rename_system_image(provider, data):
    name = data.get('name') if isinstance(data, dict) else None
    new_name = data.get('new_name') if isinstance(data, dict) else None

    mutation_name = 'SetSystemImagePerleImageRenameMutation'

    response = provider.graphql_service.send_simple_mutation_request(
        function_name=mutation_name,
        data={
            'image_name': name,
            'image_new_name': new_name,
        },
        verify=False
    )

    response_data = _response_json(response)
    mutation_data = _extract_graphql_mutation(response_data, mutation_name)

    return {
        'response': response,
        'response_data': response_data,
        'success': mutation_data.get('success'),
        'errors': mutation_data.get('errors') or response_data.get('errors'),
        'result': (mutation_data.get('data') or {}).get('result') if isinstance(mutation_data.get('data'), dict) else None,
    }


def save_running_config(provider, data):
    logger.debug(f"[config-save] Sending config save request")

    http_service = provider.http_service
    base_url = getattr(http_service, 'url', None)
    apikey = getattr(http_service, 'apikey', None)
    if not base_url:
        raise RuntimeError('Config save HTTP service URL is not configured')

    response = requests.post(
        url=f"{base_url.rstrip('/')}/config-file",
        data={"data": data, "key": apikey},
        verify=False,
    )

    status_code = getattr(response, 'status_code', 200)
    try:
        result = response.json()
    except (TypeError, ValueError) as exc:
        logger.debug(
            f"[config-save] Config save returned invalid JSON: status_code={status_code}"
        )
        raise RuntimeError('Save config returned an invalid response') from exc

    if not isinstance(result, dict):
        logger.debug(
            f"[config-save] Config save returned non-object JSON: "
            f"status_code={status_code}, response_type={type(result).__name__}"
        )
        raise RuntimeError('Save config returned an invalid response')

    logger.debug(
        f"[config-save] Config save response received: "
        f"status_code={status_code}, success={result.get('success')}"
    )
    if status_code >= 400 or result.get('success') is False:
        error = result.get('error') or result.get('message') or 'Failed to save config'
        raise RuntimeError(str(error))

    return result


def update_selected_services(provider, data):

    user_id, permission, selected_services = data.get('user_id'), data.get('permission'), data.get('selected_services')
    if selected_services is None:
        logger.debug("No selected services provided, returning current selection")
        return jsonify({
            'message': 'Selected services updated',
            'selectedServices': selected_services
        }), 200

    try:
        if not user_id:
            return jsonify({'error': 'No user_id provided'}), 400

        user_id = str(user_id)

        if not isinstance(selected_services, list):
            return jsonify({'error': 'selected_services must be a list'}), 400

        services = (
            Services.query
            .filter(Services.name.in_(selected_services))
            .all()
        )

        service_map = {s.name: s.id for s in services}
        service_ids = list(service_map.values())

        SelectedServices.query.filter_by(
            user_id=user_id
        ).update(
            {"status": "disabled"},
            synchronize_session=False
        )

        existing_records = (
            SelectedServices.query
            .filter(
                SelectedServices.user_id == user_id,
                SelectedServices.service_id.in_(service_ids)
            )
            .all()
        )

        existing_by_service_id = {
            r.service_id: r for r in existing_records
        }

        for name in selected_services:
            service_id = service_map.get(name)
            if not service_id:
                continue

            record = existing_by_service_id.get(service_id)

            if record:
                record.status = 'enabled'
            else:
                db.session.add(
                    SelectedServices(
                        user_id=user_id,
                        service_id=service_id,
                        status='enabled'
                    )
                )

        if permission == 'administrator':
            AdminSelectedService.query.delete()
            for service_id in service_map.values():
                db.session.add(AdminSelectedService(service_id=service_id))

        db.session.commit()

        now = datetime.now()
        socket_manager.emit_to_all(
            event='notification',
            data={
                'id': str(int(now.timestamp() * 1000)),
                'type': 'ignore',
                'title': 'Updated Selected Services',
                'content': 'Selected services have been updated.',
                'action': 'send-updated-selected-services',
            },
        )

        return jsonify({
            'message': 'Selected services updated',
            'selectedServices': selected_services
        }), 200

    except Exception as e:
        print(f"[update_selected_services] Exception: {e}")
        return jsonify({'error': str(e)}), 400
            
def get_selected_services(permission, user_id):
    try:
        user_id = str(user_id)

        admin_services = (
            db.session.query(Services.name)
            .join(AdminSelectedService, AdminSelectedService.service_id == Services.id)
            .all()
        )
        admin_service_names = [name for (name,) in admin_services]

        if permission == 'administrator':
            available_services = [s.name for s in Services.query.all()]
            enabled_services = admin_service_names
        else:
            available_services = admin_service_names
            enabled_services = [
                name for (name,) in
                db.session.query(Services.name)
                .join(SelectedServices, SelectedServices.service_id == Services.id)
                .filter(
                    SelectedServices.user_id == user_id,
                    SelectedServices.status == 'enabled'
                )
                .all()
            ]
            if not enabled_services or len(enabled_services) == 0:
                enabled_services = admin_service_names
        logger.debug(f"[get_selected_services] user_id: {user_id}, permission: {permission}")
        logger.debug(f"[get_selected_services] available_services: {available_services}")
        logger.debug(f"[get_selected_services] enabled_services: {enabled_services}")
        return {
            "availableServices": available_services,
            "enabledServices": enabled_services
        }

    except Exception as e:
        logger.error(f"[get_selected_services] Exception: {e}")
        return {
            "availableServices": [],
            "enabledServices": []
        }
