from app.core.network.ipv6_ra.command_ipv6_ra import IPv6RACommand
from app.core.api.http.http_request import Action
import pprint
import logging
from flask import session
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from logging import getLogger, DEBUG
from app.core.utils.validate.verify_parser import format_verify

from app.core.api.http.cmd.command import SHOW_IPV6_RA
from app.core.network.ipv6_ra.models import IPv6RA

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_ipv6_ra(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_IPV6_RA, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data

def update_ipv6_ra(provider, data):
    
    username = session.get('username', 'unknown')
    diff = data.get('diff', {})
    current_config = data.get('current', {})
    new_config = data.get('new', {})
    
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(new_config, indent=2, width=80))
    
    delete_cmds = []
    ipv6ra_delete_cmd = IPv6RACommand(operator='delete')

    delete_data = diff.get('deleted', {}).get('interface', {})
    delete_cmds = ipv6ra_delete_cmd.generate_commands(
        data=delete_data,
        current_config=current_config,
        new_config=new_config
    )
    dc = ipv6ra_delete_cmd.get_commands()
    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_del_configs = process_commands(dc)

    set_cmds = []
    ipv6ra_set_cmd = IPv6RACommand(operator='set')
 
    set_data = diff.get('created', {}).get('interface', {})
    set_cmds = ipv6ra_set_cmd.generate_commands(
        data=set_data,
        current_config=current_config,
        new_config=new_config
    )
    sc = ipv6ra_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc, tag_object=True)
    
    service = "router_advert"
    curr_config = provider.verify_service.call_get_config(service)
    current_raw_config = curr_config if curr_config else {}
    
    print("Current raw config: ")
    print(pprint.pformat(current_raw_config, indent=2, width=80))
    
    merged_del_config = merge_dicts_delete(
        {"service": {"router-advert": current_raw_config}}, 
        new_del_configs, 
        clean_empty=False
    )
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(
            service, 
            merged_config.get('service', {}).get('router-advert', {})
        )
        
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    
    verify = format_verify(verify)
    print("Formated Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    
    if str(verify) != "None" and str(verify) != "" and verify != {}:
        return [{"success": False, "error": verify, "cmd": cmds}]

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update IPv6 RA",
                "content": "IPv6 RA is successfully updated"
            }
    )
    # save to db:
    IPv6RA.refresh(new_config)

    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_ipv6_ra(provider, data: dict):

    ipv6ra_set_cmd = IPv6RACommand(operator='set')
 
    set_data = data.get('interface', {})
    set_cmds = ipv6ra_set_cmd.generate_commands(data=set_data)
    sc = ipv6ra_set_cmd.get_commands()
    verify_config = process_commands(sc, tag_object=True)
    print("verify config: ")
    print(verify_config)
    verify = None
    service = "router_advert"
    if verify_config:
        verify = provider.verify_service.call_verify(
            service, 
            verify_config.get('service', {}).get('router_advert', {})
        )
    verify = format_verify(verify)
    return verify

