import copy
import pprint
import requests
from app.core.api.http.http_request import Action


class TestVRRPEndpointUpdate1:

    @classmethod
    def setup_class(cls):
        register_url = "http://localhost/webapi/auth/register"
        register_data = {"username": "test", "password": "test"}
        try:
            response = requests.post(register_url, json=register_data)
            print(f"Registration response: {response.status_code}")
        except Exception as exc:
            print(f"Registration error (user may already exist): {exc}")

    def _delete_and_login(self, test_service_provider):
        delete_payload = '{"op": "delete", "path": ["high-availability", "vrrp"]}'
        test_service_provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=delete_payload,
            verify=False,
        )

        login_url = "http://localhost/webapi/auth/login"
        login_data = {"username": "test", "password": "test", "ssid": ""}
        login_response = requests.post(login_url, json=login_data)
        assert login_response.status_code == 200, f"Login failed: {login_response.text}"
        return login_response.cookies

    def test_update_from_initial_state(self, test_service_provider):
        vrrp_url = "http://localhost/webapi/vyos/high-availability/vrrp"
        cookies = self._delete_and_login(test_service_provider)

        initial_config = {
            "connection": {  
                    "group": [
                    {
                        "VRRPGeneral": {
                            "groupName": "test",
                            "description": "test description",
                            "enable": True,
                            "address": [
                                "10.10.10.10",
                                "20.20.20.20"
                            ],
                            "interface": "eth0",
                            "VRID": 70
                        },
                        "VRRPAdvancedConfig": {
                            "advertiseInterval": 60,
                            "authenticationPassword": "password",
                            "excludedAddresses": [
                                "20.20.20.20",
                                "30.30.30.30"
                            ],
                            "disableMaster": True,
                            "peerAddress": "5.5.5.5",
                            "delay": 90,
                            "priority": 78,
                            "RFC3768Compatibility": False,
                            "GARP": {
                                "interval": 40,
                                "delay": 5,
                                "masterRefresh": 5,
                                "masterRefreshRepeat": 200,
                                "masterRepeat": 5
                            },
                            "track": {
                                "excludeVRRP": True,
                                "interface": ["eth0"]
                            }
                        }
                    },
                    {
                        "VRRPGeneral": {
                            "groupName": "test2",
                            "description": "",
                            "enable": True,
                            "address": [
                                "192.0.2.1"
                            ],
                            "interface": "eth0",
                            "VRID": 79
                        },
                        "VRRPAdvancedConfig": {
                            "advertiseInterval": 1,
                            "authenticationPassword": "",
                            "excludedAddresses": [],
                            "disableMaster": True,
                            "peerAddress": "5.5.5.5",
                            "delay": 0,
                            "priority": 0,
                            "RFC3768Compatibility": False,
                            "GARP": {
                                "interval": 0,
                                "delay": 5,
                                "masterRefresh": 5,
                                "masterRefreshRepeat": 1,
                                "masterRepeat": 5
                            },
                            "track": {
                                "excludeVRRP": False,
                                "interface": ["eth0", "eth1"]
                            }
                        }
                    },
                    {
                        "VRRPGeneral": {
                            "groupName": "test3",
                            "description": "asdasd",
                            "enable": True,
                            "address": [
                                "30.30.30.30"
                            ],
                            "interface": "br2",
                            "VRID": 1
                        },
                        "VRRPAdvancedConfig": {
                            "advertiseInterval": 1,
                            "authenticationPassword": "",
                            "excludedAddresses": [],
                            "disableMaster": True,
                            "peerAddress": "",
                            "delay": 0,
                            "priority": 0,
                            "RFC3768Compatibility": False,
                            "GARP": {
                                "interval": 0,
                                "delay": 5,
                                "masterRefresh": 5,
                                "masterRefreshRepeat": 1,
                                "masterRepeat": 5
                            },
                            "track": {
                                "excludeVRRP": False,
                                "interface": ["br2"]
                            }
                        }
                    }
                    ],
                    "syncGroup": 
                    [
                        {
                            "groupName": "test",
                            "member": [],
                            "healthCheck": {
                                "failureCount": 3,
                                "interval": 60,
                                "pingTarget": "3.3.3.3"
                            }
                        },
                        {
                            "groupName": "test2",
                            "member": [
                                "test2",
                                "test"
                            ],
                            "healthCheck": {
                                "failureCount": 3,
                                "interval": 60,
                                "pingTarget": "4.4.4.4"
                            }
                        }
                    ]

                },
                "globalParameters": {
                    "delay": "5",
                    "version": "2",
                    "enableSNMP": True,
                    "GARP": {
                        "interval": "100",
                        "masterDelay": "50",
                        "masterRefresh": "5",
                        "masterRefreshRepeat": "1",
                        "masterRepeat": "200"
                    }
                }
        }

        response = requests.put(vrrp_url, json=initial_config, cookies=cookies)
        assert response.status_code == 200, f"Failed to apply initial config: {response.text}"
        initial_commands = response.json()
        print("\n=== Commands Generated (VRRP Radius Initial State) ===")
        print("commands", initial_commands)
        pprint.pprint(initial_commands)
        for item in initial_commands:
            assert item.get("success", False), f"Initial command failed: {item.get('error', 'Unknown error')}"

        updated_config = copy.deepcopy(initial_config)

        
        updated_config["connection"]["group"][0].update({
            "VRRPGeneral": {
                "groupName": "updated test",
                "description": "test description updated",
                "enable": True,
                "address": [
                    "10.10.10.10"
                ],
                "interface": "eth1",
                "VRID": 80
            },
            "VRRPAdvancedConfig": {
                "advertiseInterval": 30,
                "authenticationPassword": "new",
                "excludedAddresses": [
                    "25.25.25.25",
                    "35.35.35.35"
                ],
                "disableMaster": False,
                "peerAddress": "2.2.2.2",
                "delay": 50,
                "priority": 90,
                "RFC3768Compatibility": True,
                "GARP": {
                    "interval": 50,
                    "delay": 10,
                    "masterRefresh": 10,
                    "masterRefreshRepeat": 100,
                    "masterRepeat": 10
                },
                "track": {
                    "excludeVRRP": False,
                    "interface": ["eth1"]
                }
            }
        })

        updated_config["connection"]["group"][1].update({
            "VRRPGeneral": {
                "groupName": "test2-updated",
                "description": "updated description",
                "enable": False,
                "address": [
                    "192.0.2.2",
                    "192.3.4.5"
                ],
                "interface": "eth2",
                "VRID": 90
            },
            "VRRPAdvancedConfig": {
                "advertiseInterval": 10,
                "authenticationPassword": "new2",
                "excludedAddresses": [
                    "5.5.5.5"
                ],
                "disableMaster": False,
                "peerAddress": "5.5.5.6",
                "delay": 20,
                "priority": 50,
                "RFC3768Compatibility": True,
                "GARP": {
                    "interval": 20,
                    "delay": 10,
                    "masterRefresh": 10,
                    "masterRefreshRepeat": 50,
                    "masterRepeat": 10
                },
                "track": {
                    "excludeVRRP": True,
                    "interface": ["eth2"] 
                }
            }
        })
        
        updated_config["connection"]["group"][2].update({
            "VRRPGeneral": {
                "groupName": "test3-updated",
                "description": "asdasd-updated",
                "enable": False,
                "address": [
                    "30.30.40.30"
                ],
                "interface": "br3",
                "VRID": 2
            },
            "VRRPAdvancedConfig": {
                "advertiseInterval": 5,
                "authenticationPassword": "new3",
                "excludedAddresses": [],
                "disableMaster": False,
                "peerAddress": "",
                "delay": 10,
                "priority": 20,
                "RFC3768Compatibility": True,
                "GARP": {
                    "interval": 10,
                    "delay": 5,
                    "masterRefresh": 5,
                    "masterRefreshRepeat": 10,
                    "masterRepeat": 5
                },
                "track": {
                    "excludeVRRP": True,
                    "interface": ["br3"]  
                }
            }
        })

        updated_config["connection"]["syncGroup"][0].update(
            {
                "groupName": "test-updated",
                "member": ["updated test", "test2-updated"],
                "healthCheck": {
                    "failureCount": 4,
                    "interval": 45,
                    "pingTarget": "3.3.3.3"
                }
            }
        )

        updated_config["connection"]["syncGroup"][1].update(
            {
                "groupName": "test2-updated",
                "member": ["test2-updated", "test3-updated"],
                "healthCheck": {
                    "failureCount": 5,
                    "interval": 50,
                    "pingTarget": "4.4.4.4"
                }
            }
        )

        updated_config['globalParameters'].update(
            {
                "delay": "10",
                "version": "3",
                "enableSNMP": False,
                "GARP": {
                    "interval": "200",
                    "masterDelay": "100",
                    "masterRefresh": "10",
                    "masterRefreshRepeat": "2",
                    "masterRepeat": "100"
                }
            }
        )
        
        update_response = requests.put(vrrp_url, json=updated_config, cookies=cookies)
        assert update_response.status_code == 200, f"Failed to update config: {update_response.text}"
        update_commands = update_response.json()
        print("\n=== Commands Generated (VRRP Radius Update Stage 1) ===")
        pprint.pprint(update_commands)
        for item in update_commands:
            assert item.get("success", False), f"Update command failed: {item.get('error', 'Unknown error')}"

        fetch_payload = '{"op": "showConfig", "path": ["high-availability", "vrrp"]}'
        fetch_response = test_service_provider.http_service.send_request(
            action=Action.RETRIEVE,
            data=fetch_payload,
            verify=False,
        )
        fetched_config = fetch_response.json()
        print("\n=== Fetched VRRP Radius Configuration (Post-Update) ===")
        pprint.pprint(fetched_config)

        data = fetched_config.get("data", {})

        # Validate global parameters
        gp = data.get("global-parameters", {})
        assert isinstance(gp, dict), "Global parameters should be a dictionary"
        assert str(gp.get("startup-delay")) == "10", "Global delay should be 10"
        assert str(gp.get("version")) == "3", "Global version should be 3"
        gpGarp = gp.get("garp", {})
        assert isinstance(gpGarp, dict), "Global GARP should be a dictionary"
        assert str(gp.get("garp", {}).get("interval")) == "200", "Global GARP interval mismatch"
        assert str(gp.get("garp", {}).get("master-repeat")) == "100", "Global GARP master-delay mismatch"
        assert str(gp.get("garp", {}).get("master-refresh-repeat")) == "2", "Global GARP master-delay mismatch"
        assert str(gp.get("garp", {}).get("master-delay")) == "100", "Global GARP master-delay mismatch"
        #assert data.get("enable-snmp") not in data, "Global SNMP should be disabled"

        # Validate groups
        groups =  data.get("group")
        assert len(groups) == 3, "Expected 3 VRRP groups"
        assert isinstance(groups, dict), "Groups should be a dictionary"

        # Validate group 0 (updated test)
        g0 = groups.get("updated test")
        assert g0 is not None, "Group 'updated test' not found"

        assert str(g0.get("description", "")) == "test description updated", "Group description mismatch"
        assert str(g0.get("disable")), "Group enable mismatch"
        assert str(g0.get("interface", "")) == "eth1", "Group interface mismatch"
        assert str(g0.get("vrid", "")) == "80", "Group VRID mismatch"
        assert str(g0.get("advertise-interval", "")) == "30", "Group advertise interval mismatch"
        assert isinstance(g0.get("authentication"), dict), "Group authentication should be a dictionary"
        assert str(g0.get("authentication", {}).get("password", "")) == "new", "Group password mismatch"
        assert str(g0.get("authentication", {}).get("type", "")) == "plaintext-password", "Group auth type mismatch"
        assert isinstance(g0.get("address"), dict), "Group address should be a dictionary"
        assert g0.get("address", {}) == {"10.10.10.10": {}}, "Group address mismatch"
        assert isinstance(g0.get("excluded-address"), dict), "Group excluded-address should be a dictionary"
        assert g0.get("excluded-address", {}) == {"25.25.25.25": {}, "35.35.35.35": {}}, "Group excluded-address mismatch"
        assert "no-preempt" not in g0, "Group should not have no-preempt (disableMaster=False)"
        assert str(g0.get("peer-address", "")) == "2.2.2.2", "Group peer-address mismatch"
        assert str(g0.get("preempt-delay", "")) == "50", "Group preempt-delay mismatch"
        assert str(g0.get("priority", "")) == "90", "Group priority mismatch"
        assert g0.get("rfc3768-compatibility") is not None, "Group RFC3768 compatibility mismatch"
        garp0 = g0.get("garp", {}) or {}
        assert isinstance(garp0, dict), "Group GARP should be a dictionary"
        assert str(garp0.get("interval", "")) == "50", "Group GARP interval mismatch"
        assert str(garp0.get("master-delay", "")) == "10", "Group GARP master-delay mismatch"
        assert str(garp0.get("master-refresh", "")) == "10", "Group GARP master-refresh mismatch"
        assert str(garp0.get("master-refresh-repeat", "")) == "100", "Group GARP master-refresh-repeat mismatch"
        assert str(garp0.get("master-repeat", "")) == "10", "Group GARP master-repeat mismatch"
        assert isinstance(g0.get("health-check"), dict), "Group health-check should be a dictionary"
        assert str(g0.get("health-check", {}).get("failure-count", "")) == "5", "Group health-check failure count mismatch"
        assert str(g0.get("health-check", {}).get("interval", "")) == "30", "Group health-check interval mismatch"
        assert g0.get("health-check", {}).get("ping", "") == "", "Group health-check ping target should be empty"
        assert g0.get("track", {}).get("exclude-vrrp-interface") is None, "Group track exclude-vrrp should not be set"
        #assert str(g0.get("track", {}).get("interface", "")) == "eth1", "Group track interface mismatch"

        # Validate group 1 (test2-updated)
        g1 = groups.get("test2-updated")
        assert g1 is not None, "Group 'test2-updated' not found"
        assert "disable" not in g1, "Group enable mismatch"
        assert str(g1.get("description", "")) == "updated description", "Group 1 description mismatch"
        assert (str(g1.get("disable", "")) == "true") or ("disable" in g1), "Group 1 should be disabled"
        assert str(g1.get("interface", "")) == "eth2", "Group 1 interface mismatch"
        assert str(g1.get("vrid", "")) == "90", "Group 1 VRID mismatch"
        assert str(g1.get("advertise-interval", "")) == "10", "Group 1 advertise interval mismatch"
        assert isinstance(g1.get("authentication"), dict), "Group 1 authentication should be a dictionary"
        assert str(g1.get("authentication", {}).get("password", "")) == "new2", "Group 1 password mismatch"
        assert isinstance(g1.get("address"), dict), "Group address should be a dictionary"
        assert g1.get("address", {}) == {"192.0.2.2": {}, "192.3.4.5": {}}, "Group 1 address mismatch"
        assert isinstance(g1.get("excluded-address"), dict), "Group 1 excluded-address should be a dictionary"
        assert g1.get("excluded-address", {}) == {"5.5.5.5": {}}, "Group 1 excluded-address mismatch"
        assert "no-preempt" not in g1, "Group 1 should not have no-preempt"
        assert str(g1.get("peer-address", "")) == "5.5.5.6", "Group 1 peer-address mismatch"
        assert str(g1.get("preempt-delay", "")) == "20", "Group 1 preempt-delay mismatch"
        assert str(g1.get("priority", "")) == "50", "Group 1 priority mismatch"
        assert g1.get("rfc3768-compatibility") is not None, "Group 1 RFC3768 compatibility mismatch"
        assert isinstance(g1.get("garp"), dict), "Group 1 GARP should be a dictionary"
        assert str(g1.get("garp", {}).get("interval", "")) == "20", "Group 1 GARP interval mismatch"
        assert str(g1.get("garp", {}).get("master-delay", "")) == "10", "Group 1 GARP master-delay mismatch"
        assert isinstance(g1.get("health-check"), dict), "Group 1 health-check should be a dictionary"
        assert str(g1.get("health-check", {}).get("failure-count", "")) == "4", "Group 1 health-check failure count mismatch"
        assert str(g1.get("health-check", {}).get("interval", "")) == "45", "Group 1 health-check interval mismatch"
        assert isinstance(g1.get("track"), dict), "Group 1 track should be a dictionary"
        assert g1.get("track", {}).get("exclude-vrrp-interface") is not None, "Group 1 track exclude-vrrp should be set"
#        assert str(g1.get("track", {}).get("interface", "")) == "eth2", "Group 1 track interface mismatch"

        # Validate group 2 (test3-updated)
        g2 = groups.get("test3-updated")
        assert g2 is not None, "Group 'test3-updated' not found"
        assert "disable" not in g2, "Group enable mismatch"
        assert str(g2.get("description", "")) == "asdasd-updated", "Group 2 description mismatch"
        assert str(g2.get("interface", "")) == "br3", "Group 2 interface mismatch"
        assert str(g2.get("vrid", "")) == "2", "Group 2 VRID mismatch"
        assert str(g2.get("advertise-interval", "")) == "5", "Group 2 advertise interval mismatch"
        assert isinstance(g2.get("authentication"), dict), "Group 2 authentication should be a dictionary"
        assert str(g2.get("authentication", {}).get("password", "")) == "new3", "Group 2 password mismatch"
        assert isinstance(g2.get("address"), dict), "Group 2 address should be a dictionary"
        assert g2.get("address", {}) == {"30.30.40.30": {}}, "Group 2 address mismatch"
        assert isinstance(g2.get("excluded-address"), dict), "Group 2 excluded-address should be a dictionary"
        assert (g2.get("excluded-address", {}) == {}) or (len(g2.get("excluded-address", {})) == 0), "Group 2 excluded-address should be empty"
        assert "no-preempt" not in g2, "Group 2 should not have no-preempt"
        assert (str(g2.get("peer-address", "")) == "") or ("peer-address" not in g2), "Group 2 peer-address should be empty"
        assert str(g2.get("preempt-delay", "")) == "10", "Group 2 preempt-delay mismatch"
        assert str(g2.get("priority", "")) == "20", "Group 2 priority mismatch"
        assert g2.get("rfc3768-compatibility") is not None, "Group 2 RFC3768 compatibility mismatch"
        assert isinstance(g2.get("garp"), dict), "Group 2 GARP should be a dictionary"
        assert str(g2.get("garp", {}).get("interval", "")) == "10", "Group 2 GARP interval mismatch"
        assert str(g2.get("garp", {}).get("master-delay", "")) == "5", "Group 2 GARP master-delay mismatch"
        assert isinstance(g2.get("health-check"), dict), "Group 2 health-check should be a dictionary"
        assert str(g2.get("health-check", {}).get("failure-count", "")) == "2", "Group 2 health-check failure count mismatch"
        assert str(g2.get("health-check", {}).get("interval", "")) == "30", "Group 2 health-check interval mismatch"
        assert isinstance(g2.get("track"), dict), "Group 2 track should be a dictionary"
        assert g2.get("track", {}).get("exclude-vrrp-interface") is not None, "Group 2 track exclude-vrrp should be set"
 #       assert str(g2.get("track", {}).get("interface", "")) == "br3", "Group 2 track interface mismatch"

        # Validate sync groups
        sync_groups = data.get("sync-group", {})
        print(f"\nDebug - Sync groups keys: {list(sync_groups.keys())}")
        assert isinstance(sync_groups, dict), "Sync Groups should be a dictionary"

        # Validate sync group 0 (test-updated)
        print("yo")
        sg0 = sync_groups.get("test-updated")
        assert sg0 is not None, "Sync group 'test-updated' not found"
        assert sg0.get("member") is not None, "Sync group 0 members should not be None"
        assert sg0.get("member", {}) == {"updated test": {}, "test2-updated": {}}, "Sync group 0 member mismatch"
        assert isinstance(sg0.get("health-check"), dict), "Sync group 0 health-check should be a dictionary"
        assert str(sg0.get("health-check", {}).get("failure-count", "")) == "4", "Sync group 0 health-check failure count mismatch"
        assert str(sg0.get("health-check", {}).get("interval", "")) == "45", "Sync group 0 health-check interval mismatch"
        assert str(sg0.get("health-check", {}).get("ping", "")) == "3.3.3.3", "Sync group 0 ping target mismatch"

        # Validate sync group 1 (test2-updated)
        sg1 = sync_groups.get("test2-updated")
        assert sg1 is not None, "Sync group 'test2-updated' not found"
        assert isinstance(sg1.get("member"), list), "Sync group 1 members should be a dictionary"
        assert sg1.get("member", {}) == {"test2-updated", "test3-updated"}, "Sync group 1 member mismatch"
        assert isinstance(sg1.get("health-check"), dict), "Sync group 1 health-check should be a dictionary"
        assert str(sg1.get("health-check", {}).get("failure-count", "")) == "5", "Sync group 1 health-check failure count mismatch"
        assert str(sg1.get("health-check", {}).get("interval", "")) == "50", "Sync group 1 health-check interval mismatch"
        assert str(sg1.get("health-check", {}).get("ping", "")) == "4.4.4.4", "Sync group 1 ping target mismatch"


        print("\n" + "=" * 50)
        print("VRRP UPDATE STAGE 1 CONFIGURATION SUCCESSFULLY VERIFIED!")
        print("=" * 50)