import pprint
from uuid import uuid4

from flask import session

from app.core.api.http.http_request import Action
from app.core.network.nat66.command_nat66 import CommandNAT66
from app.core.network.nat66.models import NAT66Config
from app.core.network.nat.parser import parse_nat_rules, parse_nat_statistic
from app.core.utils.process_config import (
    merge_dicts_delete,
    merge_dicts_set,
    process_commands,
)
from app.log.logger import logger
from app.socket.socket_manager import socket_manager


def fetch_nat66(provider, data):
    response = provider.http_service.show_all_configs()
    return response.json()['data'].get('nat66', {})


def fetch_nat66_rules(provider, data):
    response = provider.graphql_service.send_request(
        function_name='ShowRulesNat',
        data={
            'direction': data.get('direction'),
            'family': 'inet6',
        },
        verify=False,
    )
    return parse_nat_rules(response.json().get('data', {}))


def fetch_nat66_stat(provider, data):
    response = provider.graphql_service.send_request(
        function_name='ShowStatisticsNat',
        data={
            'direction': data.get('direction'),
            'family': 'inet6',
        },
        verify=False,
    )
    return parse_nat_statistic(response.json().get('data', {}))


def update_nat66(provider, data):
    username = session['username']
    diff = data.get('diff')
    current_nat66 = data.get('current')
    new_nat66 = data.get('new')

    print('NAT66 diff data:')
    print(pprint.pformat(diff, indent=2, width=80))

    results = []

    # Generate set commands.
    nat66_set_command = CommandNAT66(operator='set', resource='nat66')
    set_commands = nat66_set_command.generate_commands(
        diff['created'],
        current_nat66,
        new_nat66,
    )
    set_vyos_commands = nat66_set_command.get_commands()
    new_set_config = process_commands(set_vyos_commands)

    nat66_delete_command = CommandNAT66(operator='delete', resource='nat66')
    delete_commands = nat66_delete_command.generate_commands(
        diff['deleted'],
        current_nat66,
        new_nat66,
    )
    delete_vyos_commands = nat66_delete_command.get_commands()
    new_delete_config = process_commands(delete_vyos_commands)

    service = 'nat66'
    active_config = provider.verify_service.call_get_config(service)
    current_config = {service: active_config}

    merged_delete_config = merge_dicts_delete(
        current_config,
        new_delete_config,
        aggressive=True,
    )
    merged_config = merge_dicts_set(
        merged_delete_config,
        new_set_config,
    )

    print('Merged NAT66 delete config:')
    print(pprint.pformat(merged_delete_config, indent=2, width=80))
    print('Merged NAT66 config:')
    print(pprint.pformat(merged_config, indent=2, width=80))

    verification = None
    if merged_config:
        verification = provider.verify_service.call_verify(service, merged_config)

    print('NAT66 verification:')
    print(pprint.pformat(verification, indent=2, width=80))

    if str(verification) not in ('None', ''):
        print('NAT66 validation error:')
        print(pprint.pformat(verification, indent=2, width=80))
        return Exception(verification)
    
    NAT66Config.refresh(new_nat66)

    logger.debug('Merged NAT66 data: %s', new_nat66)

    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
            'id': str(uuid4()),
            'type': 'ignore',
            'title': 'Success: Update NAT66',
            'content': 'NAT66 is successfully updated',
        },
    )

    commands = list(set(set_commands)) + list(set(delete_commands))
    print('NAT66 commands:')
    print(pprint.pformat(commands, indent=2, width=80))

    if commands:
        response = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=commands,
            verify=False,
        ).json()
        results.append(
            {
                'cmd': commands,
                'success': response['success'],
                'error': response['error'],
            }
        )
        if response.get('success') is False or response.get('error'):
            return Exception(
                response.get('error') or 'Failed to update NAT66'
            )

    
    return results


def verify_nat66(provider, data):

    service = 'nat66'
    current_nat66 = provider.verify_service.call_get_config(service)
    print('Current NAT66 data: %s', current_nat66)

    if not isinstance(current_nat66, dict):
        current_nat66 = {}

    current_nat66.update(
        {
            'source': data.get('source', {}),
            'destination': data.get('destination', {}),
        }
    )

    print("NAT66 verify data: ")
    print(pprint.pformat(current_nat66, indent=4))

    verification = provider.verify_service.call_verify(
        service,
        current_nat66,
    )
    print('NAT66 verification result: %s', verification)
    return verification
