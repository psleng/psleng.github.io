
from typing import Any, Dict, List, Optional

from app.core.api.http.cmd.command import Command


def _is_str_not_empty(value: Any) -> bool:
    return value is not None and str(value) not in ['', 'None']


def _truthy_flag(value: Any) -> bool:
    return value not in [False, None, 'disable', 'false', 'False', 0]


class FlexRoutingCommand(Command):

    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'failover'))
        self.route_type = kwargs.get('route_type', 'route')
        self.cmds: List[str] = []
        self.vyos_cmds: List[str] = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args: str):
        if not args:
            return
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data: Optional[Dict[str, Any]] = None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            for route_prefix, route_data in data.items():
                self._process_route_prefix(
                    route_prefix=str(route_prefix),
                    route_data=route_data,
                    current_config=current_config or {},
                    new_config=new_config or {},
                )
            return self.cmds
        except Exception as e:
            print(f"Error generating flex routing commands: {e}")
            return []

    def _process_route_prefix(self, route_prefix: str, route_data: Any, current_config: Dict[str, Any], new_config: Dict[str, Any]):
        base_path = ['protocols', 'failover', self.route_type, route_prefix]

        if self.operator == 'delete':
            current_route = (current_config or {}).get(route_prefix)
            if current_route is not None and route_data == current_route:
                self.generate(*base_path)
                return

        for path_type in ('next-hop', 'dhcp-interface', 'interface'):
            entries = route_data.get(path_type)
            if isinstance(entries, dict):
                entries = [entries]
            for item in entries or []:
                if not isinstance(item, dict):
                    item = {str(item): {}}
                for path_value, options in item.items():
                    self._process_path(base_path, path_type, str(path_value), options or {}, new_config)

    def _process_path(self, route_base_path, path_type, path_value, options, new_config):
        path = route_base_path + [path_type, path_value]
        route_prefix = route_base_path[-1]
        if self.operator == 'delete':
            new_entries = (new_config or {}).get(route_prefix, {}).get(path_type, {})
            if path_value not in new_entries:
                self.generate(*path)
                return

        for field in ('interface', 'metric'):
            if _is_str_not_empty(options.get(field)):
                self.generate(*path, field, str(options[field]))
        if 'onlink' in options and _truthy_flag(options.get('onlink')):
            self.generate(*path, 'onlink')
        if 'check' in options:
            self._process_check(path, options['check'], new_config, route_prefix, path_type, path_value)

    def _process_check(self, parent_path: List[str], check_data: Any, new_config: Dict[str, Any], route_prefix: str, path_type: str, path_value: str):
        if check_data is None:
            return

        check_path = parent_path + ['check']

        if _is_str_not_empty(check_data.get('policy')):
            self.generate(*check_path, 'policy', str(check_data['policy']))

        if _is_str_not_empty(check_data.get('port')):
            self.generate(*check_path, 'port', str(check_data['port']))

        if _is_str_not_empty(check_data.get('timeout')):
            self.generate(*check_path, 'timeout', str(check_data['timeout']))

        if _is_str_not_empty(check_data.get('type')):
            self.generate(*check_path, 'type', str(check_data['type']))

        for count in ('failure-count', 'success-count'):
            if _is_str_not_empty(check_data.get(count)):
                self.generate(*check_path, count, str(check_data[count]))

        targets = check_data.get('target')
        if targets is None:
            return

        if isinstance(targets, list):
            for t in targets:
                if isinstance(t, dict):
                    for target_ip, target_opts in t.items():
                        self._process_target(check_path, str(target_ip), target_opts, new_config, route_prefix, path_type, path_value)
                else:
                    self._process_target(check_path, str(t), {}, new_config, route_prefix, path_type, path_value)
            return

        if isinstance(targets, dict):
            for target_ip, target_opts in targets.items():
                self._process_target(check_path, str(target_ip), target_opts, new_config, route_prefix, path_type, path_value)

    def _process_target(self, check_path: List[str], target_ip: str, target_opts: Any, new_config: Dict[str, Any], route_prefix: str, path_type: str, path_value: str):
        target_path = check_path + ['target', target_ip]

        if self.operator == 'delete':
            new_route = (new_config or {}).get(route_prefix, {})
            new_path_group = new_route.get(path_type, {}) if isinstance(new_route, dict) else {}
            new_entry = new_path_group.get(path_value, {}) if isinstance(new_path_group, dict) else {}
            new_check = new_entry.get('check', {}) if isinstance(new_entry, dict) else {}
            new_targets = new_check.get('target', {}) if isinstance(new_check, dict) else {}

            if not (isinstance(new_targets, dict) and target_ip in new_targets):
                self.generate(*target_path)
                return

            new_target_opts = new_targets.get(target_ip, {}) if isinstance(new_targets, dict) else {}
            if isinstance(target_opts, dict):
                old_interface = str(target_opts.get('interface'))
                new_interface = str((new_target_opts or {}).get('interface'))
                if _is_str_not_empty(old_interface) and (not _is_str_not_empty(new_interface) or old_interface != new_interface):
                    self.generate(*target_path, 'interface', old_interface)

            return

        if _is_str_not_empty(target_opts.get('interface')):
            self.generate(*target_path, 'interface', str(target_opts['interface']))

        if _is_str_not_empty(target_opts.get('vrf')):
            self.generate(*target_path, 'vrf', str(target_opts['vrf']))
