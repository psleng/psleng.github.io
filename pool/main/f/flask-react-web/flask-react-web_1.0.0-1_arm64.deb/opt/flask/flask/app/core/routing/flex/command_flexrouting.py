
from typing import Any, Dict, List, Optional

from app.core.api.http.cmd.command import Command


def _is_str_not_empty(value: Any) -> bool:
    return value is not None and str(value) not in ['', 'None']


def _truthy_flag(value: Any) -> bool:
    return value not in [False, None, 'disable', 'false', 'False', 0]


class FlexRoutingCommand(Command):
    """Command generator for VyOS Flex Routing (protocols failover).

    (set/delete):
    - protocols failover route <route-prefix> next-hop <n.n.n.n> [interface <intf>] [metric <1-255>] [onlink]
    - protocols failover route <route-prefix> next-hop <n.n.n.n> check ...
    - protocols failover route <route-prefix> dhcp-interface <dhcp-intf-name> [interface <intf>] [metric <1-255>] [onlink]
    - protocols failover route <route-prefix> dhcp-interface <dhcp-intf-name> check ...
    """

    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'failover'))
        self.cmds: List[str] = []
        self.vyos_cmds: List[str] = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args: str):
        if not args:
            return
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data: Optional[Dict[str, Any]] = None, current_config=None, new_config=None):
        try:
            if not data:
                return []

            for route_prefix, route_data in data.items():
                self._process_route_prefix(
                    route_prefix=str(route_prefix),
                    route_data=route_data,
                    current_config=current_config or {},
                    new_config=new_config or {},
                )
            return self.cmds
        except Exception as e:
            print(f"Error generating flex routing commands: {e}")
            return []

    def _process_route_prefix(self, route_prefix: str, route_data: Any, current_config: Dict[str, Any], new_config: Dict[str, Any]):
        base_path = ['protocols', 'failover', 'route', route_prefix]

        if self.operator == 'delete':
            current_route = (current_config or {}).get(route_prefix)
            if current_route is not None and route_data == current_route:
                self.generate(*base_path)
                return

        if 'next-hop' in route_data:
            self._process_next_hops(base_path, route_data.get('next-hop'), new_config)

        if 'dhcp-interface' in route_data:
            self._process_dhcp_interfaces(base_path, route_data.get('dhcp-interface'), new_config)

    def _process_next_hops(self, route_base_path: List[str], next_hops_data: Any, new_config: Dict[str, Any]):
        if next_hops_data is None:
            return

        if isinstance(next_hops_data, list):
            for item in next_hops_data:
                if isinstance(item, dict):
                    for nh_ip, nh_opts in item.items():
                        self._process_single_next_hop(route_base_path, str(nh_ip), nh_opts, new_config)
                else:
                    self._process_single_next_hop(route_base_path, str(item), {}, new_config)
            return

        if isinstance(next_hops_data, dict):
            for nh_ip, nh_opts in next_hops_data.items():
                self._process_single_next_hop(route_base_path, str(nh_ip), nh_opts, new_config)

    def _process_single_next_hop(self, route_base_path: List[str], nh_ip: str, nh_opts: Any, new_config: Dict[str, Any]):
        nh_path = route_base_path + ['next-hop', nh_ip]

        if self.operator == 'delete':
            route_prefix = route_base_path[-1]
            new_route = (new_config or {}).get(route_prefix, {})
            new_next_hops = new_route.get('next-hop', {}) if isinstance(new_route, dict) else {}
            if isinstance(new_next_hops, dict) and nh_ip not in new_next_hops:
                self.generate(*nh_path)
                return

        if _is_str_not_empty(nh_opts.get('interface')):
            self.generate(*nh_path, 'interface', str(nh_opts['interface']))

        if _is_str_not_empty(nh_opts.get('metric')):
            self.generate(*nh_path, 'metric', str(nh_opts['metric']))

        if 'onlink' in nh_opts and _truthy_flag(nh_opts.get('onlink')):
            self.generate(*nh_path, 'onlink')

        if 'check' in nh_opts:
            self._process_check(
                parent_path=nh_path,
                check_data=nh_opts.get('check'),
                new_config=new_config,
                route_prefix=route_base_path[-1],
                path_type='next-hop',
                path_value=nh_ip,
            )

    def _process_dhcp_interfaces(self, route_base_path: List[str], dhcp_data: Any, new_config: Dict[str, Any]):
        if dhcp_data is None:
            return

        if isinstance(dhcp_data, list):
            for item in dhcp_data:
                if isinstance(item, dict):
                    for dhcp_name, dhcp_opts in item.items():
                        self._process_single_dhcp_interface(route_base_path, str(dhcp_name), dhcp_opts, new_config)
                else:
                    self._process_single_dhcp_interface(route_base_path, str(item), {}, new_config)
            return

        if isinstance(dhcp_data, dict):
            for dhcp_name, dhcp_opts in dhcp_data.items():
                self._process_single_dhcp_interface(route_base_path, str(dhcp_name), dhcp_opts, new_config)

    def _process_single_dhcp_interface(self, route_base_path: List[str], dhcp_name: str, dhcp_opts: Any, new_config: Dict[str, Any]):
        dhcp_path = route_base_path + ['dhcp-interface', dhcp_name]

        if self.operator == 'delete':
            route_prefix = route_base_path[-1]
            new_route = (new_config or {}).get(route_prefix, {})
            new_dhcp = new_route.get('dhcp-interface', {}) if isinstance(new_route, dict) else {}
            if isinstance(new_dhcp, dict) and dhcp_name not in new_dhcp:
                self.generate(*dhcp_path)
                return

        if _is_str_not_empty(dhcp_opts.get('interface')):
            self.generate(*dhcp_path, 'interface', str(dhcp_opts['interface']))

        if _is_str_not_empty(dhcp_opts.get('metric')):
            self.generate(*dhcp_path, 'metric', str(dhcp_opts['metric']))

        if 'onlink' in dhcp_opts and _truthy_flag(dhcp_opts.get('onlink')):
            self.generate(*dhcp_path, 'onlink')

        if 'check' in dhcp_opts:
            self._process_check(
                parent_path=dhcp_path,
                check_data=dhcp_opts.get('check'),
                new_config=new_config,
                route_prefix=route_base_path[-1],
                path_type='dhcp-interface',
                path_value=dhcp_name,
            )

    def _process_check(self, parent_path: List[str], check_data: Any, new_config: Dict[str, Any], route_prefix: str, path_type: str, path_value: str):
        if check_data is None:
            return

        check_path = parent_path + ['check']

        if _is_str_not_empty(check_data.get('policy')):
            self.generate(*check_path, 'policy', str(check_data['policy']))

        if _is_str_not_empty(check_data.get('port')):
            self.generate(*check_path, 'port', str(check_data['port']))

        if _is_str_not_empty(check_data.get('timeout')):
            self.generate(*check_path, 'timeout', str(check_data['timeout']))

        if _is_str_not_empty(check_data.get('type')):
            self.generate(*check_path, 'type', str(check_data['type']))

        targets = check_data.get('target')
        if targets is None:
            return

        if isinstance(targets, list):
            for t in targets:
                if isinstance(t, dict):
                    for target_ip, target_opts in t.items():
                        self._process_target(check_path, str(target_ip), target_opts, new_config, route_prefix, path_type, path_value)
                else:
                    self._process_target(check_path, str(t), {}, new_config, route_prefix, path_type, path_value)
            return

        if isinstance(targets, dict):
            for target_ip, target_opts in targets.items():
                self._process_target(check_path, str(target_ip), target_opts, new_config, route_prefix, path_type, path_value)

    def _process_target(self, check_path: List[str], target_ip: str, target_opts: Any, new_config: Dict[str, Any], route_prefix: str, path_type: str, path_value: str):
        target_path = check_path + ['target', target_ip]

        if self.operator == 'delete':
            new_route = (new_config or {}).get(route_prefix, {})
            new_path_group = new_route.get(path_type, {}) if isinstance(new_route, dict) else {}
            new_entry = new_path_group.get(path_value, {}) if isinstance(new_path_group, dict) else {}
            new_check = new_entry.get('check', {}) if isinstance(new_entry, dict) else {}
            new_targets = new_check.get('target', {}) if isinstance(new_check, dict) else {}

            if not (isinstance(new_targets, dict) and target_ip in new_targets):
                self.generate(*target_path)
                return

            new_target_opts = new_targets.get(target_ip, {}) if isinstance(new_targets, dict) else {}
            if isinstance(target_opts, dict):
                old_interface = str(target_opts.get('interface'))
                new_interface = str((new_target_opts or {}).get('interface'))
                if _is_str_not_empty(old_interface) and (not _is_str_not_empty(new_interface) or old_interface != new_interface):
                    self.generate(*target_path, 'interface', old_interface)

            return

        if _is_str_not_empty(target_opts.get('interface')):
            self.generate(*target_path, 'interface', str(target_opts['interface']))

        if _is_str_not_empty(target_opts.get('vrf')):
            self.generate(*target_path, 'vrf', str(target_opts['vrf']))
