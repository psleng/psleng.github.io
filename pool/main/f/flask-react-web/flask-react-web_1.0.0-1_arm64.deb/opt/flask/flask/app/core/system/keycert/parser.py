def normalize_crl_content(content):
    content = content.replace('-----BEGIN X509 CRL-----', '').replace('-----END X509 CRL-----', '')
    return ''.join(content.split())


def parse_to_keycert_config(data, verify=False):
    
    result = {}
    
    if 'certificates' in data:
        certificates = data['certificates']
        
        if 'ca' in certificates:
            result['ca'] = {}
            for cert in certificates['ca']:
                name = cert['name']
                result['ca'][name] = {
                    'certificate': cert['certificate']
                }
                if cert.get('private_key') and cert['private_key'].strip():
                    result['ca'][name]['private'] = {'key': cert['private_key']}
                crls = list(dict.fromkeys(filter(None, (
                    normalize_crl_content(crl) for crl in cert.get('crl', [])
                ))))
                if crls:
                    result['ca'][name]['crl'] = crls
                if cert.get('description', '').strip():
                    result['ca'][name]['description'] = cert['description']
                if cert.get('revoke'):
                    result['ca'][name]['revoke'] = {}
                if cert.get('system_install'):
                    result['ca'][name]['system_install' if verify else 'system-install'] = {}
        
        if 'certificate' in certificates:
            result['certificate'] = {}
            for cert in certificates['certificate']:
                name = cert['name']
                result['certificate'][name] = {}
                if cert.get('certificate'):
                    result['certificate'][name]['certificate'] = cert['certificate']
                if cert.get('private_key') and cert['private_key'].strip():
                    result['certificate'][name]['private'] = {'key': cert['private_key']}
                if cert.get('description', '').strip():
                    result['certificate'][name]['description'] = cert['description']
                if cert.get('revoke'):
                    result['certificate'][name]['revoke'] = {}
                if cert.get('acme') is not None:
                    result['certificate'][name]['acme'] = {
                        (key if verify else key.replace('_', '-')): str(value)
                        for key, value in cert['acme'].items()
                        if value is not None and str(value).strip()
                    }
                    if verify:
                        result['certificate'][name]['acme']['domain_name'] = [cert['acme']['domain_name']]
        
        if 'crl' in certificates:
            result['crl'] = {}
            for cert in certificates['crl']:
                name = cert['name']
                result['crl'][name] = {
                    'certificate': cert['certificate']
                }
                if cert.get('private_key') and cert['private_key'].strip():
                    result['crl'][name]['private'] = {'key': cert['private_key']}
    
    if 'keys' in data:
        keys = data['keys']
        
        if 'key_pair' in keys:
            result['key-pair'] = {}
            for key in keys['key_pair']:
                name = key['name']
                result['key-pair'][name] = {}
                if key.get('private_key') and key['private_key'].strip():
                    result['key-pair'][name]['private'] = {'key': key['private_key']}
                if key.get('public_key') and key['public_key'].strip():
                    result['key-pair'][name]['public'] = {'key': key['public_key']}
        
        if 'openvpn' in keys:
            result['openvpn'] = {'shared-secret': {}}
            for key in keys['openvpn']:
                name = key['name']
                result['openvpn']['shared-secret'][name] = {}
                if key.get('private_key') and key['private_key'].strip():
                    result['openvpn']['shared-secret'][name]['key'] = key['private_key']
                    version = str(key.get('version') or '').strip()
                    result['openvpn']['shared-secret'][name]['version'] = version if version else '1'
        
        if 'ssh' in keys:
            result['ssh'] = {}
            for key in keys['ssh']:
                name = key['name']
                result['ssh'][name] = {}
                if key.get('private_key') and key['private_key'].strip():
                    result['ssh'][name]['private'] = {'key': key['private_key']}
                if key.get('public_key') and key['public_key'].strip():
                    result['ssh'][name]['public'] = {'key': key['public_key']}
        
        if 'wireguard' in keys:
            result['wireguard'] = {}
            for key in keys['wireguard']:
                name = key['name']
                result['wireguard'][name] = {}
                if key.get('private_key') and key['private_key'].strip():
                    result['wireguard'][name]['private'] = {'key': key['private_key']}
                if key.get('public_key') and key['public_key'].strip():
                    result['wireguard'][name]['public'] = {'key': key['public_key']}
        
        if 'dh' in keys:
            result['dh'] = {}
            for dh_item in keys['dh']:
                name = dh_item['name']
                result['dh'][name] = {}
                if dh_item.get('parameters') and dh_item['parameters'].strip():
                    result['dh'][name]['parameters'] = dh_item['parameters']
    
    return result
