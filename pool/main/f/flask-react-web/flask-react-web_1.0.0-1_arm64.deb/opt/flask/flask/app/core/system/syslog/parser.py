from typing import Any, Dict


def parse_to_syslog_config(data: Dict[str, Any]) -> Dict[str, Any]:
    result: Dict[str, Any] = {}

    console = data.get('console') or {}
    local = data.get('local') or {}
    marker = data.get('marker') or {}

    if isinstance(console, dict):
        facilities = console.get('facilities') or []
        if isinstance(facilities, list) and facilities:
            result.setdefault('console', {})
            for item in facilities:
                if not isinstance(item, dict):
                    continue
                facility = item.get('facility')
                level = item.get('level')
                if not facility:
                    continue
                result['console'].setdefault('facility', {})
                result['console']['facility'].setdefault(str(facility), {})
                if level:
                    result['console']['facility'][str(facility)]['level'] = str(level)

    if isinstance(local, dict):
        facilities = local.get('facilities') or []
        if isinstance(facilities, list) and facilities:
            result.setdefault('local', {})
            for item in facilities:
                if not isinstance(item, dict):
                    continue
                facility = item.get('facility')
                level = item.get('level')
                if not facility:
                    continue
                result['local'].setdefault('facility', {})
                result['local']['facility'].setdefault(str(facility), {})
                if level:
                    result['local']['facility'][str(facility)]['level'] = str(level)

    remotes = data.get('remote') or []
    if isinstance(remotes, list) and remotes:
        result.setdefault('remote', {})
        for r in remotes:
            if not isinstance(r, dict):
                continue
            host = (r.get('host') or '').strip()
            if not host:
                continue

            node: Dict[str, Any] = {}

            if r.get('port') is not None:
                node['port'] = str(r.get('port'))

            if r.get('protocol'):
                node['protocol'] = str(r.get('protocol'))

            if r.get('sourceAddress'):
                node['source-address'] = str(r.get('sourceAddress'))

            if r.get('vrf'):
                node['vrf'] = str(r.get('vrf'))

            fmt = r.get('format') or {}
            if isinstance(fmt, dict):
                if fmt.get('includeTimezone'):
                    node.setdefault('format', {})
                    node['format']['include-timezone'] = {}
                if fmt.get('octetCounted'):
                    node.setdefault('format', {})
                    node['format']['octet-counted'] = {}

            tls = r.get('tls') or {}
            if isinstance(tls, dict) and any(v is not None and v != '' and v != {} for v in tls.values()):
                tls_node: Dict[str, Any] = {}
                if tls.get('authMode'):
                    tls_node['auth-mode'] = str(tls.get('authMode'))
                if tls.get('caCertificate'):
                    tls_node['ca-certificate'] = str(tls.get('caCertificate'))
                if tls.get('certificate'):
                    tls_node['certificate'] = str(tls.get('certificate'))
                if tls.get('permittedPeer'):
                    tls_node['permitted-peer'] = str(tls.get('permittedPeer'))
                if tls_node:
                    node['tls'] = tls_node

            facilities = r.get('facilities') or []
            if isinstance(facilities, list) and facilities:
                node.setdefault('facility', {})
                for item in facilities:
                    if not isinstance(item, dict):
                        continue
                    facility = item.get('facility')
                    level = item.get('level')
                    if not facility:
                        continue
                    node['facility'].setdefault(str(facility), {})
                    if level:
                        node['facility'][str(facility)]['level'] = str(level)

            result['remote'][host] = node

    if isinstance(marker, dict):
        marker_node: Dict[str, Any] = {}
        if marker.get('disable'):
            marker_node['disable'] = {}
        if marker.get('interval') is not None:
            marker_node['interval'] = str(marker.get('interval'))
        if marker_node:
            result['marker'] = marker_node

    preserve = data.get('preserveFqdn')
    if preserve:
        result['preserve-fqdn'] = {}

    return result
