import json
from typing import Any, Dict, List, Literal, Optional

from app.db.database import db
from app.log.logger import logger
from app.core.operation.cellular.parser import parse_wwan_config_to_form
from pydantic import BaseModel, field_validator
from sqlalchemy import Column, Integer, String, Text


WWANLimitAction = Literal['none', 'disable', 'sim-failover', 'sim-failover-sticky']


class WWANLimitDTO(BaseModel):
    size: Optional[Any] = None
    action: Optional[WWANLimitAction] = None
    billingDate: Optional[Any] = None
    warningThresholds: Optional[List[Any]] = None

    @field_validator('action', mode='before')
    @classmethod
    def normalize_empty_action(cls, value):
        return None if value == '' else value


class WWANSimSlotDTO(BaseModel):
    slotNumber: Any
    enabled: Optional[bool] = None
    iccid: Optional[str] = None
    apn: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    authType: Optional[str] = None
    pdpType: Optional[str] = None
    roaming: Optional[Any] = None
    pin: Optional[str] = None
    puk: Optional[str] = None
    supportedBands: Optional[List[str]] = None
    preferredCarrier: Optional[str] = None
    enableNetworkScan: Optional[bool] = None
    mtu: Optional[Any] = None
    warning: Optional[str] = None
    dataLimit: Optional[WWANLimitDTO] = None

    @field_validator('mtu', mode='before')
    @classmethod
    def validate_mtu(cls, value):
        if value in (None, ''):
            return None
        if isinstance(value, bool) or (isinstance(value, float) and not value.is_integer()):
            raise ValueError('MTU must be an integer between 0 and 1500')
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            raise ValueError('MTU must be an integer between 0 and 1500')
        if not 0 <= parsed <= 1500:
            raise ValueError('MTU must be an integer between 0 and 1500')
        return parsed


class WWANSimFailbackDTO(BaseModel):
    enable: Optional[bool] = None
    checkInterval: Optional[Any] = None
    stabilityTime: Optional[Any] = None


class WWANSignalThresholdDTO(BaseModel):
    rssi: Optional[Any] = None
    rsrp: Optional[Any] = None


class WWANSimFailoverDTO(BaseModel):
    enable: Optional[bool] = None
    connectRetries: Optional[Any] = None
    signalLossTimer: Optional[Any] = None
    signalThreshold: Optional[WWANSignalThresholdDTO] = None


class WWANSimDTO(BaseModel):
    activeSlot: Optional[Any] = None
    slots: Optional[List[WWANSimSlotDTO]] = None
    simFailback: Optional[WWANSimFailbackDTO] = None
    simFailover: Optional[WWANSimFailoverDTO] = None


class WWANReconnectionRetryIntervalDTO(BaseModel):
    goodSignal: Optional[Any] = None
    poorSignal: Optional[Any] = None


class WWANReconnectionDTO(BaseModel):
    enhanced: Optional[Any] = None
    signalThreshold: Optional[WWANSignalThresholdDTO] = None
    retryInterval: Optional[WWANReconnectionRetryIntervalDTO] = None
    maxWaitForSignal: Optional[Any] = None
    signalCheckInterval: Optional[Any] = None
    signalStrengthBuffer: Optional[Any] = None


class WWANInterfaceManagementDTO(BaseModel):
    enable: Optional[bool] = None
    bearerDisconnectDelay: Optional[Any] = None
    registrationRecoveryDelay: Optional[Any] = None
    registrationFlapCount: Optional[Any] = None
    registrationFlapWindow: Optional[Any] = None
    ipChangeDelay: Optional[Any] = None
    ensureLinkUpOnConnect: Optional[Any] = None
    monitorBearerState: Optional[Any] = None
    monitorIpChanges: Optional[Any] = None
    interfaceUpTimeout: Optional[Any] = None


class WWANConnectivityMonitoringDTO(BaseModel):
    enable: Optional[bool] = None
    interval: Optional[Any] = None
    timeout: Optional[Any] = None
    retryCount: Optional[Any] = None
    failureThreshold: Optional[Any] = None
    testIpv4: Optional[Any] = None
    testIpv6: Optional[Any] = None
    requireBoth: Optional[bool] = None
    ipv4Targets: Optional[List[str]] = None
    ipv6Targets: Optional[List[str]] = None


class WWANDataUsageDTO(BaseModel):
    monitoringInterval: Optional[Any] = None
    warningThresholds: Optional[List[Any]] = None
    size: Optional[Any] = None
    action: Optional[WWANLimitAction] = None
    billingDate: Optional[Any] = None
    defaultLimit: Optional[WWANLimitDTO] = None

    @field_validator('action', mode='before')
    @classmethod
    def normalize_empty_action(cls, value):
        return None if value == '' else value


class WWANHardwareResetDTO(BaseModel):
    enable: Optional[bool] = None
    maxAttempts: Optional[Any] = None
    cooldown: Optional[Any] = None


class WWANNetworkScanDTO(BaseModel):
    timeout: Optional[Any] = None


class WWANFailedRetryDTO(BaseModel):
    enable: Optional[bool] = None
    intervals: Optional[List[Any]] = None
    maxInterval: Optional[Any] = None
    escalationThreshold: Optional[Any] = None


class WWANTimeoutsDTO(BaseModel):
    connection: Optional[Any] = None
    connections: Optional[Any] = None
    registration: Optional[Any] = None
    normalMonitoringInterval: Optional[Any] = None


class WWANLoggingDTO(BaseModel):
    level: Optional[str] = None
    sink: Optional[str] = None
    verbose: Optional[Any] = None


class WWANApnDiscoveryDTO(BaseModel):
    android: Optional[bool] = None


class WWANMirrorDTO(BaseModel):
    ingress: Optional[str] = None
    egress: Optional[str] = None


class WWANIpPassthroughDTO(BaseModel):
    enabled: Optional[bool] = None
    interface: Optional[str] = None
    mac: Optional[str] = None
    leaseTime: Optional[Any] = None
    managementAddress: Optional[str] = None
    managementAddressIpv6: Optional[str] = None
    dnsServers: Optional[List[str]] = None
    disableMssClamp: Optional[bool] = None


class WWANIpv6ManagementAddressDTO(BaseModel):
    enabled: Optional[bool] = None
    disableDefaultHttps: Optional[bool] = None
    hostId: Optional[str] = None
    permitTcp: Optional[List[Any]] = None
    permitUdp: Optional[List[Any]] = None
    permitSource: Optional[List[str]] = None


class WWANIpv6BridgingDTO(BaseModel):
    interface: Optional[str] = None
    reconciliationInterval: Optional[Any] = None


class UpdateWWANInterfaceDTO(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    vrf: Optional[str] = None
    mtu: Optional[Any] = None
    ip: Optional[Dict[str, Any]] = None
    dhcp: Optional[Dict[str, Any]] = None
    network: Optional[Dict[str, Any]] = None
    mirror: Optional[WWANMirrorDTO] = None
    ipPassthrough: Optional[WWANIpPassthroughDTO] = None
    ipv6ManagementAddress: Optional[WWANIpv6ManagementAddressDTO] = None
    ipv6Bridging: Optional[WWANIpv6BridgingDTO] = None
    connectionMode: Optional[str] = None
    networkMode: Optional[str] = None
    networkTime: Optional[bool] = None
    apnDiscovery: Optional[WWANApnDiscoveryDTO] = None
    sim: Optional[WWANSimDTO] = None
    reconnection: Optional[WWANReconnectionDTO] = None
    interfaceManagement: Optional[WWANInterfaceManagementDTO] = None
    connectivityMonitoring: Optional[WWANConnectivityMonitoringDTO] = None
    dataUsage: Optional[WWANDataUsageDTO] = None
    hardwareReset: Optional[WWANHardwareResetDTO] = None
    failedRetry: Optional[WWANFailedRetryDTO] = None
    networkScan: Optional[WWANNetworkScanDTO] = None
    timeouts: Optional[WWANTimeoutsDTO] = None
    logging: Optional[WWANLoggingDTO] = None


class WWANInterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_wwan_interface'

    id = Column(Integer, primary_key=True)
    interface_name = Column(String(50), nullable=False, unique=True)
    config_json = Column(Text, nullable=False, default='{}')

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: Dict[str, Any]):
        try:
            cls.truncate()
            if not isinstance(data, dict):
                return

            for interface_name, config in data.items():
                if not isinstance(config, dict):
                    continue
                db.session.add(cls(
                    interface_name=interface_name,
                    config_json=json.dumps(config)
                ))
            db.session.commit()
        except Exception as e:
            logger.error(f"Error refreshing WWAN config: {e}")
            raise

    @classmethod
    def upsert_many(cls, data: Dict[str, Any]):
        try:
            if not isinstance(data, dict):
                return

            for interface_name, config in data.items():
                if not isinstance(config, dict):
                    continue
                row = cls.query.filter_by(interface_name=interface_name).first()
                if row:
                    row.config_json = json.dumps(config)
                else:
                    db.session.add(cls(
                        interface_name=interface_name,
                        config_json=json.dumps(config)
                    ))
            db.session.commit()
        except Exception as e:
            logger.error(f"Error upserting WWAN config: {e}")
            raise

    def raw_config(self):
        try:
            return json.loads(self.config_json or '{}')
        except Exception:
            return {}

    def serialize(self):
        return parse_wwan_config_to_form(self.interface_name, self.raw_config())


WWAN = WWANInterfaceConfig
