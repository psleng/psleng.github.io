from pydantic import BaseModel, RootModel
from typing import Optional, List, Dict
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.log.logger import logger
import json

class AreaRangeDTO(BaseModel):
    prefix: str
    cost: Optional[str] = ""
    notAdvertise: bool = False
    substitute: Optional[str] = ""


class AreaTypeConfigDTO(BaseModel):
    defaultCost: Optional[str] = ""
    noSummary: bool = False
    translate: Optional[str] = ""


class AreaDTO(BaseModel):
    id: Optional[str] = None
    areaNumber: str
    networks: List[str] = []
    authentication: str = "None"
    ranges: List[AreaRangeDTO] = []
    areaType: str = "normal"
    areaTypeConfig: AreaTypeConfigDTO = AreaTypeConfigDTO()


class MD5KeyDTO(BaseModel):
    keyId: str
    md5Key: str


class InterfaceAuthenticationDTO(BaseModel):
    type: str = "None"
    plaintextPassword: Optional[str] = ""
    md5Keys: List[MD5KeyDTO] = []


class InterfaceDTO(BaseModel):
    id: Optional[str] = None
    name: str
    area: str
    bandwidth: Optional[str] = ""
    cost: Optional[str] = ""
    deadInterval: Optional[str] = ""
    helloInterval: Optional[str] = ""
    helloMultiplier: Optional[str] = ""
    mtuIgnore: bool = False
    network: str = "broadcast"
    passiveDisable: bool = False
    priority: Optional[str] = ""
    retransmitInterval: Optional[str] = ""
    retransmitWindow: Optional[str] = ""
    transmitDelay: Optional[str] = ""
    authentication: InterfaceAuthenticationDTO = InterfaceAuthenticationDTO()


class RedistributionProtocolDTO(BaseModel):
    enabled: bool = False
    metric: Optional[str] = ""
    metricType: Optional[str] = ""


class RedistributionDTO(BaseModel):
    connected: RedistributionProtocolDTO = RedistributionProtocolDTO()
    kernel: RedistributionProtocolDTO = RedistributionProtocolDTO()
    static: RedistributionProtocolDTO = RedistributionProtocolDTO()
    rip: RedistributionProtocolDTO = RedistributionProtocolDTO()


class NeighborDTO(BaseModel):
    ip: str
    pollInterval: Optional[str] = ""
    priority: Optional[str] = ""


class SummaryAddressDTO(BaseModel):
    prefix: str
    notAdvertise: bool = False


class AdvancedConfigDTO(BaseModel):
    aggregationTimer: Optional[str] = ""
    autoCostReferenceBandwidth: Optional[str] = ""
    defaultMetric: Optional[str] = ""
    capabilityOpaque: bool = False
    logAdjacencyChanges: bool = False
    maximumPaths: Optional[str] = ""
    passiveInterfaceDefault: bool = False
    refreshTimers: Optional[str] = ""
    abrType: Optional[str] = ""
    opaqueLsa: bool = False
    rfc1583Compatibility: bool = False
    routerId: Optional[str] = ""
    spfDelay: Optional[str] = ""
    spfInitialHoldtime: Optional[str] = ""
    spfMaxHoldtime: Optional[str] = ""
    defaultInformationAlways: bool = False
    defaultInformationMetric: Optional[str] = ""
    defaultInformationMetricType: Optional[str] = ""
    distanceGlobal: Optional[str] = ""
    distanceOspfExternal: Optional[str] = ""
    distanceOspfInterArea: Optional[str] = ""
    distanceOspfIntraArea: Optional[str] = ""
    gracefulRestart: bool = False
    gracefulRestartGracePeriod: Optional[str] = ""
    maxMetricAdministrative: bool = False
    maxMetricOnShutdown: Optional[str] = ""
    maxMetricOnStartup: Optional[str] = ""
    neighbors: List[NeighborDTO] = []
    summaryAddresses: List[SummaryAddressDTO] = []


class UpdateOSPFDTO(BaseModel):
    areas: Optional[List[AreaDTO]] = []
    interfaces: Optional[List[InterfaceDTO]] = []
    redistribution: RedistributionDTO = RedistributionDTO()
    advanced: AdvancedConfigDTO = AdvancedConfigDTO()

class VerifyOSPFDTO(BaseModel):
    verify_type: str
    areas: Optional[List[AreaDTO]] = []
    interfaces: Optional[List[InterfaceDTO]] = []

class OSPFConfig(db.Model):
    __tablename__ = 'vyos_config_ospf'
    
    id = Column(Integer, primary_key=True)
    
    aggregation_timer = Column(Integer)
    auto_cost_reference_bandwidth = Column(Integer)
    default_metric = Column(Integer)
    capability_opaque = Column(Boolean, default=False)
    log_adjacency_changes_detail = Column(Boolean, default=False)
    maximum_paths = Column(Integer)
    passive_interface_default = Column(Boolean, default=False)
    refresh_timers = Column(Integer)
    
    parameters_abr_type = Column(String(50))
    parameters_opaque_lsa = Column(Boolean, default=False)
    parameters_rfc1583_compatibility = Column(Boolean, default=False)
    parameters_router_id = Column(String(50))
    
    timers_throttle_spf_delay = Column(Integer)
    timers_throttle_spf_initial_holdtime = Column(Integer)
    timers_throttle_spf_max_holdtime = Column(Integer)
    
    default_information_always = Column(Boolean, default=False)
    default_information_metric = Column(Integer)
    default_information_metric_type = Column(Integer)
    
    distance_global = Column(Integer)
    distance_ospf_external = Column(Integer)
    distance_ospf_inter_area = Column(Integer)
    distance_ospf_intra_area = Column(Integer)
    
    graceful_restart = Column(Boolean, default=False)
    graceful_restart_grace_period = Column(Integer)
    
    max_metric_administrative = Column(Boolean, default=False)
    max_metric_on_shutdown = Column(Integer)
    max_metric_on_startup = Column(Integer)
    
    areas = relationship("OSPFArea", back_populates="ospf_config", cascade="all, delete-orphan")
    interfaces = relationship("OSPFInterface", back_populates="ospf_config", cascade="all, delete-orphan")
    redistributes = relationship("OSPFRedistribute", back_populates="ospf_config", cascade="all, delete-orphan")
    neighbors = relationship("OSPFNeighbor", back_populates="ospf_config", cascade="all, delete-orphan")
    summary_addresses = relationship("OSPFSummaryAddress", back_populates="ospf_config", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'id': self.id,
            'aggregation_timer': self.aggregation_timer,
            'auto_cost_reference_bandwidth': self.auto_cost_reference_bandwidth,
            'default_metric': self.default_metric,
            'capability_opaque': self.capability_opaque,
            'log_adjacency_changes_detail': self.log_adjacency_changes_detail,
            'maximum_paths': self.maximum_paths,
            'passive_interface_default': self.passive_interface_default,
            'refresh_timers': self.refresh_timers,
            'parameters_abr_type': self.parameters_abr_type,
            'parameters_opaque_lsa': self.parameters_opaque_lsa,
            'parameters_rfc1583_compatibility': self.parameters_rfc1583_compatibility,
            'parameters_router_id': self.parameters_router_id,
            'timers_throttle_spf_delay': self.timers_throttle_spf_delay,
            'timers_throttle_spf_initial_holdtime': self.timers_throttle_spf_initial_holdtime,
            'timers_throttle_spf_max_holdtime': self.timers_throttle_spf_max_holdtime,
            'default_information_always': self.default_information_always,
            'default_information_metric': self.default_information_metric,
            'default_information_metric_type': self.default_information_metric_type,
            'distance_global': self.distance_global,
            'distance_ospf_external': self.distance_ospf_external,
            'distance_ospf_inter_area': self.distance_ospf_inter_area,
            'distance_ospf_intra_area': self.distance_ospf_intra_area,
            'graceful_restart': self.graceful_restart,
            'graceful_restart_grace_period': self.graceful_restart_grace_period,
            'max_metric_administrative': self.max_metric_administrative,
            'max_metric_on_shutdown': self.max_metric_on_shutdown,
            'max_metric_on_startup': self.max_metric_on_startup,
            'areas': [area.serialize() for area in self.areas],
            'interfaces': [intf.serialize() for intf in self.interfaces],
            'redistributes': [r.serialize() for r in self.redistributes],
            'neighbors': [n.serialize() for n in self.neighbors],
            'summary_addresses': [s.serialize() for s in self.summary_addresses]
        }

    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_ospf_area_network',
            'vyos_config_ospf_area_range',
            'vyos_config_ospf_area',
            'vyos_config_ospf_interface_auth_md5_key',
            'vyos_config_ospf_interface',
            'vyos_config_ospf_redistribute',
            'vyos_config_ospf_neighbor',
            'vyos_config_ospf_summary_address',
            'vyos_config_ospf'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh OSPF configuration from VyOS data"""
        try:
            # logger.info("Refreshing OSPF configuration")
            # logger.info(data)
            cls.truncate()
            
            ospf_config = cls()
            
            if 'aggregation' in data and 'timer' in data['aggregation']:
                ospf_config.aggregation_timer = int(data['aggregation']['timer'])
            
            if 'auto-cost' in data and 'reference-bandwidth' in data['auto-cost']:
                ospf_config.auto_cost_reference_bandwidth = int(data['auto-cost']['reference-bandwidth'])
            
            if 'default-metric' in data:
                ospf_config.default_metric = int(data['default-metric'])
            
            ospf_config.capability_opaque = 'capability' in data and 'opaque' in data.get('capability', {})
            ospf_config.log_adjacency_changes_detail = 'log-adjacency-changes' in data and 'detail' in data.get('log-adjacency-changes', {})
            
            if 'maximum-paths' in data:
                ospf_config.maximum_paths = int(data['maximum-paths'])
            
            ospf_config.passive_interface_default = data.get('passive-interface') == 'default'
            
            if 'refresh' in data and 'timers' in data['refresh']:
                ospf_config.refresh_timers = int(data['refresh']['timers'])
            
            if 'parameters' in data:
                params = data['parameters']
                ospf_config.parameters_abr_type = params.get('abr-type')
                ospf_config.parameters_opaque_lsa = 'opaque-lsa' in params
                ospf_config.parameters_rfc1583_compatibility = 'rfc1583-compatibility' in params
                ospf_config.parameters_router_id = params.get('router-id')
            
            if 'timers' in data and 'throttle' in data['timers'] and 'spf' in data['timers']['throttle']:
                spf = data['timers']['throttle']['spf']
                if 'delay' in spf:
                    ospf_config.timers_throttle_spf_delay = int(spf['delay'])
                if 'initial-holdtime' in spf:
                    ospf_config.timers_throttle_spf_initial_holdtime = int(spf['initial-holdtime'])
                if 'max-holdtime' in spf:
                    ospf_config.timers_throttle_spf_max_holdtime = int(spf['max-holdtime'])
            
            
            if 'default-information' in data:
                default_info = data['default-information']
                ospf_config.default_information_always = 'always' in default_info
                if 'metric' in default_info:
                    ospf_config.default_information_metric = int(default_info['metric'])
                if 'metric-type' in default_info:
                    ospf_config.default_information_metric_type = int(default_info['metric-type'])
            
            
            if 'distance' in data:
                distance = data['distance']
                if 'global' in distance:
                    ospf_config.distance_global = int(distance['global'])
                if 'ospf' in distance:
                    ospf_dist = distance['ospf']
                    if 'external' in ospf_dist:
                        ospf_config.distance_ospf_external = int(ospf_dist['external'])
                    if 'inter-area' in ospf_dist:
                        ospf_config.distance_ospf_inter_area = int(ospf_dist['inter-area'])
                    if 'intra-area' in ospf_dist:
                        ospf_config.distance_ospf_intra_area = int(ospf_dist['intra-area'])
            
            if 'graceful-restart' in data:
                gr = data['graceful-restart']
                ospf_config.graceful_restart = True
                if isinstance(gr, dict) and 'grace-period' in gr:
                    ospf_config.graceful_restart_grace_period = int(gr['grace-period'])
            
            if 'max-metric' in data:
                max_metric = data['max-metric']
                
                # Handle router-lsa nested format
                if 'router-lsa' in max_metric:
                    router_lsa = max_metric['router-lsa']
                    ospf_config.max_metric_administrative = 'administrative' in router_lsa
                    if 'on-shutdown' in router_lsa:
                        ospf_config.max_metric_on_shutdown = int(router_lsa['on-shutdown'])
                    if 'on-startup' in router_lsa:
                        ospf_config.max_metric_on_startup = int(router_lsa['on-startup'])
                else:
                    ospf_config.max_metric_administrative = 'administrative' in max_metric
                    if 'on-shutdown' in max_metric:
                        ospf_config.max_metric_on_shutdown = int(max_metric['on-shutdown'])
                    if 'on-startup' in max_metric:
                        ospf_config.max_metric_on_startup = int(max_metric['on-startup'])
            
            db.session.add(ospf_config)
            db.session.flush()
            
            if 'area' in data:
                for area_num, area_data in data['area'].items():
                    if not isinstance(area_data, dict):
                        continue
                    area = OSPFArea(
                        ospf_config_id=ospf_config.id,
                        area_number=str(area_num),
                        authentication=area_data.get('authentication')
                    )
                    
                    if 'area-type' in area_data:
                        area_type = area_data['area-type']
                        if not isinstance(area_type, dict):
                            area.area_type = str(area_type)
                        elif 'normal' in area_type:
                            area.area_type = 'normal'
                        elif 'nssa' in area_type:
                            area.area_type = 'nssa'
                            nssa = area_type['nssa']
                            if 'default-cost' in nssa:
                                area.area_type_default_cost = int(nssa['default-cost'])
                            area.area_type_no_summary = 'no-summary' in nssa
                            area.area_type_translate = nssa.get('translate')
                        elif 'stub' in area_type:
                            area.area_type = 'stub'
                            stub = area_type['stub']
                            if 'default-cost' in stub:
                                area.area_type_default_cost = int(stub['default-cost'])
                            area.area_type_no_summary = 'no-summary' in stub
                    
                    db.session.add(area)
                    db.session.flush()
                    
                    if 'network' in area_data:
                        networks = area_data['network']
                        if not isinstance(networks, list):
                            networks = [networks]
                        for network in networks:
                            if network:
                                db.session.add(OSPFAreaNetwork(
                                    area_id=area.id,
                                    network=network
                                ))
                    
                    if 'range' in area_data:
                        for range_prefix, range_data in area_data['range'].items():
                            area_range = OSPFAreaRange(
                                area_id=area.id,
                                range_prefix=range_prefix,
                                cost=int(range_data['cost']) if 'cost' in range_data else None,
                                not_advertise='not-advertise' in range_data,
                                substitute=range_data.get('substitute')
                            )
                            db.session.add(area_range)
            
            if 'interface' in data:
                for intf_name, intf_data in data['interface'].items():
                    if not isinstance(intf_data, dict):
                        continue
                    interface = OSPFInterface(
                        ospf_config_id=ospf_config.id,
                        interface_name=intf_name,
                        area=str(intf_data['area']) if 'area' in intf_data else None,
                        bandwidth=int(intf_data['bandwidth']) if 'bandwidth' in intf_data else None,
                        cost=int(intf_data['cost']) if 'cost' in intf_data else None,
                        dead_interval=int(intf_data['dead-interval']) if 'dead-interval' in intf_data else None,
                        hello_interval=int(intf_data['hello-interval']) if 'hello-interval' in intf_data else None,
                        hello_multiplier=int(intf_data['hello-multiplier']) if 'hello-multiplier' in intf_data else None,
                        mtu_ignore='mtu-ignore' in intf_data,
                        network=intf_data.get('network'),
                        passive='passive' in intf_data,
                        passive_disable='passive' in intf_data and 'disable' in intf_data.get('passive', {}),
                        priority=int(intf_data['priority']) if 'priority' in intf_data else None,
                        retransmit_interval=int(intf_data['retransmit-interval']) if 'retransmit-interval' in intf_data else None,
                        retransmit_window=int(intf_data['retransmit-window']) if 'retransmit-window' in intf_data else None,
                        transmit_delay=int(intf_data['transmit-delay']) if 'transmit-delay' in intf_data else None,
                        auth_plaintext_password=intf_data.get('authentication', {}).get('plaintext-password')
                    )
                    
                    db.session.add(interface)
                    db.session.flush()
                    
                    if 'authentication' in intf_data and isinstance(intf_data['authentication'], dict) and 'md5' in intf_data['authentication']:
                        md5_data = intf_data['authentication']['md5']
                        if 'key-id' in md5_data:
                            for key_id, key_data in md5_data['key-id'].items():
                                if 'md5-key' in key_data:
                                    db.session.add(OSPFInterfaceAuthMD5Key(
                                        interface_id=interface.id,
                                        key_id=str(key_id),
                                        md5_key=key_data['md5-key']
                                    ))
            
            if 'redistribute' in data:
                redistribute_data = data['redistribute']
                if isinstance(redistribute_data, str):
                    redistribute_data = [redistribute_data]
                if isinstance(redistribute_data, list):
                    redistribute_data = {proto: {} for proto in redistribute_data}
                for protocol, protocol_data in redistribute_data.items():
                    redistribute = OSPFRedistribute(
                        ospf_config_id=ospf_config.id,
                        protocol=protocol,
                        metric=int(protocol_data['metric']) if isinstance(protocol_data, dict) and 'metric' in protocol_data else None,
                        metric_type=int(protocol_data['metric-type']) if isinstance(protocol_data, dict) and 'metric-type' in protocol_data else None,
                        route_map=None
                    )
                    db.session.add(redistribute)
            
            if 'neighbor' in data:
                for neighbor_ip, neighbor_data in data['neighbor'].items():
                    neighbor = OSPFNeighbor(
                        ospf_config_id=ospf_config.id,
                        neighbor_ip=neighbor_ip,
                        poll_interval=int(neighbor_data['poll-interval']) if isinstance(neighbor_data, dict) and 'poll-interval' in neighbor_data else None,
                        priority=int(neighbor_data['priority']) if isinstance(neighbor_data, dict) and 'priority' in neighbor_data else None
                    )
                    db.session.add(neighbor)
            
            if 'summary-address' in data:
                for summary_prefix, summary_data in data['summary-address'].items():
                    summary = OSPFSummaryAddress(
                        ospf_config_id=ospf_config.id,
                        summary_prefix=summary_prefix,
                        no_advertise='no-advertise' in summary_data if isinstance(summary_data, dict) else False
                    )
                    db.session.add(summary)
            
            db.session.commit()
            logger.info("OSPF configuration refreshed successfully")
            
        except Exception as e:
            logger.error(f"Error refreshing OSPF configuration: {e}")
            # db.session.rollback()
            raise


class OSPFArea(db.Model):
    __tablename__ = 'vyos_config_ospf_area'
    
    id = Column(Integer, primary_key=True)
    ospf_config_id = Column(Integer, ForeignKey('vyos_config_ospf.id'), nullable=False)
    area_number = Column(String(50), nullable=False)
    authentication = Column(String(50))
    area_type = Column(String(50))
    area_type_default_cost = Column(Integer)
    area_type_no_summary = Column(Boolean, default=False)
    area_type_translate = Column(String(50))
    
    ospf_config = relationship("OSPFConfig", back_populates="areas")
    networks = relationship("OSPFAreaNetwork", back_populates="area", cascade="all, delete-orphan")
    ranges = relationship("OSPFAreaRange", back_populates="area", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'area_number': self.area_number,
            'authentication': self.authentication,
            'area_type': self.area_type,
            'area_type_default_cost': self.area_type_default_cost,
            'area_type_no_summary': self.area_type_no_summary,
            'area_type_translate': self.area_type_translate,
            'networks': [n.network for n in self.networks],
            'ranges': [r.serialize() for r in self.ranges]
        }


class OSPFAreaNetwork(db.Model):
    __tablename__ = 'vyos_config_ospf_area_network'
    
    id = Column(Integer, primary_key=True)
    area_id = Column(Integer, ForeignKey('vyos_config_ospf_area.id'), nullable=False)
    network = Column(String(50), nullable=False)
    
    area = relationship("OSPFArea", back_populates="networks")


class OSPFAreaRange(db.Model):
    __tablename__ = 'vyos_config_ospf_area_range'
    
    id = Column(Integer, primary_key=True)
    area_id = Column(Integer, ForeignKey('vyos_config_ospf_area.id'), nullable=False)
    range_prefix = Column(String(50), nullable=False)
    cost = Column(Integer)
    not_advertise = Column(Boolean, default=False)
    substitute = Column(String(50))
    
    area = relationship("OSPFArea", back_populates="ranges")
    
    def serialize(self):
        return {
            'range_prefix': self.range_prefix,
            'cost': self.cost,
            'not_advertise': self.not_advertise,
            'substitute': self.substitute
        }


class OSPFInterface(db.Model):
    __tablename__ = 'vyos_config_ospf_interface'
    
    id = Column(Integer, primary_key=True)
    ospf_config_id = Column(Integer, ForeignKey('vyos_config_ospf.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    area = Column(String(50))
    bandwidth = Column(Integer)
    cost = Column(Integer)
    dead_interval = Column(Integer)
    hello_interval = Column(Integer)
    hello_multiplier = Column(Integer)
    mtu_ignore = Column(Boolean, default=False)
    network = Column(String(50))
    passive = Column(Boolean, default=False)
    passive_disable = Column(Boolean, default=False)
    priority = Column(Integer)
    retransmit_interval = Column(Integer)
    retransmit_window = Column(Integer)
    transmit_delay = Column(Integer)
    auth_plaintext_password = Column(String(255))
    
    ospf_config = relationship("OSPFConfig", back_populates="interfaces")
    auth_md5_keys = relationship("OSPFInterfaceAuthMD5Key", back_populates="interface", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name,
            'area': self.area,
            'bandwidth': self.bandwidth,
            'cost': self.cost,
            'dead_interval': self.dead_interval,
            'hello_interval': self.hello_interval,
            'hello_multiplier': self.hello_multiplier,
            'mtu_ignore': self.mtu_ignore,
            'network': self.network,
            'passive': self.passive,
            'passive_disable': self.passive_disable,
            'priority': self.priority,
            'retransmit_interval': self.retransmit_interval,
            'retransmit_window': self.retransmit_window,
            'transmit_delay': self.transmit_delay,
            'auth_plaintext_password': self.auth_plaintext_password,
            'md5_keys': [k.serialize() for k in self.auth_md5_keys]
        }


class OSPFInterfaceAuthMD5Key(db.Model):
    __tablename__ = 'vyos_config_ospf_interface_auth_md5_key'
    
    id = Column(Integer, primary_key=True)
    interface_id = Column(Integer, ForeignKey('vyos_config_ospf_interface.id'), nullable=False)
    key_id = Column(String(10), nullable=False)
    md5_key = Column(String(255), nullable=False)
    
    interface = relationship("OSPFInterface", back_populates="auth_md5_keys")
    
    def serialize(self):
        return {
            'key_id': self.key_id,
            'md5_key': self.md5_key
        }


class OSPFRedistribute(db.Model):
    __tablename__ = 'vyos_config_ospf_redistribute'
    
    id = Column(Integer, primary_key=True)
    ospf_config_id = Column(Integer, ForeignKey('vyos_config_ospf.id'), nullable=False)
    protocol = Column(String(50), nullable=False)
    metric = Column(Integer)
    metric_type = Column(Integer)
    route_map = Column(String(255))
    
    ospf_config = relationship("OSPFConfig", back_populates="redistributes")
    
    def serialize(self):
        return {
            'protocol': self.protocol,
            'metric': self.metric,
            'metric_type': self.metric_type
        }


class OSPFNeighbor(db.Model):
    __tablename__ = 'vyos_config_ospf_neighbor'
    
    id = Column(Integer, primary_key=True)
    ospf_config_id = Column(Integer, ForeignKey('vyos_config_ospf.id'), nullable=False)
    neighbor_ip = Column(String(50), nullable=False)
    poll_interval = Column(Integer)
    priority = Column(Integer)
    
    ospf_config = relationship("OSPFConfig", back_populates="neighbors")
    
    def serialize(self):
        return {
            'neighbor_ip': self.neighbor_ip,
            'poll_interval': self.poll_interval,
            'priority': self.priority
        }


class OSPFSummaryAddress(db.Model):
    __tablename__ = 'vyos_config_ospf_summary_address'
    
    id = Column(Integer, primary_key=True)
    ospf_config_id = Column(Integer, ForeignKey('vyos_config_ospf.id'), nullable=False)
    summary_prefix = Column(String(50), nullable=False)
    no_advertise = Column(Boolean, default=False)
    
    ospf_config = relationship("OSPFConfig", back_populates="summary_addresses")
    
    def serialize(self):
        return {
            'summary_prefix': self.summary_prefix,
            'no_advertise': self.no_advertise
        }


OSPF = OSPFConfig
