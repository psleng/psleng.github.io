from flask_apscheduler import APScheduler
from app.event.jobs.interface.fetch_interface import fetch_interface_opr
from app.event.jobs.system.performance import fetch_memory, fetch_storage
from app.event.jobs.system.system_info import fetch_info
from app.event.jobs.system.load_average import fetch_load_average
from app.core.network.dns.jobs.dns_server import fetch_dns_server_job
from app.core.security.jobs.firewall import (
    fetch_firewall_job,
    fetch_firewall_opr_job,
    fetch_firewall_opr_log_job,
)
from app.core.network.dns.jobs.dns import fetch_dns_job
from app.core.network.nat.jobs.nat import fetch_nat_job
from app.core.network.dhcp.jobs.dhcp_server import fetch_dhcp_job
from app.core.network.dhcp.jobs.dhcp_relay import fetch_dhcp_relay_job
from app.core.network.dhcp.jobs.dhcp_server import fetch_dhcpv6_job
from app.core.service.config import fetch_country_code
from app.event.jobs.system.config import (
    fetch_os_config,
    fetch_service_stat,
    fetch_init_service_stat,
    init_db_services,
    init_admin_selected_services,
)
from app.event.jobs.system.vyos_http_api import fetch_vyos_http_api_status
from app.event.jobs.system.software_update import check_software_update_available
from app.event.jobs.system.save_config import save_config_if_recent
from app.auth.cloud_auth import refresh_cloud_sessions
from app.event.jobs.system.config import refresh_db_service_stat
from app.config.models import Interval
from app.scheduler.models import Job
from logging import getLogger, DEBUG
from flask import current_app
import os
import logging
from logging.handlers import RotatingFileHandler

logger = getLogger(__name__)
logger.setLevel(DEBUG)


def _job_fetch_interface_opr(app):
    return fetch_interface_opr(app.app_context())


def _job_fetch_info(app):
    return fetch_info(app.app_context())


def _job_fetch_os_config(app):
    return fetch_os_config(app.app_context())


def _job_fetch_service_stat(app):
    return fetch_service_stat(app.app_context())


def _job_fetch_init_service_stat(app):
    return fetch_init_service_stat(app.app_context())


def _job_fetch_load_average(app):
    return fetch_load_average(app.app_context())


def _job_fetch_vyos_http_api_status(app):
    return fetch_vyos_http_api_status(app.app_context())


def _job_fetch_storage(app):
    return fetch_storage(app.app_context())


def _job_check_software_update_available(app):
    return check_software_update_available(app.app_context())


def _job_save_recent_config(app):
    logger.debug(f"[config-save] Scheduler wrapper invoked: pid={os.getpid()}")
    result = save_config_if_recent(app.app_context())
    logger.debug(f"[config-save] Scheduler wrapper completed: saved={result}")
    return result

def _job_refresh_db_service_stat(app):
    return refresh_db_service_stat(app.app_context())


def _job_refresh_cloud_sessions(app):
    with app.app_context():
        return refresh_cloud_sessions()


_JOB_WRAPPERS = {
    "fetch_interfaces_operation": _job_fetch_interface_opr,
    "fetch_system_info": _job_fetch_info,
    "fetch_os_config": _job_fetch_os_config,
    "fetch_service_stat": _job_fetch_service_stat,
    "fetch_load_average_history": _job_fetch_load_average,
    "check_vyos_http_api": _job_fetch_vyos_http_api_status,
    "fetch_storage": _job_fetch_storage,
    "fetch_init_service_stat": _job_fetch_init_service_stat,
    "refresh_cloud_sessions": _job_refresh_cloud_sessions,
    'check_software_update_available': _job_check_software_update_available,
    'save_recent_config': _job_save_recent_config,
    #'refresh_db_service_stat': _job_refresh_db_service_stat,
}


def _configure_scheduler_file_logging() -> None:
    log_dir = "/var/log/flask-react-web"
    log_path = os.path.join(log_dir, "fetch_load_average.log")
    handler_key = "_apscheduler_shared_file_handler"

    if getattr(logger, handler_key, None) is not None:
        return

    try:
        os.makedirs(log_dir, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
        )
        file_handler.setLevel(DEBUG)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        )
        logger.addHandler(file_handler)
        setattr(logger, handler_key, file_handler)
        logger.propagate = True
    except Exception:
        logger.exception(f"APScheduler file logging could not be enabled at {log_path}")


def try_acquire_scheduler_lock(
    lock_path: str = "/tmp/flask_react_apscheduler.lock",
) -> bool:
    return True


from apscheduler.events import (
    EVENT_JOB_EXECUTED,
    EVENT_JOB_ERROR,
    EVENT_JOB_ADDED,
    EVENT_JOB_MAX_INSTANCES,
)

from app.scheduler.utils import run_once
from app.config.scheduler_constants import JOB_CONFIGS

SCHEDULED_JOB_CONFIGS = [
    {
        "id": "fetch_interfaces_operation",
        "func": fetch_interface_opr,
        "interval": JOB_CONFIGS["fetch_interfaces_operation"],
        "max_instances": 1,
        "misfire_grace_time": 120,
        "coalesce": True,
    },
    {
        "id": "fetch_system_info",
        "func": fetch_info,
        "interval": JOB_CONFIGS["fetch_system_info"],
        "max_instances": 1,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
    {
        "id": "fetch_os_config",
        "func": fetch_os_config,
        "interval": JOB_CONFIGS["fetch_os_config"],
        "max_instances": 1,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
    {
        "id": "fetch_service_stat",
        "func": fetch_service_stat,
        "interval": JOB_CONFIGS["fetch_service_stat"],
        "max_instances": 1,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
    {
        "id": "fetch_load_average_history",
        "func": fetch_load_average,
        "interval": JOB_CONFIGS["fetch_load_average_history"],
        "max_instances": 2,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
    {
        "id": "check_vyos_http_api",
        "func": fetch_vyos_http_api_status,
        "interval": JOB_CONFIGS["check_vyos_http_api"],
        "max_instances": 1,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
    {
        'id': 'check_software_update_available',
        'func': check_software_update_available,
        'interval': JOB_CONFIGS['check_software_update_available'],
        'max_instances': 1,
        'misfire_grace_time': 30,
        'coalesce': True,
    },
    {
        'id': 'save_recent_config',
        'func': save_config_if_recent,
        'interval': JOB_CONFIGS['save_recent_config'],
        'max_instances': 1,
        'misfire_grace_time': 30,
        'coalesce': True,
    },
    {
        "id": "fetch_storage",
        "func": fetch_storage,
        "interval": JOB_CONFIGS["fetch_storage"],
        "max_instances": 1,
        "misfire_grace_time": 120,
        "coalesce": True,
    },
    {
        "id": "refresh_cloud_sessions",
        "func": refresh_cloud_sessions,
        "interval": JOB_CONFIGS["refresh_cloud_sessions"],
        "max_instances": 1,
        "misfire_grace_time": 30,
        "coalesce": True,
    },
]

SCHEDULED_JOB_IDS = [job["id"] for job in SCHEDULED_JOB_CONFIGS]


def _build_executors_config() -> dict:
    return {
        "apscheduler.executors.main": {
            "class": "apscheduler.executors.pool:ThreadPoolExecutor",
            "max_workers": 1,
        },
        "apscheduler.executors.fetch_system_health": {
            "class": "apscheduler.executors.pool:ThreadPoolExecutor",
            "max_workers": 1,
        },
        "apscheduler.executors.cloud_auth": {
            "class": "apscheduler.executors.pool:ThreadPoolExecutor",
            "max_workers": 1,
        },
        'apscheduler.executors.config_save': {
            'class': 'apscheduler.executors.pool:ThreadPoolExecutor',
            'max_workers': 1
        },
    }


def init_scheduler(app):

    scheduler = APScheduler()
    scheduler.api_enabled = True
    scheduler.init_app(app)

    scheduler_config = _build_executors_config()

    scheduler_config.update(
        {
            "apscheduler.job_defaults.coalesce": True,  # Combine missed executions into a single one
            "apscheduler.job_defaults.max_instances": 1,  # Only allow one instance of each job
            "apscheduler.job_defaults.misfire_grace_time": 15,  # Skip catch-up runs older than the time specified
            "apscheduler.job_defaults.executor": "main",
        }
    )
    scheduler.scheduler.configure(scheduler_config)

    scheduler.scheduler.add_listener(job_executed_event, EVENT_JOB_EXECUTED)
    scheduler.scheduler.add_listener(job_error_event, EVENT_JOB_ERROR)
    scheduler.scheduler.add_listener(job_added_event, EVENT_JOB_ADDED)
    scheduler.scheduler.add_listener(job_max_instances_event, EVENT_JOB_MAX_INSTANCES)

    return scheduler


def job_executed_event(event):
    """Log when a job is successfully executed"""
    logger.debug(f"Job {event.job_id} executed successfully")


def job_error_event(event):
    """Log when a job execution fails"""
    logger.error(f"Job {event.job_id} failed with exception: {event.exception}")


def job_added_event(event):
    """Log when a new job is added to the scheduler"""
    logger.debug(f"Job {event.job_id} was added to the scheduler")


def job_max_instances_event(event):
    """Log when a job execution is skipped due to max_instances"""
    logger.warning(f"Job {event.job_id} skipped due to max_instances pid={os.getpid()}")


def schedule_jobs(scheduler_instance, app):
    """
    Decorator-based job scheduling with sequential execution
    """
    try:
        logger.debug("Scheduling jobs...")

        # Add jobs with per-job executor configuration
        for job in SCHEDULED_JOB_CONFIGS:
            if scheduler_instance.get_job(id=job["id"]) is None:
                executor = "main"
                if job["id"] == "fetch_load_average_history":
                    executor = "fetch_system_health"
                elif job["id"] == "check_vyos_http_api":
                    executor = "fetch_system_health"
                elif job["id"] == "fetch_storage":
                    executor = "fetch_system_health"
                elif job['id'] == 'save_recent_config':
                    executor = 'config_save'
                elif job["id"] == "refresh_cloud_sessions":
                    executor = "cloud_auth"

                job_func = _JOB_WRAPPERS.get(job["id"], job["func"])
                job_args = job.get("args")
                if job_args is None:
                    job_args = [app]

                scheduler_instance.add_job(
                    id=job["id"],
                    func=job_func,
                    args=job_args,
                    trigger="interval",
                    seconds=job["interval"],
                    executor=executor,
                    misfire_grace_time=job.get(
                        "misfire_grace_time", None
                    ),  # None = APScheduler default behavior
                    coalesce=job.get("coalesce", True),
                    max_instances=job.get("max_instances", 1),
                )

        return True
    except Exception as e:
        logger.error(f"Error scheduling jobs: {e}")
        return False


def init_jobs(app):
    try:
        logger.debug("Initializing jobs...")

        _job_fetch_info(app)
        _job_fetch_interface_opr(app)
        _job_fetch_storage(app)
        fetch_memory(app.app_context())
        _job_fetch_os_config(app)
        fetch_country_code(app.app_context())
        _job_fetch_init_service_stat(app)
        with app.app_context():
            init_db_services()
            init_admin_selected_services()
        _job_fetch_service_stat(app)

        return True
    except Exception as e:
        logger.error(f"Error initializing jobs: {e}")
        return False
