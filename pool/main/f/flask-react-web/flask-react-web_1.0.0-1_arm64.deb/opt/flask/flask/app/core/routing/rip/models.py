from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import relationship
from app.log.logger import logger
import json

from pydantic import BaseModel
from typing import Optional, List


class RIPInterfaceDTO(BaseModel):
    id: Optional[str] = None
    name: str
    authPlaintextPassword: Optional[str] = ""
    receiveVersion: Optional[str] = ""
    sendVersion: Optional[str] = ""
    splitHorizon: str = "enabled"  # enabled, disabled, poison-reverse


class RIPNetworkDistanceDTO(BaseModel):
    id: Optional[str] = None
    network: str
    distance: Optional[str] = ""


class RIPRedistributionProtocolDTO(BaseModel):
    enabled: bool = False
    metric: Optional[str] = ""


class RIPRedistributionDTO(BaseModel):
    connected: RIPRedistributionProtocolDTO = RIPRedistributionProtocolDTO()
    kernel: RIPRedistributionProtocolDTO = RIPRedistributionProtocolDTO()
    ospf: RIPRedistributionProtocolDTO = RIPRedistributionProtocolDTO()
    static: RIPRedistributionProtocolDTO = RIPRedistributionProtocolDTO()


class RIPAdvancedConfigDTO(BaseModel):
    defaultDistance: Optional[str] = ""
    defaultInformationOriginate: bool = False
    defaultMetric: Optional[str] = ""
    version: Optional[str] = ""
    timersGarbageCollection: Optional[str] = ""
    timersTimeout: Optional[str] = ""
    timersUpdate: Optional[str] = ""
    neighbors: List[str] = []
    routes: List[str] = []


class UpdateRIPDTO(BaseModel):
    neighbors: List[str] = []
    networks: List[str] = []
    networkDistances: List[RIPNetworkDistanceDTO] = []
    passiveInterfaces: List[str] = []
    routes: List[str] = []
    interfaces: List[RIPInterfaceDTO] = []
    redistribution: RIPRedistributionDTO = RIPRedistributionDTO()
    advanced: RIPAdvancedConfigDTO = RIPAdvancedConfigDTO()


class VerifyRIPDTO(BaseModel):
    verify_type: str
    interfaces: Optional[List[RIPInterfaceDTO]] = []


class RIPConfig(db.Model):
    __tablename__ = 'vyos_config_rip'
    
    id = Column(Integer, primary_key=True)
    default_distance = Column(Integer, nullable=True)
    default_information_originate = Column(Boolean, default=False)
    default_metric = Column(Integer, nullable=True)
    version = Column(Integer, nullable=True)
    
    timers_garbage_collection = Column(Integer, nullable=True)
    timers_timeout = Column(Integer, nullable=True)
    timers_update = Column(Integer, nullable=True)
    
    neighbors = relationship("RIPNeighbor", back_populates="rip_config", cascade="all, delete-orphan")
    networks = relationship("RIPNetwork", back_populates="rip_config", cascade="all, delete-orphan")
    network_distances = relationship("RIPNetworkDistance", back_populates="rip_config", cascade="all, delete-orphan")
    passive_interfaces = relationship("RIPPassiveInterface", back_populates="rip_config", cascade="all, delete-orphan")
    routes = relationship("RIPRoute", back_populates="rip_config", cascade="all, delete-orphan")
    interfaces = relationship("RIPInterface", back_populates="rip_config", cascade="all, delete-orphan")
    redistributes = relationship("RIPRedistribute", back_populates="rip_config", cascade="all, delete-orphan")
    
    def serialize(self):
        return {
            'id': self.id,
            'default_distance': self.default_distance,
            'default_information_originate': self.default_information_originate,
            'default_metric': self.default_metric,
            'version': self.version,
            'neighbors': [n.serialize() for n in self.neighbors],
            'networks': [n.serialize() for n in self.networks],
            'network_distances': [nd.serialize() for nd in self.network_distances],
            'passive_interfaces': [pi.serialize() for pi in self.passive_interfaces],
            'routes': [r.serialize() for r in self.routes],
            'timers_garbage_collection': self.timers_garbage_collection,
            'timers_timeout': self.timers_timeout,
            'timers_update': self.timers_update,
            'interfaces': [intf.serialize() for intf in self.interfaces],
            'redistributes': [r.serialize() for r in self.redistributes]
        }
    
    @classmethod
    def truncate(cls):
        from sqlalchemy import text
        
        tables_to_clear = [
            'vyos_config_rip_neighbor',
            'vyos_config_rip_network',
            'vyos_config_rip_network_distance',
            'vyos_config_rip_passive_interface',
            'vyos_config_rip_route',
            'vyos_config_rip_interface',
            'vyos_config_rip_redistribute',
            'vyos_config_rip'
        ]
        
        for table in tables_to_clear:
            db.session.execute(text(f"DELETE FROM {table}"))
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh RIP configuration from VyOS data"""
        try:
            cls.truncate()
            
            rip_config = cls()
            
            if 'default-distance' in data:
                rip_config.default_distance = int(data['default-distance'])
            
            rip_config.default_information_originate = 'default-information' in data and 'originate' in data.get('default-information', {})
            
            if 'default-metric' in data:
                rip_config.default_metric = int(data['default-metric'])
            
            if 'version' in data:
                rip_config.version = int(data['version'])
            
            if 'timers' in data:
                timers = data['timers']
                if 'garbage-collection' in timers:
                    rip_config.timers_garbage_collection = int(timers['garbage-collection'])
                if 'timeout' in timers:
                    rip_config.timers_timeout = int(timers['timeout'])
                if 'update' in timers:
                    rip_config.timers_update = int(timers['update'])
            
            db.session.add(rip_config)
            db.session.flush()
            
            if 'neighbor' in data:
                if isinstance(data['neighbor'], list):
                    neighbor_list = data['neighbor']
                elif isinstance(data['neighbor'], str):
                    neighbor_list = [data['neighbor']]
                elif isinstance(data['neighbor'], dict):
                    neighbor_list = list(data['neighbor'].keys())
                for neighbor_ip in neighbor_list:
                    db.session.add(RIPNeighbor(
                        rip_config_id=rip_config.id,
                        neighbor_ip=neighbor_ip
                    ))

            if 'network' in data:
                if isinstance(data['network'], list):
                    network_list = data['network']
                elif isinstance(data['network'], str):
                    network_list = [data['network']]
                elif isinstance(data['network'], dict):
                    network_list = list(data['network'].keys())
                for network in network_list:
                    db.session.add(RIPNetwork(
                        rip_config_id=rip_config.id,
                        network=network
                    ))
            
            if 'network-distance' in data:
                if isinstance(data['network-distance'], list):
                    network_list = data['network-distance']
                elif isinstance(data['network-distance'], str):
                    network_list = [data['network-distance']]
                elif isinstance(data['network-distance'], dict):
                    network_list = list(data['network-distance'].keys())
                for network in network_list:
                    db.session.add(RIPNetworkDistance(
                        rip_config_id=rip_config.id,
                        network=network
                    ))
            
            if 'passive-interface' in data:
                if isinstance(data['passive-interface'], list):
                    passive_list = data['passive-interface']
                elif isinstance(data['passive-interface'], str):
                    passive_list = [data['passive-interface']]
                elif isinstance(data['passive-interface'], dict):
                    passive_list = list(data['passive-interface'].keys())
                for intf_name in passive_list:
                    db.session.add(RIPPassiveInterface(
                        rip_config_id=rip_config.id,
                        interface_name=intf_name
                    ))
            
            if 'route' in data:
                if isinstance(data['route'], list):
                    route_list = data['route']
                elif isinstance(data['route'], str):
                    route_list = [data['route']]
                elif isinstance(data['route'], dict):
                    route_list = list(data['route'].keys())
                for route in route_list:
                    db.session.add(RIPRoute(
                        rip_config_id=rip_config.id,
                        route=route
                    ))
            
            if 'interface' in data:
                for intf_name, intf_data in data['interface'].items():
                    interface = RIPInterface(
                        rip_config_id=rip_config.id,
                        interface_name=intf_name,
                        auth_plaintext_password=intf_data.get('authentication', {}).get('plaintext-password'),
                        receive_version=int(intf_data['receive']['version']) if 'receive' in intf_data and 'version' in intf_data['receive'] else None,
                        send_version=int(intf_data['send']['version']) if 'send' in intf_data and 'version' in intf_data['send'] else None,
                        split_horizon_enabled='split-horizon' in intf_data and (intf_data['split-horizon'] == {} or intf_data['split-horizon'] is True),
                        split_horizon_disable='split-horizon' in intf_data and isinstance(intf_data['split-horizon'], dict) and 'disable' in intf_data['split-horizon'],
                        split_horizon_poison_reverse='split-horizon' in intf_data and isinstance(intf_data['split-horizon'], dict) and 'poison-reverse' in intf_data['split-horizon']
                    )
                    db.session.add(interface)
            
            if 'redistribute' in data:
                for protocol, protocol_data in data['redistribute'].items():
                    redistribute = RIPRedistribute(
                        rip_config_id=rip_config.id,
                        protocol=protocol,
                        metric=int(protocol_data['metric']) if isinstance(protocol_data, dict) and 'metric' in protocol_data else None
                    )
                    db.session.add(redistribute)
            
            db.session.commit()
            logger.info("RIP configuration refreshed successfully")
            
        except Exception as e:
            logger.error(f"Error refreshing RIP configuration: {e}")


class RIPInterface(db.Model):
    __tablename__ = 'vyos_config_rip_interface'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    auth_plaintext_password = Column(String(255))
    receive_version = Column(Integer)
    send_version = Column(Integer)
    split_horizon_enabled = Column(Boolean, default=False)
    split_horizon_disable = Column(Boolean, default=False)
    split_horizon_poison_reverse = Column(Boolean, default=False)
    
    rip_config = relationship("RIPConfig", back_populates="interfaces")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name,
            'auth_plaintext_password': self.auth_plaintext_password,
            'receive_version': self.receive_version,
            'send_version': self.send_version,
            'split_horizon_enabled': self.split_horizon_enabled,
            'split_horizon_disable': self.split_horizon_disable,
            'split_horizon_poison_reverse': self.split_horizon_poison_reverse
        }


class RIPNetwork(db.Model):
    __tablename__ = 'vyos_config_rip_network'

    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    network = Column(String(100), nullable=False)

    rip_config = relationship("RIPConfig", back_populates="networks")

    def serialize(self):
        return {
            'network': self.network
        }


class RIPNeighbor(db.Model):
    __tablename__ = 'vyos_config_rip_neighbor'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    neighbor_ip = Column(String(50), nullable=False)
    
    rip_config = relationship("RIPConfig", back_populates="neighbors")
    
    def serialize(self):
        return {
            'neighbor_ip': self.neighbor_ip
        }


class RIPNetworkDistance(db.Model):
    __tablename__ = 'vyos_config_rip_network_distance'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    network = Column(String(50), nullable=False)
    
    rip_config = relationship("RIPConfig", back_populates="network_distances")
    
    def serialize(self):
        return {
            'network': self.network
        }


class RIPPassiveInterface(db.Model):
    __tablename__ = 'vyos_config_rip_passive_interface'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    interface_name = Column(String(50), nullable=False)
    
    rip_config = relationship("RIPConfig", back_populates="passive_interfaces")
    
    def serialize(self):
        return {
            'interface_name': self.interface_name
        }


class RIPRoute(db.Model):
    __tablename__ = 'vyos_config_rip_route'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    route = Column(String(50), nullable=False)
    
    rip_config = relationship("RIPConfig", back_populates="routes")
    
    def serialize(self):
        return {
            'route': self.route
        }


class RIPRedistribute(db.Model):
    __tablename__ = 'vyos_config_rip_redistribute'
    
    id = Column(Integer, primary_key=True)
    rip_config_id = Column(Integer, ForeignKey('vyos_config_rip.id'), nullable=False)
    protocol = Column(String(50), nullable=False)
    metric = Column(Integer)
    
    rip_config = relationship("RIPConfig", back_populates="redistributes")
    
    def serialize(self):
        return {
            'protocol': self.protocol,
            'metric': self.metric
        }


RIP = RIPConfig