#!/usr/bin/env python3
#
from datetime import datetime, timezone
from os import environ
from sys import exit

import hmac
import hashlib
import time
import requests
import os
import json
from uuid import uuid4
from contextlib import contextmanager
import fcntl

SECRET = os.environ.get("CALLBACK_SECRET", "secret").encode()
CALLBACK_URL = "http://127.0.0.1:5000/callback"
DEBUG_LOG_PATH = "/var/log/flask-react-web/gui_event_notification.log"
OUTBOX_PATH = "/var/lib/flask-react-web/gui_event_notification_outbox.jsonl"
OUTBOX_LOCK_PATH = "/var/lib/flask-react-web/gui_event_notification_outbox.lock"
MAX_SEND_ATTEMPTS = 3


def write_debug_log(message: str) -> None:
    os.makedirs(os.path.dirname(DEBUG_LOG_PATH), exist_ok=True)
    with open(DEBUG_LOG_PATH, 'a', encoding='utf-8') as log_file:
        log_file.write(f"{datetime.now().isoformat()} {message}\n")


def make_signed_request(payload: dict):
    timestamp = str(int(time.time()))
    message = timestamp.encode()
    
    signature = hmac.new(SECRET, message, hashlib.sha256).hexdigest()
    write_debug_log(f"Sending callback payload: {payload}")
    
    response = requests.post(
        CALLBACK_URL,
        json=payload,
        headers={
            "X-Timestamp": timestamp,
            "X-Signature": signature,
            "Content-Type": "application/json"
        },
        timeout=(3, 5),
    )
    write_debug_log(f"Callback response status={response.status_code} body={response.text}")
    response.raise_for_status()
    return response


def send_with_retry(payload: dict) -> bool:
    for attempt in range(1, MAX_SEND_ATTEMPTS + 1):
        try:
            make_signed_request(payload)
            return True
        except requests.RequestException as err:
            write_debug_log(f"Callback attempt {attempt} failed: {err}")
            if attempt < MAX_SEND_ATTEMPTS:
                time.sleep(2 ** (attempt - 1))
    return False


def read_outbox() -> list[dict]:
    if not os.path.exists(OUTBOX_PATH):
        return []
    pending = []
    with open(OUTBOX_PATH, 'r', encoding='utf-8') as outbox_file:
        for line in outbox_file:
            try:
                value = json.loads(line)
                if isinstance(value, dict):
                    pending.append(value)
            except json.JSONDecodeError:
                write_debug_log('Skipping malformed callback outbox entry')
    return pending


def write_outbox(payloads: list[dict]) -> None:
    os.makedirs(os.path.dirname(OUTBOX_PATH), exist_ok=True)
    temporary_path = f"{OUTBOX_PATH}.tmp"
    with open(temporary_path, 'w', encoding='utf-8') as outbox_file:
        for payload in payloads:
            outbox_file.write(json.dumps(payload, ensure_ascii=False) + '\n')
    os.replace(temporary_path, OUTBOX_PATH)


@contextmanager
def outbox_lock():
    os.makedirs(os.path.dirname(OUTBOX_LOCK_PATH), exist_ok=True)
    with open(OUTBOX_LOCK_PATH, 'a', encoding='utf-8') as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def flush_outbox() -> None:
    pending = read_outbox()
    if not pending:
        return

    remaining = []
    delivery_failed = False
    for payload in pending:
        if delivery_failed or not send_with_retry(payload):
            delivery_failed = True
            remaining.append(payload)
    write_outbox(remaining)
    write_debug_log(f"Callback outbox replay complete remaining={len(remaining)}")

def process_event() -> None:
    # Get variables
    message_text = environ.get('message')
    event_name = environ.get('event_name')
    gui_level = environ.get('gui_level')
    email_enabled = str(environ.get('email_enabled') or '').strip().lower() in ('1', 'true', 'yes', 'on')
    write_debug_log(f"Processing event with message={message_text}")
    print(f'Logged message: {message_text}')

    payload = {
        "source_event_id": str(uuid4()),
        "occurred_at": datetime.now(timezone.utc).isoformat(),
        "event": "notify_users",
        "event_name": event_name,
        "message": message_text,
        "gui_level": gui_level,
        "email_enabled": email_enabled,
    }

    with outbox_lock():
        flush_outbox()
        if not send_with_retry(payload):
            pending = read_outbox()
            pending.append(payload)
            write_outbox(pending)
            raise RuntimeError('Callback delivery failed; event saved to local outbox')


if __name__ == '__main__':
    try:
        process_event()
        write_debug_log('Script completed successfully')
        exit(0)
    except Exception as err:
        write_debug_log(f'Error running script: {err}')
        print(f'Error running script: {err}')
        exit(1)
