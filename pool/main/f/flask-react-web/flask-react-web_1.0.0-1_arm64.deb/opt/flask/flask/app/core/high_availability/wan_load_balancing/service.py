import pprint
from uuid import uuid4

from flask import session

from app.core.api.http.cmd.command import SHOW_WAN_LOAD_BALANCING
from app.core.api.http.http_request import Action
from app.core.high_availability.wan_load_balancing.command_wan_load_balancing import WanLoadBalancingCommand
from app.core.high_availability.wan_load_balancing.models import WanLoadBalancingConfig
from app.core.high_availability.wan_load_balancing.parsers import parse_to_vyos_config
from app.core.utils.process_config import merge_dicts_delete, merge_dicts_set, process_commands
from app.log.logger import logger
from app.socket.socket_manager import socket_manager
import pprint

VERIFY_SERVICE = "load-balancing_wan"


def _processed_wan_config(config):
    return (
        config.get("load_balancing", {}).get("wan")
        or config.get("load-balancing", {}).get("wan")
        or {}
    )


def update_wan_load_balancing(provider, data):
    print("Update WAN load balancing:")
    print(data)
    username = session.get("username")
    config = data.get("new") or {}
    current_config = data.get("current") or {}
    diff = data.get("diff") or {"created": {}, "deleted": {}}

    set_command = WanLoadBalancingCommand(operator="set")
    set_cmds = set_command.generate_commands(data=diff.get("created"), current_config=current_config, new_config=config)
    set_config = process_commands(set_command.get_commands())

    delete_command = WanLoadBalancingCommand(operator="delete")
    delete_cmds = delete_command.generate_commands(data=diff.get("deleted"), current_config=current_config, new_config=config)
    delete_config = process_commands(delete_command.get_commands())

    current_raw_config = provider.verify_service.call_get_config(VERIFY_SERVICE) or {}
    merged_del_config = merge_dicts_delete(
        current_raw_config,
        _processed_wan_config(delete_config),
        clean_empty=False,
        aggressive=True,
    )
    merged_config = merge_dicts_set(
        merged_del_config,
        _processed_wan_config(set_config),
    )

    print("WAN load balancing merged config:")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = provider.verify_service.call_verify(VERIFY_SERVICE, merged_config) if merged_config else None
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]

    WanLoadBalancingConfig.refresh(merged_config)

    if username:
        socket_manager.emit_to_user(
            username,
            event="notification",
            data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update WAN Load Balancing",
                "content": "WAN load balancing is successfully updated",
            },
        )

    result = []
    if cmds:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        result.append({"cmd": cmds, "success": res.get("success"), "error": res.get("error")})
    return result


def verify_wan_load_balancing(provider, data):
    new_config = parse_to_vyos_config(data or {})

    print("New config:")
    print(pprint.pformat(new_config, indent=4))

    set_command = WanLoadBalancingCommand(operator="set")
    set_command.generate_commands(data=new_config, current_config={}, new_config=new_config)
    processed_config = process_commands(set_command.get_commands())
    
    verify_config = _processed_wan_config(processed_config)
    
    print("Verify config:")
    print(pprint.pformat(verify_config, indent=4))

    verify = provider.verify_service.call_verify(VERIFY_SERVICE, verify_config)

    print("Verify:")
    print(verify)

    return verify


def _extract_graphql_result(response, field_name, default):
    payload = response.json()
    envelope = (payload.get("data") or {}).get(field_name) or {}
    if envelope.get("errors"):
        raise Exception(envelope.get("errors"))
    data = envelope.get("data") or {}
    return data.get("result", default)


def monitor_wan_load_balancing(provider, data=None):
    target = (data or {}).get("target")
    if target == "summary":
        response = provider.graphql_service.send_request(
            function_name="ShowSummaryLoadBalancingWan",
            data=None,
            verify=False,
        )
        return _extract_graphql_result(response, "ShowSummaryLoadBalancingWan", {})
    if target == "connections":
        response = provider.graphql_service.send_request(
            function_name="ShowConnectionLoadBalancingWan",
            data=None,
            verify=False,
        )
        return _extract_graphql_result(response, "ShowConnectionLoadBalancingWan", [])
    return [] if target == "connections" else {}


def fetch_wan_load_balancing(provider, data=None):
    response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_WAN_LOAD_BALANCING, verify=False)
    data = response.json().get("data")
    return data or {}
