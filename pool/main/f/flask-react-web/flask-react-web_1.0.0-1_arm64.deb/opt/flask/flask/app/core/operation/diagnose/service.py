import json

from app.core.operation.diagnose.models import PingDiagnosticDTO, TracerouteDiagnosticDTO


PING_FUNCTION = 'ShowPingPerleDiagnosticToolQuery'
TRACEROUTE_FUNCTION = 'ShowTraceroutePerleDiagnosticToolQuery'


class DiagnosticServiceError(RuntimeError):
    """Raised when the VyOS GraphQL diagnostic request cannot be completed."""


def _format_graphql_errors(errors) -> str:
    if not errors:
        return ''
    if isinstance(errors, list):
        messages = []
        for error in errors:
            if isinstance(error, dict) and error.get('message'):
                messages.append(str(error['message']))
            else:
                messages.append(str(error))
        return '; '.join(messages)
    return str(errors)


def _read_diagnostic_response(response, function_name: str) -> dict:
    try:
        response.raise_for_status()
    except Exception as exc:
        status_code = getattr(response, 'status_code', None)
        suffix = f' (HTTP {status_code})' if status_code else ''
        raise DiagnosticServiceError(f'Diagnostic GraphQL request failed{suffix}.') from exc

    try:
        payload = response.json()
    except Exception as exc:
        raise DiagnosticServiceError('Diagnostic GraphQL response was not valid JSON.') from exc

    graphql_error = _format_graphql_errors(payload.get('errors'))
    if graphql_error:
        raise DiagnosticServiceError(graphql_error)

    response_data = payload.get('data')
    operation = response_data.get(function_name) if isinstance(response_data, dict) else None
    if not isinstance(operation, dict):
        raise DiagnosticServiceError(f'Diagnostic GraphQL response did not include {function_name}.')

    operation_error = _format_graphql_errors(operation.get('errors'))
    if operation.get('success') is False or operation_error:
        raise DiagnosticServiceError(operation_error or 'Diagnostic command failed.')

    return operation


def run_ping_diagnostic(provider, diagnostic: PingDiagnosticDTO) -> dict:
    arguments = ', '.join([
        f'ping_type: {json.dumps(diagnostic.ping_type)}',
        f'number_of_ping: {diagnostic.number_of_ping}',
        f'target: {json.dumps(str(diagnostic.target))}',
    ])
    response = provider.graphql_service.send_request(
        function_name=PING_FUNCTION,
        data=arguments,
        verify=False,
    )
    return _read_diagnostic_response(response, PING_FUNCTION)


def run_traceroute_diagnostic(provider, diagnostic: TracerouteDiagnosticDTO) -> dict:
    arguments = ', '.join([
        f'traceroute_type: {json.dumps(diagnostic.traceroute_type)}',
        f'target: {json.dumps(str(diagnostic.target))}',
    ])
    response = provider.graphql_service.send_request(
        function_name=TRACEROUTE_FUNCTION,
        data=arguments,
        verify=False,
    )
    return _read_diagnostic_response(response, TRACEROUTE_FUNCTION)
