from app.core.api.http.cmd.command import Command
from copy import deepcopy

def is_str_not_empty(value):
    return str(value).strip() not in ['', 'None']

class RIPngCommand(Command):
    """Command class for RIPng commands
    
    - set/delete protocols ripng aggregate-address <h:h:h:h:h:h:h:h/x>
    - set/delete protocols ripng default-information originate
    - set/delete protocols ripng default-metric <1-16>
    - set/delete protocols ripng network <h:h:h:h:h:h:h:h/x>
    - set/delete protocols ripng passive-interface <intf-name>
    - set/delete protocols ripng route <h:h:h:h:h:h:h:h/x>
    - set/delete protocols ripng route-map <route-map-name>
    - set/delete protocols ripng interface <intf-name>
    - set/delete protocols ripng interface <intf-name> split-horizon disable
    - set/delete protocols ripng interface <intf-name> split-horizon poison-reverse
    - set/delete protocols ripng redistribute {connected | kernel | ospfv3 | static}
    - set/delete protocols ripng redistribute {connected | kernel | ospfv3 | static} metric <1-16>
    - set/delete protocols ripng timers
    - set/delete protocols ripng timers garbage-collection <5-2147483647>
    - set/delete protocols ripng timers timeout <5-2147483647>
    - set/delete protocols ripng timers update <5-2147483647>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'ripng'))
            self.attributes = {
                'protocols': {
                    'ripng': {}
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing RIPng cmd: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            
            self.attributes['protocols']['ripng'] = data
            
            self._process_global_parameters(data)
            
            if 'timers' in data:
                self._process_timers_config(data['timers'])
            
            if 'aggregate-address' in data:
                self._process_aggregate_address_config(data['aggregate-address'], current_config, new_config)
            
            if 'network' in data:
                self._process_network_config(data['network'], current_config, new_config)
            
            if 'passive-interface' in data:
                self._process_passive_interface_config(data['passive-interface'], current_config, new_config)
            
            if 'route' in data:
                self._process_route_config(data['route'], current_config, new_config)
            
            if 'interface' in data:
                self._process_interface_config(data['interface'], current_config, new_config)
            
            if 'redistribute' in data:
                self._process_redistribute_config(data['redistribute'], current_config, new_config)
            
            print(f"Generated RIPng commands: {self.cmds}")
            return self.cmds
        except Exception as e:
            print(f"Error generating RIPng commands: {e}")
            return []
    
    def _process_global_parameters(self, data):
        base_path = ['protocols', 'ripng']
        
        if 'default-information' in data:
            if 'originate' in data['default-information']:
                self.generate(*base_path, 'default-information', 'originate')
        
        if 'default-metric' in data and is_str_not_empty(data['default-metric']):
            self.generate(*base_path, 'default-metric', str(data['default-metric']))
        
        if 'route-map' in data and is_str_not_empty(data['route-map']):
            self.generate(*base_path, 'route-map', data['route-map'])
    
    def _process_timers_config(self, timers_config):
        base_path = ['protocols', 'ripng', 'timers']
        
        if not timers_config or timers_config == {}:
            if self.operator == 'delete':
                self.generate(*base_path)
            return
        
        if 'garbage-collection' in timers_config and is_str_not_empty(timers_config['garbage-collection']):
            self.generate(*base_path, 'garbage-collection', str(timers_config['garbage-collection']))
        
        if 'timeout' in timers_config and is_str_not_empty(timers_config['timeout']):
            self.generate(*base_path, 'timeout', str(timers_config['timeout']))
        
        if 'update' in timers_config and is_str_not_empty(timers_config['update']):
            self.generate(*base_path, 'update', str(timers_config['update']))
    
    def _process_aggregate_address_config(self, aggregate_config, current_config, new_config):
        base_path = ['protocols', 'ripng', 'aggregate-address']
        
        if isinstance(aggregate_config, list):
            for item in aggregate_config:
                if isinstance(item, dict):
                    for address in item.keys():
                        if is_str_not_empty(address):
                            if self.operator == 'delete' and address not in (new_config or {}).get('aggregate-address', {}):
                                self.generate(*base_path, address)
                                continue
                            self.generate(*base_path, address)
                elif is_str_not_empty(item):
                    if self.operator == 'delete' and item not in (new_config or {}).get('aggregate-address', {}):
                        self.generate(*base_path, item)
                        continue
                    self.generate(*base_path, item)
        elif isinstance(aggregate_config, dict):
            for address in aggregate_config.keys():
                if is_str_not_empty(address):
                    if self.operator == 'delete' and address not in (new_config or {}).get('aggregate-address', {}):
                        self.generate(*base_path, address)
                        continue
                    self.generate(*base_path, address)
        elif is_str_not_empty(aggregate_config):
            address = aggregate_config
            if self.operator == 'delete' and address not in (new_config or {}).get('aggregate-address', {}):
                self.generate(*base_path, address)
                return
            self.generate(*base_path, address)
    
    def _process_network_config(self, network_config, current_config, new_config):
        base_path = ['protocols', 'ripng', 'network']

        if isinstance(network_config, str):
            if is_str_not_empty(network_config):
                self.generate(*base_path, network_config)
            return
        
        if isinstance(network_config, list):
            for item in network_config:
                if isinstance(item, dict):
                    for network in item.keys():
                        if is_str_not_empty(network):
                            if self.operator == 'delete' and network not in new_config.get('network', {}):
                                self.generate(*base_path, network)
                                continue
                            self.generate(*base_path, network)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(network_config, dict):
            for network in network_config.keys():
                if is_str_not_empty(network):
                    if self.operator == 'delete' and network not in new_config.get('network', {}):
                        self.generate(*base_path, network)
                        continue
                    self.generate(*base_path, network)
    
    def _process_passive_interface_config(self, passive_config, current_config, new_config):
        base_path = ['protocols', 'ripng', 'passive-interface']
        # Defensive alias: avoid NameError if this function gets refactored and
        # internal references are not updated consistently.
        passive_interface_config = passive_config

        if isinstance(passive_interface_config, str):
            if is_str_not_empty(passive_interface_config):
                self.generate(*base_path, passive_interface_config)
            return
        
        if isinstance(passive_interface_config, list):
            for item in passive_interface_config:
                if isinstance(item, dict):
                    for intf_name in item.keys():
                        if is_str_not_empty(intf_name):
                            if self.operator == 'delete' and intf_name not in new_config.get('passive-interface', {}):
                                self.generate(*base_path, intf_name)
                                continue
                            self.generate(*base_path, intf_name)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(passive_interface_config, dict):
            for intf_name in passive_interface_config.keys():
                if is_str_not_empty(intf_name):
                    if self.operator == 'delete' and intf_name not in new_config.get('passive-interface', {}):
                        self.generate(*base_path, intf_name)
                        continue
                    self.generate(*base_path, intf_name)
    
    def _process_route_config(self, route_config, current_config, new_config):
        base_path = ['protocols', 'ripng', 'route']
        
        if isinstance(route_config, list):
            for item in route_config:
                if isinstance(item, dict):
                    for route in item.keys():
                        if is_str_not_empty(route):
                            if self.operator == 'delete' and route not in new_config.get('route', {}):
                                self.generate(*base_path, route)
                                continue
                            self.generate(*base_path, route)
                elif is_str_not_empty(item):
                    self.generate(*base_path, item)
        elif isinstance(route_config, dict):
            for route in route_config.keys():
                if is_str_not_empty(route):
                    if self.operator == 'delete' and route not in new_config.get('route', {}):
                        self.generate(*base_path, route)
                        continue
                    self.generate(*base_path, route)
        elif is_str_not_empty(route_config):
            route = route_config
            if self.operator == 'delete' and route not in new_config.get('route', {}):
                self.generate(*base_path, route)
                return
            self.generate(*base_path, route)
    
    def _process_interface_config(self, interface_config, current_config, new_config):
        for intf_name, intf_data in interface_config.items():
            base_path = ['protocols', 'ripng', 'interface', intf_name]
            
            if not intf_data or intf_data == {}:
                self.generate(*base_path)
                continue

            if self.operator == 'delete' and intf_name not in new_config.get('interface', {}):
                self.generate(*base_path)
                continue
            
            if 'split-horizon' in intf_data:
                split_horizon_data = intf_data['split-horizon']
                
                if split_horizon_data == {} or split_horizon_data is True:
                    self.generate(*base_path, 'split-horizon')
                elif isinstance(split_horizon_data, dict):
                    if 'disable' in split_horizon_data:
                        self.generate(*base_path, 'split-horizon', 'disable')
                    elif 'poison-reverse' in split_horizon_data:
                        self.generate(*base_path, 'split-horizon', 'poison-reverse')
    
    def _process_redistribute_config(self, redistribute_config, current_config, new_config):
        for protocol, protocol_data in redistribute_config.items():
            base_path = ['protocols', 'ripng', 'redistribute', protocol]
            
            if self.operator == 'delete' and protocol not in new_config.get('redistribute', {}):
                self.generate(*base_path)
                continue
            
            if not protocol_data or protocol_data == {}:
                self.generate(*base_path)
                continue
            
            if 'metric' in protocol_data and is_str_not_empty(protocol_data['metric']):
                self.generate(*base_path, 'metric', str(protocol_data['metric']))
