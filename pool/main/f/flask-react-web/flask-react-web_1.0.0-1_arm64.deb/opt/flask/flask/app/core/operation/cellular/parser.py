
from app.core.operation.dhcp_options.parser import parse_to_dhcp_options_vyos_config
from app.core.operation.ip_options.parser import parse_to_ip_options_vyos_config
from app.core.utils.format_str import decode_description


def is_not_empty(value):
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    if isinstance(value, list):
        return len(value) > 0
    return True


def get_first(data: dict, *keys, default=None):
    if not isinstance(data, dict):
        return default
    for key in keys:
        if key in data:
            return data[key]
    return default


def get_first_not_empty(data: dict, *keys, default=None):
    if not isinstance(data, dict):
        return default
    for key in keys:
        value = data.get(key)
        if is_not_empty(value):
            return value
    return default


def set_leaf(config: dict, key: str, enabled: bool):
    if enabled is True:
        config[key] = {}


def set_toggle_leaf(config: dict, enabled_key: str, disabled_key: str, value):
    if value is True:
        config[enabled_key] = {}
    elif value is False:
        config[disabled_key] = {}


def to_config_value(value):
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    return str(value)


def to_config_list(value):
    if isinstance(value, list):
        return [str(item) for item in value if is_not_empty(item)]
    if is_not_empty(value):
        return [str(value)]
    return []


def set_value(config: dict, key: str, value):
    if is_not_empty(value):
        config[key] = to_config_value(value)


def set_threshold(config: dict, key: str, value):
    if not isinstance(value, dict):
        return

    threshold_config = {}
    set_value(threshold_config, 'rssi', value.get('rssi'))
    set_value(threshold_config, 'rsrp', value.get('rsrp'))
    if threshold_config:
        config[key] = threshold_config


def parse_to_wwan_ip_options(ip_data: dict):
    ip_result = {}
    ipv6_result = {}

    set_value(ip_result, 'adjust-mss', ip_data.get('adjustMss'))
    set_leaf(ip_result, 'disable-forwarding', ip_data.get('disableForwarding') is True)
    set_value(ip_result, 'source-validation', ip_data.get('sourceValidation'))

    set_value(ipv6_result, 'adjust-mss', ip_data.get('ipv6AdjustMss'))
    set_leaf(ipv6_result, 'disable-forwarding', ip_data.get('ipv6DisableForwarding') is True)
    set_value(ipv6_result, 'source-validation', ip_data.get('ipv6SourceValidation'))

    return ip_result, ipv6_result


def is_disable_state(value):
    return value is False or value == 'disable'


def is_enable_state(value):
    return value is True or value == 'enable'


def to_feature_state(config: dict, enabled_key: str = None, disabled_key: str = None):
    if enabled_key and has_leaf(config, enabled_key):
        return 'enable'
    if disabled_key and has_leaf(config, disabled_key):
        return 'disable'
    return 'default'


def to_logging_state(config: dict, disabled_key: str):
    if has_leaf(config, disabled_key):
        return 'disable'
    return 'default'


def has_leaf(config: dict, key: str) -> bool:
    return isinstance(config, dict) and key in config


def to_number(value):
    if value is None or value == "" or isinstance(value, dict):
        return None
    try:
        if isinstance(value, str) and "." in value:
            return float(value)
        return int(value)
    except (TypeError, ValueError):
        return value


def parse_to_wwan_config(data: dict):
    config = {}

    if not isinstance(data, dict):
        return config

    set_value(config, 'description', data.get('description'))
    set_value(config, 'vrf', data.get('vrf'))
    set_value(config, 'connection-mode', data.get('connectionMode'))
    set_value(config, 'network-mode', data.get('networkMode'))
    set_leaf(config, 'network-time', data.get('networkTime') is True)
    if data.get('networkTime') is True:
        set_value(config['network-time'], 'update-interval', data.get('networkTimeUpdateInterval'))
    set_value(config, 'default-route-metric', data.get('defaultRouteMetric'))
    set_value(config, 'mtu', data.get('mtu'))

    network = data.get('network') if isinstance(data.get('network'), dict) else {}
    addresses = []
    ipv4_network = network.get('ipv4') if isinstance(network.get('ipv4'), dict) else {}
    ipv6_network = network.get('ipv6') if isinstance(network.get('ipv6'), dict) else {}

    if ipv4_network.get('mode') == 'dhcp':
        addresses.append('dhcp')
    elif ipv4_network.get('mode') == 'static':
        static = ipv4_network.get('static') if isinstance(ipv4_network.get('static'), dict) else {}
        if is_not_empty(static.get('address')):
            addresses.append(static['address'])

    if ipv6_network.get('mode') == 'dhcpv6':
        addresses.append('dhcpv6')
    elif ipv6_network.get('mode') == 'static':
        static = ipv6_network.get('static') if isinstance(ipv6_network.get('static'), dict) else {}
        if is_not_empty(static.get('address')):
            addresses.append(static['address'])
    elif ipv6_network.get('mode') == 'autoconf':
        config.setdefault('ipv6', {}).setdefault('address', {})['autoconf'] = {}
    elif ipv6_network.get('mode') == 'delegated':
        config.setdefault('ipv6', {}).setdefault('address', {})['dhcpv6'] = {}

    if addresses:
        config['address'] = addresses

    ipv6_bridging = data.get('ipv6Bridging') or data.get('ipv6-bridging') or {}
    if ipv6_bridging and ipv6_bridging.get('enabled') is not False and ipv6_bridging.get('interface') != '':
        bridging_config = {}
        set_value(bridging_config, 'interface', ipv6_bridging.get('interface'))
        set_value(bridging_config, 'reconciliation-interval', ipv6_bridging.get('reconciliationInterval'))
        set_value(bridging_config, 'translate-prefix', ipv6_bridging.get('translatePrefix'))
        router_advert = ipv6_bridging.get('routerAdvert') or {}
        ra_config = {}
        for field, key in [
            ('minInterval', 'min-interval'),
            ('maxInterval', 'max-interval'),
            ('preferredLifetime', 'preferred-lifetime'),
            ('validLifetime', 'valid-lifetime'),
        ]:
            set_value(ra_config, key, router_advert.get(field))
        if router_advert.get('enabled') is not False and (ra_config or router_advert.get('enabled') is True):
            bridging_config['router-advert'] = ra_config
        if bridging_config:
            config['ipv6-bridging'] = bridging_config

    if data.get('enabled') is False:
        config['disable'] = {}

    if data.get('ip'):
        ip_result, ipv6_result = parse_to_ip_options_vyos_config(data['ip'])
        if ip_result:
            config['ip'] = ip_result
        if ipv6_result:
            existing_ipv6 = config.setdefault('ipv6', {})
            for key, value in ipv6_result.items():
                if key == 'address' and isinstance(value, dict):
                    existing_ipv6.setdefault('address', {}).update(value)
                else:
                    existing_ipv6[key] = value

    ipv6_management = data.get('ipv6ManagementAddress') or data.get('ipv6-management-address') or {}
    if ipv6_management:
        management_config = {}
        set_leaf(management_config, 'disable-default-https', ipv6_management.get('disableDefaultHttps') is True)
        set_value(management_config, 'host-id', ipv6_management.get('hostId'))
        if is_not_empty(ipv6_management.get('permitTcp')):
            management_config['permit-tcp'] = to_config_list(ipv6_management.get('permitTcp'))
        if is_not_empty(ipv6_management.get('permitUdp')):
            management_config['permit-udp'] = to_config_list(ipv6_management.get('permitUdp'))
        if is_not_empty(ipv6_management.get('permitSource')):
            management_config['permit-source'] = to_config_list(ipv6_management.get('permitSource'))

        if ipv6_management.get('enabled') is False:
            pass
        elif ipv6_management.get('enabled') is True or management_config:
            config.setdefault('ipv6', {})['management-address'] = management_config

    if data.get('dhcp'):
        dhcp_result, dhcpv6_result = parse_to_dhcp_options_vyos_config(data['dhcp'])
        if dhcp_result:
            config['dhcp-options'] = dhcp_result
        if dhcpv6_result:
            config['dhcpv6-options'] = dhcpv6_result

    mirror = data.get('mirror') or {}
    if mirror:
        mirror_config = {}
        set_value(mirror_config, 'ingress', mirror.get('ingress'))
        set_value(mirror_config, 'egress', mirror.get('egress'))
        if mirror_config:
            config['mirror'] = mirror_config

    ip_passthrough = data.get('ipPassthrough') or data.get('ip-passthrough') or {}
    if ip_passthrough and ip_passthrough.get('enabled') is not False:
        passthrough_config = {}
        set_value(passthrough_config, 'interface', ip_passthrough.get('interface'))
        set_value(passthrough_config, 'mac', ip_passthrough.get('mac'))
        set_value(passthrough_config, 'lease-time', ip_passthrough.get('leaseTime'))
        set_value(passthrough_config, 'passthrough-management-address', ip_passthrough.get('managementAddress'))
        set_value(passthrough_config, 'passthrough-management-address-ipv6', ip_passthrough.get('managementAddressIpv6'))
        if is_not_empty(ip_passthrough.get('dnsServers')):
            passthrough_config['dns-server'] = to_config_list(ip_passthrough.get('dnsServers'))
        set_leaf(passthrough_config, 'disable-mss-clamp', ip_passthrough.get('disableMssClamp') is True)
        set_leaf(passthrough_config, 'legacy-dhcpv4-compat', ip_passthrough.get('legacyDhcpv4Compat') is True)
        router_advert = ip_passthrough.get('routerAdvert') or {}
        ra_config = {}
        for field, key in [
            ('interval', 'interval'),
            ('routerLifetime', 'router-lifetime'),
            ('prefixLifetime', 'prefix-lifetime'),
        ]:
            set_value(ra_config, key, router_advert.get(field))
        if router_advert.get('enabled') is not False and (ra_config or router_advert.get('enabled') is True):
            passthrough_config['router-advert'] = ra_config
        if ip_passthrough.get('enabled') is True or passthrough_config:
            config['ip-passthrough'] = passthrough_config

    sim = data.get('sim') or {}
    if sim:
        sim_config = {}
        set_value(sim_config, 'primary-slot', sim.get('activeSlot'))

        slots = sim.get('slots') or []
        if slots:
            sim_config['slot'] = {}
            for slot in slots:
                if not isinstance(slot, dict):
                    continue
                slot_num = slot.get('slotNumber')
                if slot_num in (None, ""):
                    continue

                slot_config = {}
                if slot.get('enabled') is False:
                    slot_config['disable'] = {}
                set_value(slot_config, 'iccid', slot.get('iccid'))
                set_value(slot_config, 'apn', slot.get('apn'))
                set_value(slot_config, 'username', slot.get('username'))
                set_value(slot_config, 'password', slot.get('password'))
                set_value(slot_config, 'auth-type', slot.get('authType'))
                set_value(slot_config, 'pdp-type', slot.get('pdpType'))
                if is_disable_state(slot.get('roaming')):
                    slot_config['disable-roaming'] = {}
                set_value(slot_config, 'pin', slot.get('pin'))
                set_value(slot_config, 'puk', slot.get('puk'))
                if is_not_empty(slot.get('supportedBands')):
                    slot_config['supported-bands'] = to_config_list(slot.get('supportedBands'))
                set_value(slot_config, 'preferred-carrier', slot.get('preferredCarrier'))
                set_leaf(slot_config, 'enable-network-scan', slot.get('enableNetworkScan') is True)
                set_value(slot_config, 'mtu', slot.get('mtu'))
                set_value(slot_config, 'warning', slot.get('warning'))

                data_limit = slot.get('dataLimit') or {}
                data_limit_config = {}
                set_value(data_limit_config, 'size', data_limit.get('size'))
                set_value(data_limit_config, 'action', data_limit.get('action'))
                set_value(data_limit_config, 'billing-date', data_limit.get('billingDate'))
                if is_not_empty(data_limit.get('warningThresholds')):
                    data_limit_config['warning'] = to_config_list(data_limit.get('warningThresholds'))
                if data_limit_config:
                    slot_config['data-limit'] = data_limit_config

                if slot_config:
                    sim_config['slot'][str(slot_num)] = slot_config

        sim_failback = sim.get('simFailback') or {}
        if sim_failback:
            failback_config = {}
            if sim_failback.get('enable') is False:
                failback_config['disable'] = {}
            set_value(failback_config, 'check-interval', sim_failback.get('checkInterval'))
            set_value(failback_config, 'stability-time', sim_failback.get('stabilityTime'))
            if failback_config:
                sim_config['sim-failback'] = failback_config

        sim_failover = sim.get('simFailover') or {}
        if sim_failover:
            failover_config = {}
            if sim_failover.get('enable') is False:
                failover_config['disable'] = {}
            set_value(failover_config, 'connect-retries', sim_failover.get('connectRetries'))
            set_value(failover_config, 'signal-loss-timer', sim_failover.get('signalLossTimer'))
            set_threshold(failover_config, 'signal-threshold', sim_failover.get('signalThreshold'))
            if failover_config:
                sim_config['sim-failover'] = failover_config

        if sim_config:
            config['sim'] = sim_config

    apn_discovery = data.get('apnDiscovery') or {}
    if apn_discovery:
        apn_discovery_config = {}
        if apn_discovery.get('android') is False:
            apn_discovery_config['disable'] = {}
        if apn_discovery_config:
            config['apn-discovery'] = apn_discovery_config

    reconnection = data.get('reconnection') or {}
    if reconnection:
        reconnection_config = {}
        if is_disable_state(reconnection.get('enhanced')):
            reconnection_config['disable-enhanced'] = {}
        set_threshold(reconnection_config, 'signal-threshold', reconnection.get('signalThreshold'))
        retry_interval = reconnection.get('retryInterval') or {}
        retry_config = {}
        set_value(retry_config, 'good-signal', retry_interval.get('goodSignal'))
        set_value(retry_config, 'poor-signal', retry_interval.get('poorSignal'))
        if retry_config:
            reconnection_config['retry-interval'] = retry_config
        set_value(reconnection_config, 'max-wait-for-signal', reconnection.get('maxWaitForSignal'))
        set_value(reconnection_config, 'signal-check-interval', reconnection.get('signalCheckInterval'))
        set_value(reconnection_config, 'signal-strength-buffer', reconnection.get('signalStrengthBuffer'))
        if reconnection_config:
            config['reconnection'] = reconnection_config

    interface_management = data.get('interfaceManagement') or {}
    if interface_management:
        management_config = {}
        if interface_management.get('enable') is False:
            management_config['disable'] = {}
        set_value(management_config, 'bearer-disconnect-delay', interface_management.get('bearerDisconnectDelay'))
        set_value(management_config, 'registration-recovery-delay', interface_management.get('registrationRecoveryDelay'))
        set_value(management_config, 'registration-flap-count', interface_management.get('registrationFlapCount'))
        set_value(management_config, 'registration-flap-window', interface_management.get('registrationFlapWindow'))
        set_value(management_config, 'ip-change-delay', interface_management.get('ipChangeDelay'))
        if is_disable_state(interface_management.get('ensureLinkUpOnConnect')):
            management_config['disable-ensure-link-up-on-connect'] = {}
        if is_disable_state(interface_management.get('monitorBearerState')):
            management_config['disable-monitor-bearer-state'] = {}
        if is_disable_state(interface_management.get('monitorIpChanges')):
            management_config['disable-monitor-ip-changes'] = {}
        set_value(management_config, 'interface-up-timeout', interface_management.get('interfaceUpTimeout'))
        if management_config:
            config['interface-management'] = management_config

    monitoring = data.get('connectivityMonitoring') or {}
    if monitoring:
        monitoring_config = {}
        if monitoring.get('enable') is False:
            monitoring_config['disable'] = {}
        set_value(monitoring_config, 'interval', monitoring.get('interval'))
        set_value(monitoring_config, 'timeout', monitoring.get('timeout'))
        set_value(monitoring_config, 'retry-count', monitoring.get('retryCount'))
        set_value(monitoring_config, 'failure-threshold', monitoring.get('failureThreshold'))
        if is_disable_state(monitoring.get('testIpv4')):
            monitoring_config['disable-test-ipv4'] = {}
        set_leaf(monitoring_config, 'test-ipv6', is_enable_state(monitoring.get('testIpv6')))
        set_leaf(monitoring_config, 'require-both', monitoring.get('requireBoth') is True)
        if is_not_empty(monitoring.get('ipv4Targets')):
            monitoring_config['ipv4-targets'] = to_config_list(monitoring.get('ipv4Targets'))
        if is_not_empty(monitoring.get('ipv6Targets')):
            monitoring_config['ipv6-targets'] = to_config_list(monitoring.get('ipv6Targets'))
        if monitoring_config:
            config['connectivity-monitoring'] = monitoring_config

    data_usage = data.get('dataUsage') or {}
    if data_usage:
        data_usage_config = {}
        set_value(data_usage_config, 'monitoring-interval', data_usage.get('monitoringInterval'))
        if is_not_empty(data_usage.get('warningThresholds')):
            data_usage_config['warning'] = to_config_list(data_usage.get('warningThresholds'))
        default_limit = data_usage.get('defaultLimit') or {}
        default_limit_config = {}
        set_value(default_limit_config, 'size', get_first_not_empty(data_usage, 'size', default=default_limit.get('size')))
        set_value(default_limit_config, 'action', get_first_not_empty(data_usage, 'action', default=default_limit.get('action')))
        set_value(default_limit_config, 'billing-date', get_first_not_empty(data_usage, 'billingDate', default=default_limit.get('billingDate')))
        if default_limit_config:
            data_usage_config.update(default_limit_config)
        if data_usage_config:
            config['data-usage'] = data_usage_config

    hardware_reset = data.get('hardwareReset') or {}
    if hardware_reset:
        reset_config = {}
        if hardware_reset.get('enable') is False:
            reset_config['disable'] = {}
        set_value(reset_config, 'max-attempts', hardware_reset.get('maxAttempts'))
        set_value(reset_config, 'cooldown', hardware_reset.get('cooldown'))
        if reset_config:
            config['hardware-reset'] = reset_config

    failed_retry = data.get('failedRetry') or {}
    if failed_retry:
        retry_config = {}
        if failed_retry.get('enable') is False:
            retry_config['disable'] = {}
        if is_not_empty(failed_retry.get('intervals')):
            retry_config['intervals'] = to_config_list(failed_retry.get('intervals'))
        set_value(retry_config, 'max-interval', failed_retry.get('maxInterval'))
        set_value(retry_config, 'escalation-threshold', failed_retry.get('escalationThreshold'))
        if retry_config:
            config['failed-retry'] = retry_config

    network_scan = data.get('networkScan') or {}
    if network_scan:
        scan_config = {}
        set_value(scan_config, 'timeout', network_scan.get('timeout'))
        if scan_config:
            config['network-scan'] = scan_config

    timeouts = data.get('timeouts') or {}
    if timeouts:
        timeouts_config = {}
        set_value(timeouts_config, 'connection', get_first(timeouts, 'connection', 'connections'))
        set_value(timeouts_config, 'registration', timeouts.get('registration'))
        set_value(timeouts_config, 'normal-monitoring-interval', timeouts.get('normalMonitoringInterval'))
        if timeouts_config:
            config['timeouts'] = timeouts_config

    logging = data.get('logging') or {}
    if logging:
        logging_config = {}
        set_value(logging_config, 'level', logging.get('level'))
        set_value(logging_config, 'sink', logging.get('sink'))
        if is_disable_state(logging.get('verbose')):
            logging_config['disable-verbose'] = {}
        if logging_config:
            config['logging'] = logging_config

    return config


def parse_current_wwan_interface_config(os_config: dict, name: str):
    if not isinstance(os_config, dict):
        return {}
    return os_config.get('interfaces', {}).get('wwan', {}).get(name, {}) or {}


def parse_wwan_config_to_form(name: str, config: dict):
    config = config or {}
    result = {'name': name}

    def add_value(output: dict, output_key: str, source: dict, source_key: str, transform=None):
        if isinstance(source, dict) and source_key in source:
            value = source.get(source_key)
            output[output_key] = transform(value) if transform else value

    def add_leaf(output: dict, output_key: str, source: dict, source_key: str):
        if has_leaf(source, source_key):
            output[output_key] = True

    def add_list(output: dict, output_key: str, source: dict, source_key: str):
        if not isinstance(source, dict) or source_key not in source:
            return
        value = source.get(source_key)
        output[output_key] = value if isinstance(value, list) else [value]

    def add_threshold(output: dict, output_key: str, source: dict, source_key: str):
        threshold = source.get(source_key) if isinstance(source, dict) else None
        if not isinstance(threshold, dict):
            return
        parsed = {'enabled': True}
        add_value(parsed, 'rssi', threshold, 'rssi', to_number)
        add_value(parsed, 'rsrp', threshold, 'rsrp', to_number)
        if parsed:
            output[output_key] = parsed

    if 'description' in config:
        result['description'] = decode_description(config.get('description'))
    add_value(result, 'vrf', config, 'vrf')
    add_value(result, 'mtu', config, 'mtu', to_number)
    add_value(result, 'connectionMode', config, 'connection-mode')
    add_value(result, 'networkMode', config, 'network-mode')
    add_leaf(result, 'networkTime', config, 'network-time')
    add_value(result, 'networkTimeUpdateInterval', config.get('network-time'), 'update-interval', to_number)
    add_value(result, 'defaultRouteMetric', config, 'default-route-metric', to_number)
    if has_leaf(config, 'disable'):
        result['enabled'] = False

    if 'ipv6-bridging' in config:
        bridging = config.get('ipv6-bridging') or {}
        parsed = {'enabled': True}
        add_value(parsed, 'interface', bridging, 'interface')
        add_value(parsed, 'reconciliationInterval', bridging, 'reconciliation-interval', to_number)
        add_value(parsed, 'translatePrefix', bridging, 'translate-prefix')
        if isinstance(bridging.get('router-advert'), dict):
            router_advert = bridging['router-advert']
            parsed_ra = {'enabled': True}
            for field, key in [
                ('minInterval', 'min-interval'),
                ('maxInterval', 'max-interval'),
                ('preferredLifetime', 'preferred-lifetime'),
                ('validLifetime', 'valid-lifetime'),
            ]:
                add_value(parsed_ra, field, router_advert, key, to_number)
            parsed['routerAdvert'] = parsed_ra
        result['ipv6Bridging'] = parsed

    if 'ip' in config or 'ipv6' in config:
        ip = config.get('ip') or {}
        ipv6 = config.get('ipv6') or {}
        parsed_ip = {}
        add_value(parsed_ip, 'adjustMss', ip, 'adjust-mss')
        add_value(parsed_ip, 'arpCacheTimeout', ip, 'arp-cache-timeout')
        add_leaf(parsed_ip, 'disableArpFilter', ip, 'disable-arp-filter')
        add_value(parsed_ip, 'sourceValidation', ip, 'source-validation')
        add_leaf(parsed_ip, 'disableForwarding', ip, 'disable-forwarding')
        add_leaf(parsed_ip, 'enableArpAccept', ip, 'enable-arp-accept')
        add_leaf(parsed_ip, 'enableArpAnnounce', ip, 'enable-arp-announce')
        add_leaf(parsed_ip, 'enableArpIgnore', ip, 'enable-arp-ignore')
        add_leaf(parsed_ip, 'enableDirectedBroadcast', ip, 'enable-directed-broadcast')
        add_leaf(parsed_ip, 'enableProxyArp', ip, 'enable-proxy-arp')
        add_leaf(parsed_ip, 'proxyArpPvlan', ip, 'proxy-arp-pvlan')
        add_value(parsed_ip, 'ipv6AcceptDad', ipv6, 'accept-dad')
        add_value(parsed_ip, 'ipv6AdjustMss', ipv6, 'adjust-mss')
        add_value(parsed_ip, 'ipv6BaseReachableTime', ipv6, 'base-reachable-time')
        add_value(parsed_ip, 'ipv6DupAddrDetectTransmits', ipv6, 'dup-addr-detect-transmits')
        add_value(parsed_ip, 'ipv6SourceValidation', ipv6, 'source-validation')
        add_leaf(parsed_ip, 'ipv6DisableForwarding', ipv6, 'disable-forwarding')
        ipv6_address = ipv6.get('address') if isinstance(ipv6.get('address'), dict) else {}
        add_leaf(parsed_ip, 'ipv6AddressAutoconf', ipv6_address, 'autoconf')
        add_value(parsed_ip, 'ipv6AddressEui64', ipv6_address, 'eui64')
        add_value(parsed_ip, 'ipv6InterfaceIdentifier', ipv6_address, 'interface-identifier')
        add_leaf(parsed_ip, 'ipv6AddressNoDefaultLinkLocal', ipv6_address, 'no-default-link-local')
        result['ip'] = parsed_ip

    if isinstance(config.get('ipv6'), dict) and 'management-address' in config.get('ipv6', {}):
        management = config.get('ipv6', {}).get('management-address') or {}
        parsed = {'enabled': True}
        add_leaf(parsed, 'disableDefaultHttps', management, 'disable-default-https')
        add_value(parsed, 'hostId', management, 'host-id')
        add_list(parsed, 'permitTcp', management, 'permit-tcp')
        add_list(parsed, 'permitUdp', management, 'permit-udp')
        add_list(parsed, 'permitSource', management, 'permit-source')
        result['ipv6ManagementAddress'] = parsed

    if 'dhcp-options' in config or 'dhcpv6-options' in config:
        dhcp = config.get('dhcp-options') or {}
        dhcpv6 = config.get('dhcpv6-options') or {}
        parsed_dhcp = {}
        add_value(parsed_dhcp, 'dhcpClientId', dhcp, 'client-id')
        add_value(parsed_dhcp, 'dhcpDefaultRouteDistance', dhcp, 'default-route-distance')
        add_value(parsed_dhcp, 'dhcpHostName', dhcp, 'host-name')
        add_leaf(parsed_dhcp, 'dhcpMtu', dhcp, 'mtu')
        add_leaf(parsed_dhcp, 'dhcpNoDefaultRoute', dhcp, 'no-default-route')
        add_value(parsed_dhcp, 'dhcpUserClass', dhcp, 'user-class')
        add_value(parsed_dhcp, 'dhcpVendorClassId', dhcp, 'vendor-class-id')
        add_value(parsed_dhcp, 'dhcpv6Duid', dhcpv6, 'duid')
        add_leaf(parsed_dhcp, 'dhcpv6NoRelease', dhcpv6, 'no-release')
        add_leaf(parsed_dhcp, 'dhcpv6ParametersOnly', dhcpv6, 'parameters-only')
        add_leaf(parsed_dhcp, 'dhcpv6NoRequestDomainName', dhcpv6, 'no-request-domain-name')
        add_leaf(parsed_dhcp, 'dhcpv6NoRequestDns', dhcpv6, 'no-request-dns')
        add_leaf(parsed_dhcp, 'dhcpv6RapidCommit', dhcpv6, 'rapid-commit')
        add_leaf(parsed_dhcp, 'dhcpv6Temporary', dhcpv6, 'temporary')
        if isinstance(dhcpv6.get('pd'), dict):
            pd_config = {}
            for instance_id, instance_data in dhcpv6.get('pd', {}).items():
                if not isinstance(instance_data, dict):
                    continue
                parsed_pd = {}
                add_value(parsed_pd, 'length', instance_data, 'length')
                interfaces = instance_data.get('interface')
                if isinstance(interfaces, dict):
                    parsed_interfaces = {}
                    for intf_name, intf_data in interfaces.items():
                        if not isinstance(intf_data, dict):
                            continue
                        parsed_intf = {}
                        add_value(parsed_intf, 'address', intf_data, 'address')
                        add_value(parsed_intf, 'slaId', intf_data, 'sla-id')
                        add_value(parsed_intf, 'slaLength', intf_data, 'sla-length')
                        add_value(parsed_intf, 'slaLength', intf_data, 'sla-len')
                        if parsed_intf:
                            parsed_interfaces[intf_name] = parsed_intf
                    if parsed_interfaces:
                        parsed_pd['interfaces'] = parsed_interfaces
                if parsed_pd:
                    pd_config[str(instance_id)] = parsed_pd
            if pd_config:
                parsed_dhcp['dhcpv6Pd'] = pd_config
        result['dhcp'] = parsed_dhcp

    address = config.get('address')
    addresses = address if isinstance(address, list) else [address]
    address_values = [str(item) for item in addresses if item is not None]
    ipv4_address = next((item for item in address_values if item != 'dhcp' and ':' not in item and item != 'dhcpv6'), '')
    ipv6_address = next((item for item in address_values if item != 'dhcpv6' and ':' in item), '')
    ipv6_options = config.get('ipv6') if isinstance(config.get('ipv6'), dict) else {}
    ipv6_address_options = ipv6_options.get('address') if isinstance(ipv6_options.get('address'), dict) else {}

    ipv4_mode = 'dhcp' if 'dhcp' in address_values else 'static'
    if 'dhcpv6' in address_values:
        ipv6_mode = 'dhcpv6'
    elif 'autoconf' in ipv6_address_options:
        ipv6_mode = 'autoconf'
    elif 'dhcpv6' in ipv6_address_options:
        ipv6_mode = 'delegated'
    else:
        ipv6_mode = 'static'

    result['network'] = {
        'ipv4': {
            'mode': ipv4_mode,
            'static': {'address': ipv4_address},
            'dhcp': {'enabled': ipv4_mode == 'dhcp', 'options': {}},
        },
        'ipv6': {
            'mode': ipv6_mode,
            'static': {'address': ipv6_address},
            'dhcpv6': {'enabled': ipv6_mode == 'dhcpv6', 'options': {}},
            'autoconf': {'enabled': ipv6_mode == 'autoconf'},
            'delegated': {'enabled': ipv6_mode == 'delegated'},
        },
    }

    if 'mirror' in config:
        mirror = config.get('mirror') or {}
        parsed = {}
        add_value(parsed, 'ingress', mirror, 'ingress')
        add_value(parsed, 'egress', mirror, 'egress')
        result['mirror'] = parsed

    if 'ip-passthrough' in config:
        passthrough = config.get('ip-passthrough') or {}
        parsed = {'enabled': True}
        add_value(parsed, 'interface', passthrough, 'interface')
        add_value(parsed, 'mac', passthrough, 'mac')
        add_value(parsed, 'leaseTime', passthrough, 'lease-time', to_number)
        add_value(parsed, 'managementAddress', passthrough, 'management-address')
        add_value(parsed, 'managementAddressIpv6', passthrough, 'management-address-ipv6')
        add_value(parsed, 'managementAddress', passthrough, 'passthrough-management-address')
        add_value(parsed, 'managementAddressIpv6', passthrough, 'passthrough-management-address-ipv6')
        add_list(parsed, 'dnsServers', passthrough, 'dns-server')
        add_leaf(parsed, 'disableMssClamp', passthrough, 'disable-mss-clamp')
        add_leaf(parsed, 'legacyDhcpv4Compat', passthrough, 'legacy-dhcpv4-compat')
        if isinstance(passthrough.get('router-advert'), dict):
            router_advert = passthrough['router-advert']
            parsed_ra = {'enabled': True}
            for field, key in [
                ('interval', 'interval'),
                ('routerLifetime', 'router-lifetime'),
                ('prefixLifetime', 'prefix-lifetime'),
            ]:
                add_value(parsed_ra, field, router_advert, key, to_number)
            parsed['routerAdvert'] = parsed_ra
        result['ipPassthrough'] = parsed

    if 'apn-discovery' in config:
        apn_discovery = config.get('apn-discovery') or {}
        parsed = {}
        parsed['android'] = not has_leaf(apn_discovery, 'disable')
        result['apnDiscovery'] = parsed

    if 'sim' in config:
        sim = config.get('sim') or {}
        parsed = {}
        add_value(parsed, 'activeSlot', sim, 'primary-slot', to_number)
        if 'activeSlot' not in parsed:
            add_value(parsed, 'activeSlot', sim, 'active-slot', to_number)

        if 'slot' in sim:
            slots = []
            slot_config = sim.get('slot') or {}
            for slot_num in sorted(slot_config.keys(), key=lambda value: str(value)):
                slot = slot_config.get(slot_num) or {}
                parsed_slot = {'slotNumber': to_number(slot_num)}
                parsed_slot['enabled'] = not has_leaf(slot, 'disable')
                add_value(parsed_slot, 'iccid', slot, 'iccid')
                add_value(parsed_slot, 'apn', slot, 'apn')
                add_value(parsed_slot, 'username', slot, 'username')
                add_value(parsed_slot, 'password', slot, 'password')
                add_value(parsed_slot, 'authType', slot, 'auth-type')
                add_value(parsed_slot, 'pdpType', slot, 'pdp-type')
                parsed_slot['roaming'] = to_feature_state(slot, disabled_key='disable-roaming')
                add_value(parsed_slot, 'pin', slot, 'pin')
                add_value(parsed_slot, 'puk', slot, 'puk')
                add_list(parsed_slot, 'supportedBands', slot, 'supported-bands')
                add_value(parsed_slot, 'preferredCarrier', slot, 'preferred-carrier')
                add_leaf(parsed_slot, 'enableNetworkScan', slot, 'enable-network-scan')
                add_value(parsed_slot, 'mtu', slot, 'mtu', to_number)
                add_value(parsed_slot, 'warning', slot, 'warning')
                if 'data-limit' in slot:
                    data_limit = slot.get('data-limit') or {}
                    parsed_limit = {}
                    add_value(parsed_limit, 'size', data_limit, 'size', to_number)
                    add_value(parsed_limit, 'action', data_limit, 'action')
                    add_value(parsed_limit, 'billingDate', data_limit, 'billing-date', to_number)
                    add_list(parsed_limit, 'warningThresholds', data_limit, 'warning')
                    parsed_slot['dataLimit'] = parsed_limit
                slots.append(parsed_slot)
            parsed['slots'] = slots

        if 'sim-failback' in sim:
            failback = sim.get('sim-failback') or {}
            parsed_failback = {}
            parsed_failback['enable'] = not has_leaf(failback, 'disable')
            add_value(parsed_failback, 'checkInterval', failback, 'check-interval', to_number)
            add_value(parsed_failback, 'stabilityTime', failback, 'stability-time', to_number)
            parsed['simFailback'] = parsed_failback

        if 'sim-failover' in sim:
            failover = sim.get('sim-failover') or {}
            parsed_failover = {}
            parsed_failover['enable'] = not has_leaf(failover, 'disable')
            add_value(parsed_failover, 'connectRetries', failover, 'connect-retries', to_number)
            add_value(parsed_failover, 'signalLossTimer', failover, 'signal-loss-timer', to_number)
            add_threshold(parsed_failover, 'signalThreshold', failover, 'signal-threshold')
            parsed['simFailover'] = parsed_failover

        result['sim'] = parsed

    if 'reconnection' in config:
        reconnection = config.get('reconnection') or {}
        parsed = {}
        parsed['enhanced'] = to_feature_state(
            reconnection,
            enabled_key='enhanced',
            disabled_key='disable-enhanced'
        )
        add_threshold(parsed, 'signalThreshold', reconnection, 'signal-threshold')
        if 'retry-interval' in reconnection:
            retry_interval = reconnection.get('retry-interval') or {}
            parsed_retry = {}
            add_value(parsed_retry, 'goodSignal', retry_interval, 'good-signal', to_number)
            add_value(parsed_retry, 'poorSignal', retry_interval, 'poor-signal', to_number)
            parsed['retryInterval'] = parsed_retry
        add_value(parsed, 'maxWaitForSignal', reconnection, 'max-wait-for-signal', to_number)
        add_value(parsed, 'signalCheckInterval', reconnection, 'signal-check-interval', to_number)
        add_value(parsed, 'signalStrengthBuffer', reconnection, 'signal-strength-buffer', to_number)
        result['reconnection'] = parsed

    if 'interface-management' in config:
        management = config.get('interface-management') or {}
        parsed = {}
        parsed['enable'] = not has_leaf(management, 'disable')
        add_value(parsed, 'bearerDisconnectDelay', management, 'bearer-disconnect-delay', to_number)
        add_value(parsed, 'registrationRecoveryDelay', management, 'registration-recovery-delay', to_number)
        add_value(parsed, 'registrationFlapCount', management, 'registration-flap-count', to_number)
        add_value(parsed, 'registrationFlapWindow', management, 'registration-flap-window', to_number)
        add_value(parsed, 'ipChangeDelay', management, 'ip-change-delay', to_number)
        parsed['ensureLinkUpOnConnect'] = to_feature_state(
            management,
            disabled_key='disable-ensure-link-up-on-connect'
        )
        parsed['monitorBearerState'] = to_feature_state(
            management,
            disabled_key='disable-monitor-bearer-state'
        )
        parsed['monitorIpChanges'] = to_feature_state(
            management,
            disabled_key='disable-monitor-ip-changes'
        )
        add_value(parsed, 'interfaceUpTimeout', management, 'interface-up-timeout', to_number)
        result['interfaceManagement'] = parsed

    if 'connectivity-monitoring' in config:
        monitoring = config.get('connectivity-monitoring') or {}
        parsed = {}
        parsed['enable'] = not has_leaf(monitoring, 'disable')
        add_value(parsed, 'interval', monitoring, 'interval', to_number)
        add_value(parsed, 'timeout', monitoring, 'timeout', to_number)
        add_value(parsed, 'retryCount', monitoring, 'retry-count', to_number)
        add_value(parsed, 'failureThreshold', monitoring, 'failure-threshold', to_number)
        parsed['testIpv4'] = to_feature_state(monitoring, disabled_key='disable-test-ipv4')
        parsed['testIpv6'] = to_feature_state(monitoring, enabled_key='test-ipv6')
        add_leaf(parsed, 'requireBoth', monitoring, 'require-both')
        add_list(parsed, 'ipv4Targets', monitoring, 'ipv4-targets')
        add_list(parsed, 'ipv6Targets', monitoring, 'ipv6-targets')
        result['connectivityMonitoring'] = parsed

    if 'data-usage' in config:
        data_usage = config.get('data-usage') or {}
        parsed = {}
        add_value(parsed, 'monitoringInterval', data_usage, 'monitoring-interval', to_number)
        add_list(parsed, 'warningThresholds', data_usage, 'warning')
        if 'warningThresholds' not in parsed:
            add_list(parsed, 'warningThresholds', data_usage, 'warning-thresholds')
        if any(key in data_usage for key in ('size', 'action', 'billing-date', 'default-limit')):
            default_limit = data_usage.get('default-limit') or data_usage
            parsed_limit = {}
            add_value(parsed_limit, 'size', default_limit, 'size', to_number)
            add_value(parsed_limit, 'action', default_limit, 'action')
            add_value(parsed_limit, 'billingDate', default_limit, 'billing-date', to_number)
            parsed['defaultLimit'] = parsed_limit
            add_value(parsed, 'size', default_limit, 'size', to_number)
            add_value(parsed, 'action', default_limit, 'action')
            add_value(parsed, 'billingDate', default_limit, 'billing-date', to_number)
        result['dataUsage'] = parsed

    if 'hardware-reset' in config:
        hardware_reset = config.get('hardware-reset') or {}
        parsed = {}
        parsed['enable'] = not has_leaf(hardware_reset, 'disable')
        add_value(parsed, 'maxAttempts', hardware_reset, 'max-attempts', to_number)
        add_value(parsed, 'cooldown', hardware_reset, 'cooldown', to_number)
        result['hardwareReset'] = parsed

    if 'failed-retry' in config:
        failed_retry = config.get('failed-retry') or {}
        parsed = {}
        parsed['enable'] = not has_leaf(failed_retry, 'disable')
        add_list(parsed, 'intervals', failed_retry, 'intervals')
        add_value(parsed, 'maxInterval', failed_retry, 'max-interval', to_number)
        add_value(parsed, 'escalationThreshold', failed_retry, 'escalation-threshold', to_number)
        result['failedRetry'] = parsed

    if 'network-scan' in config:
        network_scan = config.get('network-scan') or {}
        parsed = {}
        add_value(parsed, 'timeout', network_scan, 'timeout', to_number)
        result['networkScan'] = parsed

    if 'timeouts' in config:
        timeouts = config.get('timeouts') or {}
        parsed = {}
        add_value(parsed, 'connection', timeouts, 'connection', to_number)
        if 'connection' not in parsed:
            add_value(parsed, 'connection', timeouts, 'connections', to_number)
        add_value(parsed, 'registration', timeouts, 'registration', to_number)
        add_value(parsed, 'normalMonitoringInterval', timeouts, 'normal-monitoring-interval', to_number)
        result['timeouts'] = parsed

    if 'logging' in config:
        logging = config.get('logging') or {}
        parsed = {}
        add_value(parsed, 'level', logging, 'level')
        add_value(parsed, 'sink', logging, 'sink')
        parsed['verbose'] = to_logging_state(logging, 'disable-verbose')
        result['logging'] = parsed

    return result


def parse_cellular_op_info(data: dict):
    cellular_info = {
        "carrier": "",
        "signal": 0,
        "apn": "",
        "imei": "",
        "phone_number": "",
    }

    operation = data.get('ShowWwanIgosWwanQuery') or {}
    result = (operation.get('data') or {}).get('result')
    if isinstance(result, dict):
        numbers = result.get('modem_phone_numbers') or []
        cellular_info['phone_number'] = result.get('modem_phone_number') or (
            ', '.join(str(number) for number in numbers if number)
        )
        cellular_info['carrier'] = (
            result.get('operator') or result.get('operator_name') or result.get('sim_operator') or ''
        )
        cellular_info['imei'] = result.get('modem_imei') or ''
        cellular_info['apn'] = result.get('connected_apn') or ''
        try:
            cellular_info['signal'] = max(0, min(100, int(result.get('signal_percent') or 0)))
        except (TypeError, ValueError, OverflowError):
            pass
        return cellular_info

    def parse_signal(signal: str):
        try:
            if 'cached' in signal:
                return 0    
            signal = signal.split('%')[0]
            return int(signal)
        except:
            return 0

    if 'ShowDetailWwanQuery' not in data:
        return cellular_info
    if 'data' not in data['ShowDetailWwanQuery']:
        return cellular_info
    if 'result' not in data['ShowDetailWwanQuery']['data']:
        return cellular_info

    result = data['ShowDetailWwanQuery']['data']['result']
    if 'numbers' in result and result['numbers'] and 'own' in result['numbers']:
        cellular_info['phone_number'] = result['numbers']['own']

    if 'status' in result and result['status'] and 'signal_quality' in result['status']:
        cellular_info['signal'] = parse_signal(result['status']['signal_quality'])

    if 'threegpp' in result and result['threegpp']:
        if 'operator_name' in result['threegpp']:
            cellular_info['carrier'] = result['threegpp']['operator_name']
        if 'imei' in result['threegpp']:
            cellular_info['imei'] = result['threegpp']['imei']

    return cellular_info
