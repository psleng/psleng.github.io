SHOW_ALL_CONFIGS = '{"op": "showConfig", "path": []}'
SHOW_INTERFACE_CONFIGS = '{"op": "showConfig", "path": ["interfaces"]}'
SHOW_INTERFACE_VALUES = '{"op": "show", "path": ["interfaces", "detail"]}'
SHOW_SYSTEMS_UPTIME = '{"op": "show", "path": ["system", "uptime"]}'
SHOW_SYSTEMS_MEMORY = '{"op": "show", "path": ["system", "memory"]}'
SHOW_REBOOT = '{"op": "show", "path": ["reboot"]}'

SHOW_SYSTEMS_SENSORS = '{"op": "show", "path": ["environment", "sensors"]}'
SHOW_SYSTEMS_DATE = '{"op": "show", "path": ["host", "date"]}'
SHOW_SYSTEMS_TIMEZONE = '{"op": "showConfig", "path": ["system", "time-zone"]}'
SHOW_SYSTEMS_BOOT_IMG = '{"op": "show", "path": ["system", "image"]}'
SHOW_SYSTEMS_NAME = '{"op": "show", "path": ["host", "name"]}'
SHOW_SYSTEMS_VERSION = '{"op": "show", "path": ["version"]}'

SHOW_SYSTEM_ALL_COMMITS = '{"op": "show", "path": ["system", "commit"]}'
SHOW_SYSTEM_DOMAIN = '{"op": "showConfig", "path": ["system", "domain-name"]}'

SHOW_DNS = '{"op": "showConfig", "path": ["service", "dns"]}'
SHOW_NAME_SERVERS = '{"op": "showConfig", "path": ["system", "name-server"]}'
SHOW_DNS_DYNAMIC = '{"op": "showConfig", "path": ["service", "dns", "dynamic"]}'

SHOW_DNS_FORWARD_CACHE_SIZE = '{"op": "showConfig", "path": ["service", "dns", "forwarding", "cache-size"]}'
SHOW_DNS_FORWARD_CACHE_SECONDS = '{"op": "show", "path": ["service", "dns", "forward-cache-seconds"]}'

SET_DNS_FORWARD_IGNORE_HOSTFILE = '{"op": "set", "path": ["service", "dns", "forwarding", "ignore-hosts-file"]}'

SHOW_FIREWALL_CONFIG = '{"op": "showConfig", "path": ["firewall"]}'
SHOW_FIREWALL_OPR = '{"op": "show", "path": ["firewall"]}'

SHOW_DHCP_CONFIG = '{"op": "showConfig", "path": ["service", "dhcp-server"]}'
SHOW_DHCPV6_CONFIG = '{"op": "showConfig", "path": ["service", "dhcpv6-server"]}'
SHOW_DHCP_RELAY_CONFIG = '{"op": "showConfig", "path": ["service", "dhcp-relay"]}'

SHOW_NTP_CONFIG = '{"op": "showConfig", "path": ["service", "ntp"]}'

SHOW_HTTPS_CONFIG = '{"op": "showConfig", "path": ["service", "https"]}'
SHOW_SSH_CONFIG = '{"op": "showConfig", "path": ["service", "ssh"]}'

SHOW_ARP_CONFIG = '{"op": "showConfig", "path": ["protocols", "static", "arp"]}'

SHOW_NDP_PROXY = '{"op": "showConfig", "path": ["service", "ndp-proxy"]}'

SHOW_RAM_TOTAL_LINUX = "lsmem -b --summary=only"

SHOW_RAM_USED_LINUX = "free -m"

SHOW_NTP_SYSTEM = '{"op": "show", "path": ["ntp", "system"]}'
SHOW_NTP_SOURCE = '{"op": "show", "path": ["ntp", "source"]}'

SHOW_INTERFACE_ETHERNET = '{"op": "showConfig", "path": ["interfaces", "ethernet"]}'
SHOW_INTERFACE_WIFI = '{"op": "showConfig", "path": ["interfaces", "wireless"]}'
SHOW_ROUTER_ADVERTISEMENT = '{"op": "showConfig", "path": ["service", "router-advert"]}'

SHOW_SYSTEM = '{"op": "showConfig", "path": ["system"]}'

SHOW_SYSLOG = '{"op": "showConfig", "path": ["system", "syslog"]}'

SHOW_ALARM = '{"op": "showConfig", "path": ["service", "event-handler"]}'

SHOW_GENERAL_ROUTING = '{"op": "showConfig", "path": ["protocols", "static", "route"]}'
SHOW_GENERAL_ROUTING_V6 = '{"op": "showConfig", "path": ["protocols", "static", "route6"]}'

SHOW_FLEX_ROUTING_V6 = '{"op": "showConfig", "path": ["protocols", "failover", "route6"]}'
SHOW_FLEX_ROUTING = '{"op": "showConfig", "path": ["protocols", "failover", "route"]}'

SHOW_USER_CONFIG = '{"op": "showConfig", "path": ["system", "login", "user"]}'
SHOW_LOGIN_CONFIG = '{"op": "showConfig", "path": ["system", "login"]}'

SHOW_PKI = '{"op": "showConfig", "path": ["pki"]}'

SHOW_WIREGUARD_GENERATE_KEY_PAIR = '{"op": "generate", "path": ["pki", "wireguard", "key-pair"]}'

SHOW_WIREGUARD_GENERATE_PRE_SHARED_KEY = '{"op": "generate", "path": ["pki", "wireguard", "preshared-key"]}'

SHOW_OPENVPN_GENERATE_SHARED_SECRET = '{"op": "generate", "path": ["pki", "openvpn", "shared-secret"]}'

SHOW_INTERFACE_VTI_CONFIGS = '{"op": "showConfig", "path": ["interfaces", "vti"]}'

SHOW_OSPF = '{"op": "showConfig", "path": ["protocols", "ospf"]}'

SHOW_OSPFv3 = '{"op": "showConfig", "path": ["protocols", "ospfv3"]}'

SHOW_VRRP = '{"op": "showConfig", "path": ["high-availability", "vrrp"]}'

SHOW_WAN_LOAD_BALANCING = '{"op": "showConfig", "path": ["load-balancing", "wan"]}'

SHOW_RIP = '{"op": "showConfig", "path": ["protocols", "rip"]}'

SHOW_RIPNG = '{"op": "showConfig", "path": ["protocols", "ripng"]}'

SHOW_PPTP = '{"op": "showConfig", "path": ["vpn", "pptp"]}'

SHOW_SSTP = '{"op": "showConfig", "path": ["vpn", "sstp"]}'

SHOW_L2TP = '{"op": "showConfig", "path": ["vpn", "l2tp"]}'

SHOW_IPV6_RA = '{"op": "showConfig", "path": ["service", "router-advert"]}'

SHOW_SNMP = '{"op": "showConfig", "path": ["service", "snmp"]}'

class Command:
    def __init__(self, operator: str, resource: str):
        self.operator = operator
        self.resource = resource
        self.prefix = '{"op":'
        self.suffix = ']}'
        self.commands: list[str] = []
        self.vyos_commands: list[str] = []

    def generate_commands(self) -> list[str]:
        op = f'"{self.operator}"'
        rs = f'"{self.resource}"'
        command = f'{self.prefix}{op}, "path": [{rs}{self.suffix}'
        self.commands = [command]
        return self.commands

    def get_vyos_commands(self) -> list[str]:
        return self.vyos_commands
