from datetime import datetime, timezone
import os

from sqlalchemy import Column, DateTime, Integer, inspect

from app.core.api.api import API_ACTION, API_TARGET
from app.db.database import db
from app.log.logger import logger


SAVE_CONFIGS = '{"op": "save", "file": "/opt/vyatta/etc/config/config.boot"}'
CONFIG_SAVE_STATE_ID = 1


class ConfigSaveState(db.Model):
    __tablename__ = 'config_save_state'

    id = Column(Integer, primary_key=True)
    changed_at = Column(DateTime, nullable=True)
    saved_at = Column(DateTime, nullable=True)

    @classmethod
    def snapshot(cls):
        if not inspect(db.engine).has_table(cls.__tablename__):
            logger.debug("[config-save] Startup snapshot skipped: state table does not exist")
            return None

        state = db.session.get(cls, CONFIG_SAVE_STATE_ID)
        if state is None:
            logger.debug("[config-save] Startup snapshot found no saved state row")
            return None
        logger.debug(
            f"[config-save] Startup snapshot captured: "
            f"changed_at={state.changed_at}, saved_at={state.saved_at}"
        )
        return {
            'changed_at': state.changed_at,
            'saved_at': state.saved_at,
        }

    @classmethod
    def restore(cls, snapshot):
        if snapshot is None:
            logger.debug("[config-save] Startup restore skipped: no state snapshot")
            return

        db.session.remove()
        db.session.merge(cls(
            id=CONFIG_SAVE_STATE_ID,
            changed_at=snapshot.get('changed_at'),
            saved_at=snapshot.get('saved_at'),
        ))
        db.session.commit()
        logger.debug(
            f"[config-save] Startup state restored: "
            f"changed_at={snapshot.get('changed_at')}, saved_at={snapshot.get('saved_at')}"
        )


def _as_utc_naive(value=None):
    value = value or datetime.now(timezone.utc)
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc).replace(tzinfo=None)
    return value


def record_successful_config_change(changed_at=None):
    try:
        changed_at = _as_utc_naive(changed_at)
        state = db.session.get(ConfigSaveState, CONFIG_SAVE_STATE_ID)
        previous_changed_at = state.changed_at if state is not None else None
        previous_saved_at = state.saved_at if state is not None else None
        logger.debug(
            f"[config-save] Recording pending change: pid={os.getpid()}, "
            f"changed_at={changed_at}, previous_changed_at={previous_changed_at}, "
            f"previous_saved_at={previous_saved_at}"
        )
        if state is None:
            state = ConfigSaveState(
                id=CONFIG_SAVE_STATE_ID,
                changed_at=changed_at,
            )
            db.session.add(state)
        else:
            state.changed_at = changed_at
            # A successful configuration change always makes the running
            # configuration dirty. Do not rely on timestamp ordering here:
            # the system clock can move backwards across restarts.
            state.saved_at = None
        db.session.commit()
        logger.debug(
            f"[config-save] Pending change committed: pid={os.getpid()}, "
            f"changed_at={changed_at}, saved_at={state.saved_at}"
        )
    except Exception as exc:
        db.session.rollback()
        logger.error(f"Failed to record pending config save: {exc}")


def save_running_config():
    from app.core.api.manager import api_manager
    result = api_manager.call(
        action=API_ACTION.SAVE,
        target=API_TARGET.CONFIG_FILE,
        data=SAVE_CONFIGS,
    )
    if isinstance(result, Exception):
        raise RuntimeError(f"Config save API call failed: {result}") from result
    if not isinstance(result, dict) or result.get('success') is not True:
        raise RuntimeError(f"Config save API returned an unsuccessful response: {result!r}")
    return result


def save_config_if_recent(app_context, now=None):
    with app_context:
        logger.debug(f"[config-save] Scheduler save check started: pid={os.getpid()}")
        state = db.session.get(ConfigSaveState, CONFIG_SAVE_STATE_ID)
        if state is None:
            logger.debug("[config-save] Scheduler save skipped: state row does not exist")
            return False
        if state.changed_at is None:
            logger.debug("[config-save] Scheduler save skipped: changed_at is empty")
            return False
        if state.saved_at is not None and state.saved_at >= state.changed_at:
            logger.debug(
                f"[config-save] Scheduler save skipped: configuration is already saved; "
                f"changed_at={state.changed_at}, saved_at={state.saved_at}"
            )
            return False

        changed_at = state.changed_at
        logger.debug(
            f"[config-save] Unsaved configuration detected: "
            f"changed_at={changed_at}, saved_at={state.saved_at}"
        )
        try:
            save_running_config()
        except Exception as exc:
            logger.error(f"Scheduled config save failed: {exc}")
            return False

        try:
            state = db.session.get(ConfigSaveState, CONFIG_SAVE_STATE_ID)
            if state is not None and (
                state.saved_at is None or state.saved_at < changed_at
            ):
                state.saved_at = changed_at
                db.session.commit()
                logger.debug(
                    f"[config-save] Persistent state marked saved: saved_at={changed_at}"
                )
            else:
                logger.debug(
                    f"[config-save] Save succeeded without state update: "
                    f"state_exists={state is not None}, "
                    f"saved_at={state.saved_at if state is not None else None}, "
                    f"target_changed_at={changed_at}"
                )
        except Exception as exc:
            db.session.rollback()
            logger.error(f"Failed to mark running configuration as saved: {exc}")
            return False

        logger.debug("Saved running configuration to config.boot")
        return True
