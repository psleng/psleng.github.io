
from app.core.high_availability.vrrp.command_vrrp import VRRPCommand
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.socket.socket_manager import socket_manager
from app.core.high_availability.vrrp.models import VRRPConfig
from app.core.models import InterfaceConfig
from flask import session
from uuid import uuid4
import pprint
from app.core.api.http.http_request import Action
from app.log.logger import logger
from app.core.high_availability.vrrp.parsers import parse_vrrp_stats, parse_vrrp_details, parse_vrrp_summary
from app.core.api.http.cmd.command import SHOW_VRRP

def update_vrrp(provider, data):

    logger.info("Update VRRP:")
    logger.info(data)
    username = session['username']
    config = data.get('new')
    current_config = data.get('current')
    diff = data.get('diff')
    print("Current config: ")
    print(pprint.pformat(current_config, indent=2, width=80))
    print("New config: ")
    print(pprint.pformat(config, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = VRRPCommand(operator='set', resource='vrrp')
    set_cmds = iface_set_cmd.generate_commands(data=diff['created'], current_config=current_config, new_config=config)
    sc = iface_set_cmd.get_commands()

    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))
    
    delete_cmds = []
    iface_delete_cmd = VRRPCommand(operator='delete', resource='vrrp')
    delete_cmds = iface_delete_cmd.generate_commands(data=diff['deleted'], current_config=current_config, new_config=config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "vrrp"
    current_service_config = provider.verify_service.call_get_config(service)
    current_raw_config = current_service_config if current_service_config else {}
    merged_del_config = merge_dicts_delete(current_raw_config, new_delete_configs.get('high-availability', {}).get('vrrp', {}), clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('high-availability', {}).get('vrrp', {}))
    
    print("Merged config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    print("Final Merged config for verify: ")
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config) 
    
    cmds = list(set(delete_cmds)) + list(set(set_cmds))
    if str(verify) != "None" and str(verify) != "":
        return [{"success": False, "error": str(verify), "cmd": cmds}]
    
    VRRPConfig.refresh(config)
    InterfaceConfig.sync_vrrp_entries()

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update VRRP",
                "content": "VRRP is successfully updated"
            }
    )
    
    r = []
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def verify_vrrp(provider, data):
    config_to_verify = data
    print("Config to verify: ")
    print(pprint.pformat(config_to_verify, indent=2, width=80))
    verify = provider.verify_service.call_verify("vrrp", config_to_verify)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify


def fetch_vrrp(provider, data: dict):
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_VRRP, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    return data


def monitor_vrrp(provider, data):
    target = data.target 
    try:
        if target == "statistics":
            res = provider.graphql_service.send_request(function_name='ShowStatisticsVrrpQuery', data=None, verify=False) 
            return parse_vrrp_stats(res.json()['data'])
        elif target == "details":
            res = provider.graphql_service.send_request(function_name='ShowDetailVrrpQuery', data=None, verify=False) 
            return parse_vrrp_details(res.json()['data'])
        elif target == "summary":
            res = provider.graphql_service.send_request(function_name='ShowSummaryVrrpQuery', data=None, verify=False) 
            return parse_vrrp_summary(res.json()['data'])
        else:
            return []
    except Exception as e:
        print("Error getting vrrp monitor data:")
        print(str(e))
        return []
