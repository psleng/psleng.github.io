# Dynamic Options

The configuration page must display the options supported by the installed
VyOS version. These values must come from VyOS `*.def` files rather than
from hard-coded frontend constants.

- During package installation, copy the required VyOS definitions into the
   Flask application. If failed to copy, the use a fallback version in def/template folder.
- During Flask startup, parse the copied definitions and populate the
   database.
- When the frontend page loads, return the stored options through the API.
- Use different namespace for each service to split def files.