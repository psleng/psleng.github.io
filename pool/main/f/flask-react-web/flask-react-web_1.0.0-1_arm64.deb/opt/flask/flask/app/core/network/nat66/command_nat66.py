import json
from app.core.api.http.cmd.command import Command
import pprint

def format_description(description: str) -> str:
    return description


def format_vyos_description(description: str) -> str:
    return description.replace(' ', '_')


class CommandNAT66(Command):
    def __init__(self, **kwargs):
        operator = kwargs.get('operator', 'set')
        resource = kwargs.get('resource', 'nat66')
        super().__init__(operator=operator, resource=resource)
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        command = {
            'op': self.operator,
            'path': list(path_elements),
        }
        return json.dumps(command)


    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(f"{self.operator} {' '.join(map(str, args))}")


    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data:
            return []

        for direction in ('source', 'destination'):
            for rule_id, rule in data.get(direction, {}).get('rule', {}).items():

                base = ('nat66', direction, 'rule', rule_id)

                if self.operator == "delete" and \
                    rule_id not in new_config.get("source", {}).get("rule", {}) and \
                        rule_id not in new_config.get("destination", {}).get("rule", {}):
                    self.generate(*base)
                    continue

                for interface in ('outbound-interface', 'inbound-interface'):
                    if interface in rule: self.generate(*base, interface, 'name', rule[interface]['name'])
                for section in ('source', 'destination', 'translation'):
                    for key, value in rule.get(section, {}).items(): self.generate(*base, section, key, value)
                if 'description' in rule:
                    self.generate(
                        *base,
                        'description',
                        format_description(str(rule['description'])),
                    )
                if 'protocol' in rule:
                    self.generate(*base, 'protocol', str(rule['protocol']))
                for flag in ('disable', 'exclude', 'log'):
                    if flag in rule: self.generate(*base, flag)

        return self.cmds

    def get_commands(self): 
        return self.vyos_cmds
