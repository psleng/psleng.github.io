import pytest

test_set = [
    pytest.param(
        {
            "current_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0"]
                            }
                        }
                    }
                }
            },
            "set_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0"]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_dns_set_1"
    )
]

test_delete = [
    pytest.param(
        {
            "current_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0", "203.0.113.0"]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example9.com": {}
                        }
                    }
                }
            },
            "expected_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0", "203.0.113.0"]
                            }
                        }
                    }
                }
            }
        },
        id="test_process_dns_delete_1"
    )
]

test_set_delete = [
    pytest.param(
        {
            "current_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0", "203.0.113.0"]
                            },
                            "dns.example9.com": {
                                "name-server": "2001:db8:abcd:12::1"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example9.com": {}
                        }
                    }
                }
            },
            "set_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.net": {
                                "name-server": ["192.0.2.1"]
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dns": {
                    "forwarding": {
                        "domain": {
                            "dns.example.com": {
                                "name-server": ["198.51.100.0", "203.0.113.0"]
                            },
                            "dns.example.net": {
                                "name-server": ["192.0.2.1"]
                            }
                        }
                    }
                }
            }
        },
        id="test_process_dns_set_delete_1"
    )
]
