import json
import re
from copy import deepcopy

from app.core.operation.serial.models import SerialSlipInterfaceDTO


SLIP_FIELDS = ('description', 'disable-vj-comp', 'local-address', 'mtu', 'remote-address')


def _devices(config):
    profiles = config.get('profile', {}).get('tty-profile', {})
    return {
        name for name, device in config.get('device', {}).items()
        if 'slip' in device or 'slip' in profiles.get(device.get('profile'), {})
    }


def _command(operator, *path):
    return json.dumps({'op': operator, 'path': list(path)})


def plan_slip_interfaces(current_config, new_config, current_interfaces, values=None):
    interfaces = deepcopy(current_interfaces)
    devices = _devices(new_config)
    removed = _devices(current_config) - devices
    largest = max((int(match[1]) for name in current_interfaces
                   if (match := re.fullmatch(r'slttys(\d+)', name))), default=-1)
    set_cmds, delete_cmds = [], []
    for name, interface in list(interfaces.items()):
        if interface.get('device') in removed:
            delete_cmds.append(_command('delete', 'interfaces', 'slip-tty', name))
            del interfaces[name]
    for device in sorted(devices):
        matches = [name for name, interface in interfaces.items() if interface.get('device') == device]
        if len(matches) > 1:
            raise ValueError(f'device {device}: multiple slip-tty interfaces use this serial port')
        if matches:
            name = matches[0]
        else:
            largest += 1
            name = f'slttys{largest}'
        previous = interfaces.get(name, {})
        candidate = deepcopy(previous)
        if values is not None and device in values:
            for field in SLIP_FIELDS:
                candidate.pop(field, None)
            candidate.update({key: ({} if key == 'disable-vj-comp' else value)
                              for key, value in values[device].items() if value is not False})
        candidate['device'] = device
        if not candidate.get('local-address') or not candidate.get('remote-address'):
            raise ValueError(f'device {device}: SLIP local-address and remote-address are required')
        SerialSlipInterfaceDTO.model_validate({
            key: (True if key == 'disable-vj-comp' else value)
            for key, value in candidate.items() if key in SLIP_FIELDS
        })
        for field in ('device', *SLIP_FIELDS):
            if field in previous and field not in candidate:
                delete_cmds.append(_command('delete', 'interfaces', 'slip-tty', name, field))
            if field in candidate and (field not in previous or candidate[field] != previous[field]):
                path = ['interfaces', 'slip-tty', name, field]
                set_cmds.append(_command('set', *path) if field == 'disable-vj-comp'
                                else _command('set', *path, str(candidate[field])))
        interfaces[name] = candidate
    return {'config': interfaces, 'set_cmds': set_cmds, 'delete_cmds': delete_cmds}
