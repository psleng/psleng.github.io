def _parse_areas_to_vyos_config(data):
    areas = {}
    for area in data['areas']:
        if not area.get('areaNumber'):
            continue
        
        area_config = {}
        
        if area.get('networks'):
            area_config['network'] = area['networks']
        
        if area.get('authentication') and area['authentication'] != 'None':
            area_config['authentication'] = area['authentication'].lower()
        
        if area.get('areaType') and area['areaType'] != 'normal':
            area_type = area['areaType']
            area_type_config = {}
            
            if area.get('areaTypeConfig'):
                type_config = area['areaTypeConfig']
                if type_config.get('defaultCost'):
                    area_type_config['default-cost'] = type_config['defaultCost']
                if type_config.get('noSummary'):
                    area_type_config['no-summary'] = {}
                if type_config.get('translate'):
                    area_type_config['translate'] = type_config['translate']
            
            area_config['area-type'] = {area_type: area_type_config}
        
        if area.get('ranges'):
            ranges = {}
            for range_item in area['ranges']:
                if range_item.get('prefix'):
                    range_config = {}
                    if range_item.get('cost'):
                        range_config['cost'] = range_item['cost']
                    if range_item.get('notAdvertise'):
                        range_config['not-advertise'] = {}
                    if range_item.get('substitute'):
                        range_config['substitute'] = range_item['substitute']
                    ranges[range_item['prefix']] = range_config
            if ranges:
                area_config['range'] = ranges
        
        areas[area['areaNumber']] = area_config
    return areas


def _parse_interfaces_to_vyos_config(data):
    interfaces = {}
    for intf in data['interfaces']:
        if not intf.get('name'):
            continue
        
        intf_config = {}
        
        if intf.get('area'):
            intf_config['area'] = intf['area']
        
        if intf.get('bandwidth'):
            intf_config['bandwidth'] = intf['bandwidth']
        if intf.get('cost'):
            intf_config['cost'] = intf['cost']
        if intf.get('deadInterval'):
            intf_config['dead-interval'] = intf['deadInterval']
        if intf.get('helloInterval'):
            intf_config['hello-interval'] = intf['helloInterval']
        if intf.get('helloMultiplier'):
            intf_config['hello-multiplier'] = intf['helloMultiplier']
        if intf.get('mtuIgnore'):
            intf_config['mtu-ignore'] = {}
        if intf.get('network'):
            intf_config['network'] = intf['network']
        if intf.get('passiveDisable'):
            intf_config['passive'] = {'disable': {}}
        elif intf.get('passive'):
            intf_config['passive'] = {}
        if intf.get('priority'):
            intf_config['priority'] = intf['priority']
        if intf.get('retransmitInterval'):
            intf_config['retransmit-interval'] = intf['retransmitInterval']
        if intf.get('retransmitWindow'):
            intf_config['retransmit-window'] = intf['retransmitWindow']
        if intf.get('transmitDelay'):
            intf_config['transmit-delay'] = intf['transmitDelay']
        
        if intf.get('authentication'):
            auth = intf['authentication']
            auth_config = {}
            
            auth_type = auth.get('type', '').lower()
            
            if auth_type in ['plaintext', 'plaintext-password'] and auth.get('plaintextPassword'):
                auth_config['plaintext-password'] = auth['plaintextPassword']
            elif auth_type == 'md5' and auth.get('md5Keys'):
                md5_keys = {}
                for key in auth['md5Keys']:
                    if key.get('keyId') and key.get('md5Key'):
                        md5_keys[key['keyId']] = {'md5-key': key['md5Key']}
                if md5_keys:
                    auth_config['md5'] = {'key-id': md5_keys}
            
            if auth_config:
                intf_config['authentication'] = auth_config
        
        interfaces[intf['name']] = intf_config
    return interfaces
        

def parse_to_vyos_config(data):
    vyos_config = {}
    
    if 'advanced' in data:
        advanced = data['advanced']
        
        if advanced.get('aggregationTimer'):
            vyos_config['aggregation'] = {'timer': advanced['aggregationTimer']}
        
        if advanced.get('autoCostReferenceBandwidth'):
            vyos_config['auto-cost'] = {'reference-bandwidth': advanced['autoCostReferenceBandwidth']}
        
        if advanced.get('defaultMetric'):
            vyos_config['default-metric'] = advanced['defaultMetric']
        
        if advanced.get('capabilityOpaque'):
            vyos_config['capability'] = {'opaque': {}}
        
        if advanced.get('logAdjacencyChanges'):
            vyos_config['log-adjacency-changes'] = {'detail': {}}
        
        if advanced.get('maximumPaths'):
            vyos_config['maximum-paths'] = advanced['maximumPaths']
        
        if advanced.get('passiveInterfaceDefault'):
            vyos_config['passive-interface'] = 'default'
        
        if advanced.get('refreshTimers'):
            vyos_config['refresh'] = {'timers': advanced['refreshTimers']}
        
        parameters = {}
        if advanced.get('abrType'):
            parameters['abr-type'] = advanced['abrType']
        if advanced.get('opaqueLsa'):
            parameters['opaque-lsa'] = {}
        if advanced.get('rfc1583Compatibility'):
            parameters['rfc1583-compatibility'] = {}
        if advanced.get('routerId'):
            parameters['router-id'] = advanced['routerId']
        if parameters:
            vyos_config['parameters'] = parameters
        
        if advanced.get('spfDelay') or advanced.get('spfInitialHoldtime') or advanced.get('spfMaxHoldtime'):
            spf = {}
            if advanced.get('spfDelay'):
                spf['delay'] = advanced['spfDelay']
            if advanced.get('spfInitialHoldtime'):
                spf['initial-holdtime'] = advanced['spfInitialHoldtime']
            if advanced.get('spfMaxHoldtime'):
                spf['max-holdtime'] = advanced['spfMaxHoldtime']
            if spf:
                vyos_config['timers'] = {'throttle': {'spf': spf}}
        
        default_info = {}
        if advanced.get('defaultInformationAlways'):
            default_info['always'] = {}
        if advanced.get('defaultInformationMetric'):
            default_info['metric'] = advanced['defaultInformationMetric']
        if advanced.get('defaultInformationMetricType'):
            default_info['metric-type'] = advanced['defaultInformationMetricType']
        if default_info:
            vyos_config['default-information'] = default_info
        
        distance = {}
        if advanced.get('distanceGlobal'):
            distance['global'] = advanced['distanceGlobal']
        
        ospf_distance = {}
        if advanced.get('distanceOspfExternal'):
            ospf_distance['external'] = advanced['distanceOspfExternal']
        if advanced.get('distanceOspfInterArea'):
            ospf_distance['inter-area'] = advanced['distanceOspfInterArea']
        if advanced.get('distanceOspfIntraArea'):
            ospf_distance['intra-area'] = advanced['distanceOspfIntraArea']
        if ospf_distance:
            distance['ospf'] = ospf_distance
        if distance:
            vyos_config['distance'] = distance
        
        if advanced.get('gracefulRestart'):
            gr = {}
            if advanced.get('gracefulRestartGracePeriod'):
                gr['grace-period'] = advanced['gracefulRestartGracePeriod']
            vyos_config['graceful-restart'] = gr if gr else {}
        
        max_metric = {}
        if advanced.get('maxMetricAdministrative'):
            max_metric['administrative'] = {}
        if advanced.get('maxMetricOnShutdown'):
            max_metric['on-shutdown'] = advanced['maxMetricOnShutdown']
        if advanced.get('maxMetricOnStartup'):
            max_metric['on-startup'] = advanced['maxMetricOnStartup']
        if max_metric:
            vyos_config['max-metric'] = {'router-lsa': max_metric}
        
        if advanced.get('neighbors'):
            neighbors = {}
            for neighbor in advanced['neighbors']:
                if neighbor.get('ip'):
                    neighbor_config = {}
                    if neighbor.get('pollInterval'):
                        neighbor_config['poll-interval'] = neighbor['pollInterval']
                    if neighbor.get('priority'):
                        neighbor_config['priority'] = neighbor['priority']
                    neighbors[neighbor['ip']] = neighbor_config
            if neighbors:
                vyos_config['neighbor'] = neighbors
        
        if advanced.get('summaryAddresses'):
            summary_addresses = {}
            for summary in advanced['summaryAddresses']:
                if summary.get('prefix'):
                    summary_config = {}
                    if summary.get('notAdvertise'):
                        summary_config['no-advertise'] = {}
                    summary_addresses[summary['prefix']] = summary_config
            if summary_addresses:
                vyos_config['summary-address'] = summary_addresses
    
    if 'areas' in data and data['areas']:
        areas = _parse_areas_to_vyos_config(data)
        if areas:
            vyos_config['area'] = areas
    
    if 'interfaces' in data and data['interfaces']:
        interfaces = _parse_interfaces_to_vyos_config(data)
        if interfaces:
            vyos_config['interface'] = interfaces
    
    if 'redistribution' in data:
        redist = data['redistribution']
        redistribute = {}
        
        for protocol in ['connected', 'kernel', 'static', 'rip']:
            if redist.get(protocol) and redist[protocol].get('enabled'):
                proto_config = {}
                if redist[protocol].get('metric'):
                    proto_config['metric'] = redist[protocol]['metric']
                if redist[protocol].get('metricType'):
                    proto_config['metric-type'] = redist[protocol]['metricType']
                redistribute[protocol] = proto_config
        
        if redistribute:
            vyos_config['redistribute'] = redistribute
    
    return vyos_config


def parse_to_vyos_config_verify(data):
    verify_type = data.get('verify_type')
    if verify_type == 'area':
        return {"area": _parse_areas_to_vyos_config(data)}
    elif verify_type == 'interface':
        return {"interface": _parse_interfaces_to_vyos_config(data)}
    return {}