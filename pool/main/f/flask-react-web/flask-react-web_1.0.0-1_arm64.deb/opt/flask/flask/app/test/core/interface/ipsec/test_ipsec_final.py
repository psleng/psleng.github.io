import pytest
from app.test.conftest import test_service_provider
from app.core.operation.models import UpdateIPsecInterfaceDTO
from app.core.operation.ipsec.command_ipsec import IpsecCommand
from app.core.operation.ipsec.parser import parse_to_ipsec_config
from app.test.core.interface.ipsec.test_cases._test_case_final import test_final
from app.test.core.base import TestFinal


class TestIPSecUpdateFinal(TestFinal):
    __test__ = False

    @pytest.fixture
    def cmd_set(self):
        return IpsecCommand(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return IpsecCommand(operator='delete')

    @pytest.fixture
    def success_verification(self):
        return ['None', '']

    @pytest.fixture
    def parser(self):
        return parse_to_ipsec_config
    
    @pytest.fixture
    def dto_model(self):
        return UpdateIPsecInterfaceDTO

    @pytest.mark.parametrize("test_data", test_final)
    def test_ipsec_update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data):
        super()._update_final(
            success_verification=success_verification,
            parser=parser,
            dto_model=dto_model,
            test_service_provider=test_service_provider,
            cmd_set=cmd_set,
            cmd_delete=cmd_delete,
            test_data=test_data
        )
