import logging
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_ROUTER_ADVERTISEMENT

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def fetch_router_advertisement_config(provider, params=None):
    logger.debug("Fetching Router Advertisement config...")
    print("Fetching Router Advertisement config...")
    router_advert_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ROUTER_ADVERTISEMENT, verify=False)
    data = router_advert_response.json()['data']
    return data
