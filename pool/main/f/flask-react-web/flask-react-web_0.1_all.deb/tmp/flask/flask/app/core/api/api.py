from abc import ABC, abstractmethod
from enum import StrEnum

class API(ABC):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def call(self):
        return None
    
    @abstractmethod
    def get_api_type(self):
        return None

class API_REQUEST(ABC):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def send_request(self):
        return None


class ServiceProvider():
    def __init__(self, 
        http_service: API_REQUEST, 
        graphql_service: API_REQUEST, 
        verify_service
    ):
        self.http_service = http_service
        self.graphql_service = graphql_service
        self.verify_service = verify_service


class API_ACTION(StrEnum):
    CREATE = "CREATE"
    READ = "READ"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    VERIFY = "VERIFY"
    MONITOR = "MONITOR"
    REFRESH = "REFRESH"
    AUTH = "AUTH"


class API_TARGET(StrEnum):
    OS_CONFIG = "OS_CONFIG"
    INTERFACE = "INTERFACE"
    INTERFACE_CONFIG = "INTERFACE_CONFIG"
    INTERFACE_ADDRESS = "INTERFACE_ADDRESS"
    INTERFACE_IPV4 = "INTERFACE_IPV4"
    INTERFACE_BY_NAME = "INTERFACE_BY_NAME"
    SYSTEM = "SYSTEM"
    SYSTEM_DATETIME = "SYSTEM_DATETIME"
    SYSTEM_CPU = "SYSTEM_CPU"
    SYSTEM_MEMORY = "SYSTEM_MEMORY"
    DNS = "DNS"
    DNS_SERVER = "DNS_SERVER"
    DNS_FORWARD = "DNS_FORWARD"
    DNS_DYNAMIC = "DNS_DYNAMIC"
    FIREWALL = "FIREWALL"
    FIREWALL_IPV4 = "FIREWALL_IPV4"
    FIREWALL_IPV6 = "FIREWALL_IPV6"
    FIREWALL_ZONE = "FIREWALL_ZONE"
    FIREWALL_OPR = "FIREWALL_OPR"
    FIREWALL_OPR_GQL = "FIREWALL_OPR_GQL"
    FIREWALL_QUERY_GQL = "FIREWALL_QUERY_GQL"
    FIREWALL_OPR_LOG = "FIREWALL_OPR_LOG"   
    NAT = "NAT"
    NAT_STAT = "NAT_STAT"
    NAT_DESTINATION = "NAT_DESTINATION"
    NAT_SOURCE = "NAT_SOURCE"
    DHCP = "DHCP"
    DHCPV6 = "DHCPV6"
    DHCP_RELAY = "DHCP_RELAY"
    DHCP_POOL_LIST = "DHCP_POOL_LIST"
    DHCP_POOL_STATISTICS = "DHCP_POOL_STATISTICS"
    DHCPV6_POOL_LIST = "DHCPv6_POOL_LIST"
    DHCPV6_POOL_STATISTICS = "DHCPv6_POOL_STATISTICS"
    NTP = "NTP"
    NTP_SYSTEM = "NTP_SYSTEM"
    NTP_SOURCE = "NTP_SOURCE"
    INTERFACE_WIFI = "INTERFACE_WIFI"
    INTERFACE_WIFI_INFO = "INTERFACE_WIFI_INFO"
    INTERFACE_WIFI_STATION = "INTERFACE_WIFI_STATION"
    INTERFACE_WIFI_SCAN = "INTERFACE_WIFI_SCAN"
    INTERFACE_CELLULAR = "INTERFACE_CELLULAR"
    INTERFACE_ETHERNET = "INTERFACE_ETHERNET"
    ROUTER_ADVERTISEMENT = "ROUTER_ADVERTISEMENT"
    GENERAL_ROUTING = "GENERAL_ROUTING"
    GENERAL_ROUTING_V6 = "GENERAL_ROUTING_V6"
    GENERAL_ROUTING_MONITOR = "GENERAL_ROUTING_MONITOR"
    LOGIN = "LOGIN"
    USER = "USER"
    WIREGUARD_KEY_PAIR = "WIREGUARD_KEY_PAIR"
    SAML = "SAML"
    INTERFACE_WIREGUARD = "INTERFACE_WIREGUARD"
    

class API_RESOLVER():
    def __init__(self):
        self._actions = None

    def actions(self):
        from app.core.api.http.srv.system_performance import (
            fetch_ram as fetch_ram_http, 
            fetch_cpu as fetch_cpu_http
        )
        from app.core.api.http.srv.system_info import (
            fetch_system_info as fetch_system_info_http
        )
        # Import DNS services only when needed to avoid circular imports
        from app.core.network.dns.service import (
            fetch_dns_config as fetch_dns_config_http,
            fetch_dns_forward as fetch_dns_forward_http,
            fetch_dns_dynamic as fetch_dns_dynamic_http,
            fetch_dns_server as fetch_dns_server_http,
            delete_dns_server as delete_dns_server_http,
            create_dns_server as create_dns_server_http,
            update_dns_forward as update_dns_forward_http,
            update_dns_dynamic as update_dns_dynamic_http,
            update_dns as update_dns_http
        )
        from app.core.security.service.firewall import (
            fetch_firewall_config as fetch_firewall_config_http,
            fetch_firewall_opr as fetch_firewall_opr_http,
            fetch_firewall_opr_graphql as fetch_firewall_opr_graphql_http,
            fetch_firewall_query_graphql as fetch_firewall_query_graphql_http,
            fetch_firewall_opr_log as fetch_firewall_opr_log_http,
            update_firewall as update_firewall_http,
            verify_firewall as verify_firewall_http
        )

        from app.core.network.nat.service import (
            fetch_nat_config as fetch_nat_config_http,
            update_nat as update_nat_http,
            verify_nat as verify_nat_http,
            fetch_nat_stat as fetch_nat_stat_http,
            fetch_nat_destination_translation as fetch_nat_destination_translation_http,
            fetch_nat_source_translation as fetch_nat_source_translation_http
        )

        from app.core.api.http.srv.system_info import (
            fetch_datetime as fetch_datetime_http,
            update_system as update_system_http
        )

        from app.core.network.dhcp.service import (
            fetch_dhcp_config as fetch_dhcp_config_http,
            fetch_dhcpv6_config as fetch_dhcpv6_config_http,
            verify_dhcp as verify_dhcp_http,
            update_dhcp_config as update_dhcp_config_http,
            fetch_dhcp_relay_config as fetch_dhcp_relay_config_http,
            fetch_dhcp_pool_list as fetch_dhcp_pool_list_http,
            fetch_dhcp_statistics as fetch_dhcp_pool_statistics_http,
            fetch_dhcpv6_pool_list as fetch_dhcpv6_pool_list_http,
            fetch_dhcpv6_statistics as fetch_dhcpv6_pool_statistics_http,
            update_dhcp_relay as update_dhcp_relay_http,
            verify_dhcpv6 as verify_dhcpv6_http,
            update_dhcpv6_config as update_dhcpv6_config_http
        )

        from app.core.service.config import (
            fetch_os_config as fetch_os_config_http,
        )
            
        from app.core.api.http.srv.interface import fetch_interface_gql

        from app.core.api.http.srv.user_management import (
            fetch_user_config as fetch_user_config_http,
            update_user as update_user_http,
            verify_user as verify_user_http
        )

        from app.core.network.ntp.service import (
            fetch_ntp_config as fetch_ntp_config_http,
            verify_ntp as verify_ntp_http,
            update_ntp as update_ntp_http,
            fetch_ntp_system as fetch_ntp_system_http,
            fetch_ntp_source_gql as fetch_ntp_source_http,
            fetch_ntp_system_gql as fetch_ntp_system_gql_http
        )
        from app.core.operation.ethernet.service import (
            fetch_ethernet_config as fetch_ethernet_config_http
        )
        from app.core.operation.router_advert.service import (
            fetch_router_advertisement_config as fetch_router_advertisement_config_http
        )
        from app.core.api.http.srv.interface import (
            update_interface_by_name as update_interface_by_name_http
        )

        
        from app.core.api.http.srv.interface import (
            create_interface as create_interface_http,
            fetch_interface as fetch_interface_http,
            update_interface as update_interface_http,
            delete_interface as delete_interface_http,
            fetch_interface_config as fetch_interface_config_http,
            delete_interface_address as delete_interface_address_http,
            fetch_wifi_info as fetch_wifi_info_http,
            fetch_wifi_station as fetch_wifi_station_http,
            fetch_wifi_scan as fetch_wifi_scan_http,
            fetch_cellular_info as fetch_cellular_info_http,
            fetch_wireguard_info as fetch_wireguard_info_http
        )

        from app.core.routing.service import (
            update_general_routing as update_general_routing_http,
            fetch_general_routing_monitor as fetch_general_routing_monitor_http,
            verify_general_routing as verify_general_routing_http,
            fetch_general_routing as fetch_general_routing_http,
            fetch_general_routing_v6 as fetch_general_routing_v6_http
        )

        from app.core.api.http.srv.system_info import (
            fetch_datetime as fetch_datetime_http,
            update_system as update_system_http
        )

        from app.core.operation.wireguard.service import (
            create_wireguard_key_pair as create_wireguard_key_pair_http,
        )
        
        from app.core.login.service import (
            fetch_login_config as fetch_login_config_http,
            update_login_config as update_login_config_http
        )

        from app.core.login.saml.service import (
            auth_saml as auth_saml_http,
            fetch_saml_config as fetch_saml_config_http,
            update_saml_config as update_saml_config_http,
            verify_saml as verify_saml_http,
            fetch_saml_info as fetch_saml_info_http
        )
        
        self._actions = {
            API_ACTION.CREATE: {
                API_TARGET.INTERFACE: create_interface_http,
                API_TARGET.DNS_SERVER: create_dns_server_http,
                API_TARGET.WIREGUARD_KEY_PAIR: create_wireguard_key_pair_http,
            },
            API_ACTION.READ: {
                API_TARGET.OS_CONFIG: fetch_os_config_http,
                API_TARGET.INTERFACE: fetch_interface_gql,
                API_TARGET.INTERFACE_CONFIG: fetch_interface_config_http,
                API_TARGET.SYSTEM: fetch_system_info_http,
                API_TARGET.SYSTEM_CPU: fetch_cpu_http,
                API_TARGET.SYSTEM_MEMORY: fetch_ram_http,
                API_TARGET.SYSTEM_DATETIME: fetch_datetime_http,
                API_TARGET.DNS: fetch_dns_config_http,
                API_TARGET.DNS_SERVER: fetch_dns_server_http,
                API_TARGET.DNS_FORWARD: fetch_dns_forward_http,
                API_TARGET.DNS_DYNAMIC: fetch_dns_dynamic_http,
                API_TARGET.FIREWALL: fetch_firewall_config_http,
                API_TARGET.FIREWALL_OPR: fetch_firewall_opr_http,
                API_TARGET.FIREWALL_OPR_GQL: fetch_firewall_opr_graphql_http,
                API_TARGET.FIREWALL_QUERY_GQL: fetch_firewall_query_graphql_http,
                API_TARGET.FIREWALL_OPR_LOG: fetch_firewall_opr_log_http,
                API_TARGET.NAT: fetch_nat_config_http,
                API_TARGET.NAT_STAT: fetch_nat_stat_http,
                API_TARGET.NAT_DESTINATION: fetch_nat_destination_translation_http,
                API_TARGET.NAT_SOURCE: fetch_nat_source_translation_http,
                API_TARGET.DHCP: fetch_dhcp_config_http,
                API_TARGET.DHCPV6: fetch_dhcpv6_config_http,
                API_TARGET.DHCP_RELAY: fetch_dhcp_relay_config_http,
                API_TARGET.DHCP_POOL_LIST: fetch_dhcp_pool_list_http,
                API_TARGET.DHCP_POOL_STATISTICS: fetch_dhcp_pool_statistics_http,
                API_TARGET.DHCPV6_POOL_LIST: fetch_dhcpv6_pool_list_http,
                API_TARGET.DHCPV6_POOL_STATISTICS: fetch_dhcpv6_pool_statistics_http,
                API_TARGET.NTP: fetch_ntp_config_http,
                API_TARGET.NTP_SYSTEM: fetch_ntp_system_gql_http,
                API_TARGET.NTP_SOURCE: fetch_ntp_source_http,
                API_TARGET.INTERFACE_ETHERNET: fetch_ethernet_config_http,
                API_TARGET.ROUTER_ADVERTISEMENT: fetch_router_advertisement_config_http,
                API_TARGET.INTERFACE_WIFI_INFO: fetch_wifi_info_http,
                API_TARGET.INTERFACE_WIFI_STATION: fetch_wifi_station_http,
                API_TARGET.INTERFACE_WIFI_SCAN: fetch_wifi_scan_http,
                API_TARGET.GENERAL_ROUTING_MONITOR: fetch_general_routing_monitor_http,
                API_TARGET.GENERAL_ROUTING: fetch_general_routing_http,
                API_TARGET.GENERAL_ROUTING_V6: fetch_general_routing_v6_http,
                API_TARGET.LOGIN: fetch_login_config_http,
                API_TARGET.USER: fetch_user_config_http,
                API_TARGET.SAML: fetch_saml_config_http
            },
            API_ACTION.UPDATE: {
                API_TARGET.INTERFACE: update_interface_http,
                API_TARGET.INTERFACE_BY_NAME: update_interface_by_name_http,
                API_TARGET.DNS_FORWARD: update_dns_forward_http,
                API_TARGET.DNS_DYNAMIC: update_dns_dynamic_http,
                API_TARGET.DNS: update_dns_http,
                API_TARGET.FIREWALL: update_firewall_http,
                API_TARGET.NAT: update_nat_http,
                API_TARGET.SYSTEM: update_system_http,
                API_TARGET.DHCP: update_dhcp_config_http,
                API_TARGET.DHCP_RELAY: update_dhcp_relay_http,
                API_TARGET.DHCPV6: update_dhcpv6_config_http,
                API_TARGET.NTP: update_ntp_http,
                API_TARGET.GENERAL_ROUTING: update_general_routing_http,
                API_TARGET.LOGIN: update_login_config_http,
                API_TARGET.USER: update_user_http,
                API_TARGET.SAML: update_saml_config_http
            },
            API_ACTION.DELETE: {
                API_TARGET.INTERFACE: delete_interface_http,
                API_TARGET.INTERFACE_ADDRESS: delete_interface_address_http,
                API_TARGET.DNS_SERVER: delete_dns_server_http,
            },
            API_ACTION.VERIFY: {
                API_TARGET.FIREWALL: verify_firewall_http,
                API_TARGET.NAT: verify_nat_http,
                API_TARGET.DHCP: verify_dhcp_http,
                API_TARGET.DHCPV6: verify_dhcpv6_http,
                API_TARGET.NTP: verify_ntp_http,
                API_TARGET.GENERAL_ROUTING: verify_general_routing_http,
                API_TARGET.USER: verify_user_http,
                API_TARGET.SAML: verify_saml_http
            },
            API_ACTION.MONITOR: {
                API_TARGET.INTERFACE_CELLULAR: fetch_cellular_info_http,
                API_TARGET.INTERFACE_WIREGUARD: fetch_wireguard_info_http,
                API_TARGET.SAML: fetch_saml_info_http
            },
            API_ACTION.AUTH: {
                API_TARGET.SAML: auth_saml_http
            }
        }
        return self._actions
