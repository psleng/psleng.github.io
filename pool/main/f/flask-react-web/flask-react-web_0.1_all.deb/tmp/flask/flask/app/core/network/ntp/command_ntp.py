from typing import List, Dict, Any
from app.core.api.http.cmd.command import Command
from app.log.logger import logger

class NTPCommand(Command):
    
    """
    Class for generating NTP commands. Support the following commands:
        Set/delete service ntp server <ip-address>
        Set/delete service ntp server <ip-address> interleave
        Set/delete service ntp server <ip-address> noselect
        Set/delete service ntp server <ip-address> nts
        Set/delete service ntp server <ip-address> pool
        Set/delete service ntp server <ip-address> ptp
        Set/delete service ntp listen-address <ip-address>
        Set/delete service ntp allow-client address <ip-address>
        Set/delete service ntp interface <interface-name>
        Set/delete service ntp leap-second <ignore|smear|system|timezone>
        Set/delete service ntp ptp
        Set/delete service ntp ptp port <port-number>
        Set/delete service ntp ptp timestamp interface <interface-name>
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'ntp'))
            self.attributes = {
                'servers': {},
                'listen_addresses': [],
                'allow_clients': [],
                'interfaces': [],
                'leap_second': None,
                'ptp': {
                    'enabled': False,
                    'port': None,
                    'timestamp_interfaces': []
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing NTP command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        if args:
            last_arg = args[-1]
            if last_arg != "all":
                self.cmds.append(self._build_command(*args))
            else:
                self.cmds.append(self._build_command(*args[:-1]))
            self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def _process_server(self, server_addr: str, server_config: Dict[str, Dict], current_config: Dict[str, Dict], new_config: Dict[str, Dict]):
        base = ['service', 'ntp', 'server', server_addr]
        
        if self.operator == 'set' and len(server_config.keys()) == 0:
            self.generate(*base)
        
        if server_config.get('interleave') is not None:
            self.generate(*base, 'interleave')
        
        if server_config.get('noselect') is not None:
            self.generate(*base, 'noselect')
        
        if server_config.get('nts') is not None:
            self.generate(*base, 'nts')
        
        if server_config.get('pool') is not None:
            self.generate(*base, 'pool')
        
        if server_config.get('ptp') is not None:
            self.generate(*base, 'ptp')

        if self.operator == 'delete':
            if server_config == current_config['server'][server_addr]:
                self.generate(*base, 'all')

    def _process_listen_address(self, address: str):
        self.generate('service', 'ntp', 'listen-address', address)

    def _process_allow_clients(self, allow_clients: List[str]):
        for client in allow_clients:
            self.generate('service', 'ntp', 'allow-client', 'address', client)

    def _process_interface(self, interface: str):
        self.generate('service', 'ntp', 'interface', interface)

    def _process_leap_second(self, leap_second: str):
        if leap_second in ['ignore', 'smear', 'system', 'timezone']:
            self.generate('service', 'ntp', 'leap-second', leap_second)

    def _process_ptp(self, ptp_config: Dict[str, Any]):
            
        if ptp_config.get('port'):
            self.generate('service', 'ntp', 'ptp', 'port', ptp_config['port'])
        
        if ptp_config.get('timestamp_interfaces'):
            for interface in ptp_config['timestamp_interfaces']:
                self.generate('service', 'ntp', 'ptp', 'timestamp', 'interface', interface)
        
        if ptp_config.get('timestamp-interface'):
            if isinstance(ptp_config['timestamp-interface'], list):
                for interface in ptp_config['timestamp-interface']:
                    self.generate('service', 'ntp', 'ptp', 'timestamp', 'interface', interface)
            else:
                self.generate('service', 'ntp', 'ptp', 'timestamp', 'interface', ptp_config['timestamp-interface'])

    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            config_data = data if data is not None else self.attributes
            logger.debug("Processing servers: ")
            if 'server' in config_data:
                for server_ip, server_config in config_data['server'].items():
                    self._process_server(server_ip, server_config, current_config, new_config)
            logger.debug("Finished processing servers: ")
            
            if 'listen-address' in config_data:
                self._process_listen_address(config_data['listen-address'])
            
            if 'allow-client' in config_data and 'address' in config_data['allow-client']:
                self._process_allow_clients(config_data['allow-client']['address'])
            
            if 'interface' in config_data:
                self._process_interface(config_data['interface'])
            
            if 'leap-second' in config_data and config_data['leap-second']:
                self._process_leap_second(config_data['leap-second'])
            
            if 'ptp' in config_data:
                self._process_ptp(config_data['ptp'])
            
            return self.cmds
        except Exception as e:
            print(f"Error generating NTP commands: {e}")
            return []

if __name__ == "__main__":
    ntp_config = {
        'server': {
            '0.pool.ntp.org': {
                'pool': True
            },
            '1.pool.ntp.org': {
                'pool': True,
                'noselect': True
            },
            '2.pool.ntp.org': {
                'pool': True
            },
            '192.168.1.254': {
                'interleave': True
            }
        },
        'listen-address': ['192.168.1.1', '10.0.0.1'],
        'allow-client': ['192.168.1.0/24', '10.0.0.0/24'],
        'interface': ['eth0', 'eth1'],
        'leap-second': 'system',
        'ptp': {
            'enabled': True,
            'port': 319,
            'timestamp_interfaces': ['eth0']
        }
    }
    
    ntp_cmd = NTPCommand(operator='set')
    
    commands = ntp_cmd.generate_commands(ntp_config)
    
    print("Generated NTP Commands:")
    for cmd in commands:
        print(f"  {cmd}")
    
    ntp_cmd_delete = NTPCommand(operator='delete')
    delete_commands = ntp_cmd_delete.generate_commands(ntp_config)
    
    print("\nDelete NTP Commands:")
    for cmd in delete_commands:
        print(f"  {cmd}")
    
    single_server_config = {
        'server': {
            'time.nist.gov': {
                'nts': True
            }
        }
    }
    
    ntp_cmd_single = NTPCommand(operator='set')
    single_commands = ntp_cmd_single.generate_commands(single_server_config)
    
    print("\nSingle Server NTP Commands:")
    for cmd in single_commands:
        print(f"  {cmd}")
