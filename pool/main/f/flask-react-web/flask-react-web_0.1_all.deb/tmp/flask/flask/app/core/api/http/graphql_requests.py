import os
from dataclasses import dataclass
from enum import Enum, StrEnum
import requests
from typing import overload
import json
from app.core.api.api import API_REQUEST
from dotenv import load_dotenv
from app.log.logger import logger

class GraphqlRequest(API_REQUEST):

    def __init__(self, hostname=None, apikey=None, port=None, protocol=None):
        super().__init__()
        load_dotenv()
        self.url = None
        if hostname and apikey and port and protocol:
            self.hostname = hostname
            self.apikey = apikey 
            self.port = port
            self.protocol = protocol
        else:
            self.hostname = os.environ.get("VYOS_HOSTNAME")
            self.apikey = os.environ.get("VYOS_APIKEY")
            self.port = os.environ.get("VYOS_PORT") 
            self.protocol = os.environ.get("VYOS_PROTOCOL")
        self.set_url(protocol=self.protocol, hostname=self.hostname, port=self.port)

    def __enter__(self):
        logger.log("Entering the context")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        logger.log("Exiting the context")
        return False
        
    def set_url(self, protocol, hostname, port):
        self.url = f"{protocol}://{hostname}:{port}/graphql"

    def send_request(self, function_name, data, verify: bool):
        data_str = f'key: "{self.apikey}"'
        
        if data:
            if isinstance(data, str):
                data_str += f", {data}"
            elif isinstance(data, dict):
                data_str += ", " + ", ".join(f"{k}: {v}" for k, v in data.items())
        
        payload = {
            "query": "{ " + function_name + f" (data: {{ {data_str} }}) " + "{ success errors data { result } } }"
        }
        headers = {}

        response = requests.post(
            url=self.url,
            headers=headers,
            json=payload,
            verify=verify
        )

        logger.log("URL: ")
        logger.log(self.url)
        logger.log("Payload: ")
        logger.log( payload)
        logger.log("Status Code: ")
        logger.log( response.status_code)
        # logger.log("Response: ")
        # logger.log(pprint.pformat( response.json()['data'], indent=2, width=80))
        
        return response

    def send_str_request(self, function_name, data, verify):
        
        data_str = f'key: "{self.apikey}", {data}'
        
        payload = {
            "query": "{ " + function_name + f" (data: {{ {data_str} }}) " + "{ success errors data { result } } }"
        }

        response = requests.post(
            url=self.url,
            headers={},
            json=payload,
            verify=verify
        )

        logger.log("URL: ")
        logger.log(self.url)
        logger.log("Payload: ")
        logger.log( payload)
        logger.log("Status Code: ")
        logger.log( response.status_code)

        return response

if __name__ == "__main__":
    req = GraphqlRequest(hostname="localhost", apikey="mykey", protocol="https", port=443)
    res = req.send_request(function_name='ShowRulesNat', data="direction: source, family: inet", verify=False)
    print(res.json())
