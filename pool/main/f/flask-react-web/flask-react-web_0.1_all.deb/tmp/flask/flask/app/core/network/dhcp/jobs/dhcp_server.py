from logging import getLogger, DEBUG
from app.core.network.dhcp.models import DHCPPool, DHCPPoolv6, DHCPListenInterface, DHCPListenInterfacev6
from app.core.models import ServiceState
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
import pprint
from app.core.network.dhcp.parser import parse_to_dhcp_config, parse_dhcp_config

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_dhcp_job(app_context):
    """Job to fetch DHCP server information and update the database.
    
    Args:
        app_context: Flask application context
    """
    try:
        refresh_db_dhcp(app_context=app_context)
    except Exception as e:
        print('Error fetch dhcp server', str(e))


def refresh_db_dhcp(app_context=None):
    try: 
        logger.info("[TASK] Fetch DHCP Servers")
        print("[TASK] Fetch DHCP Servers")
        dhcp_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP)
        print("Unparsed DHCP config:")
        print(pprint.pformat(dhcp_config, indent=2, width=80))
        parsed_dhcp_config = parse_dhcp_config({"dhcp": dhcp_config})
        print("Parsed DHCP config:")
        print(pprint.pformat(parsed_dhcp_config, indent=2, width=80))
        if app_context is not None:
            with app_context:
                DHCPPool.refresh(parsed_dhcp_config)
                DHCPListenInterface.refresh(parsed_dhcp_config)
                if 'disable' in parsed_dhcp_config['dhcp'] and (
                        parsed_dhcp_config['dhcp']['disable'] == True or parsed_dhcp_config['dhcp']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcp'] and parsed_dhcp_config['dhcp']['disable'] == False) or (
                        'disable' not in parsed_dhcp_config['dhcp']):
                    ServiceState.set_state('dhcp_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcp']:
                    ServiceState.set_state('dhcp_server', "enable")
        else:
            DHCPPool.refresh(parsed_dhcp_config)
            DHCPListenInterface.refresh(parsed_dhcp_config)
            if 'disable' in parsed_dhcp_config['dhcp'] and (
                        parsed_dhcp_config['dhcp']['disable'] == True or parsed_dhcp_config['dhcp']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
            elif ('disable' in parsed_dhcp_config['dhcp'] and parsed_dhcp_config['dhcp']['disable'] == False) or (
                    'disable' not in parsed_dhcp_config['dhcp']):
                ServiceState.set_state('dhcp_server', "enable")
            elif 'disable' not in parsed_dhcp_config['dhcp']:
                ServiceState.set_state('dhcp_server', "enable")
        return dhcp_config
    except Exception as e:
        print(str(e))


def fetch_dhcpv6_job(app_context):
    """Job to fetch DHCPv6 server information and update the database.
    
    Args:
        app_context: Flask application context
    """
    try:
        refresh_db_dhcpv6(app_context=app_context)
    except Exception as e:
        print('Error fetch dhcpv6 server', str(e))


def refresh_db_dhcpv6(app_context=None):
    try: 
        logger.info("[TASK] Fetch DHCPv6 Servers")
        print("[TASK] Fetch DHCPv6 Servers")
        dhcp_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6)
        print("Unparsed DHCPv6 config:")
        print(pprint.pformat(dhcp_config, indent=2, width=80))
        parsed_dhcp_config = parse_dhcp_config({"dhcpv6": dhcp_config})
        print("Parsed DHCPv6 config:")
        print(pprint.pformat(parsed_dhcp_config, indent=2, width=80))
        if app_context is not None:
            with app_context:
                DHCPPoolv6.refresh(parsed_dhcp_config)
                DHCPListenInterfacev6.refresh(parsed_dhcp_config)
                if 'disable' in parsed_dhcp_config['dhcpv6'] and (
                        parsed_dhcp_config['dhcpv6']['disable'] == True or parsed_dhcp_config['dhcpv6']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcpv6'] and parsed_dhcp_config['dhcpv6']['disable'] == False) or (
                        'disable' not in parsed_dhcp_config['dhcpv6']):
                    ServiceState.set_state('dhcp_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcpv6']:
                    ServiceState.set_state('dhcp_server', "enable")
        else:
            DHCPPoolv6.refresh(parsed_dhcp_config)
            DHCPListenInterfacev6.refresh(parsed_dhcp_config)
            if 'disable' in parsed_dhcp_config['dhcpv6'] and (
                        parsed_dhcp_config['dhcpv6']['disable'] == True or parsed_dhcp_config['dhcpv6']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
            elif ('disable' in parsed_dhcp_config['dhcpv6'] and parsed_dhcp_config['dhcpv6']['disable'] == False) or (
                    'disable' not in parsed_dhcp_config['dhcpv6']):
                ServiceState.set_state('dhcp_server', "enable")
            elif 'disable' not in parsed_dhcp_config['dhcpv6']:
                ServiceState.set_state('dhcp_server', "enable")
        return dhcp_config
    except Exception as e:
        print(str(e))