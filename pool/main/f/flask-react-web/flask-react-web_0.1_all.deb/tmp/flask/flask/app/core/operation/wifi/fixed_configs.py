fixed_wifi_configs = {
    "fixed_configs": {
        "interfaces": {
            "wireless": {
                "wlan0": {
                    "capabilities": {
                        "ht": {
                            "channel-set-width": [
                                "ht40+",
                                "ht40-",
                                "ht20"
                            ],
                            "ldpc": {},
                            "short-gi": [
                                "20",
                                "40"
                            ],
                            "stbc": {
                                "rx": "1",
                                "tx": {}
                            }
                        },
                        "vht": {
                            "antenna-count": "3",
                            "antenna-pattern-fixed": {},
                            "center-channel-freq": {},
                            "channel-set-width": "1",
                            "ldpc": {},
                            "short-gi": [
                                "80"
                            ],
                            "stbc": {
                                "rx": "1",
                                "tx": {}
                            }
                        }
                    },
                    "channel": "0",
                    "security": {
                        "wpa": {
                            "cipher": [
                                "CCMP-256",
                                "GCMP",
                                "CCMP",
                                "GCMP-256",
                                "TKIP"
                            ],
                            "mode": "wpa+wpa2",
                        }
                    },
                    "max-stations": "16",
                    "mode": "ac",
                    "stationary-ap": {},
                    "isolate-stations": {},
                    "type": "access-point",
                },
                "wlan1": {
                    "capabilities": {
                        "ht": {
                            "channel-set-width": [
                                "ht40+",
                                "ht40-",
                                "ht20"
                            ],
                            "ldpc": {},
                            "short-gi": [
                                "20",
                                "40"
                            ],
                            "stbc": {
                                "rx": "1",
                                "tx": {}
                            }
                        },
                        "vht": {
                            "antenna-count": "3",
                            "antenna-pattern-fixed": {},
                            "center-channel-freq": {},
                            "channel-set-width": "1",
                            "ldpc": {},
                            "short-gi": [
                                "80"
                            ],
                            "stbc": {
                                "rx": "1",
                                "tx": {}
                            }
                        }
                    },
                    "channel": "0",
                    "security": {
                        "wpa": {
                            "cipher": [
                                "CCMP-256",
                                "GCMP",
                                "CCMP",
                                "GCMP-256",
                                "TKIP"
                            ],
                            "mode": "wpa+wpa2",
                        }
                    },
                    "max-stations": "16",
                    "mode": "n",
                    "stationary-ap": {},
                    "isolate-stations": {},
                    "physical-device": "phy1",
                    "type": "access-point",
                },
                "wlan2": {
                    "type": "station",
                    "mode": "ac"
                },
                "wlan3": {
                    "type": "station",
                    "mode": "n",
                    "physical-device": "phy1"
                }
            }
        }
    }
}