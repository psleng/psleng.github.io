import json
import pprint

def parse_dhcp_relay_config(data):
    """
    Parse DHCP relay configuration.
    Sample input:
    { 'listen_interface': ['eth1', 'br1'],
                  'relay_options': { 'hop_count': '20',
                                     'max_size': '1400',
                                     'relay_agents_packets': 'forward'},
                  'server': ['1.1.1.1', '127.0.0.1'],
                  'upstream_interface': ['br3']}}

    """
    if not data:
        return {}
    
    listen_interfaces = data.get('listen_interface', data.get('listen-interface', []))
    upstream_interfaces = data.get('upstream_interface', data.get('upstream-interface', []))
    servers = data.get('server', [])
    disable = data.get('disable', False)
    
    relay_options = data.get('relay_options', data.get('relay-options', {}))
    relay_agent_packet = None
    hop_count = None
    max_packet_size = None
    
    if relay_options:
        relay_agent_packet = relay_options.get('relay_agents_packets', 
                                              relay_options.get('relay-agents-packets'))
        hop_count = relay_options.get('hop_count', relay_options.get('hop-count'))
        max_packet_size = relay_options.get('max_size', relay_options.get('max-size'))
    
    listen_interface_str = ','.join(listen_interfaces) if isinstance(listen_interfaces, list) else listen_interfaces
    upstream_interface_str = ','.join(upstream_interfaces) if isinstance(upstream_interfaces, list) else upstream_interfaces
    servers_str = ','.join(servers) if isinstance(servers, list) else servers
    
    relay_entry = {
        'relay_agent_packet': relay_agent_packet,
        'hop_count': hop_count,
        'max_packet_size': max_packet_size,
        'listen_interface': listen_interface_str,
        'upstream_interface': upstream_interface_str,
        'disable': disable,
        'relay_servers': servers_str
    }
    
    return relay_entry


# def parse_dhcp_config(data):
#     """
#     Parse DHCP configuration.
#     """
#     print(data['service'])

#     r = {"dhcp": {}, "dhcpv6": {}}
#     if 'service' not in data:
#         return r
#     if 'dhcp-server' in data['service']:
#         r['dhcp'] = data['service']['dhcp-server']
#     if 'dhcpv6-server' in data['service']:
#         r['dhcpv6'] = data['service']['dhcpv6-server']
#     return r

def parse_dhcp_stat(data):
    """
    Parse DHCP statistics.
    Sample input: 
    
    { 'ShowServerPoolStatisticsDhcp': { 'data': { 'result': [ { 'available': 100,
                                                      'leases': 1,
                                                      'pool': 'dhcp1',
                                                      'size': 101,
                                                      'subnet': [ '192.168.1.0/24'],
                                                      'use_percentage': 1},
                                                    { 'available': 1,
                                                      'leases': 0,
                                                      'pool': 'dhcp2',
                                                      'size': 1,
                                                      'subnet': [ '192.168.10.0/24'],
                                                      'use_percentage': 0}]},
                              'errors': None,
                              'success': True}}
    """
    try:
        if not data:
            return []
        result = []
        if 'ShowServerPoolStatisticsDhcp' in data:
            result = data['ShowServerPoolStatisticsDhcp']['data']['result']
        elif 'ShowPoolStatisticsDhcp' in data:
            result = data['ShowPoolStatisticsDhcp']['data']['result']
        
        if not result or not isinstance(result, list):
            return []
        # print("Parsing dhcp stat: ")
        # print(result)
        stats = []
        for pool_stat in result:
            # Format numbers with commas for better readability
            available = pool_stat.get('available', 0)
            size = pool_stat.get('size', 0)
            
            stat = {
                'pool_name': pool_stat.get('pool', ''),
                'available': f"{available:,}",
                'leases': pool_stat.get('leases', 0),
                'size': f"{size:,}",
                'subnet': ', '.join(pool_stat.get('subnet', [])) if isinstance(pool_stat.get('subnet', []), list) else '',
                'usage_percentage': pool_stat.get('use_percentage', 0)
            }
            stats.append(stat)
        
        return stats
    except Exception as e:
        print(f"Error parsing DHCP statistics: {str(e)}")
        return []

def parse_to_single_dhcp_pool(data):
    """
    Parse single DHCP pool
    Sample input:
    {
        'description': 'This is a description',
        'dhcp_name': 'dhcp1',
        'dhcp_type': 'dhcp',
        'enabled': True,
        'interface': None,
        'lease_time': '',
        'range_end': '192.168.1.200',
        'range_start': '192.168.1.10',
        'subnet': '192.168.1.0/24',
        'domain_name': '',
        'default_router': '',
        'name_server': '',
        'subnet_id': '1',
        'name_servers': [],
        'nis_domain': '',
        'nis_servers': [],
        'nisp_domain': '',
        'nisp_servers': [],
        'sip_servers': [],
        'sntp_servers': []
    }

    """
    return process_network_config(data, 'dhcp')

def parse_dhcp_pool(data):
    """
    Parse DHCP pool.
    Sample input:

    { 'ShowServerLeasesDhcp': { 'data': { 'result': [ { 'end': 1741740901.0,
                                                    'hostname': 'eng-dn24.',
                                                    'ip': '192.168.1.100',
                                                    'mac': 'd0:46:0c:b0:9a:7b',
                                                    'origin': 'local',
                                                    'pool': 'dhcp1',
                                                    'remaining': '8:16:22',
                                                    'start': 1741654501.0,
                                                    'state': 'active'}]},
                            'errors': None,
                            'success': True}}
    """
    try:
        if not data or 'ShowServerLeasesDhcp' not in data:
            return []
        
        result = data['ShowServerLeasesDhcp']['data']['result']
        if not result or not isinstance(result, list):
            return []
        
        leases = []
        for lease in result:
            lease_info = {
                'ip_address': lease.get('ip', ''),
                'mac_address': lease.get('mac', ''),
                'hostname': lease.get('hostname', '').rstrip('.'),
                'pool': lease.get('pool', ''),
                'state': lease.get('state', ''),
                'remaining_time': lease.get('remaining', ''),
                'start_time': lease.get('start', 0),
                'end_time': lease.get('end', 0),
                'origin': lease.get('origin', '')
            }
            leases.append(lease_info)
        
        return leases
    except Exception as e:
        print(f"Error parsing DHCP pool: {str(e)}")
        return []

def parse_to_dhcp_config(data):
    """
    Transforms the input DHCP configuration data to the format required by VyOS.
    
    Input format:
    {
        'dhcp': {
            'listen_interface': [],
            'pools': [
                {
                    'description': 'This is a description',
                    'dhcp_name': 'dhcp1',
                    'dhcp_type': 'dhcp',
                    'enabled': True,
                    'interface': None,
                    'lease_time': '',
                    'range_end': '192.168.1.200',
                    'range_start': '192.168.1.10',
                    'subnet': '192.168.1.0/24',
                    'domain_name': '',
                    'default_router': '',
                    'name_server': '',
                    'subnet_id': '1',
                    'name_servers': [],
                    'nis_domain': '',
                    'nis_servers': [],
                    'nisp_domain': '',
                    'nisp_servers': [],
                    'sip_servers': [],
                    'sntp_servers': []
                }
            ]
        },
        'dhcpv6': {
            'listen_interface': [],
            'pools': []
        },
        "dhcpRelays":{
            "disable":false,
            "hop_count":"20",
            "id":1,
            "listen_interface":[
                "eth1",
                "br1"
            ],
            "max_packet_size":"1400",
            "relay_agent_packet":"forward",
            "relay_servers":[
                "1.1.1.1",
                "127.0.0.1"
            ],
            "upstream_interface":[
                "br3"
            ]
        }
    }
    
    Output format:
    {
        "dhcp": {
            "listen-interface": [],
            "shared-network-name": {
                "dhcp1": {
                    "disable": {},
                    "subnet": {
                        "192.168.1.0/24": {
                            "lease": "86400",
                            "range": {
                                "range_1": {
                                    "start": "192.168.1.10",
                                    "stop": "192.168.1.200"
                                }
                            },
                            "subnet_id": "1"
                        }
                    },
                    "option": {
                        "domain-name": "",
                        "default-router": "",
                        "name-server": ""
                    }
                }
            }
        },
        "dhcpv6": {},
        "dhcpRelays": {
            "listen_interface": [],
            "relay_options": {
                "hop_count": "20",
                "max_size": "1400",
                "relay_agents_packets": "forward"
            },
            "server": [],
            "upstream_interface": []
        }
    }
    """
    result = {
        "dhcp": {
            "shared_network_name": {}
        },
        "dhcpv6": {},
        "dhcp_relay": {}
    }
    
    # If there's no data or it's not a dict, return the empty structure
    if not data or not isinstance(data, dict):
        return result
    
    # Check if the data is in the new format with pools
    if 'dhcp' in data and isinstance(data['dhcp'], dict) and 'pools' in data['dhcp']:
        
        if 'disabled' in data['dhcp'] and data['dhcp']['disabled'] == True:
            result['dhcp']['disable'] = {}
        # Process DHCP pools
        if 'listen_interface' in data['dhcp']:
            result['dhcp']['listen_interface'] = data['dhcp']['listen_interface']
        
        for pool in data['dhcp']['pools']:
            process_pool(pool, result, 'dhcp')
        
    # Process DHCPv6 pools if they exist
    if 'dhcpv6' in data and isinstance(data['dhcpv6'], dict) and 'pools' in data['dhcpv6']:
        
        if 'disabled' in data['dhcpv6'] and data['dhcpv6']['disabled'] == True:
            result['dhcpv6']['disable'] = {}
        
        if 'listen_interface' in data['dhcpv6']:
            result['dhcpv6']['listen_interface'] = data['dhcpv6']['listen_interface']
        
        for pool in data['dhcpv6']['pools']:
            process_pool(pool, result, 'dhcpv6')
    
    # Process DHCP Relay configuration if it exists
    if 'dhcpRelays' in data and isinstance(data['dhcpRelays'], dict):
        relay_data = data['dhcpRelays']
        
        # Handle disable flag
        if 'disable' in relay_data and relay_data['disable'] == True:
            result['dhcp_relay']['disable'] = {}
        
        # Process listen interfaces
        if 'listen_interface' in relay_data and isinstance(relay_data['listen_interface'], list):
            result['dhcp_relay']['listen_interface'] = relay_data['listen_interface']
        
        # Process upstream interfaces
        if 'upstream_interface' in relay_data and isinstance(relay_data['upstream_interface'], list):
            result['dhcp_relay']['upstream_interface'] = relay_data['upstream_interface']
        
        # Process relay servers
        if 'relay_servers' in relay_data and isinstance(relay_data['relay_servers'], list):
            result['dhcp_relay']['server'] = relay_data['relay_servers']
        
        # Process relay options
        relay_options = {}
        
        if 'hop_count' in relay_data:
            relay_options['hop_count'] = str(relay_data['hop_count'])
        
        if 'max_packet_size' in relay_data:
            relay_options['max_size'] = str(relay_data['max_packet_size'])
        
        if 'relay_agent_packet' in relay_data:
            relay_options['relay_agents_packets'] = relay_data['relay_agent_packet']
        
        if relay_options:
            result['dhcp_relay']['relay_options'] = relay_options
    
    return result

def process_network_config(pool_data, dhcp_type):
    """
        Helper function to process network config
    """
    if not pool_data or not isinstance(pool_data, dict):
        return {}
    
    # Extract values from pool data
    dhcp_name = pool_data.get('dhcp_name', '')
    subnet = pool_data.get('subnet', '')
    range_start = pool_data.get('range_start', '')
    range_end = pool_data.get('range_end', '')
    lease_time = pool_data.get('lease_time', '86400')
    enabled = pool_data.get('enabled', True)
    subnet_id = pool_data.get('subnet_id')
    authoritative = pool_data.get('authoritative')
    boot_file = pool_data.get('boot_file', '')
    
    description = ''
    if 'description' in pool_data:
        description = pool_data['description']
        if isinstance(description, (list, tuple)):
            description = ' '.join(description)
        elif not isinstance(description, str):
            description = str(description) if description is not None else ''
    
    default_router = pool_data.get('default_router', '')
    name_server = pool_data.get('name_server', '')
    domain_name = pool_data.get('domain_name', '')
    
    name_servers = pool_data.get('name_servers', [])
    nis_domain = pool_data.get('nis_domain', '')
    nis_servers = pool_data.get('nis_servers', [])
    nisp_domain = pool_data.get('nisp_domain', '')
    nisp_servers = pool_data.get('nisp_servers', [])
    sip_servers = pool_data.get('sip_servers', [])
    sntp_servers = pool_data.get('sntp_servers', [])
    range_prefix = pool_data.get('range_prefix', '')
    range_prefix_length = pool_data.get('range_prefix_length', '')
    ip_range_type = pool_data.get('ip_range_type', '')
    interface = pool_data.get('interface', None)
    
    if not dhcp_name or not range_start or not range_end:
        if dhcp_type == 'dhcpv6' and range_prefix and range_prefix_length:
            pass
        else:
            return
    
    # Use a default subnet if not provided
    if not subnet:
        # Try to derive subnet from range_start if possible
        ip_parts = range_start.split('.')
        if len(ip_parts) == 4:
            subnet = f"{ip_parts[0]}.{ip_parts[1]}.{ip_parts[2]}.0/24"
        else:
            return  # Can't create a valid configuration without subnet
    
    # Build the network configuration
    network_config = {
        "subnet": {
            subnet: {
                "lease": str(lease_time) if str(lease_time) != "" else '86400',
                "range": {
                    "range_1": {
                        "start": range_start,
                        "stop": range_end
                    }
                },
                "subnet_id": str(subnet_id),
            }
        },
        "description": description,
        "option": {
            "bootfile_name": boot_file
        },
    }

    if interface:
        network_config["interface"] = interface
    
    if authoritative is True:
        network_config["authoritative"] = {}
    
    if dhcp_type == 'dhcpv6' and range_prefix and range_prefix_length and ip_range_type == 'prefix_length':
        network_config["subnet"][subnet]["prefix"] = {
            "prefix_1": {
                "prefix": range_prefix,
                "length": range_prefix_length
            }
        }
        # Remove range if using prefix/length
        if 'range_start' in network_config["subnet"][subnet]:
            del network_config["subnet"][subnet]["range_start"]
        if 'range_end' in network_config["subnet"][subnet]:
            del network_config["subnet"][subnet]["range_end"]
    
    options = {}
    if default_router:
        options["default_router"] = default_router
    if name_server:
        options["name_server"] = name_server
    if domain_name:
        options["domain_name"] = domain_name
    
    # Other dhcpv6 advanced options
    if dhcp_type == 'dhcpv6':
        if name_servers and isinstance(name_servers, list) and len(name_servers) > 0:
            options["name_server"] = name_servers
        if nis_domain:
            options["nis_domain"] = nis_domain
        if nis_servers and isinstance(nis_servers, list) and len(nis_servers) > 0:
            options["nis_server"] = nis_servers
        if nisp_domain:
            options["nisplus_domain"] = nisp_domain
        if nisp_servers and isinstance(nisp_servers, list) and len(nisp_servers) > 0:
            options["nisplus_server"] = nisp_servers
        if sip_servers and isinstance(sip_servers, list) and len(sip_servers) > 0:
            options["sip_server"] = sip_servers
        if sntp_servers and isinstance(sntp_servers, list) and len(sntp_servers) > 0:
            options["sntp_server"] = sntp_servers
    
    if options:
        network_config["subnet"][subnet]["option"] = options
    
    if not enabled:
        network_config["disable"] = {}

    return network_config


def process_pool(pool_data, result, dhcp_type):
    """Helper function to process a single DHCP pool"""
    # Skip if essential data is missing
    if not pool_data or not isinstance(pool_data, dict):
        return
    
    dhcp_name = pool_data.get('dhcp_name', '')
    network_config = process_network_config(pool_data, dhcp_type)
    
    if "shared_network_name" not in result[dhcp_type]:
        result[dhcp_type]["shared_network_name"] = {}
    
    result[dhcp_type]["shared_network_name"][dhcp_name] = network_config


def parse_dhcp_config(data):
    """
    Parse DHCP configuration from VyOS format to the application format.
    
    Input can have either hyphenated keys (listen-interface) or underscore keys (listen_interface):
    {
        'dhcp': {
            'listen_interface': ['eth1', 'eth2'],
            'shared_network_name': {
                'dhcp1': {
                    'subnet': {
                        '192.168.1.0/24': {
                            'lease': '86400',
                            'option': { 'default-router': '192.168.1.1',
                                        'name-server': '192.168.1.1'},
                            'range': { 'range_1': { 'start': '192.168.1.1',
                                                    'stop': '192.168.1.254'}},
                            'subnet-id': '1'
                        }
                    }
                }
            }
        }
    }
    
    Output:
    {
        'dhcp': {
            'listen_interface': ['eth1', 'eth2'],
            'pools': [
                {
                    'dhcp_name': 'dhcp1',
                    'subnet': '192.168.1.0/24',
                    'range_start': '192.168.1.1',
                    'range_end': '192.168.1.254',
                    'lease_time': '86400',
                    'subnet_id': '1',
                    'enabled': True,
                    'description': ''
                }
            ]
        },
        'dhcpv6': {
            'listen_interface': [],
            'pools': []
        }
    }
    """
    result = {
        'dhcp': {
            'listen_interface': [],
            'pools': []
        },
        'dhcpv6': {
            'listen_interface': [],
            'pools': []
        }
    }
    
    if 'dhcp' in data and isinstance(data['dhcp'], dict):
        dhcp_data = data['dhcp']

        if 'disable' in dhcp_data:
            result['dhcp']['disable'] = {}
        
        for listen_key in ['listen_interface', 'listen-interface']:
            if listen_key in dhcp_data:
                listen_interfaces = dhcp_data[listen_key]
                if isinstance(listen_interfaces, str):
                    result['dhcp']['listen_interface'] = [listen_interfaces]
                elif isinstance(listen_interfaces, list):
                    result['dhcp']['listen_interface'] = listen_interfaces
                break
        
        for network_key in ['shared_network_name', 'shared-network-name']:
            if network_key in dhcp_data and isinstance(dhcp_data[network_key], dict):
                shared_networks = dhcp_data[network_key]
                
                for network_name, network_config in shared_networks.items():
                    authoritative = False
                    network_option = {}
                    if 'authoritative' in network_config:
                        authoritative = True
                    if 'option' in network_config:
                        network_option = network_config['option']

                    
                    if 'subnet' in network_config and isinstance(network_config['subnet'], dict):
                        for subnet, subnet_config in network_config['subnet'].items():
                            pool = {
                                'dhcp_name': network_name,
                                'subnet': subnet,
                                'range_start': '',
                                'range_end': '',
                                'lease_time': '',
                                'subnet_id': '',
                                'enabled': 'disable' not in network_config and 'disable' not in subnet_config,
                                'description': '',
                                'authoritative': authoritative,
                                'boot_file': ''
                            }

                            for boot_file_key in ['bootfile-name', 'bootfile_name']:
                                if boot_file_key in network_option:
                                    pool['boot_file'] = network_option[boot_file_key]
                                    break
                            
                            if 'description' in network_config:
                                description = network_config['description']
                                if isinstance(description, (list, tuple)):
                                    pool['description'] = ' '.join(description)
                                elif isinstance(description, str):
                                    pool['description'] = description
                                else:
                                    pool['description'] = str(description) if description is not None else ''
                            
                            if 'description' in subnet_config:
                                description = subnet_config['description']
                                if isinstance(description, (list, tuple)):
                                    pool['description'] = ' '.join(description)
                                elif isinstance(description, str):
                                    pool['description'] = description
                                else:
                                    pool['description'] = str(description) if description is not None else ''
                            
                            for subnet_id_key in ['subnet_id', 'subnet-id']:
                                if subnet_id_key in subnet_config:
                                    pool['subnet_id'] = subnet_config[subnet_id_key]
                                    break
                            
                            for lease_key in ['lease', 'lease_time', 'lease-time']:
                                if lease_key in subnet_config:
                                    if isinstance(subnet_config[lease_key], dict) and 'default' in subnet_config[lease_key]:
                                        pool['lease_time'] = subnet_config[lease_key]['default']
                                    else:
                                        pool['lease_time'] = subnet_config[lease_key]
                                    break
                            
                            if 'range' in subnet_config and isinstance(subnet_config['range'], dict):
                                for range_name, range_config in subnet_config['range'].items():
                                    if 'start' in range_config:
                                        pool['range_start'] = range_config['start']
                                    if 'stop' in range_config:
                                        pool['range_end'] = range_config['stop']
                                    break
                            if 'option' in subnet_config:
                                for router_key in ['default_router', 'default-router']:
                                    if router_key in subnet_config['option']:
                                        pool['default_router'] = subnet_config['option'][router_key]
                                        break
                                
                                for name_server_key in ['name_server', 'name-server']:
                                    if name_server_key in subnet_config['option']:
                                        value = subnet_config['option'][name_server_key]
                                        if isinstance(value, list):
                                            pool['name_servers'] = value
                                            pool['name_server'] = value
                                        else:
                                            pool['name_servers'] = [value]
                                            pool['name_server'] = value
                                        break
                                
                                for domain_key in ['domain_name', 'domain-name', 'domain-search', 'domain_search']:
                                    if domain_key in subnet_config['option']:
                                        pool['domain_name'] = subnet_config['option'][domain_key]
                                        break
                                
                                # Add support for additional DHCPv6 options
                                for nis_domain_key in ['nis_domain', 'nis-domain']:
                                    if nis_domain_key in subnet_config['option']:
                                        pool['nis_domain'] = subnet_config['option'][nis_domain_key]
                                        break
                                
                                for nis_server_key in ['nis_server', 'nis-server']:
                                    if nis_server_key in subnet_config['option']:
                                        value = subnet_config['option'][nis_server_key]
                                        if isinstance(value, list):
                                            pool['nis_servers'] = value
                                        else:
                                            pool['nis_servers'] = [value]
                                        break
                                
                                for nisp_domain_key in ['nisp_domain', 'nisp-domain', 'nisplus_domain', 'nisplus-domain']:
                                    if nisp_domain_key in subnet_config['option']:
                                        pool['nisp_domain'] = subnet_config['option'][nisp_domain_key]
                                        break
                                
                                for nisp_server_key in ['nisp_server', 'nisp-server', 'nisplus_server', 'nisplus-server']:
                                    if nisp_server_key in subnet_config['option']:
                                        value = subnet_config['option'][nisp_server_key]
                                        if isinstance(value, list):
                                            pool['nisp_servers'] = value
                                        else:
                                            pool['nisp_servers'] = [value]
                                        break
                                
                                for sip_server_key in ['sip_server', 'sip-server']:
                                    if sip_server_key in subnet_config['option']:
                                        value = subnet_config['option'][sip_server_key]
                                        if isinstance(value, list):
                                            pool['sip_servers'] = value
                                        else:
                                            pool['sip_servers'] = [value]
                                        break
                                
                                for sntp_server_key in ['sntp_server', 'sntp-server']:
                                    if sntp_server_key in subnet_config['option']:
                                        value = subnet_config['option'][sntp_server_key]
                                        if isinstance(value, list):
                                            pool['sntp_servers'] = value
                                        else:
                                            pool['sntp_servers'] = [value]
                                        break
                                
                                # Handle prefix/length for DHCPv6
                                if 'prefix' in subnet_config and isinstance(subnet_config['prefix'], dict):
                                    for prefix_name, prefix_config in subnet_config['prefix'].items():
                                        if 'prefix' in prefix_config:
                                            pool['range_prefix'] = prefix_config['prefix']
                                        if 'length' in prefix_config:
                                            pool['range_prefix_length'] = prefix_config['length']
                                        break

                            # print("Pool data:")
                            # print(pprint.pformat(pool, indent=4))
                            result['dhcp']['pools'].append(pool)
                break
    
    if 'dhcpv6' in data and isinstance(data['dhcpv6'], dict):
        dhcpv6_data = data['dhcpv6']

        if 'disable' in dhcpv6_data:
            result['dhcpv6']['disable'] = {}
        
        for listen_key in ['listen_interface', 'listen-interface']:
            if listen_key in dhcpv6_data:
                listen_interfaces = dhcpv6_data[listen_key]
                if isinstance(listen_interfaces, str):
                    result['dhcpv6']['listen_interface'] = [listen_interfaces]
                elif isinstance(listen_interfaces, list):
                    result['dhcpv6']['listen_interface'] = listen_interfaces
                break
        
        for network_key in ['shared_network_name', 'shared-network-name']:
            if network_key in dhcpv6_data and isinstance(dhcpv6_data[network_key], dict):
                shared_networks = dhcpv6_data[network_key]
                
                for network_name, network_config in shared_networks.items():
                    if 'subnet' in network_config and isinstance(network_config['subnet'], dict):
                        for subnet, subnet_config in network_config['subnet'].items():
                            pool = {
                                'dhcp_name': network_name,
                                'subnet': subnet,
                                'range_start': '',
                                'range_end': '',
                                'lease_time': '',
                                'subnet_id': '',
                                'enabled': 'disable' not in network_config and 'disable' not in subnet_config,
                                'description': '',
                                'interface': ''
                            }

                            if 'interface' in network_config:
                                pool['interface'] = network_config['interface']
                            
                            if 'description' in subnet_config:
                                description = subnet_config['description']
                                if isinstance(description, (list, tuple)):
                                    pool['description'] = ' '.join(description)
                                elif isinstance(description, str):
                                    pool['description'] = description
                                else:
                                    pool['description'] = str(description) if description is not None else ''
                            
                            for subnet_id_key in ['subnet_id', 'subnet-id']:
                                if subnet_id_key in subnet_config:
                                    pool['subnet_id'] = subnet_config[subnet_id_key]
                                    break
                            
                            for lease_key in ['lease', 'lease_time', 'lease-time']:
                                if lease_key in subnet_config:
                                    if isinstance(subnet_config[lease_key], dict) and 'default' in subnet_config[lease_key]:
                                        pool['lease_time'] = subnet_config[lease_key]['default']
                                    else:
                                        pool['lease_time'] = subnet_config[lease_key]
                                    break
                            
                            if 'range' in subnet_config and isinstance(subnet_config['range'], dict):
                                for range_name, range_config in subnet_config['range'].items():
                                    if 'start' in range_config:
                                        pool['range_start'] = range_config['start']
                                    if 'stop' in range_config:
                                        pool['range_end'] = range_config['stop']
                                    break
                            if 'option' in subnet_config:
                                for router_key in ['default_router', 'default-router']:
                                    if router_key in subnet_config['option']:
                                        pool['default_router'] = subnet_config['option'][router_key]
                                        break
                                
                                for name_server_key in ['name_server', 'name-server']:
                                    if name_server_key in subnet_config['option']:
                                        value = subnet_config['option'][name_server_key]
                                        if isinstance(value, list):
                                            pool['name_servers'] = value
                                        else:
                                            pool['name_servers'] = [value]
                                        break
                                
                                for domain_key in ['domain_name', 'domain-name', 'domain-search', 'domain_search']:
                                    if domain_key in subnet_config['option']:
                                        pool['domain_name'] = subnet_config['option'][domain_key]
                                        break
                                
                                # Add support for additional DHCPv6 options
                                for nis_domain_key in ['nis_domain', 'nis-domain']:
                                    if nis_domain_key in subnet_config['option']:
                                        pool['nis_domain'] = subnet_config['option'][nis_domain_key]
                                        break
                                
                                for nis_server_key in ['nis_server', 'nis-server']:
                                    if nis_server_key in subnet_config['option']:
                                        value = subnet_config['option'][nis_server_key]
                                        if isinstance(value, list):
                                            pool['nis_servers'] = value
                                        else:
                                            pool['nis_servers'] = [value]
                                        break
                                
                                for nisp_domain_key in ['nisp_domain', 'nisp-domain', 'nisplus_domain', 'nisplus-domain']:
                                    if nisp_domain_key in subnet_config['option']:
                                        pool['nisp_domain'] = subnet_config['option'][nisp_domain_key]
                                        break
                                
                                for nisp_server_key in ['nisp_server', 'nisp-server', 'nisplus_server', 'nisplus-server']:
                                    if nisp_server_key in subnet_config['option']:
                                        value = subnet_config['option'][nisp_server_key]
                                        if isinstance(value, list):
                                            pool['nisp_servers'] = value
                                        else:
                                            pool['nisp_servers'] = [value]
                                        break
                                
                                for sip_server_key in ['sip_server', 'sip-server']:
                                    if sip_server_key in subnet_config['option']:
                                        value = subnet_config['option'][sip_server_key]
                                        if isinstance(value, list):
                                            pool['sip_servers'] = value
                                        else:
                                            pool['sip_servers'] = [value]
                                        break
                                
                                for sntp_server_key in ['sntp_server', 'sntp-server']:
                                    if sntp_server_key in subnet_config['option']:
                                        value = subnet_config['option'][sntp_server_key]
                                        if isinstance(value, list):
                                            pool['sntp_servers'] = value
                                        else:
                                            pool['sntp_servers'] = [value]
                                        break
                                
                                # Handle prefix/length for DHCPv6
                                if 'prefix' in subnet_config and isinstance(subnet_config['prefix'], dict):
                                    for prefix_name, prefix_config in subnet_config['prefix'].items():
                                        if 'prefix' in prefix_config:
                                            pool['range_prefix'] = prefix_config['prefix']
                                        if 'length' in prefix_config:
                                            pool['range_prefix_length'] = prefix_config['length']
                                        break

                            result['dhcpv6']['pools'].append(pool)
                break
    
    return result

def parse_dhcp(data):
    """
    Parse DHCP configuration.
    Input sample:
    { 'listen-interface': [], 
        'shared-network-name': { 'dhcp1': { 'subnet': { '192.168.1.0/24': { 'lease': '86400',
                                                                                   'option': { 'default-router': '192.168.1.1',
                                                                                                'name-server': '192.168.1.1'},
                                                                                   'range': { 'range_1': { 'start': '192.168.1.1',
                                                                                                            'stop': '192.168.1.254'}},
                                                                                   'subnet-id': '1'}}},
                                        'dhcp2': { 'subnet': { '192.168.100.0/24': { 'lease': '86400',
                                                                                     'option': { 'default-router': '192.168.100.1',
                                                                                                 'name-server': '192.168.100.1'},
                                                                                     'range': { 'range_1': { 'start': '192.168.100.1',
                                                                                                             'stop': '192.168.100.254'}},
                                                                                     'subnet-id': '2'}}}}}

    Output sample:
    { 'listen_interface': [],
      'shared_network_name': { 'dhcp1': { 'subnet': { '192.168.1.0/24': { 'lease': '86400',
                                                                                   'option': { 'default_router': '192.168.1.1',
                                                                                                'name_server': '192.168.1.1'},
                                                                                   'range': { 'range_1': { 'start': '192.168.1.1',
                                                                                                            'stop': '192.168.1.254'}},
                                                                                   'subnet_id': '1'}}},
                                        'dhcp2': { 'subnet': { '192.168.100.0/24': { 'lease': '86400',
                                                                                     'option': { 'default_router': '192.168.100.1',
                                                                                                 'name_server': '192.168.100.1'},
                                                                                     'range': { 'range_1': { 'start': '192.168.100.1',
                                                                                                             'stop': '192.168.100.254'}},
                                                                                     'subnet_id': '2'}}}}}
    """
    if not data:
        return {}
    
    result = {}

    if 'disable' in data:
        result['disable'] = {}
    
    if 'listen-interface' in data:
        if isinstance(data['listen-interface'], list):
            result['listen_interface'] = data['listen-interface']
        else:
            result['listen_interface'] = [data['listen-interface']]
    elif 'listen_interface' in data:
        if isinstance(data['listen_interface'], list):
            result['listen_interface'] = data['listen_interface']
        else:
            result['listen_interface'] = [data['listen_interface']]
    else:
        result['listen_interface'] = []
    
    shared_network = data.get('shared-network-name', data.get('shared_network_name', {}))
    result['shared_network_name'] = {}
    
    for network_name, network_data in shared_network.items():
        result['shared_network_name'][network_name] = {}

        if 'interface' in network_data:
            result['shared_network_name'][network_name]['interface'] = network_data['interface']

        if 'description' in network_data:
            result['shared_network_name'][network_name]['description'] = network_data['description']

        if 'authoritative' in network_data:
            result['shared_network_name'][network_name]['authoritative'] = {}
        
        if 'option' in network_data:
            result['shared_network_name'][network_name]['option'] = {}
            
            for opt_key, opt_value in network_data['option'].items():
                new_opt_key = opt_key.replace('-', '_')
                result['shared_network_name'][network_name]['option'][new_opt_key] = opt_value
        
        if 'subnet' in network_data:
            result['shared_network_name'][network_name]['subnet'] = {}
            
            for subnet, subnet_data in network_data['subnet'].items():
                result['shared_network_name'][network_name]['subnet'][subnet] = {}
                subnet_result = result['shared_network_name'][network_name]['subnet'][subnet]
                
                for key, value in subnet_data.items():
                    if key == 'subnet-id':
                        subnet_result['subnet_id'] = value
                    elif key == 'subnet_id':
                        subnet_result['subnet_id'] = value
                    elif key != 'option' and key != 'range':
                        new_key = key.replace('-', '_')
                        subnet_result[new_key] = value
                
                if 'option' in subnet_data:
                    subnet_result['option'] = {}
                    for opt_key, opt_value in subnet_data['option'].items():
                        new_opt_key = opt_key.replace('-', '_')
                        subnet_result['option'][new_opt_key] = opt_value
                
                if 'range' in subnet_data:
                    subnet_result['range'] = {}
                    for range_key, range_data in subnet_data['range'].items():
                        subnet_result['range'][range_key] = range_data
    
    return result


def parse_dhcp_pool_to_db(pool_name: str, dhcp_data: dict):
    data = {}
    
    if 'shared_network_name' in dhcp_data and pool_name in dhcp_data.get('shared_network_name', {}):
        print("Processing shared_network_name structure")
        shared_network = dhcp_data['shared_network_name'][pool_name]
        
        if isinstance(shared_network, dict) and 'subnet' in shared_network:
            subnet_key = next(iter(shared_network.get('subnet', {}).keys()), None)
            if subnet_key:
                subnet_data = shared_network['subnet'][subnet_key]
                
                data['subnet'] = str(subnet_key)
                data['subnet_id'] = str(subnet_data.get('subnet_id', ''))
                data['lease_time'] = str(subnet_data.get('lease', ''))
                data['enabled'] = True
                
                range_data = subnet_data.get('range', {}).get('range_1', {})
                if range_data:
                    data['range_start'] = str(range_data.get('start', ''))
                    data['range_end'] = str(range_data.get('stop', ''))
                
                options = subnet_data.get('option', {})
                if options:
                    data['default_router'] = str(options.get('default_router', ''))
                    
                    name_servers = options.get('name_server')
                    if name_servers:
                        if isinstance(name_servers, list):
                            data['name_server'] = str(name_servers[0]) if name_servers else None
                        elif isinstance(name_servers, dict):
                            data['name_server'] = str(name_servers)
                        else:
                            data['name_server'] = str(name_servers)
    
    elif 'subnet' in dhcp_data:
        print("Processing direct subnet structure")
        if isinstance(dhcp_data['subnet'], dict):
            subnet_key = next(iter(dhcp_data.get('subnet', {}).keys()), None)
            if subnet_key:
                subnet_data = dhcp_data['subnet'][subnet_key]
                
                data['subnet'] = str(subnet_key)
                data['subnet_id'] = str(subnet_data.get('subnet_id', ''))
                data['lease_time'] = str(subnet_data.get('lease', ''))
                data['enabled'] = True
                
                range_data = subnet_data.get('range', {}).get('range_1', {})
                if range_data:
                    data['range_start'] = str(range_data.get('start', ''))
                    data['range_end'] = str(range_data.get('stop', ''))
                
                options = subnet_data.get('option', {})
                if options:
                    data['default_router'] = str(options.get('default_router', ''))
                    name_servers = options.get('name_server')
                    if name_servers:
                        if isinstance(name_servers, list):
                            data['name_server'] = str(name_servers[0]) if name_servers else None
                        elif isinstance(name_servers, dict):
                            data['name_server'] = str(name_servers)
                        else:
                            data['name_server'] = str(name_servers)
    
    return data


if __name__ == "__main__":
    """
    Example of how to use the parse_to_dhcp_config function.
    """
    input_data = {
        'dhcp': {
            'listen_interface': [],
            'pools': [
                {
                    'description': 'DHCP for LAN network',
                    'dhcp_name': 'lan_pool',
                    'dhcp_type': 'dhcp',
                    'enabled': True,
                    'interface': None,
                    'lease_time': '43200',  # 12 hours
                    'range_end': '192.168.1.200',
                    'range_start': '192.168.1.10',
                    'subnet': '192.168.1.0/24'
                }
            ]
        },
        'dhcpv6': {
            'listen_interface': [],
            'pools': [
                {
                    'description': 'DHCPv6 for LAN network',
                    'dhcp_name': 'lan_pool_v6',
                    'dhcp_type': 'dhcpv6',
                    'enabled': True,
                    'interface': None,
                    'lease_time': '86400',  # 24 hours
                    'range_end': '2001:db8::ffff',
                    'range_start': '2001:db8::1000',
                    'subnet': '2001:db8::/64'
                }
            ]
        }
    }
    
    vyos_config = parse_to_dhcp_config(input_data)
    
    print("Input data:")
    print(json.dumps(input_data, indent=2))
    print("\nParsed VyOS configuration:")
    print(json.dumps(vyos_config, indent=2))
    
    input_data_disabled = {
        'dhcp': {
            'listen_interface': [],
            'pools': [
                {
                    'description': 'Disabled DHCP pool',
                    'dhcp_name': 'guest_network',
                    'dhcp_type': 'dhcp',
                    'enabled': False,
                    'interface': None,
                    'lease_time': '3600',
                    'range_end': '10.0.0.100',
                    'range_start': '10.0.0.10',
                    'subnet': '10.0.0.0/24'
                }
            ]
        },
        'dhcpv6': {
            'listen_interface': [],
            'pools': []
        }
    }
    
    vyos_config_disabled = parse_to_dhcp_config(input_data_disabled)
    
    print("\nDisabled DHCP Input data:")
    print(json.dumps(input_data_disabled, indent=2))
    print("\nParsed Disabled DHCP VyOS configuration:")
    print(json.dumps(vyos_config_disabled, indent=2))
