import os
import re
from typing import List
from app.core.utils.check_os import is_linux

def read_country_code() -> List[str]:
    """
    Read country code from the VyOS configuration file and extract the country codes.
    
    Located at /opt/vyatta/share/vyatta-cfg/templates/system/wireless/country-code/node.def
    Extracts from the 'allowed' section.
    
    Returns:
        List[str]: A list of country codes (e.g., ['00', 'ad', 'ae', ...]).
    """
    file_path = '/opt/vyatta/share/vyatta-cfg/templates/system/wireless/country-code/node.def'
    
    country_codes = []
    
    if is_linux():
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as file:
                    content = file.read()
                    
                    allowed_match = re.search(r'allowed:\s*echo\s*"([^"]+)"', content)
                    
                    if allowed_match:
                        codes_str = allowed_match.group(1)
                        country_codes = codes_str.strip().split()
            except Exception as e:
                print(f"Error reading country code file: {e}")
            
    else:
        default_codes = "00 ad ae af ai al am an ar as at au aw az ba bb bd be bf bg bh bl bm bn bo br bs bt by bz ca cf ch ci cl cn co cr cu cx cy cz de dk dm do dz ec ee eg es et fi fm fr gb gd ge gf gh gl gp gr gt gu gy hk hn hr ht hu id ie il in ir is it jm jo jp ke kh kn kp kr kw ky kz lb lc li lk ls lt lu lv ma mc md me mf mh mk mn mo mp mq mr mt mu mv mw mx my ng ni nl no np nz om pa pe pf pg ph pk pl pm pr pt pw py qa re ro rs ru rw sa se sg si sk sn sr sv sy tc td tg th tn tr tt tw tz ua ug us uy uz vc ve vi vn vu wf ws ye yt za zw"
        country_codes = default_codes.split()
    
    return country_codes
