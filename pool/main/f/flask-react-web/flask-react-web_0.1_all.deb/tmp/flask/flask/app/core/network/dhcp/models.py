from typing import Optional, List
from pydantic import BaseModel
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean
import pprint

def format_description(desc: str) -> str:
    if not desc:
        return ""
    return desc.replace('_', ' ')


class PoolDTO(BaseModel):
    description: Optional[str] = None
    dhcp_type: Optional[str] = None
    enabled: Optional[bool] = None
    range_end: str
    range_start: str
    interface: Optional[str] = None
    lease_time: Optional[str] = None
    subnet: str
    dhcp_name: str
    subnet_id: str
    default_router: Optional[str] = None
    name_server: Optional[str] = None
    domain_name: Optional[str] = None
    ip_range_type: Optional[str] = None
    boot_file: Optional[str] = None
    authoritative: Optional[bool] = None



class Poolv6DTO(BaseModel):
    description: Optional[str] = None
    dhcp_type: Optional[str] = None
    enabled: Optional[bool] = None
    range_end: str
    range_start: str
    interface: Optional[str] = None
    lease_time: Optional[str] = None
    subnet: str
    dhcp_name: str
    subnet_id: str
    default_router: Optional[str] = None
    name_server: Optional[str | List[str]] = None
    domain_name: Optional[str] = None
    name_servers: Optional[List[str]] = None
    nis_domain: Optional[str] = None
    nis_servers: Optional[List[str]] = None
    nisp_domain: Optional[str] = None
    nisp_servers: Optional[List[str]] = None
    ip_range_type: Optional[str] = None
    range_prefix: Optional[str] = None
    range_prefix_length: Optional[str] = None
    sip_servers: Optional[List[str]] = None
    sntp_servers: Optional[List[str]] = None
    interface: Optional[str] = None



class DHCPDTO(BaseModel):
    listen_interface: Optional[List[str]] = None
    pools: Optional[List[PoolDTO]] = None
    disabled: Optional[bool] = None



class DHCPv6DTO(BaseModel):
    listen_interface: Optional[List[str]] = None
    pools: Optional[List[Poolv6DTO]] = None
    disabled: Optional[bool] = None


class VerifyDHCPDTO(BaseModel):
    dhcp: Optional[DHCPDTO] = None
    dhcpv6: Optional[DHCPv6DTO] = None
    verify_type: str


class DHCPRelayDTO(BaseModel):
    
    disable: Optional[bool] = None
    hop_count: Optional[str|int] = None
    id: Optional[str|int] = None
    listen_interface: Optional[List[str]] = None
    max_packet_size: Optional[str|int] = None
    relay_agent_packet: Optional[str] = None
    relay_servers: Optional[List[str]] = None
    upstream_interface: Optional[List[str]] = None
    

class UpdateDHCPDTO(BaseModel):
    dhcp: Optional[DHCPDTO] = None
    dhcpv6: Optional[DHCPv6DTO] = None
    dhcpRelays: Optional[DHCPRelayDTO] = None


class SUBNETDTO(BaseModel):
    subnet: str


class DHCPListenInterface(db.Model):
    __tablename__ = "vyos_dhcp_listen_interface"

    id = Column(Integer, primary_key=True)
    interface = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing DHCP listen interfaces...")
            cls.truncate()
            new_records = []
            
            # Check if the data is in the parsed format
            if 'dhcp' in data and isinstance(data['dhcp'], dict) and 'listen_interface' in data['dhcp']:
                interfaces = data['dhcp']['listen_interface']
            else:
                # Fallback to the old format
                interfaces = data.get('listen_interface', [])
                
            for interface in interfaces:
                new_record = cls(
                    interface=interface
                )
                new_records.append(new_record)
            if new_records:
                db.session.bulk_save_objects(new_records)
                db.session.commit()
        except Exception as e:
            print("Error refreshing DHCP listen interfaces:", str(e))

    def serialize(self):
        return {
            'id': self.id,
            'interface': self.interface
        }

    @classmethod
    def get_all_serialized(cls):
        records = cls.query.all()
        return {
            'listen_interface': [record.serialize() for record in records]
        }




class DHCPListenInterfacev6(db.Model):
    __tablename__ = "vyos_dhcp_listen_interface_v6"

    id = Column(Integer, primary_key=True)
    interface = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing DHCP listen interfaces v6...")
            cls.truncate()
            new_records = []
            
            # Check if the data is in the parsed format
            if 'dhcpv6' in data and isinstance(data['dhcpv6'], dict) and 'listen_interface' in data['dhcpv6']:
                interfaces = data['dhcpv6']['listen_interface']
            else:
                # Fallback to the old format
                interfaces = data.get('listen_interface', [])
                
            for interface in interfaces:
                new_record = cls(
                    interface=interface
                )
                new_records.append(new_record)
            if new_records:
                db.session.bulk_save_objects(new_records)
                db.session.commit()
        except Exception as e:
            print("Error refreshing DHCP listen interfaces v6:", str(e))

    def serialize(self):
        return {
            'id': self.id,
            'interface': self.interface
        }

    @classmethod
    def get_all_serialized(cls):
        records = cls.query.all()
        return {
            'listen_interface': [record.serialize() for record in records]
        }


class DHCPPool(db.Model):
    __tablename__ = "vyos_dhcp_pool"

    id = Column(Integer, primary_key=True)
    dhcp_name = Column(String(255), nullable=True)
    subnet = Column(String(255), nullable=True)
    subnet_id = Column(String(255), nullable=True)
    range_start = Column(String(255), nullable=True)
    range_end = Column(String(255), nullable=True)
    lease_time = Column(String(255), nullable=True)
    enabled = Column(Boolean, nullable=True)
    description = Column(String(255), nullable=True)
    default_router = Column(String(255), nullable=True)
    name_server = Column(String(255), nullable=True)
    domain_name = Column(String(255), nullable=True)
    authoritative = Column(Boolean, nullable=True)
    boot_file = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def create_pool_from_data(cls, pool_data: dict, pool_name: str = None):

        try:
            if isinstance(pool_data.get('name_server'), list):
                name_server = pool_data.get('name_server')[0] if pool_data.get('name_server') else None
            else:
                name_server = pool_data.get('name_server')
            
            return cls(
                dhcp_name=pool_name or pool_data.get('dhcp_name'),
                subnet=pool_data.get('subnet'),
                subnet_id=pool_data.get('subnet_id'),
                range_start=pool_data.get('range_start'),
                range_end=pool_data.get('range_end'),
                lease_time=pool_data.get('lease_time') if pool_data.get('lease_time') != "" else '86400',
                enabled=pool_data.get('enabled'),
                description=pool_data.get('description'),
                default_router=pool_data.get('default_router'),
                name_server=name_server,
                domain_name=pool_data.get('domain_name'),
                authoritative=pool_data.get('authoritative'),
                boot_file=pool_data.get('boot_file')
            )
        except Exception as e:
            print(f"Error creating DHCP pool from data: {str(e)}")
            return None
    
    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing DHCP pools...")
            cls.truncate()
            new_records = []
            
            if 'dhcp' in data and isinstance(data['dhcp'], dict) and 'pools' in data['dhcp']:
                pools = data['dhcp']['pools']
            else:
                pools = data.get('pools', [])
                
            for pool in pools:
                new_record = cls.create_pool_from_data(pool)
                if new_record:
                    new_records.append(new_record)
                    
            if new_records:
                db.session.bulk_save_objects(new_records)
                db.session.commit()
        except Exception as e:
            print("Error refreshing DHCP pools:", str(e))


    @classmethod
    def update_pool_by_name(cls, pool_name: str, dhcp_data: dict):
        try:
            # print(f"Updating DHCP pool: {pool_name}")
            # print("DHCP data: ")
            # print(pprint.pformat(dhcp_data, indent=2, width=80))
            
            from app.core.network.dhcp.parser import parse_dhcp_pool_to_db
            data = parse_dhcp_pool_to_db(pool_name, dhcp_data)
            
            existing_pool = cls.query.filter_by(dhcp_name=pool_name).first()
            
            if not existing_pool:
                print(f"DHCP pool {pool_name} not found, creating new record")
                new_pool = cls.create_pool_from_data(data, pool_name)
                if new_pool:
                    db.session.add(new_pool)
                else:
                    raise ValueError(f"Failed to create DHCP pool {pool_name}")
            else:
                # print(f"Updating existing DHCP pool: {pool_name}")
                # print("Processed data: ")
                # print(pprint.pformat(data, indent=2, width=80))
                
                if 'name_server' in data:
                    name_server_value = data['name_server']
                    if isinstance(name_server_value, list):
                        existing_pool.name_server = name_server_value[0] if name_server_value else None
                    elif isinstance(name_server_value, dict):
                        existing_pool.name_server = str(name_server_value)
                    else:
                        existing_pool.name_server = name_server_value
                
                existing_pool.subnet = data.get('subnet', existing_pool.subnet)
                existing_pool.subnet_id = data.get('subnet_id', existing_pool.subnet_id)
                existing_pool.range_start = data.get('range_start', existing_pool.range_start)
                existing_pool.range_end = data.get('range_end', existing_pool.range_end)
                existing_pool.lease_time = data.get('lease_time', existing_pool.lease_time)
                existing_pool.enabled = data.get('enabled', existing_pool.enabled)
                existing_pool.description = data.get('description', existing_pool.description)
                existing_pool.default_router = data.get('default_router', existing_pool.default_router)
                existing_pool.domain_name = data.get('domain_name', existing_pool.domain_name)
                existing_pool.authoritative = data.get('authoritative', existing_pool.authoritative)
                existing_pool.boot_file = data.get('boot_file', existing_pool.boot_file)
            
            try:
                db.session.commit()
                print(f"Successfully updated DHCP pool: {pool_name}")
            except Exception as commit_error:
                # db.session.rollback()
                print(f"Error during commit: {str(commit_error)}")
                raise
            return True
        except Exception as e:
            # db.session.rollback()
            print(f"Error updating DHCP pool {pool_name}: {str(e)}")
            return False


    def serialize(self):
        return {
            'id': self.id,
            'dhcp_name': self.dhcp_name,
            'subnet': self.subnet,
            'subnet_id': self.subnet_id,
            'range_start': self.range_start,
            'range_end': self.range_end,
            'lease_time': self.lease_time,
            'enabled': self.enabled,
            'description': format_description(self.description),
            'default_router': self.default_router,
            'name_server': self.name_server,
            'domain_name': self.domain_name,
            'authoritative': self.authoritative,
            'boot_file': self.boot_file
        }



class DHCPPoolv6(db.Model):
    __tablename__ = "vyos_dhcp_pool_v6"

    id = Column(Integer, primary_key=True)
    dhcp_name = Column(String(255), nullable=True)
    subnet = Column(String(255), nullable=True)
    subnet_id = Column(String(255), nullable=True)
    range_start = Column(String(255), nullable=True)
    range_end = Column(String(255), nullable=True)
    lease_time = Column(String(255), nullable=True)
    enabled = Column(Boolean, nullable=True)
    description = Column(String(255), nullable=True)
    default_router = Column(String(255), nullable=True)
    name_server = Column(String(255), nullable=True)
    domain_name = Column(String(255), nullable=True)
    name_servers = Column(String(255), nullable=True)
    nis_domain = Column(String(255), nullable=True)
    nis_servers = Column(String(255), nullable=True)
    nisp_domain = Column(String(255), nullable=True)
    nisp_servers = Column(String(255), nullable=True)
    range_prefix = Column(String(255), nullable=True)
    range_prefix_length = Column(String(255), nullable=True)
    sip_servers = Column(String(255), nullable=True)
    sntp_servers = Column(String(255), nullable=True)
    interface = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing DHCP pools...")
            cls.truncate()
            new_records = []
            
            # Check if the data is in the parsed format
            if 'dhcpv6' in data and isinstance(data['dhcpv6'], dict) and 'pools' in data['dhcpv6']:
                pools = data['dhcpv6']['pools']
            else:
                # Fallback to the old format
                pools = data.get('pools', [])
                
            for pool in pools:
                # Convert list fields to comma-separated strings
                name_servers = ','.join(pool.get('name_servers', [])) if pool.get('name_servers') else None
                nis_servers = ','.join(pool.get('nis_servers', [])) if pool.get('nis_servers') else None
                nisp_servers = ','.join(pool.get('nisp_servers', [])) if pool.get('nisp_servers') else None
                sip_servers = ','.join(pool.get('sip_servers', [])) if pool.get('sip_servers') else None
                sntp_servers = ','.join(pool.get('sntp_servers', [])) if pool.get('sntp_servers') else None

                if isinstance(pool.get('domain_name'), list):
                    domain_names = ','.join(pool.get('domain_name'))
                else:
                    domain_names = pool.get('domain_name')
                
                new_record = cls(
                    dhcp_name=pool.get('dhcp_name'),
                    subnet=pool.get('subnet'),
                    subnet_id=pool.get('subnet_id'),
                    range_start=pool.get('range_start'),
                    range_end=pool.get('range_end'),
                    lease_time=pool.get('lease_time'),
                    enabled=pool.get('enabled'),
                    description=pool.get('description'),
                    default_router=pool.get('default_router'),
                    name_server='',
                    domain_name=domain_names,
                    name_servers=name_servers,
                    nis_domain=pool.get('nis_domain'),
                    nis_servers=nis_servers,
                    nisp_domain=pool.get('nisp_domain'),
                    nisp_servers=nisp_servers,
                    range_prefix=pool.get('range_prefix'),
                    range_prefix_length=pool.get('range_prefix_length'),
                    sip_servers=sip_servers,
                    sntp_servers=sntp_servers,
                    interface=pool.get('interface')
                )
                new_records.append(new_record)
            if new_records:
                db.session.bulk_save_objects(new_records)
                db.session.commit()
        except Exception as e:
            print("Error refreshing DHCP pools:", str(e))

    def serialize(self):
        return {
            'id': self.id,
            'dhcp_name': self.dhcp_name,
            'subnet': self.subnet,
            'subnet_id': self.subnet_id,
            'range_start': self.range_start,
            'range_end': self.range_end,
            'lease_time': self.lease_time,
            'enabled': self.enabled,
            'description': format_description(self.description),
            'default_router': self.default_router,
            'name_server': self.name_server.split(',') if self.name_server else [],
            'domain_name': self.domain_name,
            'name_servers': self.name_servers.split(',') if self.name_servers else [],
            'nis_domain': self.nis_domain,
            'nis_servers': self.nis_servers.split(',') if self.nis_servers else [],
            'nisp_domain': self.nisp_domain,
            'nisp_servers': self.nisp_servers.split(',') if self.nisp_servers else [],
            'range_prefix': self.range_prefix,
            'range_prefix_length': self.range_prefix_length,
            'sip_servers': self.sip_servers.split(',') if self.sip_servers else [],
            'sntp_servers': self.sntp_servers.split(',') if self.sntp_servers else [],
            'interface': self.interface
        }

class DHCPRelay(db.Model):
    __tablename__ = "vyos_dhcp_relay"

    id = Column(Integer, primary_key=True)
    relay_agent_packet = Column(String(255), nullable=True)
    hop_count = Column(String(255), nullable=True)
    max_packet_size = Column(String(255), nullable=True)
    listen_interface = Column(String(255), nullable=True)
    upstream_interface = Column(String(255), nullable=True)
    disable = Column(Boolean, nullable=True)
    relay_servers = Column(String(255), nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        try:
            print("Refreshing DHCP relay...")
            cls.truncate()
            new_records = []
            
            if 'dhcp' in data and isinstance(data['dhcp'], dict) and 'relay' in data['dhcp']:
                relays = data['dhcp']['relay']
            elif 'relay' in data and isinstance(data['relay'], list):
                relays = data['relay']
            elif all(key in data for key in ['listen_interface', 'relay_servers', 'upstream_interface']):
                relays = [data]
            else:
                relays = []
                
            for relay in relays:
                # Handle the case where 'disable' is an empty dict
                is_disabled = False
                if 'disable' in relay:
                    if isinstance(relay['disable'], dict) and not relay['disable']:  # Empty dict
                        is_disabled = True
                    elif relay['disable'] is True:
                        is_disabled = True
                    
                new_record = cls(
                    relay_agent_packet=relay.get('relay_agent_packet'),
                    hop_count=relay.get('hop_count'),
                    max_packet_size=relay.get('max_packet_size'),
                    listen_interface=relay.get('listen_interface'),
                    upstream_interface=relay.get('upstream_interface'),
                    disable=is_disabled,
                    relay_servers=relay.get('relay_servers')
                )
                new_records.append(new_record)
            if new_records:
                db.session.bulk_save_objects(new_records)
                db.session.commit()
        except Exception as e:
            print("Error refreshing DHCP relay:", str(e))

    def serialize(self):
        def string_to_list(value):
            if value and isinstance(value, str):
                return [item.strip() for item in value.split(',')]
            return [] if value is None else value
            
        return {
            'id': self.id,
            'relay_agent_packet': self.relay_agent_packet,
            'hop_count': self.hop_count,
            'max_packet_size': self.max_packet_size,
            'listen_interface': string_to_list(self.listen_interface),
            'upstream_interface': string_to_list(self.upstream_interface),
            'disable': self.disable,
            'relay_servers': string_to_list(self.relay_servers)
        }

    @classmethod
    def get_all_serialized(cls):
        records = cls.query.all()
        return {
            'relay': [record.serialize() for record in records]
        }   