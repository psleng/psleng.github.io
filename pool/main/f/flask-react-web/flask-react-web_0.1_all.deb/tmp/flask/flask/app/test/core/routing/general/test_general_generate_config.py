import pytest
from app.core.routing.command_routing import RoutingCommand
from app.test.core.base import TestGenerateConfig
from app.test.core.routing.general.test_cases._test_case_generate_config import test_set, test_delete, test_process_commands

class TestGeneralRoutingGenerateConfig(TestGenerateConfig):
    __test__ = True
    
    @pytest.fixture
    def cmd_class(self):
        return RoutingCommand
    
    @pytest.fixture
    def resource(self):
        return "ipv4"
    
    @pytest.fixture
    def cmd(self, cmd_class):
        return cmd_class(operator="set", resource="ipv4")
    
    @pytest.fixture
    def cmd_set(self, cmd_class):
        return cmd_class(operator="set", resource="ipv4")
    
    @pytest.fixture
    def cmd_delete(self, cmd_class):
        return cmd_class(operator="delete", resource="ipv4")
    
    @pytest.mark.parametrize("test_data", test_set)
    def test_generate_commands_set(self, cmd_set, test_data):
        super().test_generate_commands_set(cmd_set, test_data)
    
    @pytest.mark.parametrize("test_data", test_delete)
    def test_generate_commands_delete(self, cmd_delete, test_data):
        super().test_generate_commands_delete(cmd_delete, test_data)

    @pytest.mark.parametrize("test_data", test_process_commands)
    def test_process_commands(self, test_data):
        super().test_process_commands(test_data)
    
    def test_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)
    
    def test_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    
    def test_get_commands_empty(self):
        super().test_get_commands_empty(RoutingCommand)
