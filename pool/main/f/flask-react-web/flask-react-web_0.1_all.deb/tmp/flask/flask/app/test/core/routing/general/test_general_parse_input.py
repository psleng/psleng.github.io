import pytest
from app.core.routing.models import UpdateGeneralRoutingDTO
from app.core.routing.parsers import parse_to_route_config
from app.test.core.base import TestParseInput
from app.test.core.routing.general.test_cases._test_case_parse_input import test_case_valid, test_case_invalid, test_case_minimal, test_case_comparison

class TestGeneralRoutingParseConfig(TestParseInput):
    __test__ = True
    
    @pytest.mark.parametrize("test_data", test_case_valid)
    def test_model_validate_json_valid(self, test_data):
        super().test_model_validate_json_valid(test_data, UpdateGeneralRoutingDTO)
    
    @pytest.mark.parametrize("test_data", test_case_invalid)
    def test_model_validate_json_invalid(self, test_data):
        super().test_model_validate_json_invalid(test_data, UpdateGeneralRoutingDTO)
    
    @pytest.mark.parametrize("test_data", test_case_minimal)
    def test_model_validate_minimal_json(self, test_data):
        super().test_model_validate_minimal_json(test_data, UpdateGeneralRoutingDTO)
        
    @pytest.mark.parametrize("test_data", test_case_comparison)
    def test_compare_configs_additions(self, test_data):
        super().test_compare_configs_additions(test_data)
    
    def test_parse_to_route_config_empty(self):
        empty_dto = UpdateGeneralRoutingDTO(route_ver="v4")
        data = empty_dto.model_dump(exclude_none=True)
        
        route_config = parse_to_route_config(data)
        
        assert route_config == {}