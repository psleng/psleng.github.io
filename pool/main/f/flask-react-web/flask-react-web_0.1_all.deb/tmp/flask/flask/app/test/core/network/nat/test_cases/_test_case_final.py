import pytest
import json 

test_final_1 = pytest.param(
    (
        {
            "parsed_input": {
                "json_input": {
                    "source": [
                        {
                            "rule_id": "100",
                            "rule_type": "source",
                            "description": "Source NAT rule",
                            "outbound_interface": "eth1",
                            "protocol": "tcp",
                            "source_address": "192.168.1.0/24",
                            "source_port": "8080",
                            "destination_address": "10.0.0.0/24",
                            "destination_port": "80",
                            "translation_address": "192.168.1.2",
                            "translation_port": "9090"
                        }
                    ],
                    "destination": [
                        {
                            "rule_id": "200",
                            "rule_type": "destination",
                            "description": "Destination NAT rule",
                            "inbound_interface": "eth0",
                            "protocol": "tcp",
                            "source_address": "0.0.0.0/0",
                            "destination_address": "203.0.113.10",
                            "destination_port": "80",
                            "translation_address": "192.168.1.10",
                            "translation_port": "8080"
                        }
                    ]
                },
                "validated_input": {
                    "source": [
                        {
                            "rule_id": "100",
                            "rule_type": "source",
                            "description": "Source NAT rule",
                            "outbound_interface": "eth1",
                            "protocol": "tcp",
                            "source_address": "192.168.1.0/24",
                            "source_port": "8080",
                            "destination_address": "10.0.0.0/24",
                            "destination_port": "80",
                            "translation_address": "192.168.1.2",
                            "translation_port": "9090"
                        }
                    ],
                    "destination": [
                        {
                            "rule_id": "200",
                            "rule_type": "destination",
                            "description": "Destination NAT rule",
                            "inbound_interface": "eth0",
                            "protocol": "tcp",
                            "source_address": "0.0.0.0/0",
                            "destination_address": "203.0.113.10",
                            "destination_port": "80",
                            "translation_address": "192.168.1.10",
                            "translation_port": "8080"
                        }
                    ]
                },
                "parsed_input": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1",
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.1.0/24",
                                    "port": "8080"
                                },
                                "destination": {
                                    "address": "10.0.0.0/24",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.2",
                                    "port": "9090"
                                },
                                "description": "Source_NAT_rule"
                            }
                        }
                    },
                    "destination": {
                        "rule": {
                            "200": {
                                "inbound-interface": {
                                    "name": "eth0"
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "0.0.0.0/0"
                                },
                                "destination": {
                                    "address": "203.0.113.10",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.10",
                                    "port": "8080"
                                },
                                "description": "Destination_NAT_rule"
                            }
                        }
                    }
                },
                "current_config": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1"
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.1.0/24",
                                    "port": "8080"
                                },
                                "destination": {
                                    "address": "10.0.0.0/24",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.2",
                                    "port": "9090"
                                },
                                "description": "Source_NAT_rule"
                            }
                        }
                    }
                }
            },
            "diff_added": {
                "destination": {
                    "rule": {
                        "200": {
                            "inbound-interface": {
                                "name": "eth0"
                            },
                            "protocol": "tcp",
                            "source": {
                                "address": "0.0.0.0/0"
                            },
                            "destination": {
                                "address": "203.0.113.10",
                                "port": "80"
                            },
                            "translation": {
                                "address": "192.168.1.10",
                                "port": "8080"
                            },
                            "description": "Destination_NAT_rule"
                        }
                    }
                }
            },
            "diff_deleted": {},
            "generate_config": {
                "set_cmds": [
                    "set nat destination rule 200 inbound-interface name eth0",
                    "set nat destination rule 200 protocol tcp",
                    "set nat destination rule 200 source address 0.0.0.0/0",
                    "set nat destination rule 200 destination address 203.0.113.10",
                    "set nat destination rule 200 destination port 80",
                    "set nat destination rule 200 translation address 192.168.1.10",
                    "set nat destination rule 200 translation port 8080",
                    "set nat destination rule 200 description Destination_NAT_rule"
                ],
                "delete_cmds": []
            },
            "process_config": {
                "curr_config": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1"
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.1.0/24",
                                    "port": "8080"
                                },
                                "destination": {
                                    "address": "10.0.0.0/24",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.2",
                                    "port": "9090"
                                },
                                "description": "Source_NAT_rule"
                            }
                        }
                    }
                },
                "merged_set": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1"
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.1.0/24",
                                    "port": "8080"
                                },
                                "destination": {
                                    "address": "10.0.0.0/24",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.2",
                                    "port": "9090"
                                },
                                "description": "Source_NAT_rule"
                            }
                        }
                    },
                    "destination": {
                        "rule": {
                            "200": {
                                "inbound-interface": {
                                    "name": "eth0"
                                },
                                "protocol": "tcp",
                                "source": {
                                    "address": "0.0.0.0/0"
                                },
                                "destination": {
                                    "address": "203.0.113.10",
                                    "port": "80"
                                },
                                "translation": {
                                    "address": "192.168.1.10",
                                    "port": "8080"
                                },
                                "description": "Destination_NAT_rule"
                            }
                        }
                    }
                }
            },
            "verify": {
                "verify_result": True
            }
        }
    ),
    id="test_final_1"
)

test_final_2 = pytest.param(
    (
        {
            "parsed_input": {
                "json_input": {
                        "source": [
                            {
                                "rule_id": "100",
                                "rule_type": "source",
                                "outbound_interface": "eth1",
                                "translation_address": "masquerade"
                            }
                        ],
                        "destination": []
                    },
                "validated_input": {
                        "source": [
                            {
                                "rule_id": "100",
                                "rule_type": "source",
                                "outbound_interface": "eth1",
                                "translation_address": "masquerade"
                            }
                        ],
                        "destination": []
                    },
                "parsed_input": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1"
                                },
                                "translation": {
                                    "address": "masquerade"
                                }
                            }
                        }
                    }
                },
                "current_config": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth0"
                                },
                                "translation": {
                                    "address": "masquerade"
                                }
                            }
                        }
                    }
                }
            },
            "diff_added": {},
            "diff_deleted": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth0"
                            }
                        }
                    }
                }
            },
            "generate_config": {
                "set_cmds": [
                    "set nat source rule 100 outbound-interface name eth1"
                ],
                "delete_cmds": [
                    "delete nat source rule 100 outbound-interface name eth0"
                ]
            },
            "process_config": {
                "curr_config": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth0"
                                },
                                "translation": {
                                    "address": "masquerade"
                                }
                            }
                        }
                    }
                },
                "merged_set": {
                    "source": {
                        "rule": {
                            "100": {
                                "outbound-interface": {
                                    "name": "eth1"
                                },
                                "translation": {
                                    "address": "masquerade"
                                }
                            }
                        }
                    }
                }
            },
            "verify": {
                "verify_result": True
            }
        }
    ),
    id="test_final_2"
)

test_final = [
    test_final_1,
    test_final_2
]
