import unittest
from app.core.api.http.cmd.compare import compare_configs

class TestCompareConfig(unittest.TestCase):
    """
        Test suite for jobs config comparison
    """
    def test_dns_comparison(self):
        """Test comparison of DNS configurations"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1', '2.2.2.2']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1', '2.2.2.2']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                }
            }
        )
    
    def test_multiple_domains(self):
        """Test comparison with multiple DNS domains"""
        new_config = {
            'domains': [
                {
                    'name': 'example.com',
                    'name_servers': ['1.1.1.1']
                },
                {
                    'name': 'test.com',
                    'name_servers': ['8.8.8.8']
                }
            ]
        }
        current_config = {
            'domains': [
                {
                    'name': 'example.com',
                    'name_servers': ['2.2.2.2']
                },
                {
                    'name': 'old.com',
                    'name_servers': ['9.9.9.9']
                }
            ]
        }
        
        result = compare_configs(new_config, current_config)
        
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [
                        {
                            'name': 'example.com',
                            'name_servers': ['2.2.2.2']
                        },
                        {
                            'name': 'old.com',
                            'name_servers': ['9.9.9.9']
                        }
                    ]
                },
                'created': {
                    'domains': [
                        {
                            'name': 'example.com',
                            'name_servers': ['1.1.1.1']
                        },
                        {
                            'name': 'test.com',
                            'name_servers': ['8.8.8.8']
                        }
                    ]
                }
            }
        )
    
    def test_empty_configs(self):
        """Test comparison with empty configurations"""
        result = compare_configs({}, {})
        self.assertEqual(
            result,
            {
                'deleted': {},
                'created': {}
            }
        )
    
    def test_add_new_domain(self):
        """Test adding a new domain when there are no existing domains"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        current_config = {}
        
        result = compare_configs(new_config, current_config)
        
        self.assertEqual(
            result,
            {
                'deleted': {},
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                }
            }
        )
    
    def test_remove_all_domains(self):
        """Test removing all domains"""
        new_config = {}
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {}
            }
        )
    
    def test_identical_configs(self):
        """Test comparison with identical configurations"""
        config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1', '2.2.2.2']
            }]
        }
        
        result = compare_configs(config, config)
        self.assertEqual(
            result,
            {
                'deleted': {},
                'created': {}
            }
        )

    def test_multiple_nameservers_per_domain(self):
        """Test handling multiple nameservers per domain"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1', '2.2.2.2', '3.3.3.3']
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1', '8.8.8.8']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1', '8.8.8.8']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1', '2.2.2.2', '3.3.3.3']
                    }]
                }
            }
        )

    def test_empty_nameservers(self):
        """Test handling domains with empty nameservers"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': []
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': []
                    }]
                }
            }
        )

    def test_mixed_domain_changes(self):
        """Test multiple domains with different types of changes"""
        new_config = {
            'domains': [
                {
                    'name': 'example.com',  # Modified nameservers
                    'name_servers': ['1.1.1.1', '2.2.2.2']
                },
                {
                    'name': 'new.com',  # New domain
                    'name_servers': ['3.3.3.3']
                }
            ]
        }
        current_config = {
            'domains': [
                {
                    'name': 'example.com',
                    'name_servers': ['8.8.8.8']
                },
                {
                    'name': 'old.com',  # Removed domain
                    'name_servers': ['9.9.9.9']
                }
            ]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [
                        {
                            'name': 'example.com',
                            'name_servers': ['8.8.8.8']
                        },
                        {
                            'name': 'old.com',
                            'name_servers': ['9.9.9.9']
                        }
                    ]
                },
                'created': {
                    'domains': [
                        {
                            'name': 'example.com',
                            'name_servers': ['1.1.1.1', '2.2.2.2']
                        },
                        {
                            'name': 'new.com',
                            'name_servers': ['3.3.3.3']
                        }
                    ]
                }
            }
        )

    def test_duplicate_domains(self):
        """Test handling duplicate domain entries"""
        new_config = {
            'domains': [
                {
                    'name': 'example.com',
                    'name_servers': ['1.1.1.1']
                },
                {
                    'name': 'example.com',  # Duplicate domain
                    'name_servers': ['2.2.2.2']
                }
            ]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['8.8.8.8']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['8.8.8.8']
                    }]
                },
                'created': {
                    'domains': [
                        {
                            'name': 'example.com',
                            'name_servers': ['1.1.1.1']
                        },
                        {
                            'name': 'example.com',
                            'name_servers': ['2.2.2.2']
                        }
                    ]
                }
            }
        )

    def test_case_sensitivity(self):
        """Test case sensitivity in domain names and nameservers"""
        new_config = {
            'domains': [{
                'name': 'EXAMPLE.COM',
                'name_servers': ['1.1.1.1']
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'EXAMPLE.COM',
                        'name_servers': ['1.1.1.1']
                    }]
                }
            }
        )

    def test_additional_fields(self):
        """Test domains with additional configuration fields"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1'],
                'ttl': 300,
                'enabled': True
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1'],
                'ttl': 600,
                'enabled': False
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1'],
                        'ttl': 600,
                        'enabled': False
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1'],
                        'ttl': 300,
                        'enabled': True
                    }]
                }
            }
        )

    def test_nested_domain_config(self):
        """Test domains with nested configuration objects"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1'],
                'advanced': {
                    'dnssec': True,
                    'records': {
                        'mx': ['mail.example.com'],
                        'txt': ['v=spf1 -all']
                    }
                }
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1'],
                'advanced': {
                    'dnssec': False,
                    'records': {
                        'mx': ['old-mail.example.com'],
                        'txt': ['v=spf1 +all']
                    }
                }
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1'],
                        'advanced': {
                            'dnssec': False,
                            'records': {
                                'mx': ['old-mail.example.com'],
                                'txt': ['v=spf1 +all']
                            }
                        }
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1'],
                        'advanced': {
                            'dnssec': True,
                            'records': {
                                'mx': ['mail.example.com'],
                                'txt': ['v=spf1 -all']
                            }
                        }
                    }]
                }
            }
        )

    def test_invalid_nameserver_format(self):
        """Test handling invalid nameserver formats"""
        new_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['invalid.server', None, 123]
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['invalid.server', None, 123]
                    }]
                }
            }
        )

    def test_empty_domain_name(self):
        """Test handling domains with empty names"""
        new_config = {
            'domains': [{
                'name': '',
                'name_servers': ['1.1.1.1']
            }]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {
                    'domains': [{
                        'name': '',
                        'name_servers': ['1.1.1.1']
                    }]
                }
            }
        )

    def test_missing_required_fields(self):
        """Test handling domains with missing required fields"""
        new_config = {
            'domains': [
                {
                    'name_servers': ['1.1.1.1']  # Missing name
                },
                {
                    'name': 'example.com'  # Missing name_servers
                }
            ]
        }
        current_config = {
            'domains': [{
                'name': 'example.com',
                'name_servers': ['1.1.1.1']
            }]
        }
        
        result = compare_configs(new_config, current_config)
        self.assertEqual(
            result,
            {
                'deleted': {
                    'domains': [{
                        'name': 'example.com',
                        'name_servers': ['1.1.1.1']
                    }]
                },
                'created': {
                    'domains': [
                        {
                            'name_servers': ['1.1.1.1']
                        },
                        {
                            'name': 'example.com'
                        }
                    ]
                }
            }
        )

if __name__ == '__main__':
    unittest.main()
