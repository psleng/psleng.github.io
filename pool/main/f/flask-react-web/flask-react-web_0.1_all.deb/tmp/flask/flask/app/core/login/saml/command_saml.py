from app.core.api.http.cmd.command import Command

class SamlCommand(Command):
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource='system')
            self.attributes = {}
            self.cmds = []
            self.vyos_cmds = []
            
        except Exception as e:
            print(f"Error initializing SAML command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds
       
    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data or not isinstance(data, dict):
            return []
        
        saml_config = data.get('login', {}).get('saml')
        if not saml_config:
            return []
        
        if 'name' in saml_config:
            self.generate(self.resource, 'login', 'saml', 'name', saml_config.get('name'))
        
        if 'default_sso_level' in saml_config:
            self.generate(self.resource, 'login', 'saml', 'default-sso-level', saml_config.get('default_sso_level'))

        if 'metadata_url' in saml_config:
            self.generate(self.resource, 'login', 'saml', 'metadata-url', saml_config.get('metadata_url'))
        
        for level in ('admin', 'operator'):
            level_config = saml_config.get(level)
            if not level_config:
                continue

            for attr_name, attr in level_config.get('req', {}).items():
                for value in attr.get('value', []):
                    self.generate(self.resource, 'login', 'saml', level, 'req', attr_name, 'value', value)
            
            for attr_name, attr in level_config.get('suff', {}).items():
                for value in attr.get('value', []):
                    self.generate(self.resource, 'login', 'saml', level, 'suff', attr_name,'value', value)

            user_config = level_config.get('user', [])
            for user in user_config:
                self.generate(self.resource, 'login', 'saml', level, 'user', user)
        
        return self.cmds

if __name__ == "__main__":
    test_saml = {
        "login": {
            "saml": {
                "name": "test-saml-provider",
                "default_sso_level": "admin", 
                "metadata_url": "https://idp.example.com/metadata.xml",
                "admin": {
                    "req": {
                        "uid": {
                            "value": ["admin123", "superadmin"]
                        },
                        "role": {
                            "value": ["administrator"]
                        }
                    },
                    "suff": {
                        "group": {
                            "value": ["admin-group"]
                        }
                    },
                    "user": ["admin_user", "backup_admin"]
                },
                "operator": {
                    "req": {
                        "department": {
                            "value": ["operations", "support"]
                        }
                    },
                    "suff": {
                        "team": {
                            "value": ["ops-team"]
                        }
                    },
                    "user": ["operator1", "operator2"]
                }
            }
        }
    }

    cmd_saml = SamlCommand(operator="set", resource="system")
    commands = cmd_saml.generate_commands(test_saml)
    
    print("SAML commands:")
    for cmd in commands:
        print(cmd)

