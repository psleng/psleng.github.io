class LocalClient():
    def __init__(self):
        pass
    def cmd(*args):
        print("CMD: ")