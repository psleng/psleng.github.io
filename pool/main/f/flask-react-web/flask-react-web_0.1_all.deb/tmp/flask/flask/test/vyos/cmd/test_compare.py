import unittest
from compare import compare_configs

class TestCompareConfigs(unittest.TestCase):
    def test_simple_value_changes(self):
        new_config = {"key": "new_value"}
        current_config = {"key": "old_value"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"key": "old_value"},
            "created": {"key": "new_value"}
        })

    def test_new_key_addition(self):
        new_config = {"existing": "value", "new": "value"}
        current_config = {"existing": "value"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {},
            "created": {"new": "value"}
        })

    def test_key_deletion(self):
        new_config = {"remaining": "value"}
        current_config = {"remaining": "value", "to_delete": "value"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"to_delete": "value"},
            "created": {}
        })

    def test_nested_dictionary_changes(self):
        new_config = {
            "parent": {
                "child1": "new_value",
                "child2": "unchanged"
            }
        }
        current_config = {
            "parent": {
                "child1": "old_value",
                "child2": "unchanged"
            }
        }
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"parent": {"child1": "old_value"}},
            "created": {"parent": {"child1": "new_value"}}
        })

    def test_list_comparison(self):
        new_config = {
            "items": [
                {"id": 1, "value": "one"},
                {"id": 3, "value": "three"}
            ]
        }
        current_config = {
            "items": [
                {"id": 1, "value": "one"},
                {"id": 2, "value": "two"}
            ]
        }
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"items": [{"id": 2, "value": "two"}]},
            "created": {"items": [{"id": 3, "value": "three"}]}
        })

    def test_none_values(self):
        new_config = {"key": None}
        current_config = {"key": "value"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"key": "value"},
            "created": {}
        })

    def test_empty_configs(self):
        new_config = {}
        current_config = {}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {},
            "created": {}
        })

    def test_firewall_config(self):
        new_config = {
            "firewall": {
                "name": {
                    "WAN_IN": {
                        "rule": {
                            "10": {"action": "accept", "protocol": "tcp"},
                            "20": {"action": "drop", "protocol": "udp"}
                        }
                    }
                }
            }
        }
        current_config = {
            "firewall": {
                "name": {
                    "WAN_IN": {
                        "rule": {
                            "10": {"action": "drop", "protocol": "tcp"},
                            "30": {"action": "accept", "protocol": "icmp"}
                        }
                    }
                }
            }
        }
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {
                "firewall": {
                    "name": {
                        "WAN_IN": {
                            "rule": {
                                "10": {"action": "drop"},
                                "30": {"action": "accept", "protocol": "icmp"}
                            }
                        }
                    }
                }
            },
            "created": {
                "firewall": {
                    "name": {
                        "WAN_IN": {
                            "rule": {
                                "10": {"action": "accept"},
                                "20": {"action": "drop", "protocol": "udp"}
                            }
                        }
                    }
                }
            }
        })

    def test_type_changes(self):
        new_config = {"key": {"nested": "string"}}
        current_config = {"key": "simple_value"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"key": "simple_value"},
            "created": {"key": {"nested": "string"}}
        })

    def test_deep_nested_list_comparison(self):
        new_config = {
            "interfaces": {
                "ethernet": {
                    "eth0": {
                        "address": [
                            "192.168.1.1/24",
                            "10.0.0.1/24"
                        ]
                    }
                }
            }
        }
        current_config = {
            "interfaces": {
                "ethernet": {
                    "eth0": {
                        "address": [
                            "192.168.1.1/24",
                            "172.16.0.1/24"
                        ]
                    }
                }
            }
        }
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"interfaces": {"ethernet": {"eth0": {"address": ["172.16.0.1/24"]}}}},
            "created": {"interfaces": {"ethernet": {"eth0": {"address": ["10.0.0.1/24"]}}}}
        })

    def test_empty_list_comparison(self):
        new_config = {"addresses": []}
        current_config = {"addresses": ["192.168.1.1", "10.0.0.1"]}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"addresses": ["192.168.1.1", "10.0.0.1"]},
            "created": {"addresses": []}
        })

    def test_special_characters(self):
        new_config = {"interface-name!": "eth0@1"}
        current_config = {"interface-name!": "eth0@2"}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"interface-name!": "eth0@2"},
            "created": {"interface-name!": "eth0@1"}
        })

    def test_boolean_changes(self):
        new_config = {"enabled": True, "disabled": False}
        current_config = {"enabled": False, "disabled": True}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"enabled": False, "disabled": True},
            "created": {"enabled": True, "disabled": False}
        })

    def test_empty_nested_structures(self):
        new_config = {"parent": {"child": {}}}
        current_config = {"parent": {"child": {"key": "value"}}}
        result = compare_configs(new_config, current_config)
        self.assertEqual(result, {
            "deleted": {"parent": {"child": {"key": "value"}}},
            "created": {"parent": {"child": {}}}
        })

if __name__ == '__main__':
    unittest.main()
