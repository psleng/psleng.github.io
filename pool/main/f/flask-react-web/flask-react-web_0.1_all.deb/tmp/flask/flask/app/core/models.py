import json

from requests.compat import integer_types

from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Float, Text
from sqlalchemy.orm import relationship
from sqlalchemy import text
from typing import List
from pydantic import BaseModel, RootModel, field_validator, Field, ConfigDict
from typing import Optional
import pprint
from app.log.logger import logger

def format_description(desc: str) -> str:
    if not desc:
        return ""
    return desc.replace('_', ' ')


def convert_str(data):
    if isinstance(data, int):
        return str(data)
    elif isinstance(data, str):
        return data
    elif isinstance(data, list):
        return ','.join(data)


class ServiceStatistic(db.Model):
    __tablename__ = 'vyos_service_statistic'
    id = Column(Integer, primary_key=True)
    service_name = Column(String, nullable=True)
    service_feature = Column(String, nullable=True)
    service_stat = Column(String, nullable=True)

    @classmethod
    def init_stat(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
        db.session.add_all([
            ServiceStatistic(service_name='dhcp', service_feature='active_lease', service_stat='0'),
            ServiceStatistic(service_name='dhcp', service_feature='available_ips', service_stat='254'),
            ServiceStatistic(service_name='dhcp', service_feature='lease_time', service_stat='24h'),
            ServiceStatistic(service_name='ntp', service_feature='stratum', service_stat='4'),
            ServiceStatistic(service_name='ntp', service_feature='offset', service_stat='0.49ms'),
            ServiceStatistic(service_name='ntp', service_feature='leap_status', service_stat='Normal'),
            ServiceStatistic(service_name='firewall', service_feature='accepted', service_stat='2'),
            ServiceStatistic(service_name='firewall', service_feature='dropped', service_stat='0'),
            ServiceStatistic(service_name='firewall', service_feature='total', service_stat='2'),
            ServiceStatistic(service_name='dns', service_feature='servers', service_stat='3'),
            ServiceStatistic(service_name='nat', service_feature='source-traffic', service_stat='2.9'),
            ServiceStatistic(service_name='nat', service_feature='source-packets', service_stat='6'),
            ServiceStatistic(service_name='nat', service_feature='dest-traffic', service_stat='1048576 '),
            ServiceStatistic(service_name='nat', service_feature='dest-packets', service_stat='4')
            
              ])
        db.session.commit()


    @classmethod
    def reset_stat_by_service(cls, service_name: str):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__} WHERE service_name = '{service_name}'"))
        db.session.commit()


    @classmethod
    def refresh_stats(cls, stats):
        try:
            for service, features in stats.items():
                for feature, value in features.items():
                    stat_record = cls.query.filter_by(service_name=service, service_feature=feature).first()
                    if stat_record:
                        stat_record.service_stat = str(value)
                    else:
                        new_stat = cls(service_name=service, service_feature=feature, service_stat=str(value))
                        db.session.add(new_stat)
            db.session.commit()
        except Exception as e:
            logger.error(f"Failed to refresh service stats: {e}")
            raise


class SystemDefault(db.Model):
    __tablename__ = 'vyos_system_default'
    id = Column(Integer, primary_key=True)
    country_code = Column(Text, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        logger.debug("Refresh SystemDefault data")
        if app_context is not None:
            with app_context:
                SystemDefault.truncate()
        else:
            SystemDefault.truncate()
        
        country_code = data.get('country_code')
        if not country_code:
            return
        
        if isinstance(country_code, list):
            country_code = ','.join(country_code)
        
        new_data = SystemDefault(
            country_code=country_code
        )
        if app_context is not None:
            with app_context:
                db.session.add(new_data)
                db.session.commit()
        else:
            db.session.add(new_data)
            db.session.commit()
    
    @classmethod
    def get_def_by_name(cls, name: str):
        # Use getattr to get the column attribute from the class
        column = getattr(cls, name)
        return db.session.query(cls).with_entities(column).first()
    
    
class ServiceState(db.Model):

    __tablename__ = 'vyos_service_state'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)
    status = Column(String, nullable=True)

    @classmethod
    def set_state(cls, name: str, status: str):
        try:
            # Check if service existed
            service = db.session.query(cls).filter_by(name=name).first()
            if service:
                service.status = status
                db.session.commit()
            else:
                new_service = cls(name=name, status=status)
                db.session.add(new_service)
                db.session.commit()
        except Exception as e:
            logger.error("Error setting service state:")
            logger.error(str(e))

    @classmethod
    def get_state(cls, name: str):
        service = db.session.query(cls).filter_by(name=name).first()
        return service.status if service else None
        

class System(db.Model):

    __tablename__ = 'vyos_system'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)
    domain_name = Column(String, nullable=True)
    uptime = Column(String, nullable=True)
    datetime = Column(String, nullable=True)
    boot_img_name = Column(String, nullable=True)
    boot_img_running = Column(Boolean, default=True)
    boot_img_default = Column(Boolean, default=True)
    ipv6_status = Column(Boolean, default=True)
    wireless_country_code = Column(String, nullable=True)


    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        logger.debug("Refresh System data")
        if app_context is not None:
            with app_context:
                System.truncate()
        else:
            System.truncate()
        new_data = System(
            name=data.get('name'),
            domain_name=data.get('domain_name'),
            datetime=data.get('datetime'),
            uptime=data.get('uptime'),
            boot_img_name=data.get('boot_img_name'),
            boot_img_running=data.get('boot_img_running'),
            boot_img_default=data.get('boot_img_default'),
            wireless_country_code=data.get('system', "")
        )
        if app_context is not None:
            with app_context:
                db.session.add(new_data)
                db.session.commit()
        else:
            db.session.add(new_data)
            db.session.commit()

    @classmethod
    def set_ipv6_status(cls, data: dict):
        if not data:
            return
        if 'ipv6' not in data:
            return
        
        system_config = System.query.first()
        if system_config:
            system_config.ipv6_status = True if 'block' not in data['ipv6'] else False
            db.session.commit()

    def serialize(self):
        return {
            "name": self.name,
            "domain_name": self.domain_name,
            "datetime": self.datetime,
            "uptime": self.uptime,
            "boot_img_name": self.boot_img_name,
            "boot_img_running": self.boot_img_running,
            "boot_img_default": self.boot_img_default,
            "ipv6_status": self.ipv6_status,
            "wireless_country_code": self.wireless_country_code
        }

    @classmethod
    def set_wireless_country_code(cls, country_code: str):
        if not country_code:
            return
        system_config = System.query.first()
        if system_config:
            system_config.wireless_country_code = country_code
            db.session.commit()

class Memory(db.Model):

    __tablename__ = 'vyos_memory'

    id = Column(Integer, primary_key=True)
    free = Column(Float, default=0)
    used = Column(Float, default=0)
    date = Column(String, nullable=True)
    time = Column(String, nullable=True)
    utc_timestamp = Column(String, nullable=True)


    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    
    @classmethod
    def refresh(cls, data: dict, app_context=None):
        print("Refresh Memory data")
        new_data = Memory(
            free=data.get('memory').get('free'),
            used=data.get('memory').get('used'),
            date=data.get('timestamp')[0],
            time=data.get('timestamp')[1],
            utc_timestamp=data.get('utc_timestamp')
        )
        if app_context is not None:
            with app_context:
                Memory.truncate()
                db.session.add(new_data)
                db.session.commit()
        else:
            Memory.truncate()
            db.session.add(new_data)
            db.session.commit()

class Interface(db.Model):
    __tablename__ = 'vyos_operation_interface'
    
    id = Column(Integer, primary_key=True)
    admin_state = Column(String, nullable=True)
    group = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    interface_type = Column(String, nullable=True)
    ipv4 = Column(String, nullable=True)
    ipv4_addresses = Column(String, nullable=True)
    ipv4_ranges = Column(String, nullable=True)
    ipv4_scope = Column(String, nullable=True)
    ipv4_global = Column(String, default=False)
    ipv4_global_range = Column(String, nullable=True)
    ipv4_mode = Column(String, default='static')
    ipv6 = Column(String, nullable=True)
    ipv6_addresses = Column(String, nullable=True)
    ipv6_ranges = Column(String, nullable=True)
    ipv6_scope = Column(String, nullable=True)
    ipv6_global = Column(String, default=False)
    ipv6_global_range = Column(String, nullable=True)
    ipv6_mode = Column(String, default='autoconf')
    mac_address = Column(String, nullable=True)
    mtu = Column(Integer, nullable=True)
    preferred_lft = Column(String, nullable=True)
    qdisc = Column(String, nullable=True)
    qlen = Column(Integer, nullable=True)
    rx_bytes = Column(Integer, nullable=True)
    rx_packets = Column(Integer, nullable=True)
    state = Column(String, nullable=True)
    tx_bytes = Column(Integer, nullable=True)
    tx_packets = Column(Integer, nullable=True)
    valid_lft = Column(String, nullable=True)
    desc = Column(String, nullable=True)
    flags = Column(String, nullable=True)
    speed = Column(String, nullable=True)
    redirect = Column(String, nullable=True)
    host_name = Column(String, nullable=True)
    hw_id = Column(String, nullable=True)
    bridge_mode = Column(String, nullable=True)
    deletable = Column(Boolean, default=True)
    editable = Column(Boolean, default=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def update_interface_by_name(cls, name: str, ipv4: str, desc: str):
        intf = db.session.query(Interface).filter_by(interface=name).first()
        if intf:
            intf.ipv4 = ipv4
            intf.desc = desc
            db.session.commit()

    @classmethod
    def get_interface_names(cls):
        ifaces = []
        names = db.session.query(Interface.interface).all()
        for name in names:
            # Don't take loopback and dummy ifaces
            if not name[0].startswith("lo") and not name[0].startswith("dum"):
                ifaces.append(name[0])
        return ifaces

    @classmethod
    def create_ipv4(cls, name: str, ipv4: str):
        
        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                ip_range = ipv4.split('/')
                if len(ip_range) == 2:
                    ip_addr = ip_range[0]
                    range_val = ip_range[1]
                    
                    ips = intf.ipv4.split(',') if intf.ipv4 and intf.ipv4.strip() else []
                    ranges = intf.ipv4_ranges.split(',') if intf.ipv4_ranges and intf.ipv4_ranges.strip() else []
                    
                    if ip_addr not in ips:
                        ips.append(ip_addr)
                    if range_val not in ranges:
                        ranges.append(range_val)
                    
                    ips_str = ','.join(ips) if ips else ''
                    ranges_str = ','.join(ranges) if ranges else ''
                    
                    intf.ipv4 = ips_str
                    intf.ipv4_addresses = ips_str
                    intf.ipv4_ranges = ranges_str
                    intf.ipv4_scope = "global"
                    intf.ipv4_global = ips_str
                    intf.ipv4_global_range = ranges_str
                    intf.ipv4_mode = "static"

                    db.session.commit()
        except Exception as e:
            print("Error:", str(e))

    @classmethod
    def update_ipv4(cls, name: str, current_ip: str, new_ip: str):

        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                current_ip_range = current_ip.split('/')
                new_ip_range = new_ip.split('/')
                
                ips = intf.ipv4.split(',')
                ranges = intf.ipv4_ranges.split(',')
                indx = ips.index(current_ip_range[0])
                
                ips[indx] = new_ip_range[0]
                ranges[indx] = new_ip_range[1]

                intf.ipv4_ranges = convert_str(ranges)
                intf.ipv4 = convert_str(ips)
                intf.ipv4_addresses = convert_str(ips)

                db.session.commit()
        except Exception as e:
            print("Error:", str(e))


    @classmethod
    def delete_ipv4(cls, name: str, ipv4: str):
            
        try:
            intf = db.session.query(Interface).filter_by(interface=name).first()
            if intf:
                ip_range = ipv4.split('/')
                
                ips = intf.ipv4.split(',')
                ranges = intf.ipv4_ranges.split(',')
                indx = ips.index(ip_range[0])
                
                del ips[indx]
                del ranges[indx]

                intf.ipv4_ranges = convert_str(ranges)
                intf.ipv4 = convert_str(ips)
                intf.ipv4_addresses = convert_str(ips)
                
                db.session.commit()    
        except Exception as e:
            logger.error("Error:")
            logger.error(str(e))

    @classmethod
    def process_bridge_member(cls, data, config_data):
        bridge_intf = {}
        interface_data = []
        if 'ShowInterfaces' in data and 'data' in data['ShowInterfaces'] and \
            'result' in data['ShowInterfaces']['data']:
            interface_data = data['ShowInterfaces']['data']['result']
        else:
            interface_data = data
            
        for d in interface_data:
                
            interface_type = d.get('link_type', d.get('interface_type', ''))
            interface_name = d.get('ifname', d.get('interface', ''))

            if interface_type == 'ether':
                if interface_name.startswith('br'):
                    interface_type = 'Bridge'

            if interface_type == 'Bridge':
                if 'member' in config_data['bridge'][interface_name] and 'interface' in config_data['bridge'][interface_name]['member']:
                    for child_intf in config_data['bridge'][interface_name]['member']['interface']:
                        bridge_intf[child_intf] = interface_name
        
        return bridge_intf

    @classmethod
    def refresh(cls, data, config_data, app_context=None):
        # print("Config Data:")
        # print(pprint.pformat(config_data.json()['data'], indent=2, width=80))
        conf = config_data.json()['data']
        bridge_intf = cls.process_bridge_member(data, conf)
        logger.debug("Bridge interface members: ")
        logger.debug(bridge_intf)
        try:
            logger.debug('== New Interface Table ==')
            if app_context is not None:
                with app_context:
                    Interface.truncate()
            else:
                Interface.truncate()
            
            if 'ShowInterfaces' in data and 'data' in data['ShowInterfaces'] and \
                'result' in data['ShowInterfaces']['data']:
                interface_data = data['ShowInterfaces']['data']['result']
            else:
                interface_data = data
                
            for d in interface_data:
                ipv4_addresses = []
                ipv4_ranges = []
                ipv4_scope = []
                ipv6_addresses = []
                ipv6_ranges = []
                ipv6_scope = []
                ipv4_global = []
                ipv4_global_range = []
                ipv6_global = []
                ipv6_global_range = []
                preferred_lft = ''
                valid_lft = ''
                ipv4_mode = []
                ipv6_mode = []

                address_config = []
                
                interface_type = d.get('link_type', d.get('interface_type', ''))
                interface_name = d.get('ifname', d.get('interface', ''))

                if interface_type == 'ether':
                    if interface_name.startswith('br'):
                        interface_type = 'Bridge'
                    elif interface_name.startswith('eth'):
                        interface_type = 'Ethernet'
                    elif interface_name.startswith('wlan'):
                        interface_type = 'Wireless'
                elif interface_type == 'loopback':
                    interface_type = 'Loopback'
                elif interface_name.startswith('vtun'):
                    interface_type = 'OpenVPN'
                elif interface_name.startswith('wg'):
                        interface_type = 'Wireguard'
                
                if 'wwan' in interface_name:
                    interface_type = 'Cellular'

                # Ensure interface_type is a string before calling .lower()
                if isinstance(interface_type, list):
                    interface_type = interface_type[0] if interface_type else ''
                if not isinstance(interface_type, str):
                    interface_type = str(interface_type)
                format_iface_type = interface_type.lower()
                if format_iface_type in conf and interface_name in conf[format_iface_type] \
                    and 'address' in conf[format_iface_type][interface_name]:
                    address_config = conf[format_iface_type][interface_name]['address']

                # print("Address Config: ")
                # print(address_config)
                    
                if 'addr_info' in d:
                    for addr in d['addr_info']:
                        if addr.get('family') == 'inet' and 'local' in addr:
                            ipv4_addresses.append(addr['local'])
                            prefix = addr.get('prefixlen', '')
                            ipv4_ranges.append(f"{prefix}")
                            ipv4_scope.append(addr.get('scope', ''))

                            ipAddr = addr['local'] + '/' + str(prefix)
                            # print("IP: ", ipAddr)

                            if len(address_config) > 0:
                                if ipAddr in address_config:
                                    ipv4_mode.append('static')
                                elif addr.get('scope', '') == 'global':
                                    ipv4_mode.append('dhcp')
                                else:
                                    ipv4_mode.append('static')
                            
                            if addr.get('scope', '') == 'global':
                                ipv4_global.append(addr['local'])
                                ipv4_global_range.append(f"{prefix}")
                            if not preferred_lft and 'preferred_life_time' in addr:
                                preferred_lft = str(addr['preferred_life_time'])

                                if preferred_lft == '4294967295':
                                    preferred_lft = 'forever'
                                else:
                                    preferred_lft = f"{preferred_lft}sec"
                            if not valid_lft and 'valid_life_time' in addr:
                                valid_lft = str(addr['valid_life_time'])

                                if valid_lft == '4294967295':
                                    valid_lft = 'forever'
                                else:
                                    valid_lft = f"{valid_lft}sec"
                        elif addr.get('family') == 'inet6' and 'local' in addr:
                            ipv6_addresses.append(addr['local'])
                            prefix = addr.get('prefixlen', '')
                            ipv6_ranges.append(f"{prefix}")
                            ipv6_scope.append(addr.get('scope', ''))

                            if (addr['local'] + '/' + str(prefix)) in address_config:
                                ipv6_mode.append('static')
                            elif addr.get('scope', '') == 'global':
                                ipv6_mode.append('dhcp')
                            else:
                                ipv6_mode.append('static')

                            if addr.get('scope', '') == 'global':
                                ipv6_global.append(addr['local'])
                                ipv6_global_range.append(f"{prefix}")
                            if not preferred_lft and 'preferred_life_time' in addr:
                                preferred_lft = str(addr['preferred_life_time'])

                                if preferred_lft == '4294967295':
                                    preferred_lft = 'forever'
                                else:
                                    preferred_lft = f"{preferred_lft}sec"
                            if not valid_lft and 'valid_life_time' in addr:
                                valid_lft = str(addr['valid_life_time'])

                                if valid_lft == '4294967295':
                                    valid_lft = 'forever'
                                else:
                                    valid_lft = f"{valid_lft}sec"
                
                mac_address = d.get('address', d.get('mac_address', ''))
                mtu = d.get('mtu', 0)
                qdisc = d.get('qdisc', '')
                txqlen = d.get('txqlen', d.get('qlen', 0))
                
                rx_bytes = 0
                rx_packets = 0
                tx_bytes = 0
                tx_packets = 0
                if 'stats' in d:
                    rx_bytes = d['stats'].get('rx_bytes', 0)
                    rx_packets = d['stats'].get('rx_packets', 0)
                    tx_bytes = d['stats'].get('tx_bytes', 0)
                    tx_packets = d['stats'].get('tx_packets', 0)
                else:
                    rx_bytes = d.get('rx_bytes', 0)
                    rx_packets = d.get('rx_packets', 0)
                    tx_bytes = d.get('tx_bytes', 0)
                    tx_packets = d.get('tx_packets', 0)
                
                state = d.get('operstate', d.get('state', ''))
                admin_state = 'UP' if 'UP' in d.get('flags', []) else 'DOWN'
                
                description = d.get('description', d.get('desc', ''))
                flags = d.get('flags', d.get('flags', []))
                

                deletable = True
                if interface_type in ['Loopback', 'Ethernet']:
                    deletable = False
                
                if isinstance(flags, list):
                    flags_str = str(flags)
                else:
                    flags_str = str(flags)
                
                new_interface = Interface(
                    group=d.get('group', 'default'),
                    interface=interface_name,
                    interface_type=interface_type,
                    ipv4=convert_str(ipv4_addresses),
                    ipv4_addresses=convert_str(ipv4_addresses),
                    ipv4_ranges=convert_str(ipv4_ranges),
                    ipv6=convert_str(ipv6_addresses),
                    ipv6_addresses=convert_str(ipv6_addresses),
                    ipv6_ranges=convert_str(ipv6_ranges),
                    mac_address=mac_address,
                    mtu=mtu,
                    preferred_lft=preferred_lft,
                    qdisc=qdisc,
                    qlen=txqlen,
                    rx_bytes=rx_bytes,
                    rx_packets=rx_packets,
                    state=state,
                    admin_state=admin_state,
                    tx_bytes=tx_bytes,
                    tx_packets=tx_packets,
                    valid_lft=valid_lft,
                    desc=format_description(description),
                    flags=flags_str,
                    hw_id=d.get('hw-id', ''),
                    speed=d.get('speed', ''),
                    host_name=d.get('host_name', ''),
                    redirect=d.get('redirect', ''),
                    bridge_mode=bridge_intf.get(interface_name, ''),
                    deletable=deletable,
                    editable=True,
                    ipv4_scope=convert_str(ipv4_scope),
                    ipv6_scope=convert_str(ipv6_scope),
                    ipv4_global=convert_str(ipv4_global),
                    ipv6_global=convert_str(ipv6_global),
                    ipv4_global_range=convert_str(ipv4_global_range),
                    ipv6_global_range=convert_str(ipv6_global_range),
                    ipv4_mode=convert_str(ipv4_mode),
                    ipv6_mode=convert_str(ipv6_mode),                    
                )
                
                if app_context is not None:
                    with app_context:
                        db.session.add(new_interface)
                else:
                    db.session.add(new_interface)
                    
            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
        except Exception as e:
            logger.error('Create interface error')
            logger.error(str(e))

    def serialize(self):
        ipv4_list = []
        ipv6_list = []
        ipv4_scope_list = []
        ipv6_scope_list = []
        ipv4_global = ''
        ipv6_global = ''
        ipv4_global_range = ''
        ipv6_global_range = ''
        ipv4_mode = []
        ipv6_mode = []
        
        if self.ipv4_addresses and self.ipv4_ranges:
            ipv4_list = list(zip(self.ipv4_addresses.split(',') , self.ipv4_ranges.split(',')))
        if self.ipv6_addresses and self.ipv6_ranges:
            ipv6_list = list(zip(self.ipv6_addresses.split(','), self.ipv6_ranges.split(',')))
        if self.ipv4_scope:
            ipv4_scope_list = self.ipv4_scope.split(',')
        if self.ipv6_scope:
            ipv6_scope_list = self.ipv6_scope.split(',')
        if self.ipv4_global:
            ipv4_global = self.ipv4_global.split(',')[0]
        if self.ipv6_global:
            ipv6_global = self.ipv6_global.split(',')[0]
        if self.ipv4_global_range:
            ipv4_global_range = self.ipv4_global_range.split(',')[0]
        if self.ipv6_global_range:
            ipv6_global_range = self.ipv6_global_range.split(',')[0]

        if self.ipv4_mode:
            ipv4_mode = self.ipv4_mode.split(',')
        if self.ipv6_mode:
            ipv6_mode = self.ipv6_mode.split(',')
        # convert flags string to a list
        flags_list = []
        if self.flags:
            flags_string = self.flags.strip("[]").replace("'", "").replace('"', "")
            if flags_string:
                flags_list = [flag.strip() for flag in flags_string.split(',')]

        return {
            "group": self.group,
            "interface": self.interface,
            "interface_type": self.interface_type,
            "ipv4": ipv4_list,
            "ipv4_addresses": self.ipv4_addresses,
            "ipv4_ranges": self.ipv4_ranges,
            "ipv6": ipv6_list,
            "ipv6_addresses": self.ipv6_addresses,
            "ipv6_ranges": self.ipv6_ranges,
            "mac_address": self.mac_address,
            "mtu": self.mtu,
            "preferred_lft": self.preferred_lft,
            "qdisc": self.qdisc,
            "qlen": self.qlen,
            "rx_bytes": self.rx_bytes,
            "rx_packets": self.rx_packets,
            "state": self.state,
            "admin_state": self.admin_state,
            "tx_bytes": self.tx_bytes,
            "tx_packets": self.tx_packets,
            "valid_lft": self.valid_lft,
            "desc": self.desc,
            "speed": self.speed,
            "host_name": self.host_name,
            "redirect": self.redirect,
            "hw_id": self.hw_id,
            "flags": str(self.flags),
            "flags_list": flags_list,
            "bridge_mode": self.bridge_mode,
            "ipv4_scope": ipv4_scope_list,
            "ipv6_scope": ipv6_scope_list,
            "ipv4_global": ipv4_global,
            "ipv6_global": ipv6_global,
            "ipv4_global_range": ipv4_global_range,
            "ipv6_global_range": ipv6_global_range,
            "ipv4_mode": ipv4_mode,
            "ipv6_mode": ipv6_mode,
        }