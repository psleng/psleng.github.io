SHOW_ALL_CONFIGS = '{"op": "showConfig", "path": []}'
SHOW_INTERFACE_CONFIGS = '{"op": "showConfig", "path": ["interfaces"]}'
SHOW_INTERFACE_VALUES = '{"op": "show", "path": ["interfaces", "detail"]}'
SHOW_SYSTEMS_UPTIME = '{"op": "show", "path": ["system", "uptime"]}'
SHOW_SYSTEMS_MEMORY = '{"op": "show", "path": ["system", "memory"]}'

SHOW_SYSTEMS_SENSORS = '{"op": "show", "path": ["environment", "sensors"]}'
SHOW_SYSTEMS_DATE = '{"op": "show", "path": ["host", "date"]}'
SHOW_SYSTEMS_TIMEZONE = '{"op": "showConfig", "path": ["system", "time-zone"]}'
SHOW_SYSTEMS_BOOT_IMG = '{"op": "show", "path": ["system", "image"]}'
SHOW_SYSTEMS_NAME = '{"op": "show", "path": ["host", "name"]}'
SHOW_SYSTEMS_VERSION = '{"op": "show", "path": ["version"]}'

SHOW_SYSTEM_ALL_COMMITS = '{"op": "show", "path": ["system", "commit"]}'
SHOW_SYSTEM_DOMAIN = '{"op": "showConfig", "path": ["system", "domain-name"]}'

SHOW_DNS = '{"op": "showConfig", "path": ["service", "dns"]}'
SHOW_NAME_SERVERS = '{"op": "showConfig", "path": ["system", "name-server"]}'
SHOW_DNS_DYNAMIC = '{"op": "showConfig", "path": ["service", "dns", "dynamic"]}'

SHOW_DNS_FORWARD_CACHE_SIZE = '{"op": "showConfig", "path": ["service", "dns", "forwarding", "cache-size"]}'
SHOW_DNS_FORWARD_CACHE_SECONDS = '{"op": "show", "path": ["service", "dns", "forward-cache-seconds"]}'

SET_DNS_FORWARD_IGNORE_HOSTFILE = '{"op": "set", "path": ["service", "dns", "forwarding", "ignore-hosts-file"]}'

SHOW_FIREWALL_CONFIG = '{"op": "showConfig", "path": ["firewall"]}'
SHOW_FIREWALL_OPR = '{"op": "show", "path": ["firewall"]}'

SHOW_DHCP_CONFIG = '{"op": "showConfig", "path": ["service", "dhcp-server"]}'
SHOW_DHCPV6_CONFIG = '{"op": "showConfig", "path": ["service", "dhcpv6-server"]}'
SHOW_DHCP_RELAY_CONFIG = '{"op": "showConfig", "path": ["service", "dhcp-relay"]}'

SHOW_NTP_CONFIG = '{"op": "showConfig", "path": ["service", "ntp"]}'

SHOW_RAM_TOTAL_LINUX = "lsmem -b --summary=only"

SHOW_RAM_USED_LINUX = "free -m"

SHOW_NTP_SYSTEM = '{"op": "show", "path": ["ntp", "system"]}'
SHOW_NTP_SOURCE = '{"op": "show", "path": ["ntp", "source"]}'

SHOW_INTERFACE_ETHERNET = '{"op": "showConfig", "path": ["interfaces", "ethernet"]}'
SHOW_INTERFACE_WIFI = '{"op": "showConfig", "path": ["interfaces", "wireless"]}'
SHOW_ROUTER_ADVERTISEMENT = '{"op": "showConfig", "path": ["service", "router-advert"]}'

SHOW_SYSTEM = '{"op": "showConfig", "path": ["system"]}'

SHOW_GENERAL_ROUTING = '{"op": "showConfig", "path": ["protocols", "static", "route"]}'
SHOW_GENERAL_ROUTING_V6 = '{"op": "showConfig", "path": ["protocols", "static", "route6"]}'

SHOW_USER_CONFIG = '{"op": "showConfig", "path": ["system", "login", "user"]}'
SHOW_LOGIN_CONFIG = '{"op": "showConfig", "path": ["system", "login"]}'

SHOW_WIREGUARD_GENERATE_KEY_PAIR = '{"op": "generate", "path": ["pki", "wireguard", "key-pair"]}'

class Command:
    def __init__(self, operator: str, resource: str):
        self.operator = operator
        self.resource = resource
        self.prefix = '{"op":'
        self.suffix = ']}'
        self.commands: list[str] = []
        self.vyos_commands: list[str] = []

    def generate_commands(self) -> list[str]:
        op = f'"{self.operator}"'
        rs = f'"{self.resource}"'
        command = f'{self.prefix}{op}, "path": [{rs}{self.suffix}'
        self.commands = [command]
        return self.commands

    def get_vyos_commands(self) -> list[str]:
        return self.vyos_commands