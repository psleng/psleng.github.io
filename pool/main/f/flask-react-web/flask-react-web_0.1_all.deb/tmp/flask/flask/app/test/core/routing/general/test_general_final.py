import pytest
from app.core.routing.models import UpdateGeneralRoutingDTO
from app.test.core.base import TestFinal
from app.test.core.routing.general.test_cases._test_case_final import test_final
from app.core.routing.command_routing import RoutingCommand

class TestGeneralRoutingUpdateFinal(TestFinal):
    __test__ = False # Skip the test
    
    @pytest.fixture
    def service(self):
        return "routing"

    @pytest.fixture
    def cmd_set(self):
        return RoutingCommand(operator='set', resource='ipv4')
    
    @pytest.fixture
    def cmd_delete(self):
        return RoutingCommand(operator='delete', resource='ipv4')
    
    @pytest.fixture
    def parser(self):
        from app.core.routing.parsers import parse_to_route_config
        return parse_to_route_config
    
    @pytest.fixture
    def dto_model(self):
        return UpdateGeneralRoutingDTO
    
    @pytest.mark.parametrize("test_data", test_final)
    def test_general_routing_update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data):
        super()._update_final(
            success_verification=success_verification,
            parser=parser,
            dto_model=dto_model,
            test_service_provider=test_service_provider,
            cmd_set=cmd_set,
            cmd_delete=cmd_delete,
            test_data=test_data
        )
