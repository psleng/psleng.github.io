import pytest
from app.test.core.base import TestParseInput
from app.core.network.dhcp.models import UpdateDHCPDTO
from app.core.network.dhcp.parser import parse_dhcp_config
from app.test.core.network.dhcp.test_cases._test_case_parse_input import test_valid, test_invalid, test_minimal, test_compare


class TestDHCPParseInput(TestParseInput):
    """Test class for DHCP parse input functionality"""
    __test__ = True

    @pytest.mark.parametrize("test_data", test_valid)
    def test_model_validate_json_valid(self, test_data):
        super().test_model_validate_json_valid(test_data, UpdateDHCPDTO)

    @pytest.mark.parametrize("test_data", test_invalid)
    def test_model_validate_json_invalid(self, test_data):
        super().test_model_validate_json_invalid(test_data, UpdateDHCPDTO)

    @pytest.mark.parametrize("test_data", test_minimal)
    def test_model_validate_minimal_json(self, test_data):
        super().test_model_validate_minimal_json(test_data, UpdateDHCPDTO)

    @pytest.mark.parametrize("test_data", test_compare)
    def test_compare_configs_additions(self, test_data):
        super().test_compare_configs_additions(test_data)