from flask import Blueprint

salt_bp = Blueprint('salt', __name__)

from . import routes