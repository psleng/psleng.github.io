from flask_apscheduler import APScheduler
from app.event.jobs.interface.fetch_interface import fetch_interface_opr
from app.event.jobs.system.performance import fetch_memory
from app.event.jobs.system.system_info import fetch_info
from app.core.network.dns.jobs.dns_server import fetch_dns_server_job
from app.core.security.jobs.firewall import fetch_firewall_job, fetch_firewall_opr_job, fetch_firewall_opr_log_job
from app.core.network.dns.jobs.dns import fetch_dns_job
from app.core.network.nat.jobs.nat import fetch_nat_job
from app.core.network.dhcp.jobs.dhcp_server import fetch_dhcp_job
from app.core.network.dhcp.jobs.dhcp_relay import fetch_dhcp_relay_job
from app.core.network.dhcp.jobs.dhcp_server import fetch_dhcpv6_job
from app.core.service.config import fetch_country_code
from app.event.jobs.system.config import fetch_os_config, fetch_service_stat, fetch_init_service_stat
from app.config.models import Interval
from app.scheduler.models import Job
from logging import getLogger, DEBUG
from flask import current_app

from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR, EVENT_JOB_ADDED
from app.scheduler.utils import run_once, run_concurrent
logger = getLogger(__name__)
logger.setLevel(DEBUG)

def init_scheduler(app):

    scheduler = APScheduler()
    scheduler.api_enabled = True
    scheduler.init_app(app)

    scheduler.scheduler.configure(
        {
            'apscheduler.executors.default': {
                'class': 'apscheduler.executors.pool:ThreadPoolExecutor',
                'max_workers': '1'  # sequential execution
            },
            'apscheduler.job_defaults.coalesce': 'true',  # Combine missed executions into a single one
            'apscheduler.job_defaults.max_instances': '1'  # Only allow one instance of each job
        }
    )
    
    scheduler.scheduler.add_listener(job_executed_event, EVENT_JOB_EXECUTED)
    scheduler.scheduler.add_listener(job_error_event, EVENT_JOB_ERROR)
    scheduler.scheduler.add_listener(job_added_event, EVENT_JOB_ADDED)

    return scheduler

def job_executed_event(event):
    """Log when a job is successfully executed"""
    logger.debug(f"Job {event.job_id} executed successfully")

def job_error_event(event):
    """Log when a job execution fails"""
    logger.error(f"Job {event.job_id} failed with exception: {event.exception}")

def job_added_event(event):
    """Log when a new job is added to the scheduler"""
    logger.debug(f"Job {event.job_id} was added to the scheduler")

def schedule_jobs(scheduler_instance, app_context):
    """ 
    Decorator-based job scheduling with sequential execution
    """
    @run_once
    def _schedule_jobs(app_context):
        logger.debug("Scheduling jobs...")
        print("Scheduling jobs...")
        print("Current app context")
        print(current_app.app_context())
        
        intf = {
            'quick': 10,
            'normal': 30,
            'slow': 60,
            'xslow': 300
        }
        
        job_configs = [
            {
                'id': 'fetch_interfaces_operation',
                'func': fetch_interface_opr,
                'interval': intf.get('normal')
            },
            {
                'id': 'fetch_memory',
                'func': fetch_memory,
                'interval': intf.get('slow')
            },
            {
                'id': 'fetch_system_info',
                'func': fetch_info,
                'interval': intf.get('xslow')
            },
            {
                'id': 'fetch_firewall_opr',
                'func': fetch_firewall_opr_job,
                'interval': intf.get('xslow')
            },
            {
                'id': 'fetch_firewall_opr_log',
                'func': fetch_firewall_opr_log_job,
                'interval': intf.get('xslow')
            },
            {
                'id': 'fetch_os_config',
                'func': fetch_os_config,
                'interval': intf.get('xslow')
            },
            {
                'id': 'fetch_init_service_stat',
                'func': fetch_service_stat,
                'interval': intf.get('xslow')
            }
        ]
        
        # Add jobs with sequential execution configuration
        for job in job_configs:
            if scheduler_instance.get_job(id=job['id']) is None:
                scheduler_instance.add_job(
                    id=job['id'],
                    func=job['func'],
                    args=[app_context],
                    trigger="interval",
                    seconds=job['interval'],
                    misfire_grace_time=None,  # Don't skip missed executions
                    coalesce=True,  # Combine missed executions
                    max_instances=1  # Only one instance at a time
                )
        
        return True
    
    return _schedule_jobs(app_context)

def init_jobs(app_context):

    @run_once
    # @run_concurrent(max_workers=5)  # Run up to 5 jobs concurrently
    def _init_jobs(app_context):
        logger.debug("Initializing jobs...")
        print("Initializing jobs...")

        with app_context:
            fetch_info(app_context),
            fetch_interface_opr(app_context),
            fetch_memory(app_context),
            fetch_firewall_opr_job(app_context),
            fetch_firewall_opr_log_job(app_context),
            fetch_os_config(app_context),
            fetch_country_code(app_context),
            fetch_init_service_stat(app_context)
        # Return list of jobs to run concurrently
        # return [
        #     lambda _: fetch_info(app_context),
        #     lambda _: fetch_interface_opr(app_context),
        #     lambda _: fetch_memory(app_context),
        #     lambda _: fetch_dns_server_job(app_context),
        #     lambda _: fetch_dns_job(app_context),
        #     lambda _: fetch_firewall_job(app_context),
        #     lambda _: fetch_firewall_opr_job(app_context),
        #     lambda _: fetch_firewall_opr_log_job(app_context),
        # ]
    
    _init_jobs(app_context)