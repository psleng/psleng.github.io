from app import create_app
# app = create_app()

app, socketio = create_app()

def socket_app():
    pass

if __name__ == "__main__":
    # app.run(host="0.0.0.0", port=80, debug=True)
    socketio.run(
        app,
        host="0.0.0.0", port=80, debug=True, 
        allow_unsafe_werkzeug=True
    )
    # pass