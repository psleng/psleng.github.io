from flask import Blueprint, jsonify
from .models import Page, SubPage, Feature, SubPageFeature
from . import config_bp

@config_bp.route('/pages', methods=['GET'])
def get_pages():
    pages = Page.query.all()
    pages_data = []

    sub_page_features = SubPageFeature.query.all()
    features_by_sub_page = {}
    for feature in sub_page_features:
        features_by_sub_page.setdefault(feature.sub_page_id, []).append({
            'id': feature.feature_id,
            'name': feature.feature_name,
            'enabled': feature.enabled
        })

    for page in pages:
        page_info = {
            'page_id': page.page_id,
            'page_name': page.page_name,
            'page_url': page.page_url,
            'enabled': page.enabled,
            'sub_pages': [
                {
                    'id': sub_page.sub_page_id,
                    'name': sub_page.sub_page_name,
                    'url': sub_page.sub_page_url,
                    'enabled': sub_page.enabled,
                    'features': features_by_sub_page.get(sub_page.sub_page_id, [])
                } for sub_page in page.sub_pages
            ]
        }
        pages_data.append(page_info)
    
    return jsonify(pages_data)

@config_bp.route('/features', methods=['GET'])
def get_features():
    features = Feature.query.all()
    features_data = [
        {
            'feature_id': feature.feature_id,
            'feature_name': feature.feature_name,
            'enabled': feature.enabled
        } for feature in features
    ]
    
    return jsonify(features_data)