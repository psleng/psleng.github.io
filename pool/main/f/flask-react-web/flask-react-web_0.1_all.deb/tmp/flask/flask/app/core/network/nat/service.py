from app.core.network.nat.parser import parse_nat_config, parse_nat_translation
from flask import session
from app.core.network.nat.command_nat import CommandNAT
from app.core.api.http.http_request import Action
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
import pprint
from app.socket.socket_manager import socket_manager
from uuid import uuid4
from app.core.network.nat.parser import parse_nat_statistic, parse_nat_config_to_db
from app.core.network.nat.models import NATv4
from app.log.logger import logger

def fetch_nat_config(provider, data):
    data = provider.http_service.show_all_configs()
    return parse_nat_config(data.json()['data'])

def fetch_nat_stat(provider, data):
    
    nat_statistic = provider.graphql_service.send_request(function_name='ShowStatisticsNat', data={"direction": data.get('direction'), "family": "inet"}, verify=False) 
    print("Nat Statistic: ")
    print(pprint.pformat(nat_statistic.json()['data'], indent=2, width=80)) 
    return parse_nat_statistic(nat_statistic.json()['data'])

def fetch_nat_destination_translation(provider, data):
    
    nat_translation = provider.graphql_service.send_request(function_name='ShowTranslationsNat', data={"direction": "destination", "family": "inet"}, verify=False) 
    print("Nat Translation: ")
    print(pprint.pformat(nat_translation.json()['data'], indent=2, width=80)) 
    translation = parse_nat_translation(nat_translation.json()['data'])
    return translation

def fetch_nat_source_translation(provider, data):
    
    nat_source = provider.graphql_service.send_request(function_name='ShowTranslationsNat', data={"direction": "source", "family": "inet"}, verify=False) 
    print("Nat Source: ")
    print(pprint.pformat(nat_source.json()['data'], indent=2, width=80)) 
    source = parse_nat_translation(nat_source.json()['data'])
    return source


def update_nat(provider, data):
    username = session['username']
    diff = data.get('diff')
    current_nat = data.get('current')
    new_nat = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    r = []
    ## Generate set commands
    set_cmds = []
    nat_set_cmd = CommandNAT(operator='set', resource='nat')
    set_cmds = nat_set_cmd.generate_commands(diff['created'], current_nat, new_nat)
    sc = nat_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    ## Generate delete commands
    delete_cmds = []
    nat_del_cmd = CommandNAT(operator='delete', resource='nat')

    new_dest_rules = []
    new_source_rules = []
    current_dest_rules = []
    current_source_rules = []

    if 'destination' in current_nat and 'rule' in current_nat['destination'] \
        and 'destination' in new_nat and 'rule' in new_nat['destination']:
        new_dest_rules = new_nat['destination']['rule'].keys()
        current_dest_rules = current_nat['destination']['rule'].keys()
    
    if 'source' in current_nat and 'rule' in current_nat['source'] \
        and 'source' in new_nat and 'rule' in new_nat['source']:
        new_source_rules = new_nat['source']['rule'].keys()
        current_source_rules = current_nat['source']['rule'].keys()

    for dr in current_dest_rules:
        if dr not in new_dest_rules and 'destination' in diff['deleted'] \
            and 'rule' in diff['deleted']['destination'] and dr in diff['deleted']['destination']['rule']:
            diff['deleted']['destination']['rule'][dr].update({'all': True})

    for sr in current_source_rules:
        if sr not in new_source_rules and 'source' in diff['deleted'] \
            and 'rule' in diff['deleted']['source'] and sr in diff['deleted']['source']['rule']:
            diff['deleted']['source']['rule'][sr].update({'all': True})

    delete_cmds = nat_del_cmd.generate_commands(diff['deleted'], current_nat, new_nat)
    dc = nat_del_cmd.get_commands()
    new_del_configs = process_commands(dc)

    ## Validate commands
    service = "nat"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"nat": curr_config}

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    
    # Update DB
    logger.debug("Merged NAT data:", merged_config)
    parsed_merged_config = parse_nat_config_to_db(merged_config)
    logger.debug("Parsed merged NAT data:", parsed_merged_config)
    NATv4.refresh(parsed_merged_config)
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update NAT",
                "content": "NAT is successfully updated"
            }
    )

    excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r

def verify_nat(provider, data):

    # del data['ipv6']
    logger.debug("Verify NAT data:")
    logger.debug(data)
    service = "nat"
    current_nat = provider.verify_service.call_get_config(service)
    logger.debug("Current NAT data: ")
    logger.debug(current_nat)
    if isinstance(current_nat, dict) is False:
        current_nat = {}
    current_nat.update({
        "source": data.get("source", {}),
        "destination": data.get("destination", {})
    })
    verify = provider.verify_service.call_verify(service, current_nat)
    logger.debug("Verify: ")
    logger.debug(verify)
    return verify
    