import pytest
from app.test.core.base import TestGenerateConfig
from app.core.security.cmd.command_firewall import FirewallCommand
from app.core.utils.process_config import process_commands

from app.test.core.security.firewall.test_cases._test_case_generate_config import (
    test_firewall_cmd_set,
    test_firewall_cmd_delete,
    test_process_commands
)

class TestFirewallCommand(TestGenerateConfig):
    __test__ = True

    @pytest.fixture
    def cmd_class(self):
        return FirewallCommand
        
    @pytest.fixture
    def resource(self):
        return "ipv4"

    @pytest.fixture
    def cmd(self):
        return FirewallCommand()
    
    @pytest.fixture
    def cmd_set(self):
        return FirewallCommand(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return FirewallCommand(operator='delete')
    
    def test_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    
    def test_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)
    
    @pytest.mark.parametrize("test_data", test_firewall_cmd_set)
    def test_generate_commands_set(self, cmd_set, test_data):
        super().test_generate_commands_set(cmd_set, test_data)
    
    @pytest.mark.parametrize("test_data", test_firewall_cmd_delete)
    def test_generate_commands_delete(self, cmd_delete, test_data):
        super().test_generate_commands_delete(cmd_delete, test_data)
    
    @pytest.mark.parametrize("test_data", test_process_commands)
    def test_process_commands(self, test_data):
        super().test_process_commands(test_data)
    
    def test_get_commands_empty(self):
        super().test_get_commands_empty(FirewallCommand)
