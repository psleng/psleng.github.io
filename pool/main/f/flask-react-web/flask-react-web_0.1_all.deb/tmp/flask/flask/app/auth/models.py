from app.db.database import db
from app.crypto.bcrypt import bcrypt
from sqlalchemy import ForeignKey, Integer, Column, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
from app.log.logger import logger
import pytz

tzone = pytz.timezone("America/Toronto")

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_active = db.Column(db.Integer, nullable=True)
    alternative_id = db.Column(db.Integer, nullable=True)
    
    temp_user_expiry_time = relationship('TempUserExpiryTime', back_populates='user', cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.alternative_id)

    @classmethod
    def is_exist(cls, email):
        return User.query.filter_by(email=email).first()

    @classmethod
    def create_user(cls, email, password):
        if not User.is_exist(email):
            new_user = User(
                email=email,
                is_active=1
            )
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()
            return True
        return False

    @classmethod
    def update_password(cls, email, password):
        user = cls.is_exist(email)
        if user:
            try:
                user.set_password(password)
                db.session.commit()
                logger.info(f"Password updated successfully for user: {email}")
                return True
            except Exception as e:
                logger.error(f"Error updating password for user {email}: {e}")
                return False
        logger.warning(f"Attempted to update password for non-existent user: {email}")
        return False

    @classmethod
    def _deactivate_user(cls, email):
        user = User.query.filter_by(email=email).first()
        if user:
            user.is_active = 0
            db.session.commit()
            return True
        return False

    @classmethod
    def deactivate_user(cls, user_data, app_context=None):
        try:
            if app_context is not None:
                with app_context:
                    cls._deactivate_user(user_data['username'])
            else:
                cls._deactivate_user(user_data['username'])
        except Exception as e:
            logger.error(f"Error deactivating user: {str(e)}")
            return False

    @classmethod
    def _delete_user(cls, user_name):
        logger.debug(f"Deleting user: {user_name}")
        user = User.query.filter_by(email=user_name).first()
        if user:
            db.session.delete(user)
            db.session.commit()
            return True
        return False

    @classmethod
    def delete_user(cls, user_data, app_context=None):
        try:
            if app_context is not None:
                with app_context:
                    cls._delete_user(user_data['username'])
            else:
                cls._delete_user(user_data['username'])
        except Exception as e:
            logger.error(f"Error deleting user: {str(e)}")
            return False

    @classmethod
    def serialize(cls, user):
        expiry_time = TempUserExpiryTime.get_user_expiry(user.email)
        return {
            "user_name": user.email,
            "expires_at": expiry_time.isoformat() if expiry_time else None,
            "status": user.is_active,
            "role": "administrator"
        }


class TempUserExpiryTime(db.Model):
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'))
    expiry_time = Column(DateTime, nullable=False)

    user = relationship('User', back_populates='temp_user_expiry_time')

    @classmethod
    def convert_expiry_to_datetime(cls, expiry_time_str):
        """
        Convert expiry time to datetime.
        Format of expiry time: '1d', '2h', '40m'.
        Returns a datetime object for storage in the database.
        """
        if not isinstance(expiry_time_str, str):
            return None

        try:
            time_value = int(''.join(filter(str.isdigit, expiry_time_str)))
            time_unit = ''.join(filter(str.isalpha, expiry_time_str)).lower()
        except (ValueError, TypeError):
            return None

        now = datetime.now(tzone)
        delta = None

        if time_unit == 'd':
            delta = timedelta(days=time_value)
        elif time_unit == 'h':
            delta = timedelta(hours=time_value)
        elif time_unit == 'm':
            delta = timedelta(minutes=time_value)

        return now + delta if delta else None

    @classmethod
    def create_expiry_time(cls, user_id, expiry_time):
        user = User.query.filter_by(email=user_id).first()
        if user and not TempUserExpiryTime.is_exist(user.id):
            expiry_datetime = cls.convert_expiry_to_datetime(expiry_time)
            if not expiry_datetime:
                return False

            new_user_expiry_time = TempUserExpiryTime(
                user_id=user_id,
                expiry_time=expiry_datetime
            )
            db.session.add(new_user_expiry_time)
            db.session.commit()
            return True
        return False

    @classmethod
    def is_exist(cls, user_id):
        return TempUserExpiryTime.query.filter_by(user_id=user_id).first()

    @classmethod
    def update_expiry_time(cls, user_id, expiry_time):
        user = User.query.filter_by(email=user_id).first()
        if not user:
            return False

        user_expiry_time = TempUserExpiryTime.is_exist(user_id)
        if user_expiry_time:
            expiry_datetime = cls.convert_expiry_to_datetime(expiry_time)
            if not expiry_datetime:
                return False

            user_expiry_time.expiry_time = expiry_datetime
            db.session.commit()
            return True
        return False

    @classmethod
    def _delete_user_expiry_time(cls, user_id):
        user = User.query.filter_by(email=user_id).first()
        if user:
            user_expiry_time = TempUserExpiryTime.is_exist(user_id)
            if user_expiry_time:
                db.session.delete(user_expiry_time)
                db.session.commit()
                return True

        return False

    @classmethod
    def delete_expiry_time(cls, user_id, app_context=None):
        try:
            if app_context is not None:
                with app_context:
                    cls._delete_user_expiry_time(user_id)
            else:
                cls._delete_user_expiry_time(user_id)
        except Exception as e:
            logger.error(f"Error deleting user expiry time: {str(e)}")
            return False
    
    @classmethod
    def get_user_expiry(cls, user_id):
        record = TempUserExpiryTime.is_exist(user_id)
        if record:
            return record.expiry_time
        return None

    @classmethod
    def get_all_records(cls):
        return cls.query.all()