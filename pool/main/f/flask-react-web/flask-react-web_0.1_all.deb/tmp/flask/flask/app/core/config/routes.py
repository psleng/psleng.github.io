from . import vyos_config_bp
from flask import jsonify, request
from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.event.jobs.interface.fetch_interface import long_running_task
from celery.result import AsyncResult
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)

@vyos_config_bp.route('/', methods=['POST'])
def all_configs():

    res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})
    return jsonify(res.json())

@vyos_config_bp.route('/interface', methods=['POST'])
def all_interface_configs():
    res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
    return jsonify(res.json())

@vyos_config_bp.route('/test', methods=['POST'])
def test_event():
    try:
        task = long_running_task.apply_async()
        
        return jsonify({'msg': 'Success'}), 200

    except long_running_task.OperationalError as e:
        print('Error running task', str(e))
        logger.debug('Error running task')
        logger.debug(str(e))

@vyos_config_bp.route('/result/<id>', methods=['POST'])
def access_result(id: str):
    result = AsyncResult(id)
    data = {
        "id": id,
        "ready": result.ready(),
        "successful": result.successful(),
        "value": result.result if result.ready() else None,
    }
    return jsonify(data), 200


@vyos_config_bp.route("/get_result", methods=['POST'])
def task_result() -> dict[str, object]:
    data = request.get_json()
    result = AsyncResult(data['result_id'])
    if result.ready():
        # Task has completed
        if result.successful():
    
            return {
                "ready": result.ready(),
                "successful": result.successful(),
                "value": result.result,
            }
        else:
        # Task completed with an error
            return jsonify({'status': 'ERROR', 'error_message': str(result.result)})
    else:
        # Task is still pending
        return jsonify({'status': 'Running'})


@vyos_config_bp.route('/get-config', methods=["POST"])
def get_config():
    try:
        from app.core.utils.validate.validator import Validator
        validator_service = Validator()
        data = request.get_json()
        service = data['service']
        ifname = data.get('ifname', None)

        interface_services = ['wireless', 'bridge', 'ethernet', 'vlan', 'wwan']
        if service not in interface_services:
            configs = validator_service.call_get_config(service)
        else:
            configs = validator_service.call_get_interface_config(service, ifname)
        return configs, 200
    except Exception as e:
        return {
            "data": {},
            "error": str(e)
        }, 400


@vyos_config_bp.route('/verify', methods=["POST"])
def verify():
    try:
        from app.core.utils.validate.validator import Validator
        validator_service = Validator()
        data = request.get_json()
        config = data['config']
        service = data['service']
        ifname = data.get('ifname', None)
        
        interface_services = ['wireless', 'bridge', 'ethernet', 'vlan', 'wwan']
        if service not in interface_services:
            verify = validator_service.call_verify(service, config)
        else:
            verify = validator_service.call_verify_interface(service, ifname, config)
        return verify
    except Exception as e:
        print(f"Error verify {service}: {str(e)}")
        return "", 400
