import pprint
import re

def parse_nat_statistic(data):
    # Navigate through the nested structure to get to the result array
    if not data or 'ShowStatisticsNat' not in data:
        return []
    
    show_stats = data['ShowStatisticsNat']
    if not show_stats or 'data' not in show_stats or 'result' not in show_stats['data']:
        return []

    nat_stats = []
    for item in show_stats['data']['result']:
        if 'rule' not in item:
            continue

        rule = item['rule']
        if 'expr' not in rule:
            continue

        # Initialize values
        interface = None
        protocol = None
        address = None
        bytes_count = 0
        packets = 0
        chain = rule.get('chain', '')
        comment = rule.get('comment', '')
        
        # Extract rule number from comment (e.g., "SRC-NAT-1" or "DST-NAT-1")
        rule_number = 0
        if comment:
            match = re.search(r'(?:SRC|DST)-NAT-(\d+)', comment)
            if match:
                rule_number = int(match.group(1))

        # Extract data from expressions
        for expr in rule['expr']:
            # Get interface or protocol
            if 'match' in expr and 'left' in expr['match'] and 'meta' in expr['match']['left']:
                key = expr['match']['left']['meta'].get('key')
                if key == 'oifname':
                    interface = expr['match']['right']
                elif key == 'l4proto':
                    protocol = expr['match']['right']
            
            # Get bytes and packets
            if 'counter' in expr:
                bytes_count = expr['counter'].get('bytes', 0)
                packets = expr['counter'].get('packets', 0)
            
            # Get NAT address based on chain type
            if chain == 'POSTROUTING' and 'snat' in expr:
                if 'addr' in expr['snat']:
                    if 'prefix' in expr['snat']['addr']:
                        prefix = expr['snat']['addr']['prefix']
                        addr = prefix.get('addr', '')
                        mask = prefix.get('len', 0)
                        address = f"{addr}/{mask}"
            elif chain == 'PREROUTING' and 'dnat' in expr:
                address = expr['dnat'].get('addr', '')

        nat_stats.append({
            'rule_number': rule_number,
            'chain': chain,
            'comment': comment,
            'interface': interface,
            'protocol': protocol,
            'address': address,
            'bytes': bytes_count,
            'packets': packets
        })

    # Sort by rule number
    nat_stats.sort(key=lambda x: x['rule_number'])
    return nat_stats

def parse_nat_config(data):
    if 'nat' not in data:
        return {}
    return data['nat']

def parse_nat_translation(data):
    if not data or 'ShowTranslationsNat' not in data:
        return None
    
    nat_data = data['ShowTranslationsNat']
    if not nat_data.get('success') or nat_data.get('errors'):
        return None
    
    result = nat_data.get('data', {}).get('result', {}).get('conntrack', {})
    
    if result.get('error'):
        return []
    
    translations = []
    flows = result.get('flow', [])
    
    for flow in flows:
        meta_list = flow.get('meta', [])
        if not meta_list or len(meta_list) < 3:
            continue
            
        original = next((m for m in meta_list if m.get('direction') == 'original'), {})
        reply = next((m for m in meta_list if m.get('direction') == 'reply'), {})
        independent = next((m for m in meta_list if m.get('direction') == 'independent'), {})
        
        translation = {
            'protocol': original.get('layer4', {}).get('protoname', ''),
            'src_address': original.get('layer3', {}).get('src', ''),
            'dst_address': original.get('layer3', {}).get('dst', ''),
            'translated_src': reply.get('layer3', {}).get('dst', ''),
            'translated_dst': reply.get('layer3', {}).get('src', ''),
            'timeout': independent.get('timeout', '0'),
            'id': independent.get('id', ''),
        }
        
        if 'layer4' in original and 'sport' in original['layer4']:
            translation['src_port'] = original['layer4']['sport']
            translation['dst_port'] = original['layer4']['dport']
            translation['translated_sport'] = reply['layer4']['dport']
            translation['translated_dport'] = reply['layer4']['sport']
            
        translations.append(translation)
    
    return translations

def create_rule_config(rule):
    config = {}
    
    # Add description if present
    if rule.get('description'):
        config['description'] = rule['description']
    
    # Add protocol if present
    if rule.get('protocol'):
        config['protocol'] = rule['protocol']
    else:
        config['protocol'] = 'all'
    
    # Handle source configuration
    if rule.get('source_address') or rule.get('source_port'):
        config['source'] = {}
        if rule.get('source_address'):
            config['source']['address'] = rule['source_address']
        if rule.get('source_port'):
            config['source']['port'] = rule['source_port']
    
    # Handle destination configuration
    if rule.get('destination_address') or rule.get('destination_port'):
        config['destination'] = {}
        if rule.get('destination_address'):
            config['destination']['address'] = rule['destination_address']
        if rule.get('destination_port'):
            config['destination']['port'] = rule['destination_port']
    
    # Handle translation configuration
    if rule.get('translation_address') or rule.get('translation_port'):
        config['translation'] = {}
        if rule.get('translation_address'):
            config['translation']['address'] = rule['translation_address']
        if rule.get('translation_port'):
            config['translation']['port'] = rule['translation_port']
    
    # Handle interfaces
    if rule.get('inbound_interface'):
        config['inbound-interface'] = {'name': rule['inbound_interface']}
    if rule.get('outbound_interface'):
        config['outbound-interface'] = {'name': rule['outbound_interface']}
    
    # Handle exclude flag
    if rule.get('exclude'):
        config['exclude'] = {}

    # Handle disable flag
    if rule.get('disable'):
        config['disable'] = {}
    
    if 'enable' in rule and rule.get('enable') == False:
        config['disable'] = {}
    
    return config

def parse_to_nat_config(data):
    result = {
        'source': {'rule': {}},
        'destination': {'rule': {}}
    }

    # Process IPv4 rules
    if data.get('NATv4'):
        # Handle source rules
        if data['NATv4'].get('source'):
            for rule in data['NATv4']['source']:
                rule_config = create_rule_config(rule)
                result['source']['rule'][str(rule['rule_id'])] = rule_config

        # Handle destination rules
        if data['NATv4'].get('destination'):
            for rule in data['NATv4']['destination']:
                rule_config = create_rule_config(rule)
                result['destination']['rule'][str(rule['rule_id'])] = rule_config

    return result

def parse_nat_config_to_db(data):
    """
    Parse NAT configuration from VyOS format to a structure ready for DB
    
    Args:
        Sample input data:
        {'source': {'rule': {'10': {'load_balance': {'hash': ['random']}, 'outbound_interface': {'name': 'eth3'}, 'protocol': 'all', 'translation': {'address': 'masquerade', 'options': {'address_mapping': 'random', 'port_mapping': 'none'}}}, '20': {...}}}, 'destination': {'rule': {...}}}
    
    """
    result = {
        'source': {'rule': {}},
        'destination': {'rule': {}}
    }
    
    if 'nat' not in data:
        return result
        
    nat_data = data['nat']
    
    if 'source' in nat_data and 'rule' in nat_data['source']:
        for rule_id, rule in nat_data['source']['rule'].items():
            processed_rule = {}
            
            if 'description' in rule:
                processed_rule['description'] = rule['description']
                
            if 'protocol' in rule:
                processed_rule['protocol'] = rule['protocol']
                
            if 'outbound-interface' in rule and 'name' in rule['outbound-interface']:
                processed_rule['outbound-interface'] = {'name': rule['outbound-interface']['name']}
            elif 'outbound_interface' in rule and 'name' in rule['outbound_interface']:
                processed_rule['outbound-interface'] = {'name': rule['outbound_interface']['name']}
                
            if 'source' in rule:
                processed_rule['source'] = {}
                if 'address' in rule['source']:
                    processed_rule['source']['address'] = rule['source']['address']
                if 'port' in rule['source']:
                    processed_rule['source']['port'] = rule['source']['port']
                    
            if 'destination' in rule:
                processed_rule['destination'] = {}
                if 'address' in rule['destination']:
                    processed_rule['destination']['address'] = rule['destination']['address']
                if 'port' in rule['destination']:
                    processed_rule['destination']['port'] = rule['destination']['port']
                    
            if 'translation' in rule:
                processed_rule['translation'] = {}
                if 'address' in rule['translation']:
                    processed_rule['translation']['address'] = rule['translation']['address']
                if 'port' in rule['translation']:
                    processed_rule['translation']['port'] = rule['translation']['port']
                    
            if 'exclude' in rule:
                processed_rule['exclude'] = {}
                
            if 'disable' in rule:
                processed_rule['disable'] = {}
                
            result['source']['rule'][rule_id] = processed_rule
            
    if 'destination' in nat_data and 'rule' in nat_data['destination']:
        for rule_id, rule in nat_data['destination']['rule'].items():
            processed_rule = {}
            
            if 'description' in rule:
                processed_rule['description'] = rule['description']
                
            if 'protocol' in rule:
                processed_rule['protocol'] = rule['protocol']
                
            if 'inbound-interface' in rule and 'name' in rule['inbound-interface']:
                processed_rule['inbound-interface'] = {'name': rule['inbound-interface']['name']}
            elif 'inbound_interface' in rule and 'name' in rule['inbound_interface']:
                processed_rule['inbound-interface'] = {'name': rule['inbound_interface']['name']}
                
            if 'source' in rule:
                processed_rule['source'] = {}
                if 'address' in rule['source']:
                    processed_rule['source']['address'] = rule['source']['address']
                if 'port' in rule['source']:
                    processed_rule['source']['port'] = rule['source']['port']
                    
            if 'destination' in rule:
                processed_rule['destination'] = {}
                if 'address' in rule['destination']:
                    processed_rule['destination']['address'] = rule['destination']['address']
                if 'port' in rule['destination']:
                    processed_rule['destination']['port'] = rule['destination']['port']
                    
            if 'translation' in rule:
                processed_rule['translation'] = {}
                if 'address' in rule['translation']:
                    processed_rule['translation']['address'] = rule['translation']['address']
                if 'port' in rule['translation']:
                    processed_rule['translation']['port'] = rule['translation']['port']
                    
            if 'exclude' in rule:
                processed_rule['exclude'] = {}
                
            if 'disable' in rule:
                processed_rule['disable'] = {}
                
            result['destination']['rule'][rule_id] = processed_rule
            
    return result

if __name__ == '__main__':
    test_input = { 
        'NATv4': { 'destination': [ { 
            'description': 'Destination NAT rule',
            'destination': None,
            'destination_address': '10.0.0.0/24',
            'destination_mac': None,
            'destination_port': '80',
            'destination_subnet': None,
            'enabled': None,
            'exclude': False,
            'inbound_interface': 'eth1',
            'outbound_interface': None,
            'protocol': 'tcp',
            'rule_id': '200',
            'rule_number': None,
            'rule_type': 'destination',
            'source': None,
            'source_address': '192.168.1.0/24',
            'source_mac': None,
            'source_port': '8080',
            'source_subnet': None,
            'translation_address': '192.168.2.1',
            'translation_port': '9090'}],
        'source': [ { 
            'description': 'Source NAT rule',
            'destination': None,
            'destination_address': '10.0.0.0',
            'destination_mac': None,
            'destination_port': '80',
            'destination_subnet': None,
            'enabled': None,
            'exclude': True,
            'inbound_interface': None,
            'outbound_interface': 'eth1',
            'protocol': 'tcp',
            'rule_id': '100',
            'rule_number': None,
            'rule_type': 'source',
            'source': None,
            'source_address': '192.168.1.0/24',
            'source_mac': None,
            'source_port': '8080',
            'source_subnet': None,
            'translation_address': '192.168.1.2',
            'translation_port': '9090'
        }]},
        'NATv6': None
    }

    result = parse_to_nat_config(test_input)
    print("Parsed Result:")
    print(pprint.pformat(result, indent=2, width=80))