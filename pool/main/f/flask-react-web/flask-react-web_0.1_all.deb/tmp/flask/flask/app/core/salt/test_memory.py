from app.core.salt.client import LocalClient

local = LocalClient()

r = local.cmd('hostNameVyOS-Proxy', 'status.meminfo')

print(r)