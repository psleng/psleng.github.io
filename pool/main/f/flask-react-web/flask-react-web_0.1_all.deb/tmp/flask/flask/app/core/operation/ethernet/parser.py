def parse_to_ethernet_config(data: dict):
    """
    Parse the data to the ethernet config
    Sample input:
    { 'general': {'description': 'eth1 description', 'enabled': False},
        'link': { 'autoNegotiation': True,
                    'duplex': 'auto',
                    'mtu': 10000,
                    'speed': 'auto'},
        'network': { 'bridgeInterface': '',
                    'bridgeMode': False,
                    'ipv4': { 'dhcp': { 'enabled': False,
                                        'options': { 'clientId': '',
                                                        'defaultRouteDistance': 1,
                                                        'dontInstallDefaultRoute': False,
                                                        'hostname': '',
                                                        'mtu': 1500,
                                                        'reject': False,
                                                        'userClass': '',
                                                        'vendorClass': ''}},
                                'mode': 'static',
                                'static': { 'address': '',
                                            'gateway': '',
                                            'netmask': '',
                                            'prefixLength': 24}},
                    'ipv6': { 'autoconf': {'enabled': False},
                                'delegated': {'enabled': False},
                                'dhcpv6': { 'enabled': False,
                                            'options': { 'dontSendRelease': False,
                                                        'duid': '',
                                                        'parametersOnly': False,
                                                        'pd': False,
                                                        'rapidCommit': False,
                                                        'temporaryAddress': False},
                                            'requestPrefixDelegation': False},
                                'mode': 'static',
                                'static': {'address': '', 'prefix': 64}}}}
    
    Sample output:
    { 'address': ['dhcp', 'dhcpv6'],
        'description': 'eth1 description',
        'disable': {},
        'duplex': 'auto',
        'hw-id': '08:00:27:34:d4:3f',
        'ipv6': {'address': {'autoconf': {}}},
        'mtu': '10000',
        'offload': { 'gro': {},
                    'gso': {},
                    'sg': {},
                    'tso': {}},
        'speed': 'auto'}
    """
    if not data:
        return {}

    result = {}

    # Process general settings
    if 'general' in data:
        general = data['general']
        if 'description' in general:
            result['description'] = general['description']
        if 'enabled' in general and not general['enabled']:
            result['disable'] = {}
        if 'hwId' in general:
            result['hw-id'] = general['hwId']

    # Process link settings
    if 'link' in data:
        link = data['link']
        if 'speed' in link:
            result['speed'] = link['speed']
        if 'duplex' in link:
            result['duplex'] = link['duplex']
        if 'mtu' in link:
            result['mtu'] = str(link['mtu'])
        if 'autoNegotiation' in link and not link['autoNegotiation']:
            result['link-negotiation'] = 'off'

    # Process network settings
    if 'network' in data:
        network = data['network']
        
        # Process bridge settings
        if 'bridgeMode' in network and network['bridgeMode']:
            result['bridge'] = {}
            if 'bridgeInterface' in network and network['bridgeInterface']:
                result['bridge']['interface'] = network['bridgeInterface']

        # Process IPv4 settings
        if 'ipv4' in network:
            ipv4 = network['ipv4']
            if 'mode' in ipv4:
                if ipv4['mode'] == 'dhcp':
                    result['address'] = ['dhcp']
                elif ipv4['mode'] == 'static' and 'static' in ipv4:
                    static = ipv4['static']
                    if 'address' in static and static['address']:
                        result['address'] = [f"{static['address']}/{static.get('prefixLength', 24)}"]
                        if 'gateway' in static and static['gateway']:
                            result['gateway'] = static['gateway']

        # Process IPv6 settings
        if 'ipv6' in network:
            ipv6 = network['ipv6']
            if 'mode' in ipv6:
                if ipv6['mode'] == 'dhcp':
                    result['address'] = result.get('address', []) + ['dhcpv6']
                elif ipv6['mode'] == 'static' and 'static' in ipv6:
                    static = ipv6['static']
                    if 'address' in static and static['address']:
                        result['address'] = result.get('address', []) + [f"{static['address']}/{static.get('prefix', 64)}"]
                elif ipv6['mode'] == 'autoconf' and 'autoconf' in ipv6 and ipv6['autoconf'].get('enabled', False):
                    result['ipv6'] = {'address': {'autoconf': {}}}
                elif ipv6['mode'] == 'delegated' and 'delegated' in ipv6 and ipv6['delegated'].get('enabled', False):
                    result['ipv6'] = {'address': {'delegated': {}}}

    # Add default offload settings
    result['offload'] = {
        'gro': {},
        'gso': {},
        'sg': {},
        'tso': {}
    }

    return result


def parse_ethernet_config(data: dict):
    return data