import os 
import importlib
import importlib.util
import requests

hostname = "http://10.10.50.71"
linux_root_path = "/usr/libexec/vyos"

location = {
    "service_dns_forwarding": "/conf_mode/service_dns_forwarding.py"   
}

funcs = ["get_config", "verify", "generate", "apply"]


def call_verify(service: str, config: str) -> str:
    try:
        # Call the verify function from linux path
        file_path = linux_root_path + location[service]
        spec = importlib.util.spec_from_file_location(service, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        verify = getattr(module, "verify")
        return verify(config) is None
    except Exception as e:
        print(f"Error verify {service}: {str(e)}")
        return ""

