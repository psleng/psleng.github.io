"""
    Test class for NTP configuration parsing and validation functions:
    - NTPDTO.model_validate_json()
    - parse_to_ntp_config()
    - compare_configs()
"""
import pytest
from app.core.network.ntp.models import NTPDTO
from app.core.network.ntp.parser import parse_to_ntp_config
from app.test.core.network.ntp.test_cases._test_case_parse_input import test_case_valid, test_case_invalid, test_case_minimal, test_case_comparison
from app.test.core.base import TestParseInput


class TestNTPParseConfig(TestParseInput):
    __test__ = True
    
    @pytest.mark.parametrize("test_data", test_case_valid)
    def test_model_validate_json_valid(self, test_data):
        super().test_model_validate_json_valid(test_data, NTPDTO)
    
    @pytest.mark.parametrize("test_data", test_case_invalid)
    def test_model_validate_json_invalid(self, test_data):
        super().test_model_validate_json_invalid(test_data, NTPDTO)
    
    @pytest.mark.parametrize("test_data", test_case_minimal)
    def test_model_validate_minimal_json(self, test_data):
        super().test_model_validate_minimal_json(test_data, NTPDTO)
        
    @pytest.mark.parametrize("test_data", test_case_comparison)
    def test_compare_configs_additions(self, test_data):
        super().test_compare_configs_additions(test_data)
    
    def test_parse_to_ntp_config_empty(self):
        empty_dto = NTPDTO()
        data = empty_dto.model_dump(exclude_none=True)
        
        ntp_config = parse_to_ntp_config(data)
        
        assert ntp_config == {}

