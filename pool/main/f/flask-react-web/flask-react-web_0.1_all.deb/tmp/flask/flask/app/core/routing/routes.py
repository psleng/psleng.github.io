from app.core.routing import routing_bp
from flask import jsonify, request
from app.core.routing.models import AddableGeneralRoutingDTO, GeneralRouting, GeneralRoutingV6, VerifyGeneralRoutingDTO, GeneralRoutingMonitorDTO, UpdateGeneralRoutingDTO
from app.core.routing.parsers import parse_to_route_config, parse_to_route_config_system
from app.core.routing.service import is_route_existed_in_db
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.models import Interface
from app.auth.utils import login_required
import pprint
from app.core.api.http.cmd.compare import compare_configs

@routing_bp.route('/general', methods=['GET'])
def get_general_routing():
    data = GeneralRouting.query.all()
    data6 = GeneralRoutingV6.query.all()
    interfaces = Interface.get_interface_names()
    routes = [item.serialize() for item in data]
    routes6 = [item.serialize() for item in data6]
    return jsonify({
            "routes": routes,
            "routes6": routes6,
            "interfaces": interfaces
        }), 200


@routing_bp.route('/general', methods=['PUT'])
def update_general_routing():
    try:
        data = UpdateGeneralRoutingDTO.model_validate_json(request.data)
        new_config = parse_to_route_config(data.model_dump())
        print("New config:")
        print(pprint.pformat(new_config, indent=2, width=80))

        # Current general routing
        current_config = {}
        if data.route_ver == 'ipv4':
            current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING)
        elif data.route_ver == 'ipv6':
            current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING_V6)
        print("Current general routing:")
        print(pprint.pformat(current_config, indent=2, width=80))

        # Diff new config with current config
        diff = compare_configs(new_config, current_config)

        print("Diff config:")
        print(pprint.pformat(diff, indent=2, width=80))
        
        r = []
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.GENERAL_ROUTING, 
            data={"current": current_config, "new": new_config, "diff": diff, "route_ver": data.route_ver}
        )

        # new_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING)
        # GeneralRouting.refresh(new_config, None)


        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            r.append(res)
            return jsonify(r), 200
        
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/general', methods=['DELETE'])
def delete_general_routing():
    return jsonify({'message': 'Success'}), 200


@routing_bp.route('/general/verify', methods=['POST'])
@login_required
def verify_general_routing():
    from app.pkg.vyos.template import is_v4_dest_prefix, is_v6_dest_prefix, is_v4_nexthop, is_v6_nexthop

    def convert_to_number(value):
        try:
            return int(value)
        except ValueError:
            return False

    try:
        data = VerifyGeneralRoutingDTO.model_validate_json(request.data)
        new_config = data.model_dump()
        route_version = new_config.get("route_ver")
        route_id = new_config.get("route_id")
        all_routes = new_config.get("routes")
        
        verify_route = list(filter(lambda x: x.get("id") == route_id, all_routes))[0]
        
        if verify_route:
            dest_prefix = verify_route.get("dest_prefix")
            nexthop = verify_route.get("nexthop")
            distance_str = verify_route.get("distance")
            distance = convert_to_number(distance_str)
            
            # Check if route config is valid ipv4/ipv6
            if route_version == "v4":
                if dest_prefix and dest_prefix.strip() != "" and (not is_v4_dest_prefix(dest_prefix)):
                    return jsonify({"verify": "Invalid Destination Prefix"}), 400
                if nexthop and nexthop.strip() != "" and (not is_v4_nexthop(nexthop)):
                    return jsonify({"verify": "Invalid Nexthop"}), 400
            elif route_version == "v6":
                if dest_prefix and dest_prefix.strip() != "" and (not is_v6_dest_prefix(dest_prefix)):
                    return jsonify({"verify": "Invalid Destination Prefix"}), 400
                if nexthop and nexthop.strip() != "" and (not is_v6_nexthop(nexthop)):
                    return jsonify({"verify": "Invalid Nexthop"}), 400

            if distance_str.strip() != "" and not distance:
                return jsonify({"verify": "Distance must be between 1 and 255"}), 400
            if distance and (not 1 <= distance <= 255):
                return jsonify({"verify": "Distance must be between 1 and 255"}), 400

        route_config = parse_to_route_config_system(new_config)
        route_ver = new_config.get("route_ver")
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.GENERAL_ROUTING, data={"routes": route_config, "route_ver": route_ver})
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@routing_bp.route('/general/monitor', methods=['POST'])
def fetch_general_routing_monitor():
    try:
        data = GeneralRoutingMonitorDTO.model_validate_json(request.data)
        routes = api_manager.call(action=API_ACTION.READ, target=API_TARGET.GENERAL_ROUTING_MONITOR, data=data.model_dump())
        return jsonify(routes), 200
    except Exception as e:
        print("Error:", e)
    return jsonify({'error': str(e)}), 400


@routing_bp.route('/general/addable', methods=['POST'])
def check_if_route_addable():
    try:
        addable_data = AddableGeneralRoutingDTO.model_validate_json(request.data)
        data = addable_data.model_dump()
        existed = is_route_existed_in_db(data.get('route'), data.get('route_ver'))
        if existed is None:
            return jsonify({"id": None, "addable": True}), 200
        return jsonify({"id": existed.id, "addable": False}), 200

    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400