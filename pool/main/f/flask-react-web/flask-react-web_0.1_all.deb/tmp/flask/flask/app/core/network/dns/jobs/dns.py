from app.core.network.dns.models import DNSForwarding, DNSDynamicInterface
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_dns_job(app_context):
    try:
        refresh_db_dns(app_context=app_context)
    except Exception as e:
        print('Error fetch dns', str(e))



def refresh_db_dns(app_context=None):
    try:
        dns = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS)
        print("Fetch DNS Job data:", dns)
        if app_context is not None:
            with app_context:
                DNSForwarding.refresh(dns['forwarding'])
                DNSDynamicInterface.refresh(dns['dynamic'])
        else:
            DNSForwarding.refresh(dns['forwarding'])
            DNSDynamicInterface.refresh(dns['dynamic'])
        return True
    except Exception as e:
        print(f"Error refreshing db DNS data: {e}")
        return False
