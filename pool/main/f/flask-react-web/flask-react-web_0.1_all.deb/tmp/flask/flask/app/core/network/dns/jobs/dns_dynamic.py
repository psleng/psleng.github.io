from app.core.network.dns.models import DNSDynamicHostGroup, DNSDynamicInterface
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_dns_dynamic_job(app_context):
    try:
        refresh_db_dns_dynamic(app_context=app_context)
    except Exception as e:
        print('Error fetch dns dynamic', str(e))



def refresh_db_dns_dynamic(app_context=None):
    try:
        dns = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS)
        dns_dynamic = dns["dynamic"] if "dynamic" in dns else None
        print("DNS Dynamic data:", dns_dynamic)
        logger.debug("DNS Dynamic data:")
        logger.debug(dns_dynamic)
        if app_context is not None:
            with app_context:
                DNSDynamicInterface.refresh(dns_dynamic)
        else:
            DNSDynamicInterface.refresh(dns_dynamic)
        return True
    except Exception as e:
        print(f"Error refreshing db DNS dynamic data: {e}")
        return False
