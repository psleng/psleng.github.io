from app.core.routing.models import GeneralRouting
import pprint
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from flask import session
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.socket.socket_manager import socket_manager
from uuid import uuid4
from app.core.routing.models import GeneralRouting, GeneralRoutingV6
from app.core.routing.command_routing import RoutingCommand
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_GENERAL_ROUTING, SHOW_GENERAL_ROUTING_V6
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def update_general_routing(provider, data: dict):
    username = session['username']
    diff = data.get('diff')
    current = data.get('current')
    new = data.get('new')
    route_ver = data.get('route_ver')
    print("Current General Routing data:")
    print(pprint.pformat(current, indent=2, width=80))
    print("New General Routing data:")
    print(pprint.pformat(new, indent=2, width=80))
    print("Diff General Routing data:")
    print(pprint.pformat(diff, indent=2, width=80))
    
    r = []
    cmds = []
    
    ## Generate set commands
    set_cmds = []
    general_routing_set_cmd = RoutingCommand(operator='set', resource=route_ver)
    set_cmds = general_routing_set_cmd.generate_commands(diff['created'], current, new)
    sc = general_routing_set_cmd.get_commands()
    new_set_configs = process_commands(sc)
    
    ## Generate delete commands
    del_cmds = []
    general_routing_del_cmd = RoutingCommand(operator='delete', resource=route_ver)
    del_cmds = general_routing_del_cmd.generate_commands(diff['deleted'], current, new)
    dc = general_routing_del_cmd.get_commands()
    new_del_configs = process_commands(dc)

    # Validate commands
    service = "general_routing"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"protocols": curr_config}

    print("Current General Routing config:")
    print(pprint.pformat(current_config, indent=2, width=80))

    print("New SET General Routing config:")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    print("New DEL General Routing config:")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_del_configs, clean_empty=False)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config['protocols'])
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    # Update DB
    print("UPDATE DB AFTER VERIFY: General Routing data:")
    pprint.pprint(merged_config['protocols'], indent=2, width=80)
    
    if route_ver == 'ipv4':
        GeneralRouting.refresh(merged_config['protocols'])
    elif route_ver == 'ipv6':
        GeneralRoutingV6.refresh(merged_config['protocols'])

    # Emit notification
    socket_manager.emit_to_user(
    username, 
    event='notification', 
    data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update General Routing",
            "content": "General Routing is successfully updated"
        }
    )

    excecuted_cmds = list(set(del_cmds)) + list(set(set_cmds))

    # RUN unique commands in VyOS
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r


def fetch_general_routing_monitor(provider, data: dict):

    routes = []
    if data['version'] == 'ipv4':
        route_v4 = provider.graphql_service.send_request(function_name='ShowRoute ', data={"family": "inet"}, verify=False)
        if route_v4.json()['data'].get('ShowRoute', {}).get('data', {}).get('result', None):
            routes = route_v4.json()['data']['ShowRoute']['data']['result']
    elif data['version'] == 'ipv6':
        route_v6 = provider.graphql_service.send_request(function_name='ShowRoute ', data={"family": "inet6"}, verify=False)
        if route_v6.json()['data'].get('ShowRoute', {}).get('data', {}).get('result', None):
            routes = route_v6.json()['data']['ShowRoute']['data']['result']
    return routes


def fetch_general_routing(provider, data: dict):
    """ Fetch general routing configuration"""
    logger.debug("Fetching general routing configuration...")
    print("Fetching general routing configuration")
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_GENERAL_ROUTING, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    if 'route' in data:
        return data['route']
    return {}


def fetch_general_routing_v6(provider, data: dict):
    """ Fetch general routing configuration"""
    logger.debug("Fetching general routing configuration...")
    print("Fetching general routing configuration")
    route_resp = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_GENERAL_ROUTING_V6, verify=False)
    data = route_resp.json()['data']
    if data is None:
        return {}
    if 'route6' in data:
        return data['route6']
    return {}


def verify_general_routing(provider, data: dict):
    try:
        print("Verify General Routing")
        service = "general_routing"
        route_ver = data.get("route_ver")

        if route_ver == "v4":
            config_to_verify = {
                "policy": {},
                "static": {"route": data.get("routes")}
            }
        elif route_ver == "v6":
            config_to_verify = {
                "policy": {},
                "static6": {"route6": data.get("routes")}
            }
        print("Route config: ")
        print(pprint.pformat(config_to_verify, indent=2, width=80))

        verify = provider.verify_service.call_verify(service, config_to_verify)
        print("Verify: ")
        print(pprint.pformat(verify, indent=2, width=80))
        return verify
    except Exception as e:
        print("Error:", e)
        return str(e)

def is_route_existed_in_db(route: dict, version: str):
    try:    
        if version == 'ipv4':
            is_existed = GeneralRouting.query.filter_by(
                route_type=route['route_type'],
                dest_prefix=route['dest_prefix'],
                nexthop=route['nexthop'],
                interface=route['interface'],
                route_table_id=route['route_table_id'],
                vrf=route['vrf']
            ).first()

        elif version == 'ipv6':
            is_existed = GeneralRoutingV6.query.filter_by(
                route_type=route['route_type'],
                dest_prefix=route['dest_prefix'],
                nexthop=route['nexthop'],
                interface=route['interface'],
                route_table_id=route['route_table_id'],
                vrf=route['vrf']
            ).first()

        return is_existed
    
    except Exception as e:
        print("Error:", e)
        return str(e)