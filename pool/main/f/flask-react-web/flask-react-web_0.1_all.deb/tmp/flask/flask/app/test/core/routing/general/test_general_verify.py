import pytest
from app.test.core.base import TestVerify
from app.test.core.routing.general.test_cases._test_case_verify import test_verify_success, test_verify_failed

class TestGeneralRoutingVerify(TestVerify):
    __test__ = False # Skip the test
    
    @pytest.fixture
    def service(self):
        return "routing"
    
    @pytest.fixture
    def test_get_current_config(self):
        return {
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {"distance": "1"}
                }
            }
        }
    
    @pytest.mark.parametrize("test_data", test_verify_success)
    def test_verify_success(self, test_service_provider, success_verification, service, test_data):
        super().test_verify_success(test_service_provider, success_verification, service, test_data)
    
    @pytest.mark.parametrize("test_data", test_verify_failed)
    def test_verify_failed(self, test_service_provider, success_verification, service, test_data):
        super().test_verify_failed(test_service_provider, success_verification, service, test_data)
    
    def test_verify_current_config(self, test_service_provider, success_verification, service, test_get_current_config):
        super().test_verify_current_config(test_service_provider, success_verification, service, test_get_current_config)