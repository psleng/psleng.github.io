from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship

class Page(db.Model):
    __tablename__ = 'pages'
    
    id = Column(Integer, primary_key=True)
    page_id = Column(String, nullable=False)
    page_name = Column(String, nullable=False)
    page_url = Column(String, nullable=False)
    enabled = Column(Boolean, default=True)
    
    sub_pages = relationship('SubPage', back_populates='parent_page', cascade='all, delete-orphan')

class SubPage(db.Model):
    __tablename__ = 'sub_pages'
    
    id = Column(Integer, primary_key=True)
    sub_page_id = Column(String, nullable=False)
    sub_page_name = Column(String, nullable=False)
    sub_page_url = Column(String, nullable=False)
    enabled = Column(Boolean, default=True)
    
    parent_page_id = Column(Integer, ForeignKey('pages.id'))
    parent_page = relationship('Page', back_populates='sub_pages')

class SubPageFeature(db.Model):
    __tablename__ = 'sub_page_features'
    
    id = Column(Integer, primary_key=True)
    feature_id = Column(String, nullable=False)
    feature_name = Column(String, nullable=False)
    enabled = Column(Boolean, default=True)
    
    sub_page_id = Column(String, nullable=True)

    @classmethod
    def set_v6_features_status(cls, status: bool):
        cls.query.filter(
            cls.feature_id.contains('v6')
        ).update({'enabled': status})
        db.session.commit()

class Feature(db.Model):
    __tablename__ = 'features'
    
    id = Column(Integer, primary_key=True)
    feature_id = Column(String)
    feature_name = Column(String)
    enabled = Column(Boolean, default=False)

class Interval(db.Model):

    __tablename__ = 'intervals'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    value = Column(Integer, default=0)
