from app.core.network.nat.command_nat import CommandNAT
from app.test.core.network.nat.test_cases._test_case_generate_config import test_set, test_delete, test_process_commands
import pytest
from app.test.core.base import TestGenerateConfig
from app.core.utils.process_config import process_commands


class TestNATCommand(TestGenerateConfig):
    __test__ = True

    @pytest.fixture
    def cmd_class(self):
        return CommandNAT

    @pytest.fixture
    def resource(self):
        return 'nat'

    @pytest.fixture
    def cmd(self):
        return CommandNAT()
    
    @pytest.fixture
    def nat_cmd_set(self):
        return CommandNAT(operator='set')
    
    @pytest.fixture
    def nat_cmd_delete(self):
        return CommandNAT(operator='delete')
    

    def test_nat_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    

    def test_nat_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)

    
    @pytest.mark.parametrize("test_data", test_set)
    def test_generate_commands_set(self, nat_cmd_set, test_data):
        super().test_generate_commands_set(nat_cmd_set, test_data)


    @pytest.mark.parametrize("test_data", test_delete)
    def test_generate_commands_delete(self, nat_cmd_delete, test_data):
        super().test_generate_commands_delete(nat_cmd_delete, test_data)
        
        
    @pytest.mark.parametrize("test_data", test_process_commands)
    def test_process_commands(self, test_data):
        super().test_process_commands(test_data)
        
        
    def test_get_commands_empty(self):
        super().test_get_commands_empty(CommandNAT)