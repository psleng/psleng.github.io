from app.core.api.http.http_request import Action
from app.core.operation.system_performance import load_system_memory_json, load_system_memory_linux
from logging import getLogger, INFO
from app.core.operation.system_performance import load_system_cpu_json
from app.core.api.http.cmd.command import SHOW_RAM_TOTAL_LINUX, SHOW_SYSTEMS_MEMORY, SHOW_RAM_USED_LINUX, SHOW_SYSTEMS_UPTIME
import os
import subprocess
from app.core.utils.check_os import is_linux

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_ram(provider, params):
    if not is_linux():
        data = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_MEMORY, verify=False)
        memory = load_system_memory_json(data.json()['data'])
    else:
        try:
            # Get total memory
            total_mem_proc = subprocess.Popen(
                SHOW_RAM_TOTAL_LINUX.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            total_mem_output, total_mem_error = total_mem_proc.communicate()
            
            if total_mem_error:
                print(f"Error getting total memory: {total_mem_error.decode()}")
                return None
            
            # Get used memory
            used_mem_proc = subprocess.Popen(
                SHOW_RAM_USED_LINUX.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            used_mem_output, used_mem_error = used_mem_proc.communicate()
            
            if used_mem_error:
                print(f"Error getting used memory: {used_mem_error.decode()}")
                return None
                
            memory = load_system_memory_linux(total_mem_output, used_mem_output)
            return memory
            
        except Exception as e:
            print(f"Error executing Linux memory commands: {str(e)}")
            return None
            
    return memory

def fetch_cpu(provider, params):
    
    res = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_UPTIME, verify=False)
    perf = load_system_cpu_json(res.json()['data'])
    return perf
