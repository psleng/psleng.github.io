def parse_to_saml_config(data):
    result = {
        'login': {
            'saml': {}
        }
    }

    if not isinstance(data, dict):
        return result

    for key, value in data.items():
        result['login']['saml'][key] = value

    return result