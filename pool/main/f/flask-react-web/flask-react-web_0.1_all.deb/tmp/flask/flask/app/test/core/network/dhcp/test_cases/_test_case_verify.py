import pytest

test_verify_success_1 = pytest.param(
    (
        {
            "listen_interface": ["eth2"],
            "shared_network_name": {
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                                "subnet_id": "1",
                                "range": {
                                    "range_1": {
                                        "start": "192.168.1.100",
                                        "stop": "192.168.1.200"
                                    }
                                }
                            },
                            "192.168.10.0/24": {
                                "subnet_id": "2",
                                "range": {
                                    "range_1": {
                                        "start": "192.168.10.100",
                                        "stop": "192.168.10.200"
                                    }
                                }
                            }
                        }
                    }
            }
        }
    ),
    id="test_verify_success_1"
)

test_verify_success_2 = pytest.param(
    (
        {
            "listen_interface": ["eth2"],
            "shared_network_name": {
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                            "subnet_id": "1",
                                "range": {
                                    "range_1": {
                                        "start": "192.168.1.100",
                                        "stop": "192.168.1.200"
                                    }
                                }
                            },
                            "192.168.10.0/24": {
                                "subnet_id": "2",
                                "range": {
                                    "range_1": {
                                        "start": "192.168.10.100",
                                        "stop": "192.168.10.200"
                                    }
                                }
                            }
                        }
                    }
                }
        }
    ),
    id="test_verify_success_2"
)

test_verify_success = [
    test_verify_success_1,
    test_verify_success_2,
]


test_verify_failed_1 = pytest.param(
    (
        {
            "listen_interface": ["eth1"],
            "shared_network_name": {
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                                # "subnet_id": "1", # Missing subnet-id
                                "range": {
                                    "range_1": {
                                        "start": "192.168.1.100",
                                        "stop": "192.168.1.200"
                                    }
                                }
                            }
                        }
                    }
                }
        }
    ),
    id="test_verify_failed_1"
)

test_verify_failed_2 = pytest.param(
    (
        {
            "listen_interface": ["eth1"],
            "shared-network-name": { # wrong key name
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                            "subnet_id": "1",
                            "range": {
                                "range_1": {
                                    "start": "192.168.1.100",
                                    "stop": "192.168.1.200"
                                }
                            }
                        },
                        "192.168.10.0/24": {
                            "subnet_id": "2",
                            "range": {
                                "range_1": {
                                    "start": "192.168.10.100",
                                    "stop": "192.168.10.200"
                                }
                            }
                        }
                    }
                }
            }
        }
    ),
    id="test_verify_failed_2"
)

test_verify_failed = [
    test_verify_failed_1,
    test_verify_failed_2,
]