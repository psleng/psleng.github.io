from app.core.api.http.cmd.command import Command
import pprint


def format_description(description: str) -> str:

    return description.replace(' ', '_')


class DHCPCommand(Command):
    """
    Command class for DHCP commands
    Support the following VyOS commands:
    
    # DHCPv4
    set/delete service dhcp-server disable
    set/delete service dhcp-server listen-interface <interface-name>
    set/delete service dhcp-server shared-network-name <pool-name>
    set/delete service dhcp-server shared-network-name <pool-name> description <description-text>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> subnet-id <subnet-id>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> range <range-name> start <start-ip-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> range <range-name> stop <stop-ip-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> lease 0
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> lease <lease-time-in-second>

    # Option commands
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option name-server <ipv4-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option default-router <ipv4-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option domain-name <domain-name>
    
    # DHCPv6
    set/delete service dhcpv6-server listen-interface <interface-name>
    set/delete service dhcpv6-server shared-network-name <pool-name>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> subnet-id <subnet-id>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> lease-time default <default-time>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> lease-time maximum <default-time>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> lease-time minimum <default-time>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len1> range <range-name> prefix <prefix/len2>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len1> range <range-name> prefix <prefix/len2>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> range <range-name> start <ipv6-address>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> range <range-name> stop <ipv6-address>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option name-server <ipv6-adress>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option sntp-server <ipv6-address>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option nis-domain <domain>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option nis-server <ipv6-address>
    set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option sip-server {<ipv6-address>|<fqdn>}
	set/delete service dhcpv6-server shared-network-name <pool-name> subnet <prefix/len> option domain-search <fqdn>

    # Option commands
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option name-server <ipv4-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option default-router <ipv4-address>
    set/delete service dhcp-server shared-network-name <pool-name> subnet <subnet/len> option domain-name <domain-name>

    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'dhcp'))
            self.attributes = {
                'dhcp': {
                    'shared-network-name': {},
                    'listen-interface': None,
                    'disable': False
                },
                'dhcpv6': {
                    'shared-network-name': {},
                    'listen-interface': None
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing DHCP command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a command string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        """Return the list of raw commands"""
        return self.vyos_cmds

    def _process_subnet(self, dhcp_type, network_name, subnet, subnet_config):
        """Process a subnet configuration and generate appropriate commands"""
        if dhcp_type == 'dhcp':
            base = ['service', 'dhcp-server', 'shared-network-name', network_name, 'subnet', subnet]
        else:
            base = ['service', 'dhcpv6-server', 'shared-network-name', network_name, 'subnet', subnet]
        
        if 'subnet_id' in subnet_config:
            self.generate(*base, 'subnet-id', subnet_config['subnet_id'])
        elif 'subnet-id' in subnet_config:
            self.generate(*base, 'subnet-id', subnet_config['subnet-id'])
        
        if dhcp_type == 'dhcp':
            if 'lease' in subnet_config and isinstance(subnet_config['lease'], str) and str(subnet_config['lease']).strip() != '':
                self.generate(*base, 'lease', str(subnet_config['lease']).strip())
                
            # Process DHCPv4 options
            if 'option' in subnet_config:    
                if 'default-router' in subnet_config['option']:
                    self.generate(*base, 'option', 'default-router', subnet_config['option']['default-router'])
                elif 'default_router' in subnet_config['option']:
                    self.generate(*base, 'option', 'default-router', subnet_config['option']['default_router'])
                    
                if 'name-server' in subnet_config['option']:
                    self.generate(*base, 'option', 'name-server', subnet_config['option']['name-server'])
                elif 'name_server' in subnet_config['option']:
                    self.generate(*base, 'option', 'name-server', subnet_config['option']['name_server'])
                    
                if 'domain-name' in subnet_config['option']:
                    self.generate(*base, 'option', 'domain-name', subnet_config['option']['domain-name'])
                elif 'domain_name' in subnet_config['option']:
                    self.generate(*base, 'option', 'domain-name', subnet_config['option']['domain_name'])
                    
        elif dhcp_type == 'dhcpv6':
            if 'lease-time' in subnet_config:
                lease_time = subnet_config['lease-time']
                if 'default' in lease_time:
                    self.generate(*base, 'lease-time', 'default', lease_time['default'])
                if 'maximum' in lease_time:
                    self.generate(*base, 'lease-time', 'maximum', lease_time['maximum'])
                if 'minimum' in lease_time:
                    self.generate(*base, 'lease-time', 'minimum', lease_time['minimum'])
        
        if 'range' in subnet_config:
            for range_name, range_config in subnet_config['range'].items():
                range_base = [*base, 'range', range_name]
                
                if 'start' in range_config:
                    self.generate(*range_base, 'start', range_config['start'])
                if 'stop' in range_config:
                    self.generate(*range_base, 'stop', range_config['stop'])

        if 'prefix' in subnet_config and dhcp_type == 'dhcpv6':
            for prefix_name, prefix_config in subnet_config['prefix'].items():
                prefix_base = [*base, 'prefix', prefix_name]
                
                if 'prefix' in prefix_config:
                    self.generate(*prefix_base, 'prefix', prefix_config['prefix'])
                    
        # Process DHCPv6 options
        if 'option' in subnet_config and dhcp_type == 'dhcpv6':
            options = subnet_config['option']
            
            # Process both hyphenated and underscore option keys
            def process_option(hyphen_key, value_key=None):
                underscore_key = hyphen_key.replace('-', '_')
                value_key = value_key or hyphen_key
                
                if hyphen_key in options:
                    value = options[hyphen_key]
                    if isinstance(value, str):
                        self.generate(*base, 'option', value_key, value)
                    else:
                        for item in value:
                            self.generate(*base, 'option', value_key, item)
                elif underscore_key in options:
                    value = options[underscore_key]
                    if isinstance(value, str):
                        self.generate(*base, 'option', value_key, value)
                    else:
                        for item in value:
                            self.generate(*base, 'option', value_key, item)
            
            # Process all option types
            process_option('name-server')
            process_option('sntp-server')
            process_option('nisplus-domain')
            process_option('nisplus-server')
            process_option('nis-domain')
            process_option('nis-server')
            process_option('sip-server')
            
            # domain-name/domain-search
            if 'domain-name' in options:
                self.generate(*base, 'option', 'domain-search', options['domain-name'])
            elif 'domain_name' in options:
                self.generate(*base, 'option', 'domain-search', options['domain_name'])
                    

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """
        Generate VyOS commands for DHCP configuration
        
        Input format:
        {
            'listen_interface': ['eth1', 'eth2'],
            'shared_network_name': {
                'dhcp1': {
                    'subnet': {
                        '192.168.1.0/24': {
                            'lease': '86400',
                            'disable': {},
                            'range': {
                                'range_1': {
                                    'start': '192.168.1.100',
                                    'stop': '192.168.1.200'
                                }
                            },
                            'subnet_id': '1'
                        }
                    }
                },
                'dhcp2': {
                    'subnet': {
                        '192.168.10.0/24': {
                            'lease': '86400',
                            'range': {
                                'range_2': {
                                    'start': '192.168.10.100',
                                    'stop': '192.168.10.100'
                                }
                            },
                            'subnet_id': '2'
                        }
                    }
                }
            }
        }
        """
        try:
            if not data:
                return []
            
            self.cmds = []
            self.vyos_cmds = []
            
            dhcp_type = self.resource

            if 'disable' in data:
                self.generate('service', f'{dhcp_type}-server', 'disable')
            
            if 'listen_interface' in data and data['listen_interface']:
                for interface in data['listen_interface']:
                    self.generate('service', f'{dhcp_type}-server', 'listen-interface', interface)
            
            if 'shared_network_name' in data:
                for network_name, network_config in data['shared_network_name'].items():
                    network_base = ['service', f'{dhcp_type}-server', 'shared-network-name', network_name]
                    
                    # self.generate(*network_base)

                    if 'authoritative' in network_config and network_config['authoritative'] != False:
                        self.generate(*network_base, 'authoritative')

                    if 'option' in network_config:
                        for bootfile_key in ['bootfile-name', 'bootfile_name']:
                            if bootfile_key in network_config['option'] and type(network_config['option'][bootfile_key]) == str and network_config['option'][bootfile_key].strip() != '':
                                self.generate(*network_base, 'option', 'bootfile-name', network_config['option'][bootfile_key].strip())
                    
                    if 'description' in network_config and type(network_config['description']) == str and network_config['description'].strip() != '':
                        self.generate(*network_base, 'description', format_description(network_config['description']))
                    
                    if 'subnet' in network_config:
                        for subnet, subnet_config in network_config['subnet'].items():
                            # self.generate(*network_base, 'subnet', subnet)
                            
                            if 'disable' in subnet_config:
                                self.generate(*network_base, 'subnet', subnet, 'disable')
                            
                            if 'subnet_id' in subnet_config:
                                subnet_config['subnet-id'] = str(subnet_config.pop('subnet_id'))
                            
                            self._process_subnet(dhcp_type, network_name, subnet, subnet_config)
                    if 'interface' in network_config and type(network_config['interface']) == str and network_config['interface'].strip() != '':
                        self.generate(*network_base, 'interface', network_config['interface'].strip())
                    
                    # delete entire pool if del_config is exactly the same as current config
                    if self.operator == 'delete' and 'shared_network_name' in current_config and \
                        network_name in current_config['shared_network_name'] and \
                            network_config == current_config['shared_network_name'][network_name]:
                        self.generate(*network_base)

            return self.cmds

        except Exception as e:
            print(f"Error generating DHCP commands: {e}")
            return []


class DHCPRelayCommand(Command):

    """
    Command class for DHCP Relay commands
    Support the following VyOS commands:
    
    set/delete service dhcp-relay 
    set/delete service dhcp-relay disable
    set/delete service dhcp-relay relay-options relay-agents-packets replace
    set/delete service dhcp-relay relay-options relay-agents-packets forward
    set/delete service dhcp-relay relay-options relay-agents-packets discard
    set/delete service dhcp-relay relay-options relay-agents-packets append

    set/delete service dhcp-relay relay-options hop-count <hop-count>
    set/delete service dhcp-relay relay-options max-size <packet-size>
    set/delete service dhcp-relay listen-interface <interface-name>
    
    """
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'dhcp-relay'))
            self.attributes = {
                'listen-interface': [],
                'server': [],
                'disable': False,
                'relay-options': {
                    'relay-agents-packets': 'forward',
                    'hop-count': 10,
                    'max-size': 576
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing DHCP Relay command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a command string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        """Return the list of raw commands"""
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """
        Generate VyOS commands for DHCP Relay configuration
        
        Input format:
        {
            'listen_interface': ['eth1', 'eth2'],
            'server': ['192.168.1.1', '192.168.2.1'],
            'disable': False,
            'relay_options': {
                'relay_agents_packets': 'forward',
                'hop_count': 10,
                'max_size': 576
            }
        }
        """
        try:
            if not data:
                return []
            
            self.cmds = []
            self.vyos_cmds = []
            
            # self.generate('service', 'dhcp-relay')
            
            if 'disable' in data:
                self.generate('service', 'dhcp-relay', 'disable')
            
            if 'listen_interface' in data and data['listen_interface']:
                for interface in data['listen_interface']:
                    self.generate('service', 'dhcp-relay', 'listen-interface', interface)
            
            if 'upstream_interface' in data and data['upstream_interface']:
                for usiface in data['upstream_interface']:
                    self.generate('service', 'dhcp-relay', 'upstream-interface', usiface)
            
            if 'server' in data and data['server']:
                for server in data['server']:
                    self.generate('service', 'dhcp-relay', 'server', server)
            
            if 'relay_options' in data and data['relay_options']:
                relay_options = data['relay_options']
                
                if 'relay_agents_packets' in relay_options:
                    packet_option = relay_options['relay_agents_packets']
                    if packet_option in ['replace', 'forward', 'discard', 'append']:
                        self.generate('service', 'dhcp-relay', 'relay-options', 'relay-agents-packets', packet_option)
                
                if 'hop_count' in relay_options:
                    hop_count = relay_options['hop_count']
                    self.generate('service', 'dhcp-relay', 'relay-options', 'hop-count', hop_count)
                
                if 'max_size' in relay_options:
                    max_size = relay_options['max_size']
                    self.generate('service', 'dhcp-relay', 'relay-options', 'max-size', max_size)
            
            return self.cmds
            
        except Exception as e:
            print(f"Error generating DHCP Relay commands: {e}")
            return []


if __name__ == "__main__":
    # Test data for DHCPv4
    test_data_v4 = {
        'listen_interface': ['eth1', 'eth2'],
        'shared_network_name': {
            'dhcp1': {
                'subnet': {
                    '192.168.1.0/24': {
                        'lease': '86400',
                        'disable': {},
                        'range': {
                            'range_1': {
                                'start': '192.168.1.100',
                                'stop': '192.168.1.200'
                            }
                        },
                        'subnet_id': '1',
                        'default-router': '192.168.1.1',
                        'name-server': '192.168.1.2',
                        'domain-name': 'example.com'
                    }
                }
            },
            'dhcp2': {
                'subnet': {
                    '192.168.10.0/24': {
                        'lease': '86400',
                        'range': {
                            'range_2': {
                                'start': '192.168.10.100',
                                'stop': '192.168.10.100'
                            }
                        },
                        'subnet_id': '2',
                        'default-router': '192.168.10.1',
                        'name-server': '192.168.10.2',
                        'domain-name': 'example.net'
                    }
                }
            }
        }
    }
    
    # Test data for DHCPv6
    test_data_v6 = {
        'listen_interface': ['eth1', 'eth2'],
        'shared_network_name': {
            'dhcp1': {
                'subnet': {
                    '2001:db8::/64': {
                        'lease-time': {
                            'default': '86400',
                            'maximum': '172800',
                            'minimum': '43200'
                        },
                        'range': {
                            'range_1': {
                                'start': '2001:db8::100',
                                'stop': '2001:db8::200',
                                'prefix': '2001:db8:1::/64'
                            }
                        },
                        'subnet_id': '1',
                        'option': {
                            'name-server': ['2001:db8::1', '2001:db8::2'],
                            'domain-search': ['example.com', 'example.org']
                        }
                    }
                }
            },
            'dhcp2': {
                'subnet': {
                    '2001:db8:1::/64': {
                        'lease-time': {
                            'default': '86400',
                            'maximum': '172800',
                            'minimum': '43200'
                        },
                        'range': {
                            'range_2': {
                                'start': '2001:db8:1::100',
                                'stop': '2001:db8:1::200',
                                'prefix': '2001:db8:2::/64'
                            }
                        },
                        'subnet_id': '2',
                        'option': {
                            'name-server': ['2001:db8:1::1', '2001:db8:1::2'],
                            'domain-search': ['example.net', 'example.io']
                        }
                    }
                }
            }
        }
    }
    
    # Test the DHCPv4 command generation
    dhcp_cmd_v4 = DHCPCommand(operator='set', resource='dhcp')
    commands_v4 = dhcp_cmd_v4.generate_commands(test_data_v4)
    print("DHCPv4 Commands:")
    for cmd in commands_v4:
        print(cmd)
    
    # Test the DHCPv6 command generation
    dhcp_cmd_v6 = DHCPCommand(operator='set', resource='dhcpv6')
    commands_v6 = dhcp_cmd_v6.generate_commands(test_data_v6)
    print("\nDHCPv6 Commands:")
    for cmd in commands_v6:
        print(cmd)