import pytest

test_final_1 = pytest.param(
    {
        "parsed_input": {
            "json_input": {},
            "validated_input": {},
            "current_config": {},
            "validated_input": {},
            "parsed_input": {},
            "diff_created": {},
            "diff_deleted": {}
        },
        "generate_config": {
            "set_cmds": [],
            "delete_cmds": [],
            "processed_set_config": {},
            "processed_delete_config": {}
        },
        "process_config": {
            "curr_config": {},
            "merged_del": {},
            "merged_set": {}
        },
        "verify": {
            "verify_result": False
        }
    },
    id="test_final_1"
)

test_final = [
    test_final_1
]