from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from app.db.database import db


class WireguardPeerAllowedIP(db.Model):
    __tablename__ = 'vyos_config_wireguard_peer_allowed_ip'
    id = Column(Integer, primary_key=True)
    allowed_ip = Column(String, nullable=False)
    peer_id = Column(Integer, ForeignKey('vyos_config_wireguard_peer.id'), nullable=False)


class WireguardPeerConfig(db.Model):
    __tablename__ = 'vyos_config_wireguard_peer'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    public_key = Column(String)
    description = Column(String)
    endpoint_address = Column(String)
    endpoint_port = Column(Integer)
    persistent_keepalive = Column(Integer)
    preshared_key = Column(String)
    interface_id = Column(Integer, ForeignKey('vyos_config_wireguard_interface.id'), nullable=False)
    allowed_ips = relationship('WireguardPeerAllowedIP', backref='peer', cascade="all, delete-orphan")


class WireguardAddress(db.Model):
    __tablename__ = 'vyos_config_wireguard_address'
    id = Column(Integer, primary_key=True)
    address = Column(String, nullable=False)
    interface_id = Column(Integer, ForeignKey('vyos_config_wireguard_interface.id'), nullable=False)


class WireguardInterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_wireguard_interface'
    id = Column(Integer, primary_key=True)
    iface_name = Column(String, nullable=False, unique=True)
    description = Column(String)
    private_key = Column(String)
    listen_port = Column(Integer)
    addresses = relationship('WireguardAddress', backref='interface', cascade="all, delete-orphan")
    peers = relationship('WireguardPeerConfig', backref='interface', cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        db.session.query(WireguardPeerAllowedIP).delete()
        db.session.query(WireguardPeerConfig).delete()
        db.session.query(WireguardAddress).delete()
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict):
        try:
            cls.truncate()
            for iface_name, iface_config in data.items():
                new_interface = cls(
                    iface_name=iface_name,
                    description=iface_config.get('description'),
                    private_key=iface_config.get('private-key'),
                    listen_port=iface_config.get('port')
                )
                db.session.add(new_interface)

                if 'address' in iface_config:
                    addresses = iface_config['address']
                    if not isinstance(addresses, list):
                        addresses = [addresses]
                    for addr in addresses:
                        new_addr = WireguardAddress(address=addr, interface=new_interface)
                        db.session.add(new_addr)

                if 'peer' in iface_config:
                    for peer_name, peer_data in iface_config['peer'].items():
                        new_peer = WireguardPeerConfig(
                            name=peer_name,
                            public_key=peer_data.get('public-key'),
                            description=peer_data.get('description'),
                            endpoint_address=peer_data.get('address'),
                            endpoint_port=peer_data.get('port'),
                            persistent_keepalive=peer_data.get('persistent-keepalive'),
                            preshared_key=peer_data.get('preshared-key'),
                            interface=new_interface
                        )
                        db.session.add(new_peer)

                        if 'allowed-ips' in peer_data:
                            allowed_ips = peer_data['allowed-ips']
                            if not isinstance(allowed_ips, list):
                                allowed_ips = [allowed_ips]
                            for ip in allowed_ips:
                                new_allowed_ip = WireguardPeerAllowedIP(allowed_ip=ip, peer=new_peer)
                                db.session.add(new_allowed_ip)
            
            db.session.commit()
        except Exception as e:
            print(f"Error refreshing Wireguard interface data: {e}")
            raise e

    def serialize(self):
        peers = {}
        for peer in self.peers:
            peers[peer.name] = {
                'public-key': peer.public_key,
                'description': peer.description,
                'address': peer.endpoint_address,
                'port': peer.endpoint_port,
                'persistent-keepalive': peer.persistent_keepalive,
                'preshared-key': peer.preshared_key,
                'allowed-ips': [ip.allowed_ip for ip in peer.allowed_ips]
            }

        return {
            'iface_name': self.iface_name,
            'description': self.description,
            'private_key': self.private_key,
            'listen_port': self.listen_port,
            'address': [addr.address for addr in self.addresses],
            'peer': peers
        }