from app.core.operation.ethernet.parser import parse_to_ethernet_config
from app.core.operation.wifi.parser import parse_to_wifi_config


def parse_to_interface_config(intf_type: str, data: dict):
    if intf_type == "ethernet":
        return parse_to_ethernet_config(data)
    elif intf_type == "wireless":
        return parse_to_wifi_config(data)
    else:
        return data

def parse_interface_config(data: dict):

    return data


def parse_to_system_config(data: dict):
    system_config = {
        "wireless": {}
    }
    if data.get("countryCode", None):
        system_config['wireless']['country_code'] = data.get("countryCode")

    return system_config

def parse_system(data: dict):
    system_config = {
        "wireless": {}
    }
    if data.get("country-code", None):
        system_config['wireless']['country_code'] = data.get("country-code")

    return system_config
