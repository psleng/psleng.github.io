from jinja2 import Environment
from jinja2 import FileSystemLoader
from jinja2 import ChainableUndefined

import functools
import ipaddress

_FILTERS = {}

@functools.lru_cache(maxsize=2)
def _get_environment(location=None):
    from os import getenv

    if location is None:
        loc_loader=FileSystemLoader(DEFAULT_TEMPLATE_DIR)
    else:
        loc_loader=FileSystemLoader(location)
    env = Environment(
        # Don't check if template files were modified upon re-rendering
        auto_reload=False,
        # Cache up to this number of templates for quick re-rendering
        cache_size=100,
        loader=loc_loader,
        trim_blocks=True,
        undefined=ChainableUndefined,
        extensions=['jinja2.ext.loopcontrols']
    )
    env.filters.update(_FILTERS)
    env.tests.update(_TESTS)
    return env

def register_filter(name, func=None):
    """Register a function to be available as filter in templates under given name.

    It can also be used as a decorator, see below in this module for examples.

    :raise RuntimeError:
        when trying to register a filter after a template has been rendered already
    :raise ValueError: when trying to register a name which was taken already
    """
    if func is None:
        return functools.partial(register_filter, name)
    if _get_environment.cache_info().currsize:
        raise RuntimeError(
            "Filters can only be registered before rendering the first template"
        )
    if name in _FILTERS:
        raise ValueError(f"A filter with name {name!r} was registered already")
    _FILTERS[name] = func
    return func


@register_filter('is_ipv6')
def is_ipv6(text):
    """
    Check if addr is an IPv6 address/network
    """
    if not text:
        return False

    try:
        if '/' in text:
            ipaddress.IPv6Network(text)
        else:
            ipaddress.IPv6Address(text)
        return True
    except:
        return False


@register_filter('is_ipv4')
def is_ipv4(text):
    """
    Check if addr is an IPv4 address/network
    """
    if not text:
        return False

    try:
        if '/' in text:
            ipaddress.IPv4Network(text)
        else:
            ipaddress.IPv4Address(text)
        return True
    except:
        return False


@register_filter('is_v4_dest_prefix')
def is_v4_dest_prefix(text):
    if not text:
        return False
    if '/' not in text:
        return False
    try:
        ipaddress.IPv4Network(text)
        return True
    except:
        return False

@register_filter('is_v6_dest_prefix')
def is_v6_dest_prefix(text):
    if not text:
        return False
    if '/' not in text:
        return False
    try:
        ipaddress.IPv6Network(text)
        return True
    except:
        return False

@register_filter('is_v4_nexthop')
def is_v4_nexthop(text):
    if not text:
        return False
    try:
        ipaddress.IPv4Address(text)
        return True
    except:
        return False

@register_filter('is_v6_nexthop')
def is_v6_nexthop(text):
    if not text:
        return False
    try:
        ipaddress.IPv6Address(text)
        return True
    except:
        return False
