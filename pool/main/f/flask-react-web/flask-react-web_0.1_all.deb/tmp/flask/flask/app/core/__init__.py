from flask import Blueprint

vyos_bp = Blueprint('vyos', __name__)

from . import routes