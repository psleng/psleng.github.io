from app.core.network.ntp.command_ntp import NTPCommand
from app.test.core.network.ntp.test_cases._test_case_generate_config import test_set, test_delete, test_process_commands
import pytest
from app.test.core.base import TestGenerateConfig
from app.core.utils.process_config import process_commands


class TestNTPCommand(TestGenerateConfig):
    __test__ = True

    @pytest.fixture
    def cmd_class(self):
        return NTPCommand

    @pytest.fixture
    def resource(self):
        return 'ntp'

    @pytest.fixture
    def cmd(self):
        return NTPCommand()
    
    @pytest.fixture
    def ntp_cmd_set(self):
        return NTPCommand(operator='set')
    
    @pytest.fixture
    def ntp_cmd_delete(self):
        return NTPCommand(operator='delete')
    

    def test_ntp_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    

    def test_ntp_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)

    
    @pytest.mark.parametrize("test_data", test_set)
    def test_generate_commands_set(self, ntp_cmd_set, test_data):
        super().test_generate_commands_set(ntp_cmd_set, test_data)


    @pytest.mark.parametrize("test_data", test_delete)
    def test_generate_commands_delete(self, ntp_cmd_delete, test_data):
        super().test_generate_commands_delete(ntp_cmd_delete, test_data)


    @pytest.mark.parametrize("test_data", test_process_commands)
    def test_process_commands(self, test_data):
        super().test_process_commands(test_data)


    def test_get_commands_empty(self):
        super().test_get_commands_empty(NTPCommand)
    

    def test_command_format(self):
        cmd = NTPCommand(operator='set')

        config = {'server': {'pool.ntp.org': {}}}
        
        result = cmd.generate_commands(config)
        
        assert result[0] == '{"op":"set", "path": ["service","ntp","server","pool.ntp.org"]}'
        assert cmd.get_commands()[0] == 'service ntp server pool.ntp.org'
