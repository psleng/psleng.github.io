import os
from dataclasses import dataclass
from enum import Enum, StrEnum
from app.config import global_config
from dotenv import load_dotenv
import requests
from sqlalchemy.cyextension.resultproxy import operator
from typing import overload
import json
from app.core.api.api import API_REQUEST
# from .cmd import SHOW_ALL_CONFIGS
from app.log.logger import logger

SHOW_ALL_CONFIGS = '{"op": "showConfig", "path": []}'
SHOW_INTERFACE_CONFIGS = '{"op": "showConfig", "path": ["interfaces"]}'
SHOW_SAML_CONFIG = '{"op": "showConfig", "path": ["system", "login", "saml"]}'
SAVE_CONFIGS = '{"op": "save", "file": "/opt/vyatta/etc/config/config.boot"}'

class Action(Enum):
    RETRIEVE = 1
    RESET = 2
    REBOOT = 3
    POWER_OFF = 4
    IMAGE = 5
    SHOW = 6
    GENERATE = 7
    CONFIGURE = 8
    CONFIG_FILE = 9
    AUTH = 10

class Method(StrEnum):
    POST = "POST"
    PUT = "PUT"
    GET = "GET"
    DELETE = "DELETE"


class HTTPRequest(API_REQUEST):

    def __init__(self, hostname=None, apikey=None, port=None, protocol=None):
        super().__init__()
        load_dotenv()
        self.url = None
        if hostname and apikey and port and protocol:
            self.hostname = hostname
            self.apikey = apikey 
            self.port = port
            self.protocol = protocol
        else:
            self.hostname = os.environ.get("VYOS_HOSTNAME")
            self.apikey = os.environ.get("VYOS_APIKEY")
            self.port = os.environ.get("VYOS_PORT") 
            self.protocol = os.environ.get("VYOS_PROTOCOL")
        self.set_url(protocol=self.protocol, hostname=self.hostname, port=self.port)

    def __enter__(self):
        print("Entering the context")
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        print("Exiting the context")
        return False
        
    def set_url(self, protocol, hostname, port):
        self.url = f"{protocol}://{hostname}:{port}/"

    def show_all_configs(self):
        return self.send_request(action=Action.RETRIEVE, data=SHOW_ALL_CONFIGS, verify=False)
        
    def send_request(self, action: Action, data, verify: bool):
        if isinstance(data, list):
            data = '[' + ', '.join(data) + ']'
        payload = {
            'data': data,
            'key': self.apikey
        }
        headers = {}
        response = requests.request(
            method=Method.POST.name.lower(),
            url=self.url + action.name.lower(),
            headers=headers,
            data=payload,
            verify=verify
        )
        logger.log("URL: ")
        logger.log(self.url + action.name.lower())
        logger.log("Payload: ")
        logger.log(payload)
        logger.log("Response: ")
        logger.log(response.status_code, response.json())

        # if action is configure and result success then save running configuration to config.boot
        if response.status_code == 200 and action.name.lower() == "configure":
            payload = {
                'data': SAVE_CONFIGS,
                'key': self.apikey
            }
         
            response_save = requests.request(
                method=Method.POST.name.lower(),
                url=self.url + "config-file",
                headers=headers,
                data=payload,
                verify=verify
            )

            if response_save.status_code != 200:
                # Failed to save running configuration to config.boot
                return response_save
        if response.status_code >= 400:
            logger.log(f"Failed to {action.name.lower()} with status code {response.status_code}")
            logger.log(response.json())

        return response

if __name__ == "__main__":
    load_dotenv()
    req = HTTPRequest()
    show_interface_configs = SHOW_INTERFACE_CONFIGS
    show_all_configs = SHOW_ALL_CONFIGS
    res = req.send_request(action=Action.RETRIEVE, data=show_all_configs, verify=False)
    print(res.json())
