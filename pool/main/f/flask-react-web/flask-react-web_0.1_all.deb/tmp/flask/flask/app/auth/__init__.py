from flask import Blueprint
# Create a Blueprint instance
auth_bp = Blueprint('auth', __name__)


from . import routes
from .models import *