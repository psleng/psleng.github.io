
import pytest
import json

# Test data for validation
test_case_valid = [
    pytest.param(
    {
        "valid_json": json.dumps({
            "routes": [
                {
                    "dest_prefix": "0.0.0.0/0",
                    "nexthop": "192.168.1.1",
                    "route_type": "nexthop",
                    "distance": "1"
                }
            ],
            "route_ver": "v4"
        })
    },
    id="valid_json_1"),
    pytest.param(
    {
        "valid_json": json.dumps({
            "routes": [
                {
                    "dest_prefix": "10.0.0.0/24",
                    "interface": "eth0",
                    "route_type": "interface",
                    "distance": "10"
                }
            ],
            "route_ver": "v4"
        })
    },
    id="valid_json_2")
]

test_case_invalid = [
    pytest.param(
    {
        "invalid_json": json.dumps({
            "routes": [
                {
                    "dest_prefix": "invalid_prefix",
                    "nexthop": "192.168.1.1",
                    "route_type": "nexthop"
                }
            ],
            "ver": "v4" # Wrong key name
        })
    },
    id="invalid_json_1"),
    pytest.param(
    {
        "invalid_json": json.dumps({
            "routes": [
                {
                    "dest_prefix": 200000, # Wrong data type
                    "nexthop": "999.999.999.999",
                    "route_type": "nexthop"
                }
            ],
            "route_ver": "v4"
        })
    },
    id="invalid_json_2")
]

test_case_minimal = [
    pytest.param(
    {
        "minimal_json": json.dumps({
            "route_ver": "v4"
        })
    },
    id="minimal_json_1")
]

test_case_comparison = [
    pytest.param(
    {
        "current_config": {
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {}
                }
            }
        },
        "new_config": {
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {},
                    "192.168.2.1": {"distance": "10"}
                }
            }
        },
        "expected_diff": {
            "created": {
                "0.0.0.0/0": {
                    "next-hop": {
                        "192.168.2.1": {"distance": "10"}
                    }
                }
            },
            "deleted": {
            }
        }
    },
    id="comparison_1"),
    pytest.param(
    {
        "current_config": {
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {},
                    "192.168.2.1": {"distance": "10"}
                }
            }
        },
        "new_config": {
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {}
                }
            }
        },
        "expected_diff": {
            "created": {},
            "deleted": {
                "0.0.0.0/0": {
                    "next-hop": {
                        "192.168.2.1": {"distance": "10"}
                    }
                }
            }
        }
    },
    id="comparison_2")
]
