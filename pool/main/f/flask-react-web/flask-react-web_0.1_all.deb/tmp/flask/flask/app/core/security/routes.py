from flask import jsonify, request
from app.auth.utils import login_required
from app.core.security.models import FirewallOperation, FirewallSettings, Firewallv4, Firewallv6
from app.core.security import vyos_security_bp
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.models import Interface
from app.core.security.models import UpdateFirewallDTO, VerifyFirewallDTO
from app.core.security.parser.firewall import parse_to_firewall_config
from app.core.api.http.cmd.compare import compare_configs
import pprint
import sys

@vyos_security_bp.route('/firewall', methods=['GET'])
# @login_required
def get_firewall():
    # Query from VyOS
    # current_firewall = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL)
    # print(current_firewall)
    # Query interfaces
    interfaces = Interface.get_interface_names()
    firewallv4 = Firewallv4.query.all()
    firewallv6 = Firewallv6.query.all()
    firewall_settings = FirewallSettings.query.all()
    firewall = {
        "ipv4": [],
        "ipv6": [],
        "settings": [],
        "interfaces": interfaces
    }
    for rule in firewallv4:
        firewall["ipv4"].append(rule.serialize())
    for rule in firewallv6:
        firewall["ipv6"].append(rule.serialize())
    for setting in firewall_settings:
        firewall["settings"].append(setting.serialize())
    return jsonify(firewall), 200



@vyos_security_bp.route('/firewall/opr/log', methods=['GET'])
def get_firewall_opr_log():
    try:
        # Query from db
        firewall = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_OPR_LOG)
        return jsonify(firewall), 200
    except Exception as e:
        return jsonify(str(e)), 500


@vyos_security_bp.route('/firewall/opr', methods=['GET'])
def get_firewall_opr():
    try:
        # Query from db
        firewall = FirewallOperation.get_all_serialized()
        return jsonify(firewall), 200
    except Exception as e:
        return jsonify(str(e)), 500


@vyos_security_bp.route('/firewall/opr/gql', methods=['GET'])
def get_firewall_opr_gql():
    try:
        firewall_opr = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_OPR_GQL)
        return firewall_opr, 200
    except Exception as e:
        return jsonify(str(e)), 500


@vyos_security_bp.route('/firewall/query/gql', methods=['GET'])
def get_firewall_query_gql():
    try:
        firewall_query = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_QUERY_GQL)
        return firewall_query, 200
    except Exception as e:
        return jsonify(str(e)), 500

@vyos_security_bp.route('/firewall', methods=['PUT'])
@login_required
def update_firewall():

    try:
        data = UpdateFirewallDTO.model_validate_json(request.data)
        # print("Validated data:", data)
        firewallv4 = data.firewallv4
        firewallv6 = data.firewallv6
        advanced_settings = data.advancedSettings
        zone_based_firewall = data.zoneBasedFirewall

        # Current VyOS firewall
        current_firewall = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL)
        print("Current Firewall data:")
        print(pprint.pformat(current_firewall, indent=2, width=80))

        # Parse new config to VyOS format
        
        new_config = parse_to_firewall_config(data.model_dump())
        print("New config:")
        print(pprint.pformat(new_config, indent=2, width=80))

        # Diff new config with current config
        diff = compare_configs(new_config, current_firewall)

        print("Diff config:")
        print(pprint.pformat(diff, indent=2, width=80))
        
        r = []
        if diff:
            # Send updates to VyOS
            res = api_manager.call(
                action=API_ACTION.UPDATE, 
                target=API_TARGET.FIREWALL, 
                data={"current": current_firewall, "new": new_config, "diff": diff}
            )

            # Get new configs after update
            firewall_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL)
            Firewallv4.refresh(firewall_config, None)
            Firewallv6.refresh(firewall_config, None)
            FirewallSettings.refresh(firewall_config, None)
       

            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            else:
                r.append(res)
                return jsonify(r), 200

        return jsonify({"message": "No changes detected"}), 200
        
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@vyos_security_bp.route('/firewall/verify', methods=['POST'])
@login_required
def verify_firewall():
    try:
        data = VerifyFirewallDTO.model_validate_json(request.data)
        new_config = parse_to_firewall_config(data.model_dump())
        print("Parsed config:")
        print(pprint.pformat(new_config, indent=2, width=80))
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.FIREWALL, data=new_config)
        if verify == "None" or verify == "" or verify is None:
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400
    