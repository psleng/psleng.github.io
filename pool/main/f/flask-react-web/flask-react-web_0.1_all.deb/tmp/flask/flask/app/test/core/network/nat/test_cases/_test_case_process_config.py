import pytest

test_set = [
    pytest.param(
        {
            "current_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                }
            },
            "set_config": {
                "source": {
                    "rule": {
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        },
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_set_1"
    ),
    pytest.param(
        {
            "current_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                }
            },
            "set_config": {
                "destination": {
                    "rule": {
                        "200": {
                            "inbound-interface": {
                                "name": "eth0"
                            },
                            "protocol": "tcp",
                            "destination": {
                                "address": "203.0.113.10",
                                "port": "80"
                            },
                            "translation": {
                                "address": "192.168.1.10",
                                "port": "8080"
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                },
                "destination": {
                    "rule": {
                        "200": {
                            "inbound-interface": {
                                "name": "eth0"
                            },
                            "protocol": "tcp",
                            "destination": {
                                "address": "203.0.113.10",
                                "port": "80"
                            },
                            "translation": {
                                "address": "192.168.1.10",
                                "port": "8080"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_set_2"
    )
]

test_delete = [
    pytest.param(
        {
            "current_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        },
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "source": {
                    "rule": {
                        "200": {}
                    }
                }
            },
            "expected_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_delete_1"
    ),
    pytest.param(
        {
            "current_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                },
                "destination": {
                    "rule": {
                        "200": {
                            "inbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.10"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "destination": {
                    "rule": {
                        "200": {}
                    }
                }
            },
            "expected_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        }
                    }
                },
                "destination": {
                    "rule": {}
                }
            }
        },
        id="test_process_delete_2"
    )
]

test_set_delete = [
    pytest.param(
        {
            "current_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        },
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "source": {
                    "rule": {
                        "200": {}
                    }
                }
            },
            "set_config": {
                "source": {
                    "rule": {
                        "300": {
                            "outbound-interface": {
                                "name": "eth2"
                            },
                            "translation": {
                                "address": "192.168.2.1"
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "source": {
                    "rule": {
                        "100": {
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "translation": {
                                "address": "masquerade"
                            }
                        },
                        "300": {
                            "outbound-interface": {
                                "name": "eth2"
                            },
                            "translation": {
                                "address": "192.168.2.1"
                            }
                        }
                    }
                }
            }
        },
        id="test_process_set_delete_1"
    )
]
