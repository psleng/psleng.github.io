from abc import ABC, abstractmethod
from enum import StrEnum
from app.core.api.http.srv.system_performance import fetch_ram as fetch_ram_http, fetch_cpu as fetch_cpu_http
from app.core.api.http.srv.system_info import fetch_system_info as fetch_system_info_http
from app.core.operation.utils import measure_time
from app.core.api.http.http_api import HTTP_API
from app.core.api.ansible.ansible_api import ANSIBLE_API
from app.core.api.http.http_request import HTTPRequest
from app.core.api.http.graphql_requests import GraphqlRequest
from app.core.api.api import ServiceProvider
from app.core.utils.validate.validator import Validator



class API_Manager():
    def __init__(self):
        self.manager = None

    def init_app(self, app, manager_type: str):
        # Inject dependencies:
        # - app instance/context
        # - service provider ( http_api, graphql_api and validator )

        if manager_type == "http":
            service_provider = ServiceProvider(
                http_service=HTTPRequest(),
                graphql_service=GraphqlRequest(),
                verify_service=Validator()
            )
            self.manager = HTTP_API(app, service_provider)
        else:
            service_provider = ServiceProvider(
                http_service=None,
                graphql_service=None,
                verify_service=None
            )
            self.manager = ANSIBLE_API(app, service_provider)
        
        self.config = app.config

    def get_api_type(self):
        return self.manager.get_api_type()
    
    def call(self, *args, **kwargs):
        return self.manager.call(
            action=kwargs.get('action'),
            target=kwargs.get('target'),
            data=kwargs.get('data')
        )

api_manager = API_Manager()