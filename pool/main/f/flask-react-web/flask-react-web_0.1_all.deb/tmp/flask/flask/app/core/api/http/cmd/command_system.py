from app.core.api.http.cmd.command import Command

class SystemCommand(Command):
    """
    Command class for system commands.
    Support the following VyOS commands:

    set/delete system domain-name <domain-name>
    set/delete system host-name <host-name>
    set/delete system time-zone <time-zone>
    """

    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.domain_name = kwargs.get('domain_name')
        self.host_name = kwargs.get('host_name')
        self.timezone = kwargs.get('timezone')
        self.wireless = kwargs.get('wireless')
        self.vyos_commands = []

    def generate_commands(self, diff: None, current_config: None, new_config: None) -> list[str]:
        """Generate VyOS commands for system configuration."""
        commands = []

        if self.operator == 'set':
            if self.domain_name:
                commands.append(
                    f'{{"op": "set", "path": ["system", "domain-name", "{self.domain_name}"]}}'
                )
                self.vyos_commands.append(f'set system domain-name {self.domain_name}')
            if self.host_name:
                commands.append(
                    f'{{"op": "set", "path": ["system", "host-name", "{self.host_name}"]}}'
                )
                self.vyos_commands.append(f'set system host-name {self.host_name}')
            if self.timezone:
                commands.append(
                    f'{{"op": "set", "path": ["system", "time-zone", "{self.timezone}"]}}'
                )
                self.vyos_commands.append(f'set system time-zone {self.timezone}')
            if self.wireless:
                if self.wireless.get('country_code', None):
                    country_code = self.wireless['country_code']
                    commands.append(
                        f'{{"op": "set", "path": ["system", "wireless", "country-code", "{country_code}"]}}'
                    )
                    self.vyos_commands.append(f'set system wireless country-code {country_code}')
        elif self.operator == 'delete':
            if self.domain_name:
                commands.append(
                    f'{{"op": "delete", "path": ["system", "domain-name"]}}'
                )
                self.vyos_commands.append('delete system domain-name')
            if self.host_name:
                commands.append(
                    f'{{"op": "delete", "path": ["system", "host-name"]}}'
                )
                self.vyos_commands.append('delete system host-name')
            if self.timezone:
                commands.append(
                    f'{{"op": "delete", "path": ["system", "time-zone"]}}'
                )
                self.vyos_commands.append('delete system time-zone')
        return commands

    def get_commands(self):
        return self.vyos_commands

    def get_vyos_commands(self) -> list[str]:
        """Get the equivalent VyOS CLI commands for documentation/debugging."""
        commands = []

        if self.operator == 'set':
            if self.domain_name:
                commands.append(f'set system domain-name {self.domain_name}')
            if self.host_name:
                commands.append(f'set system host-name {self.host_name}')
            if self.timezone:
                commands.append(f'set system time-zone {self.timezone}')
        elif self.operator == 'delete':
            if self.domain_name:
                commands.append('delete system domain-name')
            if self.host_name:
                commands.append('delete system host-name')
            if self.timezone:
                commands.append('delete system time-zone')

        return commands


def print_commands(cmd: SystemCommand, description: str):
    """Helper function to print both JSON and CLI commands."""
    print(f"\n{description}")
    print("JSON Commands:")
    for command in cmd.generate_commands():
        print(f"  {command}")
    print("VyOS CLI Commands:")
    for command in cmd.get_vyos_commands():
        print(f"  {command}")


if __name__ == "__main__":
    cmd1 = SystemCommand(
        operator='set',
        resource='system',
        domain_name='example.com',
        host_name='vyos-router',
        time_zone='America/Toronto'
    )
    print_commands(cmd1, "TEST 1: Set all system parameters")

    cmd2 = SystemCommand(
        operator='set',
        resource='system',
        domain_name='new-domain.com'
    )
    print_commands(cmd2, "TEST 2: Set only domain name")

    cmd3 = SystemCommand(
        operator='delete',
        resource='system',
        domain_name='example.com',
        host_name='vyos-router'
    )
    print_commands(cmd3, "TEST 3: Delete domain name and hostname")

    cmd4 = SystemCommand(
        operator='set',
        resource='system',
        time_zone='America/New_York'
    )
    print_commands(cmd4, "TEST 4: Update timezone only")

    cmd5 = SystemCommand(
        operator='delete',
        resource='system',
        domain_name='example.com',
        host_name='vyos-router',
        time_zone='America/Toronto'
    )
    print_commands(cmd5, "Example 5: Delete all system parameters")