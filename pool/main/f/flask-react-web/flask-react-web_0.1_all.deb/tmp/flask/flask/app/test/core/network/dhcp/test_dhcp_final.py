"""Test class for DHCP entire flow of updating config, includes:
    - parse_input
    - generate_config
    - process_config
    - verify
"""

import pytest
from app.test.conftest import test_service_provider
from app.core.network.dhcp.models import UpdateDHCPDTO
from app.core.network.dhcp.command_dhcp import DHCPCommand, DHCPRelayCommand
from app.core.network.dhcp.parser import parse_to_dhcp_config
from app.test.core.network.dhcp.test_cases._test_case_final import test_update_final
from app.test.core.base import TestFinal

class TestDHCPUpdateFinal(TestFinal):
    __test__ = False

    @pytest.fixture
    def cmd_set(self):
        return DHCPCommand(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return DHCPCommand(operator='delete')

    @pytest.fixture
    def success_verification(self):
        return ['None', '']

    @pytest.fixture
    def parser(self):
        return parse_to_dhcp_config
    
    @pytest.fixture
    def dto_model(self):
        return UpdateDHCPDTO

    @pytest.mark.parametrize("test_data", test_update_final)
    def test_nat_update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data):
        super()._update_final(
            success_verification=success_verification,
            parser=parser,
            dto_model=dto_model,
            test_service_provider=test_service_provider,
            cmd_set=cmd_set,
            cmd_delete=cmd_delete,
            test_data=test_data
        )
