from pydantic import BaseModel

class RunCommandDTO(BaseModel):
    command: str