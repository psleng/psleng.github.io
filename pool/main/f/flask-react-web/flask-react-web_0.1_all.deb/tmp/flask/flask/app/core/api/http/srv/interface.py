from copy import deepcopy
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_INTERFACE_VALUES, SHOW_INTERFACE_CONFIGS
from app.core.operation.interface import is_deletable_interface, load_interfaces_json_v3
from app.core.api.http.cmd.command_interface import InterfaceCommand
from app.event.models import AsyncJob
from uuid import uuid4
from logging import getLogger, INFO
from flask import session
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set
from app.core.operation.parser import parse_interface_config
from app.socket.socket_manager import socket_manager
from app.core.operation.ethernet.command_ethernet import EthernetCommand
from app.core.operation.wifi.command_wifi import WifiInterfaceCommand
from app.core.operation.bridge.command_bridge import BridgeCommand
from app.core.operation.wifi.parser import parse_wifi
from app.core.operation.wifi.models import WiFiInterfaceConfig
from app.core.network.dhcp.models import DHCPPool
from app.core.models import Interface
from app.core.operation.wifi.fixed_configs import fixed_wifi_configs
from app.core.api.http.cmd.command_system import SystemCommand
import pprint
from app.core.models import System
from app.core.operation.cellular.parser import parse_cellular_op_info
from app.core.operation.openvpn.command_openvpn import OpenvpnCommand
from app.core.operation.wireguard.command_wireguard import WireguardCommand
from app.core.operation.wireguard.parser import parse_wireguard_monitor_info

logger = getLogger(__name__)
logger.setLevel(INFO)

def create_interface_address(self, data):
    print(data)

def fetch_interface_config(provider, data=None):
    res = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_CONFIGS, verify=False)
    return res


def fetch_interface(provider, data=None):
    interface_conf = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_CONFIGS, verify=False)
    interface_op = provider.http_service.send_request(action=Action.SHOW, data=SHOW_INTERFACE_VALUES, verify=False)
    interfaces = load_interfaces_json_v3(interface_op.json()['data'], interface_conf.json()['data'])
    
    return interfaces

def fetch_interface_gql(provider, data=None):
    
    interface_op = provider.graphql_service.send_request(function_name='ShowInterfaces', data=None, verify=False) 
    # print("Interface Operation: ")
    # print(pprint.pformat(interface_op.json()['data'], indent=2, width=80)) 
    return interface_op.json()['data']

def _create_interface(provider, data):
    cmd_data = {
        "operator": "set",
        "resource": "interfaces",
        "intf_type": data.get('intf_type'),
        "name": data.get('name'),
        "description": data.get('desc'),
        "address": data.get('address')
    }

    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address'), desc=cmd_data.get('description')
    )

    cmds = intf_c.generate_commands()
    res = []
    for cmd in cmds:
        
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })

        AsyncJob.create({
            "job_id": str(uuid4()),
            "params": cmd,
            "result": success
        })
    
    return res


def create_interface(provider, data):
    try:
        pass
    except Exception as e:
        return jsonify({'error': str(e)}), 400


def update_interface(provider, data):
    cmd_data = {
        "operator": "set",
        "resource": "interfaces",
        "intf_type": data.get('intf_type'),
        "name": data.get('name'),
        "description": data.get('desc'),
        "address": data.get('address')
    }
    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address'), desc=cmd_data.get('description')
    )
    cmds = intf_c.generate_commands()
    res = []
    for cmd in cmds:
        res.append({
            "cmd": cmd,
            "success": provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        })

    return res

def verify_and_generate_commands_ethernet(provider, current_config, new_config, name):
    
    set_cmds = []
    iface_set_cmd = EthernetCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, new_config)
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = EthernetCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "interfaces"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}))    
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    return {
        "verify": verify,
        "merged_config": merged_config,
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }

def update_ethernet_by_name(provider, data):
    print("Update interface by name: ")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    intf_type = data.get('intf_type')
    name = data.get('name')

    r = []
    _data_ethernet = verify_and_generate_commands_ethernet(provider, current_config, new_config, diff)
    verify = _data_ethernet.get('verify')
    merged_config = _data_ethernet.get('merged_config')
    set_cmds = _data_ethernet.get('set_cmds')
    delete_cmds = _data_ethernet.get('delete_cmds')
    
    
    if str(verify) != "None":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    parse_interface_conf = parse_interface_config({"interfaces": merged_config})
    print("Parsed interface config to update:")
    print(pprint.pformat(parse_interface_conf, indent=2, width=80))

    # Update DB
    # TODO: Need to consider.

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Interface",
                "content": "Interface is successfully updated"
            }
    )
    
    current_bridge = None
    _current_config = data.get('current')
    # Find current bridge interface is it exists
    for bridge_name, bridge_config in _current_config['bridge'].items():
        if 'member' in bridge_config and 'interface' in bridge_config['member'] and name in bridge_config['member']['interface']:
            current_bridge = bridge_name
            break
    if current_bridge:
        # remove the current bridge interface
        # notes: new bridge will be created in the set command
        delete_cmds.append(f'{{"op":"delete", "path": ["interfaces","bridge","{current_bridge}","member","interface","{name}"]}}')

    # if is bridge mode, remove the address field of the interface
    bridge_mode = False
    if 'bridge' in diff['created'] and 'interface' in diff['created']['bridge']:
        _bridge_interface = diff['created']['bridge']['interface']
        if _bridge_interface:
            bridge_mode = True


    if bridge_mode:
        # remove all of the address fields
        delete_cmds.append(f'{{"op":"delete", "path": ["interfaces","{intf_type}","{name}","address"]}}')

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_wireguard_by_name(provider, data):
    print("Update wireguard by name")
    print(data)
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    name = data.get('name')
    
    set_cmds = []
    iface_set_cmd = WireguardCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, new_config)
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = WireguardCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "wireguard"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}))    
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    if str(verify) != "None":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Wireguard",
                "content": "Wireguard is successfully updated"
            }
    )
    
    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    r = []
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    # if len(cmds) > 0:
    #     res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
    #     r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_openvpn_by_name(provider, data):
    print("Update openvpn by name")
    print(data)
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))
    current_config = data.get('current')
    new_config = data.get('new')
    name = data.get('name')
    
    set_cmds = []
    iface_set_cmd = OpenvpnCommand(operator='set', resource='interfaces', name=name)
    set_cmds = iface_set_cmd.generate_commands({name: diff['created']}, current_config, new_config)
    sc = iface_set_cmd.get_commands()

    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = OpenvpnCommand(operator='delete', resource='interfaces', name=name)
    delete_cmds = iface_delete_cmd.generate_commands({name: diff['deleted']}, current_config, new_config)
    dc = iface_delete_cmd.get_commands()

    print("Delete commands: ")
    print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "openvpn"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}))    
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update OpenVPN",
                "content": "OpenVPN is successfully updated"
            }
    )
    
    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    r = []
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    # if len(cmds) > 0:
    #     res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
    #     r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r



def verify_and_generate_commands_system_wireless(current_config, new_config, diff):
    """
        Verify and generate commands for system wireless
    """
    new_conf = deepcopy(current_config)
    if new_conf and new_conf.get('wireless', None) and new_conf.get('wireless', {}).get('country_code', None) \
        and new_config.get('wireless', {}).get('country_code', None):
        new_conf['wireless']['country_code'] = new_config['wireless']['country_code']
    
    set_cmds = []
    iface_set_cmd = SystemCommand(operator='set', resource='system', wireless=new_conf.get('wireless'))
    set_cmds = iface_set_cmd.generate_commands(diff['created'], current_config, new_conf)
    sc = iface_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    return {
        "merged_config": new_conf,
        "set_cmds": set_cmds,
        "delete_cmds": []
    }


def verify_and_generate_commands_bridge(provider, current_config, new_config):
    """
        When updating wireless, only change bridge address if verification is passed
    """
    new_conf = deepcopy(current_config)
    if new_conf and new_conf.get('br1', None) and new_conf.get('br1', {}).get('address', {}):
        new_conf['br1']['address'] = new_config['address']

    # Dict representation of the bridge interface with only address to delete
    del_conf = {}
    if current_config and current_config.get('br1', None) and current_config.get('br1', {}).get('address', {}):
        del_conf['br1'] = {'address': current_config['br1']['address']}
    
    print("Current bridge")
    print(current_config)

    print("New bridge")
    print(new_conf)

    print("Del bridge")
    print(del_conf)

    set_cmds = []
    iface_set_cmd = BridgeCommand(operator='set', resource='interfaces')
    
    set_cmds = iface_set_cmd.generate_commands(
        new_conf, 
        {"interfaces": {"bridge": current_config}}, 
        {"interfaces": {"bridge": new_conf}}
    )

    sc = iface_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = BridgeCommand(operator='delete', resource='interfaces')
    delete_cmds = iface_delete_cmd.generate_commands(
        del_conf, 
        {"interfaces": {"bridge": del_conf}}, 
        {"interfaces": {"bridge": new_conf}}
    )

    dc = iface_delete_cmd.get_commands()
    new_delete_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_delete_configs, indent=2, width=80))

    service = "bridge"
    verify = None
    if new_conf:
        verify = provider.verify_service.query_interface_verify(service, 'br1', new_conf['br1'])

    return {
        "verify": verify,
        "merged_config": new_conf,
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }

def verify_and_generate_commands_wireless(provider, current_config, new_config, diff):
    
    # Set fixed commands:
    set_fixed_cmds = []
    iface_set_fixed_cmd = WifiInterfaceCommand(operator='set', resource='interfaces')
    set_fixed_cmds = iface_set_fixed_cmd.generate_commands(fixed_wifi_configs, current_config, new_config)
    sfc = iface_set_fixed_cmd.get_commands()
    # print("Set fixed commands: ")
    # print(pprint.pformat(sfc, indent=2, width=80))
    new_set_fixed_configs = process_commands(sfc)
    # print("New fixed set configs: ")
    # print(pprint.pformat(new_set_fixed_configs, indent=2, width=80))

    set_cmds = []
    iface_set_cmd = WifiInterfaceCommand(operator='set', resource='interfaces')
    set_cmds = iface_set_cmd.generate_commands(diff['created'], current_config, new_config)
    sc = iface_set_cmd.get_commands()
    # print("Set commands: ")
    # print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    # print("New set configs: ")
    # print(pprint.pformat(new_set_configs, indent=2, width=80))

    delete_cmds = []
    iface_delete_cmd = WifiInterfaceCommand(operator='delete', resource='interfaces')
    delete_cmds = iface_delete_cmd.generate_commands(diff['deleted'], current_config, new_config)
    dc = iface_delete_cmd.get_commands()
    # print("Delete commands: ")
    # print(pprint.pformat(dc, indent=2, width=80))
    new_delete_configs = process_commands(dc)
    # print("New delete configs: ")
    # print(pprint.pformat(new_delete_configs, indent=2, width=80))

    # Validate configs
    service = "wireless"
    wireless_ifaces = ['wlan0', 'wlan1', 'wlan2', 'wlan3']
    curr_config = {}
    for wiface in wireless_ifaces:
        curr_config[wiface] = provider.verify_service.query_interface_config(service, wiface)

    current_config = curr_config if curr_config else {}

    # print("Current raw wireless config: ")
    # print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_delete_configs.get('interfaces', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('interfaces', {}))    
    
    verify = None
    verify_iface = {}
    if merged_config:
        for wiface in wireless_ifaces:
            verify_iface[wiface] = provider.verify_service.query_interface_verify(service, wiface , merged_config.get('interfaces', {}).get(wiface, {}))
    
    # print("Verify wireless: ")
    # print(pprint.pformat(verify, indent=2, width=80))

    return {
        "verify": verify,
        "merged_config": merged_config,
        "set_cmds": set_fixed_cmds + set_cmds,
        "delete_cmds": delete_cmds
    }


def update_wireless(provider, data):
    
    from app.core.network.dhcp.service import (
        verify_and_generate_commands as verify_and_generate_commands_dhcp
    )

    print("Update interface by name: ")
    print(pprint.pformat(data, indent=2, width=80))
    username = session['username']
    diff = data.get('diff')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    current_config = data.get('current')
    new_config = data.get('new')
    intf_type = data.get('intf_type')
    new_dhcp = data.get('new_dhcp')
    current_dhcp = data.get('current_dhcp')
    diff_dhcp = data.get('diff_dhcp')
    current_bridge = data.get('current_bridge')
    new_bridge = data.get('new_bridge')
    current_system_wireless = data.get('current_system_wireless')
    new_system_wireless = data.get('new_system_wireless')
    diff_system_wireless = data.get('diff_system_wireless')

    r = []
    #==== Verify and generate commands each service ==== #

    # Verify and Update System Wireless
    print("Verify and update system wireless")
    print("Current system wireless: ")
    print(pprint.pformat(current_system_wireless, indent=2, width=80))
    print("New system wireless: ")
    print(pprint.pformat(new_system_wireless, indent=2, width=80))
    print("Diff system wireless: ")
    print(pprint.pformat(diff_system_wireless, indent=2, width=80))
    _data_system_wireless = verify_and_generate_commands_system_wireless(current_system_wireless, new_system_wireless, diff_system_wireless)
    verify_system_wireless = _data_system_wireless.get('verify')
    merged_config_system_wireless = _data_system_wireless.get('merged_config')
    set_cmds_system_wireless = _data_system_wireless.get('set_cmds')
    delete_cmds_system_wireless = _data_system_wireless.get('delete_cmds')
    
    # Verify and Update Bridge
    print("Verify and update bridge")
    _data_bridge = verify_and_generate_commands_bridge(provider, current_bridge, new_bridge)
    verify_bridge = _data_bridge.get('verify')
    merged_config_bridge = _data_bridge.get('merged_config')
    set_cmds_bridge = _data_bridge.get('set_cmds')
    delete_cmds_bridge = _data_bridge.get('delete_cmds')
    print("Parsed bridge config to update: ")
    print(pprint.pformat(merged_config_bridge, indent=2, width=80))

    if str(verify_bridge) != "None":
        
        print("Bridge Validation Error: ")
        print(pprint.pformat(verify_bridge, indent=2, width=80))
        # print("Type of Bridge Error: ", type(verify_bridge))
        # return Exception(verify_bridge)

    # Verify and Update DHCP
    print("Verify and update DHCP")
    _data_dhcp = verify_and_generate_commands_dhcp(provider, current_dhcp, new_dhcp, diff_dhcp)
    verify_dhcp = _data_dhcp.get('verify')
    merged_config_dhcp = _data_dhcp.get('merged_config')
    set_cmds_dhcp = _data_dhcp.get('set_cmds')
    delete_cmds_dhcp = _data_dhcp.get('delete_cmds')
    # print("Parsed dhcp config to update:")
    # print(pprint.pformat(merged_config_dhcp, indent=2, width=80))

    if str(verify_dhcp) != "None" and str(verify_dhcp) != "":
        print("DHCP Validation Error: ")
        print(pprint.pformat(verify_dhcp, indent=2, width=80))
        # print("Type of DHCP Error: ", type(verify_dhcp))
        return Exception(verify_dhcp)

    # Verify and Update Wireless
    print("Verify and update wireless")
    _data_wireless = verify_and_generate_commands_wireless(provider, current_config, new_config, diff)
    verify_wireless = _data_wireless.get('verify')
    merged_config_wireless = _data_wireless.get('merged_config')
    set_cmds_wireless = _data_wireless.get('set_cmds')
    delete_cmds_wireless = _data_wireless.get('delete_cmds')
    
    if str(verify_wireless) != "None":
        print("Validation Error: ")
        print(pprint.pformat(verify_wireless, indent=2, width=80))
        # print("Type of Error: ", type(verify_wireless))
        return Exception(verify_wireless)
    
    parse_interface_conf = parse_wifi({"wireless": merged_config_wireless}, merged_config_bridge)
    print("Parsed interface config to update:")
    print(pprint.pformat(parse_interface_conf, indent=2, width=80))


    #==== Update DB after verifications ==== #

    # Update WiFi DB
    WiFiInterfaceConfig.refresh(None, parse_interface_conf, "full")
    # Update DHCP DB
    DHCPPool.update_pool_by_name("wifi-dhcp", merged_config_dhcp)
    # Update Bridge DB
    Interface.create_ipv4("br1", merged_config_bridge.get('br1', {}).get('address', '/'))
    # Update System Wireless Country Code DB
    System.set_wireless_country_code(country_code=new_system_wireless.get('wireless', {}).get('country_code', None))


    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Interface",
                "content": "Interface is successfully updated"
            }
    )
    
    excecuted_cmds = list(set(delete_cmds_wireless)) + list(set(delete_cmds_dhcp)) + list(set(delete_cmds_bridge)) + \
                            list(set(set_cmds_wireless)) + list(set(set_cmds_dhcp)) + list(set(set_cmds_bridge)) + \
                                list(set(set_cmds_system_wireless))


    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    return r


def update_interface_by_name(provider, data):

    intf_type = data.get('intf_type')

    if intf_type == 'wireless':
        return update_wireless(provider, data)
    elif intf_type == 'ethernet':
        return update_ethernet_by_name(provider, data)
    elif intf_type == 'openvpn':
        return update_openvpn_by_name(provider, data)
    elif intf_type == 'wireguard':
        return update_wireguard_by_name(provider, data)


def delete_interface(provider, req_data):
    print('DELETE INTERFACE FUNCTION')
    cmds = []
    for data in req_data:        
        if is_deletable_interface(data.intf_type) == False:
            print("Interface is not deletable")
            logger.info("Interface is not deletable")
            continue
        cmd_data = {
            "operator": "delete",
            "resource": "interfaces",
            "intf_type": data.intf_type,
            "name": data.name
        }

        intf_c = InterfaceCommand(
            operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
            name=cmd_data.get('name')
        )
        cmds.append(intf_c.generate_commands())

    res = []
    for cmd in cmds:
        res.append({
            "cmd": cmd,
            "success": provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        })

    return res


def delete_interface_address(provider, data):
    res = []
    cmd_data = {
        "operator": "delete",
        "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.address
    }

    intf_c = InterfaceCommand(
        operator=cmd_data.get('operator'), resource=cmd_data.get('resource'), intf_type=cmd_data.get('intf_type'),
        name=cmd_data.get('name'), address=cmd_data.get('address')
    )

    cmds = intf_c.generate_commands()

    for cmd in cmds:
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })
    
    return res

def update_interface_address(provider, data):
    res = []
    cmd_data_1 = { "operator": "set", "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.new_address
    }

    cmd_data_2 = { "operator": "delete", "resource": "interfaces",
        "intf_type": data.intf_type,
        "name": data.name,
        "address": data.current_address
    }

    intf_c_1 = InterfaceCommand(
        operator=cmd_data_1.get('operator'), resource=cmd_data_1.get('resource'), intf_type=cmd_data_1.get('intf_type'),
        name=cmd_data_1.get('name'), address=cmd_data_1.get('address')
    )
    
    intf_c_2 = InterfaceCommand(
        operator=cmd_data_2.get('operator'), resource=cmd_data_2.get('resource'), intf_type=cmd_data_2.get('intf_type'),
        name=cmd_data_2.get('name'), address=cmd_data_2.get('address')
    )

    cmds = intf_c_1.generate_commands() + intf_c_2.generate_commands()
    res = []
    for cmd in cmds:
        success = provider.http_service.send_request(action=Action.CONFIGURE, data=cmd, verify=False).json()['success']
        res.append({
            "cmd": cmd,
            "success": success
        })
    

def fetch_wifi_info(provider, data=None):
    
    # interface_op = graphql_req.send_request(function_name='ShowInfoInterfacesWireless', data=None, verify=False) 
    interface_op = provider.graphql_service.send_request(function_name='ShowChannelWirelessQuery', data=None, verify=False) 
    return interface_op.json()['data']


def fetch_wifi_station(provider, data=None):
    intf_name = data.get('intf_name', None)
    if not intf_name:
        return []
    interface_op = provider.graphql_service.send_str_request(function_name='ShowStationsWirelessQuery', data=f'intf_name: "{intf_name}"', verify=False) 
    return interface_op.json()['data']


def fetch_wifi_scan(provider, data=None):
    intf_name = data.get('intf_name', None)
    if not intf_name:
        return []
    interface_op = provider.graphql_service.send_str_request(function_name='ShowScanWirelessQuery', data=f'intf_name: "{intf_name}"', verify=False) 
    return interface_op.json()['data']


def fetch_cellular_info(provider, data=None):
    req = provider.graphql_service.send_request(function_name='ShowDetailWwanQuery', data=f'intf_name: "wwan0"', verify=False) 
    cellular_info = parse_cellular_op_info(req.json()['data'])
    return cellular_info


def fetch_wireguard_info(provider, data=None):
    req = provider.graphql_service.send_request(function_name='ShowWireguardInterfacesWireguardQuery', data=None, verify=False) 
    wireguard_info = parse_wireguard_monitor_info(req.json()['data'])
    return wireguard_info
