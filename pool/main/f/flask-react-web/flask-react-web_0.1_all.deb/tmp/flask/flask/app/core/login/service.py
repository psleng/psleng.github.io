from app.core.api.http.http_request import Action
from app.core.login.command import LoginCommand
from app.core.api.http.cmd.command import SHOW_LOGIN_CONFIG
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete

def fetch_login_config(provider, data):
    resp = provider.http_service.send_request(
        action=Action.RETRIEVE,
        data=SHOW_LOGIN_CONFIG,
        verify=False
    )

    resp_json = resp.json()
    if resp_json.get("success") != True:
        raise Exception(f"{resp_json.get('error', 'Unknown error')}")
    
    resp_data = resp_json.get('data')
    return resp_data

def verify_login_config(provider, data):
    pass

def update_login_config(provider, data):
    diff = data.get('diff')
    current_login_config = data.get('current')
    new_login_config = data.get('new')

    login_set_cmd = LoginCommand(operator='set', resource='system')
    set_cmds = login_set_cmd.generate_commands(diff['created'], current_login_config, new_login_config)
    sc = login_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    login_delete_cmd = LoginCommand(operator='delete', resource='system')
    delete_cmds = login_delete_cmd.generate_commands(diff['deleted'], current_login_config, new_login_config)
    dc = login_delete_cmd.get_commands()
    new_del_configs = process_commands(dc)

    service = "system_login"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"system": {"login": curr_config}} if curr_config else {"system": {"login": {}}}

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    if verify and str(verify) != "None" and str(verify) != "":
        raise Exception(verify)

    executed_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    if executed_cmds:
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=executed_cmds,
            verify=False
        ).json()
        
        return [{
            "cmd": executed_cmds,
            "success": res.get('success'),
            "error": res.get('error')
        }]

    return []
