
import pytest

# Test data for command generation
test_set = [
    pytest.param(
        ({
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {"distance": "1"}
                }
            }
        },
        [
            "protocols static route 0.0.0.0/0 next-hop 192.168.1.1 distance 1"
        ]),
        id="test_route_set_1"
    ),
    pytest.param(
        (
        {
            "0.0.0.0/0": {
                "blackhole": {"distance": "100"}
            }
        },
        [
            "protocols static route 0.0.0.0/0 blackhole distance 100"
        ]),
        id="test_route_set_2"
    ),
    pytest.param(
        ({
            "10.0.0.0/24": {
                "interface": {
                    "eth0": {"distance": "10"}
                }
            }
        },
        [
            "protocols static route 10.0.0.0/24 interface eth0 distance 10"
        ]),
        id="test_route_set_3"
    )
]

test_delete = [
    pytest.param(
        ({
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {"distance": "1"}
                }
            }
        },
        [
            "protocols static route 0.0.0.0/0 next-hop 192.168.1.1"
        ]),
        id="test_route_delete_1"
    ),
    pytest.param(
        (
        {
            "0.0.0.0/0": {
                "blackhole": {"distance": "100"}
            }
        },
        [
            "protocols static route 0.0.0.0/0 blackhole"
        ]),
        id="test_route_delete_2"
    ),
    pytest.param(
        ({
            "10.0.0.0/24": {
                "interface": {
                    "eth0": {"distance": "10"}
                }
            }
        },
        [
            "protocols static route 10.0.0.0/24 interface eth0"
        ]),
        id="test_route_delete_3"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                'protocols static route 0.0.0.0/0 next-hop 192.168.1.1 distance 1'
            ],
            {
                "protocols": {
                    "static": {
                        "route": {
                            "0.0.0.0/0": {
                                "next_hop": {
                                    "192.168.1.1": {"distance": "1"}
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_1"
    ),
    pytest.param(
        (
            [
                'protocols static route 0.0.0.0/0 blackhole distance 100'
            ],
            {
                "protocols": {
                    "static": {
                        "route": {
                            "0.0.0.0/0": {
                                "blackhole": {"distance": "100"}
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_2"
    ),
]