from app.core.operation.bridge.parser import parse_to_bridge_config
from . import vyos_operation_bp
from flask import jsonify, request, current_app, session
from app.core.operation.models import CreateInterfaceDTO, UpdateSystemDatetimeDTO, UpdateSystemInfoDTO, UpdateInterfaceDTO, UpdateEthernetInterfaceByNameDTO, \
      DeleteInterfaceAddressDTO, DeleteInterfaceListDTO, UpdateInterfaceAddressDTO, CreateInterfaceAddressDTO, UpdateWifiInterfaceByNameDTO, UpdateOpenVPNInterfaceByNameDTO
from app.core.models import Interface, Memory, System, ServiceStatistic
from pydantic import ValidationError
from app.event.jobs.interface.fetch_interface import refresh_db_interface_operation
from app.event.jobs.system.performance import refresh_db_memory_operation, salt_fetch_cpu
from app.event.jobs.system.system_info import refresh_db_system_info
from app.event.a_sync.interface import update_intf_async, update_intf_address_async, create_intf_address_async, delete_intf_address_async
from app.core.utils.system_time import system_timestamp, system_utc_timestamp
import subprocess
import os 
from app.core.utils.system import get_load_averages
import threading
from app.auth.utils import login_required
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.operation.ethernet.parser import parse_to_ethernet_config
from app.core.operation.openvpn.parser import parse_to_openvpn_config, parse_current_openvpn_interface_config
from app.core.operation.parser import parse_to_interface_config
from app.core.network.dhcp.parser import parse_to_single_dhcp_pool
import pprint
from app.core.security.models import FirewallOperation
from app.event.jobs.interface.fetch_interface import refresh_db_interface_operation

from app.core.api.http.cmd.compare import compare_configs
from app.core.operation.wifi.models import WiFiInterfaceConfig
from copy import deepcopy
from app.core.network.dhcp.parser import parse_dhcp
from app.core.operation.parser import parse_to_system_config, parse_system
from app.core.models import SystemDefault
from app.log.logger import logger
from app.core.utils.check_os import is_linux
from app.core.operation.models import UserManagement
from app.auth.models import User, TempUserExpiryTime
from app.core.operation.models import UserVerifyDTO, UpdateUserDTO
from app.core.api.http.srv.parser import parse_to_single_user_config, parse_to_user_config, parse_user_db_to_user_config
from app.core.operation.wireguard.parser import parse_to_wireguard_config, parse_current_wireguard_interface_config
from app.core.operation.models import UpdateWireguardInterfaceByNameDTO, CreateWireguardInterfaceDTO
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig
from app.core.operation.wireguard.models import WireguardInterfaceConfig

def run_command(command):
    return subprocess.Popen(command, shell=True, stdout=subprocess.PIPE).stdout.read().decode('utf-8')


@vyos_operation_bp.route('/interface-conf/wifi', methods=['GET'])
def show_wifi_interfaces_config():
    try:
        wifi_iface= WiFiInterfaceConfig.query.first()
        system_conf = System.query.first()
        all_country_codes = SystemDefault.get_def_by_name('country_code')
        wifi_conf = {}
        if wifi_iface:
            wifi_conf = wifi_iface.serialize()
        if system_conf:
            wifi_conf['wireless_country_code'] = system_conf.wireless_country_code
        if all_country_codes:
            country_code_list = all_country_codes.country_code.split(',')
            wifi_conf['all_country_codes'] = country_code_list
        
        return jsonify(wifi_conf), 200
    except Exception as e:
        return jsonify({
            "error": str(e)
        }), 400

@vyos_operation_bp.route('/interface-conf/wireguard', methods=['GET'])
def show_wireguard_interfaces_config():
    try:
        wireguard_ifaces = WireguardInterfaceConfig.query.all()
        if wireguard_ifaces:
            return jsonify([iface.serialize() for iface in wireguard_ifaces]), 200
        return jsonify([]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


    
@vyos_operation_bp.route('/interface-conf/openvpn', methods=['GET'])
def show_openvpn_interfaces_config():
    try:
        openvpn_ifaces = OpenVPNInterfaceConfig.query.all()
        if openvpn_ifaces:
            return jsonify([iface.serialize() for iface in openvpn_ifaces]), 200
        return jsonify([]), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    
@vyos_operation_bp.route('/interface', methods=['GET'])
def show_interfaces():
    try:
        interfaces= []
        for record in Interface.query.filter(Interface.interface_type != "Loopback").all():
            interfaces.append(record.serialize())

        if len(interfaces) == 0:
            interfaces = refresh_db_interface_operation()
            return jsonify([]), 200

        return jsonify(interfaces), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/interface-stat/cellular', methods=['GET'])
def show_interfaces_cellular():
    try:
        cellular_info = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.INTERFACE_CELLULAR)
        logger.debug(f"Cellular info: {cellular_info}")
        return jsonify(cellular_info), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/interface-stat/wifi', methods=['GET'])
def show_interfaces_wifi():
    try:
        wifi = WiFiInterfaceConfig.get_ssid()
        if wifi:
            return jsonify({'ap_ssid': wifi.ap_ssid, 'client_ssid': wifi.client_ssid}), 200
        else:
            return jsonify({'ap_ssid': '', 'client_ssid': ''}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_operation_bp.route('/interface/statistics', methods=['GET'])
def get_interface_statistics():
    try:
        interfaces = Interface.query.filter(Interface.interface_type != "Loopback").all()
    
        interface_stats = {
            'ethernet': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'wifi': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'ap5': 0, 'ap24': 0, 'client5': 0, 'client24': 0 },
            'cellular': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'number': '', 'carrier': '', 'apn': '', 'imei': '', 'signal': '' },   
            'vpn': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
            'bridge': { 'up': 0, 'down': 0, 'rx': 0, 'tx': 0 },
        }
        
        for iface in interfaces:
            iface_dict = iface.serialize()
            iface_type = 'virtual'  # Default type for misc interfaces
            
            if iface.interface_type == 'Ethernet':
                iface_type = 'ethernet'
            elif iface.interface_type in ['WLAN', 'Wireless']:
                iface_type = 'wifi'
            elif iface.interface_type == 'Bridge':
                iface_type = 'bridge'
            elif iface.interface_type in ['WWAN', 'PPPoE','Cellular'] or (isinstance(iface.interface, str) and 'wwan' in iface.interface):
                iface_type = 'cellular'
            elif iface.interface_type in ['OpenVPN', 'WireGuard', 'SSTP', 'L2TPv3', 'VTI']:
                iface_type = 'vpn'
        
            if iface_type not in interface_stats:
                interface_stats[iface_type] = {'up': 0, 'down': 0, 'rx': 0, 'tx': 0, 'tooltip': f'{iface_type} interfaces'}
            
            is_up = iface.admin_state == 'UP'
            if is_up:
                interface_stats[iface_type]['up'] += 1
            else:
                interface_stats[iface_type]['down'] += 1

            if iface.interface == 'wlan0':
                interface_stats['wifi']['ap5'] = 1 if is_up else 0
            elif iface.interface == 'wlan1':
                interface_stats['wifi']['ap24'] = 1 if is_up else 0
            elif iface.interface == 'wlan2':
                interface_stats['wifi']['client5'] = 1 if is_up else 0
            elif iface.interface == 'wlan3':
                interface_stats['wifi']['client24'] = 1 if is_up else 0
            
            interface_stats[iface_type]['rx'] += iface.rx_bytes or 0
            interface_stats[iface_type]['tx'] += iface.tx_bytes or 0

        interface_stats = {k: v for k, v in interface_stats.items() if v['up'] > 0 or v['down'] > 0}

        return jsonify(interface_stats), 200
    except Exception as e:
        return str(e), 400


@vyos_operation_bp.route('/cpu', methods=['POST'])
def performance_cpu_http():
    if not is_linux():
        # Not running on Linux
        perf = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_CPU)
        return jsonify(perf), 200
    else:
        timestamp_date, timestamp_hour = system_timestamp()
        # Optimize by using linux cmd
        # output = run_command('uptime')
        # load_average = output.split("load average:")[1].strip().split(", ")
        load_average = get_load_averages()
        data = {
            "uptime": "1d 12h 30m 6s",
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": system_utc_timestamp(),
            # "load_averages": {"1": float(load_average[0]), "5": float(load_average[1]), "15": float(load_average[2])}
            "load_averages": {
                "1": round(min(float(load_average[1])*100, 100), 1), 
                "5": round(min(float(load_average[5])*100, 100), 1), 
                "15": round(min(float(load_average[15])*100, 100), 1)
            }
        }
        return jsonify(data), 200


def performance_cpu():
    try:    
        timestamp_date, timestamp_hour = system_timestamp()
        cpu = salt_fetch_cpu('hostNameVyOS-1')
        data = {
            "uptime": "",
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": system_utc_timestamp(),
            "load_averages": {
                "1": float(cpu.get('1-min')) *100, 
                "5": float(cpu.get('5-min')) *100, 
                "15": float(cpu.get('15-min'))*100
            }
        }
        return jsonify(data), 200
    except Exception as e:
        
        return jsonify(str(e)), 400
    

@vyos_operation_bp.route('/ram', methods=['POST'])
def performance_memory():

    memory_db = Memory.query.all()

    if len(memory_db) == 0:
        # CALL API
        memory = refresh_db_memory_operation()
        # memory = salt_refresh_db_memory_operation('hostNameVyOS-1')
        return jsonify(memory), 200
    
    r = {
        "memory": {
            "free": memory_db[0].free,
            "used": memory_db[0].used,
        },
        "timestamp": [memory_db[0].date, memory_db[0].time],
        "utc_timestamp": memory_db[0].utc_timestamp
    }
    return jsonify(r), 200


@vyos_operation_bp.route('/system-info', methods=['GET'])
def show_system_info():

    system_info = System.query.first()
    if system_info is None:
        system_info = refresh_db_system_info()
        return jsonify(system_info), 200
    
    return jsonify(system_info.serialize()), 200


@vyos_operation_bp.route('/system-info', methods=['PUT'])
def update_system_info():
    try:
        data = UpdateSystemInfoDTO.model_validate_json(request.data)
        print("System update data input: ")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.SYSTEM, 
            data={
                "systemName": data.systemName,
                "domainName": data.domainName,
                "dateTime": data.dateTime,
                "timezone": data.timezone,
                "ipv4": data.ipv4,
                "ipv6": data.ipv6
            }
        )
        return jsonify(res), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface', methods=['POST'])
@login_required
def create_interface():
    try:
        data = CreateInterfaceDTO.model_validate_json(request.data)
        res = api_manager.call(
            action=API_ACTION.CREATE, 
            target=API_TARGET.INTERFACE, 
            data={"intf_type": data.intf_type, "name": data.name, "desc": data.desc, "address": f"{data.address}/{data.subnet}"}
        )
        refresh_db_interface_operation()
        return jsonify(res), 200
    
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface-sync', methods=['PUT'])
@login_required
def update_interface_sync():
    try:
        data = UpdateInterfaceDTO.model_validate_json(request.data)
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE, 
            data={"intf_type": data.intf_type, "name": data.name, "desc": data.desc, "address": data.address}
        )
        
        refresh_db_interface_operation()

        return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400
    

@vyos_operation_bp.route('/interface', methods=['PUT'])
@login_required
def update_interface():
    try:
        user_id = session['user_id']
        data = UpdateInterfaceDTO.model_validate_json(request.data)
        # Update db
        Interface.update_interface_by_name(name=data.name, ipv4=data.address, desc=data.desc)
        # Create a thread to update Interface in Vyos
        task_thread = threading.Thread(target=update_intf_async, args=[data, current_app.app_context(), user_id])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200

    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface-monitor/wireguard/info', methods=['GET'])
@login_required
def show_interface_monitor_wireguard_info():
    try:
        res = api_manager.call(action=API_ACTION.MONITOR, target=API_TARGET.INTERFACE_WIREGUARD)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/info')
@login_required
def show_interface_monitor_wifi_info():
    try:
        print("Show interface monitor wifi info")
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_INFO)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/<intf_name>/station')
@login_required
def show_inteface_monitor_wifi_station(intf_name):
    try:
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": intf_name})
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/interface-monitor/wifi/ap/station')
@login_required
def show_interface_monitor_wifi_ap_stations():
    try:
        result = []
        wlan0_station = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": 'wlan0'})
        wlan1_station = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_STATION, data={"intf_name": 'wlan1'})
        
        if wlan0_station.get('ShowStationsWirelessQuery', None) and wlan0_station['ShowStationsWirelessQuery'].get('data', None) and \
            wlan0_station['ShowStationsWirelessQuery']['data'].get('result', None):
            for st in wlan0_station['ShowStationsWirelessQuery']['data']['result']:
                st.update({"band": "5GHz"})
                result.append(st)
        
        if wlan1_station.get('ShowStationsWirelessQuery', None) and wlan1_station['ShowStationsWirelessQuery'].get('data', None) and \
            wlan1_station['ShowStationsWirelessQuery']['data'].get('result', None):
            for st in wlan1_station['ShowStationsWirelessQuery']['data']['result']:
                st.update({"band": "2.4GHz"})
                result.append(st)
        
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface-monitor/wifi/<intf_name>/scan')
@login_required
def show_interface_monitor_wifi_scan(intf_name):
    try:
        res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_WIFI_SCAN, data={"intf_name": intf_name})
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/<intf_type>/<name>', methods=['PUT'])
@login_required
def update_interface_by_name(intf_type, name):
    try:
        if intf_type == "ethernet":
            data = UpdateEthernetInterfaceByNameDTO.model_validate_json(request.data)
        elif intf_type == "wireless":
            # print("Update wifi interface by name")
            # print(pprint.pformat(request.data, indent=2, width=80))
            data = UpdateWifiInterfaceByNameDTO.model_validate_json(request.data)
        # print("Update interface by name: ")
        # print(f"Name: {name}")
        # print(f"Intf type: {intf_type}")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_config = parse_to_interface_config(intf_type, data.model_dump())
        # print("New config: ")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        # print("Parsed new config: ")
        # print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
        # print("Current config: ")
        # print(pprint.pformat(current_config.json()['data'][intf_type][name], indent=2, width=80))

        if intf_type != 'wireless':
            diff = compare_configs(new_config, current_config.json()['data'][intf_type][name])
        else:
            match_wlan_config =  {
                "interfaces": {
                    "wireless":{
                        "wlan0": new_config['wlan0'],
                        "wlan1": new_config['wlan1'],
                        "wlan2": new_config['wlan2'],
                        "wlan3": new_config['wlan3']
                    }
                }
            }
            diff = compare_configs(match_wlan_config, {"interfaces": {"wireless": current_config.json()['data'][intf_type]}})
        # Update using the diff

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config.json()['data'], 
                "new": new_config, 
                "diff": diff, 
                "intf_type": intf_type, 
                "name": name
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/ethernet/<name>', methods=['PUT'])
@login_required
def update_ethernet_interface_by_name(name):
    try:
        
        data = UpdateEthernetInterfaceByNameDTO.model_validate_json(request.data)
        # print("Update interface by name: ")
        # print(f"Name: {name}")
        # print(f"Intf type: {intf_type}")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_config = parse_to_interface_config('ethernet', data.model_dump())
        # print("New config: ")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        # print("Parsed new config: ")
        # print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
        # print("Current config: ")
        # print(pprint.pformat(current_config.json()['data'][intf_type][name], indent=2, width=80))
        diff = compare_configs(new_config, current_config.json()['data']['ethernet'][name])
        # Update using the diff

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config.json()['data'], 
                "new": new_config, 
                "diff": diff, 
                "intf_type": 'ethernet', 
                "name": name
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400



@vyos_operation_bp.route('/interface/wireless/<name>', methods=['PUT'])
@login_required
def update_wireless_interface(name):
    try:
        data = UpdateWifiInterfaceByNameDTO.model_validate_json(request.data)
        # print("Update interface by name: ")
        # print(f"Name: {name}")
        # print(f"Intf type: {intf_type}")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dict_config = data.model_dump()
        new_config = parse_to_interface_config('wireless', dict_config['wifi'])
        new_dhcp_wifi_config = parse_to_single_dhcp_pool(dict_config['dhcp'])
        new_system_wireless = parse_to_system_config(dict_config['system'])

        bridge_addr = {
            "address": dict_config.get('wifi', {}).get('network', {}).get('ipv4', {}).get('static', {}).get('address', {}),
            "prefix_length": dict_config.get('wifi', {}).get('network', {}).get('ipv4', {}).get('static', {}).get('prefixLength', {})
        }
        new_bridge_config = parse_to_bridge_config(bridge_addr)
        # print("New wireless config: ")
        # print(pprint.pformat(data.model_dump(), indent=2, width=80))
        # print("Parsed new config: ")
        # print(pprint.pformat(new_config, indent=2, width=80))
        
        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)

        current_config = os_config.get('interfaces')
        current_dhcp = parse_dhcp(os_config.get('service', {}).get('dhcp-server', None))
        current_system_wireless = parse_system(os_config.get('system', {}).get('wireless', None))
        new_dhcp = deepcopy(current_dhcp)
        print("Current wireless config: ")
        print(pprint.pformat(current_config.get('wireless', {}), indent=2, width=80))
        
        if new_dhcp and new_dhcp.get('shared_network_name', None):
            new_dhcp['shared_network_name']['wifi-dhcp'] = new_dhcp_wifi_config

        match_wlan_config =  {
            "interfaces": {
                "wireless":{
                    "wlan0": new_config['wlan0'],
                    "wlan1": new_config['wlan1'],
                    "wlan2": new_config['wlan2'],
                    "wlan3": new_config['wlan3']
                }
            }
        }
        diff = compare_configs(match_wlan_config, {"interfaces": {"wireless": current_config.get('wireless', {})}})
        
        # print("Current DHCP config: ")
        # print(pprint.pformat(current_dhcp, indent=2, width=80))

        # print("New dhcp wifi config: ")
        # print(pprint.pformat(new_dhcp))

        diff_dhcp = compare_configs(new_dhcp, current_dhcp)

        # print("Diff dhcp: ")
        # print(pprint.pformat(diff_dhcp))

        diff_system_wireless = compare_configs(new_system_wireless, current_system_wireless)

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.INTERFACE_BY_NAME, 
            data={
                "current": current_config, 
                "new": new_config, 
                "diff": diff, 
                "intf_type": 'wireless', 
                "current_dhcp": current_dhcp,
                "new_dhcp": new_dhcp,
                "diff_dhcp": diff_dhcp,
                "current_bridge": current_config.get('bridge', {}),
                "new_bridge": new_bridge_config,
                "current_system_wireless": current_system_wireless,
                "new_system_wireless": new_system_wireless,
                "diff_system_wireless": diff_system_wireless
            }
        )
        # Refresh DB
        refresh_db_interface_operation()

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200

    except ValidationError as ve:
        return ve.json(), 400

@vyos_operation_bp.route('/interface/openvpn/<name>', methods=['PUT'])
@login_required
def update_openvpn_interface(name):
    try:
        data = UpdateOpenVPNInterfaceByNameDTO.model_validate_json(request.data)
        new_config = parse_to_openvpn_config(data.model_dump())
        logger.debug("New openvpn config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_openvpn_interface_config(os_config, name)
        logger.debug("Current openvpn config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "openvpn",
                "diff": diff,
                "name": name
            }
        )
        return jsonify({'message': 'Success'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireguard/<name>', methods=['PUT'])
@login_required
def update_wireguard_interface(name):
    try:
        data = UpdateWireguardInterfaceByNameDTO.model_validate_json(request.data)
        new_config = parse_to_wireguard_config(data.model_dump())
        logger.debug("New wireguard config: ")
        logger.debug(pprint.pformat(new_config, indent=2, width=80))

        os_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
        current_config = parse_current_wireguard_interface_config(os_config, name)
        logger.debug("Current wireguard config: ")
        logger.debug(pprint.pformat(current_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        
        api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.INTERFACE_BY_NAME,
            data={
                "current": current_config,
                "new": new_config,
                "intf_type": "wireguard",
                "diff": diff,
                "name": name
            }
        )
        return jsonify({'message': 'Success'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface/wireguard', methods=['POST'])
@login_required
def create_wireguard_interface():
    try:
        req_data = CreateWireguardInterfaceDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.INTERFACE, data=req_data)
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_operation_bp.route('/interface', methods=['DELETE'])
@login_required
def delete_interface():
    try:
        req_data = DeleteInterfaceListDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.DELETE, target=API_TARGET.INTERFACE, data=req_data)

        refresh_db_interface_operation()
        return jsonify(res), 200
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/interface/address', methods=['DELETE'])
@login_required
def delete_interface_address():
    try:
        data = DeleteInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.delete_ipv4(name=data.name, ipv4=data.address)

        task_thread = threading.Thread(target=delete_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400



@vyos_operation_bp.route('/interface/address', methods=['PUT'])
@login_required
def update_interface_address():
    try:
        data = UpdateInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.update_ipv4(name=data.name, current_ip=data.current_address, new_ip=data.new_address)

        task_thread = threading.Thread(target=update_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400



@vyos_operation_bp.route('/interface/address', methods=['POST'])
@login_required
def add_interface_address():
    try:
        data = CreateInterfaceAddressDTO.model_validate_json(request.data)

        # Update db
        Interface.create_ipv4(name=data.name, ipv4=data.address)

        task_thread = threading.Thread(target=create_intf_address_async, args=[data, current_app.app_context(), "ABC"])
        task_thread.start()

        return jsonify({'message': 'Success'}), 200
    except ValidationError as ve:
        return ve.json(), 400


@vyos_operation_bp.route('/system/datetime', methods=['GET'])
@login_required
def get_system_datetime():
    try:
        logger.debug("Getting system datetime...")
        dt_result = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM_DATETIME, data=None)
        
        if isinstance(dt_result, Exception):
            logger.error(f"Error getting datetime: {str(dt_result)}")
            return jsonify({"error": str(dt_result)}), 400
            
        if isinstance(dt_result, dict) and "error" in dt_result:
            logger.error(f"Error in datetime response: {dt_result['error']}")
            return jsonify(dt_result), 400

        logger.debug(f"Successfully got datetime: {dt_result}")

        return jsonify({"datetime": dt_result.get('datetime'), "timezone": dt_result.get('timezone')}), 200
        
    except Exception as e:
        logger.error(f"Exception getting datetime: {str(e)}")
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/wifi', methods=['PUT'])
def update_interface_wifi():
    try:
        print("Update interface wifi")
        return jsonify({'msg': 'success'}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/interface/ethernet', methods=['PUT'])
def update_interface_ethernet():
    try:
        data = {}
        current_config = parse_to_ethernet_config(data)
        print("Update interface ethernet")
        current_ethernet_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_ETHERNET)
        current_router_advert_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.ROUTER_ADVERTISEMENT)
        current_config = {
            "ethernet": current_ethernet_config,
            "router_advertisement": current_router_advert_config
        }
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))

        # diff = compare_configs(current_config, new_config)
        return jsonify({'msg': 'success'}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/services/summary', methods=['GET'])
def get_services_summary():
    default_summary = {
        "firewall": {"accepted": 0, "dropped": 0, "total": 0},
        "ntp": {"stratum": "0", "offset": "0 ms", "leap_status": "Normal"},
        "dhcp": {"active": 0, "available": 0, "lease_time": "0h"},
        "dns": {"servers": 0},
        "nat": {"source-packets": 0, "source-traffic": 0.0, "dest-packets": 0, "dest-traffic": 0.0}
    }
    try:
        service_stats = ServiceStatistic.query.all()
        
        summary = deepcopy(default_summary)

        for stat in service_stats:
            service_name = stat.service_name
            feature = stat.service_feature
            value = stat.service_stat

            if service_name == 'firewall':
                if feature in summary['firewall']:
                    summary['firewall'][feature] = value
            elif service_name == 'nat':
                if feature in summary['nat']:
                    summary['nat'][feature] = value
            elif service_name == 'dns':
                if feature in summary['dns']:
                      summary['dns'][feature] = value
            elif service_name == 'ntp':
                if feature in summary['ntp']:
                    summary['ntp'][feature] = value
            elif service_name == 'dhcp':
                if feature == 'active_lease':
                    summary['dhcp']['active'] = value
                elif feature == 'available_ips':
                    summary['dhcp']['available'] = value
                elif feature == 'lease_time':
                    summary['dhcp']['lease_time'] = value
        
        return jsonify(summary), 200
    
    except Exception as e:
        logger.error(f"Failed to get services summary: {str(e)}")
        return jsonify(default_summary), 200
    

@vyos_operation_bp.route('/user-management', methods=['GET'])
@login_required
def get_users():
    try:
        users = []
        # os users
        os_users = UserManagement.query.all()
        users += [UserManagement.serialize(user) for user in os_users]
        
        # temp user
        db_users = User.query.all()
        users += [User.serialize(user) for user in db_users]

        return jsonify({"users": users}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/user-management/verify', methods=['POST'])
@login_required
def verify_user():
    try:
        data = UserVerifyDTO.model_validate_json(request.data)
        data_dict = data.model_dump()
        user_config = parse_to_single_user_config(data_dict)
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.USER, data={data_dict['user_name']: user_config})
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 400


@vyos_operation_bp.route('/user-management', methods=['PUT'])
@login_required
def update_users():
    try:
        from app.core.utils.process_config import merge_dicts_set

        data = UpdateUserDTO.model_validate_json(request.data)
        logger.debug("Request config:")
        logger.debug(data.model_dump())
        
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.USER)
        logger.debug("Current config:")
        logger.debug(current_config)

        new_config = parse_to_user_config(data.model_dump())
        logger.debug("New parsed config:")
        logger.debug(new_config)

        # Fetch temp user from db
        db_users = User.query.all()
        db_config = parse_user_db_to_user_config(db_users)
        logger.debug("Parsed DB users:")
        logger.debug(db_config['login'])

        # Merge current VyOS config and Db config
        current_config = merge_dicts_set(current_config, db_config['login'])
        logger.debug("Merged configs: ")
        logger.debug(current_config)

        diff = compare_configs(new_config, {"login": current_config})
        logger.debug("Diff config:")
        logger.debug(diff)

        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.USER, 
            data={"current": current_config, "current_db": db_config['login'], "new": new_config, "diff": diff}
        )

        logger.debug("API response:")
        logger.debug(res)

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        else:
            return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception updating users: {str(e)}")
        return jsonify({"error": str(e)}), 400

@vyos_operation_bp.route('/wireguard/key-pair', methods=['POST'])
@login_required
def generate_wireguard_key_pair():
    try:
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.WIREGUARD_KEY_PAIR)
        return jsonify(res), 200
    except Exception as e:
        logger.error(f"Exception generating wireguard key pair: {str(e)}")
        return jsonify({"error": str(e)}), 400
    