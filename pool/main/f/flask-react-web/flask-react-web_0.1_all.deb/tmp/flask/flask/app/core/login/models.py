from pydantic import BaseModel
from pydantic import StrictStr

from typing import Optional
from typing import List
from typing import Dict

class SamlAttributeValueModel(BaseModel):
    value: List[StrictStr]

class SamlLevelModel(BaseModel):
    req: Optional[Dict[StrictStr, SamlAttributeValueModel]]
    suff: Optional[Dict[StrictStr, SamlAttributeValueModel]]
    user: Optional[List[StrictStr]]

class UpdateSamlDTO(BaseModel):
    name: Optional[StrictStr]
    metadata_url: Optional[StrictStr]
    default_sso_level: Optional[StrictStr]
    admin: Optional[SamlLevelModel]
    operator: Optional[SamlLevelModel]
