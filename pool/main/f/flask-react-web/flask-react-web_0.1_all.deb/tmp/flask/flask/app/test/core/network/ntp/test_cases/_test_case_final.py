import pytest

test_final_1 = pytest.param(
    (
        {
            "parsed_input": {
                "json_input": {
                    "servers": [
                        {
                            "address": "0.pool.ntp.org",
                            "pool": True,
                            "interleave": False,
                            "noselect": False,
                            "nts": False,
                            "ptp": False
                        },
                        {
                            "address": "1.pool.ntp.org",
                            "pool": True,
                            "interleave": False,
                            "noselect": True,
                            "nts": False,
                            "ptp": False
                        }
                    ],
                    "allow_clients": [
                        {"address": "192.168.10.0/24"},
                        {"address": "10.0.0.0/24"}
                    ],
                    "interface": "eth3",
                    "listen_address": "192.168.1.1",
                    "leap_second": "system",
                    "ptp": {
                        "port": "319",
                        "interfaces": ["eth3"]
                    }
                },
                "current_config": {
                    "server": {
                        "0.pool.ntp.org": {
                            "pool": {}
                        },
                        "2.pool.ntp.org": {
                            "pool": {}
                        }
                    },
                    "listen-address": "192.168.1.2",
                    "allow-client": {
                        "address": ["192.168.1.0/24"]
                    },
                    "interface": "eth1"
                },
                "validated_input": {
                    'allow_clients': [
                        {
                            'address': '192.168.10.0/24',
                        },
                        {
                            'address': '10.0.0.0/24',
                        },
                    ],
                    'interface': 'eth3',
                    'leap_second': 'system',
                    'listen_address': '192.168.1.1',
                    'ptp': {
                        'interfaces': [
                            'eth3',
                        ],
                        'port': '319',
                    },
                    'servers': [
                        {
                            'address': '0.pool.ntp.org',
                            'interleave': False,
                            'noselect': False,
                            'nts': False,
                            'pool': True,
                            'ptp': False,
                        },
                        {
                            'address': '1.pool.ntp.org',
                            'interleave': False,
                            'noselect': True,
                            'nts': False,
                            'pool': True,
                            'ptp': False,
                        },
                    ],
                },
                "parsed_input": {
                    'allow-client': {
                        'address': [
                            '192.168.10.0/24',
                            '10.0.0.0/24',
                        ],
                    },
                    'interface': 'eth3',
                    'leap-second': 'system',
                    'listen-address': '192.168.1.1',
                    'ptp': {
                        'port': '319',
                        'timestamp-interface': [
                            'eth3',
                        ],
                    },
                    'server': {
                        '0.pool.ntp.org': {
                            'pool': {},
                        },
                        '1.pool.ntp.org': {
                            'noselect': {},
                            'pool': {},
                        },
                    },
                },
                "diff_created": {
                    'server': {
                        '1.pool.ntp.org': {
                            'pool': {},
                            'noselect': {}
                        }
                    },
                    'listen-address': '192.168.1.1',
                    'allow-client': {
                        'address': ['192.168.10.0/24', '10.0.0.0/24']
                    },
                    'interface': 'eth3',
                    'leap-second': 'system',
                    'ptp': {'port': '319', 'timestamp-interface': ['eth3']}
                },
                "diff_deleted": {
                    'server': {
                        '2.pool.ntp.org': {
                            'pool': {}
                        }
                    },
                    'listen-address': '192.168.1.2',
                    'allow-client': {
                        'address': ['192.168.1.0/24']
                    },  
                    'interface': 'eth1'
                },
            },
            "generate_config": {
                "set_cmds": [
                    'service ntp server 0.pool.ntp.org pool',
                    'service ntp server 1.pool.ntp.org noselect',
                    'service ntp server 1.pool.ntp.org pool',
                    'service ntp listen-address 192.168.1.1',
                    'service ntp allow-client address 192.168.10.0/24',
                    'service ntp allow-client address 10.0.0.0/24',
                    'service ntp interface eth3',
                    'service ntp leap-second system',
                    'service ntp ptp port 319',
                    'service ntp ptp timestamp interface eth3',
                ],
                "delete_cmds": [
                    'service ntp server 0.pool.ntp.org pool',
                    'service ntp server 0.pool.ntp.org all',
                    'service ntp server 1.pool.ntp.org noselect',
                    'service ntp server 1.pool.ntp.org pool',
                ],
                "processed_set_config": {
                    'service': {
                        'ntp': {
                            'allow_client': {
                                'address': [
                                    '192.168.10.0/24',
                                    '10.0.0.0/24',
                                ],
                            },
                            'interface': 'eth3',
                            'leap_second': 'system',
                            'listen_address': [
                                '192.168.1.1',
                            ],
                            'ptp': {
                                'port': '319',
                                'timestamp': {
                                    'interface': [
                                        'eth3',
                                    ],
                                },
                            },
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {},
                                },
                                '1.pool.ntp.org': {
                                    'noselect': {},
                                    'pool': {},
                                },
                            },
                        },
                    },
                },
                "processed_delete_config": {
                    'service': {
                        'ntp': {
                            'server': {
                                '0.pool.ntp.org': 'all',
                                '1.pool.ntp.org': {
                                    'noselect': {},
                                    'pool': {},
                                },
                            },
                        },
                    },
                }
            },
            "process_config": {
                "curr_config": {
                    'allow_client': {
                        'address': [
                            '127.0.0.0/8',
                            '10.0.0.0/24',
                        ],
                    },
                    'config_file': '/run/chrony/chrony.conf',
                    'interface': 'eth3',
                    'leap_second': 'system',
                    'listen_address': [
                        '192.168.100.0',
                        '192.168.1.1',
                    ],
                    'ptp': {
                        'port': '319',
                        'timestamp': {
                            'interface': [
                                'eth3',
                            ],
                        },
                    },
                    'server': {
                        '0.pool.ntp.org': {
                            'pool': {},
                        },
                        '1.pool.ntp.org': {
                            'noselect': {},
                            'pool': {},
                        },
                        '2.pool.ntp.org': {},
                        '3.pool.ntp.org': {
                            'interleave': {},
                            'pool': {},
                        },
                        '5.5.5.5': {
                            'interleave': {},
                            'noselect': {},
                            'nts': {},
                            'pool': {},
                        },
                        'test.example.com': {},
                    },
                    'user': '_chrony',
                },
                "merged_del": {
                    'service': {
                        'ntp': {
                            'allow_client': {
                                'address': [
                                    '127.0.0.0/8',
                                    '10.0.0.0/24',
                                    ],
                                },
                                'config_file': '/run/chrony/chrony.conf',
                                'interface': 'eth3',
                                'leap_second': 'system',
                                'listen_address': [
                                    '192.168.100.0',
                                    '192.168.1.1',
                                ],
                                'ptp': {
                                    'port': '319',
                                    'timestamp': {
                                        'interface': [
                                            'eth3',
                                        ],
                                    },
                                },
                                'server': {
                                    '0.pool.ntp.org': {},
                                    '2.pool.ntp.org': {},
                                    '3.pool.ntp.org': {
                                        'interleave': {},
                                        'pool': {},
                                    },
                                    '5.5.5.5': {
                                        'interleave': {},
                                        'noselect': {},
                                        'nts': {},
                                        'pool': {},
                                    },
                                    'test.example.com': {},
                                },
                                'user': '_chrony',
                            },
                        
                    },
                },
                "merged_set":   {
                    'service': {
                        'ntp': {
                            'allow_client': {
                                'address': [
                                    '127.0.0.0/8',
                                    '10.0.0.0/24',
                                    '192.168.10.0/24',
                                ],
                            },
                            'config_file': '/run/chrony/chrony.conf',
                            'interface': 'eth3',
                            'leap_second': 'system',
                            'listen_address': [
                                '192.168.100.0',
                                '192.168.1.1',
                            ],
                            'ptp': {
                                'port': '319',
                                'timestamp': {
                                    'interface': [
                                        'eth3',
                                    ],
                                },
                            },
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {},
                                },
                                '1.pool.ntp.org': {
                                    'noselect': {},
                                    'pool': {},
                                },
                                '2.pool.ntp.org': {},
                                '3.pool.ntp.org': {
                                    'interleave': {},
                                    'pool': {},
                                },
                                '5.5.5.5': {
                                    'interleave': {},
                                    'noselect': {},
                                    'nts': {},
                                    'pool': {},
                                },
                                'test.example.com': {},
                            },
                            'user': '_chrony',
                        },
                    },
                }

            },
            "verify": {
                "verify_result": False
            }

        }
    ),
    id="test_final_1"
)

test_final = [
    test_final_1
]