from app.log.logger import logger

def _process_route_config(route_config: dict) -> list:
    routes = []
    
    for route_prefix, route_data in route_config.items():
        if 'blackhole' in route_data:
            blackhole_info = route_data['blackhole']
            route_entry = {
                'nexthop': None,
                'interface': None,
                'dest_prefix': route_prefix,
                'route_type': 'null',
                'distance': blackhole_info.get('distance', '1') if isinstance(blackhole_info, dict) else '1'
            }
            routes.append(route_entry)
        
        if 'reject' in route_data:
            reject_info = route_data['reject']
            route_entry = {
                'nexthop': None,
                'interface': None,
                'dest_prefix': route_prefix,
                'route_type': 'reject',
                'distance': reject_info.get('distance', '1') if isinstance(reject_info, dict) else '1'
            }
            routes.append(route_entry)
        
        dhcp_key = 'dhcp-interface' if 'dhcp-interface' in route_data else 'dhcp_interface'
        if dhcp_key in route_data:
            dhcp_interfaces = route_data[dhcp_key]
            if isinstance(dhcp_interfaces, list):
                for interface in dhcp_interfaces:
                    route_entry = {
                        'interface': interface,
                        'nexthop': None,
                        'dest_prefix': route_prefix,
                        'route_type': 'interface_dhcp',
                    }
                    routes.append(route_entry)
            else:  # String
                route_entry = {
                    'interface': dhcp_interfaces,
                    'nexthop': None,
                    'dest_prefix': route_prefix,
                    'route_type': 'interface_dhcp',
                }
                routes.append(route_entry)
        
        if 'interface' in route_data:
            interfaces = route_data['interface']
            if isinstance(interfaces, dict):
                for interface, interface_data in interfaces.items():
                    route_entry = {
                        'interface': interface,
                        'nexthop': None,
                        'dest_prefix': route_prefix,
                        'route_type': 'interface',
                        'distance': interface_data.get('distance', '1') if isinstance(interface_data, dict) else '1'
                    }
                    routes.append(route_entry)
            else:  # Handle case where interface is a string
                route_entry = {
                    'interface': interfaces,
                    'nexthop': None,
                    'dest_prefix': route_prefix,
                    'route_type': 'interface',
                    'distance': '1'
                }
                routes.append(route_entry)
        
        nexthop_key = 'next-hop' if 'next-hop' in route_data else 'next_hop'
        if nexthop_key in route_data:
            nexthops = route_data[nexthop_key]
            if isinstance(nexthops, dict):
                for nexthop, nexthop_data in nexthops.items():
                    if isinstance(nexthop_data, dict) and 'interface' in nexthop_data:
                        route_entry = {
                            'nexthop': nexthop,
                            'dest_prefix': route_prefix,
                            'route_type': 'nexthop_interface',
                            'interface': nexthop_data['interface'],
                            'distance': nexthop_data.get('distance', '1')
                        }
                    else:
                        route_entry = {
                            'interface': None,
                            'nexthop': nexthop,
                            'dest_prefix': route_prefix,
                            'route_type': 'nexthop',
                            'distance': nexthop_data.get('distance', '1') if isinstance(nexthop_data, dict) else '1'
                        }
                    routes.append(route_entry)
            else:  # Handle case where next_hop is a string
                route_entry = {
                    'interface': None,
                    'nexthop': nexthops,
                    'dest_prefix': route_prefix,
                    'route_type': 'nexthop',
                    'distance': '1'
                }
                routes.append(route_entry)
    
    return routes

def parse_route_config(route_config: dict) -> list:
    """
    Parse route config to save to db
    Example config:
    {'0.0.0.0/0': {'blackhole': {'distance': '100'}, 'dhcp-interface': ['eth2', 'br1'], 'interface': {'br1': {'distance': '120'}, 'eth2': {'distance': '50'}}, 'next-hop': {'8.8.8.8': {'distance': '200', 'interface': 'eth2'}, '10.10.0.1': {}}}, '255.255.255.0/24': {'blackhole': {'distance': '1'}}}

    Returns a list of route dictionaries in the format:
    [
        {
            'route': '0.0.0.0/0',
            'route_type': 'nexthop',
            'nexthop': '10.10.0.1',
            'distance': '1',
            'interface': 'eth0'
        },
        ...
    ]
    """
    logger.debug("General Route Config: ")
    logger.debug(route_config)

    if 'static' not in route_config:
        return []
    
    if 'route' not in route_config['static']:
        return []
    
    route_config = route_config['static']['route']

    routes = _process_route_config(route_config)
    return routes


def parse_route_config_v6(route_config: dict) -> dict:

    logger.debug("General Route Config: ")
    logger.debug(route_config)

    if 'static' not in route_config:
        return []
    
    if 'route6' not in route_config['static']:
        return []
    
    route_config = route_config['static']['route6']

    routes = _process_route_config(route_config)

    return routes


def parse_to_route_config(data: dict) -> dict:
    """
    Convert a list of route dictionaries back into the nested route configuration format expected by VyOS.
    
    Sample routes data:
    [{'route_type': 'null', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '100', 'interface': None, 'route_table_id': None, 'id': 1}, {'route_type': 'interface_dhcp', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': None, 'interface': 'eth2', 'route_table_id': None, 'id': 2}, {'route_type': 'interface_dhcp', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': None, 'interface': 'br1', 'route_table_id': None, 'id': 3}, {'route_type': 'interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '120', 'interface': 'br1', 'route_table_id': None, 'id': 4}, {'route_type': 'interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '50', 'interface': 'eth2', 'route_table_id': None, 'id': 5}, {'route_type': 'nexthop_interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': '8.8.8.8', 'distance': '200', 'interface': 'eth2', 'route_table_id': None, 'id': 6}, {'route_type': 'nexthop', 'dest_prefix': '0.0.0.0/0', 'nexthop': '10.10.0.1', 'distance': '', 'interface': None, 'route_table_id': None, 'id': 7}, {'route_type': 'null', 'dest_prefix': '255.255.255.0/24', 'nexthop': None, 'distance': '1', 'interface': None, 'route_table_id': None, 'id': 8}]
    
    Expected output format:
    {'0.0.0.0/0': {'blackhole': {'distance': '100'}, 'dhcp-interface': ['eth2', 'br1'], 'interface': {'br1': {'distance': '120'}, 'eth2': {'distance': '50'}}, 'next-hop': {'8.8.8.8': {'distance': '200', 'interface': 'eth2'}, '10.10.0.1': {}}}, '255.255.255.0/24': {'blackhole': {'distance': '1'}}}
    """
    
    if 'route_ver' not in data or data.get('routes') is None:
        return {}
        
    routes = data.get('routes', [])
    route_config = {}
    
    # Group routes by destination prefix
    for route in routes:
        dest_prefix = route.get('dest_prefix')
        if not dest_prefix:
            continue
            
        if dest_prefix not in route_config:
            route_config[dest_prefix] = {}
            
        route_type = route.get('route_type')
        distance = route.get('distance', '')
        interface = route.get('interface')
        nexthop = route.get('nexthop')
        
        if route_type == 'null':
            route_config[dest_prefix]['blackhole'] = {}
            if distance:
                route_config[dest_prefix]['blackhole']['distance'] = distance
                
        elif route_type == 'reject':
            route_config[dest_prefix]['reject'] = {}
            if distance:
                route_config[dest_prefix]['reject']['distance'] = distance
                
        elif route_type == 'interface_dhcp':
            if interface:
                if 'dhcp-interface' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['dhcp-interface'] = []
                    
                # Check if it's already a list or needs to be converted
                dhcp_interfaces = route_config[dest_prefix]['dhcp-interface']
                if isinstance(dhcp_interfaces, list):
                    if interface not in dhcp_interfaces:
                        dhcp_interfaces.append(interface)
                else:
                    route_config[dest_prefix]['dhcp-interface'] = [dhcp_interfaces, interface]
                    
        elif route_type == 'interface':
            if interface:
                if 'interface' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['interface'] = {}
                    
                route_config[dest_prefix]['interface'][interface] = {}
                if distance:
                    route_config[dest_prefix]['interface'][interface]['distance'] = distance
                    
        elif route_type == 'nexthop' or route_type == 'nexthop_interface':
            if nexthop:
                if 'next-hop' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['next-hop'] = {}
                    
                route_config[dest_prefix]['next-hop'][nexthop] = {}
                
                if distance:
                    route_config[dest_prefix]['next-hop'][nexthop]['distance'] = distance
                    
                if route_type == 'nexthop_interface' and interface:
                    route_config[dest_prefix]['next-hop'][nexthop]['interface'] = interface
    
    logger.debug("Generated Route Config:")
    logger.debug(route_config)
    return route_config


def parse_to_route_config_v6(data: dict) -> dict:
    pass


def parse_to_route_config_system(data: dict) -> dict:
    """
    Convert a list of route dictionaries back into the nested route configuration format expected by VyOS.
    
    Sample routes data:
    [{'route_type': 'null', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '100', 'interface': None, 'route_table_id': None, 'id': 1}, {'route_type': 'interface_dhcp', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': None, 'interface': 'eth2', 'route_table_id': None, 'id': 2}, {'route_type': 'interface_dhcp', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': None, 'interface': 'br1', 'route_table_id': None, 'id': 3}, {'route_type': 'interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '120', 'interface': 'br1', 'route_table_id': None, 'id': 4}, {'route_type': 'interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': None, 'distance': '50', 'interface': 'eth2', 'route_table_id': None, 'id': 5}, {'route_type': 'nexthop_interface', 'dest_prefix': '0.0.0.0/0', 'nexthop': '8.8.8.8', 'distance': '200', 'interface': 'eth2', 'route_table_id': None, 'id': 6}, {'route_type': 'nexthop', 'dest_prefix': '0.0.0.0/0', 'nexthop': '10.10.0.1', 'distance': '', 'interface': None, 'route_table_id': None, 'id': 7}, {'route_type': 'null', 'dest_prefix': '255.255.255.0/24', 'nexthop': None, 'distance': '1', 'interface': None, 'route_table_id': None, 'id': 8}]
    
    Expected output format:
    {'0.0.0.0/0': {'blackhole': {'distance': '100'}, 'dhcp_interface': ['eth2', 'br1'], 'interface': {'br1': {'distance': '120'}, 'eth2': {'distance': '50'}}, 'next_hop': {'8.8.8.8': {'distance': '200', 'interface': 'eth2'}, '10.10.0.1': {}}}, '255.255.255.0/24': {'blackhole': {'distance': '1'}}}
    """
        
    routes = data.get('routes', [])
    route_config = {}
    
    # Group routes by destination prefix
    for route in routes:
        dest_prefix = route.get('dest_prefix')
        if not dest_prefix:
            continue
            
        if dest_prefix not in route_config:
            route_config[dest_prefix] = {}
            
        route_type = route.get('route_type')
        distance = route.get('distance', '')
        interface = route.get('interface')
        nexthop = route.get('nexthop')
        
        if route_type == 'null':
            route_config[dest_prefix]['blackhole'] = {}
            if distance:
                route_config[dest_prefix]['blackhole']['distance'] = distance
                
        elif route_type == 'reject':
            route_config[dest_prefix]['reject'] = {}
            if distance:
                route_config[dest_prefix]['reject']['distance'] = distance
                
        elif route_type == 'interface_dhcp':
            if interface:
                if 'dhcp_interface' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['dhcp_interface'] = []
                    
                # Check if it's already a list or needs to be converted
                dhcp_interfaces = route_config[dest_prefix]['dhcp_interface']
                if isinstance(dhcp_interfaces, list):
                    if interface not in dhcp_interfaces:
                        dhcp_interfaces.append(interface)
                else:
                    route_config[dest_prefix]['dhcp_interface'] = [dhcp_interfaces, interface]
                    
        elif route_type == 'interface':
            if interface:
                if 'interface' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['interface'] = {}
                    
                route_config[dest_prefix]['interface'][interface] = {}
                if distance:
                    route_config[dest_prefix]['interface'][interface]['distance'] = distance
                    
        elif route_type == 'nexthop' or route_type == 'nexthop_interface':
            if nexthop:
                if 'next_hop' not in route_config[dest_prefix]:
                    route_config[dest_prefix]['next_hop'] = {}
                    
                route_config[dest_prefix]['next_hop'][nexthop] = {}
                
                if distance:
                    route_config[dest_prefix]['next_hop'][nexthop]['distance'] = distance
                    
                if route_type == 'nexthop_interface' and interface:
                    route_config[dest_prefix]['next_hop'][nexthop]['interface'] = interface
    
    return route_config