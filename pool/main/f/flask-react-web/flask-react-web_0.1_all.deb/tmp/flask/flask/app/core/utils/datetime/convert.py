def convert_datetime(datetime_str: str) -> str:
    """
    Convert a datetime string '2025-03-05T08:57' to '5 MAR 2025 08:57:00'
    """
    if not datetime_str:
        return ""
    try:
        date_part, time_part = datetime_str.split('T')
        year, month, day = date_part.split('-')
        
        month_names = {
            '01': 'JAN', '02': 'FEB', '03': 'MAR', '04': 'APR',
            '05': 'MAY', '06': 'JUN', '07': 'JUL', '08': 'AUG',
            '09': 'SEP', '10': 'OCT', '11': 'NOV', '12': 'DEC'
        }
        month_abbr = month_names.get(month, 'JAN')
        
        if len(time_part.split(':')) == 2:
            time_part = f"{time_part}:00"
            
        return f"{int(day)} {month_abbr} {year} {time_part}"
    except ValueError:
        return datetime_str