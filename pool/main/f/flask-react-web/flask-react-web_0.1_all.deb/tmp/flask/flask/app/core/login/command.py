from app.core.api.http.cmd.command import Command

class LoginCommand(Command):
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource='system')
            self.attributes = {}
            self.cmds = []
            self.vyos_cmds = []
        except Exception as e:
            print(f"Error initializing Login command: {e}")
    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'
    
    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))
    
    def get_commands(self):
        return self.vyos_cmds
    
    def _walk_config(self, data: dict, prefix: list = None):
        if prefix is None:
            prefix = [self.resource]
        
        for key, value in data.items():
            current_path = prefix + [key]
            
            if isinstance(value, dict):
                if self.operator == 'delete':
                    # For delete operations, if we have an empty dict or it's a top-level auth node,
                    # delete the node itself instead of trying to walk into it
                    if not value or (len(prefix) == 2 and prefix[1] == 'login' and 
                                   key in ['saml', 'tacacs', 'radius', 'ldap']):
                        yield current_path
                    else:
                        yield from self._walk_config(value, current_path)
                else:
                    yield from self._walk_config(value, current_path)
                    
            elif isinstance(value, list):
                if not value and self.operator == 'delete':
                    # Delete empty list nodes
                    yield current_path
                else:
                    for item in value:
                        if isinstance(item, dict):
                            yield from self._walk_config(item, current_path)
                        else:
                            yield current_path + [str(item)]
            else:
                yield current_path + [str(value)]
    
    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data or not isinstance(data, dict):
            return []
        
        system_cfg = data.get('system', {})
        login_cfg = system_cfg.get('login', {})
        
        if not login_cfg:
            return []
        
        # Walk the config and generate commands
        for path in self._walk_config(login_cfg, prefix=[self.resource, "login"]):
            self.generate(*path)
        
        return self.cmds