import pytest
from unittest.mock import Mock, patch
from flask import url_for
import unittest


class TestReadDns(unittest.TestCase):
    
    """
    Test class for testing DNS reading functionality
    """

    def test_read_dns_forwarding(self):
        """
        Test reading DNS forwarding configuration
        - Make GET request to /vyos/network/dns endpoint
        - Verify response format and status code
        """
        mock_dns_config = {
            'service': {
                'dns': {
                    'forwarding': {
                        'allow_from': ['0.0.0.0/0'],
                        'cache_size': '10000',
                        'config_dir': '/run/pdns-recursor',
                        'config_file': '/run/pdns-recursor/recursor.conf',
                        'dnssec': 'process-no-validate',
                        'listen_address': ['8.8.8.8'],
                        'negative_ttl': '3600',
                        'port': '53',
                        'serve_stale_extension': '0',
                        'source_address': ['0.0.0.0', '::'],
                        'timeout': '1500'
                    }
                }
            }
        }

        mock_vyos_req = Mock()
        mock_vyos_req.send_request.return_value.json.return_value = {'data': mock_dns_config}

        with patch('app.core.network.dns.service.VyOSRequest', return_value=mock_vyos_req):
            response = client.get('/vyos/network/dns')
            assert response.status_code == 200
            data = response.json

            assert 'forwarding' in data
            forwarding = data['forwarding']
            
            assert 'allow_from' in forwarding
            assert 'cache_size' in forwarding
            assert 'config_dir' in forwarding
            assert 'config_file' in forwarding
            assert 'dnssec' in forwarding
            assert 'listen_address' in forwarding
            assert 'negative_ttl' in forwarding
            assert 'port' in forwarding
            assert 'serve_stale_extension' in forwarding
            assert 'source_address' in forwarding
            assert 'timeout' in forwarding

            assert forwarding['allow_from'] == ['0.0.0.0/0']
            assert forwarding['cache_size'] == '10000'
            assert forwarding['config_dir'] == '/run/pdns-recursor'
            assert forwarding['config_file'] == '/run/pdns-recursor/recursor.conf'
            assert forwarding['dnssec'] == 'process-no-validate'
            assert forwarding['listen_address'] == ['8.8.8.8']
            assert forwarding['negative_ttl'] == '3600'
            assert forwarding['port'] == '53'
            assert forwarding['serve_stale_extension'] == '0'
            assert forwarding['source_address'] == ['0.0.0.0', '::']
            assert forwarding['timeout'] == '1500'