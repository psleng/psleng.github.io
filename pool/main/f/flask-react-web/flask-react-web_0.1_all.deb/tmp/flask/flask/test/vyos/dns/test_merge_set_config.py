import unittest
from app.core.utils.process_config import merge_dicts_set

class TestMergeSetConfig(unittest.TestCase):
    def test_merge_dicts_set_1(self):
        """Test merge_dicts_set function with various scenarios"""
        # Test case 1: Basic merge
        dict1 = {'service': {'jobs': {'forwarding': {'allow_from': ['0.0.0.0/0']}}}}
        dict2 = {'service': {'jobs': {'forwarding': {'cache_size': '10000'}}}}
        expected = {
            'service': {
                'jobs': {
                    'forwarding': {
                        'allow_from': ['0.0.0.0/0'],
                        'cache_size': '10000'
                    }
                }
            }
        }
        result = merge_dicts_set(dict1, dict2)
        self.assertEqual(result, expected)

    def test_merge_dicts_set_2(self):
        # Test case 2: Merge with multi-value fields
        dict1 = {'service': {'jobs': {'forwarding': {'listen_address': ['127.0.0.1']}}}}
        dict2 = {'service': {'jobs': {'forwarding': {'listen_address': ['192.168.1.1']}}}}
        expected = {
            'service': {
                'jobs': {
                    'forwarding': {
                        'listen_address': ['127.0.0.1', '192.168.1.1']
                    }
                }
            }
        }
        result = merge_dicts_set(dict1, dict2)
        self.assertEqual(result, expected)

    def test_merge_dicts_set_3(self):
        # Test case 3: Merge with key normalization
        dict1 = {'service': {'jobs': {'forwarding': {'allow-from': ['0.0.0.0/0']}}}}
        dict2 = {'service': {'jobs': {'forwarding': {'allow_from': ['::1/128']}}}}
        expected = {
            'service': {
                'jobs': {
                    'forwarding': {
                        'allow-from': ['0.0.0.0/0', '::1/128']
                    }
                }
            }
        }
        result = merge_dicts_set(dict1, dict2)
        self.assertEqual(result, expected)

    def test_merge_dicts_set_4(self):
        # Test case 4: Merge with key is node.tag
        dict1 =  {'service': {'jobs': {'forwarding': {'allow_from': ['0.0.0.0/0', '::1/128'], 'cache_size': 10000, 'listen_address': ['192.168.1.1', '192.168.1.2'], 'domain': {'example.com': {'name_server': '8.8.8.8'}}}}}}
        dict2 =  {'service': {'jobs': {'forwarding': {'allow_from': ['0.0.0.0/0', '::1/128'], 'cache_size': 10000, 'listen_address': ['192.168.1.1', '192.168.1.2'], 'domain': {'example.com': {'name_server': '8.8.4.4'}}}}}}
        expected = {'service': {'jobs': {'forwarding': {'allow_from': ['0.0.0.0/0', '::1/128'], 'cache_size': 10000, 'listen_address': ['192.168.1.1', '192.168.1.2'], 'domain': {'example.com': {'name_server': ['8.8.8.8', '8.8.4.4']}}}}}}

        result = merge_dicts_set(dict1, dict2)
        self.assertEqual(result, expected)

    def test_edge_cases(self):
        """Test edge cases for merge_dicts_set"""
        # Empty dictionaries
        self.assertEqual(merge_dicts_set({}, {}), {})
        
        # One empty dictionary
        dict1 = {'service': {'jobs': {'forwarding': {'allow_from': ['0.0.0.0/0']}}}}
        self.assertEqual(merge_dicts_set(dict1, {}), dict1)
        self.assertEqual(merge_dicts_set({}, dict1), dict1)

if __name__ == '__main__':
    unittest.main()
