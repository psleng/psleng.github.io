import time
import functools
from typing import Callable, Any
from app.config import global_config
from app.log.logger import logger

def measure_time(log_level: str = 'INFO') -> Callable:
    """
    A decorator that measures and logs the execution time of a function.
    Args:
        log_level (str): The logging level to use. Default is 'INFO'.
            Valid values are: 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            log_method = getattr(logger, log_level.lower(), logger.info)
            start_time = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                end_time = time.perf_counter()
                execution_time = end_time - start_time
                logger.debug(f"Function '{func.__name__}' executed in {execution_time:.10f} seconds")
                return result
            except Exception as e:
                end_time = time.perf_counter()
                execution_time = end_time - start_time                
                logger.error(f"Function '{func.__name__}' failed after {execution_time:.10f} seconds. ")
                logger.error(f"Error: {str(e)}")
                raise
                
        return wrapper
    return decorator


def pause_scheduler(do_pause: bool, pause_actions: list[str] = ['UPDATE']) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            paused = False
            if do_pause:
                logger.debug("Kwargs: ")
                logger.debug(kwargs)
                # Pause scheduler before the call
                try:
                    action = kwargs.get('action')
                    if action in pause_actions and global_config.app_scheduler and global_config.app_scheduler.running is True:
                        logger.debug("--- Pause scheduler ---")
                        pause_result = global_config.app_scheduler.pause()
                        logger.debug(f"Pause result: {pause_result}")
                        paused = True
                except Exception as e:
                    logger.error(f"Error pausing scheduler: {str(e)}")
            
            result = func(*args, **kwargs)
            
            if do_pause and paused:
                # Resume scheduler after the call
                try:
                    action = kwargs.get('action')
                    logger.debug("Current apcheduler running before resume:")
                    logger.debug(global_config.app_scheduler.running)
                    if action in pause_actions and global_config.app_scheduler:
                        logger.debug("--- Resume scheduler ---")
                        global_config.app_scheduler.resume()
                        paused = False
                except Exception as e:
                    logger.error(f"Error resuming scheduler: {str(e)}")
    
            return result
        return wrapper
    return decorator

# Example usage:
# @measure_time()
# def some_function():
#     time.sleep(1)  # Simulate some work
#     return "Done"

# @measure_time(log_level='DEBUG')
# def another_function():
#     time.sleep(0.5)  # Simulate some work
#     raise ValueError("Something went wrong")