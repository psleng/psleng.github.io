import sys

def is_linux():
    return sys.platform.startswith('linux')
