"""
Global pytest configuration file contains:
fixtures and configuration that will be available to all tests.
"""

import os
import sys
import pytest
from dotenv import load_dotenv

load_dotenv()

def test_app():
    """Create a test application for testing without importing Flask directly."""
    import importlib.util
    spec = importlib.util.find_spec('flask')
    flask_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(flask_module)
    
    app = flask_module.Flask(__name__)
    
    # Environment variables and global configs
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('SQLALCHEMY_DATABASE_URI')
    app.config['SECRET_KEY'] = os.environ.get('SQLALCHEMY_SECRET_KEY')
    app.config['SECURITY_PASSWORD_SALT'] = os.environ.get('SQLALCHEMY_SECURITY_PASSWORD_SALT')
    app.config['VYOS_HOSTNAME'] = os.environ.get('VYOS_HOSTNAME')
    app.config['VYOS_APIKEY'] = os.environ.get('VYOS_APIKEY')
    app.config['VYOS_PORT'] = os.environ.get('VYOS_PORT')
    app.config['VYOS_PROTOCOL'] = os.environ.get('VYOS_PROTOCOL')
    app.config['VYOS_VERIFY_SSL'] = os.environ.get('VYOS_VERIFY_SSL')
    app.config['VYOS_BACKEND'] = os.environ.get('VYOS_BACKEND')
    
    return app

@pytest.fixture(scope='session')
def test_service_provider():
    """Create a mock Service Provider for testing."""
    from app.core.api.api import ServiceProvider
    from app.core.api.http.http_request import HTTPRequest
    from app.core.api.http.graphql_requests import GraphqlRequest
    from app.core.utils.validate.validator import Validator
    
    service_provider = ServiceProvider(
        http_service=HTTPRequest(),
        graphql_service=GraphqlRequest(),
        verify_service=Validator()
    )
    
    return service_provider
