from app.core.api.api import API

class ANSIBLE_API(API):
    def __init__(self, app):
        self.config = app.config
        self.context = app.app_context()
    
    def call(self):
        return super().call()
    
    def get_api_type(self):
        return "ANSIBLE"