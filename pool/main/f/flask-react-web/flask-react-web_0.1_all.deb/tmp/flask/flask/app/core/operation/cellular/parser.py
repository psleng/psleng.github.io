

def parse_cellular_op_info(data: dict):
    cellular_info = {
        "carrier": "",
        "signal": 0,
        "apn": "",
        "imei": "",
        "phone_number": "",
    }

    def parse_signal(signal: str):
        try:
            if 'cached' in signal:
                return 0    
            signal = signal.split('%')[0]
            return int(signal)
        except:
            return 0

    if 'ShowDetailWwanQuery' not in data:
        return cellular_info
    if 'data' not in data['ShowDetailWwanQuery']:
        return cellular_info
    if 'result' not in data['ShowDetailWwanQuery']['data']:
        return cellular_info

    result = data['ShowDetailWwanQuery']['data']['result']
    if 'numbers' in result and result['numbers'] and 'own' in result['numbers']:
        cellular_info['phone_number'] = result['numbers']['own']

    if 'status' in result and result['status'] and 'signal_quality' in result['status']:
        cellular_info['signal'] = parse_signal(result['status']['signal_quality'])

    if 'threegpp' in result and result['threegpp']:
        if 'operator_name' in result['threegpp']:
            cellular_info['carrier'] = result['threegpp']['operator_name']
        if 'imei' in result['threegpp']:
            cellular_info['imei'] = result['threegpp']['imei']

    return cellular_info
