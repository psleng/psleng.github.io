from app.core import salt

local = salt.client.LocalClient()
interf = local.cmd('hostNameVyOS-Proxy', 'netmiko.send_command', ['show interface'])

print(interf)