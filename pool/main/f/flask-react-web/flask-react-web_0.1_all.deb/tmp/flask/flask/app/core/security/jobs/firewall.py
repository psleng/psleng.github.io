from app.core.network.dns.models import DNSForwarding
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.security.models import Firewallv4, Firewallv6, FirewallSettings, FirewallOperation, FirewallOperationLog
from logging import getLogger, INFO
from flask import current_app

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_firewall_job(app_context):
    try:
        refresh_db_firewall(app_context=app_context)
    except Exception as e:
        print('Error fetch firewall', str(e))


def refresh_db_firewall(app_context=None):
    try:
        firewall = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL)
        print("Firewall data:", firewall)
       
        if app_context is not None:
            with app_context:
                Firewallv4.refresh(firewall, None)
                Firewallv6.refresh(firewall, None)
        else:
            with current_app.app_context():
                Firewallv4.refresh(firewall, None)
                Firewallv6.refresh(firewall, None)
        return True
    except Exception as e:
        print(f"Error refreshing db firewall data: {e}")
        return False

def fetch_firewall_opr_job(app_context):
    try:
        refresh_db_firewall_opr(app_context=app_context)
    except Exception as e:
        print('Error fetch firewall opr', str(e))


def refresh_db_firewall_opr(app_context=None):
    try:
        firewall_opr = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_OPR)
        if app_context is not None:
            FirewallOperation.refresh(firewall_opr, app_context=app_context)
        else:
            FirewallOperation.refresh(firewall_opr)
        return True
    except Exception as e:
        print(f"Error refreshing db firewall operation data: {e}")
        return False

def fetch_firewall_opr_log_job(app_context):
    try:
        refresh_db_firewall_opr_log(app_context=app_context)
    except Exception as e:
        print('Error fetch firewall opr log', str(e))


def refresh_db_firewall_opr_log(app_context=None):
    try:
        # firewall_opr_log = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_OPR_LOG)
        # print("Firewall Operation Log data:", firewall_opr_log)
        # FirewallOperationLog.refresh(firewall_opr_log)
        return True
    except Exception as e:
        print(f"Error refreshing db firewall operation log data: {e}")
        return False