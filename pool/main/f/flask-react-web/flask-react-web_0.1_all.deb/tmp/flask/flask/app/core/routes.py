from flask import jsonify
from . import vyos_bp
from .operation import vyos_operation_bp
from .config import vyos_config_bp
from .salt import salt_bp
from .routing import routing_bp
from .network import vyos_network_bp
from .security import vyos_security_bp
from .login import vyos_login_bp
from app.core.api.manager import api_manager

vyos_bp.register_blueprint(vyos_operation_bp, url_prefix="/opr")
vyos_bp.register_blueprint(vyos_config_bp, url_prefix="/configs")
vyos_bp.register_blueprint(salt_bp, url_prefix="/salt")
vyos_bp.register_blueprint(routing_bp, url_prefix="/routing")
vyos_bp.register_blueprint(vyos_network_bp, url_prefix="/network")
vyos_bp.register_blueprint(vyos_security_bp, url_prefix="/security")
vyos_bp.register_blueprint(vyos_login_bp, url_prefix="/login")

@vyos_bp.route("/api-manager", methods=['GET'])
def get_api_type():
    return jsonify(api_manager.get_api_type()), 200