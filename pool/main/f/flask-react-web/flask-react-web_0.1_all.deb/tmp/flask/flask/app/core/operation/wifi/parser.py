from copy import deepcopy
import pprint
from app.core.utils.debug.debug_log import debug_log

# @debug_log
def parse_to_wifi_config(data: dict):
    """
    'network': {'ipConfig': 'dhcp',
                'ipv4': {'address': '',
                        'dhcpOptions': {'clientId': '',
                                        'defaultRouteDistance': 1,
                                        'hostName': '',
                                        'noDefaultRoute': False,
                                        'userClass': '',
                                        'vendorClassId': ''},
                        'gateway': '',
                        'netmask': ''},
                'ipv6': {'address': '',
                        'dhcpv6Options': {'duid': '',
                                        'noRelease': False,
                                        'parametersOnly': False,
                                        'rapidCommit': False,
                                        'temporaryAddress': False},
                        'prefix': 64}},
                'password': '',
                'security': 'WPA2',
                'ssid': ''},
        'description': '',
        'enabled': True,
        'network': {'bridgeInterface': '',
                        'bridgeMode': False,
                        'ipMode': 'static',
                        'ipv4': {'dhcp': {'enabled': False,
                                        'options': {'clientId': '',
                                                'defaultRouteDistance': 1,
                                                'dontInstallDefaultRoute': False,
                                                'hostname': '',
                                                'mtu': 1500,
                                                'reject': False,
                                                'userClass': '',
                                                'vendorClass': ''}},
                                'static': {'address': '',
                                        'gateway': '',
                                        'netmask': '',
                                        'prefixLength': 24}},
                        'ipv6': {'dhcpv6': {'enabled': False,
                                        'options': {'dontSendRelease': False,
                                                        'duid': '',
                                                        'parametersOnly': False,
                                                        'pd': False,
                                                        'rapidCommit': False,
                                                        'temporaryAddress': False}},
                                'mode': 'static',
                                'static': {'address': '', 'prefix': 64}}},
        'password': '',
        'security': {'encryption': 'AES', 'type': 'WPA2'},
        'advanced': {'countryCode': 'US'},
        'ssid': ''}



        Sample output:
        'wlan0', 'wlan1' (ap)
        'wlan2', 'wlan3' (client)

        {
            "ap": { 
                    'disable': {},
                    'description': 'Here is the description',
                    'disable-broadcast-ssid': {},
                    'isolate-stations': {},
                    'mgmt-frame-protection': 'optional',
                    'mode': 'ac',
                    'security': { 'wpa': { 'cipher': [ 'GCMP',
                                                    'CCMP',
                                                    'GCMP-256',
                                                    'CCMP-256',
                                                    'TKIP'],
                                            'mode': 'wpa2',
                                            'passphrase': '123perle456'}},
                    'ssid': 'duc123',
                    'type': 'access-point'
                    },
            "client": { 'security': { 'wpa': { 'cipher': [ 'GCMP-256',
                                                            'GCMP',
                                                            'CCMP',
                                                            'CCMP-256',
                                                            'TKIP'],
                                            'passphrase': 'password1'}}
        }


    
    """
    # print("parse_to_wifi_config input data")
    # print(pprint.pformat(data))
    
    # Transform the new-style WiFi config into VyOS-style AP/client config dicts


    result = {}

    # --- ACCESS POINT (AP) ---
    ap = {}
    # Mode
    if data.get('mode'):
        ap['mode'] = data['mode']
    # Description
    if data.get('description'):
        ap['description'] = data['description']
    # SSID
    if data.get('ssid'):
        ap['ssid'] = data['ssid']
    # Security
    sec = data.get('security', {})
    if sec.get('type', '').lower().startswith('wpa'):
        wpa_mode = sec.get('type', '').lower()
        _cipher = []
        if isinstance(sec.get('encryption'), str):
            _cipher = sec.get('encryption')
        elif isinstance(sec.get('encryption'), list):
            encryption_list = sec.get('encryption')
            if len(encryption_list) == 1:
                _cipher = encryption_list[0]
            elif len(encryption_list) > 1:
                _cipher = sec.get('encryption', [])
        ap['security'] = {
            'wpa': {
                'mode': wpa_mode,
                'cipher': _cipher,
                'passphrase': data.get('password', '')
            }
        }
    # Access Control
    access_control = data.get('accessControl', {})
    mode = access_control.get('mode', None)
    accept_list = access_control.get('acceptList', [])
    deny_list = access_control.get('denyList', []) 
    if mode == 'deny' or mode == 'accept':
        station_address = {}
        station_address['mode'] = mode

        if len(accept_list) > 0:
            ap['security'] = ap.get('security', {})
            station_address['accept'] = {
                "mac": accept_list if len(accept_list) > 1 else accept_list[0]
            }
        
        if len(deny_list) > 0:
            ap['security'] = ap.get('security', {})
            station_address['deny'] = {
                "mac": deny_list if len(deny_list) > 1 else deny_list[0]
            }
            
        
        ap['security'] = ap.get('security', {})
        ap['security']['station-address'] = deepcopy(station_address)
    
    # Advanced
    adv = data.get('advanced', {})
    if 'hiddenSSID' in adv and adv['hiddenSSID'] is True:
        ap['disable-broadcast-ssid'] = {}
    if adv.get('preventBridging'):
        ap['isolate-stations'] = {}
    if adv.get('managementFrameProtection') and adv['managementFrameProtection'] != 'disabled':
        ap['mgmt-frame-protection'] = adv['managementFrameProtection']
    if 'mode' in adv:
        ap['mode'] = adv['mode']

    if 'capabilities' not in ap:
        ap['capabilities'] = {}
        
    if adv.get('acMode') and adv['acMode'].get('channelWidth'):
        if 'vht' not in ap['capabilities']:
            ap['capabilities']['vht'] = {}
        ap['capabilities']['vht']['channel-set-width'] = adv['acMode']['channelWidth']

    if adv.get('axMode') and adv['axMode'].get('channelWidth'):
        if 'he' not in ap['capabilities']:
            ap['capabilities']['he'] = {}
        ap['capabilities']['he']['channel-set-width'] = adv['axMode']['channelWidth']

    if adv.get('nMode') and adv['nMode'].get('channelWidth'):
        if 'ht' not in ap['capabilities']:
            ap['capabilities']['ht'] = {}
        ap['capabilities']['ht']['channel-set-width'] = adv['nMode']['channelWidth']

    # Max stations is preset
    # if adv.get('maxClients'):
    #     ap['max-stations'] = adv['maxClients']
    
    if adv.get('beaconProtection'):
        ap['beacon-protection'] = {}
    if adv.get('disassociateOnFailures'):
        ap['disassociate-on-failures'] = {}
    if adv.get('dedicatedThreadPerClient'):
        ap['dedicated-thread-per-client'] = {}

    # Country code
    if data.get('countryCode') and data.get('countryCode') != '':
        ap['country-code'] = data.get('countryCode')
    
    # Type is preset
    # ap['type'] = 'access-point'

    # --- NETWORK ---
    net = data.get('network', {})
    if net.get('bridgeMode'):
        ap['bridge'] = {'interface': net.get('bridgeInterface', '')}
    # IPv4
    ipv4 = net.get('ipv4', {})
    if net.get('ipMode') == 'dhcp':
        ap['address'] = ['dhcp']
    elif net.get('ipMode') == 'static' and 'static' in ipv4:
        static = ipv4['static']
        if static.get('address'):
            prefix = static.get('prefixLength', 24)
            ap['address'] = [f"{static['address']}/{prefix}"]
            if static.get('gateway'):
                ap['gateway'] = static['gateway']
    # IPv6
    ipv6 = net.get('ipv6', {})
    if ipv6.get('mode') == 'dhcpv6':
        ap.setdefault('address', []).append('dhcpv6')
    elif ipv6.get('mode') == 'static' and 'static' in ipv6:
        static6 = ipv6['static']
        if static6.get('address'):
            prefix = static6.get('prefix', 64)
            ap.setdefault('address', []).append(f"{static6['address']}/{prefix}")

    result['wlan0'] = ap.copy()
    result['wlan1'] = ap.copy()

    # Disable/enable
    if not data.get('enabled5', False):
        result['wlan0']['disable'] = {}
    
    if not data.get('enabled24', False):
        result['wlan1']['disable'] = {}

    # --- CLIENT ---
    client_in = data.get('client', {})
    client = {}

    if client_in.get('ssid'):
        client['ssid'] = client_in['ssid']
    if client_in.get('password'):
        client['security'] = {
            'wpa': {
                'mode': 'wpa2',
                'passphrase': client_in['password']
            }
        }
    if client_in.get('security'):
        client['security'] = {
            'wpa': {
                'mode': client_in['security'],
                'passphrase': client_in.get('password', '')
            }
        }
    # Network config for client
    cnet = client_in.get('network', {})
    if cnet.get('ipConfig') == 'dhcp':
        client['address'] = ['dhcp']
    elif cnet.get('ipConfig') == 'static':
        ipv4 = cnet.get('ipv4', {})
        if ipv4.get('address'):
            prefix = 24
            client['address'] = [f"{ipv4['address']}/{prefix}"]
            if ipv4.get('gateway'):
                client['gateway'] = ipv4['gateway']
    # IPv6 for client
    ipv6 = cnet.get('ipv6', {})
    if ipv6.get('address'):
        prefix = ipv6.get('prefix', 64)
        client.setdefault('address', []).append(f"{ipv6['address']}/{prefix}")
    
    result['wlan2'] = client.copy()
    result['wlan3'] = client.copy()

    if not client_in.get('enabled5', False):
        result['wlan2']['disable'] = {}
    if not client_in.get('enabled24', False):
        result['wlan3']['disable'] = {}
    
    if cnet.get('ipv4', None) and cnet['ipv4'].get('dhcpOptions', None) and cnet['ipv4']['dhcpOptions'].get('defaultRoute', None):
        defaultRoutes = cnet['ipv4']['dhcpOptions']['defaultRoute']
        if 'GHz5' in defaultRoutes:
            result['wlan2']['dhcp-options'] = {
                'default-route-distance': defaultRoutes['GHz5']
            }
        if 'GHz24' in defaultRoutes:
            result['wlan3']['dhcp-options'] = {
                'default-route-distance': defaultRoutes['GHz24']
            }
    
    return result

# @debug_log
def parse_wifi_config(data: dict, bridge_name: str) -> dict:
    """
    Parse VyOS WiFi configuration into a format suitable for WiFiInterfaceConfig.refresh
    
    Args:
        data: VyOS configuration data containing wireless interfaces
        
    Returns:
        Dictionary with WiFi interface configuration data formatted for WiFiInterfaceConfig model
    """
    result = {
        # Access Point defaults
        'ap_enable': False,
        'ap_enable5': False,
        'ap_enable24': False,
        'ap_description': '',
        'ap_ssid': '',
        'ap_password': '',
        'ap_mode': 'ac',
        'ap_security': '',
        'ap_encryption': [],
        'ap_hidden_ssid': False,
        'ap_prevent_low': False,
        'ap_management_frame': '',
        'ap_bridge_mode': True,
        'ap_ipv4_mode': 'static',
        'ap_ipv4_address': '',
        'ap_ipv4_length': '',
        'ap_ipv6_mode': 'static',
        'ap_ipv6_address': '',
        'ap_ipv6_length': '',
        'ap_acl_mode': '',
        'ap_acl_accept': '',
        'ap_acp_deny': '',
        
        # Client defaults
        'client_enable': False,
        'client_enable5': False,
        'client_enable24': False,
        'client_ssid': '',
        'client_password': '',
        'client_security': '',
        'client_bridge_mode': True,
        'client_ipv4_mode': 'static',
        'client_ipv4_address': '',
        'client_ipv4_length': '',
        'client_ipv6_mode': 'static',
        'client_ipv6_address': '',
        'client_ipv6_length': '',
        'client_default_route_distance_5': '',
        'client_default_route_distance_24': ''
    }
    
    if not data or 'wireless' not in data:
        return result

    ap_ifnames = ['wlan0', 'wlan1']
    client_ifnames = ['wlan2', 'wlan3']
    
    bridges = data['bridge']
    # TODO: Handle multiple IPs of bridge if happened?

    if bridge_name in bridges:
        ap_ip = bridges[bridge_name]['address']
        if isinstance(ap_ip, str):
            ap_address, ap_length = ap_ip.split('/')    
        elif isinstance(ap_ip, list):
            ap_address, ap_length = ap_ip[0].split('/')
        else:
            ap_address = ''
            ap_length = ''
        result['ap_ipv4_address'] = ap_address
        result['ap_ipv4_length'] = ap_length

    wireless = data['wireless']
    
    is_ap_5_disable = False
    is_ap_24_disable = False
    is_client_5_disable = False
    is_client_24_disable = False
    
    for ifname, ifconfig in wireless.items():
        if not isinstance(ifconfig, dict):
            continue
        
        if ifname == 'wlan0':
            is_ap_5_disable = 'disable' in ifconfig
        elif ifname == 'wlan1':
            is_ap_24_disable = 'disable' in ifconfig
        elif ifname == 'wlan2':
            is_client_5_disable = 'disable' in ifconfig
        elif ifname == 'wlan3':
            is_client_24_disable = 'disable' in ifconfig
        
        is_disabled = 'disable' in ifconfig
        
        if 'description' in ifconfig:
            result['ap_description'] = ifconfig['description']
        
        if_type = ifconfig.get('type', '').lower()
        
        if 'mode' in ifconfig and ifname == 'wlan0':
            result['ap_mode'] = ifconfig['mode']

        if 'capabilities' in ifconfig:
            capabilities = ifconfig['capabilities']
            if 'vht' in capabilities:
                vht = capabilities['vht']
                result['ap_ac_channel_width'] = vht.get('channel-set-width', '')
            if 'he' in capabilities:
                he = capabilities['he']
                result['ap_ax_channel_width'] = he.get('channel-set-width', '')
            if 'ht' in capabilities:
                ht = capabilities['ht']
                result['ap_n_channel_width'] = ht.get('channel-set-width', [])
        
        if if_type == 'access-point' or ifname in ap_ifnames:
            result['ap_enable'] = not is_disabled
            result['ap_ssid'] = ifconfig.get('ssid', '')
            
            if 'security' in ifconfig: 
                if 'wpa' in ifconfig['security']:
                    wpa_config = ifconfig['security']['wpa']
                    result['ap_security'] = wpa_config.get('mode', '')
                    
                    result['ap_password'] = wpa_config.get('passphrase', '')
                    
                    ciphers = wpa_config.get('cipher')
                    if isinstance(ciphers, list) and ciphers:
                        result['ap_encryption'] = ciphers
                    elif isinstance(ciphers, str):
                        result['ap_encryption'] = [ciphers]
                if 'station-address' in ifconfig['security']:
                    station_address = ifconfig['security']['station-address']
                    result['ap_acl_mode'] = station_address.get('mode', '')
                    acl_accept = station_address.get('accept', None)
                    if acl_accept and acl_accept.get('mac', None):
                        accept_macs = acl_accept['mac']
                        if isinstance(accept_macs, list):
                            result['ap_acl_accept'] = accept_macs
                        elif isinstance(accept_macs, str):
                            result['ap_acl_accept'] = [accept_macs]
                            
                    acl_deny = station_address.get('deny', None)
                    if acl_deny and acl_deny.get('mac', None):
                        deny_macs = acl_deny['mac']
                        if isinstance(deny_macs, list):
                            result['ap_acl_deny'] = deny_macs
                        elif isinstance(deny_macs, str):
                            result['ap_acl_deny'] = [deny_macs]
            
            result['ap_hidden_ssid'] = 'hidden' in ifconfig
            
            if 'mgmt-frame-protection' in ifconfig:
                result['ap_management_frame'] = ifconfig.get('mgmt-frame-protection', '')

            if 'isolate-stations' in ifconfig:
                result['ap_prevent_low'] = True
            
            if 'address' in ifconfig:
                addresses = ifconfig['address']
                if isinstance(addresses, list):
                    for addr in addresses:
                        if ':' in addr:  # IPv6
                            ip, prefix = addr.split('/')
                            result['ap_ipv6_address'] = ip
                            result['ap_ipv6_length'] = prefix
                elif isinstance(addresses, str):
                    addr = addresses
                    if ':' in addr:  # IPv6
                        if '/' in addr:
                            ip, prefix = addr.split('/')
                            result['ap_ipv6_address'] = ip
                            result['ap_ipv6_length'] = prefix
                        else:
                            result['ap_ipv6_address'] = addr
        
        # Process Client interfaces
        elif if_type == 'station' or ifname in client_ifnames:  # Client mode
            result['client_enable'] = not is_disabled
            result['client_ssid'] = ifconfig.get('ssid', '')
            
            if 'security' in ifconfig and 'wpa' in ifconfig['security']:
                wpa_config = ifconfig['security']['wpa']
                result['client_security'] = wpa_config.get('mode', '')
                result['client_password'] = wpa_config.get('passphrase', '')
            
            if 'address' in ifconfig:
                addresses = ifconfig['address']
                if isinstance(addresses, list):
                    for addr in addresses:
                        if '.' in addr:  # IPv4
                            ip, prefix = addr.split('/')
                            result['client_ipv4_address'] = ip
                            result['client_ipv4_length'] = prefix
                        elif ':' in addr:  # IPv6
                            ip, prefix = addr.split('/')
                            result['client_ipv6_address'] = ip
                            result['client_ipv6_length'] = prefix
                elif isinstance(addresses, str):
                    addr = addresses
                    if '.' in addr:  # IPv4
                        if '/' in addr:
                            ip, prefix = addr.split('/')
                            result['client_ipv4_address'] = ip
                            result['client_ipv4_length'] = prefix
                        else:
                            result['client_ipv4_address'] = addr
                    elif ':' in addr:  # IPv6
                        if '/' in addr:
                            ip, prefix = addr.split('/')
                            result['client_ipv6_address'] = ip
                            result['client_ipv6_length'] = prefix
                        else:
                            result['client_ipv6_address'] = addr
            
            if 'dhcp-options' in ifconfig:
                if 'default-route-distance' in ifconfig['dhcp-options']:
                    if ifname == 'wlan2':
                        result['client_default_route_distance_5'] = ifconfig['dhcp-options']['default-route-distance']
                    if ifname == 'wlan3':
                        result['client_default_route_distance_24'] = ifconfig['dhcp-options']['default-route-distance']
    
    result['ap_enable5'] = not is_ap_5_disable
    result['ap_enable24'] = not is_ap_24_disable
    result['client_enable5'] = not is_client_5_disable
    result['client_enable24'] = not is_client_24_disable
    
    return result


def parse_wifi(data: dict, bridge: dict) -> dict:
    """
        Parse full running config of wireless to serialized format that is ready to save to db
        Sample Output:
        data: { 
            'ap_acl_accept': ['01:03:02:04:05:06'],
            'ap_acl_deny': ['01:02:03:04:05:06', '03:01:03:04:05:06'],
            'ap_acl_mode': 'accept',
            'ap_acp_deny': '',
            'ap_bridge_mode': True,
            'ap_description': '',
            'ap_enable': True,
            'ap_enable24': True,
            'ap_enable5': True,
            'ap_encryption': ['GCMP', 'CCMP-256', 'GCMP-256', 'TKIP', 'CCMP'],
            'ap_hidden_ssid': False,
            'ap_ipv4_address': '',
            'ap_ipv4_length': '',
            'ap_ipv4_mode': 'static',
            'ap_ipv6_address': '',
            'ap_ipv6_length': '',
            'ap_ipv6_mode': 'static',
            'ap_management_frame': '',
            'ap_mode': 'ac',
            'ap_password': '123perle456',
            'ap_prevent_low': False,
            'ap_security': 'wpa+wpa2',
            'ap_ssid': 'duc456',
            'client_bridge_mode': True,
            'client_default_route_distance_24': '',
            'client_default_route_distance_5': '',
            'client_enable': True,
            'client_enable24': True,
            'client_enable5': False,
            'client_ipv4_address': '',
            'client_ipv4_length': '',
            'client_ipv4_mode': 'static',
            'client_ipv6_address': '',
            'client_ipv6_length': '',
            'client_ipv6_mode': 'static',
            'client_password': '1Black2And3Yellow4Hello5',
            'client_security': 'wpa+wpa2',
            'client_ssid': 'PSL-WIRELESS'
        }
        bridge: { 
            'br1': { 
                'address': '192.168.1.1/24',
                'member': {'interface': {'wlan0': {}, 'wlan1': {}}}
            }
        }
    """
    if not data or 'wireless' not in data:
        return {}
    
    wireless_data = data.get('wireless', {})
    result = {}
    
    result = {
        # AP settings
        'ap_acl_accept': [],
        'ap_acl_deny': [],
        'ap_acl_mode': 'deny',  # Default to deny mode
        'ap_bridge_mode': True,
        'ap_description': '',
        'ap_enable': True,
        'ap_enable24': False,
        'ap_enable5': False,
        'ap_encryption': [],
        'ap_hidden_ssid': False,
        'ap_ipv4_address': '',
        'ap_ipv4_length': '',
        'ap_ipv4_mode': 'static',
        'ap_ipv6_address': '',
        'ap_ipv6_length': '',
        'ap_ipv6_mode': 'static',
        'ap_management_frame': '',
        'ap_mode': 'ac',
        'ap_password': '',
        'ap_prevent_low': False,
        'ap_security': '',
        'ap_ssid': '',
        'ap_ac_channel_width': '',
        'ap_ax_channel_width': '',
        'ap_n_channel_width': '',
        
        
        # Client settings
        'client_bridge_mode': True,
        'client_default_route_distance_24': '',
        'client_default_route_distance_5': '',
        'client_enable': True,
        'client_enable24': False,
        'client_enable5': False,
        'client_ipv4_address': '',
        'client_ipv4_length': '',
        'client_ipv4_mode': 'static',
        'client_ipv6_address': '',
        'client_ipv6_length': '',
        'client_ipv6_mode': 'static',
        'client_password': '',
        'client_security': '',
        'client_ssid': ''
    }
    
    ap_24_data = wireless_data.get('wlan0', {})
    ap_5_data = wireless_data.get('wlan1', {})
    
    client_24_data = wireless_data.get('wlan2', {})
    client_5_data = wireless_data.get('wlan3', {})
    
    result['ap_enable24'] = 'disable' not in ap_24_data
    result['ap_enable5'] = 'disable' not in ap_5_data
    result['client_enable24'] = 'disable' not in client_24_data
    result['client_enable5'] = 'disable' not in client_5_data

    # Get bridge address and handle both string and list formats
    bridge_addr = bridge.get("br1", {}).get('address', "/")
    
    if isinstance(bridge_addr, list):
        if bridge_addr and len(bridge_addr) > 0:
            bridge_addr_str = bridge_addr[0] if isinstance(bridge_addr[0], str) else str(bridge_addr[0])
        else:
            bridge_addr_str = "/"  # Default if list is empty
    else:
        bridge_addr_str = str(bridge_addr)
    
    bridge_address_parts = bridge_addr_str.split('/')
    
    ip_addr = ""
    prefix_len = ""
    
    if len(bridge_address_parts) >= 2:
        ip_addr = bridge_address_parts[0]
        prefix_len = bridge_address_parts[1]
    elif len(bridge_address_parts) == 1:
        ip_addr = bridge_address_parts[0]
    
    result['ap_ipv4_address'] = ip_addr
    result['ap_ipv4_length'] = prefix_len
    
    result['ap_enable'] = result['ap_enable24'] or result['ap_enable5']
    result['client_enable'] = result['client_enable24'] or result['client_enable5']
    
    ap_data = ap_5_data if result['ap_enable5'] else ap_24_data if result['ap_enable24'] else {}
    
    if ap_data:
        result['ap_ssid'] = ap_data.get('ssid', '')
        if result['ap_enable5']:
            result['ap_mode'] = ap_5_data.get('mode', '')
        result['ap_management_frame'] = ap_data.get('mgmt_frame_protection', 'disabled')
        result['ap_prevent_low'] = ap_data.get('isolate_stations', False)
        
        security = ap_data.get('security', {})
        wpa = security.get('wpa', {})
        result['ap_security'] = wpa.get('mode', '')
        result['ap_password'] = wpa.get('passphrase', '')
        result['ap_encryption'] = wpa.get('cipher', [])
        
        station_address = security.get('station_address', {})
        result['ap_acl_mode'] = station_address.get('mode', 'deny')

        capabilities = ap_data.get('capabilities', {})
        he = capabilities.get('he', {})
        ht = capabilities.get('ht', {})
        vht = capabilities.get('vht', {})
        
        result['ap_ac_channel_width'] = vht.get('channel_set_width', '')
        result['ap_ax_channel_width'] = he.get('channel_set_width', '')
        result['ap_n_channel_width'] = ht.get('channel_set_width', [])
        
        if 'accept' in station_address and 'mac' in station_address['accept']:
            result['ap_acl_accept'] = station_address['accept']['mac']
        
        if 'deny' in station_address and 'mac' in station_address['deny']:
            result['ap_acl_deny'] = station_address['deny']['mac']
    
    client_data = client_5_data if result['client_enable5'] else client_24_data if result['client_enable24'] else {}
    
    if client_data:
        result['client_ssid'] = client_data.get('ssid', '')
        
        security = client_data.get('security', {})
        wpa = security.get('wpa', {})
        result['client_security'] = wpa.get('mode', '')
        result['client_password'] = wpa.get('passphrase', '')
        
        dhcp_options = client_data.get('dhcp_options', {})
        if result['client_enable24']:
            result['client_default_route_distance_24'] = dhcp_options.get('default_route_distance', '')
        if result['client_enable5']:
            result['client_default_route_distance_5'] = dhcp_options.get('default_route_distance', '')
        
        address = client_data.get('address', [])
        if address and address[0] == 'dhcp':
            result['client_ipv4_mode'] = 'dhcp'
    
    return result