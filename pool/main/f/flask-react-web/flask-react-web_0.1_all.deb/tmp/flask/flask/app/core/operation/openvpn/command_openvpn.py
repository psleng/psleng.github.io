from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint

class OpenvpnCommand(IfaceCommand):
    """
    Command class for OpenVPN Interface:
    Extends the IfaceCommand class, it supports all of commands in IfaceCommand
    And extra commands specific to OpenVPN interface:

    - set/delete interfaces openvpn <interface-name> disable
    - set/delete interfaces openvpn <interface-name> mode {site-to-site | client | server}
    - set/delete interfaces openvpn <interface-name> <description>
    - set/delete interfaces openvpn <interface-name> device-type {tun | tap}
    - set/delete interfaces openvpn <interface-name> local-address <x.x.x.x | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> local-host <x.x.x.x| h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> local-port <1-65535>
    - set/delete interfaces openvpn <interface-name> protocol {udp | tcp-passive | tcp-active}
    - set/delete interfaces openvpn <interface-name> remote-address <x.x.x.x | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> remote-host <x.x.x.x | h:h:h:h:h:h:h:h | host-name>
    - set/delete interfaces openvpn <interface-name> remote-port <1-65535>

    # Server mode commands
    - set/delete interfaces openvpn <interface-name> server client <client-name> {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces openvpn <interface-name> server client <client-name> push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server client <client-name> subnet {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server client-ip-pool disable
    - set/delete interfaces openvpn <interface-name> server client-ip-pool start <n.n.n.n>
    - set/delete interfaces openvpn <interface-name> server client-ip-pool stop <n.n.n.n>
    - set/delete interfaces openvpn <interface-name> server client-ip-pool subnet-mask <m.m.m.m>
    - set/delete interfaces openvpn <interface-name> server client-ipv6-pool disable
    - set/delete interfaces openvpn <interface-name> server client-ipv6-pool base <h:h:h:h:h:h:h:h/x>
    - set/delete interfaces openvpn <interface-name> server domain-name <domain>
    - set/delete interfaces openvpn <interface-name> server max-connections <1-4096>
    - set/delete interfaces openvpn <interface-name> server name-server  {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces openvpn <interface-name> server push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server push-route {x.x.x.x/n | h:h:h:h:h:h:h:h/x} metric <0-4294967295>
    - set/delete interfaces openvpn <interface-name> server reject-unconfigured-clients
    - set/delete interfaces openvpn <interface-name> server subnet {x.x.x.x/n | h:h:h:h:h:h:h:h/x}
    - set/delete interfaces openvpn <interface-name> server topology {subnet | point-to-point}

    # Security commands
    - set/delete interfaces openvpn <interface-name> tls auth-key <key-name>
    - set/delete interfaces openvpn <interface-name> tls ca-certificate <ca-cert-name>
    - set/delete interfaces openvpn <interface-name> tls certificate <cert-name>
    - set/delete interfaces openvpn <interface-name> tls crypt-key <key-name>
    - set/delete interfaces openvpn <interface-name> tls dh-params <dh-params-name>
    - set/delete interfaces openvpn <interface-name> tls peer-fingerprint <finger-print>
    - set/delete interfaces openvpn <interface-name> tls role {active | passive}
    - set/delete interfaces openvpn <interface-name> tls tls-version-min {1.0 | 1.1 | 1.2 ….}
    - set/delete interfaces openvpn <interface-name> encryption cipher {none | 3des …}
    - set/delete interfaces openvpn <interface-name> encryption data-ciphers {none | 3des …}
    - set/delete interfaces openvpn <interface-name> hash {md5 | sha1 …}
    - set/delete interfaces openvpn <interface-name> shared-secret-key <key>

    # Advanced commands
    - set/delete interfaces openvpn <interface-name> ip-version {auto | ipv4 | ipv6}
    - set/delete interfaces openvpn <interface-name> keep-alive failure-count <0-1000>
    - set/delete interfaces openvpn <interface-name> keep-alive interval <0-600>
    - set/delete interfaces openvpn <interface-name> persistent-tunnel
    - set/delete interfaces openvpn <interface-name> use-lzo-compression
    - set/delete interfaces openvpn <interface-name> replace-default-route local 1


    """
    def __init__(self, **kwargs):
        try:
            self.name = kwargs.get('name', None)
            super().__init__(
                operator=kwargs.get('operator', 'set'),
                resource=kwargs.get('resource', 'openvpn'),
                name=self.name
            )
            self.attributes = {
                'interfaces': {
                    'openvpn': {
                        self.name: {}
                    }
                }
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing OpenVPN command: {e}")

    
    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        return self.vyos_cmds

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if data is None:
            return []

        self.attributes['interfaces']['openvpn'] = data

        for iface_name, iface_config in self.attributes['interfaces']['openvpn'].items():
            base_path = ['interfaces', 'openvpn', iface_name]

            simple_keys = [
                'disable', 'mode', 'description', 'device-type', 'local-address',
                'local-host', 'local-port', 'protocol', 'remote-address', 'remote-host',
                'remote-port', 'persistent-tunnel', 'use-lzo-compression', 'hash',
                'shared-secret-key'
            ]
            for key in simple_keys:
                if key in iface_config:
                    value = iface_config[key]
                    if isinstance(value, dict) and not value:
                        self.generate(*base_path, key)
                    elif (isinstance(value, str) or isinstance(value, int)) and value != '' and value != None:
                        self.generate(*base_path, key, value)

            # Nested configs
            if 'server' in iface_config:
                self._process_server_config(base_path, iface_config['server'])

            if 'tls' in iface_config:
                self._process_tls_config(base_path, iface_config['tls'])

            if 'encryption' in iface_config:
                self._process_encryption_config(base_path, iface_config['encryption'])

            if 'keep-alive' in iface_config:
                self._process_keep_alive_config(base_path, iface_config['keep-alive'])

            if 'replace-default-route' in iface_config:
                self.generate(*base_path, 'replace-default-route', 'local', iface_config['replace-default-route']['local'])

        return self.get_commands()

    def _process_server_config(self, base_path, server_config):
        server_base_path = base_path + ['server']
        for key, value in server_config.items():
            if key == 'client':
                for client_name, client_config in value.items():
                    client_path = server_base_path + ['client', client_name]
                    if 'ip' in client_config:
                        self.generate(*client_path, 'ip', client_config['ip'])
                    if 'pushRoute' in client_config:
                        if isinstance(client_config['pushRoute'], list):
                            for route in client_config['pushRoute']:
                                self.generate(*client_path, 'push-route', route)
                        elif isinstance(client_config['pushRoute'], str):
                            self.generate(*client_path, 'push-route', client_config['pushRoute'])
                    if 'subnet' in client_config:
                        if isinstance(client_config['subnet'], list):
                            for subnet in client_config['subnet']:
                                self.generate(*client_path, 'subnet', subnet)
                        elif isinstance(client_config['subnet'], str):
                            self.generate(*client_path, 'subnet', client_config['subnet'])
            elif key in ['client-ip-pool', 'client-ipv6-pool'] and value.get('disabled') is False:
                pool_path = server_base_path + [key]
                for pool_key, pool_value in value.items():
                    if pool_key != 'disabled' and pool_value != '' and pool_value is not None:
                        self.generate(*pool_path, pool_key, pool_value)
            elif key == 'push-route':
                if isinstance(value, list): 
                    for route in value:
                        self.generate(*server_base_path, 'push-route', route)
                elif isinstance(value, str):
                    self.generate(*server_base_path, 'push-route', value)
            elif key in ['domain-name', 'max-connections', 'topology']:
                self.generate(*server_base_path, key, value)
            elif key == 'name-server':
                if isinstance(value, list):
                    for ns in value:
                        self.generate(*server_base_path, 'name-server', ns)
                elif isinstance(value, str):
                    self.generate(*server_base_path, 'name-server', value)

    def _process_tls_config(self, base_path, tls_config):
        tls_base_path = base_path + ['tls']
        for key, value in tls_config.items():
            if key == 'caCert':
                for cert in value:
                    self.generate(*tls_base_path, 'ca-certificate', cert)
            elif key == 'certificate':
                for cert in value:
                    self.generate(*tls_base_path, 'certificate', cert)
            elif key == 'peerFingerprint':
                for fingerprint in value:
                    self.generate(*tls_base_path, 'peer-fingerprint', fingerprint)
            elif key == 'authKey':
                self.generate(*tls_base_path, 'auth-key', value)
            elif key == 'dhParams':
                self.generate(*tls_base_path, 'dh-params', value)
            elif key == 'role':
                self.generate(*tls_base_path, 'role', value)
            elif key == 'tlsVersionMin':
                self.generate(*tls_base_path, 'tls-version-min', value)
            else:
                self.generate(*tls_base_path, key, value)

    def _process_encryption_config(self, base_path, encryption_config):
        enc_base_path = base_path + ['encryption']
        for key, value in encryption_config.items():
            if key == 'dataCiphers':
                for cipher in value:
                    self.generate(*enc_base_path, 'data-ciphers', cipher)
            else:
                self.generate(*enc_base_path, key, value)

    def _process_keep_alive_config(self, base_path, keep_alive_config):
        ka_base_path = base_path + ['keep-alive']
        for key, value in keep_alive_config.items():
            self.generate(*ka_base_path, key, value)

if __name__ == "__main__":
    pass