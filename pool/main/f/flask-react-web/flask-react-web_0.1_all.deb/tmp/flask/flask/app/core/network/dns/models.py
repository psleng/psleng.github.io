import json

from app.db.database import db
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy import text
from typing import List
from optparse import Option
from pydantic import BaseModel, RootModel, field_validator, Field, ConfigDict
from typing import Optional, List, DefaultDict, Dict
from app.core.operation.validate import validate_ipv4, validate_ipv6, validate_ip_range

from app.db.database import db

class CreateDNSServerDTO(BaseModel):
    ip_address: str
    ip_address_type: str

class DeleteDNSServerDTO(BaseModel):
    ip_address: str
    ip_address_type: str

class DNSDomain(BaseModel):
    name: str
    name_servers: list[str]

class DNSNameServer(BaseModel):
    address: str
    port: Optional[int] = None

class DNSForwardingDTO(BaseModel):
    allow_from: list[str] = []
    cache_size: Optional[int] = None
    dhcp_interfaces: list[str] = []
    domains: list[DNSDomain] = []
    ignore_hosts_file: bool = False
    listen_addresses: list[str] = []
    name_servers: list[DNSNameServer] = []
    negative_ttl: Optional[int] = None


class DNSServerDTO(BaseModel):
    ipv4: Optional[List[str]] = Field(default_factory=list)
    ipv6: Optional[List[str]] = Field(default_factory=list)

    model_config = ConfigDict(extra='forbid')

class WebDTO(BaseModel):
    skip: Optional[str] = None
    url: Optional[str] = None

class AddressDTO(BaseModel):
    interface: Optional[str] = None
    web: Optional[WebDTO] = None

class DDNSInterfaceDTO(BaseModel):
    address: Optional[AddressDTO] = None
    expiry_time: Optional[str] = None
    hostname: Optional[str] = None
    ip_version: Optional[str] = None
    key_path: Optional[str] = None
    login: Optional[str] = None
    name: str
    password: Optional[str] = None
    server: Optional[str] = None
    protocol: Optional[str] = None
    ttl: Optional[str] = None
    wait_time: Optional[str] = None
    zone: Optional[str] = None

class DDNSDTO(BaseModel):
    host_groups: Optional[List[str]] = Field(default_factory=list)
    interfaces: Optional[List[DDNSInterfaceDTO]] = Field(default_factory=list)

    model_config = ConfigDict(extra='forbid')

class UpdateDNSDTO(BaseModel):
    forwarding: Optional[DNSForwardingDTO] = None
    dns_server: Optional[DNSServerDTO] = None
    ddns: Optional[DDNSDTO] = None

class DNSInterfaceConfig(BaseModel):
    interface: Optional[str] = None
    url: Optional[str] = None
    skip: Optional[str] = None
    protocol: Optional[str] = None
    login: Optional[str] = None
    password: Optional[str] = None
    registered_service: Optional[str] = None
    hostname: Optional[str] = None

class HostGroup(BaseModel):
    id: str
    name: str
    hosts: list[str]

class Web(BaseModel):
    skip: Optional[str] = None
    url: Optional[str] = None


class Address(BaseModel):
    interface: Optional[str] = None
    web: Web


class DNSInterface(BaseModel):
    id: str
    address: Address
    expiry_time: Optional[str] = None
    ip_version: Optional[str] = None
    key_path: Optional[str] = None
    hostname: str
    name: str
    ttl: Optional[str] = None
    wait_time: Optional[str] = None
    zone: Optional[str] = None
    protocol: str
    login: str
    password: str

class UpdateDynamicDNSDTO(BaseModel):
    host_groups: list[HostGroup] = []
    interfaces: list[DNSInterface] = []

class DNSInterfaceConfig(BaseModel):
    interface: Optional[str] = None
    url: Optional[str] = None
    skip: Optional[str] = None
    protocol: Optional[str] = None
    login: Optional[str] = None
    password: Optional[str] = None
    registered_service: Optional[str] = None
    hostname: Optional[str] = None

class UpdateDynamicDNSDTO(BaseModel):
    host_group: Dict[str, list[str]] = {}
    dns_interface: Optional[DNSInterfaceConfig] = None



class DNSServer(db.Model):

    __tablename__ = 'vyos_dns_server'

    id = Column(Integer, primary_key=True)
    ip_address = Column(String, nullable=True)
    ip_address_type = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    
    @classmethod
    def refresh(cls, data_list: list, app_context=None):
        """Refresh DNS Server data in the database.
        
        Args:
            data_list: List of dictionaries, each containing:
                      - ip_address: IP address string
                      - ip_address_type: 'ipv4' or 'ipv6'
        """
        try:
            print("Refresh DNS Server data")
            if app_context is not None:
                with app_context:
                    DNSServer.truncate()
            else:
                DNSServer.truncate()
            
            for data in data_list:
                new_data = DNSServer(
                    ip_address=data.get('ip_address'),
                    ip_address_type=data.get('ip_address_type')
                )
                if app_context is not None:
                    with app_context:
                        db.session.add(new_data)
                else:
                    db.session.add(new_data)

            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
        except Exception as e:
            print("Error refreshing DNS Server:", str(e))
            
    def serialize(self):
        return {
            "ip_address": self.ip_address,
            "ip_address_type": self.ip_address_type
        }


class DNSDynamicInterface(db.Model):
    __tablename__ = 'vyos_dns_dynamic_interface'

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    url = Column(String, nullable=True)
    skip = Column(String, nullable=True)
    service = Column(String, nullable=True)
    login = Column(String, nullable=True)
    password = Column(String, nullable=True)
    hostname = Column(String, nullable=True)
    zone = Column(String, nullable=True)
    server = Column(String, nullable=True)
    protocol = Column(String, nullable=True)
    expiry_time = Column(String, nullable=True)
    ip_version = Column(String, nullable=True)
    ttl = Column(String, nullable=True)
    wait_time = Column(String, nullable=True)
    key_path = Column(String, nullable=True)
    zone = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        print("Refresh DNS Dynamic Interface data:")

        try:
            if app_context is not None:
                with app_context:
                    DNSDynamicInterface.truncate()
            else:
                DNSDynamicInterface.truncate()
            
            if not data or 'name' not in data:
                if app_context is not None:
                    with app_context:
                        db.session.commit()
                else:
                    db.session.commit()
                return

            name_configs = data.get('name', {})
            for ddns_name, ddns_data in name_configs.items():
                ddns = cls()
                if app_context is not None:
                    with app_context:
                        db.session.add(ddns)
                else:
                    db.session.add(ddns)

                ddns.name = ddns_name
                ddns.service = ddns_name

                if 'address' in ddns_data:
                    address_data = ddns_data['address']
                    if 'web' in address_data:
                        web_data = address_data['web']
                        ddns.url = web_data.get('url', '')
                        ddns.skip = web_data.get('skip', '')
                    elif 'interface' in address_data:
                        ddns.interface = address_data.get('interface', '')

                if 'host-name' in ddns_data:
                    ddns.hostname = ddns_data['host-name']
                if 'password' in ddns_data:
                    ddns.password = ddns_data['password']
                if 'protocol' in ddns_data:
                    ddns.protocol = ddns_data['protocol']
                if 'server' in ddns_data:
                    ddns.server = ddns_data['server']
                if 'username' in ddns_data:
                    ddns.login = ddns_data['username']
                if 'zone' in ddns_data:
                    ddns.zone = ddns_data['zone']

            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()
            print("DNS Dynamic Interface refresh completed successfully")
        except Exception as e:
            # db.session.rollback()
            print(f"Error refreshing DNS Dynamic Interface: {str(e)}")
            raise

    def serialize(self):
        return {
            "name": self.name,
            "address": {
                "web": {
                    "url": self.url,
                    "skip": self.skip
                },
                "interface": self.interface
            },
            "protocol": self.protocol,
            "login": self.login,
            "password": self.password,
            "hostname": self.hostname,
            "zone": self.zone,
            "server": self.server,
            "expiry_time": self.expiry_time,
            "ip_version": self.ip_version,
            "ttl": self.ttl,
            "wait_time": self.wait_time,
            "key_path": self.key_path
        }


class DNSDynamicHostGroup(db.Model):
    __tablename__ = 'vyos_dns_dynamic_host_group'

    id = Column(Integer, primary_key=True)
    group_name = Column(String, nullable=True)
    host_name = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, data: dict):
        print("Refresh DNS Dynamic Host Group data:", data)

        DNSDynamicHostGroup.truncate()
        for group_name, host_names in data.items():
            for host_name in host_names:
                new_data = DNSDynamicHostGroup(
                    group_name=group_name,
                    host_name=host_name
                )
                db.session.add(new_data)
        db.session.commit()

    def serialize(self):
        return {
            "group_name": self.group_name,
            "host_name": self.host_name
        }


class DNSForwarding(db.Model):
    __tablename__ = 'vyos_dns_forwarding'

    id = Column(Integer, primary_key=True)
    cache_size = Column(Integer, nullable=True)
    negative_ttl = Column(Integer, nullable=True)
    ignore_hosts_file = Column(Boolean, nullable=True)
    allow_from = Column(String, nullable=True)
    dhcp_interfaces = Column(String, nullable=True)
    listen_addresses = Column(String, nullable=True)
    domains = Column(String, nullable=True)
    name_servers = Column(String, nullable=True)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, data: dict, app_context=None):
        """Refresh DNS Forwarding data in the database.

        Args:
            data: Dictionary containing one or more DNS forwarding attributes to update.
                Supported attributes:
                - allow_from: List of allowed networks
                - dhcp_interfaces: List of DHCP interfaces
                - listen_addresses: List of listen addresses
                - domains: List of domain configurations
                - name_servers: List of nameserver configurations
                - cache_size: Cache size (integer)
                - negative_ttl: Negative TTL (integer)
                - ignore_hosts_file: Whether to ignore hosts file (boolean)
        """
        print("Refresh DNS Forwarding data:")

        try:
            if app_context is not None:
                with app_context:
                    DNSForwarding.truncate()
            else:
                DNSForwarding.truncate()
            
            if not data or data == {}:
                # If data is empty, truncate the table
                if app_context is not None:
                    with app_context:
                        db.session.commit()
                else:
                    db.session.commit()
                return
            
            # Get existing record or create new one
            if app_context is not None:
                with app_context:
                    dns_forward = cls.query.first()
            else:
                dns_forward = cls.query.first()
                
            if not dns_forward:
                dns_forward = cls()
                if app_context is not None:
                    with app_context:
                        db.session.add(dns_forward)
                else:
                    db.session.add(dns_forward)
            # Update only the attributes that are present in the data
            if 'allow_from' in data:
                dns_forward.allow_from = json.dumps(data['allow_from'])
            if 'dhcp_interfaces' in data:
                dns_forward.dhcp_interfaces = json.dumps(data['dhcp_interfaces'])
            if 'listen_addresses' in data:
                dns_forward.listen_addresses = json.dumps(data['listen_addresses'])
            if 'domains' in data:
                dns_forward.domains = json.dumps(data['domains'])
            if 'name_servers' in data:
                dns_forward.name_servers = json.dumps(data['name_servers'])
            if 'cache_size' in data:
                dns_forward.cache_size = data['cache_size']
            if 'negative_ttl' in data:
                dns_forward.negative_ttl = data['negative_ttl']
            if 'ignore_hosts_file' in data:
                dns_forward.ignore_hosts_file = data['ignore_hosts_file']

            if app_context is not None:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

            return True
        except Exception as e:
            print(f"Error refreshing DNS forwarding data: {e}")
            # db.session.rollback()
            return False

    def serialize(self):
        try:
            return {
                "cache_size": self.cache_size,
                "negative_ttl": self.negative_ttl,
                "ignore_hosts_file": self.ignore_hosts_file,
                "allow_from": json.loads(self.allow_from) if self.allow_from else [],
                "dhcp_interfaces": json.loads(self.dhcp_interfaces) if self.dhcp_interfaces else [],
                "listen_addresses": json.loads(self.listen_addresses) if self.listen_addresses else [],
                "domains": json.loads(self.domains) if self.domains else [],
                "name_servers": json.loads(self.name_servers) if self.name_servers else []
            }
        except Exception as e:
            print(f"Error serializing DNS Forwarding data: {e}")
            return {
                "cache_size": 10000,
                "negative_ttl": 3600,
                "ignore_hosts_file": False,
                "allow_from": [],
                "dhcp_interfaces": [],
                "listen_addresses": [],
                "domains": [],
                "name_servers": []
            }
