from app.core.network.dns.models import DNSServer
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_dns_server_job(app_context):
    """Job to fetch DNS server information and update the database.
    
    Args:
        app_context: Flask application context
    """
    try:
        refresh_db_dns_server(app_context=app_context)
    except Exception as e:
        print('Error fetch dns server', str(e))



def refresh_db_dns_server(app_context=None):
    try: 
        logger.info("[TASK] Fetch DNS Servers")
        print("[TASK] Fetch DNS Servers")
        vyos_data = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_SERVER)
        logger.info(vyos_data)
        print(vyos_data)
        if app_context is not None:
            DNSServer.refresh(vyos_data, app_context=app_context)
        else:
            DNSServer.refresh(vyos_data)
        return vyos_data
    except Exception as e:
        print(str(e))
