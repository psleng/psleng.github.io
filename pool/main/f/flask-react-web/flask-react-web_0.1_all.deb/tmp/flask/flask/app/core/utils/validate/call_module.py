import importlib
import importlib.util
import os
from typing import Any, Optional, Dict, Union

def call_module_function(
    module_path: str,
    function_name: str,
    args: Optional[tuple] = None,
    kwargs: Optional[Dict[str, Any]] = None,
    root_path: str = "/usr/libexec/vyos"
) -> Union[Any, tuple[str, int]]:
    """
    Call a specific function from a module with arguments and return its result.
    
    Args:
        module_path: Path to the module relative to root_path
        function_name: Name of the function to call
        args: Tuple of positional arguments to pass to the function
        kwargs: Dictionary of keyword arguments to pass to the function
        root_path: Base path where modules are located
        
    Returns:
        The result of the function call, or a tuple of (error_message, status_code)
        
    Raises:
        ImportError: If module cannot be imported
        AttributeError: If function doesn't exist in module
        Exception: For other errors during execution
    """
    try:
        # Normalize paths and create full path
        module_path = module_path.lstrip('/')
        file_path = os.path.join(root_path, module_path)
        
        # Check if file exists
        if not os.path.exists(file_path):
            return f"Module not found at {file_path}", 404
            
        # Import module
        spec = importlib.util.spec_from_file_location("vyos_module", file_path)
        if spec is None:
            return f"Could not create module spec for {file_path}", 500
            
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Get the function
        if not hasattr(module, function_name):
            return f"Function {function_name} not found in module {module_path}", 404
        
        func = getattr(module, function_name)
        
        # Call function with provided arguments
        if args and kwargs:
            result = func(*args, **kwargs)
        elif args:
            result = func(*args)
        elif kwargs:
            result = func(**kwargs)
        else:
            result = func()
            
        return result
        
    except ImportError as e:
        return f"Failed to import module {module_path}: {str(e)}", 500
    except AttributeError as e:
        return f"Function {function_name} not found: {str(e)}", 404
    except Exception as e:
        return f"Error executing {function_name}: {str(e)}", 500

def call_get_config(service: str, root_path: str = "/usr/libexec/vyos") -> Union[str, tuple[str, int]]:
    """Call get_config function for a service"""
    service_path = f"/conf_mode/{service}.py"
    return call_module_function(service_path, "get_config", root_path=root_path)

def call_verify(service: str, config: Any, root_path: str = "/usr/libexec/vyos") -> Union[bool, tuple[str, int]]:
    """Call verify function for a service with config"""
    service_path = f"/conf_mode/{service}.py"
    result = call_module_function(service_path, "verify", args=(config,), root_path=root_path)
    
    if isinstance(result, tuple):  # Error case
        return result
    return result is None  # VyOS verify returns None for success

def call_generate(service: str, config: Any, root_path: str = "/usr/libexec/vyos") -> Union[list, tuple[str, int]]:
    """Call generate function for a service with config"""
    service_path = f"/conf_mode/{service}.py"
    return call_module_function(service_path, "generate", args=(config,), root_path=root_path)

def call_apply(service: str, config: Any, root_path: str = "/usr/libexec/vyos") -> Union[None, tuple[str, int]]:
    """Call apply function for a service with config"""
    service_path = f"/conf_mode/{service}.py"
    return call_module_function(service_path, "apply", args=(config,), root_path=root_path)


result = call_module_function("/conf_mode/service_dns_forwarding.py", "get_config")
print("Result:", result)
