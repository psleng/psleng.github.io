import pytest
import json

test_valid = [
    pytest.param(
        {
            "valid_json": json.dumps({
                "dhcp": {
                    "listen_interface": ["eth0", "eth1"],
                    "pools": [
                        {
                            "description": "LAN DHCP Pool",
                            "dhcp_name": "LAN",
                            "dhcp_type": "dhcp",
                            "enabled": True,
                            "lease_time": "86400",
                            "range_end": "192.168.1.200",
                            "range_start": "192.168.1.100",
                            "subnet": "192.168.1.0/24",
                            "subnet_id": "1",
                            "default_router": "192.168.1.1",
                            "name_server": "8.8.8.8",
                            "domain_name": "example.com",
                            "authoritative": True
                        }
                    ]
                },
                "dhcpv6": {
                    "listen_interface": ["eth0"],
                    "pools": [
                        {
                            "description": "IPv6 Pool",
                            "dhcp_name": "IPv6LAN",
                            "dhcp_type": "dhcpv6",
                            "enabled": True,
                            "lease_time": "86400",
                            "range_end": "2001:db8::200",
                            "range_start": "2001:db8::100",
                            "subnet": "2001:db8::/64",
                            "subnet_id": "1",
                            "name_servers": ["2001:4860:4860::8888"]
                        }
                    ]
                },
                "dhcpRelays": {
                    "disable": False,
                    "hop_count": "10",
                    "listen_interface": ["eth2"],
                    "max_packet_size": "576",
                    "relay_agent_packet": "forward",
                    "relay_servers": ["192.168.2.1", "192.168.2.2"],
                    "upstream_interface": ["eth3"]
                }
            })
        },
        id="test_valid_full_config"
    ),
    pytest.param(
        {
            "valid_json": json.dumps({
                "dhcp": {
                    "pools": [
                        {
                            "dhcp_name": "LAN",
                            "range_end": "192.168.1.200",
                            "range_start": "192.168.1.100",
                            "subnet": "192.168.1.0/24",
                            "subnet_id": "1"
                        }
                    ]
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            })
        },
        id="test_valid_minimal_config"
    )
]

test_invalid = [
    pytest.param(
        {
            "invalid_json": json.dumps({
                "dhcp": {
                    "pools": [
                        {
                            "dhcp_name": "LAN",
                            "range_end": 2200000, # Invalid IP address
                            "range_start": "192.168.1.100",
                            "subnet": "192.168.1.0/24",
                            "subnet_id": "1"
                        }
                    ]
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            })
        },
        id="test_invalid_ip_address"
    ),
    pytest.param(
        {
            "invalid_json": json.dumps({
                "dhcp": {
                    "pools": [
                        {
                            "dhcp_name": "LAN",
                            "range_end": "192.168.1.200",
                            "range_start": "192.168.1.100",
                            "subnet": 1230000, # Invalid subnet format
                            "subnet_id": "1"
                        }
                    ]
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            })  
        },
        id="test_invalid_subnet"
    )
]

test_minimal = [
    pytest.param(
        {
            "minimal_json": json.dumps({
                "dhcp": {
                    "pools": [
                        {
                            "dhcp_name": "LAN",
                            "range_end": "192.168.1.200",
                            "range_start": "192.168.1.100",
                            "subnet": "192.168.1.0/24",
                            "subnet_id": "1"
                        }
                    ]
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            })
        },
        id="test_minimal_dhcp_config"
    ),
    pytest.param(
        {
            "minimal_json": json.dumps({
                "dhcpRelays": {
                    "listen_interface": ["eth2"],
                    "relay_servers": ["192.168.2.1"]
                }
            })
        },
        id="test_minimal_relay_config"
    )
]

test_compare = [
    pytest.param(
        {
            "json_input": {
                "dhcp": {
                    "listen_interface": ["eth0"],
                    "pools": [
                        {
                            "dhcp_name": "LAN",
                            "range_end": "192.168.1.200",
                            "range_start": "192.168.1.100",
                            "subnet": "192.168.1.0/24",
                            "subnet_id": "1"
                        }
                    ]
                }
            },
            "current_config": {
                "dhcp": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.50",
                                            "stop": "192.168.1.150"
                                        }
                                    },
                                    "subnet-id": "1"
                                }
                            }
                        }
                    }
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            },
            "new_config": {
                "dhcp": {
                    "listen-interface": ["eth0"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.100",
                                            "stop": "192.168.1.200"
                                        }
                                    },
                                    "subnet-id": "1"
                                }
                            }
                        }
                    }
                },
                "dhcpv6": {},
                "dhcpRelays": {}
            },
            "expected_diff": {
                "created": {
                    "dhcp": {
                        "listen-interface": ["eth0"],
                        "shared-network-name": {
                            "LAN": {
                                "subnet": {
                                    "192.168.1.0/24": {
                                        "range": {
                                            "range_1": {
                                                "start": "192.168.1.100",
                                                "stop": "192.168.1.200"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "deleted": {
                    "dhcp": {
                        "listen-interface": ["eth1"],
                        "shared-network-name": {
                            "LAN": {
                                "subnet": {
                                    "192.168.1.0/24": {
                                        "range": {
                                            "range_1": {
                                                "start": "192.168.1.50",
                                                "stop": "192.168.1.150"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_compare_dhcp_config"
    )
]