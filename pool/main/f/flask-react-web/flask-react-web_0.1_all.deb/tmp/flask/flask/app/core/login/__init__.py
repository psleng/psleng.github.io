from flask import Blueprint

vyos_login_bp = Blueprint('login', __name__)

from . import routes