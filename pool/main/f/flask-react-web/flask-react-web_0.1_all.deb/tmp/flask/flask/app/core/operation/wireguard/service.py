from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_WIREGUARD_GENERATE_KEY_PAIR
from app.core.operation.wireguard.parser import parse_wireguard_key_pair

def create_wireguard_key_pair(provider, data):
    res = provider.http_service.send_request(action=Action.GENERATE, data=SHOW_WIREGUARD_GENERATE_KEY_PAIR, verify=False)
    return parse_wireguard_key_pair(res.json()['data'])