from app.core.api.http.cmd.command import Command
import pprint

def format_description(description: str) -> str:

    return description.replace(' ', '_')


class IfaceCommand(Command):
    """
    Command class for Interface commands.
    Support the following VyOS commands:

    set/del interface <intf-type> <intf-name> disable (default enable)

    set/del interface <intf-type> <intf-name> description <description>
    set/del interface bridge <bridge-intf-name> member interface <intf-name>

    - Static: set/del interface <intf-type> <intf-name> address <ipv4>
    - DHCP: set/del interface <intf-type> <intf-name> address dhcp

    - DHCP: set/del interface <intf-type> <intf-name> address dhcpv6
    - Autoconfiguration: set/del interface <intf-type> <intf-name> ipv6 address autoconf
    - Static: set/del interface <intf-type> <intf-name> address <ipv6>

    IPv6 Neighbor Discovery
    - Route Preference: set/del service router-advert interface <intf-name> default-preference {low|medium|high} (default medium)
    - Managed config flag: set/del service router-advert interface <intf-name> managed-flag (default no)
    - Other config flag: set/del service router-advert interface <intf-name> other-config-flag (default no)
    - DAD attempts: set/del interfaces ethernet eth2 ipv6 dup-addr-detect-transmits <0-600> (default 1; 0 means don't send)
    - Reachable time: set/del service router-advert interface <intf-name> reachable-time <0-3600000> (default 0 means unspecified)
    - Retransmission time: set/del service router-advert interface <intf-name> retrans-timer <0-4294967295> (default 0 means unspecified)

    IPv6 Routing Prefix Advertisement
    - Address: set/del service router-advert interface <intf-name> prefix <prefix/len>
    - Prefix length: set/del service router-advert interface <intf-name> prefix <prefix/len>
    - Valid lifetime: set/del service router-advert interface <intf-name> prefix <prefix/len> valid-lifetime {<1-4294967295> | infinity} (default 2592000)
    - Preferred lifetime: set/del service router-advert interface <intf-name> prefix <prefix/len> preferred-lifetime {<1-4294967295>| infinity} (default 14400)
    - Do not use prefix for onlink determination: set/del service router-advert interface <intf-name> prefix <prefix/len> no-on-link-flag (default no)
    - Do not use prefix for autoconfiguration: set/del service router-advert interface <intf-name> prefix <prefix/len> no-autonomous-flag (default no)

    IPv6 Router Advertisement Control
    - Suppress IPv6 router advertisements: set/del service router-advert interface <intf-name> no-send-advert (default no)
    - Hop limit: set/del service router-advert interface <intf-name> hop-limit <1-255> (default 64)
    - Max RA interval: set/del service router-advert interface <intf-name> interval max <4-1800> (default 600)
    - Minimum interval: set/del service router-advert interface <intf-name> interval min <3-1350> (default 0.33*max if max > 9; otherwise equal max according to RFC 4861)
    - RA lifetime: set/del service router-advert interface <intf-name> default-lifetime <4-9000> (default 3*max)
    - Add DNS: set/del service router-advert interface <intf-name> name-server <ipv6>
    """
    
    def __init__(self, **kwargs):
        try:
            super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'interface'))
            self.attributes = {
                'interfaces': {},
                'router_advert': {}
            }
            self.cmds = []
            self.vyos_cmds = []
            
            for key, value in kwargs.items():
                if key in self.attributes:
                    self.attributes[key] = value
        except Exception as e:
            print(f"Error initializing Interface command: {e}")

    def _build_command(self, *path_elements: str) -> str:
        """Build a command string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        """Generate and store both VyOS format and raw command format"""
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(' '.join(map(str, args)))

    def get_commands(self):
        """Return the list of raw commands"""
        return self.vyos_cmds

    def _process_interface(self, interface_type, interface_name, config):
        """Process interface configuration and generate commands"""
        base = ['interfaces', interface_type, interface_name]
        
        # Process basic interface settings
        if 'disable' in config:
            self.generate(*base, 'disable') if config['disable'] else self.generate(*base, 'disable')
        
        if 'description' in config:
            self.generate(*base, 'description', format_description(config['description']))
        
        if 'address' in config:
            if isinstance(config['address'], str):
                self.generate(*base, 'address', config['address'])
            else:
                for addr in config['address']:
                    if isinstance(addr, dict):
                        if addr.get('type') == 'static':
                            self.generate(*base, 'address', addr['value'])
                        elif addr.get('type') == 'dhcp':
                            self.generate(*base, 'address', 'dhcp')
                        elif addr.get('type') == 'dhcpv6':
                            self.generate(*base, 'address', 'dhcpv6')
                        elif addr.get('type') == 'autoconf':
                            self.generate('ipv6', 'address', 'autoconf')
                    else:
                        # Handle string format (e.g., '192.168.1.123/24')
                        self.generate(*base, 'address', addr)

    def _process_bridge_member(self, bridge_name, member_name):
        """Process bridge member configuration"""
        self.generate('interface', 'bridge', bridge_name, 'member', 'interface', member_name)

    def _process_ipv6_neighbor_discovery(self, interface_name, config):
        """Process IPv6 neighbor discovery settings"""
        base = ['service', 'router-advert', 'interface', interface_name]
        
        if 'default-preference' in config:
            self.generate(*base, 'default-preference', config['default-preference'])
        
        if 'managed-flag' in config:
            self.generate(*base, 'managed-flag', 'set' if config['managed-flag'] else 'delete')
        
        if 'other-config-flag' in config:
            self.generate(*base, 'other-config-flag', 'set' if config['other-config-flag'] else 'delete')
        
        if 'dup-addr-detect-transmits' in config:
            self.generate('interfaces', 'ethernet', interface_name, 'ipv6', 'dup-addr-detect-transmits', config['dup-addr-detect-transmits'])
        
        if 'reachable-time' in config:
            self.generate(*base, 'reachable-time', config['reachable-time'])
        
        if 'retrans-timer' in config:
            self.generate(*base, 'retrans-timer', config['retrans-timer'])

    def _process_ipv6_prefix_advertisement(self, interface_name, config):
        """Process IPv6 prefix advertisement settings"""
        base = ['service', 'router-advert', 'interface', interface_name]
        
        for prefix, prefix_config in config.items():
            if 'valid-lifetime' in prefix_config:
                self.generate(*base, 'prefix', prefix, 'valid-lifetime', prefix_config['valid-lifetime'])
            
            if 'preferred-lifetime' in prefix_config:
                self.generate(*base, 'prefix', prefix, 'preferred-lifetime', prefix_config['preferred-lifetime'])
            
            if 'no-on-link-flag' in prefix_config:
                self.generate(*base, 'prefix', prefix, 'no-on-link-flag', 'set' if prefix_config['no-on-link-flag'] else 'delete')
            
            if 'no-autonomous-flag' in prefix_config:
                self.generate(*base, 'prefix', prefix, 'no-autonomous-flag', 'set' if prefix_config['no-autonomous-flag'] else 'delete')

    def _process_router_advertisement_control(self, interface_name, config):
        """Process IPv6 router advertisement control settings"""
        base = ['service', 'router-advert', 'interface', interface_name]
        
        if 'no-send-advert' in config:
            self.generate(*base, 'no-send-advert', 'set' if config['no-send-advert'] else 'delete')
        
        if 'hop-limit' in config:
            self.generate(*base, 'hop-limit', config['hop-limit'])
        
        if 'interval' in config:
            if 'max' in config['interval']:
                self.generate(*base, 'interval', 'max', config['interval']['max'])
            if 'min' in config['interval']:
                self.generate(*base, 'interval', 'min', config['interval']['min'])
        
        if 'default-lifetime' in config:
            self.generate(*base, 'default-lifetime', config['default-lifetime'])
        
        if 'name-server' in config:
            self.generate(*base, 'name-server', config['name-server'])

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """Generate VyOS commands for interface configuration"""
        if data:
            for interface_type, interfaces in data.get('interfaces', {}).items():
                for interface_name, config in interfaces.items():
                    self._process_interface(interface_type, interface_name, config)
                    
                    if interface_type == 'bridge' and 'members' in config:
                        for member in config['members']:
                            self._process_bridge_member(interface_name, member)

            for interface_name, config in data.get('router_advert', {}).items():
                if 'neighbor_discovery' in config:
                    self._process_ipv6_neighbor_discovery(interface_name, config['neighbor_discovery'])
                
                if 'prefix_advertisement' in config:
                    self._process_ipv6_prefix_advertisement(interface_name, config['prefix_advertisement'])
                
                if 'advertisement_control' in config:
                    self._process_router_advertisement_control(interface_name, config['advertisement_control'])

        return self.get_commands()