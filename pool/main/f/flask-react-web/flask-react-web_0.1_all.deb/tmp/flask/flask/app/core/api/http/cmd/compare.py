from typing import Dict, Any, List, Set, Union
from app.core.operation.utils import measure_time
from app.core.utils.process_config import normalize_key
import pprint

@measure_time(log_level='DEBUG')
def compare_configs(new_config: Dict[str, Any], current_config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Compare new configuration with current configuration and return differences.
    
    Args:
        new_config: New configuration dictionary
        current_config: Current configuration dictionary
        
    Returns:
        dict: Dictionary containing deleted and created fields in the format:
        {
            'deleted': {'domains': [{'name': 'example.com', 'name_servers': ['1.1.1.1', '2.2.2.2']}]},
            'created': {'domains': [{'name': 'example.com', 'name_servers': ['1.1.1.1']})}
        }
    """
    print("Comparing configs...")
    print("New Config:")
    print(pprint.pformat(new_config, indent=2, width=80))
    print("Current Config:")
    print(pprint.pformat(current_config, indent=2, width=80))
    def compare_lists(new_list: List[Dict[str, Any]], current_list: List[Dict[str, Any]]) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Compare two lists of dictionaries and return deleted and created items"""
        deleted = []
        created = []
        
        # Convert items to strings for comparison
        current_items = [str(item) for item in current_list]
        new_items = [str(item) for item in new_list]
        
        # Find deleted items
        for i, current_item in enumerate(current_items):
            if current_item not in new_items:
                deleted.append(current_list[i])
        
        # Find created items
        for i, new_item in enumerate(new_items):
            if new_item not in current_items:
                created.append(new_list[i])
        
        return deleted, created

    def compare_dicts(new_dict: Dict[str, Any], current_dict: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
        """Compare two dictionaries and return deleted and created differences"""
        deleted = {}
        created = {}

        # Handle None values
        if new_dict is None and current_dict is not None:
            return current_dict, {}
        elif current_dict is None and new_dict is not None:
            return {}, new_dict
        elif new_dict is None and current_dict is None:
            return {}, {}

        # Compare each key in both dictionaries
        all_keys = set(new_dict.keys()) | set(current_dict.keys())
        for key in all_keys:
            new_val = new_dict.get(key)
            current_val = current_dict.get(key)

            # Handle lists (like domains list)
            if isinstance(new_val, list) or isinstance(current_val, list):
                new_list = new_val if isinstance(new_val, list) else []
                current_list = current_val if isinstance(current_val, list) else []
                deleted_items, created_items = compare_lists(new_list, current_list)
                if deleted_items:
                    deleted[key] = deleted_items
                if created_items:
                    created[key] = created_items
                continue

            # Handle nested dictionaries
            if isinstance(new_val, dict) and isinstance(current_val, dict):
                d, c = compare_dicts(new_val, current_val)
                if d:
                    deleted[key] = d
                if c:
                    created[key] = c
                continue

            # Handle simple values
            if new_val != current_val:
                if current_val is not None:
                    deleted[key] = current_val
                if new_val is not None:
                    created[key] = new_val

        return deleted, created

    deleted, created = compare_dicts(new_config, current_config)
    return {"deleted": deleted, "created": created}

if __name__ == "__main__":
    new_config = {
        "firewall": {
            "name": {
                "WAN_IN": {
                    "rule": {
                        "10": {"action": "accept", "protocol": "tcp"},
                        "20": {"action": "drop", "protocol": "udp"}
                    }
                }
            }
        }
    }
    current_config = {
        "firewall": {
            "name": {
                "WAN_IN": {
                    "rule": {
                        "10": {"action": "drop", "protocol": "tcp"},
                        "30": {"action": "accept", "protocol": "icmp"}
                    }
                }
            }
        }
    }
    
    result = compare_configs(new_config, current_config, ())
    print(result)
