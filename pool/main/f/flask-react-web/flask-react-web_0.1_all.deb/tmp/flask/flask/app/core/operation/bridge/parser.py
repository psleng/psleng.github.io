def parse_to_bridge_config(data: dict):
    """
        Parse data to bridge config
        Sample input:
        {
            address: "192.168.1.1"
            prefix_length: "24"
        }
        Output:
        {
            address: "192.168.1.1/24"
        }
    """

    if not data:
        return {}

    result = {}
    if "address" in data and "prefix_length" in data:
        address = data['address']
        prefix_length = data['prefix_length']

        result['address'] = str(address) + "/" + str(prefix_length)
    
    return result

