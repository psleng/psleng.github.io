"""
    Test class for NAT entire flow of updating config, includes:
    - parse_input
    - generate_config
    - process_config
    - verify
"""
import pytest
import json
from app.test.conftest import test_service_provider
from app.core.network.nat.models import NATDTO
from app.core.network.nat.parser import parse_to_nat_config
from app.core.api.http.cmd.compare import compare_configs
from app.core.network.nat.command_nat import CommandNAT
from app.test.core.network.nat.test_cases._test_case_final import test_final
from app.test.core.base import TestFinal
from app.core.utils.process_config import process_commands, merge_dicts_delete, merge_dicts_set

class TestNATUpdateFinal(TestFinal):
    __test__ = False # Skip final test cases
    
    @pytest.fixture
    def cmd_set(self):
        return CommandNAT(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return CommandNAT(operator='delete')

    @pytest.fixture
    def success_verification(self):
        return ['None', '']

    @pytest.fixture
    def parser(self):
        return parse_to_nat_config
    
    @pytest.fixture
    def dto_model(self):
        return NATDTO

    @pytest.mark.parametrize("test_data", test_final)
    def test_nat_update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data):
        super()._update_final(
            success_verification=success_verification,
            parser=parser,
            dto_model=dto_model,
            test_service_provider=test_service_provider,
            cmd_set=cmd_set,
            cmd_delete=cmd_delete,
            test_data=test_data
        )