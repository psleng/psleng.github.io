from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_INTERFACE_ETHERNET
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)


def fetch_ethernet_config(provider, params=None):
    """Fetch Ethernet configuration."""
    
    logger.debug("Fetching Ethernet config...")
    print("Fetching Ethernet config...")
    data = provider.verify_service.call_get_config("ethernet")
    ethernet_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_INTERFACE_ETHERNET, verify=False)
    data = ethernet_response.json()['data']
    
    return data