from pydantic import BaseModel, RootModel
from typing import Optional, List
from app.db.database import db
from sqlalchemy import Column, Integer, String, UniqueConstraint
from app.log.logger import logger

from app.core.routing.parsers import parse_route_config, parse_route_config_v6

class CreateRoutingDTO(BaseModel):
    intf_type: str
    name: str
    address: str
    desc: Optional[str] = None

class UpdateRoutingDTO(BaseModel):
    name: str
    intf_type: str
    desc: Optional[str] = None
    address: Optional[str] = None

class DeleteRoutingDTO(BaseModel):
    name: str
    intf_type: str


class RouteV4DTO(BaseModel):
    route_type: Optional[str] = None
    dest_prefix: Optional[str] = None
    nexthop: Optional[str] = None
    distance: Optional[str] = None
    interface: Optional[str] = None
    route_table_id: Optional[int] = None
    id: Optional[int] = None
    vrf: Optional[str] = None


class RouteV6DTO(BaseModel):
    route_type: Optional[str] = None
    dest_prefix: Optional[str] = None
    nexthop: Optional[str] = None
    distance: Optional[str] = None
    interface: Optional[str] = None
    route_table_id: Optional[int] = None
    id: Optional[int] = None
    vrf: Optional[str] = None


class VerifyGeneralRoutingDTO(BaseModel):
    routes: Optional[List[RouteV4DTO] | List[RouteV6DTO]] = None
    route_ver: str
    route_id: Optional[int] = None
    
class GeneralRoutingMonitorDTO(BaseModel):
    version: str

class UpdateGeneralRoutingDTO(BaseModel):
    routes: Optional[List[RouteV4DTO] | List[RouteV6DTO]] = None
    route_ver: str

class AddableGeneralRoutingDTO(BaseModel):
    route: RouteV4DTO | RouteV6DTO
    route_ver: str
    

class GeneralRouting(db.Model):
    __tablename__ = 'vyos_general_routing'
    
    id = Column(Integer, primary_key=True)
    route_type = Column(String, nullable=True)
    dest_prefix = Column(String, nullable=True)
    nexthop = Column(String, nullable=True)
    distance = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    route_table_id = Column(Integer, nullable=True, default=0)
    vrf = Column(String, nullable=True, default="default")
    __table_args__ = (UniqueConstraint('route_type', 'dest_prefix', 'nexthop', 'interface', 'route_table_id', 'vrf', name='vyos_general_routing_route_type_dest_prefix_nexthop'),)

    def serialize(self):
        return {
            "id": self.id,
            "route_type": self.route_type,
            "dest_prefix": self.dest_prefix,
            "nexthop": self.nexthop,
            "distance": self.distance,
            "interface": self.interface,
            "route_table_id": self.route_table_id,
            "vrf": self.vrf
        }

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        try:
            GeneralRouting.truncate()
            logger.debug("Refresh Routing data")
            logger.debug(data)
            general_routes = parse_route_config(data)
            logger.debug("Parsed general routing: ")
            logger.debug(general_routes)
            
            for item in general_routes:
                new_data = cls(
                    route_type=item.get('route_type'),
                    dest_prefix=item.get('dest_prefix'),
                    nexthop=item.get('nexthop'),
                    distance=item.get('distance'),
                    interface=item.get('interface'),
                    route_table_id=item.get('route_table_id'),
                    vrf=item.get('vrf')
                )
                db.session.add(new_data)
            db.session.commit()
        except Exception as e:
            logger.error("Error refreshing Routing data:")
            logger.error(str(e))
            raise e


class GeneralRoutingV6(db.Model):
    __tablename__ = 'vyos_general_routing_v6'
    
    id = Column(Integer, primary_key=True)
    route_type = Column(String, nullable=True)
    dest_prefix = Column(String, nullable=True)
    nexthop = Column(String, nullable=True)
    distance = Column(String, nullable=True)
    interface = Column(String, nullable=True)
    route_table_id = Column(Integer, nullable=True, default=0)
    vrf = Column(String, nullable=True, default="default")
    __table_args__ = (UniqueConstraint('route_type', 'dest_prefix', 'nexthop', 'interface', 'route_table_id', 'vrf', name='vyos_general_routing_route_type_dest_prefix_nexthop'),)

    def serialize(self):
        return {
            "id": self.id,
            "route_type": self.route_type,
            "dest_prefix": self.dest_prefix,
            "nexthop": self.nexthop,
            "distance": self.distance,
            "interface": self.interface,
            "route_table_id": self.route_table_id,
            "vrf": self.vrf
        }

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data: dict):
        try:
            GeneralRoutingV6.truncate()
            logger.debug("Refresh Routing data")
            logger.debug(data)
            general_routes = parse_route_config_v6(data)
            logger.debug("Parsed general routing: ")
            logger.debug(general_routes)

            for item in general_routes:
                new_data = cls(
                    route_type=item.get('route_type'),
                    dest_prefix=item.get('dest_prefix'),
                    nexthop=item.get('nexthop'),
                    distance=item.get('distance'),
                    interface=item.get('interface'),
                    route_table_id=item.get('route_table_id'),
                    vrf=item.get('vrf')
                )
                db.session.add(new_data)
            db.session.commit()
        except Exception as e:
            logger.error("Error refreshing Routing data:")
            logger.error(str(e))
            raise e



class RouteTable(db.Model):
    __tablename__ = 'vyos_route_table'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=True)

    def serialize(self):
        return {
            "id": self.id,
            "name": self.name
        }


    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()


    @classmethod
    def refresh(cls, data: dict):
        try:
            logger.debug("Refresh Route Table data")
            logger.debug(data)

            RouteTable.truncate()

            for item in data:
                new_data = cls(
                    name=item.get('name')
                )
                db.session.add(new_data)
            db.session.commit()
        except Exception as e:
            logger.error("Error refreshing Route Table data:")
            logger.error(str(e))
            raise e
