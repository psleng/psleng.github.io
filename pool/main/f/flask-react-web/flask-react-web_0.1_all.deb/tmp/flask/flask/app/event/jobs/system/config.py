from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.service.config import refresh_config, refresh_service_stat, init_service_stat
from app.log.logger import logger

   
def fetch_os_config(app_context):
    try:
        os_config = refresh_db_os_config(app_context=app_context)
        return os_config
    except Exception as e:
        logger.error("Fetch OS config failed: ")
        logger.error(str(e))
        return None


def refresh_db_os_config(app_context=None):
    res = api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG)
    config_data = {}
    if res:
        config_data = res

    if app_context is not None:
        with app_context:
            refresh_config(config_data)
    else:
        refresh_config(config_data)

    return config_data


def fetch_init_service_stat(app_context):
    try:
        service_stat = init_db_service_stat(app_context=app_context)
        return service_stat
    except Exception as e:
        logger.error("Fetch service stat failed: ")
        logger.error(str(e))
        return None
    

def fetch_service_stat(app_context):
    try:
        service_stat = refresh_db_service_stat(app_context=app_context)
        return service_stat
    except Exception as e:
        logger.error("Fetch service stat failed: ")
        logger.error(str(e))
        return None


def refresh_db_service_stat(app_context=None):
    dhcp_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_POOL_STATISTICS)
    ntp_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP_SYSTEM)
    firewall_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.FIREWALL_QUERY_GQL)
    
    service_stat = {
        "dhcp": dhcp_stat,
        "ntp": ntp_stat,
        "firewall": firewall_stat
    }

    if app_context is not None:
        with app_context:
            refresh_service_stat(service_stat)
    else:
        refresh_service_stat(service_stat)

    return service_stat


def init_db_service_stat(app_context=None):

    if app_context is not None:
        with app_context:
            init_service_stat()
    else:
        init_service_stat()

    return None
