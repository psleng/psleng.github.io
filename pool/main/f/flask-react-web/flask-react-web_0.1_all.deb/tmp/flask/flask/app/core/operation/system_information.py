import re
from datetime import datetime
import pytz

def parse_datetime(data):
    """Parse date and time from VyOS output."""
    try:
        # VyOS returns date in format: Mon Mar  3 02:04:06 PM EST 2025
        pattern = r'(\w+)\s+(\w+)\s+(\d+)\s+(\d+):(\d+):(\d+)\s+([AP]M)\s+(\w+)\s+(\d{4})'
        match = re.match(pattern, data.strip())
        
        if not match:
            raise ValueError(f"Could not parse datetime string: {data}")
            
        weekday, month, day, hour, minute, second, ampm, tz, year = match.groups()
        
        hour = int(hour)
        if ampm == 'PM' and hour != 12:
            hour += 12
        elif ampm == 'AM' and hour == 12:
            hour = 0
            
        return f"{year}-{datetime.strptime(month, '%b').month:02d}-{int(day):02d}T{hour:02d}:{minute}"
            
    except Exception as e:
        print(f"Error parsing datetime: {str(e)}")
        return ""

def parse_timezone(data):
    try:
        if isinstance(data, dict) and 'time-zone' in data:
            return data['time-zone']
        return ""
    except Exception as e:
        print(f"Error parsing timezone: {str(e)}")
        return ""

def parse_boot_img(text):
    try:
        lines = text.strip().split('\n')
        if len(lines) > 2:
            boot_images = []
            for i in range(2, len(lines)):
                if not lines[i].strip():
                    continue
                
                parts = lines[i].split()
                if len(parts) >= 3:
                    image = {
                        "name": parts[0],
                        "default_boot": parts[1] == "Yes",
                        "running": parts[2] == "Yes"
                    }
                    boot_images.append(image)
                    if image["running"]:
                        return image
                elif len(parts) >= 1:
                    image = {
                        "name": parts[0],
                        "default_boot": False,
                        "running": False
                    }
                    boot_images.append(image)
            
            if boot_images:
                return boot_images[0]
        
        return {
            "name": "",
            "default_boot": False,
            "running": False
        }
    except Exception as e:
        print(f"Error parsing boot image: {str(e)}")
        return {
            "name": "",
            "default_boot": False,
            "running": False
        }

def parse_system_version(text):
    try:
        for line in text.strip().split('\n'):
            if line.startswith('Version:'):
                match = re.search(r'VyOS\s+([^\s]+)', line)
                if match:
                    return match.group(1)
        return ""
    except Exception as e:
        print(f"Error parsing system version: {str(e)}")
        return ""

def parse_commits(text):
    """Parse the commits information."""
    commits = []
    for line in text.strip().split('\n'):
        match = re.match(r'(\d+)\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+by\s+(\w+)\s+via\s+(.+)', line)
        if match:
            commits.append({
                "index": int(match.group(1)),
                "date": match.group(2),
                "user": match.group(3),
                "method": match.group(4)
            })
    return commits

def parse_date(text):
    """ Parse date data """
    return text.split('\n')[0]

def parse_hostname(text):
    """ Parse hostname """
    try:
        return text.split('\n')[0]
    except:
        return ""

def parse_domainname(text):
    """ Parse domain-name """
    try:
        return text.split('\n')[0]
    except:
        return ""

def parse_wireless_country_code(data):
    try:
        return data.get('wireless', {}).get('country-code', "")
    except:
        return ""