import pytest
import json

test_case_valid = [
    pytest.param(
        {
            "valid_json": json.dumps({
                "firewallv4": {
                    "inbound": [
                        {
                            "rule_number": 1,
                            "action": "accept",
                            "protocol": "tcp",
                            "enabled": True,
                            "log_enabled": False,
                            "firewall_type": "prerouting",
                            "source_address": "192.168.1.1",
                            "source_subnet": "24",
                            "source_port": "80",
                            "destination_address": "10.0.0.1",
                            "destination_port": "443",
                            "interface": "eth0"
                        }
                    ],
                    "outbound": []
                },
                "firewallv6": {
                    "inbound": [],
                    "outbound": []
                }
            })
        },
        id="parse_ipv4_inbound_rule"
    ),
    pytest.param(
        {
            "valid_json": json.dumps({
                "firewallv4": {
                    "inbound": [],
                    "outbound": []
                },
                "firewallv6": {
                    "inbound": [],
                    "outbound": [
                        {
                            "rule_number": 10,
                            "action": "drop",
                            "protocol": "tcp",
                            "enabled": True,
                            "log_enabled": True,
                            "firewall_type": "output",
                            "source_address": "2001:db8::1",
                            "source_port": "80",
                            "destination_address": "2001:db8::2",
                            "destination_port": "8080"
                        }
                    ]
                }
            })
        },
        id="parse_ipv6_outbound_rule"
    ),
    pytest.param(
        {
            "valid_json": json.dumps({
                "firewallv4": {
                    "inbound": [],
                    "outbound": [
                        {
                            "rule_number": 20,
                            "action": "drop",
                            "protocol": "tcp",
                            "enabled": False,
                            "log_enabled": False,
                            "description": "Block SMTP traffic",
                            "firewall_type": "output",
                            "source_address": "192.168.0.1",
                            "source_subnet": "24",
                            "destination_port": "25"
                        }
                    ]
                },
                "firewallv6": {
                    "inbound": [],
                    "outbound": []
                }
            })
        },
        id="parse_ipv4_with_description_disabled"
    )
]

test_case_invalid = [
    pytest.param(
        {
            "invalid_json": json.dumps({
                "firewallv4_invalid": {
                    "inbound": [],
                    "outbound": []
                },
                "firewallv6": {
                    "inbound": [],
                    "outbound": []
                }
            })
        },
        id="invalid_json_1"
    ),
    pytest.param(
        {
            "invalid_json": json.dumps({
                "firewallv4": {
                    "inbound": [],
                    "outbound": []
                },
                "firewallv6_invalid": {
                    "inbound": [],
                    "outbound": []
                }
            })
        },
        id="invalid_json_2"
    )
]

test_case_minimal = [
    pytest.param(
        {
            "minimal_json": json.dumps({
                "firewallv4": {
                    "inbound": [],
                    "outbound": []
                },
                "firewallv6": {
                    "inbound": [],
                    "outbound": []
                }
            })
        },
        id="minimal_json_1"
    )
]

test_case_comparison = [
    pytest.param(
        {
            "current_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "default_action": "accept",
                                "rule": {}
                            }
                        }
                    }
                }
            },
            "new_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "default_action": "accept",
                                "rule": {
                                    "1": {
                                        "action": "accept",
                                        "protocol": "tcp",
                                        "source": {
                                            "address": "192.168.1.1",
                                            "address_mask": "255.255.255.0",
                                            "port": "80"
                                        },
                                        "destination": {
                                            "address": "10.0.0.1",
                                            "port": "443"
                                        },
                                        "inbound_interface": {
                                            "name": "eth0"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_diff": {
                "deleted": {},
                "created": {
                    "firewall": {
                        "ipv4": {
                            "prerouting": {
                                "raw": {
                                    "rule": {
                                        "1": {
                                            "action": "accept",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "192.168.1.1",
                                                "address_mask": "255.255.255.0",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "10.0.0.1",
                                                "port": "443"
                                            },
                                            "inbound_interface": {
                                                "name": "eth0"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="compare_add_rule"
    ),
    pytest.param(
        {
            "current_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "default_action": "accept",
                                "rule": {
                                    "1": {
                                        "action": "accept",
                                        "protocol": "tcp",
                                        "source": {
                                            "address": "192.168.1.1",
                                            "address_mask": "255.255.255.0",
                                            "port": "80"
                                        },
                                        "destination": {
                                            "address": "10.0.0.1",
                                            "port": "443"
                                        },
                                        "inbound_interface": {
                                            "name": "eth0"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "new_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "rule": {}
                            }
                        }
                    }
                }
            },
            "expected_diff": {
                "deleted": {
                    "firewall": {
                        "ipv4": {
                            "prerouting": {
                                "raw": {
                                    "default_action": "accept",
                                    "rule": {
                                        "1": {
                                            "action": "accept",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "192.168.1.1",
                                                "address_mask": "255.255.255.0",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "10.0.0.1",
                                                "port": "443"
                                            },
                                            "inbound_interface": {
                                                "name": "eth0"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "created": {}
            }
        },
        id="compare_delete_rule"
    ),
    pytest.param(
        {
            "current_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "default_action": "accept",
                                "rule": {
                                    "1": {
                                        "action": "accept",
                                        "protocol": "tcp",
                                        "source": {
                                            "address": "192.168.1.1",
                                            "address_mask": "255.255.255.0",
                                            "port": "80"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "new_config": {
                "firewall": {
                    "ipv4": {
                        "prerouting": {
                            "raw": {
                                "default_action": "accept",
                                "rule": {
                                    "1": {
                                        "action": "accept",
                                        "protocol": "tcp",
                                        "source": {
                                            "address": "192.168.1.1",
                                            "address_mask": "255.255.255.0",
                                            "port": "80"
                                        },
                                        "destination": {
                                            "address": "10.0.0.1",
                                            "port": "443"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_diff": {
                "deleted": {},
                "created": {
                    "firewall": {
                        "ipv4": {
                            "prerouting": {
                                "raw": {
                                    "rule": {
                                        "1": {
                                            "destination": {
                                            "address": "10.0.0.1",
                                            "port": "443"
                                        }
                                    }
                                }
                            }
                        }
                    }}
                }
            }
        },
        id="compare_modify_rule"
    )
]
