from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.api.http.http_request import Action
from app.core.network.dns.models import DNSServer, DNSForwarding, DNSDynamicInterface
from app.core.security.models import Firewallv4, Firewallv6, FirewallSettings
from app.core.network.nat.models import NATv4
from app.core.network.dhcp.models import DHCPRelay, DHCPPool, DHCPPoolv6, DHCPListenInterface, DHCPListenInterfacev6
from app.core.network.ntp.models import NTPConfig, NTPAllowClient, NTPPTP, NTPServer
from app.core.models import ServiceState, System, ServiceStatistic
from app.core.network.dns.parser import parse_dns_config, parse_dns_dynamic, parse_dns_servers, parse_dns_forward
from app.core.security.parser.firewall import parse_firewall_config, parse_firewall_operation, parse_firewall_operation_log
from app.core.network.nat.parser import parse_nat_config
from app.core.network.dhcp.parser import parse_dhcp_config, parse_dhcp_relay_config
from app.core.network.ntp.parser import parse_ntp_config
from app.core.api.http.srv.parser import parse_user_config_to_db
from app.core.routing.models import GeneralRouting, GeneralRoutingV6
from app.core.service.country_code import read_country_code
from app.core.models import SystemDefault
from app.log.logger import logger
from app.core.operation.models import UserManagement
from app.core.operation.wireguard.models import WireguardInterfaceConfig
from app.core.operation.openvpn.models import OpenVPNInterfaceConfig


def refresh_config(config):
    if config:
        if 'service' in config:
            if 'dns' in config['service']:
                dns_config = parse_dns_config(config['service']['dns'])
                DNSForwarding.refresh(dns_config.get('forwarding'))
                DNSDynamicInterface.refresh(dns_config.get('dynamic'))
            
            if 'dhcp-server' in config['service']:
                parsed_dhcp_config = parse_dhcp_config({'dhcp': config['service']['dhcp-server']})
                DHCPPool.refresh(parsed_dhcp_config)
                DHCPListenInterface.refresh(parsed_dhcp_config)

                if 'disable' in parsed_dhcp_config['dhcp'] and (
                        parsed_dhcp_config['dhcp']['disable'] == True or parsed_dhcp_config['dhcp']['disable'] == {}):
                    ServiceState.set_state('dhcp_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcp'] and parsed_dhcp_config['dhcp']['disable'] == False) or (
                        'disable' not in parsed_dhcp_config['dhcp']):
                    ServiceState.set_state('dhcp_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcp']:
                    ServiceState.set_state('dhcp_server', "enable")

            if 'dhcpv6-server' in config['service']:
                parsed_dhcp_config = parse_dhcp_config({'dhcpv6': config['service']['dhcpv6-server']})
                DHCPPoolv6.refresh(parsed_dhcp_config)
                DHCPListenInterfacev6.refresh(parsed_dhcp_config)
                if 'disable' in parsed_dhcp_config['dhcpv6'] and (
                        parsed_dhcp_config['dhcpv6']['disable'] == True or parsed_dhcp_config['dhcpv6']['disable'] == {}):
                    ServiceState.set_state('dhcpv6_server', "disable")
                elif ('disable' in parsed_dhcp_config['dhcpv6'] and parsed_dhcp_config['dhcpv6']['disable'] == False):
                    ServiceState.set_state('dhcpv6_server', "enable")
                elif 'disable' not in parsed_dhcp_config['dhcpv6']:
                    ServiceState.set_state('dhcpv6_server', "enable")

            if 'dhcp-relay' in config['service']:
                dhcp_relay_config = parse_dhcp_relay_config(config['service']['dhcp-relay'])
                DHCPRelay.refresh(dhcp_relay_config)
            
            if 'ntp' in config['service']:
                ntp_config = parse_ntp_config(config['service']['ntp'])
                NTPConfig.refresh(ntp_config)
                NTPAllowClient.refresh(ntp_config.get('allow-client'))
                NTPPTP.refresh(ntp_config.get('ptp'))
                NTPServer.refresh(ntp_config.get('server'))


        if 'system' in config:
            if 'name-server' in config['system']:
                name_servers = parse_dns_servers(config['system']['name-server'])
                DNSServer.refresh(name_servers)
            
            if 'login' in config['system']:
                
                users = parse_user_config_to_db(config['system'])
                UserManagement.refresh(users)

        
        if 'firewall' in config:
            firewall_config = parse_firewall_config(config['firewall'])
            Firewallv4.refresh(firewall_config, None)
            Firewallv6.refresh(firewall_config, None)
            # When firewall ipv6 block is enabled, disable all of ipv6 features in all pages.
            System.set_ipv6_status(firewall_config)

        if 'nat' in config:
            nat_config = parse_nat_config(config)
            NATv4.refresh(nat_config)

        if 'protocols' in config:
            GeneralRouting.refresh(config['protocols'])
            GeneralRoutingV6.refresh(config['protocols'])

        if 'interfaces' in config:
            # refresh wifi
            # refresh openvpn
            if 'openvpn' in config['interfaces']:
                logger.debug("Openvpn interface config: ")
                logger.debug(config['interfaces']['openvpn'])
                OpenVPNInterfaceConfig.refresh(config['interfaces']['openvpn'])
            # refresh wireguard
            if 'wireguard' in config['interfaces']:
                logger.debug("Wireguard interface config: ")
                logger.debug(config['interfaces']['wireguard'])
                WireguardInterfaceConfig.refresh(config['interfaces']['wireguard'])


def fetch_os_config(provider, data={"refresh": None}):
    try:
        do_refresh = False
        if data and isinstance(data, dict):
            do_refresh = data.get("refresh", False)
        res = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_ALL_CONFIGS, verify=False)
        config_data = res.json()['data']
        if do_refresh:
            refresh_config(config_data)
        return config_data
    except Exception as e:
        print("Fetch os config exception: ")
        print(str(e))
        return {}

def fetch_country_code(app_context):
    try:
        
        country_codes = read_country_code()
        SystemDefault.refresh(
            {"country_code": country_codes}, 
            app_context
        )

    except Exception as e:
        print("Fetch country code failed: ")
        print(str(e))
        logger.error("Fetch country code failed: ")
        logger.error(str(e))


def refresh_service_stat(stat):
    try:
        stats_to_update = {}

        # DHCP
        dhcp_stats_raw = stat.get('dhcp')
        if isinstance(dhcp_stats_raw, list):
            active_leases = sum(int(p.get('leases', 0)) for p in dhcp_stats_raw)
            available_ips = sum(int(p.get('available', '0')) for p in dhcp_stats_raw)
            stats_to_update['dhcp'] = {
                'active_lease': active_leases,
                'available_ips': available_ips
            }

        # NTP
        ntp_stats_raw = stat.get('ntp')
        if isinstance(ntp_stats_raw, dict):
            stratum = ntp_stats_raw.get('stratum', 0)
            offset_val = ntp_stats_raw.get('last_offset', 0.0)
            offset = f"{offset_val} ms"
            stats_to_update['ntp'] = {
                'stratum': stratum,
                'offset': offset
            }

        # Firewall
        firewall_stats_raw = stat.get('firewall')
        if isinstance(firewall_stats_raw, list):
            accepted_rules = 0
            dropped_rules = 0
            for rule in firewall_stats_raw:
                try:
                    action = rule.get('config', {}).get('action')
                    if action == 'accept':
                        accepted_rules += 1
                    elif action == 'drop':
                        dropped_rules += 1
                except (ValueError, TypeError):
                    continue
            stats_to_update['firewall'] = {
                'accepted': accepted_rules,
                'dropped': dropped_rules,
                'total': accepted_rules + dropped_rules
            }
        
        if stats_to_update:
            ServiceStatistic.refresh_stats(stats_to_update)
            logger.debug("Service statistics refreshed successfully.")
        else:
            logger.debug("No valid service statistics found to refresh.")

    except Exception as e:
        logger.debug(f"An error occurred during service stat refresh: {e}")


def init_service_stat():
    try:
        ServiceStatistic.init_stat()
    except Exception as e:
        logger.error("Refresh service stat failed: ")
        logger.error(str(e))
        return None