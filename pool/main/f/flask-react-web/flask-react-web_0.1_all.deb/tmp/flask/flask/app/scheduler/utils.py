import functools
import threading
from logging import getLogger
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = getLogger(__name__)

def run_once(func):
    """
    Decorator to ensure a function is executed only once in multi-threads. 
    """
    func._lock = threading.Lock()
    func._run = False
    func._result = None

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with func._lock:
            # If the function has already run, return the previous result
            if func._run:
                logger.debug(f"Function {func.__name__} already executed. Skipping.")
                return func._result
            
            logger.debug(f"Executing function {func.__name__} for the first time")
            result = func(*args, **kwargs)
            
            # Mark as run and store the result
            func._run = True
            func._result = result
            
            return result
    
    def reset():
        with func._lock:
            func._run = False
            func._result = None
    
    wrapper.reset = reset
    return wrapper

def run_concurrent(max_workers=None):
    """
    Decorator to run functions concurrently using threads.
    Args:
        max_workers: Maximum number of threads to use. None means use default (min(32, os.cpu_count() + 4))
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger.debug(f"Running {func.__name__} concurrently")
            
            # Get the list of jobs to run
            jobs = func(*args, **kwargs)
            if not isinstance(jobs, (list, tuple)):
                logger.warning(f"Function {func.__name__} did not return a list of jobs")
                return jobs

            # Create a thread pool
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all jobs
                future_to_job = {
                    executor.submit(job, *args): job.__name__ 
                    for job in jobs
                }
                
                # Wait for all jobs to complete
                results = []
                for future in as_completed(future_to_job):
                    job_name = future_to_job[future]
                    try:
                        result = future.result()
                        results.append(result)
                        logger.debug(f"Job {job_name} completed successfully")
                    except Exception as e:
                        logger.error(f"Job {job_name} failed with error: {str(e)}")
                
                return results
                
        return wrapper
    return decorator
