from app.log.logger import logger


def parse_to_openvpn_config(data: dict):
    config = {}
    general = data.get('general', {})
    openvpn = data.get('openvpn', {})
    security = data.get('security', {})
    advanced = openvpn.get('advanced', {})
    tls = security.get('tls', {})
    encryption = security.get('encryption', {})
    server = openvpn.get('server', {})

    if 'description' in general:
        config['description'] = general['description']
    if 'deviceType' in openvpn:
        config['device-type'] = openvpn['deviceType']
    if security.get('hash', {}).get('algorithm') is not None:
        config['hash'] = security['hash']['algorithm']
    if 'ipVersion' in advanced:
        config['ip-version'] = advanced['ipVersion']

    if 'keepAlive' in advanced:
        config['keep-alive'] = {}
        if 'failureCount' in advanced['keepAlive']:
            config['keep-alive']['failure-count'] = advanced['keepAlive']['failureCount']
        if 'interval' in advanced['keepAlive']:
            config['keep-alive']['interval'] = advanced['keepAlive']['interval']


    if 'localAddress' in openvpn:
        config['local-address'] = {openvpn['localAddress']: {}}

    if 'mode' in general:
        config['mode'] = general['mode']

    if advanced.get('persistentTunnel') is True:
        config['persistent-tunnel'] = {}

    if 'protocol' in openvpn:
        config['protocol'] = openvpn['protocol']

    if 'remoteAddress' in openvpn:
        config['remote-address'] = openvpn['remoteAddress']

    if 'remoteHost' in openvpn:
        config['remote-host'] = openvpn['remoteHost']

    if 'remotePort' in openvpn:
        config['remote-port'] = str(openvpn['remotePort'])

    if server:
        server_config = {}
        if 'clientIpPool' in server:
            server_config['client-ip-pool'] = {
                'start': server['clientIpPool']['start'],
                'stop': server['clientIpPool']['stop'],
                'disabled': server['clientIpPool']['disabled'],
                'subnet-mask': server['clientIpPool']['subnetMask']
            }
        if 'clientIpv6Pool' in server:
            server_config['client-ipv6-pool'] = {
                'base': server['clientIpv6Pool']['base'],
                'disabled': server['clientIpv6Pool']['disabled']
            }
        if 'subnet' in server:
            server_config['subnet'] = server['subnet']
        if 'client' in server and isinstance(server['client'], list):
            server_config['client'] = {}
            for client in server['client']:
                if 'name' in client:
                    _client = {}
                    if 'ip' in client:
                        _client['ip'] = client['ip']
                    if 'pushRoute' in client:
                        _client['push-route'] = client['pushRoute']
                    if 'subnet' in client:
                        _client['subnet'] = client['subnet']
                    server_config['client'].update({client['name']: _client})
        if 'topology' in server:
            server_config['topology'] = server['topology']
        if 'domainName' in server:
            server_config['domain-name'] = server['domainName']
        if 'maxConnections' in server:
            server_config['max-connections'] = server['maxConnections']
        if 'nameServer' in server:
            server_config['name-server'] = server['nameServer']
        if 'pushRoutes' in server:
            server_config['push-route'] = []
            for pushRoute in server['pushRoutes']:
                server_config['push-route'].append(pushRoute)
        if 'rejectUnconfiguredClients' in server:
            server_config['reject-unconfigured-clients'] = {}
        
        if server_config:
            config['server'] = server_config

    if tls:
        tls_config = {}
        if 'caCert' in tls and tls['caCert']:
            tls_config['ca-certificate'] = tls['caCert'][0] if isinstance(tls['caCert'], list) else tls['caCert']
        if 'certificate' in tls and tls['certificate']:
            tls_config['certificate'] = tls['certificate'][0] if isinstance(tls['certificate'], list) else tls['certificate']
        if tls_config:
            config['tls'] = tls_config

    if encryption:
        encryption_config = {}
        if 'dataCiphers' in encryption and encryption['dataCiphers']:
            encryption_config['data-ciphers'] = []
            for cipher in encryption['dataCiphers']:
                encryption_config['data-ciphers'].append(cipher)
        if 'cipher' in encryption and encryption['cipher']:
            encryption_config['cipher'] = encryption['cipher']
        if encryption_config:
            config['encryption'] = encryption_config

    if advanced.get('useLzoCompression') is True:
        config['use-lzo-compression'] = {}

    logger.debug("Parsed openvpn config: ")
    logger.debug(config)

    return config

def parse_current_openvpn_interface_config(interface_config: dict, name: str):

    config = {}
    if not interface_config:
        return config
    if not interface_config.get('interfaces', {}):
        return config
    if not interface_config.get('interfaces', {}).get('openvpn', {}):
        return config
    for interface, interface_conf in interface_config.get('interfaces', {}).get('openvpn', {}).items():
        if interface == name:
            config = interface_conf
            break
    return config