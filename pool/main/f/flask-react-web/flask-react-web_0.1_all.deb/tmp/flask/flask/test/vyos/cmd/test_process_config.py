import unittest
import os
from app.core.utils.process_config import process_commands, normalize_key, denormalize_key

class TestProcessConfig(unittest.TestCase):
    def test_normalize_key(self):
        """Test key normalization function"""
        self.assertEqual(normalize_key("allow-from"), "allow_from")
        self.assertEqual(normalize_key("cache-size"), "cache_size")
        self.assertEqual(normalize_key("already_normalized"), "already_normalized")
        self.assertEqual(normalize_key("multiple-dashes-here"), "multiple_dashes_here")
        self.assertEqual(normalize_key(""), "")

    def test_denormalize_key(self):
        """Test key denormalization function"""
        self.assertEqual(denormalize_key("allow_from"), "allow-from")
        self.assertEqual(denormalize_key("cache_size"), "cache-size")
        self.assertEqual(denormalize_key("already-normalized"), "already-normalized")
        self.assertEqual(denormalize_key("multiple_underscores_here"), "multiple-underscores-here")
        self.assertEqual(denormalize_key(""), "")

    def test_process_commands(self):
        """Test process_commands function with various command formats"""
        # Test commands
        commands = [
            "service jobs forwarding allow-from 0.0.0.0/0",
            "service jobs forwarding cache-size 10000",
            "service jobs forwarding listen-address 192.168.1.1"
        ]

        # Expected result
        expected = {
            'service': {
                'jobs': {
                    'forwarding': {
                        'allow_from': ['0.0.0.0/0'],
                        'cache_size': 10000,
                        'listen_address': ['192.168.1.1']
                    }
                }
            }
        }

        # Process commands
        result = process_commands(commands)
        self.assertEqual(result, expected)

    def test_process_commands_complex(self):
        """Test process_commands with more complex scenarios"""
        commands = [
            "service jobs forwarding allow-from 0.0.0.0/0",
            "service jobs forwarding allow-from ::1/128",
            "service jobs forwarding cache-size 10000",
            "service jobs forwarding listen-address 192.168.1.1",
            "service jobs forwarding listen-address 192.168.1.2",
            "service jobs forwarding domain example.com name-server 8.8.8.8",
            "service jobs forwarding domain example.com name-server 8.8.4.4"
        ]

        expected = {
            'service': {
                'jobs': {
                    'forwarding': {
                        'allow_from': ['0.0.0.0/0', '::1/128'],
                        'cache_size': 10000,
                        'listen_address': ['192.168.1.1', '192.168.1.2'],
                        'domain': {
                            'example.com': {
                                'name_server': ['8.8.8.8', '8.8.4.4']
                            }
                        }
                    }
                }
            }
        }

        result = process_commands(commands)
        self.assertEqual(result, expected)

    def test_edge_cases(self):
        """Test edge cases and error handling"""
        # Empty command list
        self.assertEqual(process_commands([]), {})

        # Invalid command format
        # with self.assertRaises(Exception) as context:
        #     process_commands(["invalid command format"])
        # self.assertEqual(str(context.exception), "invalid command format")

        # # Invalid templates path
        # with self.assertRaises(Exception) as context:
        #     process_commands(["service jobs forwarding allow-from 0.0.0.0/0"], templates_path="/nonexistent/path/templates.json")
        # self.assertEqual(str(context.exception), "Cannot read templates file")

if __name__ == '__main__':
    unittest.main()
