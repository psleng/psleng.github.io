import pytest

test_firewall_cmd_set = [
    pytest.param(
        ({
            "ipv4": {
                "prerouting": {
                    "raw": {
                        "default_action": "accept",
                        "rule": {
                            "1": {
                                "action": "accept",
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.1.1",
                                    "port": "80"
                                },
                                "destination": {
                                    "address": "10.0.0.1",
                                    "port": "443"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv4 prerouting raw default-action accept",
            "firewall ipv4 prerouting raw rule 1 action accept",
            "firewall ipv4 prerouting raw rule 1 protocol tcp",
            "firewall ipv4 prerouting raw rule 1 source address 192.168.1.1",
            "firewall ipv4 prerouting raw rule 1 source port 80",
            "firewall ipv4 prerouting raw rule 1 destination address 10.0.0.1",
            "firewall ipv4 prerouting raw rule 1 destination port 443",
        ]),
        id="firewall_set_ipv4_rule"
    ),
    pytest.param(
        ({
            "ipv6": {
                "output": {
                    "raw": {
                        "default_action": "accept",
                        "rule": {
                            "10": {
                                "action": "drop",
                                "protocol": "tcp",
                                "source": {
                                    "address": "2001:db8::1",
                                    "port": "80"
                                },
                                "destination": {
                                    "address": "2001:db8::2",
                                    "port": "8080"
                                },
                                "log": {}
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv6 output raw default-action accept",
            "firewall ipv6 output raw rule 10 action drop",
            "firewall ipv6 output raw rule 10 protocol tcp",
            "firewall ipv6 output raw rule 10 source address 2001:db8::1",
            "firewall ipv6 output raw rule 10 source port 80",
            "firewall ipv6 output raw rule 10 destination address 2001:db8::2",
            "firewall ipv6 output raw rule 10 destination port 8080",
            "firewall ipv6 output raw rule 10 log"
        ]),
        id="firewall_set_ipv6_rule"
    ),
    pytest.param(
        ({
            "ipv4": {
                "output": {
                    "raw": {
                        "default_action": "accept",
                        "rule": {
                            "20": {
                                "action": "drop",
                                "protocol": "tcp",
                                "source": {
                                    "address": "192.168.0.1",
                                },
                                "destination": {
                                    "port": "25"
                                },
                                "disable": {},
                                "description": "Block_SMTP_traffic"
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv4 output raw default-action accept",
            "firewall ipv4 output raw rule 20 action drop",
            "firewall ipv4 output raw rule 20 protocol tcp",
            "firewall ipv4 output raw rule 20 source address 192.168.0.1",
            "firewall ipv4 output raw rule 20 destination port 25",
            "firewall ipv4 output raw rule 20 disable",
            "firewall ipv4 output raw rule 20 description Block_SMTP_traffic"
        ]),

        id="firewall_set_with_description_and_disable"
    )
]

# Test data for delete commands
test_firewall_cmd_delete = [
    pytest.param(
        ({
            "ipv4": {
                "prerouting": {
                    "raw": {
                        "rule": {
                            "1": {
                                "action": "reject",
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv4 prerouting raw rule 1 action reject"
        ]),
        id="firewall_delete_ipv4_rule"
    ),
    pytest.param(
        ({
            "ipv4": {
                "prerouting": {
                    "raw": {
                        "rule": {
                            "5": {
                                "source": {
                                    "address": "192.168.1.1"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv4 prerouting raw rule 5 source address 192.168.1.1"
        ]),
        id="firewall_delete_specific_rule_property"
    ),
    pytest.param(
        ({
            "ipv6": {
                "output": {
                    "raw": {
                        "rule": {
                            "10": {
                                "source": {
                                    "address": "2001::1"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "firewall ipv6 output raw rule 10 source address 2001::1"
        ]),
        id="firewall_delete_ipv6_rule"
    )
]

# Test data for process_commands function
test_process_commands = [
    pytest.param(
        ([
            'firewall ipv4 prerouting raw default-action accept',
            'firewall ipv4 prerouting raw rule 1 action accept',
            'firewall ipv4 prerouting raw rule 1 protocol tcp',
            'firewall ipv4 prerouting raw rule 1 source address 192.168.1.1'
        ],
        {
            'firewall': {
                'ipv4': {
                    'prerouting': {
                        'raw': {
                            'default_action': 'accept',
                            'rule': {
                                '1': {
                                    'action': 'accept',
                                    'protocol': 'tcp',
                                    'source': {
                                        'address': '192.168.1.1'
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }),
        id="firewall_process_commands_ipv4"
    ),
    pytest.param(
        ([
            'firewall ipv6 output raw default-action accept',
            'firewall ipv6 output raw rule 10 action drop',
            'firewall ipv6 output raw rule 10 protocol tcp',
            'firewall ipv6 output raw rule 10 log'
        ],
        {
            'firewall': {
                'ipv6': {
                    'output': {
                        'raw': {
                            'default_action': 'accept',
                            'rule': {
                                '10': {
                                    'action': 'drop',
                                    'protocol': 'tcp',
                                    'log': {}
                                }
                            }
                        }
                    }
                }
            }
        }),
        id="firewall_process_commands_ipv6"
    )
]
