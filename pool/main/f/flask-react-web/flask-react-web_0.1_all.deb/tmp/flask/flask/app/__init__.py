from flask import Flask, send_from_directory, request, session as sess, jsonify
from datetime import datetime, timezone
from .auth import auth_bp
from .core import vyos_bp
from .cli import cli_bp
from .event import event_bp
from .config import config_bp, global_config
from flask_cors import CORS
from app.crypto.bcrypt import bcrypt
from app.db import db
from app.scheduler import init_scheduler, schedule_jobs, init_jobs
import os
from dotenv import load_dotenv
from app.config import init_db, load_json_config, init_pages, register_cleanup_before_shutdown
from app.core.api.manager import api_manager
from app.event import celery_init_app
from flask_socketio import SocketIO
import logging
from app.log.logger import logger
from app.socket.socket_manager import socket_manager
from app.auth.pam.otp_store import otp_store
from uuid import uuid4
import sys
import pytz
load_dotenv()

tzone_str = "America/Toronto"
tzone = pytz.timezone(tzone_str)

socket_clients = []

def create_app():
    app = Flask(__name__, static_folder="template/static", template_folder="template")
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0 # no-cache html/css/js files
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')

    CORS(app, supports_credentials=True)

    socketio = SocketIO(app, async_mode=os.environ.get('SOCKETIO_ASYNC_MODE'), cors_allowed_origins="*",
                        manage_session=False, 
                        engineio_logger=False, logger=logging.getLogger(__name__))
    
    
    socket_manager.init_app(app, socketio)

    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_REFRESH_EACH_REQUEST'] = False
    # SQL config
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('SQLALCHEMY_DATABASE_URI')
    app.config['SECRET_KEY'] = os.environ.get('SQLALCHEMY_SECRET_KEY')
    app.config['SECURITY_PASSWORD_SALT'] = os.environ.get('SQLALCHEMY_SECURITY_PASSWORD_SALT')

    db.init_app(app)
        
    # Migrate db
    init_db(app)

    # App config
    # load_json_config()

    bcrypt.init_app(app)

    # VYOS config
    app.config['VYOS_HOSTNAME'] = os.environ.get('VYOS_HOSTNAME')
    app.config['VYOS_APIKEY'] = os.environ.get('VYOS_APIKEY')
    app.config['VYOS_PORT'] = os.environ.get('VYOS_PORT')
    app.config['VYOS_PROTOCOL'] = os.environ.get('VYOS_PROTOCOL')
    app.config['VYOS_VERIFY_SSL'] = os.environ.get('VYOS_VERIFY_SSL')
    # Init API Manager
    app.config['VYOS_BACKEND'] = os.environ.get('VYOS_BACKEND')
    
    api_manager.init_app(app=app, manager_type=app.config['VYOS_BACKEND'])
    print("=== API TYPE === \n", api_manager.get_api_type())
    logger.info("=== API TYPE === \n")
    logger.info(api_manager.get_api_type())
    
    # Scheduler
    scheduler = init_scheduler(app)
    with app.app_context():
        print("App context init")
        print(app.app_context())
        init_jobs(app.app_context())
        schedule_jobs(scheduler, app.app_context())

        scheduler.start()

    # Celery
    app.config['CELERY_BROKER_URL'] = os.environ.get('CELERY_BROKER_URL')
    # app.config['CELERY_BROKER_BACKEND'] = os.environ.get('CELERY_BROKER_BACKEND')
    app.config['CELERY_RESULT_BACKEND'] = os.environ.get('CELERY_RESULT_BACKEND')
    app.config['CELERY_ACCEPT_CONTENT'] = ['json']
    app.config['CELERY_TASK_SERIALIZER'] = 'json'
    app.config['CELERY_TASK_IGNORE_RESULT'] = False

    celery_init_app(app)
    
    # Global Config instance
    global_config.init_app(app)
    global_config.init_scheduler(scheduler)

    # Register API blueprint
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(vyos_bp, url_prefix="/vyos")
    app.register_blueprint(cli_bp, url_prefix="/cli")
    app.register_blueprint(config_bp, url_prefix="/app-config")
    app.register_blueprint(event_bp, url_prefix="/events")

    # Route to serve React frontend
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve(path):
        if path != "" and os.path.exists(app.static_folder + '/' + path):
            return send_from_directory(app.static_folder, path)
        else:
            return send_from_directory(app.template_folder, 'index.html')

    @socketio.on('connect')
    def socket_on_connect(auth):
        print(f"Client connected | SID: {request.sid} | Namespace: {request.namespace}")
        print("Authentication: ", auth)
        logger.info(f"Client connected | SID: {request.sid} | Namespace: {request.namespace} Authentication: {auth}")
        if auth and auth.get('token'):
            socket_manager.register_client(
                request.sid, 
                auth.get('token')
            )
            socket_manager.emit_to_client(
                sid=request.sid, 
                event='SID', 
                data={
                    'message': 'Connected',
                    'SID': request.sid
                }
            )
        else:
            # register guest client:
            socket_manager.register_guest(request.sid )
            socket_manager.emit_to_guest(
                ssid=request.sid, 
                event='SID', 
                data={
                    'message': 'Connected',
                    'SSID': request.sid
                }
            )

    @socketio.on('disconnect')
    def socket_on_disconnect():
        socket_manager.remove_client(request.sid)
        socket_manager.remove_guest(request.sid)

    @socketio.on("topic")
    def topic_handler(json):
        try:
            print("Received emit message")
            print(sess.get('sid'))
            socket_manager.emit_to_client(
                sid=request.sid, 
                event='notification', 
                data={
                    "id": str(uuid4()),
                    "type": "success",
                    "title": "Success",
                    "content": "Notification is successfully registered"
                }
            )
        except Exception as e:
            print('Topic listener error: ', str(e))

    @socketio.on("clientOTP")
    def client_otp_handler(json_data):
        """Handles the OTP submitted by the client via WebSocket."""
        try:
            otp = json_data.get('otp')
            request_id = request.sid

            if otp and request_id:
                otp_store.set_otp(request_id, otp)
            else:
                logger.error(f"OTP or request_id missing in clientOTP handler. SID: {request_id}")

        except Exception as e:
            logger.error(f"Error in client_otp_handler: {e}")

    # Generate pages with config file
    init_pages(app)
    register_cleanup_before_shutdown(app)

    # return app

    @app.before_request
    def check_session_expiry():
        # Exclude the login route from the expiry check to avoid a redirect loop
        if request.endpoint and 'login' in request.endpoint:
            return

        if 'expires_at' in sess:
            expires_at_str = sess['expires_at']
            try:
                expires_at = datetime.fromisoformat(expires_at_str)

                if expires_at.tzinfo is None:
                    expires_at = tzone.localize(expires_at)

                if datetime.now(tzone) > expires_at:
                    sess.clear()
                    logger.info("Session expired. User logged out.")
                    if 'api' in request.url_rule.rule:
                        return jsonify({"message": "Session has expired. Please log in again."}), 401
            except (ValueError, TypeError):
                sess.clear()
                logger.warning("Invalid 'expires_at' in session. Clearing session.")
                if 'api' in request.url_rule.rule:
                    return jsonify({"message": "Invalid session. Please log in again."}), 401



    return app, socketio
