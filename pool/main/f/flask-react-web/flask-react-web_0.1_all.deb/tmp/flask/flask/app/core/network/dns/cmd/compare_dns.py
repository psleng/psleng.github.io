from typing import Dict, List, Optional
from app.core.operation.utils import measure_time
from app.core.network.dns.models import DNSForwardingDTO

@measure_time(log_level='DEBUG')
def compare_dns_forward(new_config: DNSForwardingDTO, current_config: dict) -> dict:
    """
    Compare new DNS forwarding configuration with current configuration and return differences
    
    Args:
        new_config: New DNS forwarding configuration
        current_config: Current DNS forwarding configuration from VyOS
        
    Returns:
        dict: Dictionary containing deleted and created fields
    """
    deleted = {}
    created = {}

    if new_config.cache_size != current_config.get('cache_size'):
        deleted['cache_size'] = current_config.get('cache_size')
        created['cache_size'] = new_config.cache_size
        
    if new_config.negative_ttl != current_config.get('negative_ttl'):
        deleted['negative_ttl'] = current_config.get('negative_ttl')
        created['negative_ttl'] = new_config.negative_ttl
        
    if new_config.ignore_hosts_file != current_config.get('ignore_hosts_file'):
        deleted['ignore_hosts_file'] = current_config.get('ignore_hosts_file')
        created['ignore_hosts_file'] = new_config.ignore_hosts_file
    
    current_allow_from = set(current_config.get('allow_from', []))
    new_allow_from = set(new_config.allow_from)
    if current_allow_from != new_allow_from:
        deleted_allow = list(current_allow_from - new_allow_from)
        created_allow = list(new_allow_from - current_allow_from)
        if deleted_allow:
            deleted['allow_from'] = deleted_allow
        if created_allow:
            created['allow_from'] = created_allow
        
    current_dhcp = set(current_config.get('dhcp_interfaces', []))
    new_dhcp = set(new_config.dhcp_interfaces)
    if current_dhcp != new_dhcp:
        deleted_dhcp = list(current_dhcp - new_dhcp)
        created_dhcp = list(new_dhcp - current_dhcp)
        if deleted_dhcp:
            deleted['dhcp_interfaces'] = deleted_dhcp
        if created_dhcp:
            created['dhcp_interfaces'] = created_dhcp
        
    current_listen = set(current_config.get('listen_addresses', []))
    new_listen = set(new_config.listen_addresses)
    if current_listen != new_listen:
        deleted_listen = list(current_listen - new_listen)
        created_listen = list(new_listen - current_listen)
        if deleted_listen:
            deleted['listen_addresses'] = deleted_listen
        if created_listen:
            created['listen_addresses'] = created_listen
    
    current_domains = {
        domain['name']: set(domain['name_servers'])
        for domain in current_config.get('domains', [])
    }
    new_domains = {
        domain.name: set(domain.name_servers)
        for domain in new_config.domains
    }
    
    deleted_domains = [
        {'name': name, 'name_servers': list(servers)}
        for name, servers in current_domains.items()
        if name not in new_domains
    ]
    
    created_domains = [
        {'name': name, 'name_servers': list(servers)}
        for name, servers in new_domains.items()
        if name not in current_domains
    ]
    
    updated_domains = [
        {'name': name, 'name_servers': list(current_servers)}
        for name, current_servers in current_domains.items()
        if name in new_domains and current_servers != new_domains[name]
    ]
    
    updated_new_domains = [
        {'name': name, 'name_servers': list(new_servers)}
        for name, new_servers in new_domains.items()
        if name in current_domains and current_domains[name] != new_servers
    ]
    
    if deleted_domains or updated_domains:
        deleted['domains'] = deleted_domains + updated_domains
        
    if created_domains or updated_new_domains:
        created['domains'] = created_domains + updated_new_domains
    
    current_name_servers = {
        (server.get('address'), server.get('port'))
        for server in current_config.get('name_servers', [])
    }
    new_name_servers = {
        (server.address, server.port)
        for server in new_config.name_servers
    }
    
    if current_name_servers != new_name_servers:
        deleted_servers = [
            {'address': address, 'port': port}
            for address, port in current_name_servers - new_name_servers
        ]
        created_servers = [
            {'address': address, 'port': port}
            for address, port in new_name_servers - current_name_servers
        ]
        if deleted_servers:
            deleted['name_servers'] = deleted_servers
        if created_servers:
            created['name_servers'] = created_servers
    
    result = {
        'deleted': deleted,
        'created': created
    }
        
    return result

if __name__ == "__main__":
    new_config = DNSForwardingDTO(
        cache_size=100,
        negative_ttl=60,
        ignore_hosts_file=True,
        allow_from=['1.1.1.1', '2.2.2.2'],
        dhcp_interfaces=['eth0', 'eth1'],
        listen_addresses=['eth0', 'eth1'],
        name_servers=[
            {'address': '1.1.1.1', 'port': 53},
            {'address': '2.2.2.2', 'port': 53}
        ],
        domains=[
            {
                'name': 'example.com',
                'name_servers': [            
                    '1.1.1.1'
                ]
            }
        ]
    )

    current_config = {
        'cache_size': 100,
        'negative_ttl': 60,
        'ignore_hosts_file': True,    
        'allow_from': ['1.1.1.1', '2.2.2.2'],
        'dhcp_interfaces': ['eth0', 'eth1'],
        'listen_addresses': ['eth0', 'eth1'],
        'name_servers': [
            {'address': '1.1.1.1', 'port': 53},
            {'address': '2.2.2.2', 'port': 53}
        ],
        'domains': [
            {
                'name': 'example.com',
                'name_servers': [            
                    '1.1.1.1',
                    '2.2.2.2'
                ]
            }
        ]
    }

    result = compare_dns_forward(new_config, current_config)
    print(result)