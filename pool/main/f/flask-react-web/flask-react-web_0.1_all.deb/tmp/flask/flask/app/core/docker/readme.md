## VyOS 1.5-rolling
Script to run VyOS in Docker container

### Build Docker image on Linux
```bash
./build-vyos.sh
```

### Run Docker container
```bash
docker run -d --rm --name vyos --privileged -v /lib/modules:/lib/modules vyos:1.5-rolling /sbin/init
docker exec -it vyos su - vyos
```