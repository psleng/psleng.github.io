import pytest
from app.test.core.base import TestGenerateConfig
from app.core.network.dhcp.command_dhcp import DHCPCommand, DHCPRelayCommand
from app.core.utils.process_config import process_commands

# Import test case data
from app.test.core.network.dhcp.test_cases._test_case_generate_config import (
    test_dhcp_cmd_set,
    test_dhcp_cmd_set_v6,
    test_dhcp_cmd_delete,
    test_process_commands
)

test_set = [
    pytest.param(
        (test_case.values[0], test_case.values[1]),
        id=test_case.id
    ) for test_case in test_dhcp_cmd_set
]

test_set_v6 = [
    pytest.param(
        (test_case.values[0], test_case.values[1]),
        id=test_case.id
    ) for test_case in test_dhcp_cmd_set_v6
]

test_delete = [
    pytest.param(
        (test_case.values[0], test_case.values[1]),
        id=test_case.id
    ) for test_case in test_dhcp_cmd_delete
]

test_process = [
    pytest.param(
        commands, dict_config,
        id=test_case.id
    ) for test_case in test_process_commands
    for commands, dict_config in [test_case.values[0]]
]


class TestDHCPCommand(TestGenerateConfig):
    """Test class for DHCP command generation"""
    __test__ = True

    @pytest.fixture
    def cmd_class(self):
        return DHCPCommand

    @pytest.fixture
    def resource(self):
        return 'dhcp-server'

    @pytest.fixture
    def cmd(self):
        return DHCPCommand()
    
    @pytest.fixture
    def cmd_set(self):
        return DHCPCommand(operator='set')

    @pytest.fixture
    def cmd_set_v6(self):
        return DHCPCommand(operator='set', resource='dhcpv6')
    
    @pytest.fixture
    def cmd_delete(self):
        return DHCPCommand(operator='delete')
    
    def test_dhcp_command_initialization(self, cmd, cmd_class, resource):
        super().test_command_initialization(cmd, cmd_class, resource)
    
    def test_dhcp_command_custom_initialization(self, cmd_class):
        super().test_command_custom_initialization(cmd_class)
    
    @pytest.mark.parametrize("test_data", test_set)
    def test_generate_commands_set(self, cmd_set, test_data):
        super().test_generate_commands_set(cmd_set, test_data)

    @pytest.mark.parametrize("test_data", test_set_v6)
    def test_generate_commands_set_v6(self, cmd_set_v6, test_data):
        super().test_generate_commands_set(cmd_set=cmd_set_v6, test_data=test_data)
    
    @pytest.mark.parametrize("test_data", test_delete)
    def test_generate_commands_delete(self, cmd_delete, test_data):
        super().test_generate_commands_delete(cmd_delete, test_data)
    
    @pytest.mark.parametrize("commands,dict_config", test_process)
    def test_process_commands(self, commands, dict_config):
        """Test process_commands functionality"""
        config = process_commands(commands)
        assert config == dict_config
    
    def test_get_commands_empty(self):
        super().test_get_commands_empty(DHCPCommand)