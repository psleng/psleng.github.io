from app.auth.utils import login_required
from . import cli_bp
from flask import jsonify, request, session, Response
from functools import wraps
from flask_sqlalchemy import SQLAlchemy
from .models import RunCommandDTO
import requests

# Login Route
@cli_bp.route('/run', methods=['POST'])
def login():
    try:
        data = RunCommandDTO.model_validate_json(request.data)
        command = data.command
        return jsonify({'cmd': command}), 200

    except Exception as e:
        print(str(e))
        return jsonify({'message': 'Invalid request'}), 400


TARGET_URL = "http://127.0.0.1:7681"

@cli_bp.route('/shell', methods=['GET', 'POST', 'PUT', 'DELETE'])
@login_required
def cli_proxy():
    target_full_url = f"{TARGET_URL}"

    try:
        resp = requests.request(
            method=request.method,
            url=target_full_url,
            headers={key: value for (key, value) in request.headers if key != 'Host'},
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False
        )

        excluded_headers = ['content-encoding', 'content-length', 'transfer-encoding', 'connection']
        headers = [(name, value) for name, value in resp.raw.headers.items() if name.lower() not in excluded_headers]
        
        return Response(resp.content, resp.status_code, headers)

    except requests.exceptions.RequestException as e:
        return f"Proxy Error: {e}", 500


@cli_bp.route('/shell/token', methods=['GET', 'POST', 'PUT', 'DELETE'])
@login_required
def cli_proxy_token():
    target_full_url = f"{TARGET_URL}/token"

    try:
        resp = requests.request(
            method=request.method,
            url=target_full_url,
            headers={key: value for (key, value) in request.headers if key != 'Host'},
            data=request.get_data(),
            cookies=request.cookies,
            allow_redirects=False
        )

        excluded_headers = ['content-encoding', 'content-length', 'transfer-encoding', 'connection']
        headers = [(name, value) for name, value in resp.raw.headers.items() if name.lower() not in excluded_headers]
        
        return Response(resp.content, resp.status_code, headers)

    except requests.exceptions.RequestException as e:
        return f"Proxy Error: {e}", 500
