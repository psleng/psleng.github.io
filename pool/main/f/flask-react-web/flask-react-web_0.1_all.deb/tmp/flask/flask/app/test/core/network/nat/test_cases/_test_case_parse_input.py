import pytest
import json

test_case_valid = [
    pytest.param(
    (
        {
            "valid_json": json.dumps({
                "source": [
                    {
                        "rule_id": "100",
                        "rule_type": "source",
                        "description": "Source NAT rule",
                        "outbound_interface": "eth1",
                        "protocol": "tcp",
                        "source_address": "192.168.1.0/24",
                        "source_port": "8080",
                        "destination_address": "10.0.0.0/24",
                        "destination_port": "80",
                        "translation_address": "192.168.1.2",
                        "translation_port": "9090"
                    }
                ],
                "destination": [
                    {
                        "rule_id": "200",
                        "rule_type": "destination",
                        "description": "Destination NAT rule",
                        "inbound_interface": "eth0",
                        "protocol": "tcp",
                        "source_address": "0.0.0.0/0",
                        "destination_address": "203.0.113.10",
                        "destination_port": "80",
                        "translation_address": "192.168.1.10",
                        "translation_port": "8080"
                    }
                ]
            })
        }
    ),
    id="valid_json_1"),
    pytest.param(
    {
        "valid_json": json.dumps({
            "source": [
                {
                    "rule_id": "100",
                    "rule_type": "source",
                    "outbound_interface": "eth1",
                    "translation_address": "masquerade"
                }
            ],
            "destination": []
        })
        
    },
    id="valid_json_2")
]

test_case_invalid = [
    pytest.param(
    {
        "invalid_json": json.dumps({
            "input_json": {
                "source": [
                    {
                        "rule_id": "invalid",
                        "outbound_interface": "eth1",
                        "translation_address": "192.168.1.2"
                    }
                ]
            }
        })
    },
    id="invalid_json_1"),
    pytest.param(
    {
        "invalid_json": json.dumps({
            "input_json": {
                "source": [
                    {
                        "rule_id": "100",
                        "outbound_interface": "eth1",
                        "translation_address": "999.999.999.999"
                    }
                ]
            }
        })
    },
    id="invalid_json_2")
]

test_case_minimal = [
    pytest.param(
    {
        "minimal_json": json.dumps({
            "source": [],
            "destination": []
            
        })
    },
    id="minimal_json_1")
]

test_case_comparison = [
    pytest.param(
    {
        "current_config": {
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    }
                }
            }
        },
        "new_config": {
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    },
                    "200": {
                        "outbound-interface": {
                            "name": "eth0"
                        },
                        "translation": {
                            "address": "192.168.1.1"
                        }
                    }
                }
            }
        },
        "expected_diff": {
            "created": {
                "source": {
                    "rule": {
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            },
            "deleted": {}
        }
    },
    id="comparison_1"),
    pytest.param(
    {
        "current_config": {
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    },
                    "200": {
                        "outbound-interface": {
                            "name": "eth0"
                        },
                        "translation": {
                            "address": "192.168.1.1"
                        }
                    }
                }
            }
        },
        "new_config": {
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    }
                }
            }
        },
        "expected_diff": {
            "created": {},
            "deleted": {
                "source": {
                    "rule": {
                        "200": {
                            "outbound-interface": {
                                "name": "eth0"
                            },
                            "translation": {
                                "address": "192.168.1.1"
                            }
                        }
                    }
                }
            }
        }
    },
    id="comparison_2")
]
