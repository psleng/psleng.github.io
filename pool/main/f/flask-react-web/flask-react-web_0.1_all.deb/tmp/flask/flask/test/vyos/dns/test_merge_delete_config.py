import unittest
from app.core.utils.process_config import merge_dicts_delete, normalize_key

class TestMergeDeleteConfig(unittest.TestCase):
    def test_merge_dicts_delete_1(self):
        """Test merge_dicts_delete function with various scenarios"""
        # Test case 1: Delete single value
        dict1 = {'service': {'dns': {'forwarding': {'cache_size': '10000'}}}}
        dict2 = {'service': {'dns': {'forwarding': {'cache_size': '10000'}}}}
        expected = {}
        result = merge_dicts_delete(dict1, dict2)
        self.assertEqual(result, expected)

    def test_merge_dicts_delete_2(self):
        # Test case 2: Delete from multi-value field
        dict1 = {'service': {'dns': {'forwarding': {'listen_address': ['127.0.0.1', '192.168.1.1']}}}}
        dict2 = {'service': {'dns': {'forwarding': {'listen_address': ['127.0.0.1']}}}}
        expected = {
            'service': {
                'dns': {
                    'forwarding': {
                        'listen_address': ['192.168.1.1']
                    }
                }
            }
        }
        result = merge_dicts_delete(dict1, dict2)
        self.assertEqual(result, expected)

    def test_merge_dicts_delete_3(self):
        # Test case 3: Delete entire dictionary
        dict1 = {'service': {'dns': {'forwarding': {'cache_size': '10000', 'listen_address': ['127.0.0.1']}}}}
        dict2 = {'service': {'dns': {'forwarding': 'all'}}}
        expected = {}
        result = merge_dicts_delete(dict1, dict2)
        self.assertEqual(result, expected)

    def test_edge_cases(self):
        """Test edge cases for merge_dicts_delete"""
        # Empty dictionaries
        self.assertEqual(merge_dicts_delete({}, {}), {})
        
        # One empty dictionary
        dict1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0']}}}}
        self.assertEqual(merge_dicts_delete(dict1, {}), dict1)
        self.assertEqual(merge_dicts_delete({}, dict1), {})

        # Delete non-existent key
        dict1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0']}}}}
        dict2 = {'service': {'dns': {'forwarding': {'cache_size': None}}}}
        self.assertEqual(merge_dicts_delete(dict1, dict2), dict1)

        # Delete one key
        dict1 = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0'], 'cache_size': '10000'}}}}
        dict2 = {'service': {'dns': {'forwarding': {'cache_size': '10000'}}}}
        expected = {'service': {'dns': {'forwarding': {'allow_from': ['0.0.0.0/0']}}}}
        self.assertEqual(merge_dicts_delete(dict1, dict2), expected)

if __name__ == '__main__':
    unittest.main()
