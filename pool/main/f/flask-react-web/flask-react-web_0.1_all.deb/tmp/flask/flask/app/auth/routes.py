from . import auth_bp
from flask import jsonify, request, session, Response, current_app, redirect
from functools import wraps
from flask_sqlalchemy import SQLAlchemy
from .models import User, TempUserExpiryTime
from .utils import login_required
import pam
import os
import pexpect
import paramiko
from app.core.utils.check_os import is_linux
from app.socket.socket_manager import socket_manager
from app.auth.pam.otp_store import otp_store
from app.log.logger import logger
from datetime import datetime, timedelta, timezone
import pytz
from app.core.operation.models import UserManagement

tzone_str = "America/Toronto"
tzone = pytz.timezone(tzone_str)

from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET

def authenticate_db(username, password):
    logger.debug(f"Attempting to authenticate user: {username}")
    user = User.query.filter_by(email=username).first()
    if user and user.check_password(password):
        logger.debug(f"User '{username}' found and password verified.")
        expiry_time = TempUserExpiryTime.get_user_expiry(username)
        if expiry_time:
            logger.debug(f"Found custom expiry time for user '{username}': {expiry_time}")
            now = datetime.now(tzone)

            if expiry_time.tzinfo is None:
                expiry_time = tzone.localize(expiry_time)

            if expiry_time > now:
                session.permanent = True
                session['user_id'] = user.id
                session['username'] = user.email
                session['expires_at'] = expiry_time.isoformat()
                # current_app.permanent_session_lifetime = expiry_time - now
                logger.debug(f"Session for '{username}' created with custom expiry: {session['expires_at']}")
                return True
            else:
                logger.debug(f"Custom expiry time for user '{username}' has passed.")
                return False
        else:
            logger.debug(f"No custom expiry time found for user '{username}'. Setting default 8-hour session.")
            session.permanent = True
            session['user_id'] = user.id
            session['username'] = user.email
            expires_at = datetime.now(tzone) + timedelta(hours=8)
            session['expires_at'] = expires_at.isoformat()
            # current_app.permanent_session_lifetime = timedelta(hours=8)
            logger.debug(f"Session for '{username}' created with default expiry: {session['expires_at']}")
            return True
    else:
        logger.debug(f"Authentication failed for user: {username}. User not found or password incorrect.")
    return False


def authenticate_ssh(username, password):
    pam_authenticator = pam.pam()

    if pam_authenticator.authenticate(username=username, password=password):
        session['user_id'] = "ssh_" + username
        session['username'] = username
        return True
    return False

def is_user_in_group(username, groupname):
    """Checks if a user is a member of a specific group.

    Args:
        username (str): The username to check.
        groupname (str): The group name to check for membership.

    Returns:
        bool: True if the user is a member of the group, False otherwise.
    """
    import pwd
    import grp
    try:
        gid = pwd.getpwnam(username).pw_gid
        group_id_list = os.getgrouplist(username, gid)
        user_groups = [grp.getgrgid(g).gr_name for g in group_id_list]
        return groupname in user_groups
    except KeyError:
        return False

def check_permission(username):
    # Check if the user is not in the 'vyattacfg' group
    if not is_user_in_group(username, 'vyattacfg'):
        session['permission'] = "operator"
        db_permission = UserManagement.get_user_permission(username)
        if db_permission:
            session['permission'] = db_permission
    else:
        session['permission'] = "administrator"


def get_server_auth_methods(username):
    """Check available authentication methods for a user on the local SSH server."""
    transport = None
    try:
        transport = paramiko.Transport(('localhost', 22))
        transport.start_client()
        return transport.get_banner(), transport.auth_handler.get_allowed_auths(username)
    except paramiko.SSHException as e:
        logger.error(f"SSH connection error when checking auth methods: {e}")
        return None, []
    finally:
        if transport:
            transport.close()

def login_mfa_paramiko(username, password, request_id):
    logger.debug(f'Starting MFA login for user: {username}')
    client = None
    try:
        if not all([username, password]):
            logger.debug('Username or password not provided.')
            return jsonify({'message': 'Username and password are required.'}), 400

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        # Use a custom handler for interactive authentication
        def auth_handler(title, instructions, prompt_list):
            resp = []
            for pr in prompt_list:
                prompt = pr[0].strip()
                if 'password' in prompt.lower():
                    resp.append(password)
                elif 'otp' in prompt.lower():
                    logger.debug('OTP prompt received. Requesting OTP from client.')
                    socket_manager.emit_to_guest(
                        ssid=request_id,
                        event='clientRequest',
                        data={
                            'action': 'login-mfa-password',
                            'ssid': request_id,
                            'data': prompt
                        }
                    )

                    event = otp_store.request_otp(request_id)
                    logger.debug('Waiting for OTP from client.')
                    is_otp_received = event.wait(timeout=60.0)

                    if not is_otp_received:
                        logger.debug('OTP submission timed out.')
                        raise Exception('OTP submission timed out.')

                    otp = otp_store.get_otp(request_id)
                    if not otp:
                        logger.debug('Failed to retrieve submitted OTP.')
                        raise Exception('Failed to retrieve submitted OTP.')
                    
                    logger.debug('OTP received. Sending OTP to process.')
                    resp.append(otp)
                else:
                    resp.append('')
            return tuple(resp)

        try:
            # If no MFA is required, let users pass
            client.connect(
                'localhost',
                username=username,
                password=password,
                auth_timeout=15,
                allow_agent=False,
                look_for_keys=False
            )
            logger.debug('Password authentication successful. No MFA required.')

        except paramiko.AuthenticationException:
            logger.debug('Password auth failed. Trying keyboard-interactive for MFA.')
            # If password auth fails, it might be because MFA is needed.
            # transport object for the interactive auth.
            try:
                transport = paramiko.Transport(('localhost', 22))
                transport.start_client()
                transport.auth_interactive(username, auth_handler)
                
                # If successful, create a client from the transport
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client._transport = transport
            except paramiko.AuthenticationException as e:
                logger.debug(f'Interactive authentication failed: {e}')
                return jsonify({'message': 'Invalid credentials or OTP.'}), 401
            except Exception as e:
                logger.error(f'An error occurred during interactive authentication: {e}')
                return jsonify({'message': str(e)}), 500

        except Exception as e:
            logger.error(f'An unexpected error occurred during connection: {e}')
            return jsonify({'message': 'An unexpected error occurred.', 'error': str(e)}), 500

        if client.get_transport() and client.get_transport().is_authenticated():
            logger.debug('Authentication successful.')
            check_permission(username)
            session['user_id'] = f"ssh_{username}"
            session['username'] = username
            return jsonify({'message': 'Login successful.'}), 200
        else:
            logger.debug('Authentication failed.')
            return jsonify({'message': 'Invalid username or password.'}), 401

    except paramiko.AuthenticationException:
        logger.debug('Authentication failed.')
        return jsonify({'message': 'Invalid username or password.'}), 401
    except Exception as e:
        logger.debug(f'An unexpected error occurred in login_mfa_paramiko: {e}')
        return jsonify({
            'message': 'An unexpected error occurred during the login process.',
            'error': str(e)
            }), 500
    finally:
        if client:
            client.close()

def login_mfa(username, password, request_id):
    logger.debug(f'Starting MFA login for user: {username}')
    child = None
    try:
        if not all([username, password]):
            logger.debug('Username or password not provided.')
            return jsonify({'message': 'Username and password are required.'}), 400

        logger.debug(f'Spawning sudo login for {username}')
        child = pexpect.spawn(f'sudo login {username}', timeout=20, encoding='utf-8')

        logger.debug('Expecting password prompt.')
        i = child.expect(['Password:', pexpect.EOF, pexpect.TIMEOUT])
        if i != 0:
            logger.debug(f'Failed to get password prompt. Index: {i}, Output: {child.before}')
            return jsonify({
                'message': 'Failed to get password prompt from server.',
                'output': child.before,
                }), 401
        
        logger.debug('Password prompt received. Sending password.')
        child.sendline(password)

        otp_prompt_regex = r'.*OTP.*'
        welcome_regex = r'.*Welcome to.*'
        
        logger.debug('Expecting OTP, Welcome message, or failure.')
        i = child.expect([otp_prompt_regex, 'Authentication failure', welcome_regex, pexpect.EOF, pexpect.TIMEOUT])
        logger.debug(f'Received index: {i}. Output: {child.before}')

        if i == 1:
            logger.debug('Authentication failure after password.')
            return jsonify({'message': 'Invalid username or password.'}), 401
        if i == 2:
            logger.debug('Welcome message received. Login successful.')
            check_permission(username)
            session['user_id'] = f"ssh_{username}"
            session['username'] = username
            return jsonify({'message': 'Login successful.'})
        if i == 0: # OTP prompt
            logger.debug('OTP prompt received. Requesting OTP from client.')
            socket_manager.emit_to_guest(
                ssid=request_id,
                event='clientRequest',
                data={
                    'action': 'login-mfa-password',
                    'ssid': request_id,
                    'data': child.before.strip() + child.after.strip()
                }
            )

            event = otp_store.request_otp(request_id)
            logger.debug('Waiting for OTP from client.')
            is_otp_received = event.wait(timeout=60.0)

            if not is_otp_received:
                logger.debug('OTP submission timed out.')
                child.close()
                return jsonify({
                    'message': 'OTP submission timed out.',
                    'output': child.before,
                    }), 408

            otp = otp_store.get_otp(request_id)
            if not otp:
                logger.debug('Failed to retrieve submitted OTP.')
                child.close()
                return jsonify({
                    'message': 'Failed to retrieve submitted OTP.',
                    'output': child.before,
                    }), 500

            logger.debug('OTP received. Sending OTP to process.')
            child.sendline(otp)
            
            child.sendline('whoami')
            whoami_index = child.expect([username, pexpect.EOF, pexpect.TIMEOUT])
            
            if whoami_index == 0:
                logger.debug(f'whoami command successful. User: {child.before.strip()}')
                session['user_id'] = f"ssh_{username}"
                session['username'] = username
                check_permission(username)
                child.sendline('exit')
                if not child.closed:
                    logger.debug('Closing child process.')
                    child.close()
                return jsonify({'message': 'Login successful'}), 200
            else:
                logger.error(f'whoami command failed. Expected {username} but got something else.')
                child.close()
                return jsonify({'message': 'Login verification failed.'}), 401
        else: # Timeout or other error
            logger.debug('Unexpected response after password.')
            return jsonify({
                'message': 'Server did not request an OTP.',
                'output': child.before,
                }), 401

    except Exception as e:
        logger.debug(f'An unexpected error occurred in login_mfa: {e}')
        if child and not child.closed:
            child.close()
        return jsonify({
            'message': 'An unexpected error occurred during the login process.',
            'error': str(e)
            }), 500

# Login Route
@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data['username']
        password = data['password']
        request_id = data['ssid']

        if authenticate_db(username, password):
            session['permission'] = "administrator"
            db_permission = UserManagement.get_user_permission(username)
            if db_permission:
                session['permission'] = db_permission
            return jsonify({'message': 'Login successful'}), 200
        # elif is_linux() and authenticate_ssh(username, password):
        #     session['username'] = username
        #     check_permission(username)

        #     return jsonify({'message': 'Login successful'}), 200
        elif is_linux():
            return login_mfa(username, password, request_id)
        else:
            return jsonify({'message': 'Invalid credentials'}), 401
    
    except pexpect.exceptions.ExceptionPexpect as e:
        return jsonify({'message': f'An unexpected authentication error occurred: {e}'}), 400

    except Exception as e:
        print(str(e))
        return jsonify({'message': 'Invalid request'}), 400


def authenticate_pam(username, password, service):
    pam_authenticator = pam.pam()
    return pam_authenticator.authenticate(username=username, password=password, service=service)

@auth_bp.route('/saml/enabled', methods=['GET'])
def saml_enabled():
    try:
        res = api_manager.call(
            action=API_ACTION.MONITOR,
            target=API_TARGET.SAML
        )

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        
        provider_name = res.get('name')
        provider_icon = res.get('icon')
        provider_enabled = res.get('enabled', False)

        return jsonify({
            "name": provider_name,
            "icon": provider_icon,
            "enabled": provider_enabled
        }), 200
    except Exception as e:
        logger.error(f"Error checking SAML config: {str(e)}")
        return jsonify({"enabled": False}), 200

@auth_bp.route('/saml', methods=['GET'])
def saml_auth():
    session_token = request.cookies.get('saml_session_token')
    saml_return_url = request.cookies.get('saml_return_url')
    if saml_return_url:
        homepage = saml_return_url
    else:
        homepage = request.url_root.rstrip('/')

    if session_token:
        res = api_manager.call(
            action=API_ACTION.AUTH,
            target=API_TARGET.SAML,
            data={"type": "CHECK_AUTH", "session": session_token}
        )
        if isinstance(res, Exception):
            response = redirect(f"{homepage}?sso_error=1")
            response.delete_cookie("saml_session_token", path="/")
            response.delete_cookie("saml_return_url", path="/")
        elif res.get("auth_status") == "SUCCESS":
            permission = res.get("auth_level")
            user_id = res.get("user_id")

            session['user_id'] = "sso_" + user_id.lower()
            session['permission'] = "administrator" if permission.lower() == "admin" else permission.lower()
            session['username'] = user_id.lower()

            response = redirect(homepage)
            response.delete_cookie("saml_session_token", path="/")
            response.delete_cookie("saml_return_url", path="/")

            return response
        elif res.get("auth_status") == "FAILED":
            response = redirect(f"{homepage}?sso_error=1")
            response.delete_cookie("saml_session_token", path="/")
            response.delete_cookie("saml_return_url", path="/")
        
    
    relay_state = request.base_url
    res = api_manager.call(
        action = API_ACTION.AUTH,
        target = API_TARGET.SAML,
        data={"type": "AUTH", "RelayState": relay_state}
    )

    if isinstance(res, Exception):
        return jsonify({"error": str(res)}), 400

    response = redirect(res.get("sso_url"))
    response.set_cookie(
        'saml_session_token', 
        res.get("session"), 
        httponly=True, 
        secure=False,
        path="/",
        samesite="Lax"
    )

    saml_return_url = request.args.get('saml_return_url')
    response.set_cookie(
        "saml_return_url",
        saml_return_url or "",
        httponly=True,
        secure=False,
        path="/",
        samesite="Lax"
    )

    return response

# Logout Route
@auth_bp.route('/logout', methods=['POST'])
@login_required
def logout():
    try:
        user = session['username']
        session.clear()
        return jsonify({'message': 'Success'}), 200
    except Exception as e:
        return jsonify({'message': 'Invalid request'}), 400


@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        username = data['username']
        password = data['password']

        if User.create_user(username, password):
            return jsonify({'message': 'Success'}), 200
        return jsonify({'message': 'User already existed'}), 400

    except Exception as e:
        return jsonify({'message': str(e)}), 400

@auth_bp.route('profile', methods=['GET'])
@login_required
def get_profile():
    logger.debug("Attempting to get user profile.")
    try:
        user_name = session['username']
        permission = session['permission']
        logger.debug(f"Retrieved from session: user='{user_name}', permission='{permission}'")

        res = {'user': user_name, 'permission': permission}
        logger.debug(f"Initial response object: {res}")

        user = User.is_exist(session['username'])
        if user:
            logger.debug(f"User '{user_name}' exists in the database.")
            user_expiry_time = TempUserExpiryTime.get_user_expiry(user_name)
            if user_expiry_time:
                logger.debug(f"Found expiry time for user_id '{session['user_id']}': {user_expiry_time}")
                res['expires_at'] = user_expiry_time.isoformat()
                res['timezone'] = tzone_str
            else:
                logger.debug(f"No custom expiry time found for user_id '{session['user_id']}'.")
        else:
            logger.debug(f"User '{user_name}' does not exist in the database.")

        logger.debug(f"Final response object: {res}")
        return jsonify(res), 200

    except Exception as e:
        logger.error(f"Error in get_profile: {str(e)}")
        print(str(e))
        return jsonify({'message': 'Invalid request', 'user': None}), 400
