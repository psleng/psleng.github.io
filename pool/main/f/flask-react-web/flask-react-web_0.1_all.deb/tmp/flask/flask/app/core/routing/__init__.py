from flask import Blueprint

routing_bp = Blueprint('routing', __name__)

from . import routes