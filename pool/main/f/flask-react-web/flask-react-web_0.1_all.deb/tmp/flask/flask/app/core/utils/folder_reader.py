import os
import json
from typing import Dict, Any
import sys

def read_folder_structure(path: str) -> Dict[str, Any]:
    """
    Recursively reads a folder structure and returns a dictionary representation.
    
    Args:
        path (str): The path to the root folder
        
    Returns:
        Dict[str, Any]: A dictionary containing the folder structure where:
            - key: folder/file name
            - value: another dictionary for folders, None for files, or the first line of node.def files
    """
    result = {}
    
    if not os.path.exists(path):
        raise FileNotFoundError(f"Path does not exist: {path}")
    
    base_name = os.path.basename(path)
    first_line = ""
    if os.path.isfile(path):
        if base_name == 'node.def':
            try:
                with open(path, 'r') as f:
                    first_line = f.readline().strip()
                    if 'multi:' in first_line.lower():
                        return "multi"
                    return None
            except Exception as e:
                print(f"Error reading node.def file {path}: {str(e)}")
                return None
        return None
    
    try:
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            if os.path.isdir(item_path):
                result[item] = read_folder_structure(item_path)
            else:
                if item == 'node.def':
                    try:
                        with open(item_path, 'r') as f:
                            first_line = f.readline().strip()
                            if 'multi:' in first_line.lower():
                                first_line = "multi"
                        result[item] = first_line
                    except Exception as e:
                        print(f"Error reading node.def file {item_path}: {str(e)}")
                        result[item] = None
                else:
                    result[item] = None
                
        return result
    
    except PermissionError:
        print(f"Permission denied accessing: {path}")
        return {}
    except Exception as e:
        print(f"Error processing {path}: {str(e)}")
        return {}

def print_folder_structure(structure: Dict[str, Any], indent: int = 0) -> None:
    for name, contents in structure.items():
        prefix = "    " * indent
        if contents is None:
            print(f"{prefix} {name}")
        elif isinstance(contents, str):
            print(f"{prefix} {name}: {contents}")
        else:
            print(f"{prefix} {name}")
            print_folder_structure(contents, indent + 1)

def save_to_json(structure: Dict[str, Any], output_file: str) -> None:
    """
    Saves the folder structure to a JSON file.
    """
    try:
        
        if os.path.exists(output_file):
            os.remove(output_file)

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(structure, f, indent=2, ensure_ascii=False)
        print(f"\nStructure saved to: {output_file}")
    
    except Exception as e:
        print(f"Error saving JSON file: {str(e)}")

if __name__ == "__main__":
    
    target_path = "/opt/vyatta/share/vyatta-cfg/templates/"
    output_json = "templates.json"
    
    try:
        folder_structure = read_folder_structure(target_path)
        print("\nFolder Structure:")
        print_folder_structure(folder_structure)
        
        save_to_json(folder_structure, output_json)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)
