import pytest

test_set = [
    pytest.param(
        ({
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "192.168.1.0/24",
                            "port": "8080"
                        },
                        "destination": {
                            "address": "10.0.0.0/24",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.2",
                            "port": "9090"
                        },
                        "description": "Source_NAT_rule"
                    }
                }
            }
        },
        [
            "set nat source rule 100 outbound-interface name eth1",
            "set nat source rule 100 protocol tcp",
            "set nat source rule 100 source address 192.168.1.0/24",
            "set nat source rule 100 source port 8080",
            "set nat source rule 100 destination address 10.0.0.0/24",
            "set nat source rule 100 destination port 80",
            "set nat source rule 100 translation address 192.168.1.2",
            "set nat source rule 100 translation port 9090",
            "set nat source rule 100 description Source_NAT_rule"
        ]),
        id="test_source_nat_set_1"
    ),
    pytest.param(
        ({
            "destination": {
                "rule": {
                    "200": {
                        "inbound-interface": {
                            "name": "eth0"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "0.0.0.0/0"
                        },
                        "destination": {
                            "address": "203.0.113.10",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.10",
                            "port": "8080"
                        },
                        "description": "Destination_NAT_rule"
                    }
                }
            }
        },
        [
            "set nat destination rule 200 inbound-interface name eth0",
            "set nat destination rule 200 protocol tcp",
            "set nat destination rule 200 source address 0.0.0.0/0",
            "set nat destination rule 200 destination address 203.0.113.10",
            "set nat destination rule 200 destination port 80",
            "set nat destination rule 200 translation address 192.168.1.10",
            "set nat destination rule 200 translation port 8080",
            "set nat destination rule 200 description Destination_NAT_rule"
        ]),
        id="test_destination_nat_set_1"
    ),
    pytest.param(
        ({
            "source": {
                "rule": {
                    "300": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    }
                }
            }
        },
        [
            "set nat source rule 300 outbound-interface name eth1",
            "set nat source rule 300 translation address masquerade"
        ]),
        id="test_masquerade_set_1"
    )
]

test_delete = [
    pytest.param(
        ({
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "192.168.1.0/24",
                            "port": "8080"
                        },
                        "destination": {
                            "address": "10.0.0.0/24",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.2",
                            "port": "9090"
                        },
                        "description": "Source_NAT_rule"
                    }
                }
            }
        },
        [
            "delete nat source rule 100 outbound-interface name eth1",
            "delete nat source rule 100 protocol tcp",
            "delete nat source rule 100 source address 192.168.1.0/24",
            "delete nat source rule 100 source port 8080",
            "delete nat source rule 100 destination address 10.0.0.0/24",
            "delete nat source rule 100 destination port 80",
            "delete nat source rule 100 translation address 192.168.1.2",
            "delete nat source rule 100 translation port 9090",
            "delete nat source rule 100 description Source_NAT_rule"
        ]),
        id="test_source_nat_delete_1"
    ),
    pytest.param(
        ({
            "destination": {
                "rule": {
                    "200": {
                        "inbound-interface": {
                            "name": "eth0"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "0.0.0.0/0"
                        },
                        "destination": {
                            "address": "203.0.113.10",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.10",
                            "port": "8080"
                        },
                        "description": "Destination_NAT_rule"
                    }
                }
            }
        },
        [
            "delete nat destination rule 200 inbound-interface name eth0",
            "delete nat destination rule 200 protocol tcp",
            "delete nat destination rule 200 source address 0.0.0.0/0",
            "delete nat destination rule 200 destination address 203.0.113.10",
            "delete nat destination rule 200 destination port 80",
            "delete nat destination rule 200 translation address 192.168.1.10",
            "delete nat destination rule 200 translation port 8080",
            "delete nat destination rule 200 description Destination_NAT_rule"
        ]),
        id="test_destination_nat_delete_1"
    ),
    pytest.param(
        ({
            "source": {
                "rule": {
                    "300": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    }
                }
            }
        },
        [
            "delete nat source rule 300 outbound-interface name eth1",
            "delete nat source rule 300 translation address masquerade"
        ]),
        id="test_masquerade_delete_1"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                "set service nat source rule 10 outbound-interface eth0",
                "set service nat source rule 10 source address 192.168.1.0/24",
                "set service nat source rule 10 translation address masquerade"
            ],
            {
                "service": {
                    "nat": {
                        "source": {
                            "rule": {
                                "10": {
                                    "outbound_interface": "eth0",
                                    "source": {
                                        "address": "192.168.1.0/24"
                                    },
                                    "translation": {
                                        "address": "masquerade"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_source_nat"
    ),
    pytest.param(
        (
            [
                "set service nat destination rule 20 inbound-interface eth1",
                "set service nat destination rule 20 destination address 10.0.0.1",
                "set service nat destination rule 20 destination port 80",
                "set service nat destination rule 20 protocol tcp",
                "set service nat destination rule 20 translation address 192.168.1.100",
                "set service nat destination rule 20 translation port 8080"
            ],
            {
                "service": {
                    "nat": {
                        "destination": {
                            "rule": {
                                "20": {
                                    "inbound_interface": "eth1",
                                    "destination": {
                                        "address": "10.0.0.1",
                                        "port": "80"
                                    },
                                    "protocol": "tcp",
                                    "translation": {
                                        "address": "192.168.1.100",
                                        "port": "8080"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_destination_nat"
    )
]
