"""
Usage:
    python run_tests.py                   # Run all tests
    python run_tests.py -p test/core/network/ntp  # Run tests in specific path
    python run_tests.py -f test_ntp_cmd   # Run specific test file
"""

import os
import sys
import argparse


def find_python_files():
    python_files = []
    for dirpath, dirnames, filenames in os.walk("."):
        for filename in [f for f in filenames if (f.endswith(".py") and f.startswith("test_"))]:
            python_files.append(os.path.join(dirpath, filename))
    return python_files

# Ensure the flask directory is in the Python path
flask_dir = os.path.dirname(os.path.abspath(__file__))
if flask_dir not in sys.path:
    sys.path.insert(0, flask_dir)

def fix_import_path():
    # Prevent circular imports by isolating the Flask import
    # Create a temporary sys.modules entry to prevent circular imports
    # If flask is already imported and it's the local one, temporarily remove it    
    if 'flask' in sys.modules and sys.modules['flask'].__file__ == os.path.join(flask_dir, '__init__.py'):
        del sys.modules['flask']

    for path in sys.path:
        if 'site-packages' in path and path not in sys.path[:3]:
            sys.path.remove(path)
            sys.path.insert(0, path)
            break

def parse_args():
    parser = argparse.ArgumentParser(description='Run tests for Flask-React-Dev project')
    parser.add_argument('-p', '--path', help='Path to test directory or file')
    parser.add_argument('-f', '--file', help='Test file name without .py extension')
    parser.add_argument('-q', '--quiet', action='store_true', help='Run in quiet mode')
    return parser.parse_args()

def main():
    fix_import_path()
    
    import pytest
    
    args = parse_args()
    pytest_args = []
    
    if not args.quiet:
        pytest_args.append('-v')
    
    if args.path:
        pytest_args.append(args.path)
    elif args.file:
        files = find_python_files()
        test_file = f"test_{args.file}.py" if not args.file.startswith('test_') else f"{args.file}.py"
        for file in files:
            if file.split(os.path.sep)[-1] == f"{test_file}":
                pytest_args.append(file)
    else:
        # Default to running all tests
        pytest_args.append('app/test')
    
    pytest_args.extend(['--ignore=run.py', '--ignore=flask/app/__init__.py'])
    
    # Run tests
    exit_code = pytest.main(pytest_args)
    sys.exit(exit_code)

if __name__ == '__main__':
    main()
