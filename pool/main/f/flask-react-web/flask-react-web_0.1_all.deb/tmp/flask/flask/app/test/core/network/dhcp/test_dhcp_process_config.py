import pytest
from app.test.core.network.dhcp.test_cases._test_case_process_config import test_set, test_delete, test_set_delete
from app.test.core.base import TestProcessConfig


class TestDHCPUpdateConfig(TestProcessConfig):
    __test__ = True

    @pytest.mark.parametrize("test_data", test_set)
    def test_merge_dicts_set(self, test_data):
        super().test_merge_dicts_set(test_data)

    @pytest.mark.parametrize("test_data", test_delete)
    def test_merge_dicts_delete(self, test_data):
        super().test_merge_dicts_delete(test_data, aggressive=True)
    
    @pytest.mark.parametrize("test_data", test_set_delete)
    def test_merge_dicts_set_delete(self, test_data):
        super().test_merge_dicts_set_delete(test_data, aggressive=True)
