import pytest

test_set = [
    pytest.param(
        ({
            'server': {
                '0.pool.ntp.org': {
                    'pool': {}
                },
                '1.pool.ntp.org': {
                    'pool': {},
                    'noselect': {}
                },
                '2.pool.ntp.org': {
                    'pool': {}
                },
                '192.168.1.254': {
                    'interleave': {}
                }
            }
        },
        [
            'service ntp server 0.pool.ntp.org pool',
            'service ntp server 1.pool.ntp.org pool',
            'service ntp server 1.pool.ntp.org noselect',
            'service ntp server 2.pool.ntp.org pool',
            'service ntp server 192.168.1.254 interleave'
        ]),
        id="test_server_set_1"
    ),
    pytest.param(
        ({
            'server': {
                '0.pool.ntp.org': {
                    'pool': {}
                },
                '12.pool.ntp.org': {
                    'pool': {},
                    'noselect': {}
                },
                '2.pool.ntp.org': {
                    'pool': {}
                },
                '192.168.1.254': {
                    'interleave': {}
                }
            }
        },
        [
            'service ntp server 0.pool.ntp.org pool',
            'service ntp server 12.pool.ntp.org pool',
            'service ntp server 12.pool.ntp.org noselect',
            'service ntp server 2.pool.ntp.org pool',
            'service ntp server 192.168.1.254 interleave'
        ]),
        id="test_server_set_2"
    ),
    pytest.param(
        ({
            'listen-address': '192.168.1.1'
        },
        [
            'service ntp listen-address 192.168.1.1'
        ]),
        id="test_listen_address_set"
    ),
    pytest.param(
        ({
            'allow-client': {
                'address': ['192.168.1.0/24', '10.0.0.0/24']
            }
        },
        [
            
            'service ntp allow-client address 192.168.1.0/24',
            'service ntp allow-client address 10.0.0.0/24'
        ]),
        id="test_allow_client_set"
    ),
    pytest.param(
        ({
            'interface': 'eth0'
        },
        [
            'service ntp interface eth0'
        ]),
        id="test_interface"
    ),
    pytest.param(
        ({
            'leap-second': 'system'
        },
        [
            'service ntp leap-second system'
        ]),
        id="test_leap_second"
    ),
    pytest.param(
        ({
            'server': {
                'time.nist.gov': {
                    'nts': {}
                }
            }
        },
        [
            'service ntp server time.nist.gov nts'
        ]),
        id="test_nts_option"
    ),
    pytest.param(
        ({
            'ptp': {
                'enabled': {},
                'port': 319,
                'timestamp_interfaces': ['eth0']
            }
        },
        [
            'service ntp ptp port 319',
            'service ntp ptp timestamp interface eth0'   
        ]),
        id="test_ptp"
    ),
    pytest.param(
        ({
            'server': {
                'example.com': {
                    'interleave': {},
                    'noselect': {},
                    'nts': {},
                    'pool': {},
                    'ptp': {}
                }
            },
            'listen-address': '10.0.0.1',
            'allow-client': {
                'address': ['172.16.0.0/24']
            },
            'interface': 'eth1',
            'leap-second': 'ignore',
            'ptp': {
                'port': 320,
                'timestamp-interface': ['eth1', 'eth2']
            }
        },
        [
            'service ntp server example.com interleave',
            'service ntp server example.com noselect',
            'service ntp server example.com nts',
            'service ntp server example.com pool',
            'service ntp server example.com ptp',
            'service ntp listen-address 10.0.0.1',
            'service ntp allow-client address 172.16.0.0/24',
            'service ntp interface eth1',
            'service ntp leap-second ignore',
            'service ntp ptp port 320',
            'service ntp ptp timestamp interface eth1',
            'service ntp ptp timestamp interface eth2'
        ]),
        id="test_all_options"
    )
]

test_delete = [
    pytest.param(
        ({
            'server': {
                'example.com': {
                    'interleave': {},
                    'noselect': {},
                    'nts': {},
                    'pool': {},
                    'ptp': {}
                }
            },
            'listen-address': '10.0.0.1',
            'allow-client': {
                'address': ['172.16.0.0/24']
            },
            'interface': 'eth1',
            'leap-second': 'ignore',
            'ptp': {
                'port': 320,
                'timestamp-interface': ['eth1', 'eth2']
            }
        },
        [
            'service ntp server example.com interleave', 
            'service ntp server example.com noselect', 
            'service ntp server example.com nts', 
            'service ntp server example.com pool', 
            'service ntp server example.com ptp'
        ]
        ),
        id="test_delete_1"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                'service ntp server example.com interleave',
                'service ntp server example.com noselect',
                'service ntp server example.com nts',
                'service ntp server example.com pool',
                'service ntp server example.com ptp',
                'service ntp listen-address 10.0.0.1',
                'service ntp allow-client address 172.16.0.0/24',
                'service ntp interface eth1',
                'service ntp leap-second ignore',
                'service ntp ptp port 320'
            ],
            {
                "service": {
                    "ntp": {
                        'server': {
                            'example.com': {
                                'interleave': {},
                                'noselect': {},
                                'nts': {},
                                'pool': {},
                                'ptp': {}
                            }
                        },
                        'listen_address': ['10.0.0.1'],
                        'allow_client': {
                            'address': ['172.16.0.0/24']
                        },
                        'interface': 'eth1',
                        'leap_second': 'ignore',
                        'ptp': {
                            'port': '320'
                        }
                    }
                }
            }
        ),
        id="test_process_commands_1"
    ),
    pytest.param(
        (
            [
                'service ntp server example.com interleave',
                'service ntp server example.com noselect',
                'service ntp server example.com nts',
                'service ntp server example.com pool',
                'service ntp server example.com ptp',
            ],
            {
                "service": {
                    "ntp": {
                        'server': {
                            'example.com': {
                                'interleave': {},
                                'noselect': {},
                                'nts': {},
                                'pool': {},
                                'ptp': {}
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_commands_2"
    ),
]