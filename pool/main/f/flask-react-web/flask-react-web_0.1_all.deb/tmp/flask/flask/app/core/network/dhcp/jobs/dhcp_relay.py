from logging import getLogger, DEBUG
from app.core.network.dhcp.models import DHCPRelay
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
import pprint
from app.core.network.dhcp.parser import parse_dhcp_relay_config

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_dhcp_relay_job(app_context):
    """Job to fetch DHCP relay information and update the database.
    
    Args:
        app_context: Flask application context
    """
    try:
        refresh_db_dhcp_relay(app_context=app_context)
    except Exception as e:
        print('Error fetch dhcp relay', str(e))


def refresh_db_dhcp_relay(app_context=None):
    try: 
        logger.info("[TASK] Fetch DHCP Relay")
        print("[TASK] Fetch DHCP Relay")
        dhcp_relay_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_RELAY)
        print("Unparsed DHCP Relay config:")
        print(pprint.pformat(dhcp_relay_config, indent=2, width=80))
        parsed_dhcp_relay_config = parse_dhcp_relay_config(dhcp_relay_config)
        print("Parsed DHCP Relay config:")
        print(pprint.pformat(parsed_dhcp_relay_config, indent=2, width=80))
        if app_context is not None:
            with app_context:
                DHCPRelay.refresh(parsed_dhcp_relay_config)
        else:
            DHCPRelay.refresh(parsed_dhcp_relay_config)
        return dhcp_relay_config
    except Exception as e:
        print(str(e))