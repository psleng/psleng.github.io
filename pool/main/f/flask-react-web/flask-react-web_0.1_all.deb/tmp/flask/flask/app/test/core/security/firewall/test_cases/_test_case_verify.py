import pytest

test_verify_success_1 = pytest.param(
    (
        {
            "firewall": {
                "ipv4": {
                    "prerouting": {
                        "raw": {
                            "default-action": "accept",
                            "rule": {
                                "1": {
                                    "action": "accept",
                                    "protocol": "tcp",
                                    "source": {
                                        "address": "192.168.1.1",
                                        "address-mask": "255.255.255.0",
                                        "port": "80"
                                    },
                                    "destination": {
                                        "address": "10.0.0.1",
                                        "port": "443"
                                    },
                                    "inbound-interface": {
                                        "name": "eth0"
                                    }
                                }
                            }
                        }
                    }
                },
                "ipv6": {}
            }
        }
    ),
    id="test_verify_success_1"
)

test_verify_success_2 = pytest.param(
    (
        {
            "firewall": {
                "ipv4": {
                    "prerouting": {
                        "raw": {
                            "default-action": "accept",
                            "rule": {
                                "10": {
                                    "action": "accept",
                                    "protocol": "tcp",
                                    "source": {
                                        "address": "10.10.1.10",
                                        "port": "80"
                                    },
                                    "inbound-interface": {
                                        "name": "eth0"
                                    }
                                }
                            }
                        }
                    }
                },
                "ipv6": {}
            }
        }
    ),
    id="test_verify_success_2"
)

test_verify_success = [
    test_verify_success_1,
    test_verify_success_2
]

test_verify_failed_1 = pytest.param(
    (
        
    ),
    id="test_verify_failed_1"
)

test_verify_failed_2 = pytest.param(
    (
        
    ),
    id="test_verify_failed_2"
)

# Skip the failed verification test cases
test_verify_failed = [
    # test_verify_failed_1,
    # test_verify_failed_2
]