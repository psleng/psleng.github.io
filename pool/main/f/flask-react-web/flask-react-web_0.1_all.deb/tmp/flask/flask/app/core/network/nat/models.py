from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, text
from pydantic import BaseModel, Field
from typing import Optional, Dict, List


def format_description(desc: str) -> str:
    if not desc:
        return ""
    return desc.replace('_', ' ')

class NATPortAddress(BaseModel):
    address: Optional[str] = None
    port: Optional[str] = None

class NATRuleDTO(BaseModel):
    rule_id: str
    description: Optional[str] = None
    outbound_interface: Optional[str] = None  # source NAT
    inbound_interface: Optional[str] = None   # destination NAT
    source: Optional[NATPortAddress] = None
    destination: Optional[NATPortAddress] = None
    translation: Optional[NATPortAddress] = None
    protocol: Optional[str] = None
    exclude: Optional[bool] = False
    disable: Optional[bool] = False

class NATConfigDTO(BaseModel):
    rule_type: str  # 'source' or 'destination'
    rules: Dict[str, NATRuleDTO]

class NATRule(BaseModel):
    inbound_interface: Optional[str] = None
    outbound_interface: Optional[str] = None
    enabled: Optional[bool] = None
    disable: Optional[bool] = None
    exclude: Optional[bool] = None
    description: Optional[str] = None
    protocol: Optional[str] = None
    source: Optional[str] = None
    destination: Optional[str] = None
    source_address: Optional[str] = None
    source_subnet: Optional[str] = None
    source_port: Optional[str] = None
    source_mac: Optional[str] = None
    destination_address: Optional[str] = None
    destination_subnet: Optional[str] = None
    destination_port: Optional[str] = None
    destination_mac: Optional[str] = None
    translation_address: Optional[str] = None
    translation_port: Optional[str] = None
    rule_id: Optional[str] = None
    rule_number: Optional[str] = None
    rule_type: str


class NATModel(BaseModel):
    inbound: list[NATRule] = []
    outbound: list[NATRule] = []


class NATDTO(BaseModel):
    source: list[NATRule]
    destination: list[NATRule]


class VerifyNATDTO(BaseModel):
    NATv4: Optional[NATDTO] = None
    NATv6: Optional[NATDTO] = None


class UpdateNATDTO(BaseModel):
    NATv4: Optional[NATDTO] = None
    NATv6: Optional[NATDTO] = None
    
class NATv4(db.Model):

    __tablename__ = 'nat_v4'

    id = Column(Integer, primary_key=True)
    rule_type = Column(String, nullable=False)  # 'source' or 'destination'
    rule_id = Column(String, nullable=False)
    description = Column(String, nullable=True)
    outbound_interface = Column(String, nullable=True)  # source NAT
    inbound_interface = Column(String, nullable=True)   # destination NAT
    source_address = Column(String, nullable=True)
    source_port = Column(String, nullable=True)
    destination_address = Column(String, nullable=True)
    destination_port = Column(String, nullable=True)
    translation_address = Column(String, nullable=True)
    translation_port = Column(String, nullable=True)
    protocol = Column(String, nullable=True)
    exclude = Column(Boolean, default=False)
    disable = Column(Boolean, default=False)

    @classmethod
    def truncate(cls):
        db.session.query(cls).delete()
        db.session.commit()
    
    @classmethod
    def refresh(cls, data):
        """Refresh NAT rules from VyOS data.
        
        Args:
            data: Dictionary containing source and destination NAT rules
            Example format:
            {
                "source": {
                    "rule": {
                        "100": {
                            "description": "Source NAT rule",
                            "destination": {
                                "address": "10.0.0.0",
                                "port": "80"
                            },
                            "exclude": {},
                            "outbound-interface": {
                                "name": "eth1"
                            },
                            "protocol": "tcp",
                            "source": {
                                "address": "192.168.1.0/24",
                                "port": "8080"
                            },
                            "translation": {
                                "address": "192.168.1.2",
                                "port": "9090"
                            }
                        }
                    }
                },
                "destination": {
                    "rule": {
                        "200": {
                            "description": "Destination NAT rule",
                            "destination": {...},
                            "inbound-interface": {...},
                            "protocol": "tcp",
                            "source": {...},
                            "translation": {...}
                        }
                    }
                }
            }
        """
        try:
            cls.truncate()
            
            # Process source NAT rules
            if 'source' in data and 'rule' in data['source']:
                for rule_id, rule in data['source']['rule'].items():
                    new_rule = cls(
                        rule_type='source',
                        rule_id=rule_id,
                        description=rule.get('description', ''),
                        protocol=rule.get('protocol', ''),
                        source_address=rule.get('source', {}).get('address', ''),
                        source_port=rule.get('source', {}).get('port', ''),
                        destination_address=rule.get('destination', {}).get('address', ''),
                        destination_port=rule.get('destination', {}).get('port', ''),
                        translation_address=rule.get('translation', {}).get('address', ''),
                        translation_port=rule.get('translation', {}).get('port', ''),
                        outbound_interface=rule.get('outbound-interface', {}).get('name', ''),
                        disable='disable' in rule,
                        exclude='exclude' in rule
                    )
                    db.session.add(new_rule)

            # Process destination NAT rules
            if 'destination' in data and 'rule' in data['destination']:
                for rule_id, rule in data['destination']['rule'].items():
                    new_rule = cls(
                        rule_type='destination',
                        rule_id=rule_id,
                        description=rule.get('description', ''),
                        protocol=rule.get('protocol', ''),
                        source_address=rule.get('source', {}).get('address', ''),
                        source_port=rule.get('source', {}).get('port', ''),
                        destination_address=rule.get('destination', {}).get('address', ''),
                        destination_port=rule.get('destination', {}).get('port', ''),
                        translation_address=rule.get('translation', {}).get('address', ''),
                        translation_port=rule.get('translation', {}).get('port', ''),
                        inbound_interface=rule.get('inbound-interface', {}).get('name', ''),
                        disable='disable' in rule,
                        exclude='exclude' in rule
                    )
                    db.session.add(new_rule)

            db.session.commit()
        except Exception as e:
            print("Error refreshing NAT:", str(e))
            
    def serialize(self):
        """Serialize NAT rule to dictionary format matching VyOS structure."""
        data = {
            "rule_id": self.rule_id,
            "rule_type": self.rule_type,
            "description": format_description(self.description),
            "protocol": self.protocol,
            "source_address": self.source_address,
            "source_port": self.source_port,
            "destination_address": self.destination_address,
            "destination_port": self.destination_port,
            "translation_address": self.translation_address,
            "translation_port": self.translation_port,
            "exclude": self.exclude,
            "disable": self.disable,
            "outbound_interface": self.outbound_interface,
            "inbound_interface": self.inbound_interface
        }

        return data
