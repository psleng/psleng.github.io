import inspect
import json
from datetime import datetime
from functools import wraps
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def debug_log(f):
    """Decorator that prints function name, input arguments, and output value.

    Args:
        f: The function to be decorated
        
    Returns:
        The decorated function with logging capability
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        func_name = f.__name__
        module_name = f.__module__
        fn = f"{module_name}.{func_name}"
        
        args_repr = [repr(arg) for arg in args]
        kwargs_repr = [f"{k}={repr(v)}" for k, v in kwargs.items()]
        signature = ", ".join(args_repr + kwargs_repr)
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        print(f"[DEBUG] {timestamp} | ENTER {fn} | INPUTS: {signature}")
        logger.debug(f"[DEBUG] {timestamp} | ENTER {fn} | INPUTS: {signature}")
        
        output = f(*args, **kwargs)
        
        try:
            output_repr = json.dumps(output, default=str, indent=2)
        except (TypeError, ValueError, OverflowError):
            output_repr = repr(output)
        
        print(f"[DEBUG] {timestamp} | EXIT {fn} | OUTPUT: {output_repr}")
        logger.debug(f"[DEBUG] {timestamp} | EXIT {fn} | OUTPUT: {output_repr}")
        
        return output
    return decorated_function