from app.event.jobs.interface.fetch_interface import fetch_interface_opr
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET

def create_intf_address_async(data, app_context, token):
    try:
        _status = True
        app_context.push()
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.INTERFACE, data=data)

        for r in res:
            if r.get('success') == False:
                _status = False
                break

        fetch_interface_opr(app_context=app_context)
        if _status is False:
            print("Status is False ", token)

            with app_context:
                msg = {
                    "id": str(uuid4()),
                    "content": "Failed to add interface address",
                    "title": "Error",
                    "type": "error",
                    "page": "config/interface",
                    "operation": "add"
                }
                socket_manager.emit_to_user(user_token=token, event='notification', data=msg)

    except Exception as e:
        print(str(e))
        return False
    

def delete_intf_address_async(data, app_context, token):
    try:
        _status = True
        app_context.push()
        res = api_manager.call(action=API_ACTION.DELETE, target=API_TARGET.INTERFACE_ADDRESS, data=data)
        for r in res:
            if r.get('success') == False:
                _status = False
                break

        fetch_interface_opr(app_context=app_context)
        if _status is False:
            with app_context:
                msg = {
                    "content": "Failed to delete interface address",
                    "title": "Error",
                    "type": "error",
                    "page": "config/interface",
                    "operation": "delete"
                }
                socket_manager.emit_to_user(user_token=token, event='notification', data=msg)

    except Exception as e:
        print(str(e))
        return False
    


def update_intf_async(data, app_context, token):
    try:
        update_status = True
        app_context.push()
        res = api_manager.call(action=API_ACTION.UPDATE, target=API_TARGET.INTERFACE, data=data)
        for r in res:
            if r.get('success') == False:
                update_status = False
                break


        fetch_interface_opr(app_context=app_context)
        if update_status is False:
            with app_context:
                msg = {
                    "content": "Failed to update interface",
                    "title": "Error",
                    "type": "error",
                    "page": "config/interface",
                    "operation": "update"
                }
                socket_manager.emit_to_user(user_token=token, event='notification', data=msg)

    except Exception as e:
        print(str(e))
        return False
    

def update_intf_address_async(data, app_context, token):
    try:
        update_status = True
        app_context.push()
        res = api_manager.call(action=API_ACTION.UPDATE, target=API_TARGET.INTERFACE_ADDRESS, data=data)
        for r in res:
            if r.get('success') == False:
                update_status = False
                break
        fetch_interface_opr(app_context=app_context)
        if update_status is False:
            with app_context:
                msg = {
                    "content": "Failed to update interface address",
                    "title": "Error",
                    "type": "error",
                    "page": "config/interface",
                    "operation": "update"
                }
                socket_manager.emit_to_user(user_token=token, event='notification', data=msg)

    except Exception as e:
        print(str(e))
        return False
    
