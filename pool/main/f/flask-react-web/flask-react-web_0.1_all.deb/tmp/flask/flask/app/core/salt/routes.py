from . import salt_bp
# from app.core.salt.master import MasterCommand
from flask import jsonify
from app.core.salt.master import get_hostname, get_hosttime, get_cpu, get_interfaces, get_memory, get_system_uptime
from logging import getLogger, DEBUG

logger = getLogger(__name__)
logger.setLevel(DEBUG)


@salt_bp.route('/info', methods=['POST'])
def show_salt_info():
    try:

        return jsonify({
            'hostname': get_hostname('hostNameVyOS-1'), 
            'time': get_hosttime('hostNameVyOS-1'), 
            'cpu': get_cpu('hostNameVyOS-1'), 
            'interfaces': get_interfaces('hostNameVyOS-1'), 
            'memory': get_memory('hostNameVyOS-1'), 
            'uptime': get_system_uptime('hostNameVyOS-1')
        }), 200

    except Exception as e:
        return str(e), 400