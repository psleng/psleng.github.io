import json
import re
from datetime import datetime
from app.core.utils.system_time import system_timestamp, system_utc_timestamp
import math
import pytz
from typing import Dict, Any, Optional
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def load_system_cpu_json(txt):
    """
    Load system text to json
    Example:
    Uptime: 2d 3h 6m 49s\n\nLoad averages:\n1  minute:   0.0%\n5  minutes:  0.0%\n15 minutes:  0.0%\n\n
    :param txt:
    :return: json
    """
    timestamp_date, timestamp_hour = system_timestamp()
    utc_timestamp = system_utc_timestamp()
    try:
        data = {}
        uptime_patterns = [
            r'Uptime:\s*(\d+y\s*)?(\d+m\s*)?(\d+w\s*)?(\d+d\s*)?(\d+h\s*)?(\d+m\s*)?(\d+s)?',
            r'Uptime:\s*(\d+m\s*)?(\d+w\s*)?(\d+d\s*)?(\d+h\s*)?(\d+m\s*)?(\d+s)?',
            r'Uptime:\s*(\d+w\s*)?(\d+d\s*)?(\d+h\s*)?(\d+m\s*)?(\d+s)?',
            r'Uptime:\s*(\d+h\s*)?(\d+m\s*)?(\d+s)?',
            r'Uptime:\s*(\d+m\s*)?(\d+s)?',
            r'Uptime:\s*(\d+s)?'
        ]
        
        data = {'uptime': ""}
    
        for pattern in uptime_patterns:
            match = re.search(pattern, txt)
            if match:
                uptime_str = ' '.join([group for group in match.groups() if group is not None])
                data['uptime'] = uptime_str.strip()
                break 

        load_averages = {}
        load_averages_match = re.findall(r'(\d+)\s*minute[s]*:\s*(\d+\.\d+)%', txt)
        for minute, load in load_averages_match:
            load_averages[minute] = float(load)

        data['load_averages'] = load_averages
        data['timestamp'] = [timestamp_date, timestamp_hour]
        data['utc_timestamp'] = utc_timestamp

        return data
    except Exception as e:
        return {
            "uptime": "",
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": utc_timestamp,
            "load_avg": {"1": "", "5": "", "15": ""}
        }

def convert_to_kb(value, unit):
    unit_multipliers = {
        "PB": math.pow(1024, 4),
        "TB": math.pow(1024, 3),
        "GB": math.pow(1024, 2),
        "MB": math.pow(1024, 1),
    }
    if unit in unit_multipliers:
        return value * unit_multipliers[unit]
    else:
        raise ValueError(f"Unsupported unit: {unit}")


def load_system_memory_json(txt):
    """
    Load system memory text to JSON.
    Example:
    Total: 1.94 GB\nFree:  1.33 GB\nUsed:  620.72 MB\n
    or
    Total: 0.001 TB\nFree: 0.0005 TB\nUsed:  512.0 MB\n
    Returns: JSON, values in KB.
    """
    timestamp_date, timestamp_hour = system_timestamp()
    utc_timestamp = system_utc_timestamp()
    data = {"free": 0, "used": 0}
    try:
        pattern = r"Total:\s*([\d\.]+)\s*(PB|TB|GB|MB)\nFree:\s*([\d\.]+)\s*(PB|TB|GB|MB)\nUsed:\s*([\d\.]+)\s*(PB|TB|GB|MB)\n"
        match = re.search(pattern, txt)

        if match:
            total_value = float(match.group(1))
            total_unit = match.group(2)
            free_value = float(match.group(3))
            free_unit = match.group(4)
            used_value = float(match.group(5))
            used_unit = match.group(6)
            
            total_kb = convert_to_kb(total_value, total_unit)
            free_kb = convert_to_kb(free_value, free_unit)
            used_kb = convert_to_kb(used_value, used_unit)

            data['free'] = free_kb
            data['used'] = used_kb

        return {
            "memory": data,
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": utc_timestamp
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return data


def salt_load_system_memory_json(minion, data):
    """
    Load system memory JSON.
    """
    try:
        timestamp_date, timestamp_hour = system_timestamp()
        utc_timestamp = system_utc_timestamp()
        mem_total = data.get(minion).get('MemTotal').get('value')
        mem_free = data.get(minion).get('MemFree').get('value')
        
        return {
            "memory": {"free": int(mem_free), "used": int(mem_total) - int(mem_free)},
            "timestamp": [timestamp_date, timestamp_hour],
            "utc_timestamp": utc_timestamp,
            "data": data
        }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return str(e)


def load_system_memory_linux(total, used):
    timestamp_date, timestamp_hour = system_timestamp()
    utc_timestamp = system_utc_timestamp()
    # Parse total memory output
    total_mem_lines = total.decode().split('\n')
    total_memory = 0
    for line in total_mem_lines:
        if 'Total online memory:' in line:
            total_memory = int(line.split(':')[1].strip()) / (1024)  # Convert to KB
            break
    
    # Parse used memory output
    used_mem_lines = used.decode().split('\n')
    used_memory = 0
    for line in used_mem_lines:
        if line.startswith('Mem:'):
            parts = line.split()
            used_memory = float(parts[2])
            used_memory = used_memory * (1024)  # Used memory in KB
            break
    
    memory = {
        "memory": {
            "used": int(used_memory),
            "free": int(total_memory) - int(used_memory)
        },
        "timestamp": [timestamp_date, timestamp_hour],
        "utc_timestamp": utc_timestamp,
    }

    return memory

if __name__ == "__main__":
    txt = "Uptime: 2d 3h 6m 49s\n\nLoad averages:\n1  minute:   0.0%\n5  minutes:  0.0%\n15 minutes:  0.0%\n\n"
    load_system_cpu_json(txt)

    txt = "Total: 1.94 GB\nFree:  1.33 GB\nUsed:  620.72 MB\n"
    load_system_memory_json(txt)