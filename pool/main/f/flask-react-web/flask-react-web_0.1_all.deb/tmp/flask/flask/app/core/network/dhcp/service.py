import logging
from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_ALL_CONFIGS
from app.core.network.dhcp.parser import parse_dhcp_config, parse_dhcp_stat, parse_dhcp_pool
import pprint
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.network.dhcp.command_dhcp import DHCPCommand, DHCPRelayCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from flask import session
from app.core.network.dhcp.models import DHCPPool, DHCPListenInterface, DHCPRelay, DHCPPoolv6, DHCPListenInterfacev6
from app.core.network.dhcp.parser import parse_dhcp_config, parse_dhcp_relay_config, parse_dhcp
from app.core.models import ServiceState
from app.core.api.http.cmd.command import SHOW_DHCP_CONFIG, SHOW_DHCPV6_CONFIG, SHOW_DHCP_RELAY_CONFIG
from app.log.logger import logger


def fetch_dhcp_relay_config(provider, params=None):
    """Fetch DHCP relay configuration."""
    
    logger.debug("Fetching DHCP relay config...")
    print("Fetching DHCP relay config...")
    data = provider.verify_service.call_get_config("dhcp_relay")
    # dhcp_relay_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DHCP_RELAY_CONFIG, verify=False)
    # data = dhcp_relay_response.json()['data']
    # data = parse_dhcp_relay_config(data)
    # print("Call get config DHCP-relay")
    print(data)
    
    return data


def fetch_dhcp_config(provider, params=None):
    """Fetch DHCP configuration."""
    
    logger.debug("Fetching DHCP config...")
    print("Fetching DHCP config...")
    dhcp_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DHCP_CONFIG, verify=False)
    data = dhcp_response.json()['data']
    parsed_data = parse_dhcp(data)
    
    # print("Call get config DHCP-server")
    # print(parsed_data)
    
    return parsed_data


def fetch_dhcpv6_config(provider, params=None):
    """Fetch DHCPv6 configuration."""
    
    logger.debug("Fetching DHCPv6 config...")
    print("Fetching DHCPv6 config...")
    dhcp_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_DHCPV6_CONFIG, verify=False)
    data = dhcp_response.json()['data']
    parsed_data = parse_dhcp(data)
    
    # print("Call get config DHCPv6-server")
    # print(parsed_data)
    
    return parsed_data

def verify_and_generate_commands(provider, current_dhcp, new_dhcp, diff):
    logger.debug("Current DHCP: ")
    logger.debug(current_dhcp)
    logger.debug("New DHCP: ")
    logger.debug(new_dhcp)
    logger.debug("Diff DHCP: ")
    logger.debug(diff)
    ## Generate set commands
    set_cmds = []
    dhcp_set_cmd = DHCPCommand(operator='set', resource='dhcp')
    set_cmds = dhcp_set_cmd.generate_commands(diff['created'], current_dhcp, new_dhcp)
    sc = dhcp_set_cmd.get_commands()
    print("Set commands: ")
    print(pprint.pformat(sc, indent=2, width=80))
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    ## Generate delete commands
    delete_cmds = []
    dhcp_del_cmd = DHCPCommand(operator='delete', resource='dhcp')
    delete_cmds = dhcp_del_cmd.generate_commands(diff['deleted'], current_dhcp, new_dhcp)
    dc = dhcp_del_cmd.get_commands()
    new_del_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    ## Validate commands
    service = "dhcp_server"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current raw config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_del_configs.get('service', {}).get('dhcp_server', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('service', {}).get('dhcp_server', {}))
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    return {
        "verify": verify,
        "merged_config": merged_config,
        "set_cmds": set_cmds,
        "delete_cmds": delete_cmds
    }


def update_dhcp_config(provider, data):
    """Update DHCP configuration."""
    username = session['username']
    diff = data.get('diff')
    current_dhcp = data.get('current')
    new_dhcp = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    r = []
    _data = verify_and_generate_commands(provider, current_dhcp, new_dhcp, diff)
    verify = _data.get('verify')
    merged_config = _data.get('merged_config')
    set_cmds = _data.get('set_cmds')
    delete_cmds = _data.get('delete_cmds')


    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)


    parse_dhcp_conf = parse_dhcp_config({"dhcp": merged_config})
    print("Parsed DHCP config to update:")
    print(pprint.pformat(parse_dhcp_conf, indent=2, width=80))

    # Update DB

    DHCPListenInterface.refresh(parse_dhcp_conf)
    DHCPPool.refresh(parse_dhcp_conf)
    if 'disable' in parse_dhcp_conf['dhcp'] and (parse_dhcp_conf['dhcp']['disable'] == True or parse_dhcp_conf['dhcp']['disable'] == {}):
        ServiceState.set_state('dhcp_server', "disable")
    elif ('disable' in parse_dhcp_conf['dhcp'] and parse_dhcp_conf['dhcp']['disable'] == False):
        ServiceState.set_state('dhcp_server', "enable")
    elif 'disable' not in parse_dhcp_conf['dhcp']:
        ServiceState.set_state('dhcp_server', "enable")
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update DHCP",
                "content": "DHCP is successfully updated"
            }
    )

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r



def update_dhcpv6_config(provider, data):
    """Update DHCPv6 configuration."""
    username = session['username']
    diff = data.get('diff')
    current_dhcp = data.get('current')
    new_dhcp = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    r = []
    ## Generate set commands
    set_cmds = []
    dhcp_set_cmd = DHCPCommand(operator='set', resource='dhcpv6')
    set_cmds = dhcp_set_cmd.generate_commands(diff['created'], current_dhcp, new_dhcp)
    sc = dhcp_set_cmd.get_commands()
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    ## Generate delete commands
    delete_cmds = []
    dhcp_del_cmd = DHCPCommand(operator='delete', resource='dhcpv6')
    delete_cmds = dhcp_del_cmd.generate_commands(diff['deleted'], current_dhcp, new_dhcp)
    dc = dhcp_del_cmd.get_commands()
    new_del_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    ## Validate commands
    service = "dhcpv6_server"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    merged_del_config = merge_dicts_delete(current_config, new_del_configs.get('service', {}).get('dhcpv6_server', {}))
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('service', {}).get('dhcpv6_server', {}))
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)


    parse_dhcp_conf = parse_dhcp_config({"dhcpv6": merged_config})
    print("Parsed DHCPv6 config to update:")
    print(pprint.pformat(parse_dhcp_conf, indent=2, width=80))

    # Update DB

    DHCPListenInterfacev6.refresh(parse_dhcp_conf)
    DHCPPoolv6.refresh(parse_dhcp_conf)
    if 'disable' in parse_dhcp_conf['dhcpv6'] and (parse_dhcp_conf['dhcpv6']['disable'] == True or parse_dhcp_conf['dhcpv6']['disable'] == {}):
        ServiceState.set_state('dhcpv6_server', "disable")
    elif ('disable' in parse_dhcp_conf['dhcpv6'] and parse_dhcp_conf['dhcpv6']['disable'] == False):
        ServiceState.set_state('dhcpv6_server', "enable")
    elif 'disable' not in parse_dhcp_conf['dhcpv6']:
        ServiceState.set_state('dhcpv6_server', "enable")
    
    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update DHCPv6",
                "content": "DHCPv6 is successfully updated"
            }
    )

    excecuted_cmds = list(set(delete_cmds)) + list(set(set_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r



def verify_dhcp(provider, data):
    
    # del data['ipv6']
    print("Verify DHCP data:", data)
    service = "dhcp_server"
    verify = provider.verify_service.call_verify(service, data)
    # verify = call_verify(service, data)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify

def verify_dhcpv6(provider, data):
    
    print("Verify DHCPv6 data:", data)
    service = "dhcpv6_server"
    verify = provider.verify_service.call_verify(service, data)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify

def fetch_dhcp_statistics(provider, data):
    dhcp_statistics_old = provider.graphql_service.send_request(function_name='ShowPoolStatisticsDhcp', data={"family": "inet"}, verify=False)
    dhcp_statistics = provider.graphql_service.send_request(function_name='ShowServerPoolStatisticsDhcp', data={"family": "inet"}, verify=False) 
    
    if dhcp_statistics_old.status_code == 200:
        dhcp_stat = parse_dhcp_stat(dhcp_statistics_old.json()['data'])
    else:
        dhcp_stat = parse_dhcp_stat(dhcp_statistics.json()['data'])
    
    return dhcp_stat if isinstance(dhcp_stat, list) else []
    

def fetch_dhcp_pool_list(provider, data):
    
    dhcp_pool_list = provider.graphql_service.send_request(function_name='ShowServerLeasesDhcp', data={"family": "inet", "state": "all", "origin": "local"}, verify=False) 
    print("DHCP Pool List: ")
    print(pprint.pformat(dhcp_pool_list.json()['data'], indent=2, width=80)) 
    dhcp_pool = parse_dhcp_pool(dhcp_pool_list.json()['data'])
    return dhcp_pool if isinstance(dhcp_pool, list) else []


def fetch_dhcpv6_statistics(provider, data):
    
    dhcp_statistics_old = provider.graphql_service.send_request(function_name='ShowPoolStatisticsDhcp', data={"family": "inet6"}, verify=False)
    dhcp_statistics = provider.graphql_service.send_request(function_name='ShowServerPoolStatisticsDhcp', data={"family": "inet6"}, verify=False) 
    
    if dhcp_statistics_old.status_code == 200:
        dhcp_stat = parse_dhcp_stat(dhcp_statistics_old.json()['data'])
    else:
        dhcp_stat = parse_dhcp_stat(dhcp_statistics.json()['data'])
    
    return dhcp_stat if isinstance(dhcp_stat, list) else []


def fetch_dhcpv6_pool_list(provider, data):

    dhcp_pool_list = provider.graphql_service.send_request(function_name='ShowServerLeasesDhcp', data={"family": "inet6", "state": "all", "origin": "local"}, verify=False) 
    print("DHCP Pool List: ")
    print(pprint.pformat(dhcp_pool_list.json()['data'], indent=2, width=80)) 
    dhcp_pool = parse_dhcp_pool(dhcp_pool_list.json()['data'])
    return dhcp_pool if isinstance(dhcp_pool, list) else []


def update_dhcp_relay(provider, data):
    """Update DHCP configuration."""
    username = session['username']
    diff = data.get('diff')
    current_dhcp = data.get('current')
    new_dhcp = data.get('new')
    print("Diff data: ")
    print(pprint.pformat(diff, indent=2, width=80))

    print("Current raw config: ")
    print(pprint.pformat(current_dhcp, indent=2, width=80))

    print("New raw config: ")
    print(pprint.pformat(new_dhcp, indent=2, width=80))

    print("Diff raw config: ")
    print(pprint.pformat(diff, indent=2, width=80))
    r = []
    ## Generate set commands
    set_cmds = []
    dhcp_set_cmd = DHCPRelayCommand(operator='set', resource='dhcp')
    set_cmds = dhcp_set_cmd.generate_commands(diff['created'], current_dhcp, new_dhcp)
    sc = dhcp_set_cmd.get_commands()
    new_set_configs = process_commands(sc)
    print("New set configs: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    ## Generate delete commands
    delete_cmds = []
    dhcp_del_cmd = DHCPRelayCommand(operator='delete', resource='dhcp')
    delete_cmds = dhcp_del_cmd.generate_commands(diff['deleted'], current_dhcp, new_dhcp)
    dc = dhcp_del_cmd.get_commands()
    new_del_configs = process_commands(dc)
    print("New delete configs: ")
    print(pprint.pformat(new_del_configs, indent=2, width=80))

    ## Validate commands
    service = "dhcp_relay"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = curr_config if curr_config else {}

    print("Current vyos config: ")
    print(pprint.pformat(current_config, indent=2, width=80))

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs.get('service', {}).get('dhcp_relay', {}))
    
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))

    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)
    
    
    # Update DB
    # print("DHCP relay data:", merged_config)

    parse_dhcp_relay_conf = parse_dhcp_relay_config(merged_config)
    # print("Parsed DHCP relay config:", pprint.pformat(parse_dhcp_relay_conf, indent=2, width=80))

    DHCPRelay.refresh(parse_dhcp_relay_conf)

    # Emit notification
    socket_manager.emit_to_user(
        username, 
        event='notification', 
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update DHCP Relay",
                "content": "DHCP Relay is successfully updated"
            }
    )

    excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r
