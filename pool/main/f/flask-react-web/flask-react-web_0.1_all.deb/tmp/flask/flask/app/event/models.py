from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, text, DateTime
from datetime import datetime

class AsyncJob(db.Model):

    __tablename__ = "event_jobs"

    id = Column(Integer, primary_key=True)
    job_id = Column(String, nullable=False)
    params = Column(String, nullable=True)
    result = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.now())

    @classmethod
    def create(cls, job):
        new_job = AsyncJob(
            job_id=job.get('job_id'),
            params=job.get('params'),
            result=job.get('result')
        )
        db.session.add(new_job)
        db.session.commit()
        return True