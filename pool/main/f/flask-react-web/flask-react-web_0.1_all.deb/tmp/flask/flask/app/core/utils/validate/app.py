import importlib
import importlib.util
from flask import Flask, request
app = Flask(__name__)

linux_root_path = "/usr/libexec/vyos"

location = {
    "service_dns_forwarding": "/conf_mode/service_dns_forwarding.py",
    "service_dns_dynamic": "/conf_mode/service_dns_dynamic.py"
}

funcs = ["get_config", "verify", "generate", "apply"]

def call_get_config(service: str) -> str:
    try:
        # Call the get_config function from linux path
        file_path = linux_root_path + location[service]
        spec = importlib.util.spec_from_file_location(service, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        get_config = getattr(module, "get_config")
        return get_config()
    except Exception as e:
        print(f"Error reading {service}: {str(e)}")
        return ""


def call_verify(service: str, config: str) -> str:
    try:
        # Call the verify function from linux path
        file_path = linux_root_path + location[service]
        spec = importlib.util.spec_from_file_location(service, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        verify = getattr(module, "verify")
        return str(verify(config)), 200
    except Exception as e:
        print(f"Error verify {service}: {str(e)}")
        return str(e), 400


@app.route("/")
def hello():
    return "<h1>Validator!</h1>"


@app.route('/get-config', methods=["POST"])
def get_config():
    try:
        data = request.get_json()
        service = data['service']
        configs = call_get_config(service)
        return configs
    except Exception as e:
        return {}, 200


@app.route('/verify', methods=["POST"])
def verify():
    try:
        data = request.get_json()
        config = data['config']
        service = data['service']
        verify = call_verify(service, config)
        return verify
    except Exception as e:
        print(f"Error verify {service}: {str(e)}")
        return "", 400


if __name__ == "__main__":
    app.run(host='0.0.0.0')