import subprocess
from app.log.logger import logger

def run_linux_cmd(cmd):
    error, output = None, ""
    logger.debug(f"Running linux command: {cmd}")
    try:
        proc = subprocess.Popen(
            cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        output, err = proc.communicate()

        if proc.returncode != 0:
            error = err.strip()
            logger.error(f"Command failed with return code {proc.returncode}: {error}")
        else:
            output = output.strip()
            logger.debug(f"Command executed successfully. Output: {output}")

    except Exception as e:
        error = f"Exception occurred: {str(e)}"
        logger.error(error)
        output = ""

    return output, error