from app.core.api.http.cmd.command import SHOW_FIREWALL_CONFIG, SHOW_FIREWALL_OPR
from app.core.api.http.http_request import Action
from app.core.security.parser.firewall import parse_firewall_config, parse_firewall_operation, parse_firewall_operation_log, parse_firewall_query_gql
import pprint
from flask import jsonify, session
from app.core.security.cmd.command_firewall import FirewallCommand
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.socket.socket_manager import socket_manager
from uuid import uuid4
from app.core.security.models import Firewallv4, Firewallv6, FirewallSettings, FirewallOperation, FirewallOperationLog


def fetch_firewall_opr_graphql(provider, data=None):
    
    firewall_opr = provider.graphql_service.send_request(function_name="ShowStatisticsFirewallQuery", data={}, verify=False)
    return firewall_opr.json()['data']


def fetch_firewall_query_graphql(provider, data=None):
    
    firewall_opr = provider.graphql_service.send_request(function_name="ShowFirewallFirewallQuery", data={}, verify=False)
    parsed_firewall_opr = parse_firewall_query_gql(firewall_opr.json()['data'])
    return parsed_firewall_opr
    

def fetch_firewall_opr(provider, data=None):
    firewall_opr = provider.http_service.send_request(action=Action.SHOW, data=SHOW_FIREWALL_OPR, verify=False)  
    print("Firewall Operation: ")
    print(pprint.pformat(firewall_opr, indent=2, width=80)) 
    opr = parse_firewall_operation(firewall_opr.json()['data'])
    return opr

def fetch_firewall_opr_log(provider, data=None):
    
    firewall_opr_log = provider.graphql_service.send_request(function_name='ShowLog', data={"count": "1000", "reverse": "true"}, verify=False) 
    print("Firewall Operation Log: ")
    print(pprint.pformat(firewall_opr_log, indent=2, width=80)) 
    opr_log = parse_firewall_operation_log(firewall_opr_log.json()['data'])
    return opr_log if isinstance(opr_log, list) else []

def fetch_firewall_config(provider, data=None):
    firewall_config = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_FIREWALL_CONFIG, verify=False)  
    print("Firewall Config: ")
    print(pprint.pformat(firewall_config, indent=2, width=80)) 
    config = parse_firewall_config(firewall_config.json()['data'])
    return config

def update_firewall_zone(provider, data):
    pass

def remove_firewall_rule_cmd(sc, dc):
    print("SC: ")
    print(pprint.pformat(sc, indent=2, width=80))
    print("DC: ")
    print(pprint.pformat(dc, indent=2, width=80))
    return ""

def update_firewall(provider, data):

    username = session['username']
    diff = data.get('diff')
    current_firewall = data.get('current')
    new_firewall = data.get('new')
   # print("Current Firewall data: ")
    #print(pprint.pformat(current_firewall, indent=2, width=80))
   # print("New Firewall data: ")
   # print(pprint.pformat(new_firewall, indent=2, width=80))
    r = []
    cmds = []
    ## Generate set commands
    set_cmds = []
    firewall_set_cmd = FirewallCommand(operator='set')
    set_cmds = firewall_set_cmd.generate_commands(diff['created'], current_firewall, new_firewall)
    sc = firewall_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    ## Generate delete commands
    delete_cmds = []
    firewall_del_cmd = FirewallCommand(operator='delete')
    delete_cmds = firewall_del_cmd.generate_commands(diff['deleted'], current_firewall, new_firewall)
    dc = firewall_del_cmd.get_commands()
    new_del_configs = process_commands(dc)

    ## Validate commands
    service = "firewall"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"firewall": curr_config}

    #print("Current Firewall Config: ")
    #print(pprint.pformat(current_config, indent=2, width=80))

    print("New Firewall SET Config: ")
    print(pprint.pformat(new_set_configs, indent=2, width=80))

    # merged_config = merge_dicts_set(current_config, new_set_configs)
    # merged_del_config = merge_dicts_delete(merged_config, new_del_configs)

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    print("Merged Config: ")
    print(pprint.pformat(merged_config, indent=2, width=80))
    print("Merged Del Config: ")
    print(pprint.pformat(merged_del_config, indent=2, width=80))
    
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config['firewall'])
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))

    
    if str(verify) != "None" and str(verify) != "":
        print("Validation Error: ")
        print(pprint.pformat(verify, indent=2, width=80))
        print("Type of Error: ", type(verify))
        return Exception(verify)

    # Update DB
    if 'firewall' in merged_config:
        print("UPDATE DB AFTER VERIFY: Firewall data:", merged_config['firewall'])
        Firewallv4.refresh(merged_config['firewall'])
        Firewallv6.refresh(merged_config['firewall'])
        FirewallSettings.refresh(merged_config['firewall'])

    # Emit notification
    socket_manager.emit_to_user(
    username, 
    event='notification', 
    data={
            "id": str(uuid4()),
            "type": "ignore",
            "title": "Success: Update Firewall",
            "content": "Firewall is successfully updated"
        }
    )

    excecuted_cmds = list(set(set_cmds)) + list(set(delete_cmds))

    # Make sure all of commands are unique
    cmds = excecuted_cmds
    print("Commands: ")
    print(pprint.pformat(cmds, indent=2, width=80))

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})
    
    return r


def verify_firewall(provider, data):

    # del data['ipv6']
    print("Verify Firewall data:", data)
    service = "firewall"
    verify = provider.verify_service.call_verify(service, data)
    # verify = call_verify(service, data)
    print("Verify: ")
    print(pprint.pformat(verify, indent=2, width=80))
    return verify