from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship

class OpenVPNRemoteHost(db.Model):
    __tablename__ = 'vyos_config_openvpn_remote_host'
    id = Column(Integer, primary_key=True)
    host = Column(String(255), nullable=False)
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False)

    def serialize(self):
        return {'id': self.id, 'host': self.host}

class OpenVPNEncryption(db.Model):
    __tablename__ = 'vyos_config_openvpn_encryption'
    id = Column(Integer, primary_key=True)
    data_ciphers = Column(String(255))
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False, unique=True)

    def serialize(self):
        return {'data_ciphers': self.data_ciphers.split(' ') if self.data_ciphers else []}

class OpenVPNServerClientPushRoute(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_push_route'
    id = Column(Integer, primary_key=True)
    route = Column(String(255), nullable=False)
    client_id = Column(Integer, ForeignKey('vyos_config_openvpn_server_client.id'), nullable=False)

    def serialize(self):
        return self.route

class OpenVPNServerClientSubnet(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_subnet'
    id = Column(Integer, primary_key=True)
    subnet = Column(String(255), nullable=False)
    client_id = Column(Integer, ForeignKey('vyos_config_openvpn_server_client.id'), nullable=False)

    def serialize(self):
        return self.subnet

class OpenVPNServerClient(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client'
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    ip = Column(String(255))
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)
    push_routes = relationship('OpenVPNServerClientPushRoute', backref='client', lazy=True, cascade="all, delete-orphan")
    subnets = relationship('OpenVPNServerClientSubnet', backref='client', lazy=True, cascade="all, delete-orphan")

    def serialize(self):
        return {
            'ip': self.ip,
            'push_routes': [r.serialize() for r in self.push_routes],
            'subnets': [s.serialize() for s in self.subnets]
        }

class OpenVPNServerClientIpPool(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_client_ip_pool'
    id = Column(Integer, primary_key=True)
    start = Column(String(255))
    stop = Column(String(255))
    subnet_mask = Column(String(255))
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False, unique=True)

    def serialize(self):
        return {'start': self.start, 'stop': self.stop, 'subnet_mask': self.subnet_mask}

class OpenVPNServerNameServer(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_name_server'
    id = Column(Integer, primary_key=True)
    address = Column(String(255), nullable=False)
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)

    def serialize(self):
        return self.address

class OpenVPNServerPushRoute(db.Model):
    __tablename__ = 'vyos_config_openvpn_server_push_route'
    id = Column(Integer, primary_key=True)
    route = Column(String(255), nullable=False)
    server_id = Column(Integer, ForeignKey('vyos_config_openvpn_server.id'), nullable=False)

    def serialize(self):
        return self.route

class OpenVPNServer(db.Model):
    __tablename__ = 'vyos_config_openvpn_server'
    id = Column(Integer, primary_key=True)
    subnet = Column(String(255))
    topology = Column(String(50))
    domain_name = Column(String(255))
    max_connections = Column(Integer)
    interface_id = Column(Integer, ForeignKey('vyos_config_openvpn_interface.id'), nullable=False, unique=True)
    clients = relationship('OpenVPNServerClient', backref='server', lazy=True, cascade="all, delete-orphan")
    client_ip_pool = relationship('OpenVPNServerClientIpPool', uselist=False, backref='server', lazy=True, cascade="all, delete-orphan")
    name_servers = relationship('OpenVPNServerNameServer', backref='server', lazy=True, cascade="all, delete-orphan")
    push_routes = relationship('OpenVPNServerPushRoute', backref='server', lazy=True, cascade="all, delete-orphan")

    def serialize(self):
        return {
            'subnet': self.subnet,
            'topology': self.topology,
            'domain_name': self.domain_name,
            'max_connections': self.max_connections,
            'clients': {client.name: client.serialize() for client in self.clients},
            'client_ip_pool': self.client_ip_pool.serialize() if self.client_ip_pool else None,
            'name_servers': [ns.serialize() for ns in self.name_servers],
            'push_routes': [pr.serialize() for pr in self.push_routes]
        }

class OpenVPNInterfaceConfig(db.Model):
    __tablename__ = 'vyos_config_openvpn_interface'

    id = Column(Integer, primary_key=True)
    name = Column(String(255), unique=True, nullable=False)
    description = Column(String(255))
    device_type = Column(String(50))
    hash_algo = Column(String(50))
    ip_version = Column(String(50))
    keep_alive_failure_count = Column(Integer)
    keep_alive_interval = Column(Integer)
    local_address = Column(String(255))
    mode = Column(String(50))
    persistent_tunnel = Column(Boolean, default=False)
    protocol = Column(String(50))
    remote_address = Column(String(255))
    remote_port = Column(Integer)
    tls_ca_certificate = Column(String(255))
    tls_certificate = Column(String(255))
    tls_version_min = Column(String(50))
    use_lzo_compression = Column(Boolean, default=False)

    remote_hosts = relationship('OpenVPNRemoteHost', backref='interface', lazy=True, cascade="all, delete-orphan")
    encryption = relationship('OpenVPNEncryption', uselist=False, backref='interface', lazy=True, cascade="all, delete-orphan")
    server = relationship('OpenVPNServer', uselist=False, backref='interface', lazy=True, cascade="all, delete-orphan")

    @classmethod
    def truncate(cls):
        db.session.query(OpenVPNRemoteHost).delete()
        db.session.query(OpenVPNServerClientPushRoute).delete()
        db.session.query(OpenVPNServerClientSubnet).delete()
        db.session.query(OpenVPNServerClient).delete()
        db.session.query(OpenVPNServerClientIpPool).delete()
        db.session.query(OpenVPNServerNameServer).delete()
        db.session.query(OpenVPNServerPushRoute).delete()
        db.session.query(OpenVPNServer).delete()
        db.session.query(OpenVPNEncryption).delete()
        db.session.query(cls).delete()
        db.session.commit()

    @classmethod
    def refresh(cls, config):
        try:
            cls.truncate()
            for iface_name, iface_config in config.items():
                new_iface = cls(
                    name=iface_name,
                    description=iface_config.get('description'),
                    device_type=iface_config.get('device-type'),
                    hash_algo=iface_config.get('hash'),
                    ip_version=iface_config.get('ip-version'),
                    local_address=next(iter(iface_config.get('local-address', {})), None),
                    mode=iface_config.get('mode'),
                    persistent_tunnel='persistent-tunnel' in iface_config,
                    protocol=iface_config.get('protocol'),
                    remote_address=iface_config.get('remote-address'),
                    remote_port=iface_config.get('remote-port'),
                    use_lzo_compression='use-lzo-compression' in iface_config
                )

                if 'keep-alive' in iface_config:
                    new_iface.keep_alive_failure_count = iface_config['keep-alive'].get('failure-count')
                    new_iface.keep_alive_interval = iface_config['keep-alive'].get('interval')

                if 'tls' in iface_config:
                    new_iface.tls_ca_certificate = iface_config['tls'].get('ca-certificate')
                    new_iface.tls_certificate = iface_config['tls'].get('certificate')
                    new_iface.tls_version_min = iface_config['tls'].get('tls-version-min')

                if 'remote-host' in iface_config:
                    remote_hosts = iface_config['remote-host']
                    if isinstance(remote_hosts, dict):
                        for host in remote_hosts.keys():
                            new_iface.remote_hosts.append(OpenVPNRemoteHost(host=host))
                
                if 'encryption' in iface_config:
                    data_ciphers_list = iface_config['encryption'].get('data-ciphers')
                    data_ciphers_str = ' '.join(data_ciphers_list) if isinstance(data_ciphers_list, list) else data_ciphers_list
                    new_iface.encryption = OpenVPNEncryption(
                        data_ciphers=data_ciphers_str
                    )

                if 'server' in iface_config:
                    server_config = iface_config['server']
                    new_server = OpenVPNServer(
                        subnet=server_config.get('subnet'),
                        topology=server_config.get('topology'),
                        domain_name=server_config.get('domain-name'),
                        max_connections=server_config.get('max-connections')
                    )
                    new_iface.server = new_server

                    if 'client-ip-pool' in server_config:
                        pool_config = server_config['client-ip-pool']
                        new_server.client_ip_pool = OpenVPNServerClientIpPool(
                            start=pool_config.get('start'),
                            stop=pool_config.get('stop'),
                            subnet_mask=pool_config.get('subnet-mask')
                        )

                    if 'name-server' in server_config:
                        ns_config = server_config['name-server']
                        if isinstance(ns_config, str):
                            new_server.name_servers.append(OpenVPNServerNameServer(address=ns_config))
                        elif isinstance(ns_config, dict):
                             for ns in ns_config.keys():
                                new_server.name_servers.append(OpenVPNServerNameServer(address=ns))

                    if 'push-route' in server_config:
                        pr_config = server_config['push-route']
                        if isinstance(pr_config, str):
                            new_server.push_routes.append(OpenVPNServerPushRoute(route=pr_config))
                        elif isinstance(pr_config, dict):
                            for route in pr_config.keys():
                                new_server.push_routes.append(OpenVPNServerPushRoute(route=route))

                    if 'client' in server_config:
                        for client_name, client_config in server_config['client'].items():
                            new_client = OpenVPNServerClient(
                                name=client_name,
                                ip=client_config.get('ip')
                            )
                            new_server.clients.append(new_client)

                            if 'push-route' in client_config:
                                cr_config = client_config['push-route']
                                if isinstance(cr_config, str):
                                    new_client.push_routes.append(OpenVPNServerClientPushRoute(route=cr_config))
                                elif isinstance(cr_config, dict):
                                    for route in cr_config.keys():
                                        new_client.push_routes.append(OpenVPNServerClientPushRoute(route=route))
                            
                            if 'subnet' in client_config:
                                cs_config = client_config['subnet']
                                if isinstance(cs_config, str):
                                    new_client.subnets.append(OpenVPNServerClientSubnet(subnet=cs_config))
                                elif isinstance(cs_config, dict):
                                    for subnet in cs_config.keys():
                                        new_client.subnets.append(OpenVPNServerClientSubnet(subnet=subnet))

                db.session.add(new_iface)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            print(f"Error refreshing OpenVPN interface data: {e}")
            raise e

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'device_type': self.device_type,
            'hash_algo': self.hash_algo,
            'ip_version': self.ip_version,
            'keep_alive_failure_count': self.keep_alive_failure_count,
            'keep_alive_interval': self.keep_alive_interval,
            'local_address': self.local_address,
            'mode': self.mode,
            'persistent_tunnel': self.persistent_tunnel,
            'protocol': self.protocol,
            'remote_address': self.remote_address,
            'remote_port': self.remote_port,
            'tls_ca_certificate': self.tls_ca_certificate,
            'tls_certificate': self.tls_certificate,
            'tls_version_min': self.tls_version_min,
            'use_lzo_compression': self.use_lzo_compression,
            'remote_hosts': [host.serialize() for host in self.remote_hosts],
            'encryption': self.encryption.serialize() if self.encryption else None,
            'server': self.server.serialize() if self.server else None
        }
