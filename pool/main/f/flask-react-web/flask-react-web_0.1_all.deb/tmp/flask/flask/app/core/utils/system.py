from re import search
from app.core.utils.cpu import get_core_count
from app.core.utils.file import read_file


def get_load_averages():
    """ Returns load averages for 1, 5, and 15 minutes """

    data = read_file("/proc/loadavg")
    matches = search(r"\s*(?P<one>[0-9\.]+)\s+(?P<five>[0-9\.]+)\s+(?P<fifteen>[0-9\.]+)\s*", data)

    core_count = get_core_count()

    res = {}
    res[1]  = float(matches["one"]) / core_count
    res[5]  = float(matches["five"]) / core_count
    res[15] = float(matches["fifteen"]) / core_count

    return res