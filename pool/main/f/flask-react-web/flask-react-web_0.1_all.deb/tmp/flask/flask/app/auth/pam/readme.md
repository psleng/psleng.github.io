### MFA with PAM:

#### Setup Radius server
```bash
Set system login radius server <radius-server-ip>
Set system login radius server <radius-server-ip> key <radius-server-key>
Set system login radius server <radius-server-ip> port <radius-server-port>
Set system login radius server <radius-server-ip> timeout <radius-server-timeout>
```

#### Requirements.txt
```bash
pexpect
```

#### Workflow
0. Users go to /login page, react will register a websoket as guest and get a ssid from flask.
1. User will input username and password, react will send a request to flask with ssid, username and password.
2. Flask will use **pexpect** to spawn a login process and expect the password prompt, in order to call PAM stack.
3. Based on the response from PAM stack (Radius configured), there are three possible responses:
    - (1) Authentication failure
    - (2) Welcome message
    - (3) OTP prompt
4. (1) and (2): Flask will return 401/200 to react, end the request.
5. (3) OTP prompt: Request hang while otp is exchanged. React to Flask using websocket, and Flask to PAM using pexpect with the help of thread event (see **otp_store.py**).
6. If OTP is correct, user will be logged in, otherwise, Flask will return 401 to react, end the request.

### Workflow Diagram

```mermaid
sequenceDiagram
    participant User
    participant ReactFrontend as React Frontend
    participant FlaskBackend as Flask Backend
    participant PAM_OS as PAM/OS
    participant RadiusServer as Radius Server

    User->>ReactFrontend: Navigates to /login
    ReactFrontend->>FlaskBackend: Request WebSocket SSID
    FlaskBackend-->>ReactFrontend: Provides SSID

    User->>ReactFrontend: Enters username & password
    ReactFrontend->>FlaskBackend: POST /login (credentials + SSID)

    FlaskBackend->>PAM_OS: pexpect.spawn('sudo login ...')
    PAM_OS->>FlaskBackend: "Password:"
    FlaskBackend->>PAM_OS: Sends password

    PAM_OS->>RadiusServer: Authentication Request
    RadiusServer-->>PAM_OS: Response

    alt Authentication Failure
        PAM_OS->>FlaskBackend: "Authentication failure"
        FlaskBackend-->>ReactFrontend: 401 Unauthorized
        ReactFrontend-->>User: Shows error message
    else Welcome Message (Login Success)
        PAM_OS->>FlaskBackend: "Welcome to..."
        FlaskBackend-->>ReactFrontend: 200 OK (Login successful)
        ReactFrontend-->>User: Redirects to dashboard
    else OTP Prompt
        PAM_OS->>FlaskBackend: "OTP:"
        FlaskBackend->>ReactFrontend: (via WebSocket) clientRequest 'login-mfa-password'
        ReactFrontend->>User: Shows OTP input field

        User->>ReactFrontend: Enters OTP
        ReactFrontend->>FlaskBackend: (via WebSocket) sendOTP
        FlaskBackend->>PAM_OS: (via pexpect with thread event) Sends OTP

        PAM_OS->>RadiusServer: Verify OTP
        RadiusServer-->>PAM_OS: OTP Response

        alt Correct OTP
            PAM_OS->>FlaskBackend: Shell prompt ($ or #)
            FlaskBackend-->>ReactFrontend: 200 OK (Login successful)
            ReactFrontend-->>User: Redirects to dashboard
        else Incorrect OTP
            PAM_OS->>FlaskBackend: "Authentication failure"
            FlaskBackend-->>ReactFrontend: 401 Unauthorized
            ReactFrontend-->>User: Shows "Invalid OTP"
        end
    end
```

