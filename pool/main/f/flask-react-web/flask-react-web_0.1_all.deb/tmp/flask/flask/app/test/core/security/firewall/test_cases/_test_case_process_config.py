import pytest
import copy

initial_empty_firewall_config = {
    "firewall": {}
}

config_after_set_1 = {
    "firewall": {
        "ipv4": {
            "prerouting": {
                "raw": {
                    "default_action": "accept",
                    "rule": {
                        "10": {
                            "action": "accept",
                            "description": "Allow specific traffic in raw prerouting",
                            "destination": {"address": "192.168.1.100"}
                        }
                    }
                }
            }
        }
    }
}

config_after_set_2 = {
    "firewall": {
        "ipv4": {
            "prerouting": {
                "filter": {
                    "default_action": "drop",
                    "rule": {
                        "10": {
                            "action": "accept",
                            "description": "Allow SSH from trusted_host",
                            "protocol": "tcp",
                            "source": {"address": "10.0.0.5"},
                            "destination": {"port": "22"}
                        },
                        "20": {
                            "action": "accept",
                            "description": "Allow ICMP (ping)",
                            "protocol": "icmp"
                        }
                    }
                }
            }
        }
    }
}

config_after_set_3 = {
    "firewall": {
        "ipv4": {
            "prerouting": {
                "filter": {
                    "default_action": "accept",
                    "rule": {
                        "10": {
                            "action": "drop",
                            "description": "Block traffic",
                            "source": {"address": "192.0.2.0/24"}
                        },
                        "20": {
                            "action": "accept",
                            "description": "Allow established connections",
                            "state": {"established": True, "related": True}
                        }
                    }
                }
            }
        }
    }
}

config_after_set_4 = {
    "firewall": {
        "ipv4": {
            "prerouting": {
                "nat": {
                    "rule": {
                        "10": {
                            "action": "dnat",
                            "description": "Web server traffic",
                            "inbound_interface": "eth0",
                            "protocol": "tcp",
                            "destination": {"address": "203.0.113.10", "port": "80"},
                            "translation": {"address": "192.168.1.100", "port": "8080"}
                        }
                    }
                }
            },
            "postrouting": {
                "nat": {
                    "rule": {
                        "10": {
                            "action": "snat",
                            "description": "NAT for internal network",
                            "outbound_interface": "eth0",
                            "source": {"address": "192.168.1.0/24"},
                            "translation": {"address": "masquerade"}
                        }
                    }
                }
            }
        }
    }
}

config_after_set_5 = {
    "firewall": {
        "ipv6": {
            "prerouting": {
                "filter": {
                    "default_action": "drop",
                    "rule": {
                        "10": {
                            "action": "accept",
                            "description": "Allow HTTP/HTTPS for IPv6",
                            "protocol": "tcp",
                            "destination": {"port": "80,443"}
                        },
                        "20": {
                            "action": "reject",
                            "description": "Reject auth port with logging",
                            "protocol": "tcp",
                            "destination": {"port": "113"},
                            "log": True
                        }
                    }
                }
            }
        }
    }
}

test_set_1 = pytest.param(
    {
        "current_config": copy.deepcopy(initial_empty_firewall_config),
        "set_config": copy.deepcopy(config_after_set_1),
        "delete_config": None,
        "expected_config": copy.deepcopy(config_after_set_1)
    },
    id="set_1_prerouting_raw_from_empty"
)

test_set_2 = pytest.param(
    {
        "current_config": copy.deepcopy(initial_empty_firewall_config),
        "set_config": copy.deepcopy(config_after_set_2),
        "delete_config": None,
        "expected_config": copy.deepcopy(config_after_set_2)
    },
    id="set_2_input_filter_from_empty"
)

test_set_3 = pytest.param(
    {
        "current_config": copy.deepcopy(initial_empty_firewall_config),
        "set_config": copy.deepcopy(config_after_set_3),
        "delete_config": None,
        "expected_config": copy.deepcopy(config_after_set_3)
    },
    id="set_3_forward_filter_from_empty"
)

test_set_4 = pytest.param(
    {
        "current_config": copy.deepcopy(initial_empty_firewall_config),
        "set_config": copy.deepcopy(config_after_set_4),
        "delete_config": None,
        "expected_config": copy.deepcopy(config_after_set_4)
    },
    id="set_4_nat_dnat_snat_from_empty"
)

test_set_5 = pytest.param(
    {
        "current_config": copy.deepcopy(initial_empty_firewall_config),
        "set_config": copy.deepcopy(config_after_set_5),
        "delete_config": None,
        "expected_config": copy.deepcopy(config_after_set_5)
    },
    id="set_5_ipv6_filter_log_from_empty"
)

test_set = [
    test_set_1,
    test_set_2,
    test_set_3,
    test_set_4,
    test_set_5
]

# --- Test Cases for Deleting Configurations ---
test_delete_1 = pytest.param(
    {
        "current_config": copy.deepcopy(config_after_set_1),
        "set_config": None,
        "delete_config": {
            "firewall": {"ipv4": {"prerouting": {"raw": {"rule": {"10": {}}}}}}
        },
        "expected_config": {
            "firewall": {"ipv4": {"prerouting": {"raw": {"default_action": "accept", "rule": {}}}}}
        }
    },
    id="delete_1_prerouting_raw_rule10"
)

test_delete_2 = pytest.param(
    {
        "current_config": copy.deepcopy(config_after_set_2),
        "set_config": None,
        "delete_config": {
            "firewall": {"ipv4": {"prerouting": {"filter": {"rule": {"10": {}, "20": {}}}}}}
        },
        "expected_config": {
            "firewall": {"ipv4": {"prerouting": {"filter": {"default_action": "drop", "rule": {}}}}}
        }
    },
    id="delete_2_input_filter_all_rules"
)

test_delete_3 = pytest.param(
    {
        "current_config": copy.deepcopy(config_after_set_3),
        "set_config": None,
        "delete_config": {
            "firewall": {"ipv4": {"prerouting": {"filter": {"default_action": "accept"}}}}
        },
        "expected_config": {
            "firewall": {
                "ipv4": {
                    "prerouting": {
                        "filter": {
                            "rule": copy.deepcopy(config_after_set_3["firewall"]["ipv4"]["prerouting"]["filter"]["rule"])
                        }
                    }
                }
            }
        }
    },
    id="delete_3_forward_filter_default_action"
)

test_delete_4 = pytest.param(
    {
        "current_config": copy.deepcopy(config_after_set_4),
        "set_config": None,
        "delete_config": {
            "firewall": {"ipv4": {"prerouting": {"nat": {"rule": {"10": {}}}}}}
        },
        "expected_config": {
            "firewall": {
                "ipv4": {
                    "prerouting": {"nat": {"rule": {}}},
                    "postrouting": copy.deepcopy(config_after_set_4["firewall"]["ipv4"]["postrouting"])
                }
            }
        }
    },
    id="delete_4_nat_dnat_rule"
)

test_delete_5 = pytest.param(
    {
        "current_config": copy.deepcopy(config_after_set_5),
        "set_config": None,
        "delete_config": {
            "firewall": {"ipv6": {"prerouting": {"filter": {"rule": {"20": {}}}}}}
        },
        "expected_config": {
            "firewall": {
                "ipv6": {
                    "prerouting": {
                        "filter": {
                            "default_action": "drop",
                            "rule": {"10": copy.deepcopy(config_after_set_5["firewall"]["ipv6"]["prerouting"]["filter"]["rule"]["10"])}
                        }
                    }
                }
            }
        }
    },
    id="delete_5_ipv6_filter_rule20"
)

test_delete = [
    test_delete_1,
    test_delete_2,
    test_delete_3,
    test_delete_4,
    test_delete_5
]

current_for_tsd1 = copy.deepcopy(config_after_set_2)
set_for_tsd1 = {
    "firewall": {"ipv4": {"prerouting": {"filter": {"rule": {
        "10": {
            "action": "accept",
            "description": "Allow SSH from new_trusted_host",
            "protocol": "tcp",
            "source": {"address": "10.0.0.10"},
            "destination": {"port": "22"}
        },
        "30": {
            "action": "accept",
            "description": "Allow HTTP",
            "protocol": "tcp",
            "destination": {"port": "80"}
        }
    }}}}}
}
delete_for_tsd1 = {
    "firewall": {"ipv4": {"prerouting": {"filter": {"rule": {"20": {}}}}}}
}
expected_for_tsd1 = {
    "firewall": {"ipv4": {"prerouting": {"filter": {
        "default_action": "drop",
        "rule": {
            "10": set_for_tsd1["firewall"]["ipv4"]["prerouting"]["filter"]["rule"]["10"],
            "30": set_for_tsd1["firewall"]["ipv4"]["prerouting"]["filter"]["rule"]["30"]
        }
    }}}}
}
test_set_delete_1 = pytest.param(
    {
        "current_config": current_for_tsd1,
        "set_config": set_for_tsd1,
        "delete_config": delete_for_tsd1,
        "expected_config": expected_for_tsd1
    },
    id="set_delete_1_input_filter_modify_delete_add"
)

current_for_tsd2 = copy.deepcopy(config_after_set_1)
current_for_tsd2["firewall"]["ipv4"]["prerouting"] = {
    "filter": {"default_action": "drop", "rule": {}}
}
delete_for_tsd2 = {
    "firewall": {"ipv4": {"prerouting": {"raw": {}}}}
}
expected_for_tsd2 = {
    "firewall": {
        "ipv4": {
            "prerouting": {
                "filter": {
                    "default_action": "drop",
                }
            }
        }
    }
}
test_set_delete_2 = pytest.param(
    {
        "current_config": current_for_tsd2,
        "set_config": {},
        "delete_config": delete_for_tsd2,
        "expected_config": expected_for_tsd2
    },
    id="set_delete_2_remove_prerouting_raw_table"
)

current_for_tsd3 = copy.deepcopy(config_after_set_1)
set_for_tsd3 = {
    "firewall": {"ipv4": {"prerouting": {"raw": {"rule": {
        "10": {
            "action": "accept",
            "description": "Allow specific traffic in raw prerouting - updated destination",
            "destination": {"address": "192.168.1.200"}
        }
    }}}}}
}
expected_for_tsd3 = {
    "firewall": {"ipv4": {"prerouting": {"raw": {
        "default_action": "accept",
        "rule": {"10": set_for_tsd3["firewall"]["ipv4"]["prerouting"]["raw"]["rule"]["10"]}
    }}}}
}
test_set_delete_3 = pytest.param(
    {
        "current_config": current_for_tsd3,
        "set_config": set_for_tsd3,
        "delete_config": {},
        "expected_config": expected_for_tsd3
    },
    id="set_delete_3_prerouting_raw_modify_rule_destination"
)

test_set_delete = [
    test_set_delete_1,
    test_set_delete_2,
    test_set_delete_3
]