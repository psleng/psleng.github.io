import pytest

current_config = {
    "service": {
        "ntp": {
            'server': {
                '0.pool.ntp.org': {
                    'pool': {}
                },
                '1.pool.ntp.org': {
                    'pool': {},
                    'noselect': {}
                }
            },
            'listen_address': ['192.168.1.1'],
            'allow_client': {
                "address": ['192.168.1.0/24']
            },
            'interface': 'eth0',
            'leap_second': 'system'
        }
    }
}

test_set_1 = pytest.param(
        (
            {
                "current_config": current_config,
                "set_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '2.pool.ntp.org': {
                                    'pool': {}
                                }
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {}
                                },
                                '2.pool.ntp.org': {
                                    'pool': {}
                                }
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_set_1"
    )

test_set_2 = pytest.param(
        (
            {
                "current_config": current_config,
                "set_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '1.pool.ntp.org': {
                                    'nts': {},
                                    'interleave': {}
                                }
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {},
                                    'nts': {},
                                    'interleave': {}
                                },
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_set_2"
    )

test_set_3 = pytest.param(
        (
            {
                "current_config": current_config,
                "set_config": {
                    "service": {
                        "ntp": {
                            'allow_client': {
                                "address": ['10.0.0.0/24']
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {},
                                },
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24', '10.0.0.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_set_3"
    )


test_set_4 = pytest.param(
        (
            {
                "current_config": current_config,
                "set_config": {
                    "service": {
                        "ntp": {
                            'ptp': {
                                'port': 319
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {},
                                },
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system',
                            'ptp': {
                                'port': 319
                            }
                        }
                    }
                }
            }
        ),
        id="test_set_4"
    )


test_set_5 = pytest.param(
        (
            {
                "current_config": current_config,
                "set_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '2.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'nts': {}
                                }
                            },
                            'allow_client': {
                                "address": ['10.0.0.0/24']
                            },
                            'ptp': {
                                'port': 319
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {},
                                    'nts': {}
                                },
                                '2.pool.ntp.org': {
                                    'pool': {}
                                },
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24', '10.0.0.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system',
                            'ptp': {
                                'port': 319
                            }
                        }
                    }
                }
            }
        ),
        id="test_set_5"
    )



test_set = [
    test_set_1,
    test_set_2,
    test_set_3,
    test_set_4,
    test_set_5
]

test_delete_1 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '1.pool.ntp.org': {
                                    'noselect': {}
                                }
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {}
                                }
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_delete_1"
    )

test_delete_2 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'leap_second': 'system'
                        }
                    }   
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {}
                                }
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                        }
                    }
                }
            }
        ),
        id="test_delete_2"
    )


test_delete_3 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {},
                                '1.pool.ntp.org': {}
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                            },
                            'listen_address': ['192.168.1.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_delete_3"
    )

test_delete_4 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'allow_client': {
                                'address': ['192.168.1.0/24']
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {}
                                }
                            },
                            'listen_address': ['192.168.1.1'],
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
        ),
        id="test_delete_4"
    )


test_delete = [
    test_delete_1,
    test_delete_2,
    test_delete_3,
    test_delete_4
]


test_set_delete_1 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'listen_address': ['192.168.1.1']
                        }
                    }   
                },
                "set_config": {
                    "service": {
                        "ntp": {
                            'listen_address': ['10.0.0.1']
                        }
                    }   
                },
                "expected_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'pool': {},
                                    'noselect': {}
                                }
                            },
                            'listen_address': ['10.0.0.1'],
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'interface': 'eth0',
                            'leap_second': 'system'
                        }
                    }
                }
            }
            
        ),
        id="test_set_delete_1"
    )

test_set_delete_2 = pytest.param(
        (
            {
                "current_config": current_config,
                "delete_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '0.pool.ntp.org': 'all'
                            },
                            'allow_client': {
                                "address": ['192.168.1.0/24']
                            },
                            'leap_second': 'system'
                        }
                    } 
                },
                "set_config": {
                    "service": {
                        "ntp": {
                            'server': {
                                '2.pool.ntp.org': {
                                    'pool': {}
                                },
                                '1.pool.ntp.org': {
                                    'nts': {}
                                }
                            },
                            'allow_client': {
                                "address": ['10.0.0.0/24']
                            },
                            'ptp': {
                                'port': 319
                            }
                        }
                    }
                },
                "expected_config": {
                    "service": {
                        "ntp":  {
                            'allow_client': {
                                'address': [
                                    '10.0.0.0/24',
                                ],
                            },
                            'interface': 'eth0',
                            'listen_address': [
                                '192.168.1.1',
                            ],
                            'ptp': {
                                'port': 319,
                            },
                            'server': {
                                '1.pool.ntp.org': {
                                    'noselect': {},
                                    'nts': {},
                                    'pool': {},
                                },
                                '2.pool.ntp.org': {
                                    'pool': {},
                                },
                            },
                        }
                    }
                }
            }
            
        ),
        id="test_set_delete_2"
    )

test_set_delete = [
    test_set_delete_1,
    test_set_delete_2
]