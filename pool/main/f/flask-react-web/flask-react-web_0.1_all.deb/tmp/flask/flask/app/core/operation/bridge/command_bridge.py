from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint

class BridgeCommand(IfaceCommand):
    """
        Command class for Bridge Interface:
        Support all of commands in IfaceCommand
        And extra commands specific to Bridge interface:

        Bridge Interface Settings:
        • set/del interface bridge <bridge-name> member interface <interface>

    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
    def _process_bridge_address(self, bridge_name, address):
        if isinstance(address, list):
            for addr in address:
                self.generate('interfaces', 'bridge', bridge_name, 'address', addr)
        elif isinstance(address, str):
            self.generate('interfaces', 'bridge', bridge_name, 'address', address)


    def generate_commands(self, data=None, current_config=None, new_config=None):
        try:
            if not data:
                return []
            if data:
                # generate specific commands for bridge
                for bridge_name, config in data.items():
                    if 'address' in config:
                        self._process_bridge_address(bridge_name, config['address'])

            return self.cmds

        except Exception as e:
            print(f"Error generating commands: {e}")
            return []


