from flask import jsonify, request, session, Response
from . import event_bp
from queue import Empty, Queue
import json
from uuid import uuid4
from app.socket.socket_manager import socket_manager
from logging import getLogger

user_connections = {}

def generate_events(user_id):
    """Generator to stream events to a specific user."""
    user_queue = user_connections[user_id]
    while True:
        try:
            # Wait for a message in the user's queue
            message = user_queue.get(timeout=5)
            json_message = {
                "id": str(uuid4()),  
                "type": message.get('type'), 
                "title": message.get('title'), 
                "content": message.get('content'),
                "page": message.get('page'),
                "operation": message.get('operation')
            }
            yield f"data: {json_message}\n\n"
        except Empty:
            # Send a heartbeat to keep the connection alive
            json_message = {"id": str(uuid4()), "type": "heartbeat", "title": "Heartbeat", "content": "heartbeat"}
            yield f"data: {json_message}\n\n"

# @event_bp.route('/')
# def events():
#     """Endpoint to handle SSE connections."""
#     user_id = session['user_id']
#     if not user_id:
#         return {"error": "User ID is required"}, 400

#     if user_id not in user_connections:
#         user_connections[user_id] = Queue()

#     return Response(generate_events(user_id), content_type='text/event-stream')


def send_message(user_id, message):

    if not user_id or not message:
        return {"error": "User ID and message are required"}, 400

    if user_id in user_connections:
        user_connections[user_id].put(message)
        return {"status": "Message sent"}, 200
    else:
        return {"error": "User not connected"}, 404

@event_bp.route('/send_message', methods=['POST'])
def send():
    # data = request.json
    # msg = {
    #     "content": data.get('message'),
    #     "title": "Success",
    #     "type": "success"
    # }
    # send_message(data.get('user_id'), msg)
    print('Session object', session)
    print('Session object', session.get('sid', None))
    
    socket_manager.emit_to_client(
        sid=None, 
        event='notification', 
        data={
            "id": str(uuid4()),
            "type": "success",
            "title": "Success",
            "content": "Notification is successfully registered"
        })

    return jsonify({'message': 'Success'}), 200


@event_bp.route('/send_message_to_userid', methods=['POST'])    
def send_user_message():
    data = request.get_json()
    socket_manager.emit_to_user(
        data['sid'], 
        event='notification', 
        data={
            "id": str(uuid4()),
            "type": "success",
            "title": "Success",
            "content": "Notification is successfully registered"
        }
    )
    return 'Message sent'


@event_bp.route('/send_message_test', methods=['POST'])
def send_message_test():
    data = request.get_json()
    socket_manager.emit_test(
        data['sid'],
        event='notification',
        data={
                "id": str(uuid4()),
                "type": "success",
                "title": "Success",
                "content": "Notification is successfully registered"
            }
    )
    # socket_manager.clear()
    logger = getLogger(__name__)
    logger.info("Current connected clients")
    logger.info(socket_manager.connected_clients)

    return 'OK'