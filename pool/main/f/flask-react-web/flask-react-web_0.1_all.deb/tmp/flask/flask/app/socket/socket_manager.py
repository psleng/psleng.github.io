import threading
from queue import Queue
from flask import Flask, session
from flask_socketio import SocketIO
from functools import wraps
from uuid import uuid4
from app.log.logger import logger


class SocketManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        self.connected_clients = {}
        self.connected_guests = {}
        self.client_queue = Queue()
        self.socketio = None
        self.app = None
        self.socket_to_user = {}
        
    def _clear_state(self):
        self.connected_clients = {}
        self.connected_guests = {}
        self.client_queue = Queue()
        self.socket_to_user = {}

    def init_app(self, app, socketio):
        self.app = app
        self.socketio = socketio
        self._start_background_thread()

    def _start_background_thread(self):
        """Start the background thread for processing client messages"""
        def background_task():
            while True:
                try:
                    if not self.client_queue.empty():
                        sid, event, data = self.client_queue.get()
                        
                        try:
                            with self.app.app_context():
                                self.socketio.emit(event, data, room=sid)
                        except Exception as e:
                            logger.error(f"Error emitting to {sid}")
                            logger.error(str(e))
                        
                        self.client_queue.task_done()
                    
                    threading.Event().wait(0.1)
                except Exception as e:
                    logger.error("Background task error")
                    logger.error(str(e))

        thread = threading.Thread(target=background_task, daemon=True)
        thread.start()


    def register_client(self, sid, user_token):
        logger.debug("Register client")
        logger.debug(sid)
        logger.debug(user_token)
        # Ensure user's socket sessions are tracked
        if user_token not in self.connected_clients:
            self.connected_clients[user_token] = set()
        
        self.connected_clients[user_token].add(sid)
        self.socket_to_user[sid] = user_token
        
        logger.debug("Registered client")
        logger.debug(user_token)
        logger.debug(sid)

    def remove_client(self, sid):
        """Remove a client from connected clients"""
        logger.debug("Remove client")
        logger.debug(sid)
        logger.debug("Socket to user")
        logger.debug(self.socket_to_user)
        # print("Connected clients", self.connected_clients)
        if sid in self.socket_to_user:
            user_token = self.socket_to_user[sid]
            
            if user_token in self.connected_clients:
                self.connected_clients[user_token].discard(sid)
                
                if not self.connected_clients[user_token]:
                    del self.connected_clients[user_token]
            
            del self.socket_to_user[sid]

    def emit_to_user(self, user_token, event, data):
        logger.debug("Connected clients")
        logger.debug(self.connected_clients)
        if user_token in self.connected_clients:
            logger.debug("All SID")
            logger.debug(self.connected_clients[user_token])
            for sid in self.connected_clients[user_token]:
                self.client_queue.put((sid, event, data))

    
    def register_guest(self, sid):
        logger.debug("Register guest")
        logger.debug(sid)
        # Ensure user's socket sessions are tracked
        if sid not in self.connected_guests:
            self.connected_guests[sid] = {"SSID": sid}
        
        self.connected_guests[sid].update({"SSID": sid})


    def remove_guest(self, sid):
        logger.debug("Remove guest")
        logger.debug(sid)
        if sid in self.connected_guests:
            del self.connected_guests[sid]

    def emit_to_guest(self, ssid, event, data):
        logger.debug("Connected guests")
        logger.debug(self.connected_guests)
        for sid, v in self.connected_guests.items():
            if sid == ssid:
                self.client_queue.put((sid, event, data))


    def emit_test(self, sid, event, data):
        try:
            logger.debug("=== Emit Test ===")
            self.client_queue.put((sid, event, data))
        except Exception as e:
            logger.error("Emit test error")
            logger.error(str(e))

    def emit_to_client(self, sid, event, data):
        """Queue a message to a specific client socket session"""
        if sid:
            self.client_queue.put((sid, event, data))

    def clear(self):
        self._clear_state()

    def get_connected_clients(self):
        return self.connected_clients

    def get_connected_guests(self):
        return self.connected_guests
        
socket_manager = SocketManager()