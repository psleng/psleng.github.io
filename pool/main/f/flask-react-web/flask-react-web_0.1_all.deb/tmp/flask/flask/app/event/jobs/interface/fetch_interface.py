from app.core.models import Interface
from app.core.operation.wifi.models import WiFiInterfaceConfig
from app.config import global_config
from celery import shared_task
from time import sleep
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.log.logger import logger

def fetch_interface_opr(app_context):
    try:
        logger.debug("[TASK] Fetch Interfaces")
        refresh_db_interface_operation(app_context=app_context)
    except Exception as e:
        logger.error('Error fetch interface', str(e))


def refresh_db_interface_operation(app_context=None):
    try:
        interfaces = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE)
        interfaces_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.INTERFACE_CONFIG)
        
        # logger.debug("Interface Graphql data: ")
        # logger.debug(interfaces)
        
        if app_context is not None:
            with app_context:
                Interface.refresh(interfaces, interfaces_config)
                WiFiInterfaceConfig.refresh(interfaces, interfaces_config, "api")
        else:
            Interface.refresh(interfaces, interfaces_config)
            WiFiInterfaceConfig.refresh(interfaces, interfaces_config, "api")
        return interfaces
    except Exception as e:
        logger.error("Exception", str(e))
        return []
    

@shared_task(ignore_result=False)
def long_running_task():
    logger.debug('Task started')
    try:
        sleep(10)
        logger.debug('Task completed')
        return 'Task completed'
    except Exception as e:
        logger.debug(f"Task failed: {e}")
        return str(e)