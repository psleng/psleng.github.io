from celery import Celery, Task
from flask import Flask, Blueprint

event_bp = Blueprint('events', __name__)

from . import routes

def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name, task_cls=FlaskTask)
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app