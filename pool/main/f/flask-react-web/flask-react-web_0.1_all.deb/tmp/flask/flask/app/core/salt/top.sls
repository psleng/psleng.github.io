base:
  'hostNameVyOS-Proxy': 
    - hostNameVyOS-Proxy 

  