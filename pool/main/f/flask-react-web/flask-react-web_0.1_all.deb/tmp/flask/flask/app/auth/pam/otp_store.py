import threading

class OTPStore:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance.otp_requests = {}
        return cls._instance

    def request_otp(self, request_id):
        if request_id not in self.otp_requests:
            self.otp_requests[request_id] = {
                'event': threading.Event(),
                'otp': None
            }
        return self.otp_requests[request_id]['event']

    def set_otp(self, request_id, otp):
        if request_id in self.otp_requests:
            self.otp_requests[request_id]['otp'] = otp
            self.otp_requests[request_id]['event'].set()

    def get_otp(self, request_id):
        if request_id in self.otp_requests:
            otp = self.otp_requests[request_id]['otp']
            # Clean up the request to prevent reuse and memory leaks
            del self.otp_requests[request_id]
            return otp
        return None

otp_store = OTPStore()
