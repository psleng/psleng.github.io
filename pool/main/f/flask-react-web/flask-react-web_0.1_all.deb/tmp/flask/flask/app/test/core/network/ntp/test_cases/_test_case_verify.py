import pytest

test_verify_failed_1 = pytest.param(
    (
        { 
            'allow_client': {'address': ['127.0.0.0/8', '10.0.0.0/24', '10.20.30.0/24']},
            'config_file': '/run/chrony/chrony.conf',
            'interface': 'eth3',
            'leap_second': 'timezone',
            'listen_address': ['192.168.222.0'],
            'user': '_chrony'
        }
    ),
    id="test_verify_failed_1"
)



test_verify_failed = [
    test_verify_failed_1
]


test_verify_success_1 = pytest.param(
    (
        { 
            'allow_client': {'address': ['127.0.0.0/8', '10.0.0.0/24', '10.20.30.0/24']},
            'config_file': '/run/chrony/chrony.conf',
            'interface': 'eth3',
            'leap_second': 'timezone',
            'listen_address': ['192.168.222.0'],
            'server': { 
                '0.pool.ntp.org': {},
                '1.pool.ntp.org': {},
                '2.pool.ntp.org': {},
                '3.pool.ntp.org': {
                    'interleave': {}, 
                    'pool': {}
                },
                '5.5.5.5': { 
                    'interleave': {},
                    'noselect': {},
                    'nts': {},
                    'pool': {}},
                'test.example.com': {}
            },
            'user': '_chrony'
        }
    ),
    id="test_verify_success_1"
)

test_verify_success = [
    test_verify_success_1
]
