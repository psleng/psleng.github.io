from flask import Blueprint

vyos_security_bp = Blueprint('security', __name__)

from . import routes