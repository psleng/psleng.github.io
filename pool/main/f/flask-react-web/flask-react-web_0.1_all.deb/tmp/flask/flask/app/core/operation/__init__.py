from flask import Blueprint

vyos_operation_bp = Blueprint('opr', __name__)

from . import routes