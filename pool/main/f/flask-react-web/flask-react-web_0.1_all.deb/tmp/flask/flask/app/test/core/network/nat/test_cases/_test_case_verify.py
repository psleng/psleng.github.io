import pytest

test_verify_success_1 = pytest.param(
    (
        { 
            "source": {
                "rule": {
                    "100": {
                        "outbound_interface": {
                            "name": "eth2"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "192.168.1.0/24",
                            "port": "8080"
                        },
                        "destination": {
                            "address": "10.0.0.0/24",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.1",
                            "port": "9090"
                        },
                        "description": "Source_NAT_rule"
                    }
                }
            },
            "destination": {
                "rule": {
                    "200": {
                        "inbound_interface": {
                            "name": "eth3"
                        },
                        "protocol": "tcp",
                        "source": {
                            "address": "0.0.0.0/0"
                        },
                        "destination": {
                            "address": "203.0.113.10",
                            "port": "80"
                        },
                        "translation": {
                            "address": "192.168.1.10",
                            "port": "8080"
                        },
                        "description": "Destination_NAT_rule"
                    }
                }
            },
            'load_balance': {'hash': ['random']}, 
            'firewall_group': {}, 
            'ip_fqdn': {}, 
            'ip6_fqdn': {}
        }
    ),
    id="test_verify_success_1"
)

test_verify_success_2 = pytest.param(
    (
        { 
            "source": {
                "rule": {
                    "300": {
                        "outbound_interface": {
                            "name": "eth2"
                        },
                        "translation": {
                            "address": "masquerade"
                        }
                    }
                }
            },
            'load_balance': {'hash': ['random']}, 
            'firewall_group': {}, 
            'ip_fqdn': {}, 
            'ip6_fqdn': {}
        }
    ),
    id="test_verify_success_2"
)

test_verify_success = [
    test_verify_success_1,
    test_verify_success_2
]

test_verify_failed_1 = pytest.param(
    (
        { 
            "source": {
                "rule": {
                    "100": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "999.999.999.999"
                        }
                    }
                }
            }
        }
    ),
    id="test_verify_failed_1"
)

test_verify_failed_2 = pytest.param(
    (
        { 
            "source": {
                "rule": {
                    "invalid": {
                        "outbound-interface": {
                            "name": "eth1"
                        },
                        "translation": {
                            "address": "192.168.1.1"
                        }
                    }
                }
            }
        }
    ),
    id="test_verify_failed_2"
)

test_verify_failed = [
    test_verify_failed_1,
    test_verify_failed_2
]
