import pytest

test_update_final_1 = pytest.param(
            {
                "parsed_input": {
                    "json_input": {
                        "firewallv4": {
                            "inbound": [
                                {
                                    "rule_number": 1,
                                    "action": "accept",
                                    "protocol": "tcp",
                                    "enabled": True,
                                    "log_enabled": False,
                                    "firewall_type": "prerouting",
                                    "source_address": "192.168.1.1",
                                    "source_subnet": "24",
                                    "source_port": "80",
                                    "destination_address": "10.0.0.1",
                                    "destination_port": "443",
                                    "interface": "eth0"
                                }
                            ]
                        },
                        "firewallv6": {
                            "inbound": [],
                            "outbound": []
                        }
                    },
                    "validated_input": {
                        "firewallv4": {
                            "inbound": [
                                {
                                    "rule_number": 1,
                                    "action": "accept",
                                    "protocol": "tcp",
                                    "enabled": True,
                                    "log_enabled": False,
                                    "firewall_type": "prerouting",
                                    "source_address": "192.168.1.1",
                                    "source_subnet": "24",
                                    "source_port": "80",
                                    "destination_address": "10.0.0.1",
                                    "destination_port": "443",
                                    "interface": "eth0"
                                }
                            ]
                        },
                        "firewallv6": {
                            "inbound": [],
                            "outbound": []
                        }
                    },
                    "parsed_input": {
                        "ipv4": {
                            "prerouting": {
                                "raw": {
                                    "default_action": "accept",
                                    "rule": {
                                        "1": {
                                            "action": "accept",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "192.168.1.1",
                                                "address-mask": "255.255.255.0",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "10.0.0.1",
                                                "port": "443"
                                            },
                                            "inbound-interface": {
                                                "name": "eth0"
                                            }
                                        }
                                    }
                                }
                            }, 
                        },
                        "ipv6": {}
                    },
                    "current_config": {},
                    "diff_created": {
                        "ipv4": {
                            "prerouting": {
                                "raw": {
                                    "default_action": "accept",
                                    "rule": {
                                        "1": {
                                            "action": "accept",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "192.168.1.1",
                                                "address-mask": "255.255.255.0",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "10.0.0.1",
                                                "port": "443"
                                            },
                                            "inbound-interface": {
                                                "name": "eth0"
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        "ipv6": {}
                    },
                    "diff_deleted": {}
                },
                "generate_config": {
                    "set_cmds": [
                        "firewall ipv4 prerouting raw default-action accept",
                        "firewall ipv4 prerouting raw rule 1 action accept",
                        "firewall ipv4 prerouting raw rule 1 protocol tcp",
                        "firewall ipv4 prerouting raw rule 1 source address 192.168.1.1",
                        "firewall ipv4 prerouting raw rule 1 source address-mask 255.255.255.0",
                        "firewall ipv4 prerouting raw rule 1 source port 80",
                        "firewall ipv4 prerouting raw rule 1 destination address 10.0.0.1",
                        "firewall ipv4 prerouting raw rule 1 destination port 443",
                        "firewall ipv4 prerouting raw rule 1 inbound-interface name eth0"
                    ],
                    "delete_cmds": [],
                    "processed_set_config": {
                        "firewall": {
                            "ipv4": {
                                "prerouting": {
                                    "raw": {
                                        "default-action": "accept",
                                        "rule": {
                                            "1": {
                                                "action": "accept",
                                                "protocol": "tcp",
                                                "source": {
                                                    "address": "192.168.1.1",
                                                    "address-mask": "255.255.255.0",
                                                    "port": "80"
                                                },
                                                "destination": {
                                                    "address": "10.0.0.1",
                                                    "port": "443"
                                                },
                                                "inbound-interface": {
                                                    "name": "eth0"
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            "ipv6": {}
                        }
                    },
                    "processed_delete_config": {}
                },
                "process_config": {
                    "curr_config": {},
                    "merged_del": {
                        "firewall": {}
                    },
                    "merged_set": {
                        "firewall": {
                            "ipv4": {
                                "prerouting": {
                                    "raw": {
                                        "default-action": "accept",
                                        "rule": {
                                            "1": {
                                                "action": "accept",
                                                "protocol": "tcp",
                                                "source": {
                                                    "address": "192.168.1.1",
                                                    "address-mask": "255.255.255.0",
                                                    "port": "80"
                                                },
                                                "destination": {
                                                    "address": "10.0.0.1",
                                                    "port": "443"
                                                },
                                                "inbound-interface": {
                                                    "name": "eth0"
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            "ipv6": {}
                        }
                    }
                },
                "verify": {
                    "verify_result": True
                }
            },
        id="firewall_final_ipv4_rule"
    )
test_update_final_2 = pytest.param(
            {
                "parsed_input": {
                    "json_input": {
                        "firewallv4": {
                            "inbound": [],
                            "outbound": []
                        },
                        "firewallv6": {
                            "outbound": [
                                {
                                    "rule_number": 10,
                                    "action": "drop",
                                    "protocol": "tcp",
                                    "enabled": True,
                                    "log_enabled": True,
                                    "firewall_type": "output",
                                    "source_address": "2001:db8::1",
                                    "source_port": "80",
                                    "destination_address": "2001:db8::2",
                                    "destination_port": "8080"
                                }
                            ]
                        }
                    },
                    "validated_input": {
                        "firewallv4": {
                            "inbound": [],
                            "outbound": []
                        },
                        "firewallv6": {
                            "outbound": [
                                {
                                    "rule_number": 10,
                                    "action": "drop",
                                    "protocol": "tcp",
                                    "enabled": True,
                                    "log_enabled": True,
                                    "firewall_type": "output",
                                    "source_address": "2001:db8::1",
                                    "source_port": "80",
                                    "destination_address": "2001:db8::2",
                                    "destination_port": "8080"
                                }
                            ]
                        }
                    },
                    "parsed_input": {
                        "ipv4": {},
                        "ipv6": {
                            "output": {
                                "raw": {
                                    "default_action": "accept",
                                    "rule": {
                                        "10": {
                                            "action": "drop",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "2001:db8::1",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "2001:db8::2",
                                                "port": "8080"
                                            },
                                            "log": {}
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "current_config": {},
                    "diff_created": {
                        "ipv4": {},
                        "ipv6": {
                            "output": {
                                "raw": {
                                    "default_action": "accept",
                                    "rule": {
                                        "10": {
                                            "action": "drop",
                                            "protocol": "tcp",
                                            "source": {
                                                "address": "2001:db8::1",
                                                "port": "80"
                                            },
                                            "destination": {
                                                "address": "2001:db8::2",
                                                "port": "8080"
                                            },
                                            "log": {}
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "diff_deleted": {}
                },
                "generate_config": {
                    "set_cmds": [
                        "firewall ipv6 output raw default-action accept",
                        "firewall ipv6 output raw rule 10 action drop",
                        "firewall ipv6 output raw rule 10 protocol tcp",
                        "firewall ipv6 output raw rule 10 source address 2001:db8::1",
                        "firewall ipv6 output raw rule 10 source port 80",
                        "firewall ipv6 output raw rule 10 destination address 2001:db8::2",
                        "firewall ipv6 output raw rule 10 destination port 8080",
                        "firewall ipv6 output raw rule 10 log"
                    ],
                    "delete_cmds": [],
                    "processed_set_config": {
                        "firewall": {
                            "ipv4": {},
                            "ipv6": {
                                "output": {
                                    "raw": {
                                        "default-action": "accept",
                                        "rule": {
                                            "10": {
                                                "action": "drop",
                                                "protocol": "tcp",
                                                "source": {
                                                    "address": "2001:db8::1",
                                                    "port": "80"
                                                },
                                                "destination": {
                                                    "address": "2001:db8::2",
                                                    "port": "8080"
                                                },
                                                "log": {}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "processed_delete_config": {}
                },
                "process_config": {
                    "curr_config": {},
                    "merged_del": {
                        "firewall": {}
                    },
                    "merged_set": {
                        "firewall": {
                            "ipv4": {},
                            "ipv6": {
                                "output": {
                                    "raw": {
                                        "default-action": "accept",
                                        "rule": {
                                            "10": {
                                                "action": "drop",
                                                "protocol": "tcp",
                                                "source": {
                                                    "address": "2001:db8::1",
                                                    "port": "80"
                                                },
                                                "destination": {
                                                    "address": "2001:db8::2",
                                                    "port": "8080"
                                                },
                                                "log": {}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "verify": {
                    "verify_result": True
                }
            },
        id="firewall_final_ipv6_rule"
    )

test_update_final = [
    test_update_final_1,
    test_update_final_2
]