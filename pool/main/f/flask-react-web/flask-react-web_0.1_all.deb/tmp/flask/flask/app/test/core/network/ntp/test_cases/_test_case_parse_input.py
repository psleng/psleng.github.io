import pytest
import json

test_case_valid = [
    pytest.param(
    ({
        "valid_json": json.dumps({
            "servers": [
                {
                    "address": "0.pool.ntp.org",
                    "pool": True,
                    "interleave": False,
                    "noselect": False,
                    "nts": False,
                    "ptp": False
                },
                {
                    "address": "1.pool.ntp.org",
                    "pool": True,
                    "interleave": False,
                    "noselect": True,
                    "nts": False,
                    "ptp": False
                }
            ],
            "allow_clients": [
                {"address": "192.168.1.0/24"},
                {"address": "10.0.0.0/24"}
            ],
            "interface": "eth0",
            "listen_address": "192.168.1.1",
            "leap_second": "system",
            "ptp": {
                "port": "319",
                "interfaces": ["eth0"]
            }
        })
    }),
    id="valid_json_1"),
    pytest.param(
    ({
        "valid_json": json.dumps({
            "servers": [
                {
                    "address": "0.pool.ntp.org",
                    "pool": True,
                    "interleave": True,
                    "noselect": False,
                    "nts": True,
                    "ptp": False
                },
                {
                    "address": "1.pool.ntp.org",
                    "pool": False,
                    "interleave": False,
                    "noselect": False,
                    "nts": False,
                    "ptp": True
                },
                {
                    "address": "time.example.com",
                    "pool": False,
                    "interleave": True,
                    "noselect": True,
                    "nts": True,
                    "ptp": True
                }
            ],
            "allow_clients": [
                {"address": "192.168.1.0/24"},
                {"address": "10.0.0.0/8"},
                {"address": "172.16.0.0/12"}
            ],
            "interface": "eth1",
            "listen_address": "10.0.0.1",
            "leap_second": "file",
            "ptp": {
                "port": "320",
                "interfaces": ["eth0", "eth1"]
            }
        })
    }),
    id="valid_json_2")
]

test_case_invalid = [
    pytest.param(
        {
            "invalid_json": json.dumps({
                "servers": [
                    {
                        "address": "0.pool.ntp.org",
                        "pool": "not-a-boolean", 
                        "interleave": False
                    }
                ],
                "allow_clients": "not-a-list", 
                "interface": 123, 
                "ptp": "not-an-object" 
            })
        },
        id="invalid_json_1")
]

test_case_minimal = [
    pytest.param(
    {
        "minimal_json": json.dumps({
            "servers": [
                {"address": "0.pool.ntp.org"}
            ]
        })
    },
    id="minimal_config_1"),
    pytest.param(
    {
        "minimal_json": json.dumps({
            "servers": [
                {"address": "time.example.com"}
            ]
        })
    },
    id="minimal_config_2")
]

test_case_comparison = [
    pytest.param(
    ({
        "current_config": {
            "server": {
                "0.pool.ntp.org": {
                    "pool": {}
                },
                "2.pool.ntp.org": {
                    "pool": {}
                }
            },
            "listen-address": "192.168.1.2",
            "allow-client": {
                "address": ["192.168.1.0/24"]
            },
            "interface": "eth1"
        },
        "new_config": {
            "server": {
                "0.pool.ntp.org": {
                    "pool": {}
                },
                "1.pool.ntp.org": {
                    "pool": {},
                    "noselect": {}
                }
            },
            "listen-address": "192.168.1.1",
            "allow-client": {
                "address": ["192.168.1.0/24", "10.0.0.0/24"]
            },
            "interface": "eth0",
            "leap-second": "system"
        },
        "expected_diff": {
            "created": {
                "server": {
                    "1.pool.ntp.org": {
                        "pool": {},
                        "noselect": {}
                    }
                },
                "listen-address": "192.168.1.1",
                "allow-client": {
                    "address": ["10.0.0.0/24"]
                },
                "interface": "eth0",
                "leap-second": "system"
            },
            "deleted": {
                "server": {
                    "2.pool.ntp.org": {
                        "pool": {}
                    }
                },
                "listen-address": "192.168.1.2",
                "interface": "eth1"
            }
        }
    }),
    id="compare_0"),
    pytest.param(
    {
        "current_config": {"server": None},
        "new_config": {"server": {"time.example.com": {}}},
        "expected_diff": {
            "deleted": {},
            "created": {"server": {"time.example.com": {}}}
        }
    },
    id="compare_1"),
    pytest.param(
    {
        "current_config": {"server": {"time.example.com": {}}},
        "new_config": {"server": {"time.example.com": {}}},
        "expected_diff": {
            "deleted": {},
            "created": {}
        }
    },
    id="compare_2"),
    pytest.param(
    {
        "current_config": {},
        "new_config": {},
        "expected_diff": {
            "deleted": {},
            "created": {}
        }
    },
    id="compare_3")
]