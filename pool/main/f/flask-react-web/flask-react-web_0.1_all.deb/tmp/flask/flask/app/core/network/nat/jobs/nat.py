from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.network.nat.models import NATv4
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_nat_job(app_context):
    try:
        refresh_db_nat(app_context=app_context)
    except Exception as e:
        print('Error fetch nat', str(e))

    
def refresh_db_nat(app_context):
    try: 
        logger.info("[TASK] Fetch NAT")
        print("[TASK] Fetch NAT")
        vyos_data = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT)
        logger.info(vyos_data)
        print(vyos_data)
        if app_context is not None:
            with app_context:
                    NATv4.refresh(vyos_data)
        else:
            NATv4.refresh(vyos_data)
        return vyos_data
    except Exception as e:
        print(str(e))
        return False