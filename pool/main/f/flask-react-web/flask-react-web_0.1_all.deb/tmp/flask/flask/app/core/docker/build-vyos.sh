#!/bin/bash

set -e

ISO_URL="https://github.com/vyos/vyos-nightly-build/releases/download/1.5-rolling-202411050007/vyos-1.5-rolling-202411050007-generic-amd64.iso"
ISO_NAME="vyos-1.5-rolling-202411050007-generic-amd64.iso"
IMAGE_NAME="vyos:1.5-rolling"

mkdir -p /workspace/rootfs /workspace/unsquashfs

echo "Downloading VyOS ISO..."
wget -O /workspace/${ISO_NAME} ${ISO_URL}

echo "Mounting the ISO..."
mount -o loop /workspace/${ISO_NAME} /workspace/rootfs

echo "Extracting SquashFS filesystem..."
unsquashfs -f -d /workspace/unsquashfs/ /workspace/rootfs/live/filesystem.squashfs

echo "Creating Docker image..."
tar -C /workspace/unsquashfs -c . | docker import - ${IMAGE_NAME}

echo "Unmounting the ISO..."
umount /workspace/rootfs

echo "Cleaning up..."
rm -rf /workspace/rootfs /workspace/unsquashfs /workspace/${ISO_NAME}

echo "VyOS Docker image created: ${IMAGE_NAME}"
