from app.core.api.http.cmd.command import Command

def format_description(description: str) -> str:
    # Replace spaces with underscores
    return description.replace(' ', '_')

class CommandNAT(Command):
    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator', 'set'), resource=kwargs.get('resource', 'source'))
        self.cmds = []
        self.vyos_cmds = []

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate(self, *args):
        self.cmds.append(self._build_command(*args))
        self.vyos_cmds.append(f"{self.operator} {' '.join(map(str, args))}")

    def get_commands(self):
        return self.vyos_cmds

    def _process_rule(self, rule_path, rule_config):
        """Helper method to process a single NAT rule configuration"""

        if 'outbound-interface' in rule_config:
            self.generate(*rule_path, 'outbound-interface', 'name', rule_config['outbound-interface']['name'])
        if 'inbound-interface' in rule_config:
            self.generate(*rule_path, 'inbound-interface', 'name', rule_config['inbound-interface']['name'])

        if 'source' in rule_config:
            if 'address' in rule_config['source']:
                self.generate(*rule_path, 'source', 'address', rule_config['source']['address'])
            if 'port' in rule_config['source']:
                self.generate(*rule_path, 'source', 'port', rule_config['source']['port'])

        if 'destination' in rule_config:
            if 'address' in rule_config['destination']:
                self.generate(*rule_path, 'destination', 'address', rule_config['destination']['address'])
            if 'port' in rule_config['destination']:
                self.generate(*rule_path, 'destination', 'port', rule_config['destination']['port'])

        if 'translation' in rule_config:
            if 'address' in rule_config['translation']:
                self.generate(*rule_path, 'translation', 'address', rule_config['translation']['address'])
            if 'port' in rule_config['translation']:
                self.generate(*rule_path, 'translation', 'port', rule_config['translation']['port'])

        if 'description' in rule_config:
            self.generate(*rule_path, 'description', format_description(rule_config['description']))
        if 'protocol' in rule_config:
            self.generate(*rule_path, 'protocol', rule_config['protocol'])
        if 'exclude' in rule_config:
            self.generate(*rule_path, 'exclude')
        if 'disable' in rule_config:
            self.generate(*rule_path, 'disable')
        if 'all' in rule_config and rule_config['all'] and self.operator == "delete":
            self.generate(*rule_path)

    def generate_commands(self, data=None, current_config=None, new_config=None):
        if not data:
            return []

        base_path = ['nat']

        try:
            if 'source' in data and 'rule' in data['source']:
                for rule_id, rule_config in data['source']['rule'].items():
                    rule_path = [*base_path, 'source', 'rule', rule_id]
                    self._process_rule(rule_path, rule_config)

            if 'destination' in data and 'rule' in data['destination']:
                for rule_id, rule_config in data['destination']['rule'].items():
                    rule_path = [*base_path, 'destination', 'rule', rule_id]
                    self._process_rule(rule_path, rule_config)

            return self.cmds

        except Exception as e:
            print(f"Error generating NAT commands: {str(e)}")
            return []
