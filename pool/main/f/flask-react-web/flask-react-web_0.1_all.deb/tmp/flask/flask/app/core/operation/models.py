from optparse import Option
from pydantic import BaseModel, RootModel, field_validator, Field
from typing import Optional, List, DefaultDict, Dict, Any
from app.core.operation.validate import validate_ipv4, validate_ipv6, validate_ip_range
from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, text
from app.log.logger import logger

class UserManagement(db.Model):

    __tablename__ = "vyos_user"
    id = Column(Integer, primary_key=True)
    user_name = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    status = Column(Boolean, default=True)
    role = Column(String, nullable=False)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))

    @classmethod
    def refresh(cls, users: list, app_context=None):
        try:
            logger.debug(f"Refresh users: {users}")

            if app_context:
                with app_context:
                    cls.truncate()
            else:
                cls.truncate()

            for user_data in users:
                if not isinstance(user_data, dict):
                    continue

                new_user = UserManagement(
                    user_name=user_data.get('user-name'),
                    full_name=user_data.get('full-name'),
                    status=not user_data.get('disable', False),
                    role=user_data.get('type', 'administrator')
                )

                if app_context:
                    with app_context:
                        db.session.add(new_user)
                else:
                    db.session.add(new_user)

            if app_context:
                with app_context:
                    db.session.commit()
            else:
                db.session.commit()

        except Exception as e:
            logger.error(f"Error refreshing users: {e}")

    @classmethod
    def serialize(cls, user):
        return {
            "user_name": user.user_name,
            "status": user.status,
            "full_name": user.full_name,
            "role": user.role
        }

    @classmethod
    def get_user_permission(cls, user_name):
        user = cls.query.filter_by(user_name=user_name).first()
        if user and user.role and user.role.lower() in ["administrator", "operator", "operator+"]:
            return user.role.lower()
        return None

class UserVerifyDTO(BaseModel):
    user_name: str
    full_name: Optional[str] = None
    password: Optional[str] = None
    disabled: bool
    role: str
    expiry_time: Optional[str] = None


class UpdateUserDTO(BaseModel):
    users: list[UserVerifyDTO]

class CreateInterfaceDTO(BaseModel):
    intf_type: str
    name: str
    address: str
    subnet: str
    desc: Optional[str] = None

    @field_validator('address')
    def validate_ip_address(cls, v):
        if not validate_ipv4(v) and not validate_ipv6(v):
            raise ValueError('Invalid IP address format')
        return v

    @field_validator('subnet')
    def validate_subnet(cls, v, info):
        try:
            # First check if subnet is a valid number
            if not v.isdigit():
                raise ValueError('Subnet must be a valid number')

            # Get the address value from the data
            address = info.data.get('address')
            if address:
                is_ipv6 = validate_ipv6(address)
                if not validate_ip_range(v, is_ipv6):
                    max_range = "128" if is_ipv6 else "32"
                    raise ValueError(f'Invalid subnet range (0-{max_range})')
            return v
        except ValueError as e:
            raise ValueError(str(e))

class UpdateInterfaceDTO(BaseModel):
    name: str
    intf_type: str
    desc: Optional[str] = None
    address: Optional[str] = None


class UpdateInterfaceByNameGeneralDTO(BaseModel):
    desc: Optional[str] = None

class UpdateInterfaceByNameLinkDTO(BaseModel):
    speed: Optional[str] = None
    duplex: Optional[str] = None
    

class GeneralDTO(BaseModel):
    enabled: Optional[bool] = None
    description: Optional[str] = None
    hwId: Optional[str] = None

class LinkDTO(BaseModel):
    autoNegotiation: Optional[bool] = None
    speed: Optional[str] = None
    duplex: Optional[str] = None
    mtu: Optional[int] = None

    
class IPv4StaticDTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    prefixLength: Optional[str|int] = None

class IPv4DHCPOptionsDTO(BaseModel):
    clientId: Optional[str] = None
    defaultRouteDistance: Optional[int] = None
    hostname: Optional[str] = None
    mtu: Optional[int] = None
    dontInstallDefaultRoute: Optional[bool] = None
    reject: Optional[bool] = None
    userClass: Optional[str] = None
    vendorClass: Optional[str] = None

class IPv4DHCPDTO(BaseModel):
    enabled: Optional[bool] = None
    options: IPv4DHCPOptionsDTO

class IPv4DTO(BaseModel):
    mode: Optional[str] = None
    static: IPv4StaticDTO
    dhcp: IPv4DHCPDTO

class IPv6StaticDTO(BaseModel):
    address: Optional[str] = None
    prefix: Optional[str|int] = None

class IPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    dontSendRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    pd: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class IPv6DHCPv6DTO(BaseModel):
    enabled: Optional[bool] = None
    requestPrefixDelegation: Optional[bool] = None
    options: IPv6DHCPv6OptionsDTO

class IPv6AutoconfDTO(BaseModel):
    enabled: Optional[bool] = None

class IPv6DelegatedDTO(BaseModel):
    enabled: Optional[bool] = None

class IPv6DTO(BaseModel):
    mode: Optional[str] = None
    static: IPv6StaticDTO
    dhcpv6: IPv6DHCPv6DTO
    autoconf: IPv6AutoconfDTO
    delegated: IPv6DelegatedDTO


class NetworkDTO(BaseModel):
    bridgeMode: Optional[bool] = None
    bridgeInterface: Optional[str] = None
    ipv4: IPv4DTO
    ipv6: IPv6DTO

class UpdateEthernetInterfaceByNameDTO(BaseModel):
    general: GeneralDTO
    link: LinkDTO
    network: NetworkDTO


class WifiSecurityDTO(BaseModel):
    type: Optional[str] = None
    encryption: Optional[str|list] = None


class ModeChannelWidthDTO(BaseModel):
    channelWidth: Optional[str] = None


class ModeChannelWidthMultipleDTO(BaseModel):
    channelWidth: Optional[list] = None


class WifiAdvancedDTO(BaseModel):
    hiddenSSID: Optional[bool] = None
    preventBridging: Optional[bool] = None
    managementFrameProtection: Optional[str] = None
    maxClients: Optional[int] = None
    beaconProtection: Optional[bool] = None
    disassociateOnFailures: Optional[bool] = None
    dedicatedThreadPerClient: Optional[bool] = None
    mode: Optional[str] = None
    acMode: Optional[ModeChannelWidthDTO] = None
    axMode: Optional[ModeChannelWidthDTO] = None
    nMode: Optional[ModeChannelWidthMultipleDTO] = None

class WifiIPv4StaticDTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    prefixLength: Optional[int] = None

class WifiIPv4DHCPOptionsDTO(BaseModel):
    clientId: str
    defaultRouteDistance: int
    hostname: str
    mtu: int
    dontInstallDefaultRoute: Optional[bool] = None
    reject: Optional[bool] = None
    userClass: Optional[str] = None
    vendorClass: Optional[str] = None

class WifiIPv4DHCPDTO(BaseModel):
    enabled: Optional[bool] = None
    options: WifiIPv4DHCPOptionsDTO

class WifiIPv4DTO(BaseModel):
    static: WifiIPv4StaticDTO
    dhcp: WifiIPv4DHCPDTO

class WifiIPv6StaticDTO(BaseModel):
    address: Optional[str] = None
    prefix: Optional[int] = None

class WifiIPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    dontSendRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    pd: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class WifiIPv6DHCPv6DTO(BaseModel):
    enabled: bool
    options: WifiIPv6DHCPv6OptionsDTO

class WifiIPv6DTO(BaseModel):
    mode: str
    static: WifiIPv6StaticDTO
    dhcpv6: WifiIPv6DHCPv6DTO

class WifiNetworkDTO(BaseModel):
    bridgeMode: Optional[bool] = None
    bridgeInterface: Optional[str] = None
    ipMode: Optional[str] = None
    ipv4: Optional[WifiIPv4DTO] = None
    ipv6: Optional[WifiIPv6DTO] = None

class DefaultRouteDTO(BaseModel):
    GHz5: Optional[str] = None
    GHz24: Optional[str] = None

class WifiClientIPv4DHCPOPTIONSDTO(BaseModel):
    defaultRoute: DefaultRouteDTO


class WifiClientIPv4DTO(BaseModel):
    address: Optional[str] = None
    netmask: Optional[str] = None
    gateway: Optional[str] = None
    dhcpOptions: Optional[WifiClientIPv4DHCPOPTIONSDTO] = None

class WifiClientIPv6DHCPv6OptionsDTO(BaseModel):
    duid: Optional[str] = None
    noRelease: Optional[bool] = None
    parametersOnly: Optional[bool] = None
    rapidCommit: Optional[bool] = None
    temporaryAddress: Optional[bool] = None

class WifiClientIPv6DTO(BaseModel):
    address: Optional[str] = None
    prefix: Optional[int] = None
    dhcpv6Options: Optional[WifiClientIPv6DHCPv6OptionsDTO] = None

class WifiClientNetworkDTO(BaseModel):
    ipConfig: Optional[str] = None
    ipv4: Optional[WifiClientIPv4DTO] = None
    ipv6: Optional[WifiClientIPv6DTO] = None

class WifiClientDTO(BaseModel):
    enabled: Optional[bool] = None
    enabled5: Optional[bool] = None
    enabled24: Optional[bool] = None
    ssid: Optional[str] = None
    password: Optional[str] = None
    security: Optional[str] = None
    network: Optional[WifiClientNetworkDTO] = None

class AccessControlDTO(BaseModel):
    enabled: Optional[bool] = None
    acceptList: Optional[List[str]] = None
    denyList: Optional[List[str]] = None
    mode: Optional[str] = None

class WifiInterfaceDTO(BaseModel):
    enabled: bool
    enabled5: bool
    enabled24: bool
    description: str
    ssid: str
    security: WifiSecurityDTO
    password: str
    advanced: WifiAdvancedDTO
    network: WifiNetworkDTO
    client: WifiClientDTO
    accessControl: AccessControlDTO
    countryCode: Optional[str] = None


class SystemDTO(BaseModel):
    countryCode: Optional[str] = None


class PoolDTO(BaseModel):
    description: Optional[str] = None
    dhcp_type: Optional[str] = None
    enabled: Optional[bool] = None
    range_end: str
    range_start: str
    interface: Optional[str] = None
    lease_time: Optional[str] = None
    subnet: str
    dhcp_name: str
    subnet_id: str
    default_router: Optional[str] = None
    name_server: Optional[str] = None
    domain_name: Optional[str] = None
    ip_range_type: Optional[str] = None
    boot_file: Optional[str] = None
    authoritative: Optional[bool] = None


class UpdateWifiInterfaceByNameDTO(BaseModel):
    wifi: WifiInterfaceDTO
    dhcp: PoolDTO
    system: SystemDTO


class OpenVPNGeneralDTO(BaseModel):
    enabled: bool
    description: Optional[str] = None
    mode: Optional[str] = None

class OpenVPNClientIpPoolDTO(BaseModel):
    disabled: bool
    start: str
    stop: str
    subnetMask: str

class OpenVPNClientIpv6PoolDTO(BaseModel):
    disabled: bool
    base: str

class OpenVPNClientOverridesDTO(BaseModel):
    name: str
    ip: str
    pushRoute: List[str]
    subnet: List[str]

class OpenVPNServerDTO(BaseModel):
    bridge: Optional[str] = None
    clientIpPool: OpenVPNClientIpPoolDTO
    clientIpv6Pool: OpenVPNClientIpv6PoolDTO
    client: List[OpenVPNClientOverridesDTO]
    domainName: Optional[str] = None
    maxConnections: Optional[int] = None
    nameServer: Optional[List[str]] = None
    pushRoutes: Optional[List[str]] = None
    rejectUnconfiguredClients: bool
    subnet: Optional[str] = None
    topology: Optional[str] = None

class OpenVPNKeepAliveDTO(BaseModel):
    failureCount: int
    interval: int

class OpenVPNAdvancedDTO(BaseModel):
    ipVersion: str
    keepAlive: OpenVPNKeepAliveDTO
    persistentTunnel: bool
    useLzoCompression: bool
    replaceDefaultRoute: bool

class OpenVPNDTO(BaseModel):
    deviceType: str
    localAddress: str
    localHost: List[str]
    localPort: int
    protocol: str
    remoteAddress: str
    remoteHost: List[str]
    remotePort: int
    server: OpenVPNServerDTO
    advanced: OpenVPNAdvancedDTO

class OpenVPNTlsDTO(BaseModel):
    authKey: str
    caCert: List[str]
    certificate: List[str]
    cryptKey: str
    dhParams: str
    peerFingerprint: List[str]
    role: str
    tlsVersionMin: str

class OpenVPNEncryptionDTO(BaseModel):
    cipher: str
    dataCiphers: List[str]

class OpenVPNHashDTO(BaseModel):
    algorithm: str

class OpenVPNSecurityDTO(BaseModel):
    tls: OpenVPNTlsDTO
    encryption: OpenVPNEncryptionDTO
    hash: OpenVPNHashDTO
    sharedSecretKey: str

class UpdateOpenVPNInterfaceByNameDTO(BaseModel):
    general: OpenVPNGeneralDTO
    openvpn: OpenVPNDTO
    security: OpenVPNSecurityDTO

class DeleteInterfaceDTO(BaseModel):
    name: str
    intf_type: str

class DeleteInterfaceListDTO(RootModel):
    root: List[DeleteInterfaceDTO]
    
    def __iter__(self):
        return iter(self.root)

    def __getitem__(self, item):
        return self.root[item]

class DeleteInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    address: str


class UpdateInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    current_address: str
    new_address: str


class CreateInterfaceAddressDTO(BaseModel):
    name: str
    intf_type: str
    address: str

class UpdateSystemDatetimeDTO(BaseModel):
    date: str
    time: str
    timezone: str

class UpdateSystemInfoDTO(BaseModel):
    systemName: str
    domainName: str
    dateTime: str
    timezone: str
    ipv4: bool

class WireguardPeerDTO(BaseModel):
    allowed_ips: Optional[List[str]] = None
    preshared_key: Optional[str] = None
    host_name: Optional[str] = None
    persistent_keepalive: Optional[int] = None
    address: Optional[str] = None
    port: Optional[int] = None


class UpdateWireguardInterfaceByNameDTO(BaseModel):
    enabled: Optional[bool] = None
    description: Optional[str] = None
    address: Optional[List[str]] = None
    listen_port: Optional[int] = None
    private_key: Optional[str] = None
    peer: Optional[Dict[str, WireguardPeerDTO]] = None
    mtu: Optional[int] = None
    dns_retry: Optional[int] = None


class CreateWireguardInterfaceDTO(BaseModel):
    name: str
    enabled: bool
    description: Optional[str] = None
    address: List[str]
    listen_port: int
    private_key: str
    peer: Dict[str, WireguardPeerDTO]
    mtu: Optional[int] = None
    dns_retry: Optional[int] = None