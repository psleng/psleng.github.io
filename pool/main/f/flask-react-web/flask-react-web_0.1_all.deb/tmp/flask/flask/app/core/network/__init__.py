from flask import Blueprint

vyos_network_bp = Blueprint('network', __name__)

from . import routes