from app.core.api.http.cmd.command import Command

class NameServerCommand(Command):

    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.attributes = {
            'name_servers': None,  # List[dict] with 'address' and optional 'port'
            'ip_address_type': None  # 'ipv4' or 'ipv6'
        }
        # Update attributes with provided values
        for key, value in kwargs.items():
            if key in self.attributes:
                self.attributes[key] = value

    def _build_command(self, *path_elements: str) -> str:
        """Build a cmd string in VyOS format"""
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    
    def generate_commands(self) -> list[str]:
        cmds = []
        if not self.attributes['name_servers']:
            return []
        base_path = [self.resource, 'name-server']

        match self.operator:
            case "set":
                for ns in self.attributes['name_servers']:
                    ns_cmd = [*base_path, ns['address']]
                    if 'port' in ns:
                        ns_cmd.extend(['port', str(ns['port'])])
                    cmds.append(self._build_command(*ns_cmd))

            case "delete":
                for ns in self.attributes['name_servers']:
                    ns_cmd = [*base_path, ns['address']]
                    if 'port' in ns:
                        ns_cmd.extend(['port', str(ns['port'])])
                    cmds.append(self._build_command(*ns_cmd))

            case _:
                raise ValueError(f"Invalid operator: {self.operator}")

        return cmds