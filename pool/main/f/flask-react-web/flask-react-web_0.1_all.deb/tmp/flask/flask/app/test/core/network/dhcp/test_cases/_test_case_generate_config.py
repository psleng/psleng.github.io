import pytest

test_dhcp_cmd_set = [
    pytest.param(
        {
            "listen_interface": ["eth0", "eth1"],
            "shared_network_name": {
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                            "subnet_id": "1",
                            "range": {
                                "range_1": {
                                    "start": "192.168.1.100",
                                    "stop": "192.168.1.200"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "service dhcp-server listen-interface eth0",
            "service dhcp-server listen-interface eth1",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 subnet-id 1",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 start 192.168.1.100",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 stop 192.168.1.200",
        ],
        id="test_dhcp_set_commands"
    )
]

test_dhcp_cmd_set_v6 = [
    pytest.param(
        {
            "listen_interface": ["eth0"],
            "shared_network_name": {
                "IPv6LAN": {
                    "subnet": {
                        "2001:db8::/64": {
                            "subnet_id": "1",
                            "range": {
                                "range_1": {
                                    "start": "2001:db8::100",
                                    "stop": "2001:db8::200"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "service dhcpv6-server listen-interface eth0",
            'service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 subnet-id 1', 
            "service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 range range_1 start 2001:db8::100",
            "service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 range range_1 stop 2001:db8::200",
        ],
        id="test_dhcpv6_set_commands"
    )
]

test_dhcp_cmd_delete = [
    pytest.param(
        {
            "listen_interface": ["eth0"],
            "shared_network_name": {
                "LAN": {
                    "subnet": {
                        "192.168.1.0/24": {
                            "subnet_id": "1",
                            "range": {
                                "range_1": {
                                    "start": "192.168.1.100",
                                    "stop": "192.168.1.200"
                                }
                            }
                        }
                    }
                }
            }
        },
        [
            "service dhcp-server listen-interface eth0",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 subnet-id 1",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 start 192.168.1.100",
            "service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 stop 192.168.1.200"
        ],
        id="test_dhcp_delete_commands"
    )
]

test_process_commands = [
    pytest.param(
        (
            [
                "set service dhcp-server listen-interface eth0",
                "set service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 subnet-id 1",
                "set service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 start 192.168.1.100",
                "set service dhcp-server shared-network-name LAN subnet 192.168.1.0/24 range range_1 stop 192.168.1.200"
            ],
            {
                "service": {
                    "dhcp_server": {
                        "listen_interface": ["eth0"],
                        "shared_network_name": {
                            "LAN": {
                                "subnet": {
                                    "192.168.1.0/24": {
                                        "subnet_id": "1",
                                        "range": {
                                            "range_1": {
                                                "start": "192.168.1.100",
                                                "stop": "192.168.1.200"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_dhcp_commands"
    ),
    pytest.param(
        (
            [
                "set service dhcpv6-server listen-interface eth0",
                "set service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 subnet-id 1",
                "set service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 range range_1 start 2001:db8::100",
                "set service dhcpv6-server shared-network-name IPv6LAN subnet 2001:db8::/64 range range_1 stop 2001:db8::200"
            ],
            {
                "service": {
                    "dhcpv6_server": {
                        "listen_interface": ["eth0"],
                        "shared_network_name": {
                            "IPv6LAN": {
                                "subnet": {
                                    "2001:db8::/64": {
                                        "subnet_id": "1",
                                        "range": {
                                            "range_1": {
                                                "start": "2001:db8::100",
                                                "stop": "2001:db8::200"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        ),
        id="test_process_dhcpv6_commands"
    ),
    pytest.param(
        (
            [
                "set service dhcp-relay listen-interface eth2",
                "set service dhcp-relay server 192.168.2.1"
            ],
            {
                "service": {
                    "dhcp_relay": {
                        "listen_interface": ["eth2"],
                        "server": ["192.168.2.1"]
                    }
                }
            }
        ),
        id="test_process_dhcp_relay_commands"
    )
]
