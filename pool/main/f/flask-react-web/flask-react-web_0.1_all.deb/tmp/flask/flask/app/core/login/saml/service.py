from app.core.api.http.http_request import Action
from app.core.login.saml.command_saml import SamlCommand
from app.core.api.http.http_request import Action, SHOW_SAML_CONFIG
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
import json

def auth_saml(provider, data):
    api_data = {
        "op": "SAML",
        "data": data
    }

    resp = provider.http_service.send_request(
        action=Action.AUTH,
        data=json.dumps(api_data),
        verify=False
    )

    resp_json = resp.json()
    if resp_json.get("success") != True:
        raise Exception(f"{resp_json.get('error', 'Unknown error')}")

    resp_data = resp_json.get("data")
    return resp_data

def fetch_saml_config(provider, data):
    data = provider.http_service.send_request(
        action=Action.RETRIEVE, 
        data=SHOW_SAML_CONFIG, 
        verify=False
    )

    data_json = data.json()
    if data_json.get("success") != True:
        raise Exception(f"{data_json.get('error', 'Unknown error')}")
    
    saml_config = data_json.get('data')
    if saml_config is None:
        return {}
    return saml_config

def verify_saml(provider, data):
    current_config = data.get('current')
    new_config = data.get('new')
    diff = data.get('diff')

    # Generate set commands for new config
    saml_set_cmd = SamlCommand(operator='set', resource='system')
    saml_set_cmd.generate_commands(diff['created'], current_config, new_config)
    sc = saml_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    # Generate delete commands for removed config
    saml_delete_cmd = SamlCommand(operator='delete', resource='system')
    saml_delete_cmd.generate_commands(diff['deleted'], current_config, new_config)
    dc = saml_delete_cmd.get_commands()
    new_del_configs = process_commands(dc)

    # Get current system login config
    service = "system"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"system": {"login": {"saml": curr_config}}} if curr_config else {"system": {"login": {}}}

    # Merge configurations
    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    # Verify the merged configuration
    if merged_config:
        verify_result = provider.verify_service.call_verify(service, merged_config)
        return verify_result
    
    return None

def update_saml_config(provider, data):
    diff = data.get('diff')
    current_saml_config = data.get('current')
    new_saml_config = data.get('new')

    # Generate set commands
    saml_set_cmd = SamlCommand(operator='set', resource='system')
    set_cmds = saml_set_cmd.generate_commands(diff['created'], current_saml_config, new_saml_config)
    sc = saml_set_cmd.get_commands()
    new_set_configs = process_commands(sc)

    # Generate delete commands
    saml_delete_cmd = SamlCommand(operator='delete', resource='system')
    delete_cmds = saml_delete_cmd.generate_commands(diff['deleted'], current_saml_config, new_saml_config)
    dc = saml_delete_cmd.get_commands()
    new_del_configs = process_commands(dc)

    # Validate commands
    service = "system_login"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"system": {"login": curr_config}} if curr_config else {"system": {"login": {}}}

    merged_del_config = merge_dicts_delete(current_config, new_del_configs)
    merged_config = merge_dicts_set(merged_del_config, new_set_configs)

    # Verify configuration
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    
    if verify and str(verify) != "None" and str(verify) != "":
        raise Exception(verify)

    # Execute commands
    executed_cmds = list(set(set_cmds)) + list(set(delete_cmds))
    if executed_cmds:
        res = provider.http_service.send_request(
            action=Action.CONFIGURE,
            data=executed_cmds,
            verify=False
        ).json()
        
        return [{
            "cmd": executed_cmds,
            "success": res.get('success'),
            "error": res.get('error')
        }]

    return []

def fetch_saml_info(provider, data):
    api_data = {
        "op": "SAML",
        "data": {
            "type": "INFO"
        }
    }

    resp = provider.http_service.send_request(
        action=Action.AUTH,
        data=json.dumps(api_data),
        verify=False
    )

    resp_json = resp.json()
    if resp_json.get("success") != True:
        raise Exception(f"{resp_json.get('error', 'Unknown error')}")

    resp_data = resp_json.get("data")
    return resp_data
