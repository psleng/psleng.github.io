from flask import Blueprint

cli_bp = Blueprint('cli', __name__)

from . import routes
from .models import *