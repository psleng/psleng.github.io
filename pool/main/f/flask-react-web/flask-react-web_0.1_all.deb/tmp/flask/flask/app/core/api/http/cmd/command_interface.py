from app.core.api.http.cmd.command import Command

class InterfaceCommand(Command):

    def __init__(self, **kwargs):
        super().__init__(operator=kwargs.get('operator'), resource=kwargs.get('resource'))
        self.attributes = {
            'intf_type': None,
            'name': None, 
            'desc': None,
            'address': None,
            'speed': None,
            'mtu': None,
            'duplex': None,
            'redirect': None
        }
        # Update attributes with provided values
        for key, value in kwargs.items():
            if key in self.attributes:
                self.attributes[key] = value

    def _build_command(self, *path_elements: str) -> str:
        path = ','.join(f'"{element}"' for element in path_elements)
        return f'{{"op":"{self.operator}", "path": [{path}]}}'

    def generate_commands(self) -> list[str]:
        if not self.attributes['name']:
            return []
        cmds = []
        base_path = [
            self.resource,
            self.attributes['intf_type'],
            self.attributes['name']
        ]

        match self.operator:
            case "set":
                # Generate set commands for each configured attribute
                if self.attributes['desc']:
                    cmds.append(self._build_command(*base_path, "description", self.attributes['desc']))
                if self.attributes['address']:
                    cmds.append(self._build_command(*base_path, "address", self.attributes['address']))
                if self.attributes['speed']:
                    cmds.append(self._build_command(*base_path, "speed", self.attributes['speed']))
                if self.attributes['mtu']:
                    cmds.append(self._build_command(*base_path, "mtu", self.attributes['mtu']))
                if self.attributes['duplex']:
                    cmds.append(self._build_command(*base_path, "duplex", self.attributes['duplex']))
                if self.attributes['redirect']:
                    cmds.append(self._build_command(*base_path, "redirect", self.attributes['redirect']))

            case "delete":
                # Generate delete commands
                if self.attributes['desc']:
                    cmds.append(self._build_command(*base_path, "description", self.attributes['desc']))
                if self.attributes['address']:
                    cmds.append(self._build_command(*base_path, "address", self.attributes['address']))
                if not (self.attributes['desc'] or self.attributes['address']):
                    cmds.append(self._build_command(*base_path))

            case _:
                raise ValueError(f"Invalid operator: {self.operator}")

        self.commands = cmds
        return self.commands
