"""Test class for Firewall final end-to-end testing"""

import pytest
from copy import deepcopy
from app.test.core.base import TestFinal
from app.core.security.cmd.command_firewall import FirewallCommand
from app.core.security.parser.firewall import parse_to_firewall_config
from app.core.security.models import UpdateFirewallDTO as FirewallUpdateDTO
from app.core.utils.process_config import merge_dicts_set, merge_dicts_delete
from app.test.core.security.firewall.test_cases._test_case_final import test_update_final


class TestFirewallFinal(TestFinal):
    __test__ = False
    
    @pytest.fixture
    def cmd_set(self):
        return FirewallCommand(operator='set')
    
    @pytest.fixture
    def cmd_delete(self):
        return FirewallCommand(operator='delete')

    @pytest.fixture
    def success_verification(self):
        return ['None', '']

    @pytest.fixture
    def parser(self):
        return parse_to_firewall_config
    
    @pytest.fixture
    def dto_model(self):
        return FirewallUpdateDTO

    @pytest.mark.parametrize("test_data", test_update_final)
    def test_ntp_update_final(self, success_verification, parser, dto_model, test_service_provider, cmd_set, cmd_delete, test_data):
        super()._update_final(
            success_verification=success_verification,
            parser=parser,
            dto_model=dto_model,
            test_service_provider=test_service_provider,
            cmd_set=cmd_set,
            cmd_delete=cmd_delete,
            test_data=test_data
        )