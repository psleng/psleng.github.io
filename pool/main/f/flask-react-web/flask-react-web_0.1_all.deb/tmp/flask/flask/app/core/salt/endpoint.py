from flask import Flask, jsonify, request
from app.core import salt

local = salt.client.LocalClient()
app = Flask(__name__)

@app.route('/proxy/run', methods=['POST'])
def proxy_run():
    try:
        data = request.get_json()
        minion = data['minion']
        command = data['cmd']
        arg = data['arg']
        result = local.cmd(minion, command, arg)

        return result, 200
    except Exception as e:
        return str(e), 400