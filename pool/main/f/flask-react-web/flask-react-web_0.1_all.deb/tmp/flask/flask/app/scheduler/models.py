from app.db.database import db
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, text

class Job(db.Model):

    __tablename__ = "scheduler_jobs"

    id = Column(Integer, primary_key=True)
    job_id = Column(String, nullable=False)
    trigger = Column(String, nullable=False, default="interval")
    seconds = Column(Integer, nullable=False, default=60)

    @classmethod
    def truncate(cls):
        db.session.execute(text(f"DELETE FROM {cls.__tablename__}"))
    

    @classmethod
    def create(cls, job):
        new_job = Job(
            job_id=job.get('job_id'),
            trigger=job.get('trigger'),
            seconds=job.get('seconds'),
        )
        db.session.add(new_job)
        db.session.commit()
        return True