from datetime import datetime
import pytz

def system_timestamp():
    current_time = datetime.now()
    return current_time.strftime("%Y-%m-%d"), current_time.strftime("%H:%M:%S")


def system_utc_timestamp():
    utc_time = datetime.now(pytz.utc)
    formatted_time = utc_time.strftime('%a %b %d %I:%M:%S %p UTC %Y')
    return formatted_time
