from app.core.utils.cmd_linux import run_linux_cmd
from app.auth.models import User, TempUserExpiryTime
from app.log.logger import logger
from app.core.api.http.cmd.command_auth import AuthCommand
from flask import session
from app.core.utils.process_config import process_commands, merge_dicts_set, merge_dicts_delete
from app.socket.socket_manager import socket_manager
from app.core.api.http.http_request import Action
import pprint
from app.auth.models import User
from app.core.operation.models import UserManagement
from app.core.api.http.srv.parser import parse_to_user_config, parse_user_config_to_db
from uuid import uuid4
from app.core.api.http.cmd.command import SHOW_USER_CONFIG
from app.core.utils.check_os import is_linux
from app.config import global_config

def _create_user_linux_cmd(user_name, password):
    logger.debug(f"[START] [_create_user_linux_cmd] for user: {user_name}")
    cmd_str = f"sudo userdel -r -f {user_name} ; sudo useradd --create-home --no-user-group --shell /bin/vbash --home /home/{user_name} --group frr,frrvty,vyattacfg,sudo,adm,dip,disk,_kea -p $(openssl passwd -6 {password}) {user_name} ;"
    logger.debug(f"Executing command: {cmd_str}")
    _, cmd_error = run_linux_cmd(cmd_str)
    if cmd_error:
        logger.error(f"Error creating linux user {user_name}: {cmd_error}")
    else:
        logger.debug(f"Successfully created linux user: {user_name}")
    logger.debug(f"[END] [_create_user_linux_cmd] for user: {user_name}")
    return cmd_error


def _delete_user_linux_cmd(user_name):
    logger.debug(f"[START] [_delete_user_linux_cmd] for user: {user_name}")
    cmd_str = f"sudo pkill -u {user_name} ; sudo userdel -r -f {user_name}"
    logger.debug(f"Executing command: {cmd_str}")
    _, cmd_error = run_linux_cmd(cmd_str)
    if cmd_error:
        logger.error(f"Error deleting linux user {user_name}: {cmd_error}")
    else:
        logger.debug(f"Successfully deleted linux user: {user_name}")
    logger.debug(f"[END] [_delete_user_linux_cmd] for user: {user_name}")
    return cmd_error

def create_tmp_user(user_data):
    username = user_data['username']
    logger.debug(f"[START] [create_tmp_user] for user: {username} with data: {user_data}")
    
    logger.debug(f"Creating Linux user '{username}'")
    _create_user_linux_cmd(username, user_data['password'])
    
    logger.debug(f"Creating database entry for user '{username}'")
    User.create_user(username, user_data['password'])
    
    logger.debug(f"Setting expiry time for user '{username}'")
    TempUserExpiryTime.create_expiry_time(username, user_data['expiry_time'])
    
    logger.debug(f"Scheduling deletion for user '{username}'")
    expiry_datetime = TempUserExpiryTime.convert_expiry_to_datetime(user_data['expiry_time'])
    if expiry_datetime and global_config.app_scheduler:
        job_id = f"delete_tmp_user_{username}"
        logger.debug(f"Scheduling job '{job_id}' to run at {expiry_datetime}")
        global_config.app_scheduler.add_job(
            id=job_id,
            func=delete_tmp_user,
            trigger='date',
            run_date=expiry_datetime,
            args=[{'username': username}],
            replace_existing=True
        )
    logger.debug(f"[END] [create_tmp_user] for user: {username}")

def delete_all_tmp_users():
    try:
        records = TempUserExpiryTime.get_all_records()
        for record in records:
            if record.user:
                delete_tmp_user({'username': record.user.email})
                if is_linux():
                    _delete_user_linux_cmd(record.user.email)
    except Exception as e:
        logger.error(f"Error deleting temporary users: {e}")


def delete_tmp_user(user_data):
    username = user_data['username']
    logger.debug(f"[START] [delete_tmp_user] for user: {username}")

    logger.debug(f"Deleting Linux user '{username}'")
    _delete_user_linux_cmd(username)

    logger.debug(f"Deleting expiry time from database for user '{username}'")
    TempUserExpiryTime.delete_expiry_time(username, app_context=global_config.get_app_context())

    logger.debug(f"Deleting user from database: '{username}'")
    User.delete_user(user_data, app_context=global_config.get_app_context())

    logger.debug(f"[END] [delete_tmp_user] for user: {username}")


def update_tmp_user(user_data):
    username = user_data['username']
    logger.debug(f"[START] [update_tmp_user] for user: {username} with data: {user_data}")
    password = user_data.get('password')
    expiry_time = user_data.get('expiry_time')

    if password:
        logger.debug(f"Updating password for user '{username}'")
        logger.debug(f"Re-creating linux user '{username}' with new password")
        _delete_user_linux_cmd(username)
        _create_user_linux_cmd(username, password)
        logger.debug(f"Updating password in database for user '{username}'")
        User.update_password(username, password)

    if expiry_time:
        logger.debug(f"Updating expiry time for user '{username}' to {expiry_time}")
        TempUserExpiryTime.update_expiry_time(username, expiry_time)

        logger.debug(f"Rescheduling deletion for user '{username}'")
        expiry_datetime = TempUserExpiryTime.convert_expiry_to_datetime(expiry_time)
        if expiry_datetime and global_config.app_scheduler:
            job_id = f"delete_tmp_user_{username}"
            logger.debug(f"Rescheduling job '{job_id}' to run at {expiry_datetime}")
            global_config.app_scheduler.add_job(
                id=job_id,
                func=delete_tmp_user,
                trigger='date',
                run_date=expiry_datetime,
                args=[{'username': username}],
                replace_existing=True
            )
    logger.debug(f"[END] [update_tmp_user] for user: {username}")


def update_linux_user(diff_create, diff_delete, db_config):
    """
        Update based on different scenarios:
        - Delete user: user in diff_delete and db_config, but not in diff_create
        - Create user: user in diff_create but not in diff_delete and not in db_config
        - Update user: user in diff_create and db_config
        
        db_config is result of parse_user_db_to_user_config()['login']
    """
    logger.debug(f"[START] [update_linux_user]")
    logger.debug(f"diff_create: {diff_create}")
    logger.debug(f"diff_delete: {diff_delete}")
    logger.debug(f"db_config: {db_config}")

    if 'login' in diff_create:
        diff_create = diff_create['login']
    if 'login' in diff_delete:
        diff_delete = diff_delete['login']

    if not is_linux():
        logger.debug("Not a Linux system. Skipping execution.")
        return
    
    def is_diff_valid(diff):
        return isinstance(diff, dict) and (diff == {} or ('user' in diff and isinstance(diff['user'], dict)))

    if not is_diff_valid(diff_create) or not is_diff_valid(diff_delete):
        logger.error(f"Invalid diff format. diff_create: {diff_create}, diff_delete: {diff_delete}")
        return

    db_users = db_config.get('user', {})
    create_users = diff_create.get('user', {})
    delete_users = diff_delete.get('user', {})

    logger.debug(f"Users to consider for deletion: {list(delete_users.keys())}")
    logger.debug(f"Users to consider for creation: {list(create_users.keys())}")
    logger.debug(f"Users in DB: {list(db_users.keys())}")

    # Scenario 1: Delete user
    logger.debug("--- Processing Deletions ---")
    for user_name in delete_users:
        if user_name in db_users and user_name not in create_users:
            logger.debug(f"Condition met: Deleting user '{user_name}'")
            delete_tmp_user({'username': user_name})

    # Scenario 2: Create user
    logger.debug("--- Processing Creations ---")
    for user_name, user_data in create_users.items():
        if user_name not in db_users:
            logger.debug(f"Condition met: Creating user '{user_name}'")
            password = user_data.get('authentication', {}).get('plaintext-password')
            expiry_time = user_data.get('expiry-time')
            if password and expiry_time:
                create_tmp_user({
                    'username': user_name,
                    'password': password,
                    'expiry_time': expiry_time
                })
            else:
                logger.error(f"Password or expiry_time not found for new user: {user_name}")

    # Scenario 3: Update user
    logger.debug("--- Processing Updates ---")
    for user_name, user_data in create_users.items():
        if user_name in db_users:
            logger.debug(f"Condition met: Updating user '{user_name}'")
            update_payload = {'username': user_name}
            password = user_data.get('authentication', {}).get('plaintext-password')
            expiry_time = user_data.get('expiry-time')

            if password:
                update_payload['password'] = password
            if expiry_time:
                update_payload['expiry_time'] = expiry_time
            
            if 'password' in update_payload or 'expiry_time' in update_payload:
                update_tmp_user(update_payload)
            else:
                logger.warning(f"No password or expiry_time found for updating user: {user_name}")
    logger.debug("[END] [update_linux_user]")

def fetch_user_config(provider, data):
    data = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_USER_CONFIG, verify=False)
    user_config = data.json()['data']
    logger.debug("User config: ")
    logger.debug(user_config)
    if user_config is None:
        return {}
    return user_config

def update_user(provider, data):
    logger.debug(f"[update_user] --- Updating User --- ")
    logger.debug(f"[update_user] Input data: {pprint.pformat(data)}")
    username = session['username']
    diff = data.get('diff')
    current_user_config = data.get('current')
    current_db_config = data.get('current_db')

    new_user_config = data.get('new')
    logger.debug(f"[update_user] Diff data: {pprint.pformat(diff)}")

    update_linux_user(diff['created'], diff['deleted'], current_db_config)

    r=[]
    ## Generate Set Commands
    set_cmds = []
    user_set_cmd = AuthCommand(operator='set', resource='system')
    set_cmds = user_set_cmd.generate_commands(diff['created'], current_user_config, new_user_config)
    sc = user_set_cmd.get_commands()
    logger.debug(f"[update_user] Set commands generated: {pprint.pformat(sc)}")
    new_set_configs = process_commands(sc)
    logger.debug(f"[update_user] Processed set configs: {pprint.pformat(new_set_configs)}")

    #Generate delete commands
    delete_cmds = []
    user_del_cmd = AuthCommand(operator='delete', resource='system')

    delete_cmds = user_del_cmd.generate_commands(diff['deleted'], current_user_config, new_user_config)
    dc = user_del_cmd.get_commands()
    logger.debug(f"[update_user] Delete commands generated: {pprint.pformat(dc)}")
    new_del_configs = process_commands(dc)
    logger.debug(f"[update_user] Processed delete configs: {pprint.pformat(new_del_configs)}")


    ## Validate commands
    service = "system_login"
    curr_config = provider.verify_service.call_get_config(service)
    current_config = {"system": {"login": curr_config}}
    logger.debug(f"[update_user] Current config for validation: {pprint.pformat(current_config)}")

    merged_del_config = merge_dicts_delete(current_config, new_del_configs, aggressive=True)
    logger.debug(f"[update_user] Merged delete config: {pprint.pformat(merged_del_config)}")

    merged_config = merge_dicts_set(merged_del_config, new_set_configs)
    logger.debug(f"[update_user] Final merged config: {pprint.pformat(merged_config)}")
 
    verify = None
    if merged_config:
        verify = provider.verify_service.call_verify(service, merged_config)
    logger.debug(f"[update_user] Verification result: {pprint.pformat(verify)}")

    if str(verify) != "None" and str(verify) != "":
        logger.error(f"[update_user] Validation Error: {pprint.pformat(verify)}")
        return Exception(verify)
    
    # Update DB
    logger.debug(f"[update_user] Merged user data for DB: {merged_config}")
    parsed_merged_config = parse_user_config_to_db(merged_config)
    logger.debug(f"[update_user] Parsed merged user data for DB: {parsed_merged_config}")
    UserManagement.refresh(parsed_merged_config)

    # Emit Notification
    socket_manager.emit_to_user(
        username,
        event='notification',
        data={
                "id": str(uuid4()),
                "type": "ignore",
                "title": "Success: Update Users",
                "content": "Users are successfully updated"
            }
    )
    executed_cmds = list(set(set_cmds)) + list(set(delete_cmds))

    # Make sure all of commands are unique
    cmds = executed_cmds
    logger.debug(f"[update_user] Final commands to execute: {pprint.pformat(cmds)}")

    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False).json()
        logger.debug(f"[update_user] Command execution result: {res}")
        r.append({"cmd": cmds, "success": res['success'], "error": res['error']})

    logger.debug(f"[update_user] --- End Updating User --- ")
    return r


def verify_user(provider, data):
    logger.debug(f"[verify_user] --- Verifying User ---")
    logger.debug(f"[verify_user] Input data: {data}")
    service = "system_login"
    logger.debug(f"[verify_user] Service: {service}")

    current_user = provider.verify_service.call_get_config(service)
    logger.debug(f"[verify_user] Current user config from provider: {current_user}")

    if not isinstance(current_user, dict):
        current_user = {}
    
    logger.debug(f"[verify_user] Current user config before update: {current_user}")
    
    update_data = {"user": data}
    current_user.update(update_data)
    logger.debug(f"[verify_user] User config after update: {current_user}")

    verify = provider.verify_service.call_verify(service, current_user)
    logger.debug(f"[verify_user] Verification result: {verify}")
    logger.debug(f"[verify_user] --- End Verifying User ---")
    return verify
    
