from app.core.api.http.cmd.command import Command


class WireguardCommand(Command):
    """
    Command class for Wireguard Interface
    Support the following VyOS command:

    - set/delete interfaces wireguard <interface-name> disable
    - set/delete interfaces wireguard <interface-name> description <description-text>
    - set/delete interfaces wireguard <interface-name> address <x.x.x.x/n | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces wireguard <interface-name> private-key <private-key-string>
    - set/delete interfaces wireguard <interface-name> public-key <public-key-string>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> description <description-text>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> disable
    - set/delete interfaces wireguard <interface-name> peer <peer-name> address {x.x.x.x | h:h:h:h:h:h:h:h}
    - set/delete interfaces wireguard <interface-name> peer <peer-name> port <1-65535>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> allowed-ips <x.x.x.x/n | h:h:h:h:h:h:h:h/x>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> host-name <hostname-text>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> persistent-keepalive <1-65535>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> preshared-key <passphrase>
    - set/delete interfaces wireguard <interface-name> peer <peer-name> public-key <public-key>
    - set/delete interfaces wireguard <interface-name> max-dns-retry <1-15>
    - set/delete interfaces wireguard <interface-name> mtu <68-16000>
    - set/delete interfaces wireguard <interface-name> port <1-65535>

    """

    def __init__(self, **kwargs):
        super().__init__(
            operator=kwargs.get('operator', 'set'),
            resource=kwargs.get('resource', 'wireguard')
        )
        self.cmds = []

    def _generate_cmd(self, *args):
        processed_args = [f'"{arg}"' if ' ' in str(arg) else str(arg) for arg in args]
        self.cmds.append(' '.join(processed_args))

    def get_commands(self):
        return self.cmds

    def generate_commands(self, data, current_config=None, new_config=None):
        if not data:
            return []

        for iface_name, iface_config in data.items():
            base_path = ["interfaces", self.resource, iface_name]

            simple_keys = ['disable', 'description', 'private-key', 'public-key', 'port', 'mtu', 'max-dns-retry']
            for key in simple_keys:
                if key in iface_config:
                    value = iface_config[key]
                    if isinstance(value, bool) and value:
                        self._generate_cmd(self.operator, *base_path, key)
                    elif not isinstance(value, bool):
                        self._generate_cmd(self.operator, *base_path, key, value)

            if 'address' in iface_config:
                for addr in iface_config['address']:
                    if addr:
                        self._generate_cmd(self.operator, *base_path, 'address', addr.strip())

            if 'peer' in iface_config:
                self._process_peer_config(base_path, iface_config['peer'])

        return self.get_commands()

    def _process_peer_config(self, base_path, peer_config):
        for peer_name, peer_attrs in peer_config.items():
            peer_path = base_path + ['peer', peer_name]

            simple_keys = ['description', 'disable', 'endpoint', 'persistent-keepalive', 'preshared-key', 'public-key']
            for key in simple_keys:
                if key in peer_attrs:
                    value = peer_attrs[key]
                    if isinstance(value, bool) and value:
                        self._generate_cmd(self.operator, *peer_path, key)
                    elif not isinstance(value, bool) and value:
                        self._generate_cmd(self.operator, *peer_path, key, value)

            if 'allowed-ips' in peer_attrs:
                for ip in peer_attrs['allowed-ips']:
                    if ip:
                        self._generate_cmd(self.operator, *peer_path, 'allowed-ips', ip.strip())
