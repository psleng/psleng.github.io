"""Test class for Firewall verification functionality"""

import pytest
from app.test.core.base import TestVerify
from app.test.core.security.firewall.test_cases._test_case_verify import test_verify_success, test_verify_failed

class TestFirewallVerify(TestVerify):
    __test__ = False
    
    @pytest.fixture
    def service(self):
        return "firewall"
    
    @pytest.fixture
    def test_get_current_config(self):
        return {
            "firewallv4": {
                "inbound": [
                    {
                        "rule_number": 1,
                        "action": "accept",
                        "protocol": "tcp",
                        "enabled": True,
                        "log_enabled": False,
                        "firewall_type": "prerouting",
                        "source_address": "192.168.1.1",
                        "source_subnet": "24",
                        "source_port": "80",
                        "destination_address": "10.0.0.1",
                        "destination_port": "443",
                        "interface": "eth0"
                    }
                ]
            },
            "firewallv6": {
                "outbound": [],
                "inbound": []
            }
        }
    
    @pytest.mark.parametrize("test_data", test_verify_success)
    def test_verify_success(self, test_service_provider, success_verification, service, test_data):
        super().test_verify_success(test_service_provider, success_verification, service, test_data)
    
    @pytest.mark.parametrize("test_data", test_verify_failed)
    def test_verify_failed(self, test_service_provider, success_verification, service, test_data):
        super().test_verify_failed(test_service_provider, success_verification, service, test_data)
    
    def test_verify_current_config(self, test_service_provider, success_verification, service, test_get_current_config):
        super().test_verify_current_config(test_service_provider, success_verification, service, test_get_current_config)