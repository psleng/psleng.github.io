from app.log.logger import logger

def parse_to_wireguard_config(data):
    config = {}
    for key, value in data.items():
        if value is None or key == 'peer' or key == 'enabled':
            continue

        vyos_key = key.replace('_', '-')
        if isinstance(value, list):
            config[vyos_key] = ','.join(map(str, value))
        else:
            config[vyos_key] = str(value)

    if 'peer' in data and data['peer'] is not None:
        config['peer'] = {}
        for public_key, peer_data in data['peer'].items():
            if peer_data is None:
                continue
            
            peer_config = {}
            for key, value in peer_data.items():
                if value is None:
                    continue
                
                vyos_key = key.replace('_', '-')
                if isinstance(value, list):
                    peer_config[vyos_key] = ','.join(map(str, value))
                else:
                    peer_config[vyos_key] = str(value)
            
            if 'address' in peer_data and 'port' in peer_data and peer_data['address'] and peer_data['port']:
                peer_config['endpoint'] = f"{peer_data['address']}:{peer_data['port']}"
                if 'address' in peer_config: del peer_config['address']
                if 'port' in peer_config: del peer_config['port']

            config['peer'][public_key] = peer_config

    return config


def parse_current_wireguard_interface_config(os_config, name):
    wireguard_config = os_config.get('interfaces', {}).get('wireguard', {}).get(name, {})
    logger.debug("Current wireguard config: ")
    logger.debug(wireguard_config)
    return wireguard_config


def parse_wireguard_key_pair(data):
    """
    Sample data: 
    "data": "Private key: <private_key>\nPublic key: <public_key>\n\n"
    """
    result = {
        "public_key": '',
        "private_key": ''
    }
    lines = data.strip().split('\n')
    for line in lines:
        if line.startswith('Private key:'):
            result['private_key'] = line.split(':', 1)[1].strip()
        elif line.startswith('Public key:'):
            result['public_key'] = line.split(':', 1)[1].strip()
    return result


def parse_wireguard_monitor_info(data):
    logger.debug("Wireguard monitor info: ")
    logger.debug(data)

    result = []
    if not data or 'ShowWireguardInterfacesWireguardQuery' not in data or \
        not data['ShowWireguardInterfacesWireguardQuery']:
        return result

    interfaces = data['ShowWireguardInterfacesWireguardQuery'].get('data', {}).get('result', [])
    for iface in interfaces:
        if not iface:
            continue

        ifname = iface.get('ifname')
        flags = iface.get('flags', [])
        mtu = iface.get('mtu')

        local_addresses = []
        for addr in iface.get('addr_info', []):
            local_addresses.append(f"{addr.get('local')}/{addr.get('prefixlen')}")

        stats = iface.get('stats', {})
        rx_bytes = stats.get('rx_bytes')
        rx_packets = stats.get('rx_packets')
        rx_errors = stats.get('rx_errors')
        tx_bytes = stats.get('tx_bytes')
        tx_packets = stats.get('tx_packets')
        tx_errors = stats.get('tx_errors')

        # Peers
        peers_info = []
        if 'wireguard' in iface and iface['wireguard'] and 'peers' in iface['wireguard']:
            for peer in iface['wireguard']['peers']:
                peers_info.append({
                    'peer_address': peer.get('peer'),
                    'listening_port': iface.get('wireguard', {}).get('listening_port'),
                    'endpoint': peer.get('endpoint'),
                    'allowed_ips': peer.get('allowed_ips', []),
                    'public_key': iface.get('wireguard', {}).get('public_key'),
                    'sent': peer.get('transfer_tx'),
                    'received': peer.get('transfer_rx')
                })

        result.append({
            'ifname': ifname,
            'flags': flags,
            'mtu': mtu,
            'local_addresses': local_addresses,
            'rx_bytes': rx_bytes,
            'rx_packets': rx_packets,
            'rx_errors': rx_errors,
            'tx_bytes': tx_bytes,
            'tx_packets': tx_packets,
            'tx_errors': tx_errors,
            'peers': peers_info
        })

    return result