
def is_subnet_connected(subnet, primary=False):
    """
    Verify is the given IPv4/IPv6 subnet is connected to any interface on this
    system.

    primary check if the subnet is reachable via the primary IP address of this
    interface, or in other words has a broadcast address configured. ISC DHCP
    for instance will complain if it should listen on non broadcast interfaces.

    Return True/False
    """
    from ipaddress import ip_address
    from ipaddress import ip_network

    from netifaces import ifaddresses
    from netifaces import interfaces
    from netifaces import AF_INET
    from netifaces import AF_INET6

    from app.pkg.vyos.template import is_ipv6

    # determine IP version (AF_INET or AF_INET6) depending on passed address
    addr_type = AF_INET
    if is_ipv6(subnet):
        addr_type = AF_INET6

    for interface in interfaces():
        # check if the requested address type is configured at all
        if addr_type not in ifaddresses(interface).keys():
            continue

        # An interface can have multiple addresses, but some software components
        # only support the primary address :(
        if primary:
            ip = ifaddresses(interface)[addr_type][0]['addr']
            if ip_address(ip) in ip_network(subnet):
                return ip
        else:
            # Check every assigned IP address if it is connected to the subnet
            # in question
            for ip in ifaddresses(interface)[addr_type]:
                # remove interface extension (e.g. %eth0) that gets thrown on the end of _some_ addrs
                addr = ip['addr'].split('%')[0]
                if ip_address(addr) in ip_network(subnet):
                    return ip

    return None

def is_ipv6_link_local(addr):
    from ipaddress import ip_interface
    from app.pkg.vyos.template import is_ipv6
    addr = addr.split('%')[0]
    if is_ipv6(addr):
        if ip_interface(addr).is_link_local:
            return True
    return False
