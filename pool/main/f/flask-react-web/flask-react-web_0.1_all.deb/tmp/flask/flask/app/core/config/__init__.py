from flask import Blueprint

vyos_config_bp = Blueprint('configs', __name__)

from . import routes