from . import vyos_login_bp
from .models import UpdateSamlDTO

from flask import jsonify, request, session, redirect
from app.core.api.api import API_TARGET, API_ACTION
from app.core.api.manager import api_manager
from app.core.login.saml.parser import parse_to_saml_config
from app.core.api.http.cmd.compare import compare_configs
from app.auth.utils import login_required

def normalize_keys(config: dict) -> dict:
    normalized = {}
    for key, value in config.items():
        new_key = key.replace("_", "-")
        if isinstance(value, dict):
            normalized[new_key] = normalize_keys(value)
        elif isinstance(value, list):
            normalized[new_key] = [
                normalize_keys(v) if isinstance(v, dict) else v
                for v in value
            ]
        else:
            normalized[new_key] = value
    return normalized

@vyos_login_bp.route('/saml', methods=['GET'])
@login_required
def show_saml_config():
    """Get SAML configuration"""
    try:
        res = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.SAML
        )
        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        
        return jsonify({"success": True, "data": res}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_login_bp.route('/saml', methods=['PUT'])
@login_required
def update_saml_config():
    """Update SAML configuration"""
    try:
        data = UpdateSamlDTO.model_validate_json(request.data)
        current_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.SAML
        )
        if isinstance(current_config, Exception):
            return jsonify({"error": str(current_config)}), 400

        new_config = parse_to_saml_config(data.model_dump())
        diff = compare_configs(new_config, current_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.SAML,
            data={"current": current_config, "new": new_config, "diff": diff}
        )

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        
        return jsonify({"success": True, "data": res}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 400

@vyos_login_bp.route('/saml/verify', methods=['POST'])
@login_required
def verify_saml_config():
    """Verify SAML configuration before applying"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "error": "No data provided"}), 400

        current_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.SAML
        )
        if isinstance(current_config, Exception):
            return jsonify({"error": str(current_config)}), 400

        new_config = parse_to_saml_config(data)
        diff = compare_configs(new_config, current_config)

        result = api_manager.call(
            action=API_ACTION.VERIFY,
            target=API_TARGET.SAML,
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        
        if result and str(result) != "None" and str(result) != "":
            return jsonify({"success": False, "verify": result}), 400
            
        return jsonify({"success": True, "verify": "Success"}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400
    
@vyos_login_bp.route('/AAA', methods=['GET'])
@login_required
def show_aaa_config():
    try:
        res = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.LOGIN
        )
        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400

        if 'saml' in res:
            saml_config = res.get('saml')
            saml_config['type'] = 'saml'

            return jsonify({"success": True, "data": saml_config})
        elif 'radius' in res:
            radius_config = res.get('radius')
            radius_config['type'] = 'radius'

            return jsonify({"success": True, "data": radius_config})
        elif 'tacacs' in res:
            tacacs_config = res.get('tacacs')
            tacacs_config['type'] = 'tacacs'

            return jsonify({"success": True, "data": tacacs_config})

        return jsonify({"success": False, "data": None})
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
@vyos_login_bp.route("/AAA", methods=['PUT'])
@login_required
def update_aaa_config():
    try:
        AAAConfig = request.get_json(force=True)

        current_config = api_manager.call(
            action=API_ACTION.READ,
            target=API_TARGET.LOGIN
        )
        if isinstance(current_config, Exception):
            return jsonify({"error": str(current_config)}), 400
        
        new_config = dict(current_config)
        config_type = AAAConfig.pop('type', 'noconf')
        match config_type:
            case 'saml':
                if 'radius' in current_config:
                    new_config.pop('radius')
                if 'tacacs' in current_config:
                    new_config.pop('tacacs')
                new_config['saml'] = AAAConfig
            case 'radius':
                if 'saml' in current_config:
                    new_config.pop('saml')
                if 'tacacs' in current_config:
                    new_config.pop('tacacs')
                new_config['radius'] = AAAConfig
            case 'tacacs':
                if 'radius' in current_config:
                    new_config.pop('radius')
                if 'saml' in current_config:
                    new_config.pop('saml')
                new_config['tacacs'] = AAAConfig
            case 'noconf':
                if 'radius' in current_config:
                    new_config.pop('radius')
                if 'saml' in current_config:
                    new_config.pop('saml')
                if 'tacacs' in current_config:
                    new_config.pop('tacacs')

        new_login_config = normalize_keys({
            "system": {
                "login": new_config
            }
        })

        current_login_config = normalize_keys({
            "system": {
                "login": current_config
            }
        })

        diff = compare_configs(new_login_config, current_login_config)

        res = api_manager.call(
            action=API_ACTION.UPDATE,
            target=API_TARGET.LOGIN,
            data={"current": current_login_config, "new": new_login_config, "diff": diff}
        )

        if isinstance(res, Exception):
            return jsonify({"error": str(res)}), 400
        
        return jsonify({"success": True, "data": res}), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400