proxy: 
  proxytype: netmiko
  device_type: vyos
  host: localhost 
  username: vyos 
  password: vyos 