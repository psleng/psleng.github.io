from app.core.salt.client import LocalClient

class MasterCommand():

    def __init__(self, minion):
        self.minion = minion
        self.local = LocalClient()

    def run_local(self,  cmd, cmd_args=None):
        if cmd_args:
            return self.local.cmd(self.minion, cmd)
        return self.local.cmd(self.minion, cmd, cmd_args)
    
    def get_minion_cpu(self):
        return self.run_local()
    

def local_cmd(minion, command):
    local = LocalClient()
    return local.cmd(minion, command)


def get_memory(minion):
    local = LocalClient()
    return local.cmd(minion, 'status.meminfo')


def get_cpu(minion):
    local = LocalClient()
    return local.cmd(minion, 'status.loadavg')


def get_system_uptime(minion):
    local = LocalClient()
    return local.cmd(minion, 'status.uptime')

def get_hostname(minion):
    local = LocalClient()
    return local.cmd(minion, 'network.get_hostname')

def get_hosttime(minion):
    local = LocalClient()
    return local.cmd(minion, 'status.time')

def get_interfaces(minion):
    local = LocalClient()
    return local.cmd(minion, 'network.interfaces')
