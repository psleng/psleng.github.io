from app.core.operation.system_performance import load_system_cpu_json
from app.core.models import System
from app.core.operation.system_information import parse_date, parse_hostname, parse_domainname
from app.core.salt.master import get_system_uptime
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_info(app_context):
    try:
        refresh_db_system_info(app_context=app_context)

    except Exception as e:
        print('Error fetch system info', str(e))


def refresh_db_system_info(app_context=None):
    try: 
        logger.info("[TASK] Fetch System Info")
        print("[TASK] Fetch System Info")
        vyos_data = api_manager.call(action=API_ACTION.READ, target=API_TARGET.SYSTEM)
        logger.info(vyos_data)
        print(vyos_data)
        if app_context is not None:
            with app_context:
                System.refresh(vyos_data)
        else:
            System.refresh(vyos_data)
        return vyos_data
    except Exception as e:
        print(str(e))
        print(str(e))


def salt_refresh_db_system_info(minion):
    """
        Update db with minion's data. Sample:
        uptime = {
            "days": 4,
            "seconds": 426705,
            "since_iso": "2024-12-13T19:42:15.317346",
            "since_t": 1734118935,
            "time": "22:31",
            "users": 3
        }
    """
    try: 
        uptime = get_system_uptime()

        data = {
            "datetime": parse_date(system_date.json()['data']),
            "boot_img_name": boot_img.get('name'),
            "boot_img_running": boot_img.get('running'),
            "boot_img_default": boot_img.get('default_boot'),
            "name": parse_hostname(system_name.json()['data']),
            "domain_name": parse_domainname(system_domain.json()['data']),
            # "commits": parse_commits(system_commits.json()['data']),
            "uptime": load_system_cpu_json(system_uptime.json()['data']).get('uptime')
        }
        System.refresh(data)
        return data
    except Exception as e:
        print(str(e))