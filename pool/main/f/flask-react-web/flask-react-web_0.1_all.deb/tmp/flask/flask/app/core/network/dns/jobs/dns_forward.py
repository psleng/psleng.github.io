from app.core.network.dns.models import DNSForwarding
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from logging import getLogger, INFO

logger = getLogger(__name__)
logger.setLevel(INFO)

def fetch_dns_forward_job(app_context):
    try:
        refresh_db_dns_forward(app_context=app_context)
    except Exception as e:
        print('Error fetch dns forward', str(e))



def refresh_db_dns_forward(app_context=None):
    try:
        dns_forward = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_FORWARD)
        print("DNS Forwarding data:", dns_forward)
        if app_context is not None:
            with app_context:
                DNSForwarding.refresh(dns_forward)
        else:
            DNSForwarding.refresh(dns_forward)
        return True
    except Exception as e:
        print(f"Error refreshing db DNS forwarding data: {e}")
        return False
