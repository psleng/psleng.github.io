import pytest

test_set = [
    pytest.param(
        {
            "current_config": {
                "dhcp": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.50",
                                            "stop": "192.168.1.150"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "set_config": {
                "dhcp": {
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.10.0/24": {
                                    "subnet-id": "2",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.10.100",
                                            "stop": "192.168.10.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dhcp": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.50",
                                            "stop": "192.168.1.150"
                                        }
                                    }
                                },
                                "192.168.10.0/24": {
                                    "subnet-id": "2",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.10.100",
                                            "stop": "192.168.10.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_update_dhcp_config"
    ),
    pytest.param(
        {
            "current_config": {
                "dhcpv6": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "IPv6LAN": {
                            "subnet": {
                                "2001:db8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:db8::50",
                                            "stop": "2001:db8::150"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "set_config": {
                "dhcpv6": {
                    "shared-network-name": {
                        "IPv6LAN": {
                            "subnet": {
                                "2001:dc8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:dc8::100",
                                            "stop": "2001:dc8::200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dhcpv6": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "IPv6LAN": {
                            "subnet": {
                                "2001:db8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:db8::50",
                                            "stop": "2001:db8::150"
                                        }
                                    }
                                },
                                "2001:dc8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:dc8::100",
                                            "stop": "2001:dc8::200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        },
        id="test_update_dhcpv6_config"
    )
]

test_delete = [
    pytest.param(
        {
            "current_config": {
                "dhcp": {
                    "listen-interface": ["eth0"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.100",
                                            "stop": "192.168.1.200"
                                        }
                                    },
                                    "option": {
                                        "default-router": "192.168.1.1",
                                        "name-server": "8.8.8.8"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "dhcp": {
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "option": {
                                        "default-router": "192.168.1.1",
                                        "name-server": "8.8.8.8"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dhcp": {
                    "listen-interface": ["eth0"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.100",
                                            "stop": "192.168.1.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_delete_dhcp_config"
    ),
    pytest.param(
        {
            "current_config": {
                "dhcpv6": {
                    "listen-interface": ["eth0"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "2001:db8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:db8::100",
                                            "stop": "2001:db8::200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {
                "dhcpv6": {
                    "listen-interface": ["eth0"]
                }
            },
            "expected_config": {
                "dhcpv6": {
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "2001:db8::/64": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "2001:db8::100",
                                            "stop": "2001:db8::200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_delete_dhcpv6_config"
    )
]


test_set_delete = [
    pytest.param(
        {
            "current_config": {
                "dhcp": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.100",
                                            "stop": "192.168.1.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "delete_config": {},
            "set_config": {
                "dhcp": {
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.10.0/24": {
                                    "subnet-id": "2",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.10.100",
                                            "stop": "192.168.10.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "expected_config": {
                "dhcp": {
                    "listen-interface": ["eth1"],
                    "shared-network-name": {
                        "LAN": {
                            "subnet": {
                                "192.168.1.0/24": {
                                    "subnet-id": "1",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.1.100",
                                            "stop": "192.168.1.200"
                                        }
                                    }
                                },
                                "192.168.10.0/24": {
                                    "subnet-id": "2",
                                    "range": {
                                        "range_1": {
                                            "start": "192.168.10.100",
                                            "stop": "192.168.10.200"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        id="test_set_delete_dhcp_config"
    )
]