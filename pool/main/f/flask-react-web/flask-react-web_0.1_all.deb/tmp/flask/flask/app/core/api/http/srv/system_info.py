from app.core.api.http.http_request import Action
from app.core.api.http.cmd.command import SHOW_SYSTEMS_TIMEZONE,SHOW_SYSTEMS_BOOT_IMG, SHOW_SYSTEM, SHOW_SYSTEMS_VERSION, SHOW_SYSTEM_DOMAIN, SHOW_SYSTEMS_DATE, SHOW_SYSTEMS_UPTIME, SHOW_SYSTEMS_NAME
from app.core.operation.system_information import parse_boot_img, parse_date, parse_hostname, parse_wireless_country_code, parse_domainname, parse_datetime, parse_system_version, parse_timezone
from app.core.operation.system_performance import load_system_cpu_json
from logging import getLogger, INFO, DEBUG
from app.core.api.http.cmd.command_system import SystemCommand
import pprint
import os 
from app.core.utils.cmd_linux import run_linux_cmd
from app.config.models import SubPageFeature
from app.core.utils.datetime.convert import convert_datetime
from app.core.utils.check_os import is_linux

logger = getLogger(__name__)
logger.setLevel(DEBUG)

def fetch_system_info(provider, params):
    """Fetch all system information."""
    system_date = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_DATE, verify=False)
    # system_boot_img = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_BOOT_IMG, verify=False)
    system_version = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_VERSION, verify=False)
    system_name = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_NAME, verify=False)
    system_domain = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEM_DOMAIN, verify=False)
    system_uptime = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_UPTIME, verify=False)
    system = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEM, verify=False)

    # boot_img = parse_boot_img(system_boot_img.json()['data'])
    boot_img = parse_system_version(system_version.json()['data'])

    r = {
        "datetime": parse_date(system_date.json()['data']),
        "boot_img_name": boot_img,
        "boot_img_running": True,
        "boot_img_default": True,
        "name": parse_hostname(system_name.json()['data']),
        "domain_name": parse_domainname(system_domain.json()['data']),
        "uptime": load_system_cpu_json(system_uptime.json()['data']).get('uptime'),
        "system": parse_wireless_country_code(system.json()['data'])
    }
    return r

def fetch_datetime(provider, params=None):
    """Fetch system datetime information."""
    try:
        logger.debug("Fetching datetime...")
        datetime_response = provider.http_service.send_request(action=Action.SHOW, data=SHOW_SYSTEMS_DATE, verify=False)
        timezone_response = provider.http_service.send_request(action=Action.RETRIEVE, data=SHOW_SYSTEMS_TIMEZONE, verify=False)
        
        if not datetime_response or not datetime_response.json() or 'data' not in datetime_response.json():
            logger.error("Invalid datetime response")
            return {"error": "Invalid datetime response"}
            
        data = datetime_response.json()['data']
        logger.debug(f"Raw datetime data: {data}")
        
        parsed = parse_datetime(data)
        logger.debug(f"Parsed datetime: {parsed}")
        
        return {
            "datetime": parsed,
            "timezone": parse_timezone(timezone_response.json()['data'])
        }
    except Exception as e:
        logger.error(f"Error fetching datetime: {str(e)}")
        return {"error": str(e)}

def update_system(provider, data):
    
    from app.core.security.service.firewall import FirewallCommand
    from app.core.models import System
    
    systemName = data.get('systemName', None)
    domainName = data.get('domainName', None)
    dateTime = data.get('dateTime', None)
    timezone = data.get('timezone', None)
    ipv6 = data.get('ipv6', None)

    system_command = SystemCommand(
        operator='set',
        resource='system',
        host_name=systemName,
        domain_name=domainName,
        timezone=timezone
    )

    if ipv6 is False:
        firewall_command = FirewallCommand(operator='set')
        firewall_cmds = firewall_command.generate_commands(data={'ipv6': {'block': {}}})
        SubPageFeature.set_v6_features_status(status=False)
        System.set_ipv6_status(data={'ipv6': {'block': {}}})
        
    elif ipv6 is True:
        firewall_command = FirewallCommand(operator='delete')
        firewall_cmds = firewall_command.generate_commands(data={'ipv6': {'block': {}}})
        SubPageFeature.set_v6_features_status(status=True)
        System.set_ipv6_status(data={'ipv6': {}})

    if is_linux() and dateTime:
        # Linux command to change date and time
        converted_datetime = convert_datetime(dateTime)
        datetime_cmd = f"date -s '{converted_datetime}'"
        datetime_output, datetime_error = run_linux_cmd(datetime_cmd)
        logger.debug(f"Datetime command: {datetime_cmd}")
        logger.debug(f"Datetime output: {datetime_output}")
        logger.debug(f"Datetime error: {datetime_error}")
    
    cmds = firewall_cmds
    # cmds = system_command.generate_commands()

    r = []
    if len(cmds) > 0:
        res = provider.http_service.send_request(action=Action.CONFIGURE, data=cmds, verify=False)
        r.append({
            "cmd": cmds,
            "success": res.json()['success'],
            "error": res.json()['error']
        })

    return r