from app.core.operation.command_iface import IfaceCommand
from app.core.api.http.cmd.command import Command
import pprint
class EthernetCommand(IfaceCommand):
    """
    Command class for Ethernet Interface:
    Extends the IfaceCommand class, it supports all of commands in IfaceCommand
    And extra commands specific to Ethernet interface:

    Ethernet Interface Settings:
    • set/del interface ethernet <intf-name> speed <auto|10|100|1000>
    • set/del interface ethernet <intf-name> duplex <auto|half|full>
    • set/del interface ethernet <intf-name> mtu <68-16000>
    • set/del interface ethernet <intf-name> link-negotiation <auto|off>
    • set/del interface ethernet <intf-name> energy-efficient-ethernet <enable|disable>
    • set/del interface ethernet <intf-name> enable-console-management <enable|disable>
    • set/del interface ethernet <intf-name> address-type <static|dhcp|dhcpv6|autoconf>
    • set/del interface ethernet <intf-name> protocol <none|pppoe>
    • set/del interface ethernet <intf-name> port <none|modem>
    • set/del interface ethernet <intf-name> dhcp-server {enable|disable}
    • set/del interface ethernet <intf-name> router-preference {low|medium|high}
    • set/del interface ethernet <intf-name> reachable-time <0-3600000>
    • set/del interface ethernet <intf-name> retransmission-time <0-4294967295>
    • set/del interface ethernet <intf-name> hop-limit <1-255>
    • set/del interface ethernet <intf-name> ra-interval {min|max}
    • set/del interface ethernet <intf-name> minimum-interval <3-1350>
    • set/del interface ethernet <intf-name> ra-lifetime <4-9000>
    • set/del interface ethernet <intf-name> role {access|trunk}
    """

    def __init__(self, **kwargs):
        try:
            super().__init__(**kwargs)
            self.attributes['ethernet'] = {
                'speed': 'auto',
                'duplex': 'auto',
                'mtu': 1500,
                'link-negotiation': 'auto',
                'energy-efficient-ethernet': 'disable',
                'enable-console-management': 'disable',
                'address-type': 'static',
                'protocol': 'none',
                'port': 'none',
                'dhcp-server': 'disable',
                'router-preference': 'medium',
                'reachable-time': 0,
                'retransmission-time': 0,
                'hop-limit': 64,
                'ra-interval': {
                    'min': 0,
                    'max': 600
                },
                'role': 'access'
            }
        except Exception as e:
            print(f"Error initializing Ethernet command: {e}")

    def _process_ethernet_settings(self, interface_name, config):
        """Process Ethernet-specific settings"""
        base = ['interfaces', 'ethernet', interface_name]
        
        if 'speed' in config:
            if config['speed'] in ['auto', '10', '100', '1000']:
                self.generate(*base, 'speed', config['speed'])
            else:
                raise ValueError(f"Invalid speed value: {config['speed']}")
        
        if 'duplex' in config:
            if config['duplex'] in ['auto', 'half', 'full']:
                self.generate(*base, 'duplex', config['duplex'])
            else:
                raise ValueError(f"Invalid duplex value: {config['duplex']}")
        
        if 'mtu' in config:
            # Convert mtu to integer if it's a string
            mtu_value = int(config['mtu']) if isinstance(config['mtu'], str) else config['mtu']
            if 68 <= mtu_value <= 16000:
                self.generate(*base, 'mtu', mtu_value)
            else:
                raise ValueError(f"Invalid MTU value: {mtu_value}. Must be between 68 and 16000")
        
        if 'link-negotiation' in config:
            if config['link-negotiation'] in ['auto', 'off']:
                self.generate(*base, 'link-negotiation', config['link-negotiation'])
            else:
                raise ValueError(f"Invalid link-negotiation value: {config['link-negotiation']}")
        
        if 'energy-efficient-ethernet' in config:
            if config['energy-efficient-ethernet'] in ['enable', 'disable']:
                self.generate(*base, 'energy-efficient-ethernet', config['energy-efficient-ethernet'])
            else:
                raise ValueError(f"Invalid energy-efficient-ethernet value: {config['energy-efficient-ethernet']}")
        
        if 'enable-console-management' in config:
            if config['enable-console-management'] in ['enable', 'disable']:
                self.generate(*base, 'enable-console-management', config['enable-console-management'])
            else:
                raise ValueError(f"Invalid enable-console-management value: {config['enable-console-management']}")
        
        if 'address-type' in config:
            if config['address-type'] in ['static', 'dhcp', 'dhcpv6', 'autoconf']:
                self.generate(*base, 'address-type', config['address-type'])
            else:
                raise ValueError(f"Invalid address-type value: {config['address-type']}")
        
        if 'protocol' in config:
            if config['protocol'] in ['none', 'pppoe']:
                self.generate(*base, 'protocol', config['protocol'])
            else:
                raise ValueError(f"Invalid protocol value: {config['protocol']}")
        
        if 'port' in config:
            if config['port'] in ['none', 'modem']:
                self.generate(*base, 'port', config['port'])
            else:
                raise ValueError(f"Invalid port value: {config['port']}")
        
        if 'dhcp-server' in config:
            if config['dhcp-server'] in ['enable', 'disable']:
                self.generate(*base, 'dhcp-server', config['dhcp-server'])
            else:
                raise ValueError(f"Invalid dhcp-server value: {config['dhcp-server']}")
        
        if 'router-preference' in config:
            if config['router-preference'] in ['low', 'medium', 'high']:
                self.generate(*base, 'router-preference', config['router-preference'])
            else:
                raise ValueError(f"Invalid router-preference value: {config['router-preference']}")
        
        if 'reachable-time' in config:
            reachable_time = int(config['reachable-time']) if isinstance(config['reachable-time'], str) else config['reachable-time']
            if 0 <= reachable_time <= 3600000:
                self.generate(*base, 'reachable-time', reachable_time)
            else:
                raise ValueError(f"Invalid reachable-time value: {reachable_time}. Must be between 0 and 3600000")
        
        if 'retransmission-time' in config:
            retrans_time = int(config['retransmission-time']) if isinstance(config['retransmission-time'], str) else config['retransmission-time']
            if 0 <= retrans_time <= 4294967295:
                self.generate(*base, 'retransmission-time', retrans_time)
            else:
                raise ValueError(f"Invalid retransmission-time value: {retrans_time}. Must be between 0 and 4294967295")
        
        if 'hop-limit' in config:
            hop_limit = int(config['hop-limit']) if isinstance(config['hop-limit'], str) else config['hop-limit']
            if 1 <= hop_limit <= 255:
                self.generate(*base, 'hop-limit', hop_limit)
            else:
                raise ValueError(f"Invalid hop-limit value: {hop_limit}. Must be between 1 and 255")
        
        if 'ra-interval' in config:
            if 'min' in config['ra-interval']:
                min_value = int(config['ra-interval']['min']) if isinstance(config['ra-interval']['min'], str) else config['ra-interval']['min']
                if 3 <= min_value <= 1350:
                    self.generate(*base, 'ra-interval', 'min', min_value)
                else:
                    raise ValueError(f"Invalid ra-interval min value: {min_value}. Must be between 3 and 1350")
            if 'max' in config['ra-interval']:
                max_value = int(config['ra-interval']['max']) if isinstance(config['ra-interval']['max'], str) else config['ra-interval']['max']
                if 4 <= max_value <= 1800:
                    self.generate(*base, 'ra-interval', 'max', max_value)
                else:
                    raise ValueError(f"Invalid ra-interval max value: {max_value}. Must be between 4 and 1800")
        
        if 'ra-lifetime' in config:
            lifetime = int(config['ra-lifetime']) if isinstance(config['ra-lifetime'], str) else config['ra-lifetime']
            if 4 <= lifetime <= 9000:
                self.generate(*base, 'ra-lifetime', lifetime)
            else:
                raise ValueError(f"Invalid ra-lifetime value: {lifetime}. Must be between 4 and 9000")
        
        if 'role' in config:
            if config['role'] in ['access', 'trunk']:
                self.generate(*base, 'role', config['role'])
            else:
                raise ValueError(f"Invalid role value: {config['role']}. Must be 'access' or 'trunk'")
            
        if 'bridge' in config:
            _bridge_interface = config['bridge'].get('interface')
            if _bridge_interface:
                self.generate('interfaces', 'bridge', _bridge_interface, 'member', 'interface', interface_name)

    def generate_commands(self, data=None, current_config=None, new_config=None):
        """Generate VyOS commands for Ethernet interface configuration"""
        try:
            if not data:
                return []
            if data:
                print("Data passed to Ethernet Command class: ")
                print(pprint.pformat(data, indent=2, width=80))
                # generate specific commands for ethernet
                for interface_name, config in data.items():
                    self._process_ethernet_settings(interface_name, config)
                
                # Format data for parent class
                formatted_data = {
                    'interfaces': {
                        'ethernet': data
                    }
                }
                # generate general commands for interfaces
                super().generate_commands(formatted_data, current_config, new_config)

            return self.cmds

        except Exception as e:
            print(f"Error generating commands: {e}")
            return []
        