import pytest

test_verify_success_1 = pytest.param(
    (
        { 
            "0.0.0.0/0": {
                "next-hop": {
                    "192.168.1.1": {"distance": "1"}
                }
            },
            "10.0.0.0/24": {
                "next-hop": {
                    "192.168.2.1": {"distance": "10"}
                }
            }
        }
    ),
    id="test_verify_success_1"
)

test_verify_success_2 = pytest.param(
    (
        { 
            "0.0.0.0/0": {
                "interface": {
                    "eth0": {"distance": "1"}
                }
            }
        }
    ),
    id="test_verify_success_2"
)

test_verify_success = [
    test_verify_success_1,
    test_verify_success_2
]

test_verify_failed_1 = pytest.param(
    (
        { 
            "0.0.0.0/0": {
                "next-hop": {
                    "a.b.c.d": {"distance": "1"}
                }
            }
        }
    ),
    id="test_verify_failed_1"
)

test_verify_failed_2 = pytest.param(
    (
        { 
            "invalid/prefix": {
                "next-hop": {
                    "192.168.1.1": {"distance": "1"}
                }
            }
        }
    ),
    id="test_verify_failed_2"
)

# Skip the failed verification test cases
test_verify_failed = [
    # test_verify_failed_1,
    # test_verify_failed_2
]