import pprint
import logging

logger = logging.getLogger(__name__)

def parse_ntp_config(config):
    """
    Parse NTP configuration from VyOS config
    
    Sample config:
    {
        'allow-client': {
            'address': [
                '127.0.0.0/8',
                '169.254.0.0/16',
                '10.0.0.0/8',
                '172.16.0.0/12',
                '192.168.0.0/16',
                '::1/128',
                'fe80::/10',
                'fc00::/7'
            ]
        },
        'interface': 'br2',
        'listen-address': '1.1.1.1',
        'ptp': {'port': '319'},
        'server': {
            '1.1.1.1': {},
            '2.2.2.2': {
                'interleave': {},
                'noselect': {},
                'nts': {},
                'pool': {},
                'ptp': {}
            },
            'ca.poll.ntp.org': {},
            'time1.vyos.net': {},
            'time2.vyos.net': {},
            'time3.vyos.net': {}
        }
    }
    """
    logger.debug(f"Parsing NTP config: {pprint.pformat(config, indent=2, width=80)}")
    
    result = {
        'interface': None,
        'listen_address': None,
        'allow-client': [],
        'server': [],
        'ptp': {}
    }
    
    if 'interface' in config:
        result['interface'] = config['interface']
    
    if 'listen-address' in config:
        result['listen_address'] = config['listen-address']
    
    if 'leap-second' in config:
        result['leap_second'] = config['leap-second']
    
    if 'allow-client' in config and 'address' in config['allow-client']:
        addresses = config['allow-client']['address']
        if isinstance(addresses, list):
            result['allow-client'] = addresses
        else:
            result['allow-client'] = [addresses]
    
    if 'server' in config:
        servers = []
        for server_addr, server_config in config['server'].items():
            server_data = {
                'address': server_addr,
                'interleave': False,
                'noselect': False,
                'nts': False,
                'pool': False,
                'ptp': False
            }
            
            if server_config:
                server_data['interleave'] = 'interleave' in server_config
                server_data['noselect'] = 'noselect' in server_config
                server_data['nts'] = 'nts' in server_config
                server_data['pool'] = 'pool' in server_config
                server_data['ptp'] = 'ptp' in server_config
            
            servers.append(server_data)
        
        result['server'] = servers
    
    if 'ptp' in config:
        ptp_config = {
            'port': None,
            'interfaces': []
        }
        
        if 'port' in config['ptp']:
            ptp_config['port'] = config['ptp']['port']
        
        if 'timestamp-interface' in config['ptp']:
            if isinstance(config['ptp']['timestamp-interface'], list):
                ptp_config['interfaces'] = config['ptp']['timestamp-interface']
            else:
                ptp_config['interfaces'] = [config['ptp']['timestamp-interface']]
        
        result['ptp'] = ptp_config
    
    logger.debug(f"Parsed NTP config: {pprint.pformat(result, indent=2, width=80)}")
    return result


def parse_to_ntp_config(data: dict):
    """
    Transform NTP DTO structure into VyOS configuration format.
    
    Sample input:
    { 'allow_clients': [ {'address': '127.0.0.0/8'},
                     {'address': '169.254.0.0/16'},
                     {'address': '10.0.0.0/8'},
                     {'address': '172.16.0.0/12'},
                     {'address': '192.168.0.0/16'},
                     {'address': '::1/128'},
                     {'address': 'fe80::/10'},
                     {'address': 'fc00::/7'}],
      'interface': 'br2',
      'leap_second': None,
      'listen_address': '1.1.1.1',
      'ptp': {'interface': None, 'port': '319'},
      'servers': [ { 'address': '1.1.1.1',
                     'interleave': False,
                     'noselect': False,
                     'nts': False,
                     'pool': False,
                     'ptp': False},
                   { 'address': '2.2.2.2',
                     'interleave': True,
                     'noselect': True,
                     'nts': True,
                     'pool': True,
                     'ptp': True},
                   { 'address': 'ca.poll.ntp.org',
                     'interleave': False,
                     'noselect': False,
                     'nts': False,
                     'pool': False,
                     'ptp': False},
                   { 'address': 'time1.vyos.net',
                     'interleave': False,
                     'noselect': False,
                     'nts': False,
                     'pool': False,
                     'ptp': False},
                   { 'address': 'time2.vyos.net',
                     'interleave': False,
                     'noselect': False,
                     'nts': False,
                     'pool': False,
                     'ptp': False},
                   { 'address': 'time3.vyos.net',
                     'interleave': False,
                     'noselect': False,
                     'nts': False,
                     'pool': False,
                     'ptp': False}]}

    Sample output:
    {
        'allow-client': {
            'address': [
                '127.0.0.0/8',
                '169.254.0.0/16',
                '10.0.0.0/8',
                '172.16.0.0/12',
                '192.168.0.0/16',
                '::1/128',
                'fe80::/10',
                'fc00::/7'
            ]
        },
        'interface': 'br2',
        'listen-address': '1.1.1.1',
        'ptp': {'port': '319'},
        'server': {
            '1.1.1.1': {},
            '2.2.2.2': {
                'interleave': {},
                'noselect': {},
                'nts': {},
                'pool': {},
                'ptp': {}
            },
            'ca.poll.ntp.org': {},
            'time1.vyos.net': {},
            'time2.vyos.net': {},
            'time3.vyos.net': {}
        }
    }
    """
    result = {}
    
    if data.get('allow_clients'):
        allow_client_addresses = []
        for client in data['allow_clients']:
            if client.get('address'):
                allow_client_addresses.append(client['address'])
        
        if allow_client_addresses:
            result['allow-client'] = {'address': allow_client_addresses}
    
    if data.get('interface'):
        result['interface'] = data['interface']
    
    if data.get('listen_address'):
        result['listen-address'] = data['listen_address']
    
    if data.get('leap_second'):
        result['leap-second'] = data['leap_second']
    
    if data.get('ptp'):
        ptp_config = {}
        if data['ptp'].get('port'):
            ptp_config['port'] = data['ptp']['port']
        if data['ptp'].get('interfaces'):
            ptp_config['timestamp-interface'] = data['ptp']['interfaces']
        
        if ptp_config:
            result['ptp'] = ptp_config
    
    if data.get('servers'):
        server_config = {}
        for server in data['servers']:
            if server.get('address'):
                server_address = server['address']
                server_options = {}
                
                for option in ['interleave', 'noselect', 'nts', 'pool', 'ptp']:
                    if server.get(option):
                        server_options[option] = {}
                
                server_config[server_address] = server_options
        
        if server_config:
            result['server'] = server_config
    
    import pprint
    logger.debug(f"Converted NTP config: {pprint.pformat(result, indent=2, width=80)}")
    
    return result


def parse_ntp_system(data):
    """
    Parse NTP system status data into a structured dictionary.
    
    Sample data:
        Reference ID    : 603511F6 (96.53.17.246)
        Stratum         : 4
        Ref time (UTC)  : Thu Apr 03 17:22:07 2025
        System time     : 0.003282160 seconds slow of NTP time
        Last offset     : -0.004008784 seconds
        RMS offset      : 0.001333268 seconds
        Frequency       : 0.855 ppm fast
        Residual freq   : -0.169 ppm
        Skew            : 0.260 ppm
        Root delay      : 0.068179026 seconds
        Root dispersion : 0.017737787 seconds
        Update interval : 2058.2 seconds
        Leap status     : Normal
    """
    if not data:
        return {}
    
    result = {}
    
    lines = data.strip().split('\n')
    for line in lines:
        if ':' in line:
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()
            
            if key == 'Reference ID' and '(' in value and ')' in value:
                ref_id_parts = value.split('(', 1)
                ref_id = ref_id_parts[0].strip()
                ref_ip = ref_id_parts[1].rstrip(')')
                result['reference_id'] = ref_id
                result['reference_ip'] = ref_ip
            else:
                key_snake = key.lower().replace(' ', '_')
                result[key_snake] = value
    
    if 'system_time' in result:
        if 'slow of NTP time' in result['system_time'] or 'fast of NTP time' in result['system_time']:
            result['sync_status'] = 'Synchronized'
        else:
            result['sync_status'] = 'Unsynchronized'
    
    return result


def parse_ntp_source(data):
    """
    Parse NTP source data into a structured dictionary.
    
    Sample data:
        .-- Source mode  '^' = server, '=' = peer, '#' = local clock.
    / .- Source state '*' = current best, '+' = combined, '-' = not combined,
    | /             'x' = may be in error, '~' = too variable, '?' = unusable.
    ||                                                 .- xxxx [ yyyy ] +/- zzzz
    ||      Reachability register (octal) -.           |  xxxx = adjusted offset,
    ||      Log2(Polling interval) --.      |          |  yyyy = measured offset,
    ||                                \     |          |  zzzz = estimated error.
    ||                                 |    |           \
    MS Name/IP address         Stratum Poll Reach LastRx Last sample               
    ===============================================================================
    ^* 96.53.17.246                  3  10   275   750  -6964us[  -11ms] +/-   72ms
    ^+ ec2-34-206-168-146.compu>     2  10   377   842  +1940us[-2065us] +/-   49ms
    ^- ec2-18-193-41-138.eu-cen>     3  10   377   925  +4932us[ +930us] +/-   94ms
    ^- ec2-122-248-201-177.ap-s>     2  10   373   829    +11ms[+7199us] +/-  226ms
    """
    if not data:
        return []
    
    result = []
    
    header_line = None
    data_lines = []
    
    lines = data.strip().split('\n')
    for i, line in enumerate(lines):
        if 'Name/IP address' in line:
            header_line = i
            break
    
    if header_line is not None:
        data_start = header_line + 2
        
        for i in range(data_start, len(lines)):
            line = lines[i].strip()
            if not line:
                continue
                
            if len(line) < 2:
                continue
                
            mode_char = line[0]
            state_char = line[1]
            
            mode = 'unknown'
            if mode_char == '^':
                mode = 'server'
            elif mode_char == '=':
                mode = 'peer'
            elif mode_char == '#':
                mode = 'local'
            
            state = 'unknown'
            if state_char == '*':
                state = 'current_best'
            elif state_char == '+':
                state = 'combined'
            elif state_char == '-':
                state = 'not_combined'
            elif state_char == 'x':
                state = 'error'
            elif state_char == '~':
                state = 'too_variable'
            elif state_char == '?':
                state = 'unusable'
            
            parts = line[2:].strip().split()
            if len(parts) < 6:
                continue
                
            source = {
                'mode': mode,
                'state': state,
                'address': parts[0],
                'stratum': parts[1],
                'poll': parts[2],
                'reach': parts[3],
                'last_rx': parts[4]
            }
            
            source['last_sample'] = ' '.join(parts[5:])
            
            result.append(source)
    
    return result

def parsed_ntp_source_gql(ntp_source, ntp_source_stats):
    """
    Parse NTP Source and NTP source statistics then combine them together
    
    Args:
        ntp_source: GraphQL response containing NTP source data
        ntp_source_stats: GraphQL response containing NTP source statistics data
        
    Returns:
        A list of dictionaries with combined NTP source information
    """
    result = []
    
    if not ntp_source or not isinstance(ntp_source, dict):
        logger.error("Invalid NTP source data format")
        return result
        
    if not ntp_source_stats or not isinstance(ntp_source_stats, dict):
        logger.error("Invalid NTP source statistics data format")
    
    sources = []
    try:
        if 'ShowSourcesNtpQuery' in ntp_source and \
           ntp_source['ShowSourcesNtpQuery'].get('data', {}).get('result'):
            sources = ntp_source['ShowSourcesNtpQuery']['data']['result']
    except Exception as e:
        logger.error(f"Error extracting NTP source data: {str(e)}")
        return result
    

    stats = []
    stats_by_name = {}
    try:
        if ntp_source_stats and 'ShowSourcestatsNtpQuery' in ntp_source_stats and \
           ntp_source_stats['ShowSourcestatsNtpQuery'].get('data', {}).get('result'):
            stats = ntp_source_stats['ShowSourcestatsNtpQuery']['data']['result']
            
            for stat in stats:
                if 'name_ip_address' in stat:
                    stats_by_name[stat['name_ip_address']] = stat
    except Exception as e:
        logger.error(f"Error extracting NTP source statistics data: {str(e)}")

    for source in sources:
        try:
            name = source.get('name_ip_address', '')
            state = source.get('state', '')
            mode = source.get('mode', '')
            
            try:
                stratum = int(source.get('stratum', '0'))
            except (ValueError, TypeError):
                stratum = 0
                
            try:
                poll = int(source.get('poll', '0'))
            except (ValueError, TypeError):
                poll = 0
                
            reach = source.get('reach', '')
            
            try:
                last_rx = int(source.get('last_rx', '0'))
            except (ValueError, TypeError):
                last_rx = 0
            
            last_sample = {}
            for field in ['adj_offset', 'est_error', 'mes_offset']:
                source_field = f'last_sample_{field}'
                try:
                    if source_field in source and source[source_field]:
                        last_sample[field] = float(source[source_field])
                    else:
                        last_sample[field] = 0.0
                except (ValueError, TypeError):
                    last_sample[field] = 0.0
            
            combined_entry = {
                'name': name,
                'state': state,
                'mode': mode,
                'stratum': stratum,
                'poll': poll,
                'reach': reach,
                'last_rx': last_rx,
                'last_sample': last_sample,
                'statistics': {}
            }
            
            if name in stats_by_name:
                stat = stats_by_name[name]
                statistics = {}
                
                for field, default in [
                    ('frequency', 0.0),
                    ('freq_skew', 0.0),
                    ('offset', 0.0),
                    ('std_dev', 0.0)
                ]:
                    try:
                        if field in stat and stat[field]:
                            statistics[field] = float(stat[field])
                        else:
                            statistics[field] = default
                    except (ValueError, TypeError):
                        statistics[field] = default
                
                for field, default in [('span', 0), ('np', 0), ('nr', 0)]:
                    try:
                        if field in stat and stat[field]:
                            statistics[field] = int(stat[field])
                        else:
                            statistics[field] = default
                    except (ValueError, TypeError):
                        statistics[field] = default
                
                combined_entry['statistics'] = statistics
            
            result.append(combined_entry)
        except Exception as e:
            logger.error(f"Error processing NTP source {source.get('name_ip_address', 'unknown')}: {str(e)}")

    return result

def parse_ntp_system_gql(ntp_system):
    """Parse NTP system data from GraphQL query response.
    """
    try:
        if not ntp_system or 'ShowSystemNtpQuery' not in ntp_system:
            logger.error("Invalid NTP system data structure")
            return {}
            
        query_data = ntp_system.get('ShowSystemNtpQuery', {})
        if not query_data.get('success'):
            logger.error(f"NTP system query failed: {query_data.get('errors')}")
            return {}
            
        data = query_data.get('data', {}).get('result', [])
        if not data or not isinstance(data, list) or len(data) == 0:
            logger.warning("No NTP system data available")
            return {}
            
        ntp_data = data[0]
        
        result = {
            'frequency': float(ntp_data.get('frequency', 0.0)),
            'last_offset': float(ntp_data.get('last_offset', 0.0)),
            'leap_status': ntp_data.get('leap_status', 'Unknown'),
            'ref_id': ntp_data.get('ref_id', ''),
            'ref_id_name': ntp_data.get('ref_id_name', ''),
            'ref_time': ntp_data.get('ref_time', ''),
            'residual_freq': float(ntp_data.get('residual_freq', 0.0)),
            'rms_offset': float(ntp_data.get('rms_offset', 0.0)),
            'root_delay': float(ntp_data.get('root_delay', 0.0)),
            'root_dispersion': float(ntp_data.get('root_dispersion', 0.0)),
            'skew': float(ntp_data.get('skew', 0.0)),
            'stratum': int(ntp_data.get('stratum', 0)),
            'system_time': float(ntp_data.get('system_time', 0.0)),
            'update_interval': float(ntp_data.get('update_interval', 0.0))
        }
        
        return result
    except Exception as e:
        logger.error(f"Error parsing NTP system data: {str(e)}")
        return {}
