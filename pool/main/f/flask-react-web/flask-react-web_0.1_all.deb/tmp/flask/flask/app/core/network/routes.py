from app.core.network import vyos_network_bp
from flask import jsonify, request
from app.core.api.manager import api_manager
from app.core.api.api import API_ACTION, API_TARGET
from app.core.network.dns.models import CreateDNSServerDTO, DeleteDNSServerDTO, DNSForwarding, UpdateDNSDTO, DNSServer, DNSDynamicHostGroup, DNSDynamicInterface, \
    UpdateDynamicDNSDTO
from app.auth.utils import login_required
from app.core.network.dns.jobs.dns_server import refresh_db_dns_server
from app.core.network.dns.jobs.dns_forward import refresh_db_dns_forward
from app.core.network.dns.jobs.dns_dynamic import refresh_db_dns_dynamic
from app.core.network.dns.jobs.dns import refresh_db_dns
from app.core.network.dns.cmd.compare_dns import compare_dns_forward
from app.core.api.http.cmd.compare import compare_configs
from app.core.network.dns.parser import parse_to_dns_dynamic_config
from app.core.models import Interface
from app.core.network.nat.models import NATv4
import pprint
from app.core.network.nat.models import VerifyNATDTO, UpdateNATDTO
from app.core.network.nat.parser import parse_to_nat_config
from app.core.network.dhcp.models import VerifyDHCPDTO, UpdateDHCPDTO, DHCPPool, DHCPListenInterface, DHCPRelay, SUBNETDTO, DHCPPoolv6, DHCPListenInterfacev6
from app.core.network.dhcp.parser import parse_to_dhcp_config
from app.core.models import ServiceState
from app.core.network.dhcp.utils import is_subnet_connected
from app.core.network.ntp.models import NTPConfig, NTPAllowClient, NTPServer, NTPPTP, NTPDTO
from app.core.network.ntp.parser import parse_to_ntp_config


@vyos_network_bp.route('/host-table', methods=['GET'])
def get_host_table():
    data = [
        {'host_name': 'example.com', 'ip_address': '1.1.1.1'},
        {'host_name': 'example-2.com', 'ip_address': '1.1.10.10'}
    ]
    return jsonify(data), 200

@vyos_network_bp.route('/host-table', methods=['POST'])
def create_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/host-table', methods=['PUT'])
def update_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/host-table', methods=['DELETE'])
def delete_host_table():
    return jsonify({'message': 'Success'}), 200

@vyos_network_bp.route('/dns', methods=['GET'])
@login_required
def get_dns():
    try:
        # DNS Server
        records = DNSServer.query.all()
        dns_server = {
            "ipv4": [],
            "ipv6": []
        }
        for record in records:
            data = record.serialize()
            if data["ip_address_type"] == "ipv4":
                dns_server["ipv4"].append(data["ip_address"])
            elif data["ip_address_type"] == "ipv6":
                dns_server["ipv6"].append(data["ip_address"])
                
        # DNS Forward
        dns_forward = DNSForwarding.query.first()
        if dns_forward:
            dns_forward = dns_forward.serialize()
        
        # DNS Dynamic
        host_groups = DNSDynamicHostGroup.query.all()
        ifaces = DNSDynamicInterface.query.all()
        host_groups = [group.serialize() for group in host_groups]
        ifaces = [iface.serialize() for iface in ifaces]
        
        # Interface List
        interfaces = Interface.get_interface_names()

        return jsonify({
            "dns_server": dns_server, 
            "forwarding": dns_forward, 
            "ddns": {
                "host_group": host_groups, 
                "dns_interface": ifaces
            },
            "interfaces": interfaces
        }), 200
    except Exception as e:
        print(e)
        return jsonify({
            "dns_server": {
                "ipv4": [],
                "ipv6": []
            },
            "forwarding": None,
            "ddns": {
                "host_group": [],
                "dns_interface": []
            }
        }), 400


@vyos_network_bp.route('/dns/server', methods=['GET'])
@login_required
def get_dns_server():
    try:
        records = DNSServer.query.all()
        response = {
            "ipv4": [],
            "ipv6": []
        }

        for record in records:
            data = record.serialize()
            if data["ip_address_type"] == "ipv4":
                response["ipv4"].append(data["ip_address"])
            elif data["ip_address_type"] == "ipv6":
                response["ipv6"].append(data["ip_address"])

        return jsonify(response), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/server', methods=['POST'])
@login_required
def create_dns_server():
    try:
        data = CreateDNSServerDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.CREATE, target=API_TARGET.DNS_SERVER, data=data)
        refresh_db_dns_server()
        return jsonify(res), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/server', methods=['DELETE'])
@login_required
def delete_dns_server():
    try:
        data = DeleteDNSServerDTO.model_validate_json(request.data)
        res = api_manager.call(action=API_ACTION.DELETE, target=API_TARGET.DNS_SERVER, data=data)
        refresh_db_dns_server()
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/forward', methods=['GET'])
def get_dns_forward():
    try:
        res = DNSForwarding.query.first().serialize()
        return jsonify(res), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/forward', methods=['PUT'])
@login_required
def update_dns_forward():
    try:
        data = UpdateDNSDTO.model_validate_json(request.data)
        new_dns_forward = data.forwarding
        # Convert to dict, then save to db
        DNSForwarding.refresh(new_dns_forward.model_dump())

        # Query in VyOS
        current_dns_forward = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_FORWARD)
        diff = compare_dns_forward(new_dns_forward, current_dns_forward)

        # Send updates to VyOS
        if diff:
            print("Diff data:", diff)
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_FORWARD,
                data={"current": current_dns_forward, "new": new_dns_forward, "diff": diff}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            else:
                refresh_db_dns_forward()
                return jsonify(res), 200

        return jsonify({"message": "No changes detected"}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dns/dynamic', methods=['GET'])
@login_required
def get_dns_dynamic():
    try:
        host_groups = DNSDynamicHostGroup.query.all()
        ifaces = DNSDynamicInterface.query.all()
        host_groups = [group.serialize() for group in host_groups]
        ifaces = [iface.serialize() for iface in ifaces]

        return jsonify({
            "host_groups": host_groups,
            "ifaces": ifaces
        }), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns/dynamic', methods=['PUT'])
@login_required
def update_dns_dynamic():
    try:
        data = UpdateDynamicDNSDTO.model_validate_json(request.data)
        print(data)
        return jsonify({"message": "Success"}), 200
    except Exception as e:
        return str(e), 400


@vyos_network_bp.route('/dns', methods=['PUT'])
@login_required
def update_dns():
    try:
        data = UpdateDNSDTO.model_validate_json(request.data)
        # print("Validated data:", data)
        new_dns_forward = data.forwarding
        # new_dns_server = data.dns_server
        new_ddns = data.ddns

        # Convert to dict, then save to db
        # DNSForwarding.refresh(new_dns_forward.model_dump())

        # Query in VyOS
        current_dns = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS)
        current_dns_forward = current_dns["forwarding"] if "forwarding" in current_dns else None
        current_ddns =  current_dns["dynamic"] if "dynamic" in current_dns else None

        # print("Current DNS data:", current_dns)
        # print("New DNS data:", data)

        # current_dns_server = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DNS_SERVER)

        # diff = compare_dns_forward(new_dns_forward, current_dns_forward)
        # print("New DNS Forward:", new_dns_forward)

        if new_dns_forward is None:
            diff_forward = compare_configs({}, current_dns_forward)
        else:
            diff_forward = compare_configs(new_dns_forward.model_dump(), current_dns_forward)
        # print("Compare DNS Forward:", diff_forward)

        # diff_server = compare_configs(new_dns_server.model_dump(), current_dns_server, None)
        # print("Current DNS :", current_dns)
        
        print("Current DDNS:", current_ddns)
        print("New DDNS:", new_ddns.model_dump().get('interfaces'))
        print("Parsed New DDNS:", parse_to_dns_dynamic_config(new_ddns.model_dump().get('interfaces')))
        diff_ddns = compare_configs(
            parse_to_dns_dynamic_config(new_ddns.model_dump().get('interfaces')), 
            current_ddns
        )

        print("Compare DNS Dynamic:", diff_ddns)

        # API Manager handles logic
        r = []
        _data = {
            "forwarding": {
                "current": current_dns_forward,
                "new": new_dns_forward,
                "diff": diff_forward
            },
            "dynamic": {
                "current": current_ddns,
                "new": new_ddns,
                "diff": diff_ddns
            }
        }

        # Update DNS Forwarding
        if diff_forward:
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_FORWARD,
                data={"current": current_dns_forward, "new": new_dns_forward, "diff": diff_forward}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            r += res
            refresh_db_dns_forward()

        # Update DNS Dynamic
        if diff_ddns:
            res = api_manager.call(
                action=API_ACTION.UPDATE,
                target=API_TARGET.DNS_DYNAMIC,
                data={"current": current_ddns, "new": new_ddns, "diff": diff_ddns}
            )
            if isinstance(res, Exception):
                return jsonify({'error': str(res)}), 400
            r += res
            refresh_db_dns_dynamic()
        
        # Update combined dns_dynamic and dns_forward
        # res = api_manager.call(action=API_ACTION.UPDATE, target=API_TARGET.DNS, data=_data)
        # if isinstance(res, Exception):
        #     return jsonify({'error': str(res)}), 400
        # r += res
        # refresh_db_dns()

        return jsonify(r), 200

    except Exception as e:
        print("Exception:", e)
        print("Type: ", type(e))
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat', methods=['GET'])
@login_required
def get_nat():
    try:
        interfaces = Interface.get_interface_names()
        nat = NATv4.query.all()
        nat_dict = {
            "interfaces": interfaces,
            "nat_v4": []
        }
        for n in nat:
            nat_dict["nat_v4"].append(n.serialize())
        
        # nat_query = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT)
        return jsonify(nat_dict), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat', methods=['PUT'])
@login_required
def update_nat():
    try:
        data = UpdateNATDTO.model_validate_json(request.data)
        print("Validated data:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT)
        print("Current NAT Config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        # Parse new config to VyOS format
        new_config = parse_to_nat_config(data.model_dump())
        print("New config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        diff = compare_configs(new_config, current_config)
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.NAT, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        
        return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/verify', methods=['POST'])
@login_required
def verify_nat():
    try:
        data = VerifyNATDTO.model_validate_json(request.data)
        print("Unparsed config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        nat_config = parse_to_nat_config(data.model_dump())
        print("Parsed config: ")
        print(pprint.pformat(nat_config, indent=2, width=80))
        verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.NAT, data=nat_config)
        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400
    
    except Exception as e:
        print("Error:", e)
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/nat/stat', methods=['GET'])
@login_required
def get_nat_stat():
    try:
        nat_source_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'source'})
        nat_destination_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'destination'})

        return jsonify({
            'source': nat_source_stat,
            'destination': nat_destination_stat
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/destination', methods=['GET'])
@login_required
def get_nat_destination():
    try:
        nat_destination = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_DESTINATION)
        return jsonify(nat_destination), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@vyos_network_bp.route('/nat/source', methods=['GET'])
@login_required
def get_nat_source():
    try:
        nat_source = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_SOURCE)
        return jsonify(nat_source), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400



@vyos_network_bp.route('/nat/source/stat', methods=['GET'])
@login_required
def get_nat_source_stat():
    try:
        nat_source_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'source'})
        return jsonify(nat_source_stat), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/nat/destination/stat', methods=['GET'])
@login_required
def get_nat_destination_stat():
    try:
        nat_destination_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NAT_STAT, data={'direction': 'destination'})
        return jsonify(nat_destination_stat), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp', methods=['GET'])
@login_required
def get_dhcp():
    try:
        listen_interfaces = DHCPListenInterface.query.all()
        pools = DHCPPool.query.all()
        relay = DHCPRelay.query.first()
        listen_interfaces_v6 = DHCPListenInterfacev6.query.all()
        pools_v6 = DHCPPoolv6.query.all()
        interfaces = Interface.get_interface_names()
        dhcp_state = ServiceState.get_state('dhcp_server')
        dhcpv6_state = ServiceState.get_state('dhcpv6_server')
        
        response = {
            "dhcp": {
                "listen_interface": [l.interface for l in listen_interfaces],
                "pools": [p.serialize() for p in pools],
                "disabled": dhcp_state == 'disable'
            },
            "dhcpv6": {
                "listen_interface": [l.interface for l in listen_interfaces_v6],
                "pools": [p.serialize() for p in pools_v6],
                "disabled": dhcpv6_state == 'disable'
            },
            "dhcpRelays": relay.serialize() if relay else None,
            "interfaces": interfaces
        }
        
        return jsonify(response), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/verify', methods=['POST'])
@login_required
def verify_dhcp():
    try:
        
        data = VerifyDHCPDTO.model_validate_json(request.data)
        
        print("Unparsed config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        
        dhcp_config = parse_to_dhcp_config(data.model_dump())
        
        print("Parsed config: ")
        print(pprint.pformat(dhcp_config, indent=2, width=80))
        
        if data.verify_type == "dhcp":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCP, data=dhcp_config.get("dhcp", {}))
        elif data.verify_type == "dhcpv6":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCPV6, data=dhcp_config.get("dhcpv6", {}))
        elif data.verify_type == "relay":
            verify = api_manager.call(action=API_ACTION.VERIFY, target=API_TARGET.DHCP_RELAY, data=dhcp_config.get("dhcp_relay", {}))
        else:
            return jsonify({"error": "Invalid verify type"}), 400

        if verify == "None" or verify is None or verify == "":
            return jsonify({"verify": "Success"}), 200
        return jsonify({"verify": verify}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp', methods=['PUT'])
@login_required
def update_dhcp():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP
        new_config = dhcp_config.get("dhcp", {})
        print("Parsed config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCP, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        # Refresh DB
        # If failed to update, return old configs
        # If success, return new configs
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except Exception as e:
        print("Exception:", e.message)
        return jsonify({'error': str(e)}), 400

    
@vyos_network_bp.route('/dhcpv6', methods=['PUT'])
@login_required
def update_dhcpv6():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP
        new_config = dhcp_config.get("dhcpv6", {})
        print("Parsed config: ")
        print(pprint.pformat(new_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCPV6, 
            data={"current": current_config, "new": new_config, "diff": diff}
        )
        
        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/relay', methods=['PUT'])
@login_required
def update_dhcp_relay():
    try:
        data = UpdateDHCPDTO.model_validate_json(request.data)
        print("Request config:")
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        dhcp_config = parse_to_dhcp_config(data.model_dump())

        # Update DHCP Relay
        new_relay_config = dhcp_config.get("dhcp_relay", {})
        print("Parsed relay config: ")
        print(pprint.pformat(new_relay_config, indent=2, width=80))

        current_relay_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_RELAY)
        print("Current relay config: ")
        print(pprint.pformat(current_relay_config, indent=2, width=80))
        
        relay_diff = compare_configs(new_relay_config, current_relay_config)
        print("Diff relay config: ")
        print(pprint.pformat(relay_diff, indent=2, width=80))
        
        relay_res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.DHCP_RELAY, 
            data={"current": current_relay_config, "new": new_relay_config, "diff": relay_diff}
        )

        if isinstance(relay_res, Exception):
            return jsonify({'error': str(relay_res)}), 400
        else:
            return jsonify(relay_res), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/relay', methods=['GET'])
@login_required
def get_dhcp_relay():
    try:
        dhcp_relay = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_RELAY)
        
        return jsonify(dhcp_relay), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/stat', methods=['GET'])
@login_required
def get_dhcp_stat():
    try:
        dhcp_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_POOL_STATISTICS)
        return jsonify(dhcp_stat), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/pool', methods=['GET'])
@login_required
def get_dhcp_pool():
    try:
        dhcp_pool = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCP_POOL_LIST)
        return jsonify(dhcp_pool), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcpv6/stat', methods=['GET'])
@login_required
def get_dhcpv6_stat():
    try:
        dhcpv6_stat = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6_POOL_STATISTICS)
        return jsonify(dhcpv6_stat), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcpv6/pool', methods=['GET'])
@login_required
def get_dhcpv6_pool():
    try:
        dhcpv6_pool = api_manager.call(action=API_ACTION.READ, target=API_TARGET.DHCPV6_POOL_LIST)
        return jsonify(dhcpv6_pool), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/dhcp/subnet', methods=['POST'])
@login_required
def query_subnet():
    try:
        data = SUBNETDTO.model_validate_json(request.data)
        ip = is_subnet_connected(data.subnet)
        return jsonify({"ip": ip}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp', methods=['GET'])
@login_required
def get_ntp_config():
    try:
        ntp_config_data = NTPConfig.query.first()
        if not ntp_config_data:
            return jsonify({"error": "No NTP configuration found"}), 404
        
        result = ntp_config_data.serialize()
        
        allow_clients = NTPAllowClient.query.all()
        result['allow_clients'] = [client.serialize() for client in allow_clients]
        
        servers = NTPServer.query.all()
        result['servers'] = [server.serialize() for server in servers]
        
        ptp_config = NTPPTP.query.first()
        if ptp_config:
            result['ptp'] = ptp_config.serialize()
        else:
            result['ptp'] = None
        
        interfaces = Interface.get_interface_names()
        result['available_interfaces'] = interfaces
        
        return jsonify(result), 200
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp', methods=['PUT'])
@login_required
def update_ntp():
    try:
        data = NTPDTO.model_validate_json(request.data)
        print(pprint.pformat(data.model_dump(), indent=2, width=80))
        new_ntp_config = parse_to_ntp_config(data.model_dump())
        print(pprint.pformat(new_ntp_config, indent=2, width=80))

        current_config = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP)
        print("Current config: ")
        print(pprint.pformat(current_config, indent=2, width=80))
        
        diff = compare_configs(new_ntp_config, current_config)
        
        print("Diff config: ")
        print(pprint.pformat(diff, indent=2, width=80))
        
        res = api_manager.call(
            action=API_ACTION.UPDATE, 
            target=API_TARGET.NTP, 
            data={"current": current_config, "new": new_ntp_config, "diff": diff}
        )

        # Refresh DB
        api_manager.call(action=API_ACTION.READ, target=API_TARGET.OS_CONFIG, data={"refresh": True})

        if isinstance(res, Exception):
            return jsonify({'error': str(res)}), 400
        else:
            return jsonify(res), 200


        return jsonify({"success": True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp/system', methods=['GET'])
@login_required
def get_ntp_system():
    try:
        ntp_system = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP_SYSTEM)
        return jsonify(ntp_system), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@vyos_network_bp.route('/ntp/source', methods=['GET'])
@login_required
def get_ntp_source():
    try:
        ntp_source = api_manager.call(action=API_ACTION.READ, target=API_TARGET.NTP_SOURCE)
        return jsonify(ntp_source), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400