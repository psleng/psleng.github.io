import os 
import importlib
import importlib.util
import requests

hostname = os.environ.get("VYOS_HOSTNAME")

linux_root_path = "/usr/libexec/vyos"

location = {
    "service_dns_forwarding": "/conf_mode/service_dns_forwarding.py"   
}

funcs = ["get_config", "verify", "generate", "apply"]

# call the get_config function
def call_get_config(service: str) -> str:
    try:
        # Call the get_config function from linux path
        file_path = linux_root_path + location[service]
        spec = importlib.util.spec_from_file_location(service, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        get_config = getattr(module, "get_config")
        return get_config()
    except Exception as e:
        print(f"Error call_get_config {service}: {str(e)}")
        return ""
