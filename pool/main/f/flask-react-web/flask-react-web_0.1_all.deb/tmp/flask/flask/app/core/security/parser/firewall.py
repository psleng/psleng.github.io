import re
import pprint
from datetime import datetime
import pytz

def convert_CIDR_predix_to_subnet_mask(cidr: int) -> str:

    if not isinstance(cidr, int) or cidr < 0 or cidr > 32:
        raise ValueError('CIDR prefix must be an integer between 0 and 32')

    binary = ('1' * cidr + '0' * (32 - cidr))
    
    octets = [binary[i:i+8] for i in range(0, 32, 8)]
    decimal_octets = [str(int(octet, 2)) for octet in octets]
    
    return '.'.join(decimal_octets)

def convert_to_CIDR(subnet_mask: str) -> int:
    if not subnet_mask or not re.match(r'^(\d{1,3}\.){3}\d{1,3}$', subnet_mask):
        return ""
    
    return convert_subnet_mask_to_CIDR(subnet_mask)

def convert_subnet_mask_to_CIDR(subnet_mask: str) -> int:

    if not re.match(r'^(\d{1,3}\.){3}\d{1,3}$', subnet_mask):
        raise ValueError('Invalid subnet mask format')
    
    try:
        binary = ''.join([bin(int(x))[2:].zfill(8) for x in subnet_mask.split('.')])
        if '01' in binary:  
            raise ValueError('Invalid subnet mask: 1s must be continuous')
        return binary.count('1')
    except Exception as e:
        raise ValueError(f'Invalid subnet mask: {str(e)}')

def validate_and_convert_subnet(subnet: str | int) -> str:

    if isinstance(subnet, int) or (isinstance(subnet, str) and subnet.isdigit()):
        return convert_CIDR_predix_to_subnet_mask(int(subnet))
    elif isinstance(subnet, str):
        cidr = convert_subnet_mask_to_CIDR(subnet)
        return convert_CIDR_predix_to_subnet_mask(cidr)
    else:
        raise ValueError('Subnet must be either an integer CIDR prefix or a string subnet mask')

def get_severity(priority):
    """Map syslog priority to severity level."""
    severity_map = {
        '0': 'emergency',
        '1': 'alert',
        '2': 'critical',
        '3': 'error',
        '4': 'warning',
        '5': 'notice',
        '6': 'info',
        '7': 'debug'
    }
    return severity_map.get(str(priority), 'unknown')

def parse_firewall_operation_log(response_data):
    """Parse VyOS firewall operation logs from GraphQL response.
    
    Args:
        response_data (dict): GraphQL response containing ShowLog data
        
    Returns:
        list: List of parsed firewall log entries, sorted by timestamp from newest to oldest
    """
    try:
        if not response_data or 'ShowLog' not in response_data:
            return []
            
        log_entries = []
        results = response_data['ShowLog']['data']['result']
        
        # Set up timezone
        toronto_tz = pytz.timezone('America/Toronto')
        
        for entry in results:
            # Only process kernel logs with ipv4/ipv6 raw prefix
            if entry['syslog_identifier'] != 'kernel' or not any(f'[{ip}-' in entry['message'] for ip in ['ipv4', 'ipv6']):
                continue
                
            # Parse the message
            msg = entry['message']
            
            # Extract IP version
            ip_version = 'ipv4' if 'ipv4-' in msg else 'ipv6'
            
            # Extract interfaces first
            interface_in = ''
            interface_out = ''
            
            # Find IN= in the message (it might be attached to the prefix)
            if 'IN=' in msg:
                in_start = msg.index('IN=') + 3
                in_end = msg.find(' ', in_start)
                if in_end == -1:
                    in_end = len(msg)
                interface_in = msg[in_start:in_end]
            
            # Find OUT= in the message
            if 'OUT=' in msg:
                out_start = msg.index('OUT=') + 4
                out_end = msg.find(' ', out_start)
                if out_end == -1:
                    out_end = len(msg)
                interface_out = msg[out_start:out_end]
            
            # Parse remaining key-value pairs
            pairs = {}
            for part in msg.split(' '):
                if '=' in part:
                    key, val = part.split('=', 1)
                    pairs[key] = val
            
            # Convert timestamp to Toronto timezone
            utc_dt = datetime.fromtimestamp(int(entry['realtime_timestamp']) / 1000000, pytz.UTC)
            toronto_dt = utc_dt.astimezone(toronto_tz)
            
            # Get severity from priority
            severity = get_severity(entry['priority'])
            
            log_entry = {
                'ip_version': ip_version,
                'priority': severity,
                'interface_in': interface_in,
                'interface_out': interface_out,
                'source': pairs.get('SRC', ''),
                'destination': pairs.get('DST', ''),
                'source_port': pairs.get('SPT', ''),
                'destination_port': pairs.get('DPT', ''),
                'protocol': pairs.get('PROTO', ''),
                'bytes': int(pairs.get('LEN', 0)),
                'timestamp': toronto_dt,
                'message': msg
            }
            
            log_entries.append(log_entry)
    
        # Sort log entries by timestamp from newest to oldest
        # log_entries.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return log_entries
    except Exception as e:
        print(f"Error parsing firewall operation log: {str(e)}")
        return []

def parse_firewall_operation(data):
    result = {
        'ipv4': {},
        'ipv6': {}
    }

    def transform_ruleset_name(name):
        name = name.lower().strip()
        name = name.replace('raw', '').strip()
        if 'prerouting' in name:
            return 'inbound'
        elif 'output' in name:
            return 'outbound'
        return name

    if not isinstance(data, str) or not data.strip():
        return result

    blocks = []
    current_block = []
    in_block = False
    
    for line in data.split('\n'):
        line = line.rstrip()
        if line.startswith('ipv'):
            # Start of a new block
            if current_block:
                blocks.append('\n'.join(current_block))
            current_block = [line]
            in_block = True
        elif in_block:
            current_block.append(line)
    
    # Add the last block
    if current_block:
        blocks.append('\n'.join(current_block))

    for block in blocks:
        lines = [line for line in block.split('\n') if line.strip() and not line.startswith('--')]
        if not lines:
            continue

        # Parse ruleset type and name
        header = lines[0]
        if not ('ipv4' in header.lower() or 'ipv6' in header.lower()):
            continue

        ip_version = 'ipv4' if 'ipv4' in header.lower() else 'ipv6'
        ruleset_raw = header.split('"')[1] if '"' in header else ''
        ruleset_name = transform_ruleset_name(ruleset_raw)

        # Find the header row
        header_row = None
        data_start = 0
        for i, line in enumerate(lines):
            if 'Rule' in line and 'Action' in line:
                header_row = line
                data_start = i + 1  # Skip header
                break

        if not header_row:
            continue

        # Parse headers
        headers = []
        for header in header_row.split():
            header = header.lower()
            if header == 'rule':
                headers.append('rule_number')
            else:
                headers.append(header)

        # Initialize ruleset
        if ruleset_name not in result[ip_version]:
            result[ip_version][ruleset_name] = {'rules': []}

        # Parse rules
        for line in lines[data_start:]:
            if not line or '-' * 5 in line:
                continue

            # Split the line into fields
            fields = []
            current_field = ''
            in_space = False

            for char in line:
                if char.isspace():
                    if not in_space and current_field:
                        fields.append(current_field)
                        current_field = ''
                    in_space = True
                else:
                    current_field += char
                    in_space = False
            
            if current_field:
                fields.append(current_field)

            if len(fields) < 3:  # Need at least rule, action, protocol
                continue

            rule_data = {}
            conditions_text = ''

            # Process each field
            for i, field in enumerate(fields):
                if i < len(headers):
                    header = headers[i]
                    if header in ['packets', 'bytes']:
                        try:
                            rule_data[header] = int(field.replace(',', ''))
                        except (ValueError, TypeError):
                            rule_data[header] = 0
                    else:
                        rule_data[header] = field
                else:
                    conditions_text += ' ' + field

            # Process conditions if present
            if conditions_text:
                conditions_text = conditions_text.strip()
                
                # Extract protocol info
                l4proto_match = re.search(r'meta l4proto\s+([^\s]+)', conditions_text)
                if l4proto_match:
                    proto = l4proto_match.group(1)
                    if proto.startswith('{'):
                        protos = re.findall(r'[\w-]+', proto)
                        rule_data['protocol'] = '_'.join(p for p in protos if p not in ['{', '}'])
                    else:
                        rule_data['protocol'] = proto
                
                # Extract source address
                saddr_match = re.search(r'ip saddr\s+([^\s]+)', conditions_text)
                if saddr_match:
                    rule_data['source_address'] = saddr_match.group(1)
                
                # Extract prefix if present
                prefix_match = re.search(r'prefix\s+"([^"]+)"', conditions_text)
                if prefix_match:
                    rule_data['prefix'] = prefix_match.group(1)

            if rule_data:
                result[ip_version][ruleset_name]['rules'].append(rule_data)

    return result

def parse_firewall_config(data):
    if not data:
        return {}
    return data

def parse_to_firewall_config(data):
    result = {
        'global-options': {},
        'ipv4': {},
        'ipv6': {}
    }
    if data.get('advancedSettings'):
        packet_handling = data['advancedSettings'].get('packetHandling')
        
        if packet_handling:
            if packet_handling.get('ipv4_ping') is False:
                result['global-options']['all-ping'] = 'disable'
            else:
                result['global-options']['all-ping'] = 'enable'

            if packet_handling.get('invalid_address') is False:
                result['global-options']['log-martians'] = 'disable'
            else:
                result['global-options']['log-martians'] = 'enable'

        state_policy = data['advancedSettings'].get('statePolicy')

        if state_policy:
            result['global-options']['state-policy'] = {}

            if state_policy.get('established'):
                result['global-options']['state-policy']['established'] = {
                    "action": state_policy['established'].lower()
                }

            if state_policy.get('invalid'):
                result['global-options']['state-policy']['invalid'] = {
                    "action": state_policy['invalid'].lower()
                }
            
            if state_policy.get('related'):
                result['global-options']['state-policy']['related'] = {
                    "action": state_policy['related'].lower()
                }

    # Process IPv4 rules
    if data.get('firewallv4'):
        # Handle inbound (prerouting) rules
        if data['firewallv4'].get('inbound'):
            result['ipv4']['prerouting'] = {'raw': {'default_action': 'accept', 'rule': {}}}
            for rule in data['firewallv4']['inbound']:
                rule_config = create_rule_config(rule)
                result['ipv4']['prerouting']['raw']['rule'][str(rule['rule_number'])] = rule_config

        # Handle outbound (output) rules
        if data['firewallv4'].get('outbound'):
            result['ipv4']['output'] = {'raw': {'default_action': 'accept', 'rule': {}}}
            for rule in data['firewallv4']['outbound']:
                rule_config = create_rule_config(rule)
                result['ipv4']['output']['raw']['rule'][str(rule['rule_number'])] = rule_config

    # Process IPv6 rules
    if data.get('firewallv6'):
        # Handle inbound (prerouting) rules
        if data['firewallv6'].get('inbound'):
            result['ipv6']['prerouting'] = {'raw': {'default_action': 'accept', 'rule': {}}}
            for rule in data['firewallv6']['inbound']:
                rule_config = create_rule_config(rule)
                result['ipv6']['prerouting']['raw']['rule'][str(rule['rule_number'])] = rule_config

        # Handle outbound (output) rules
        if data['firewallv6'].get('outbound'):
            result['ipv6']['output'] = {'raw': {'default_action': 'accept', 'rule': {}}}
            for rule in data['firewallv6']['outbound']:
                rule_config = create_rule_config(rule)
                result['ipv6']['output']['raw']['rule'][str(rule['rule_number'])] = rule_config

    return result

def create_rule_config(rule):
    """Create a rule configuration from input data"""
    config = {}
    
    # Set basic rule properties
    if rule.get('action'):
        config['action'] = rule['action'].lower()
    if rule.get('protocol'):
        config['protocol'] = rule['protocol'].lower()
    if rule.get('log_enabled') and rule.get('log_enabled') == True:
        config['log'] = {}

    if rule.get('enabled') is False:
        config['disable'] = {}

    if rule.get('description') and rule.get('description') != "" and rule.get('description') != None:
        config['description'] = rule['description']

    # Handle source configuration
    source = {}
    if rule.get('source_address'):
        source['address'] = rule['source_address']
    if rule.get('source_subnet'):
        try:
            source['address-mask'] = validate_and_convert_subnet(rule['source_subnet'])
        except ValueError as e:
            print(f"Warning: Invalid source subnet for rule {rule.get('rule_number')}: {str(e)}")
            source['address-mask'] = '255.255.255.0'  # Default fallback
    if rule.get('source_port'):
        source['port'] = rule['source_port']
    if rule.get('source_mac'):
        source['mac-address'] = rule['source_mac']
    if source:
        config['source'] = source
    
    # Handle destination configuration
    destination = {}
    if rule.get('destination_address'):
        destination['address'] = rule['destination_address']
    if rule.get('destination_subnet'):
        try:
            destination['address-mask'] = validate_and_convert_subnet(rule['destination_subnet'])
        except ValueError as e:
            print(f"Warning: Invalid destination subnet for rule {rule.get('rule_number')}: {str(e)}")
            destination['address-mask'] = '255.255.255.0'  # Default fallback
    if rule.get('destination_port'):
        destination['port'] = rule['destination_port']
    if rule.get('destination_mac'):
        destination['mac-address'] = rule['destination_mac']
    if destination:
        config['destination'] = destination
    
    # Handle interface
    if rule.get('interface'):
        config['inbound-interface'] = {'name': rule['interface']}

    # Handle log-enabled
    if rule.get('log'):
        config['log'] = True
    
    return config

#ADD stuff to thiss
def parse_firewall_query_gql(firewall: dict):
    """
        Parse the firewall query. Each rule will have rule definition and statistics
        Sample input:
        {
            "ShowFirewallFirewallQuery": {
                "data": {
                    "result": {
                        "config": {
                            "ipv4": {
                                "prerouting": {
                                    "raw": {
                                        "default_action": "accept",
                                        "rule": {
                                            "10": {
                                                "action": "accept",
                                                "destination": {
                                                    "port": "53"
                                                },
                                                "inbound_interface": {
                                                    "name": "br100"
                                                },
                                                "log": {},
                                                "protocol": "tcp_udp",
                                                "source": {}
                                            },
                                            "20": {
                                                "action": "accept",
                                                "destination": {
                                                    "port": "53"
                                                },
                                                "log": {},
                                                "protocol": "tcp_udp"
                                            },
                                            "30": {
                                                "action": "accept",
                                                "inbound_interface": {
                                                    "name": "br11"
                                                },
                                                "protocol": "vrrp",
                                                "source": {
                                                    "address": "!192.168.1.1/32"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        "statistics": {
                            "ipv4": {
                                "rulesets": {
                                    "raw": {
                                        "hook": "prerouting",
                                        "rules": {
                                            "10": {
                                                "bytes": "0",
                                                "conditions": "meta l4proto { tcp, udp } th dport 53 iifname \"br100\"  prefix \"[ipv4-PRE-raw-10-A]\"  accept",
                                                "packets": "0"
                                            },
                                            "20": {
                                                "bytes": "0",
                                                "conditions": "meta l4proto { tcp, udp } th dport 53  prefix \"[ipv4-PRE-raw-20-A]\"  accept",
                                                "packets": "0"
                                            },
                                            "30": {
                                                "bytes": "0",
                                                "conditions": "meta l4proto vrrp ip saddr != 192.168.1.1 iifname \"br11\"  accept",
                                                "packets": "0"
                                            },
                                            "default_action": {
                                                "bytes": "507828496",
                                                "conditions": "accept comment \"PRE-raw default-action accept\"",
                                                "packets": "1601708"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "errors": null,
                "success": true
            }
        }
        
        Returns:
            list: A list of firewall rules with both definition and statistics combined
    """
    if not firewall or 'ShowFirewallFirewallQuery' not in firewall:
        return []
    
    result = []
    query_data = firewall.get('ShowFirewallFirewallQuery', {})
    
    if not query_data.get('success', False):
        return []
    
    data = query_data.get('data', {}).get('result', {})
    if not data:
        return []
    
    config = data.get('config', {})
    statistics = data.get('statistics', {})
    
    if 'ipv4' in config and 'ipv4' in statistics:
        ipv4_config = config['ipv4']
        ipv4_stats = statistics['ipv4']
        
        for chain_name, chain_data in ipv4_config.items():
            for table_name, table_data in chain_data.items():
                default_action = table_data.get('default_action', 'accept')
                
                rules = table_data.get('rule', {})
                
                stats_rules = {}
                if 'rulesets' in ipv4_stats and table_name in ipv4_stats['rulesets']:
                    ruleset = ipv4_stats['rulesets'][table_name]
                    if 'rules' in ruleset:
                        stats_rules = ruleset['rules']
                
                for rule_id, rule_config in rules.items():
                    rule_result = {
                        'family': 'ipv4',
                        'chain': chain_name,
                        'table': table_name,
                        'rule_id': rule_id,
                        'config': rule_config,
                        'default_action': default_action,
                        'statistics': {}
                    }
                    
                    if rule_id in stats_rules:
                        rule_result['statistics'] = stats_rules[rule_id]
                    
                    result.append(rule_result)
                
                if 'default_action' in stats_rules:
                    result.append({
                        'family': 'ipv4',
                        'chain': chain_name,
                        'table': table_name,
                        'rule_id': 'default',
                        'config': {'action': default_action},
                        'default_action': default_action,
                        'statistics': stats_rules.get('default_action', {})
                    })
    
    return result


if __name__ == "__main__":
    from datetime import datetime
    test_data = {
        'global-options': {
            'all-ping': {
                'ipv4-ping': {
                    'enabled': False
                },
                'log-martians': {
                    'enabled': True
                }
            },
            'state-policy' : {
                'established': {
                    'action': 'accept'
                }, 
                'invalid': {
                    'action': 'drop'
                },
                'related': {
                    'action': 'reject'
                }
            }
        },
        "ipv4": {
            "output": {
                "raw": {
                    "default_action": "accept",
                    "rule": {
                        "20": {
                            "action": "drop",
                            "destination": {
                                "port": "25"
                            },
                            "protocol": "tcp",
                            "source": {
                                "address": "192.168.0.1",
                                "address-mask": "255.255.255.0"
                            }
                        }
                    }
                }
            }
        },
        "ipv6": {
            "prerouting": {
                "raw": {
                    "default_action": "drop",
                    "rule": {
                        "10": {
                            "action": "accept",
                            "destination": {
                                "address": "2001:db8::2",
                                "port": "8080"
                            },
                            "inbound-interface": {
                                "name": "eth1"
                            },
                            "log": {},
                            "protocol": "tcp",
                            "source": {
                                "address": "2001:db8::1",
                                "port": "80"
                            }
                        }
                    }
                }
            }
        }
    }
    
    result = parse_to_firewall_config({
        "advancedSettings": {
            "packetHandling": 
            {
                "ipv4_ping": True,
                "invalid_address": False
            }
            ,   
            "statePolicy": 
            {
                "established": "Accept",
                "invalid": "Drop",
                "related": "Accept"
            }
            
        },
        "firewallv4": {
            "inbound": [
                {
                    "action": "accept",
                    "protocol": "tcp",
                    "source_address": "10.10.200.200",
                    "source_subnet": 24,
                    "destination_address": "10.0.0.200",
                    "destination_subnet": 24,
                    "rule_number": "1",
                    "enabled": False,
                    "log_enabled": False
                }
            ],
            "outbound": [
                {
                    "action": "drop",
                    "protocol": "tcp",
                    "destination_port": "25",
                    "source_address": "192.168.0.1",
                    "source_subnet": 24,
                    "rule_number": "20",
                    "log_enabled": True
                }
            ]
        },
        "firewallv6": {
            "inbound": [
                {
                    "action": "accept",
                    "protocol": "tcp",
                    "source_address": "2001:db8::1",
                    "source_port": "80",
                    "destination_address": "2001:db8::2",
                    "destination_port": "8080",
                    "interface": "eth1",
                    "rule_number": "10"
                }
            ]
        }
    })

    # print(pprint.pformat(result, indent=2, width=80))

    if_res = parse_firewall_operation_log({"ShowLog": {"data": {"result": [
        {
            "boot_id": "79ab46062fff4fc58b8537a371dd0d82",
            "cursor": "s=54529f158dd0456cb5d0c64e75edf6be;i=10db23b;b=79ab46062fff4fc58b8537a371dd0d82;m=1b9ac17159e;t=62e0ca8176ad0;x=c94d4757f8cc255a",
            "hostname": "vyos",
            "machine_id": "4946f9f854794f3882d07de71e894f54",
            "message": "[ipv4-PRE-raw-1000-A]IN=eth3 OUT= MAC=1c:63:49:1a:d1:0d:e8:c8:29:95:92:5a:08:00 SRC=10.10.200.24 DST=10.10.200.160 LEN=40 TOS=0x00 PREC=0x00 TTL=128 ID=51849 DF PROTO=TCP SPT=64377 DPT=443 WINDOW=255 RES=0x00 ACK URGP=0 ",
            "monotonic_timestamp": "1896967771550",
            "priority": "4",
            "realtime_timestamp": "1739481754856144",
            "runtime_scope": "system",
            "source_monotonic_timestamp": "1896970724663",
            "syslog_facility": "0",
            "syslog_identifier": "kernel",
            "transport": "kernel"
        }
    ]}}})

    test_firewall_str = 'Rulesets Information\n\n---------------------------------\nipv4 Firewall "output raw"\n\nRule     Action    Protocol      Packets     Bytes  Conditions\n-------  --------  ----------  ---------  --------  -----------------------------------------------\n30       accept    tcp                 0         0  meta l4proto tcp ip saddr 192.168.1.100  accept\n324      accept    tcp             41065  33140665  meta l4proto tcp  accept\ndefault  accept    all               475     30255\n\n\n---------------------------------\nipv4 Firewall "prerouting raw"\n\nRule     Action    Protocol      Packets     Bytes  Conditions\n-------  --------  ----------  ---------  --------  --------------------------------------------------------------\n1        accept    tcp_udp         75594  64016581  meta l4proto { tcp, udp }  prefix "[ipv4-PRE-raw-1-A]"  accept\n10       accept    icmp                0         0  meta l4proto icmp  accept\n20       accept    mpls-in-ip          0         0  meta l4proto mpls-in-ip  accept\n4234     accept    tcp                 0         0  meta l4proto tcp  accept\ndefault  accept    all                 0         0\n\n\n---------------------------------\nipv6 Firewall "prerouting raw"\n\nRule     Action    Protocol      Packets    Bytes\n-------  --------  ----------  ---------  -------\ndefault  accept    all               235    13256\n\n'

    parsed_fw = parse_firewall_operation(test_firewall_str)

    print(pprint.pformat(result, indent=2, width=80))
    #print(pprint.pformat(parsed_fw, indent=2, width=80))

    # print(pprint.pformat(if_res, indent=2, width=80))
    