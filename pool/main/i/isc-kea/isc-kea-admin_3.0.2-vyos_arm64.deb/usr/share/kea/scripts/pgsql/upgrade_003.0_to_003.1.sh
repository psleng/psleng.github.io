#!/bin/sh

# Copyright (C) 2017-2025 Internet Systems Consortium, Inc. ("ISC")
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

# Exit with error if commands exit with non-zero and if undefined variables are
# used.
set -eu

# shellcheck disable=SC2034
# SC2034: ... appears unused. Verify use (or export if used externally).
prefix="/usr"

# Include utilities based on location of this script. Check for sources first,
# so that the unexpected situations with weird paths fall on the default
# case of installed.
script_path=$(cd "$(dirname "${0}")" && pwd)
if test "${script_path}" = "XXX-tests-builddir-XXX/src/share/database/scripts/pgsql"; then
    # shellcheck source=./src/bin/admin/admin-utils.sh.in
    . "XXX-tests-builddir-XXX/src/bin/admin/admin-utils.sh"
else
    # shellcheck source=./src/bin/admin/admin-utils.sh.in
    . "${prefix}/share/kea/scripts/admin-utils.sh"
fi

VERSION=$(pgsql_version "$@")

if [ "$VERSION" != "3.0" ]; then
    printf 'This script upgrades 3.0 to 3.1. '
    printf 'Reported version is %s. Skipping upgrade.\n' "${VERSION}"
    exit 0
fi

psql "$@" >/dev/null <<EOF
START TRANSACTION;

-- This line starts the schema upgrade to version 3.1.

-- The 'client-id' host identifier type was missing in the
-- 2.0 -> 3.0 upgrade script. However, it was present in the
-- dhcpdb_create.pgsql file. This means that this entry may
-- or may not be present. By the conditional insert below we
-- will only insert it if it doesn't exist.
INSERT INTO host_identifier_type (type, name)
  SELECT 3, 'client-id'
    WHERE NOT EXISTS (
        SELECT type FROM host_identifier_type WHERE type = 3
    );

-- We also add a new identifier type: flex-id.
INSERT INTO host_identifier_type VALUES (4, 'flex-id');

-- Update the schema version number.
UPDATE schema_version
    SET version = '3', minor = '1';

-- This line concludes the schema upgrade to version 3.1.

-- Commit the script transaction.
COMMIT;

EOF
