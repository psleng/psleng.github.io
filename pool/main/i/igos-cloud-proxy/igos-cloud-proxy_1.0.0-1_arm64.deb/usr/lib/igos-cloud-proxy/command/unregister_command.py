from .command import Command


class UnregCommand(Command):

    def __init__(self, reason=False):
        super().__init__()
        self.unreg_command_reason = reason
