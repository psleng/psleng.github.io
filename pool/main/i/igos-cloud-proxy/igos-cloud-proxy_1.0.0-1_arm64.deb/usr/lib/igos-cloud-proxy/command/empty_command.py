from .command import Command


class EmptyCommand(Command):

    def __init__(self, holdConnection=False):
        super().__init__()
        self.empty_command_hold_connection = holdConnection


class EmptyCommandNew(Command):
    PARAMS = [
        "nextPollDelay",
        "keepAlive",
        "minRetryInterval",
        "maxRetryInterval",
        "pollTimeout",
    ]

    def __init__(
        self,
        nextPollDelay=None,
        keepAlive=None,
        minRetryInterval=None,
        maxRetryInterval=None,
        pollTimeout=None,
    ):
        super().__init__()
        self.empty_command_nextPollDelay = nextPollDelay
        self.empty_command_keepAlive = keepAlive
        self.empty_command_minRetryInterval = minRetryInterval
        self.empty_command_maxRetryInterval = maxRetryInterval
        self.empty_command_pollTimeout = pollTimeout
