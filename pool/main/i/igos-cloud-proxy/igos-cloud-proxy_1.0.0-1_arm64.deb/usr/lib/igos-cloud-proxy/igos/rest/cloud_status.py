import json

from igos.vyos_api import VyosAPI, VyosRestCommands
from igos.rest.common import get_cloud_iface, parse_interfaces
from utils import proxy_config
from message import Message


def get_cloud_services_status(message: Message, provider: VyosAPI) -> str:
    ifaces_output = provider.call_action(VyosRestCommands.SHOW_INTERFACES).get(
        "data", ""
    )
    interfaces = parse_interfaces(ifaces_output)
    cloud_iface, local_ip = get_cloud_iface(interfaces)
    iface_name = cloud_iface["name"] if cloud_iface else ""

    # Determine WAN/LAN role from default route
    iface_role = "LAN"
    route_output = provider.call_action(VyosRestCommands.SHOW_IP_ROUTE_DEFAULT).get(
        "data", ""
    )
    if iface_name and f"dev {iface_name}" in route_output:
        iface_role = "WAN"

    return json.dumps(
        {
            "cloudServicesStatus": {
                "cloudDeviceID": proxy_config.serial_number,
                "cloudConnectionStatus": "connected",
                "cloudConnectionIFName": iface_name,
                "cloudConnectionIpAddress": local_ip,
                "cloudConnectionIFRole": iface_role,
            }
        }
    )
