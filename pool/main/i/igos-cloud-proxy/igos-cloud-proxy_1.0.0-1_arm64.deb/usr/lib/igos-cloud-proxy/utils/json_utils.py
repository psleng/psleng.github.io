import json

from .logger import Logger


class JSONUtils:
    @staticmethod
    def to_json(obj):
        return json.dumps(obj, indent=4, default=JSONUtils.json_default)

    @staticmethod
    def json_default(obj):
        if isinstance(obj, bytes):
            return obj.decode("utf-8")  # Convert bytes to a readable string
        return obj.__dict__

    @staticmethod
    def from_json(json_str, target_class):
        returnObj = json.loads(json_str, object_hook=lambda d: target_class(**d))
        return returnObj

    @staticmethod
    def from_json_by_PARAMS(json_str, target_class):
        """
        Deserialize a JSON string into an instance of target_class.
        Only parameters explicitly listed in target_class.PARAMS are used.
        Logs the module, function name, and parameter values.
        """
        log = Logger()
        param_names = getattr(target_class, "PARAMS", [])

        def object_hook(d):
            params = {k: d.get(k, None) for k in param_names}
            # Log module and function name, and parameter values
            module_name = __name__
            func_name = "from_json_by_PARAMS"
            param_str = ", ".join(f"{k}={repr(v)}" for k, v in params.items())
            log.debug(
                f"[{module_name}.{func_name}] Creating {target_class.__name__} with parameters: {param_str}"
            )
            return target_class(**params)

        try:
            return json.loads(json_str, object_hook=object_hook)
        except json.JSONDecodeError:
            log.debug(f"[{__name__}.from_json_by_PARAMS] Invalid JSON string.")
            return None

    @staticmethod
    def from_json_check_PARAMS(json_str, target_class):
        """
        Deserialize a JSON string into an instance of target_class.
        Only parameters explicitly listed in target_class.PARAMS are used.
        Logs the module, function name, and parameter values.
        Raises AttributeError if PARAMS is not defined in target_class.
        """
        log = Logger()

        # Check for PARAMS attribute and raise error if missing
        if not hasattr(target_class, "PARAMS"):
            raise AttributeError(
                f"Class '{target_class.__name__}' must define a class-level PARAMS attribute (list of parameter names)."
            )
        param_names = getattr(target_class, "PARAMS")

        def object_hook(d):
            params = {k: d.get(k, None) for k in param_names}
            # Log module and function name, and parameter values
            module_name = __name__
            func_name = "from_json_check_PARAMS"
            param_str = ", ".join(f"{k}={repr(v)}" for k, v in params.items())
            log.debug(
                f"[{module_name}.{func_name}] Creating {target_class.__name__} with parameters: {param_str}"
            )
            return target_class(**params)

        try:
            return json.loads(json_str, object_hook=object_hook)
        except json.JSONDecodeError:
            log.debug(f"[{__name__}.from_json_check_PARAMS] Invalid JSON string.")
            return None
