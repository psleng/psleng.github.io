from .command import Command


class ExecuteRestCommand(Command):

    def __init__(self, restCommandUri=None, requestMethod="GET", commandBody=""):
        super().__init__()
        self._rest_command_method = requestMethod
        self._rest_command_uri = restCommandUri
        self._rest_command_body = commandBody

    @property
    def rest_command_uri(self):
        return self._rest_command_uri

    @property
    def rest_command_method(self):
        return self._rest_command_method

    @property
    def rest_command_body(self):
        return self._rest_command_body
