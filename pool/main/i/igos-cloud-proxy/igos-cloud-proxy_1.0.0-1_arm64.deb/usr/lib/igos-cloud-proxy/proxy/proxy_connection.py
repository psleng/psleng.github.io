import collections
import threading
import time
from threading import Event

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from utils import Logger
from utils.constants import PerleConstants

MAX_CONNECTIONS = 200  # Maximum allowed proxy connections
active_connections = collections.deque()  # FIFO queue to track active connections


def create_http_client(max_connections):
    retry_strategy = Retry(
        total=5,
        backoff_factor=0.1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE"],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)

    http_client = requests.Session()
    http_client.verify = PerleConstants.HTTPS_VERIFY_CERTIFICATE
    http_client.mount("http://", adapter)
    http_client.mount("https://", adapter)

    http_client.max_connections = max_connections  # Set the maximum connections

    return http_client


class ProxyConnection:
    def __init__(
        self,
        router_app,
        proxy_cookie,
        connections,
        proxy_uri,
        proxy_id,
        router_id,
        router_uri,
        use_hard_coded_target_host,
        inactivity_timeout,
        session_timeout,
    ):
        # inactivity_timeout and session_timeout are specified in seconds
        self.thread_pool = []
        self.router_client = requests.Session()
        self.router_client.verify = PerleConstants.PROXY_VERIFY_CERTIFICATE
        self.router_client.max_connections = connections
        self.router_app = router_app
        self.proxy_id = proxy_id
        self.proxy_cookie = proxy_cookie
        self.session_id = ""
        self.stop_event = Event()
        self.inactivity_timeout = inactivity_timeout
        self.session_timeout = session_timeout
        self._inactivity_timer = None
        self._session_timer = None
        self._timer_lock = threading.Lock()
        self.start_time = time.time()

        log = Logger()
        # If connections exceed the limit, shutdown oldest (FIFO)
        while len(active_connections) >= MAX_CONNECTIONS:
            oldest_connection = active_connections.popleft()
            log.debug(
                f"Max connections reached ({MAX_CONNECTIONS}). Shutting down oldest connection: {oldest_connection.proxy_id}"
            )
            oldest_connection.shutdown()
        active_connections.append(self)  # Add new connection to queue

        # launch threads
        from proxy.thread import ProxyThread

        for _ in range(connections):
            proxy_thread = ProxyThread(
                self,
                proxy_cookie,
                self.router_client,
                proxy_uri,
                proxy_id,
                router_id,
                router_uri,
                use_hard_coded_target_host,
                self.stop_event,
                inactivity_timeout,
            )
            self.thread_pool.append(proxy_thread)
            proxy_thread.start()

        # initialize timers based on provided values (seconds)
        self._initialize_timers(log)

    def _initialize_timers(self, log: Logger):
        """Create or reset inactivity and session timers according to current settings."""
        with self._timer_lock:
            # determine inactivity period (seconds)
            inactivity_secs = self.inactivity_timeout or 0

            # set / reset inactivity timer
            if hasattr(self, "_inactivity_timer") and self._inactivity_timer:
                self._inactivity_timer.cancel()
            if inactivity_secs > 0:
                self._inactivity_timer = threading.Timer(inactivity_secs, self.shutdown)
                self._inactivity_timer.start()

            # session timer
            if hasattr(self, "_session_timer") and self._session_timer:
                self._session_timer.cancel()
            if self.session_timeout and self.session_timeout > 0:
                session_secs = self.session_timeout
                self._session_timer = threading.Timer(session_secs, self.shutdown)
                self._session_timer.start()

    def reset_inactivity_timer(self):
        """Reset only the inactivity timer (called on user activity)."""
        log = Logger()
        log.debug(f"Resetting inactivity timer for proxy {self.proxy_id}")
        with self._timer_lock:
            if self._inactivity_timer:
                self._inactivity_timer.cancel()
            inactivity_secs = self.inactivity_timeout or 0
            if inactivity_secs > 0:
                self._inactivity_timer = threading.Timer(inactivity_secs, self.shutdown)
                self._inactivity_timer.start()

    def reset_session_timer(self):
        """Reset only the session timer (called when user explicitly extends session)."""
        log = Logger()
        log.debug(f"Resetting session timer for proxy {self.proxy_id}")
        with self._timer_lock:
            if self._session_timer:
                self._session_timer.cancel()
            if self.session_timeout and self.session_timeout > 0:
                session_secs = self.session_timeout
                self._session_timer = threading.Timer(session_secs, self.shutdown)
                self._session_timer.start()

    def reset_both_timers(self):
        """Convenience helper to reset both inactivity and session timers."""
        self.reset_inactivity_timer()
        self.reset_session_timer()

    def update_timeouts(self, inactivity_timeout, session_timeout):
        """Update timeouts values and reinitialize timers accordingly."""
        log = Logger()
        log.debug(
            f"Updating timeouts for proxy {self.proxy_id}: inactivity={inactivity_timeout}, session={session_timeout} (seconds)"
        )
        with self._timer_lock:
            if inactivity_timeout is not None:
                self.inactivity_timeout = inactivity_timeout
            if session_timeout is not None:
                self.session_timeout = session_timeout
        # restart timers with new values
        self._initialize_timers(log)

    def wait_for_threads_to_end(self):
        log = Logger()
        try:
            self.stop_event.set()
            for thread in self.thread_pool:
                thread.stop_event.set()
                if isinstance(thread.proxy_http_client, requests.Session):
                    thread.proxy_http_client.close()
                    thread.proxy_http_client = None
            log.debug("Threads stopped")
        except Exception as e:
            log.error(f"Waiting for threads to end is interrupted: {e}")

    def shutdown(self):
        global active_connections

        # cancel any running timers
        with self._timer_lock:
            if hasattr(self, "_inactivity_timer") and self._inactivity_timer:
                self._inactivity_timer.cancel()
                self._inactivity_timer = None
            if hasattr(self, "_session_timer") and self._session_timer:
                self._session_timer.cancel()
                self._session_timer = None

        if self in active_connections:
            active_connections.remove(self)  # Remove from queue before shutting down

        # inform parent application so it can drop reference
        try:
            if self.router_app:
                self.router_app.channel_closed(self)
        except Exception as e:
            log = Logger()
            log.debug(f"Exception notifying router_app of closed connection: {e}")

        self.wait_for_threads_to_end()

        # Close the router client
        if isinstance(self.router_client, requests.Session):
            self.router_client.close()
        self.router_client = None

    def proxy_thread_ending(self):
        # log = Logger()
        # log.debug(f"Proxy thread stopped: {proxy_thread}")
        any_alive = False
        for thread in self.thread_pool:
            if thread.isAlive():
                any_alive = True
            # log.debug(f"Proxy thread ending: {thread.ending()}; {proxy_thread}")
        if not any_alive:
            self.router_app = None
