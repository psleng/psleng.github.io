#!/usr/bin/python3
# -*- encoding: utf-8 -*-

from .constants import PerleConstants
import syslog

# Can be used to print current line when debugging,
# similar to '__LINE__' in c language
# Maybe set another param for logger class to add line number in message?
# e.g.: log = Logger()\n log.info(f'Line: {LINE()} test')

# def LINE():
#     return str(sys._getframe(1).f_lineno)


class Logger(object):
    """
    Perle Python logging class which uses "print()" when run from anywhere but the
    router platform, and acts as a wrapper around the "syslog" module when run on a router
    platform device.
    """

    def __init__(self):
        self.priority = syslog.LOG_DEBUG
        self.proc = "cloud-services"
        self.pid = syslog.LOG_PID
        self.facility = (
            syslog.LOG_LOCAL7
        )  # Should match DEFAULT_LOGGING_FACILITY defined in flash.h
        # self.debugOn = None

    def set_facility(self, facility):
        """
        --- facility ---
        kern, user, mail, daemon, auth, security, syslog, lpr,news
        uudp, cron, authpriv, ftp, local0, local1, local2, local3
        local4, local5, local6, local7
        ----------------

        """
        if facility == "kern":
            self.facility = syslog.LOG_KERN
        elif facility == "user":
            self.facility = syslog.LOG_USER
        elif facility == "mail":
            self.facility = syslog.LOG_MAIL
        elif facility == "daemon":
            self.facility = syslog.LOG_DAEMON
        elif facility == "auth":
            self.facility = syslog.LOG_AUTH
        elif facility == "security":
            self.facility = syslog.LOG_AUTH
        elif facility == "syslog":
            self.facility = syslog.LOG_SYSLOG
        elif facility == "lpr":
            self.facility = syslog.LOG_LPR
        elif facility == "news":
            self.facility = syslog.LOG_NEWS
        elif facility == "uudp":
            self.facility = syslog.LOG_UUCP
        elif facility == "cron":
            self.facility = syslog.LOG_CRON
        elif facility == "authpriv":
            self.facility = 80
        elif facility == "ftp":
            self.facility = 88
        elif facility == "local0":
            self.facility = syslog.LOG_LOCAL0
        elif facility == "local1":
            self.facility = syslog.LOG_LOCAL1
        elif facility == "local2":
            self.facility = syslog.LOG_LOCAL2
        elif facility == "local3":
            self.facility = syslog.LOG_LOCAL3
        elif facility == "local4":
            self.facility = syslog.LOG_LOCAL4
        elif facility == "local5":
            self.facility = syslog.LOG_LOCAL5
        elif facility == "local6":
            self.facility = syslog.LOG_LOCAL6
        elif facility == "local7":
            self.facility = syslog.LOG_LOCAL7

        return self.facility

    def set_priority(self, priority):
        """
        --- priority ---
        emerg, alert,crit, error, warning, notice, info, debug
        ----------------

        """
        if priority == "emerg":
            self.priority = syslog.LOG_EMERG
        elif priority == "alert":
            self.priority = syslog.LOG_ALERT
        elif priority == "crit":
            self.priority = syslog.LOG_CRIT
        elif priority == "error":
            self.priority = syslog.LOG_ERR
        elif priority == "warning":
            self.priority = syslog.LOG_WARNING
        elif priority == "notice":
            self.priority = syslog.LOG_NOTICE
        elif priority == "info":
            self.priority = syslog.LOG_INFO
        elif priority == "debug":
            self.priority = syslog.LOG_DEBUG

        return self.priority

    def _logging(self, message):
        """
        output to syslog or print

        """
        syslog.openlog(self.proc, self.pid, self.facility)
        if isinstance(message, str):
            syslog.syslog(self.priority, message.replace("\n", " "))
        else:
            syslog.syslog(self.priority, str(message).replace("\n", " "))
        syslog.closelog()

    def debug(self, message):
        self.set_priority("debug")
        self._logging(message)

    def info(self, message):
        self.set_priority("info")
        self._logging(message)

    def notice(self, message):
        self.set_priority("notice")
        self._logging(message)

    def warning(self, message):
        self.set_priority("warning")
        self._logging(message)

    def error(self, message):
        self.set_priority("error")
        self._logging(message)

    def crit(self, message):
        self.set_priority("crit")
        self._logging(message)

    def alert(self, message):
        self.set_priority("alert")
        self._logging(message)

    def emerg(self, message):
        self.set_priority("emerg")
        self._logging(message)

    def disable_debugging(self):
        if not PerleConstants.ISROUTER:
            return

        self.debug(f"Turning debug logging OFF")
        syslog.setlogmask(syslog.setlogmask(0) & (~(syslog.LOG_MASK(syslog.LOG_DEBUG))))

    def enable_debugging(self):
        self.debug(f"Turning debug logging ON")
        syslog.setlogmask(syslog.setlogmask(0) | (syslog.LOG_MASK(syslog.LOG_DEBUG)))


# ---------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------


def main():
    """
    TEST
    """

    log = Logger()
    log.info("Testing debug log messages")

    log.info("\nCalling log.disable_debugging()")
    log.disable_debugging()
    log.info("Testing info log messages")
    log.notice("Testing notice log messages")
    log.warning("Testing warning log messages")
    log.error("Testing error log messages")
    log.crit("Testing crit log messages")
    log.alert("Testing alert log messages")
    log.emerg("Testing emerg log messages")

    log.info("Calling log.enable_debugging()")
    log.enable_debugging()
    log.debug("Testing debug log messages")
    log.info("Testing info log messages")
    log.notice("Testing notice log messages")
    log.warning("Testing warning log messages")
    log.error("Testing error log messages")
    log.crit("Testing crit log messages")
    log.alert("Testing alert log messages")
    log.emerg("Testing emerg log messages")


if __name__ == "__main__":
    main()
