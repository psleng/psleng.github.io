# File: perle_cloud_uris.py


class PerleCloudUris:
    # CLOUD_PRIVATE_BASE_URI = "http://localhost:8080"
    # CLOUD_PUBLIC_BASE_URI = "http://localhost:8080"

    # routers connect here to get their commands
    routersFrontEndCommandPath = "routers/command"
    routersFrontEndRegisterPath = "routers/register"
    # routersFrontEndURI = CLOUD_PUBLIC_BASE_URI + routersFrontEndPath

    # front end nodes connect here to get commands for routers
    commandServicePath = "commandService/command"
    # commandServiceURI = CLOUD_PRIVATE_BASE_URI + commandServicePath

    # PROXY stuff: where router provides responses for proxyfied user messages he gets via the proxy cloud
    proxyToRouterPath = "proxyRouterService"
    # proxyToRouterURI = CLOUD_PUBLIC_BASE_URI + proxyToRouterPath

    # REST - where cloud receive commands from user
    CREATE_PROXY = "userCommand/createProxy"
    EXECUTE_REST_COMMAND = "userCommand/restCommand"
    REGISTER_ROUTER_COMMAND = "userCommand/registerRouter"
