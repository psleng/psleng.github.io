import json

from message import Message
from igos.vyos_api import VyosAPI, VyosRestCommands


def get_cli(message: Message, provider: VyosAPI):
    diagnostic_info = {
        "config": provider.call_action(VyosRestCommands.SHOW_CONFIG).get("data", ""),
        "version": provider.call_action(VyosRestCommands.SHOW_VERSION).get("data", ""),
        "memory": provider.call_action(VyosRestCommands.SHOW_MEMORY).get("data", ""),
        "storage": provider.call_action(VyosRestCommands.SHOW_STORAGE).get("data", ""),
        "log": provider.call_action(VyosRestCommands.SHOW_LOG).get("data", ""),
    }

    diagnostic_info_string = "\n".join(
        f"===== {k.upper()} =====\n{v}" for k, v in diagnostic_info.items()
    )

    return json.dumps(
        {
            "cliCommands": [
                {
                    "command": "show tech-support",
                    "commandType": "show",
                    "responseStatus": {"code": 6, "message": "Successful"},
                    "commandOutput": diagnostic_info_string,
                }
            ]
        }
    )
