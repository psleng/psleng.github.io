import time
from collections.abc import Callable

from utils import Logger
from message import Message

from .vyos_api import VyosAPI
from .rest.system import get_system_info
from .rest.cloud_status import get_cloud_services_status
from .rest.easy_port import get_easyport_interface
from .rest.cli import get_cli

IGOS_API_ROUTES: dict[str, Callable[[Message, VyosAPI], str]] = {
    "/api/v1.1/managed-devices/system": get_system_info,
    "/api/v1.1/managed-devices/services/cloud-services/status": get_cloud_services_status,
    "/api/v1.1/managed-devices/easyport/interfaces/all": get_easyport_interface,
    "/api/v1.1/managed-devices/cli": get_cli,
}


class IGOSRestService:
    def __init__(self, vyos_api_key: str):
        self._api = VyosAPI(vyos_api_key)
        self._log = Logger()

    def process_rest_command(self, rest_message: Message) -> str:
        from utils import JSONUtils
        from command import ExecuteRestCommand

        rest_command: ExecuteRestCommand = JSONUtils.from_json(
            rest_message.messageParams, ExecuteRestCommand
        )

        uri: str = rest_command.rest_command_uri or ""
        self._log.debug(f"IGOSRestService.process_rest_command: uri={uri}")
        self._log.debug(rest_command.rest_command_body)
        start = time.time()

        try:
            result: str = IGOS_API_ROUTES[uri](rest_message, self._api)
            elapsed_ms = (time.time() - start) * 1000
            self._log.debug(
                f"IGOSRestService.process_rest_command: uri={uri}, "
                f"total_elapsed={elapsed_ms:.1f}ms, response_len={len(result)}"
            )
            return result
        except Exception as ex:
            elapsed_ms = (time.time() - start) * 1000
            self._log.debug(
                f"IGOSRestService.process_rest_command FAILED: uri={uri}, "
                f"{type(ex).__name__}: {ex}, total_elapsed={elapsed_ms:.1f}ms"
            )
            raise
