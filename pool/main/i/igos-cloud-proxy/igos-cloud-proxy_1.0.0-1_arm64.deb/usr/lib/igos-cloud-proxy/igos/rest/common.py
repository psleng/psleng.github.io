import re
import socket
from urllib.parse import urlparse

from utils import proxy_config


def parse_interfaces(ifaces_output: str) -> list[dict]:
    """Parse VyOS 'show interfaces' tabular output into a list of {name, mac, ips}."""
    interfaces = []
    current: dict | None = None
    for line in ifaces_output.splitlines():
        # Skip header/separator lines
        if (
            not line.strip()
            or line.startswith("Codes:")
            or line.startswith("Interface")
            or line.startswith("---")
        ):
            continue
        parts = line.split()
        # Continuation line (extra IP for previous interface) — starts with whitespace
        if line[0] == " ":
            if current is not None:
                ip_match = re.match(r"(\d+\.\d+\.\d+\.\d+)/", parts[0])
                if ip_match:
                    current["ips"].append(ip_match.group(1))
            continue
        # New interface row: Interface  IP  MAC  VRF  MTU  S/L  [Description]
        name = parts[0]
        ip_str = parts[1] if len(parts) > 1 else "-"
        mac_str = parts[2] if len(parts) > 2 else ""
        current = {
            "name": name,
            "mac": mac_str if re.match(r"[0-9a-fA-F:]{17}$", mac_str) else "",
            "ips": [],
        }
        ip_match = re.match(r"(\d+\.\d+\.\d+\.\d+)/", ip_str)
        if ip_match:
            current["ips"].append(ip_match.group(1))
        interfaces.append(current)
    return interfaces


def get_cloud_iface(interfaces: list[dict]) -> tuple[dict | None, str]:
    """Return (interface dict, local_ip) for the interface used to reach the cloud."""
    cloud_host = urlparse(proxy_config.perleCloudURL).hostname
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((cloud_host, 443))
        local_ip = s.getsockname()[0]
    finally:
        s.close()
    for iface in interfaces:
        if local_ip in iface["ips"]:
            return iface, local_ip
    return None, local_ip
