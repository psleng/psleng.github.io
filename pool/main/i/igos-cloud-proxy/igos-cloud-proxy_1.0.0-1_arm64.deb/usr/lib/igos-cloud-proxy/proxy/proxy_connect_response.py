class ProxyConnectResponse:
    def __init__(self, router_uri):
        self.routerURI = router_uri
