import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .constants import PerleConstants
from .logger import Logger


class ConnectionUtils:
    @staticmethod
    def get_http_session(router_config, max_connections):
        session = requests.Session()

        retry_strategy = Retry(
            total=5,
            backoff_factor=0.1,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"],
        )

        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=max_connections,
            pool_maxsize=max_connections,
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        if not router_config.do_handle_compression:
            session.headers.update({"Accept-Encoding": "identity"})

        return session

    @staticmethod
    def increaseRetryTime(retry_count):
        """
        Retry times:
        5, 8, 11, 17, 29, 53, 101, ...
        - First retry adds a fixed increment
        - From retry_count >= 2, increment grows exponentially: increment * 2^(retry_count - 1)
        - Value is capped at max_retry_time
        - Default max_retry_time is 120
        """
        if retry_count < 2:
            return min(
                PerleConstants.CONNECT_FAIL_RETRY_TIME
                + (PerleConstants.CONNECT_FAIL_RETRY_TIME_INCREMENT * retry_count),
                PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX,
            )
        else:
            return min(
                PerleConstants.CONNECT_FAIL_RETRY_TIME
                + PerleConstants.CONNECT_FAIL_RETRY_TIME_INCREMENT
                * (2 ** (retry_count - 1)),
                PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX,
            )

    @staticmethod
    def updateFailRetryTime(min, max):
        if min > max:
            return

        # Store the cloud-set connect retry time on failure in PerleConstant
        if min > 0 and min != PerleConstants.CONNECT_FAIL_RETRY_TIME:
            PerleConstants.CONNECT_FAIL_RETRY_TIME = min

        if max != PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX:
            PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX = max

    @staticmethod
    def updatNextCommandTimeout(poll):
        if poll is None:
            return
        if poll != PerleConstants.NEXT_COMMAND_TIMEOUT:
            PerleConstants.NEXT_COMMAND_TIMEOUT = poll

    @staticmethod
    def safe_sleep(sleep_time):
        """Sleep that catches exceptions (e.g. signal interrupts) gracefully."""
        if not sleep_time:
            return
        log = Logger()
        try:
            time.sleep(sleep_time)
        except Exception as ex:
            log.debug(f"Got Exception during safe_sleep(): Exception = \n{ex}")

    @staticmethod
    def get_system_uptime():
        """Returns system uptime in seconds from /proc/uptime."""
        with open("/proc/uptime", "r") as f:
            return int(float(f.readline().split()[0]))

    @staticmethod
    def init_backoff_retry_time():
        """Reset the backoff retry time to the default in the proxy config."""
        from .proxy_config import ProxyConfig

        proxy_config = ProxyConfig()
        proxy_config.data.ConnectFailRetryTime = str(
            PerleConstants.CONNECT_FAIL_RETRY_TIME
        )
