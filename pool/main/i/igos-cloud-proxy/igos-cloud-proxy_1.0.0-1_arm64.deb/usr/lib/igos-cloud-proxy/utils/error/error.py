class Error:
    def __init__(self, errorCode, errorMessage):
        self.error_code = errorCode
        self.error_message = errorMessage
