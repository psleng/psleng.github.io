import os
from enum import Enum


class PerleConstants:

    # Indicates that this is an actual router
    ISROUTER = True

    # Indicates that this a simulation running on PC
    # To simulate this, create an folder product/flash along your python code, create an empty file pcSimulateRouter in this folder
    IS_pcSimulateRouter = os.access("/router/product/flash/pcSimulateRouter", os.F_OK)

    # configuration database (only if _ISROUTER true)
    CONFIGDB = "/tmp/db/config.db"

    # Note /product folder is wiped out, hence following files will get removed if user does factory default on device
    CLOUD_AUTH_TOKEN_FILE = "/etc/igos-cloud-proxy/.igos-cloud-auth.token"
    CLOUD_SETTINGS_FILE = "/etc/igos-cloud-proxy/.igos-cloud-settings.conf"

    # Default values, in seconds, should line up with values in flash.h
    CONNECT_FAIL_RETRY_TIME: int = 5
    CONNECT_FAIL_RETRY_TIME_MAX: int = 120  # default to 120 seconds
    CONNECT_FAIL_RETRY_TIME_INCREMENT = 3
    NEXT_POLL_DELAY = 0
    CHECK_CLOUD_URL_CONNECT_TIMEOUT = 1
    CHECK_CLOUD_URL_READ_TIMEOUT = 1

    DISCONNECT_READ_TIMEOUT = 1

    NEXT_COMMAND_TIMEOUT: int = 30

    MAX_CONNECT_INTERVAL_KEEP_CONNECTED = (
        60 * 5
    )  # if interval time is less than 5 minutes, then we will keep connection up

    UNEXPECTED_CONDITION_DELAY = 5

    # Some Device Registry defines
    REGISTER_RETRY_TIME = 2  # seconds
    REGISTRY_RETRY_COUNT = 3

    DEFAULT_HTTP_CONNECT_TIME = 3
    DEFAULT_HTTP_READ_TIME = 5

    DEFAULT_ROUTER_URI_PROTOCOL = "https"
    DEFAULT_ROUTER_URI_IP = "127.0.0.1"
    DEFAULT_ROUTER_URI = f"{DEFAULT_ROUTER_URI_PROTOCOL}://{DEFAULT_ROUTER_URI_IP}"

    DEFAULT_ROUTER_URI_PORT_PROXY = "443"

    DEFAULT_ROUTER_URI_PROXY = f"{DEFAULT_ROUTER_URI_PROTOCOL}://{DEFAULT_ROUTER_URI_IP}:{DEFAULT_ROUTER_URI_PORT_PROXY}"

    DEFAULT_ROUTER_URI_PORT_REST = "443"
    DEFAULT_ROUTER_URI_REST = f"{DEFAULT_ROUTER_URI_PROTOCOL}://{DEFAULT_ROUTER_URI_IP}:{DEFAULT_ROUTER_URI_PORT_REST}"

    HTTPS_VERIFY_CERTIFICATE = True
    PROXY_VERIFY_CERTIFICATE = False

    DEFAULT_PROXY_IDLE_TIMEOUT = 300

    # Keep this value in sync with CFGDB_ENUM_TYPE_PERLE_FACILITY_TYPE in debug_facility.h
    PERLE_FAC_CLOUD_SERVICES = 51

    # Keep this value in sync with CONFIG_RPC_REQUEST_ID_FIRST_CLOUD_CONNECT defined in configRpcRequestId_e enum in config_rpc.h
    CONFIG_RPC_REQUEST_ID_FIRST_CLOUD_CONNECT = 291

    # HTTP message header to be sent back to cloud
    HTTP_KEEP_ALIVE_HEADER = "Connection"
    HTTP_KEEP_ALIVE_HEADER_VAL_TRUE = "keep-alive"
    HTTP_KEEP_ALIVE_HEADER_VAL_FALSE = "close"


class CloudConnStatus(
    Enum
):  # Should keep in sync with CFGDB_ENUM_TYPE_CLOUD_CONNECTION_STATUS in C code
    CLOUD_STATUS_DEVICE_UNREGISTERED = 0
    CLOUD_STATUS_CONNECTING = 1
    CLOUD_STATUS_CONNECTED = 2
    CLOUD_STATUS_CLOUD_IDLE = 3
    CLOUD_STATUS_CONNECTION_FAILED = 4


class CloudRegisterFailCodes(
    Enum
):  # Should keep in sync with CFGDB_ENUM_TYPE_CLOUD_CONN_FAIL_CODE in C code
    CLOUD_CONN_FAIL_OK = (
        0  # keyword = "SUCCESSFUL", string = "Cloud connection successful"
    )
    CLOUD_CONN_FAIL_INVALID = -1  # keyword = "INVALID", string = "Internal error"
    CLOUD_CONN_FAIL_UNREACHABLE = (
        -2
    )  # keyword = "UNREACHABLE", string = "Destination unreachable"
    CLOUD_CONN_FAIL_UNRESOLVE = (
        -3
    )  # keyword = "UNRESOLVE", string = "Could not resolve cloud URL name"
    CLOUD_CONN_FAIL_REGISTRATION = (
        -4
    )  # keyword = "REGISTRATION-FAIL", string = "Registration failed. Registration PIN incorrect or PIN has expired"
    CLOUD_CONN_FAIL_UNKNOWN = -99  # keyword = "UNKNOWN", string = "Unknown failure"
