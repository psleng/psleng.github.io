import base64
import json
import time
import requests
from pathlib import Path


from utils.constants import PerleConstants, PerleCloudUris
from utils import proxy_config


class RegistrationError(Exception):
    """Raised when device registration fails."""

    pass


class AuthConstant:
    AUTHORIZATION_HEADER = "Authorization"
    BEARER = "Bearer "
    ROUTER_AUTHORIZATION_ID = "ROUTER_AUTHORIZATION_"
    ROUTER_ACTIVATION_ID = "ROUTER_ACTIVATION_"


class RouterActivation:
    def __init__(self, deviceId, activationCode):
        self.deviceId = deviceId
        self.activationCode = activationCode

    def to_dict(self):
        return {"deviceId": self.deviceId, "activationCode": self.activationCode}


class RouterAuthorization:
    def __init__(self, deviceId, authToken):
        self.deviceId = deviceId
        self.authToken = authToken

    def to_dict(self):
        return {"deviceId": self.deviceId, "authToken": self.authToken}


class DeviceAuthorizationService:
    def __init__(self, router_id: str, registration_code: str) -> None:
        self._is_registered: bool = False
        self._auth_token: str = ""

        self._router_id: str = router_id
        self._registration_code: str = registration_code

        self._authorization_header: str = AuthConstant.AUTHORIZATION_HEADER
        self._authorization_hvalue: str = ""

    def _save_auth_token(self, auth_token: str) -> None:
        import os

        os.makedirs(
            os.path.dirname(PerleConstants.CLOUD_AUTH_TOKEN_FILE), exist_ok=True
        )
        with open(PerleConstants.CLOUD_AUTH_TOKEN_FILE, "w") as auth_file:
            json.dump(
                {
                    self._router_id: auth_token,
                    "registration_code": self._registration_code,
                },
                auth_file,
            )

    def _remove_auth_token(self) -> None:
        auth_file = Path(PerleConstants.CLOUD_AUTH_TOKEN_FILE)
        if auth_file.exists():
            auth_file.unlink()

    def deregister_device(self) -> None:
        """Remove stored credentials and mark the device as unregistered."""
        self._remove_auth_token()
        self._auth_token = ""
        self._authorization_hvalue = ""
        self._is_registered = False

    def _use_activation_headers(self) -> None:
        router_activation = RouterActivation(self._router_id, self._registration_code)
        router_activation_b64 = base64.b64encode(
            json.dumps(router_activation.to_dict()).encode()
        ).decode()

        self._authorization_hvalue = (
            AuthConstant.BEARER
            + AuthConstant.ROUTER_ACTIVATION_ID
            + router_activation_b64
        )

    def _use_authorization_headers(self, auth_token: str) -> None:
        router_authorization = RouterAuthorization(self._router_id, auth_token)
        router_authorization_b64 = base64.b64encode(
            json.dumps(router_authorization.to_dict()).encode()
        ).decode()

        self._authorization_hvalue = (
            AuthConstant.BEARER
            + AuthConstant.ROUTER_AUTHORIZATION_ID
            + router_authorization_b64
        )

    def _validate_auth_token(self, auth_token: str) -> bool:
        """Check if a saved auth token is still valid with the cloud."""
        from utils import Logger

        log = Logger()
        self._use_authorization_headers(auth_token)

        validate_request = json.dumps(
            {
                "routerId": self._router_id,
                "messageId": 0,
                "messageType": "GET_NEXT_COMMAND",
                "messageParams": json.dumps({"timeout": 1}),
                "authToken": auth_token,
                "requiresResponse": True,
            }
        )
        headers = {
            "Content-Type": "application/json",
            self._authorization_header: self._authorization_hvalue,
            PerleConstants.HTTP_KEEP_ALIVE_HEADER: PerleConstants.HTTP_KEEP_ALIVE_HEADER_VAL_FALSE,
        }

        try:
            resp = requests.post(
                url=proxy_config.perleCloudURL
                + PerleCloudUris.routersFrontEndCommandPath,
                headers=headers,
                data=validate_request,
                verify=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
                timeout=(
                    PerleConstants.DEFAULT_HTTP_CONNECT_TIME,
                    PerleConstants.DEFAULT_HTTP_READ_TIME,
                ),
            )
            data = resp.json()
            if data.get("messageType") == "ERROR":
                params = data.get("messageParams")
                if params:
                    error = json.loads(params) if isinstance(params, str) else params
                    if error.get("errorCode") == "AUTH_FAILED":
                        log.warning("Saved auth token is invalid, will re-register")
                        return False
            log.debug("Saved auth token validated successfully")
            return True
        except Exception as ex:
            log.debug(f"Auth token validation failed with exception: {ex}")
            return False

    def register_device(self) -> None:
        """Register the device with PerleCloud.

        Tries saved auth token first (validates it), falls back to
        activation code registration, raises RuntimeError if both fail.
        """
        from utils import Logger

        log = Logger()

        # 1. Try saved auth token
        if Path(PerleConstants.CLOUD_AUTH_TOKEN_FILE).exists():
            with open(PerleConstants.CLOUD_AUTH_TOKEN_FILE) as f:
                saved = json.load(f)

            auth_token = saved.get(self._router_id)
            saved_code = saved.get("registration_code", "")

            # If the registration code changed, re-register with the new one
            if self._registration_code and saved_code != self._registration_code:
                log.info("Registration code changed, re-registering with new code")
                self._remove_auth_token()
            elif auth_token and self._validate_auth_token(auth_token):
                self._auth_token = auth_token
                self._use_authorization_headers(auth_token)
                self._is_registered = True
                return
            else:
                # Token was invalid — clean it up
                log.warning("Removing invalid saved auth token")
                self._remove_auth_token()

        # 2. Try registration code
        if not self._registration_code:
            raise RegistrationError(
                "No valid auth token and no registration code configured"
            )

        self._use_activation_headers()

        # Generate a registration request for the cloud
        register_command = json.dumps(
            {"deviceSecretUID": self._router_id, "code": self._registration_code}
        )
        register_request = json.dumps(
            {
                "routerId": self._router_id,
                "messageId": 0,
                "messageType": "REGISTER_ROUTER_REQUEST",
                "messageParams": register_command,
                "authToken": None,
                "requiresResponse": True,
            }
        )

        # Send registration request to cloud, retrying on network errors
        headers = {
            "Content-Type": "application/json",
            self._authorization_header: self._authorization_hvalue,
            PerleConstants.HTTP_KEEP_ALIVE_HEADER: PerleConstants.HTTP_KEEP_ALIVE_HEADER_VAL_TRUE,
        }

        retry_delay = PerleConstants.CONNECT_FAIL_RETRY_TIME
        max_retry_delay = 30

        while True:
            try:
                register_reponse_data = requests.post(
                    url=proxy_config.perleCloudURL
                    + PerleCloudUris.routersFrontEndRegisterPath,
                    headers=headers,
                    data=register_request,
                    verify=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
                    timeout=(
                        PerleConstants.DEFAULT_HTTP_CONNECT_TIME,
                        PerleConstants.DEFAULT_HTTP_READ_TIME,
                    ),
                ).json()
                break
            except (
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout,
                requests.exceptions.ReadTimeout,
            ) as ex:
                log.warning(
                    f"Network error during registration, retrying in "
                    f"{retry_delay}s: {type(ex).__name__}"
                )
                time.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, max_retry_delay)

        # Update authorization
        auth_token = register_reponse_data.get("authToken")
        if (
            register_reponse_data.get("messageType") == "REGISTER_ROUTER_RESPONSE"
            and auth_token
        ):
            self._auth_token = auth_token
            self._use_authorization_headers(auth_token)
            self._save_auth_token(auth_token)
            self._is_registered = True
        else:
            error_msg = register_reponse_data.get("messageParams", "")
            if isinstance(error_msg, str):
                try:
                    error_detail = json.loads(error_msg)
                    error_msg = error_detail.get("errorMessage", error_msg)
                except (json.JSONDecodeError, TypeError):
                    pass
            raise RegistrationError(f"Registration failed: {error_msg}")

    @property
    def auth_header(self) -> str:
        return self._authorization_header

    @property
    def auth_header_value(self) -> str:
        return self._authorization_hvalue

    @property
    def auth_token(self) -> str:
        return self._auth_token

    @property
    def is_registered(self) -> bool:
        return self._is_registered
