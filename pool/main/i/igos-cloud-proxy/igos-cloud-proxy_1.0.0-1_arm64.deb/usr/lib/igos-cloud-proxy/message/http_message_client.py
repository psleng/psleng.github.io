import json
import sys
import textwrap
import traceback

import requests

from .message import Message
from utils import Logger, PerleSignalInterrupt
from utils.constants import PerleConstants
from utils.auth import DeviceAuthorizationService


class HttpMessageClient:
    def __init__(self, target_uri, auth_manager: DeviceAuthorizationService):
        self.auth_manager = auth_manager
        self.target_uri = target_uri
        self.session = requests.Session()
        self.authHeader = None
        self.authHeaderValue = None
        self.keepAliveHeader = PerleConstants.HTTP_KEEP_ALIVE_HEADER
        self.keepAliveHeaderValue = PerleConstants.HTTP_KEEP_ALIVE_HEADER_VAL_TRUE

    @staticmethod
    def getNextCmdParams_to_json(nextCmdTimeout):
        messageParam_dict = {
            "timeout": nextCmdTimeout,
        }
        json_data = json.dumps(messageParam_dict)
        return json_data

    def get_next_command(self, message, nextCmdTimeout):
        log = Logger()
        try:
            response_message = None
            messageParms = self.getNextCmdParams_to_json(nextCmdTimeout)
            message.messageParams = messageParms
            response_body = self.send_message(
                self.target_uri,
                message,
                timeout=(PerleConstants.DEFAULT_HTTP_CONNECT_TIME, nextCmdTimeout),
            )
            if response_body is not None:
                response_dict = json.loads(response_body)
                response_message = Message(
                    response_dict["routerId"],
                    response_dict["messageId"],
                    response_dict["messageType"],
                    response_dict["requiresResponse"],
                )
                response_message.authToken = response_dict["authToken"]
                response_message.messageParams = response_dict["messageParams"]

        except Exception as ex:
            response_message = None
            # check if Perle signal interrupt
            if isinstance(ex, PerleSignalInterrupt):
                log.debug(
                    f"Perle signal handler is interrupting processing of GET_NEXT_COMMAND, just return with None response"
                )
            else:
                log.debug(
                    f"get_next_command(): Got unknown exception in processing GET_NEXT_COMMAND:  Exception = \n{ex}"
                )
                log.debug("EXCEPTION: ".join(traceback.format_exception(ex)))

        return response_message

    @staticmethod
    def discCmdParams_to_json():
        messageParam_dict = {
            "offlineDuration": None,
        }
        json_data = json.dumps(messageParam_dict)
        return json_data

    def send_disconnect_command(self, message):
        messageParms = self.discCmdParams_to_json()
        message.messageParams = messageParms
        self.send_message(
            self.target_uri,
            message,
            timeout=(
                PerleConstants.DEFAULT_HTTP_CONNECT_TIME,
                PerleConstants.DISCONNECT_READ_TIMEOUT,
            ),
        )

    def send_command_response(self, message):
        self.send_message(self.target_uri, message)

    def set_keepAlive_header(self, keepAliveHeader, keepAliveHeaderValue):
        self.keepAliveHeader = keepAliveHeader
        self.keepAliveHeaderValue = keepAliveHeaderValue

    def set_keep_alive(self, keep_alive):
        """Set keep-alive header from a boolean value."""
        if keep_alive:
            self.keepAliveHeaderValue = PerleConstants.HTTP_KEEP_ALIVE_HEADER_VAL_TRUE
        else:
            self.keepAliveHeaderValue = PerleConstants.HTTP_KEEP_ALIVE_HEADER_VAL_FALSE

    def send_message(
        self,
        uri,
        message,
        timeout=(
            PerleConstants.DEFAULT_HTTP_CONNECT_TIME,
            PerleConstants.DEFAULT_HTTP_READ_TIME,
        ),
    ):
        log = Logger()
        log.debug(f"Sending message {message.messageType.name} ...")
        headers = {
            "Content-Type": "application/json",
            self.auth_manager.auth_header: self.auth_manager.auth_header_value,
            self.keepAliveHeader: self.keepAliveHeaderValue,
        }
        if self.session.cookies:
            cookie_str = "; ".join(
                f"{name}={value}" for name, value in self.session.cookies.items()
            )
            headers["Cookie"] = cookie_str
        if message.requiresResponse:
            requires_response = "true"
        else:
            requires_response = "false"

        message_dict = {
            "routerId": message.routerId,
            "messageId": message.messageId,
            "messageType": message.messageType.name,
            "messageParams": message.messageParams,
            "authToken": message.authToken,
            "requiresResponse": requires_response,
        }

        message_as_string = json.dumps(message_dict)
        data = message_as_string
        headers = headers
        verify = PerleConstants.HTTPS_VERIFY_CERTIFICATE

        log.debug(textwrap.dedent(f"""
                send_message():
                uri = {uri},
                data = {data},
                headers = {headers},
                timeout = {timeout},
                verify = {verify}
            """).strip())
        # <JSONDecodeError> class first introduced in python 3.5
        # https://docs.python.org/3.5/library/json.html#json.JSONDecodeError
        if sys.version_info.major == 3 and sys.version_info.minor <= 4:
            try:
                message_as_string = json.dumps(message_dict)
                response = self.session.post(
                    uri,
                    data=message_as_string,
                    headers=headers,
                    timeout=timeout,
                    verify=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
                )
                if not response.status_code == 200:
                    log.debug(
                        f"Response to {message.messageType.name} command was not valid: status_code = {response.status_code}"
                    )
                    return None

            except Exception as ex:
                log.debug(
                    f"Got Exception trying to send_message to cloud: Exception = \n{ex}"
                )
                if isinstance(ex, ValueError):
                    log.debug(
                        f"send_message(): Got ValueError exception trying to decode response"
                    )

                return None
        else:
            from json import JSONDecodeError

            try:
                message_as_string = json.dumps(message_dict)
                response = self.session.post(
                    uri,
                    data=message_as_string,
                    headers=headers,
                    timeout=timeout,
                    verify=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
                )
                if not response.status_code == 200:
                    log.debug(
                        f"Response to {message.messageType.name} command was not valid: status_code = {response.status_code}"
                    )
                    return None

            except Exception as ex:
                log.debug(
                    f"Got Exception trying to send_message to cloud: Exception = \n{ex}"
                )
                if isinstance(ex, JSONDecodeError):
                    log.debug(
                        f"send_message(): Got JSONDecodeError exception trying to decode response"
                    )

                return None

        return response.text

    def shutdown(self):
        self.session.close()  # Close the session to release the connection
