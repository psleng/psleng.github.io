import base64
import json
import re
import time
from http.client import HTTPConnection, responses
from threading import Thread
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from requests.exceptions import ConnectionError
from urllib3.util.retry import Retry

from .socketio_thread import SocketIOThread
from proxy.router_request_for_proxy_data import RouterRequestForProxyData
from proxy import HttpTransferData, ProxyConstants, ProxyData
from utils import Logger
from utils.constants import PerleConstants
from utils.error import ErrorCode


class ProxyThread(Thread):
    CONNECT_RETRY_TIME = 5
    ERROR_RETRY_TIME = 50

    def __init__(
        self,
        proxy_connection,
        proxy_cookie,
        router_client,
        proxy_uri,
        proxy_id,
        router_id,
        router_uri,
        use_hard_coded_target_host,
        stop_event,
        inactivity_timeout,
    ):
        super().__init__(daemon=True)
        self.thread_id = Thread.getName(self)
        self.proxy_connection = proxy_connection
        self.proxy_cookie = proxy_cookie
        self.proxy_uri = proxy_uri
        self.router_http_client = router_client
        self.proxy_http_client = requests.Session()
        self.proxy_http_client.verify = PerleConstants.HTTPS_VERIFY_CERTIFICATE
        retry_strategy = Retry(
            total=5,
            backoff_factor=0.1,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "PUT", "DELETE"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.proxy_http_client.mount("http://", adapter)
        self.proxy_http_client.mount("https://", adapter)
        self.router_id = router_id
        self.router_response_data = RouterRequestForProxyData(-1, proxy_id)
        self.router_response = RouterRequestForProxyData.to_json(
            self.router_response_data
        )
        self.hard_coded_target_host = self.get_http_host(router_uri)
        self.use_hard_coded_target_host = use_hard_coded_target_host
        self.stop_event = stop_event
        self.idle_timeout = (
            inactivity_timeout  # kept attribute name for backwards compatibility
        )
        self.socketio_thread = SocketIOThread(self.proxy_connection.session_id)
        self.socketio_thread.start()

    def load_proxy_data_from_json(self, json_str):
        json_data = json.loads(json_str)
        log = Logger()
        payload_data = json_data.get("payload", {})
        log.debug(
            "Proxy request received: "
            f"requestId={json_data.get('requestId')}, "
            f"requestMethod={json_data.get('requestMethod')}, "
            f"proxyRequestUri={json_data.get('proxyRequestUri')}, "
            f"headerCount={len(payload_data.get('headers', []))}, "
            f"contentBytesLength={len(payload_data.get('contentBytes') or '')}"
        )

        request_id = json_data["requestId"]
        proxy_id = json_data["proxyId"]
        request_method = json_data["requestMethod"]
        proxy_request_uri = json_data["proxyRequestUri"]
        if proxy_request_uri is not None:
            proxy_request_uri = proxy_request_uri.replace(
                "undefined", self.proxy_connection.session_id
            )
        error_message = json_data["errorMessage"]
        error_code = json_data["errorCode"]

        payload_data = json_data["payload"]
        payload = HttpTransferData()

        for header in payload_data["headers"]:
            payload.add_header(header)

        payload.set_content_bytes(payload_data["contentBytes"])
        # payload.host_name = payload_data["hostName"]
        # payload.port = payload_data["port"]
        # payload.scheme = payload_data["scheme"]

        proxy_data = ProxyData(proxy_request_uri, request_id, proxy_id)
        proxy_data.request_method = request_method
        proxy_data.payload = payload
        proxy_data.error_message = error_message
        proxy_data.error_code = error_code
        return proxy_data

    @staticmethod
    def get_http_host(router_uri):
        log = Logger()
        try:
            target_parsed = urlparse(router_uri)
        except (ValueError, TypeError) as e:
            log.debug(f"Error occurred while parsing url: {e}")
            return None
        target_host = HTTPConnection(str(target_parsed.hostname), target_parsed.port)
        return target_host

    def handle_proxy_exceptions(self, ex, performing_str):
        log = Logger()
        self.stop_event.set()
        # check for connection error
        if isinstance(ex, ConnectionError):
            log.debug(f"{performing_str}: ConnectionError exception:\n {ex}")

        # check for ReadTimeoutError
        elif isinstance(ex, requests.exceptions.Timeout):
            log.debug(f"{performing_str}: Timeout waiting for response:\n {ex}")
        else:
            log.debug(f"{performing_str}: Unknown exception: \n{ex}")

    @staticmethod
    def _is_socketio_request(proxy_request: ProxyData) -> bool:
        return bool(
            proxy_request.proxy_request_uri
            and "/socket.io/" in proxy_request.proxy_request_uri
        )

    @staticmethod
    def _is_socketio_long_poll_request(proxy_request: ProxyData) -> bool:
        if not ProxyThread._is_socketio_request(proxy_request):
            return False

        request_method = (proxy_request.request_method or "").upper()
        if request_method not in {"GET", "POST"}:
            return False

        proxy_request_uri = proxy_request.proxy_request_uri or ""
        return "transport=polling" in proxy_request_uri

    # ****************************************************** Thread Main Line ****************************************************
    def run(self):
        log = Logger()

        try:
            while not self.stop_event.is_set():
                try:
                    # log.debug(f'While loop TOP: Sending router response to proxy PLUS getting next user request')
                    log.debug(
                        f"While loop TOP: thread_id = {self.thread_id}, self.stop_event.is_set() = {self.stop_event.is_set()}"
                    )

                    # log.debug(f'Router response was {self.router_response}; on thread: {self.thread_id}')
                    http_response = (
                        self.send_router_response_and_get_next_user_request_from_proxy(
                            self.router_response
                        )
                    )
                    # if None probably got error
                    if http_response is None:
                        break

                    status_code = http_response.status_code
                    if status_code != 200:
                        log.debug(
                            f"Error getting next proxyRequest from user, statusCode: {status_code}"
                        )
                        self.stop_event.set()
                        break

                    try:
                        proxy_request = http_response.content.decode("utf-8")
                    except UnicodeDecodeError as ude:
                        log.debug(
                            f"Failed to decode proxy request body, using replacement chars: {ude}"
                        )
                        proxy_request = http_response.content.decode(
                            "utf-8", errors="replace"
                        )

                    # any successful fetch of a proxy request counts as user activity -> reset inactivity timer
                    try:
                        self.proxy_connection.reset_inactivity_timer()
                    except Exception:
                        # ignore if connection already shutting down
                        pass
                    # log.debug(f'Got proxy_request from user: {proxy_request}')
                    request = self.load_proxy_data_from_json(proxy_request)
                    log.debug(
                        f"ProxyData requestID: {request.request_id}; on thread: {self.thread_id}"
                    )

                    # Keep existing behavior for graphql requests.
                    if (
                        request.proxy_request_uri
                        and "/graphql" in request.proxy_request_uri
                    ):
                        log.debug(
                            f"Skipping {request.proxy_request_uri} request (requestID: {request.request_id}); on thread: {self.thread_id}"
                        )
                        skip_response = RouterRequestForProxyData(
                            request.request_id, request.proxy_id
                        )
                        self.router_response = skip_response.to_json_minimal()
                        continue

                    if self._is_socketio_long_poll_request(request):
                        log.debug(
                            f"Queueing socket.io request {request.proxy_request_uri} (requestID: {request.request_id}); on thread: {self.thread_id}"
                        )
                        self.socketio_thread.submit_long_poll_request(request)
                        self.router_response_data = RouterRequestForProxyData(
                            -1, request.proxy_id
                        )
                        self.router_response = RouterRequestForProxyData.to_json(
                            self.router_response_data
                        )
                        continue

                    # Handle empty proxy command (indicated by negative request ID)
                    # This is used to deal with load balancers and request timeouts when proxy user is idle
                    if request.request_id < 0:
                        if self.socketio_thread.has_long_poll_response():
                            socketio_response = (
                                self.socketio_thread.get_long_poll_reponse()
                            )
                            if socketio_response is not None:
                                self.router_response = socketio_response
                                log.debug(
                                    f"Using queued socket.io response for thread_id = {self.thread_id}"
                                )
                                continue
                        log.debug(
                            f"Empty proxy command received with requestID: {request.request_id}"
                        )
                        empty_proxy_response = RouterRequestForProxyData(
                            request.request_id, request.proxy_id
                        )
                        self.router_response = empty_proxy_response.to_json_minimal()
                        log.debug(
                            f"Sending minimal empty proxy response to proxy: {self.router_response}"
                        )
                        continue

                    error_code = request.error_code
                    error_message = request.error_message
                    if error_code is None and error_message is None:
                        self.router_response = self.send_request_to_router(request)
                        try:
                            router_response_json = json.loads(self.router_response)
                            payload = router_response_json.get("payload", {})
                            log.debug(
                                "Got router response: "
                                f"requestId={router_response_json.get('requestId')}, "
                                f"statusCode={router_response_json.get('statusCode')}, "
                                f"reasonPhrase={router_response_json.get('reasonPhrase')}, "
                                f"headerCount={len(payload.get('headers', []))}, "
                                f"contentBytesLength={len(payload.get('contentBytes') or '')}"
                            )
                        except Exception as ex:
                            log.debug(
                                f"Got router response (summary unavailable): {ex}"
                            )
                        continue

                    if (
                        (error_code == ErrorCode.TIMEOUT)
                        or (error_message is not None)
                        and (error_message.lower() == "timeout")
                    ):
                        log.debug(
                            f"Timeout error getting user request from proxy: {request.error_message}"
                        )
                        time.sleep(self.ERROR_RETRY_TIME)
                        continue

                    log.debug(
                        f"Error getting user request from proxy: {request.error_message}"
                    )
                    self.stop_event.set()

                except requests.exceptions.RequestException:
                    time.sleep(self.CONNECT_RETRY_TIME)
                except Exception as e:
                    log.debug(f"proxy_thread run(): {e}")

        finally:
            try:
                self.socketio_thread.stop()
            except Exception as ex:
                log.debug(f"proxy_thread run(): failed to stop socketio thread: {ex}")

        # ****************************************************** End of Thread Main Line ****************************************************

    def send_router_response_and_get_next_user_request_from_proxy(
        self, router_response
    ):
        data = router_response
        response = None
        cookies = {ProxyConstants.PROXY_COOKIE: self.proxy_cookie}
        headers = {"Content-Type": "application/json"}
        self.add_proxy_cookie(headers, cookies)
        try:
            response = self.proxy_http_client.post(
                self.proxy_uri,
                data=data,
                headers=headers,
                timeout=(
                    PerleConstants.CHECK_CLOUD_URL_CONNECT_TIMEOUT,
                    self.idle_timeout * 60,
                ),
                verify=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
            )
        except (
            requests.exceptions.ConnectTimeout,
            requests.exceptions.ReadTimeout,
        ) as timeout_error:
            self.handle_proxy_exceptions(
                timeout_error,
                f"Idle timeout {self.idle_timeout} min(s) reached, session ended",
            )
        except requests.exceptions.RequestException as ex:
            self.handle_proxy_exceptions(ex, f"Get next user proxy request failed")
        return response

    def add_proxy_cookie(self, headers, cookies):
        headers["Cookie"] = self.format_cookies(cookies)
        return headers

    @staticmethod
    def format_cookies(cookies):
        res = ""
        for name, value in cookies.items():
            res = name + "=" + value + ";"
        return res

    def send_request_to_router(self, to_router_request_data):
        router_response_data = None
        log = Logger()
        response_json = None
        try:
            to_router_request = to_router_request_data.new_proxy_request(
                session_id=self.proxy_connection.session_id
            )
            router_response_data = RouterRequestForProxyData(
                to_router_request_data.request_id, to_router_request_data.proxy_id
            )

            prepared_request = self.router_http_client.prepare_request(
                to_router_request
            )
            try:
                ###################################################
                header_snapshot = dict(prepared_request.headers)
                log.debug(
                    f"Proxy->Router request: {prepared_request.method} {prepared_request.url} headerCount={len(header_snapshot)}"
                )
                if prepared_request.body is not None:
                    body_len = (
                        len(prepared_request.body)
                        if hasattr(prepared_request.body, "__len__")
                        else "unknown"
                    )
                    log.debug(f"Proxy->Router body length: {body_len}")
                #########################################################
            except Exception as ex:
                log.debug(f"Failed to log proxy request: {ex}")
            from_router_response = self.router_http_client.send(
                prepared_request,
                stream=True,
                allow_redirects=False,
                verify=PerleConstants.PROXY_VERIFY_CERTIFICATE,
            )

            if from_router_response.status_code == 302:
                raw_content = from_router_response.content
            else:
                buffer = b""
                while True:
                    chunk = from_router_response.raw.read(1024)
                    if not chunk:
                        break
                    buffer += chunk
                raw_content = buffer

            b64_encoded_content = base64.b64encode(raw_content)
            cookies_str = from_router_response.headers.get("Set-Cookie", None)
            # Make sure to close the response to release the connection
            from_router_response.close()

            if cookies_str is not None:
                matches = re.findall(r"\bsession=([^;]*)", cookies_str)
                session = matches[-1] if matches else ""
                self.proxy_connection.session_id = session
            router_response_data.status_code = from_router_response.status_code
            setattr(
                router_response_data,
                "reason_phrase",
                responses[from_router_response.status_code],
            )
            router_response_data.copy_response_headers(from_router_response)
            if (
                router_response_data.status_code != 304
            ):  # HttpServletResponse.SC_NOT_MODIFIED
                router_response_data.payload.content_bytes = b64_encoded_content
            response_json = router_response_data.to_json()

        except Exception as ex:
            self.handle_proxy_exceptions(ex, f"Send proxy data to device failed")
        return response_json
