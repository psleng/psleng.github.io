import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .logger import Logger


class ProxyConfigException(Exception):
    def __init__(self, message: str) -> None:
        super().__init__(message)


@dataclass
class ProxyConfigData:
    ConnectFailBackoffRetryTime: str = "5"
    cloudConnectCount: str = "0"
    connectionFailReason: str = "-1"
    ConnectFailRetryTime: str = "5"

    _connectInterval: str = field(default="1800", repr=False)

    @property
    def connectInterval(self) -> str:
        return self._connectInterval

    _http_port: str = field(default="443", repr=False)

    @property
    def http_port(self) -> str:
        return self._http_port

    _idle_timeout: str = field(default="20", repr=False)

    @property
    def idle_timeout(self) -> str:
        return self._idle_timeout

    _local_port: str = field(default="8080", repr=False)

    @property
    def local_port(self) -> str:
        return self._local_port


class ProxyConfig:
    _config_path: str = r"/etc/igos-cloud-proxy"
    _config_file: str = r"igos-cloud-proxy.conf"

    _config: Path = Path(_config_path) / Path(_config_file)

    def __init__(self):
        self._perleCloudURL: str = "https://devices.perleapps.com/"
        self._proxy_data: ProxyConfigData = ProxyConfigData()

        self._load(self._config)

    def _load(self, config: Path):
        config_data: Optional[dict] = None
        with open(config, "r") as file:
            import json

            config_data = json.load(file)
            if config_data is None:
                raise ProxyConfigException("Could Not Load Proxy Config (NO DATA)")

        if not all(isinstance(val, str) for val in config_data.values()):
            raise ProxyConfigException("All values of config must be Type: str")

        # Assing perle cloud devices url overide if it exsits in the vyos rendered config file
        self._perleCloudURL = (
            config_data.get("perleCloudURL_OVERRIDE", "")
            if config_data.get("perleCloudURL_OVERRIDE", "") is not ""
            else self._perleCloudURL
        )

        self._tmpDeviceRegistrationPIN: str = config_data.get(
            "tmpDeviceRegistrationPIN", ""
        )
        # "150-043724M10035"

        try:
            serial_path = Path("/sys/class/dmi/id/product_serial")
            if serial_path.exists():
                with open(serial_path) as serial_file:
                    self._serialNumber: str = serial_file.read()
            else:
                self._serialNumber: str = "000-000000M00000"
        except:
            self._serialNumber: str = "000-000000M00000"

    @property
    def serial_number(self) -> str:
        return self._serialNumber

    @property
    def perleCloudURL(self) -> str:
        return self._perleCloudURL

    @property
    def tmpDeviceRegistrationPIN(self) -> str:
        return self._tmpDeviceRegistrationPIN

    @property
    def data(self) -> ProxyConfigData:
        return self._proxy_data

    def load_cloud_settings(self):
        """
        Loads minRetryInterval, maxRetryInterval, and pollTimeout from the
        cloud settings file. Creates the file with defaults if it doesn't exist.
        """
        from .constants import PerleConstants

        log = Logger()
        settings_path = PerleConstants.CLOUD_SETTINGS_FILE
        default_settings = {
            "minRetryInterval": PerleConstants.CONNECT_FAIL_RETRY_TIME,
            "maxRetryInterval": PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX,
            "pollTimeout": PerleConstants.NEXT_COMMAND_TIMEOUT,
        }
        try:
            if not os.path.exists(settings_path):
                settings_dir = os.path.dirname(settings_path)
                if settings_dir:
                    os.makedirs(settings_dir, exist_ok=True)
                with open(settings_path, "w") as f:
                    json.dump(default_settings, f, indent=4)
                log.debug(
                    f"cloudSettings file not found at {settings_path}, created with default values."
                )
                settings = default_settings
            else:
                with open(settings_path, "r") as f:
                    settings = json.load(f)

            min_val = settings.get("minRetryInterval")
            max_val = settings.get("maxRetryInterval")
            poll_val = settings.get("pollTimeout")

            if min_val is None:
                log.debug("minRetryInterval not found in cloudSettings, using default.")
            elif isinstance(min_val, int):
                PerleConstants.CONNECT_FAIL_RETRY_TIME = min_val

            if max_val is None:
                log.debug("maxRetryInterval not found in cloudSettings, using default.")
            elif isinstance(max_val, int):
                PerleConstants.CONNECT_FAIL_RETRY_TIME_MAX = max_val

            if poll_val is None:
                log.debug("pollTimeout not found in cloudSettings, using default.")
            elif isinstance(poll_val, int):
                PerleConstants.NEXT_COMMAND_TIMEOUT = poll_val

        except Exception as ex:
            log.debug(f"Error loading cloudSettings: {ex}")

    def update_cloud_settings_param(self, param_name, param_value):
        """
        Atomic update of a single parameter in the cloud settings JSON file.
        Returns True if a write occurred, False otherwise.
        """
        from .constants import PerleConstants

        log = Logger()
        settings_path = PerleConstants.CLOUD_SETTINGS_FILE
        tmp_path = settings_path + ".tmp"

        settings_dir = os.path.dirname(settings_path)
        if settings_dir:
            os.makedirs(settings_dir, exist_ok=True)
        try:
            settings = {}
            if os.path.exists(settings_path):
                try:
                    with open(settings_path, "r") as f:
                        settings = json.load(f)
                except (json.JSONDecodeError, IOError, OSError) as e:
                    log.debug(
                        f"cloudSettings file error: {e}, resetting settings file."
                    )
                    settings = {}

            if settings.get(param_name) == param_value:
                return False

            log.debug(f"cloudSettings updated: {param_name} = {param_value}")
            settings[param_name] = param_value

            with open(tmp_path, "w") as f:
                json.dump(settings, f, indent=4)
            os.replace(tmp_path, settings_path)
            return True
        except Exception as ex:
            log.debug(f"Exception in update_cloud_settings_param: {ex}")
            return False


proxy_config = ProxyConfig()
