import json

from message import Message
from igos.vyos_api import VyosAPI


def get_easyport_interface(message: Message, provider: VyosAPI):
    return json.dumps({"easyportInterfacesList": []})
