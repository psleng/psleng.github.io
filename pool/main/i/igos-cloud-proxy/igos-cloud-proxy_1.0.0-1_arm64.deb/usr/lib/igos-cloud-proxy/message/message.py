import json
import sys
from typing import Optional

from .message_type import MessageType
from utils import JSONUtils, Logger
from utils.error import Error


class Message:
    def __init__(
        self,
        router_id: str,
        message_id: int,
        message_type: MessageType,
        requires_response: bool,
    ):
        self.routerId: str = router_id
        self.messageId: int = message_id
        self.messageType: MessageType = message_type
        self.requiresResponse: bool = requires_response
        self.messageParams: Optional[str] = None
        self.authToken: Optional[str] = None

    def to_json(self) -> str:
        return json.dumps(
            {
                "routerId": self.routerId,
                "messageId": self.messageId,
                "messageType": self.messageType.name,
                "messageParams": self.messageParams,
                "authToken": self.authToken,
                "requiresResponse": self.requiresResponse,
            }
        )

    @classmethod
    def create_error_message(cls, router_id, message_id, error_code, error_message):
        log = Logger()
        result_message = cls(router_id, message_id, MessageType.ERROR, False)
        error = Error(error_code, error_message)
        # <JSONDecodeError> class first introduced in python 3.5
        # https://docs.python.org/3.5/library/json.html#json.JSONDecodeError
        if sys.version_info.major == 3 and sys.version_info.minor <= 4:
            try:
                result_message.messageParams = JSONUtils.to_json(error)
            except ValueError:
                log.debug("Raised ValueError")
                return None
        else:
            try:
                result_message.messageParams = JSONUtils.to_json(error)
            except json.JSONDecodeError:
                # Handle JSON serialization error
                log.debug("Error converting to JSON")
                return None
        return result_message
