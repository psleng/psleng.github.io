import asyncio
import base64
from http.client import responses
from queue import Queue
from threading import Event, Thread
from typing import Optional

import aiohttp

from proxy.router_request_for_proxy_data import RouterRequestForProxyData
from proxy import ProxyConstants, ProxyData
from utils import Logger
from utils.constants import PerleConstants


class SocketIOError(Exception):
    """Custom Socket.io Error class"""

    def __init__(self, message: str) -> None:
        """Initializes the Socker.io error class

        Args:
            message (str): The error message

        Returns:
            None
        """
        super().__init__(message)


class SocketIOThread(Thread):
    def __init__(self, session_id: str, max_connections: int = 100):
        super().__init__()
        self._session_id: str = session_id
        self._log = Logger()

        self._output_queue: Queue[str] = Queue(maxsize=max_connections)
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._session: Optional[aiohttp.ClientSession] = None
        self._ready: Event = Event()
        self._shutdown_event: Optional[asyncio.Event] = None
        self._max_connections: int = max_connections

    async def _main(self) -> None:
        # Create an async HTTP session
        self._log.debug(
            f"SocketIOThread starting event loop for session_id={self._session_id}"
        )
        connector = aiohttp.TCPConnector(
            limit=self._max_connections,
            verify_ssl=PerleConstants.HTTPS_VERIFY_CERTIFICATE,
        )
        self._session = aiohttp.ClientSession(connector=connector)
        self._shutdown_event = asyncio.Event()

        self._ready.set()
        self._log.debug("SocketIOThread HTTP session ready")
        await self._shutdown_event.wait()  # Keep event loop alive until stop() signals shutdown

    async def _fetch(self, proxy_request: ProxyData) -> None:
        assert self._session is not None
        method = (proxy_request.request_method or "GET").upper()
        url = proxy_request.proxy_request_uri
        self._log.debug(
            f"SocketIOThread fetch start: requestId={proxy_request.request_id}, proxyId={proxy_request.proxy_id}, method={method}, url={url}"
        )
        hop_by_hop_headers = {
            header.lower() for header in ProxyConstants.hop_by_hop_headers
        }
        headers = {
            header["name"]: header["value"]
            for header in proxy_request.payload.get_headers()
            if header["name"].lower() not in hop_by_hop_headers
        }

        request_body = b""
        content_bytes = proxy_request.payload.get_content_bytes()
        if content_bytes:
            if isinstance(content_bytes, str):
                content_bytes = content_bytes.encode("utf-8", errors="ignore")
            try:
                request_body = base64.b64decode(content_bytes)
            except Exception:
                request_body = b""

        request_kwargs = {"headers": headers, "allow_redirects": False}
        if request_body and method in {"POST", "PUT", "PATCH", "DELETE"}:
            request_kwargs["data"] = request_body

        self._log.debug(
            f"SocketIOThread outbound request prepared: requestId={proxy_request.request_id}, headerCount={len(headers)}, bodyLength={len(request_body)}"
        )

        response_proxy_data = RouterRequestForProxyData(
            proxy_request.request_id, proxy_request.proxy_id
        )

        try:
            async with self._session.request(method, url, **request_kwargs) as response:
                response_body = await response.read()
                response_proxy_data.status_code = response.status
                setattr(
                    response_proxy_data, "reason_phrase", responses[response.status]
                )

                self._log.debug(
                    f"SocketIOThread response received: requestId={proxy_request.request_id}, status={response.status}, reason={responses[response.status]}, responseBytes={len(response_body)}"
                )

                for header_name, header_value in response.headers.items():
                    if header_name.lower() in hop_by_hop_headers:
                        continue
                    response_proxy_data.copy_response_header(header_name, header_value)

                if response.status != 304:
                    response_proxy_data.payload.set_content_bytes(
                        base64.b64encode(response_body)
                    )
        except Exception as ex:
            self._log.debug(
                f"SocketIOThread fetch failed: requestId={proxy_request.request_id}, proxyId={proxy_request.proxy_id}, error={ex}"
            )
            response_proxy_data.status_code = 500
            setattr(response_proxy_data, "reason_phrase", "Internal Server Error")

        response_json = response_proxy_data.to_json()
        if response_json is not None:
            self._log.debug(
                f"SocketIOThread queueing response: requestId={proxy_request.request_id}, queueSizeBeforePut={self._output_queue.qsize()}"
            )
            await self._loop.run_in_executor(
                None, lambda: self._output_queue.put(response_json)
            )
            self._log.debug(
                f"SocketIOThread response queued: requestId={proxy_request.request_id}, queueSizeAfterPut={self._output_queue.qsize()}"
            )
        else:
            self._log.debug(
                f"SocketIOThread dropping empty response JSON: requestId={proxy_request.request_id}"
            )

    def submit_long_poll_request(self, proxy_request: ProxyData) -> None:
        self._log.debug(
            f"SocketIOThread submit_long_poll_request called: requestId={proxy_request.request_id}, proxyId={proxy_request.proxy_id}"
        )
        self._ready.wait()
        asyncio.run_coroutine_threadsafe(self._fetch(proxy_request), self._loop)

    def has_long_poll_response(self) -> bool:
        return not self._output_queue.empty()

    def get_long_poll_reponse(self):
        if self._output_queue.empty():
            return None
        self._log.debug(f"SENDING POLL RESPONSE")
        return self._output_queue.get_nowait()

    def run(self) -> None:
        self._log.debug("SocketIOThread run() entered")
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._main())

    def stop(self) -> None:
        self._log.debug("SocketIOThread stop() requested")

        async def _shutdown() -> None:
            if self._session:
                self._log.debug("SocketIOThread closing HTTP session")
                await self._session.close()
            if self._shutdown_event is not None:
                self._shutdown_event.set()
                self._log.debug("SocketIOThread shutdown event set")

        asyncio.run_coroutine_threadsafe(_shutdown(), self._loop)
        self.join()
        self._ready.clear()
        self._log.debug("SocketIOThread stopped")
