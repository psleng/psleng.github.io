#!/usr/bin/python3

import signal
import sys
import time

from .constants import PerleConstants
from .logger import Logger


# Custom exception to interrupt sleeps
class PerleSignalInterrupt(Exception):
    def __init__(self, message=None):
        self.message = message
        super().__init__(message)


class SignalHandler(object):
    def setup(self):

        if PerleConstants.ISROUTER:
            signal.signal(signal.SIGHUP, self.catch)
            signal.siginterrupt(signal.SIGHUP, False)

            signal.signal(signal.SIGUSR1, self.catch)
            signal.siginterrupt(signal.SIGUSR1, False)

            signal.signal(signal.SIGUSR2, self.catch)
            signal.siginterrupt(signal.SIGUSR2, False)

            signal.signal(signal.SIGTERM, self.catch)
            signal.siginterrupt(signal.SIGTERM, True)
        else:
            signal.signal(signal.SIGINT, self.catch)

    def catch(self, signum, frame):
        log = Logger()
        if sys.version_info.major == 3 and sys.version_info.minor <= 4:
            # class <signal.Signals> first introduced in python 3.5
            # https://docs.python.org/3/library/signal.html#signal.Signals
            SIGNALS_TO_NAMES_DICT = dict(
                (getattr(signal, n), n)
                for n in dir(signal)
                if n.startswith("SIG") and "_" not in n
            )
            log.debug(
                f"Signal handler in called with signal {SIGNALS_TO_NAMES_DICT[signum]} ({signum})"
            )
        else:
            log.debug(
                f"Signal handler called with signal {signal.Signals(signum).name} ({signum})"
            )

        if PerleConstants.ISROUTER or PerleConstants.IS_pcSimulateRouter:
            # Signal for configuration update
            if signum == signal.SIGHUP:
                self.sigUpdateConfig = True
                log.debug(
                    f"Indicate configuration update pending: self.sigUpdateConfig = {self.sigUpdateConfig}"
                )
            # Signal for reload of debug facility
            elif signum == signal.SIGUSR1:
                self.sigUpdateDebugMode = True
                log.debug(
                    f"Indicate reload of debug facility pending: self.sigUpdateDebugMode = {self.sigUpdateDebugMode}"
                )
                # Signal for cloud connect now & device register
            elif signum == signal.SIGUSR2:
                self.sigConnectNowRequest = True
                log.debug(
                    f"Indicate cloud connect now or device register pending: self.sigConnectNowRequest = {self.sigConnectNowRequest}"
                )
            elif signum == signal.SIGTERM:
                self.sigStop = True
                log.debug(
                    f"Indicate process termination pending: self.sigStop = {self.sigStop}"
                )
            else:
                log.debug(f"Unhandled Signal: signum = {signum}\n frame={frame}")
        else:
            if signum == signal.SIGINT:
                log.debug(f"You pressed Ctrl-C")
                self.sigStop = True
            else:
                log.debug("Unhandled Signal: signum = {signum}\n frame={frame}")

        raise PerleSignalInterrupt(
            "Raising Perle signal interrupt for any sleep() calls"
        )

    def __init__(self):
        self.sigUpdateConfig = False
        self.sigUpdateDebugMode = False
        self.sigConnectNowRequest = False
        self.sigStop = False


# ---------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------


def main():
    """
    TEST
    """

    sigHandler = SignalHandler()
    sigHandler.setup()
    time.sleep(5)


if __name__ == "__main__":
    main()
