

class ProxyConstants:
    PROXY_COOKIE = "PERLE_PROXY_COOKIE"
    proxyConnections = 3
    ATTR_TARGET_URI = f'{__name__}.targetUri'    # ProxyConstants.__name__
    ATTR_TARGET_HOST = f'{__name__}.targetHost'  # ProxyConstants.__name__

    for_header_name = "X-Forwarded-For"
    proto_header_name = "X-Forwarded-Proto"

    # Define the set of hop-by-hop headers
    hop_by_hop_headers = {
        "Connection", "Keep-Alive", "Proxy-Authenticate", "Proxy-Authorization",
        "TE", "Trailers", "Transfer-Encoding", "Upgrade"
    }
