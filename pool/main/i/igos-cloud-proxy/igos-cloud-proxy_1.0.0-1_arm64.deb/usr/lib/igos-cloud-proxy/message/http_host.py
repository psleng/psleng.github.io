# from urllib.parse import urlparse


class HttpHost:
    def __init__(self, host_name, port, scheme):
        # parsed_url = urlparse(host_string)
        # self.scheme = parsed_url.scheme
        # self.host_name = parsed_url.hostname
        # self.port = parsed_url.port
        self.scheme = scheme
        self.host_name = host_name
        self.port = port

    def __str__(self):
        return f"{self.scheme}://{self.host_name}:{self.port}"

# Example usage
# host_string = "https://www.example.com:443"
# host = HttpHost(host_string)
# print(host.scheme)  # Output: https
# print(host.host_name)  # Output: www.example.com
# print(host.port)  # Output: 443
# print(host)  # Output: https://www.example.com:443
