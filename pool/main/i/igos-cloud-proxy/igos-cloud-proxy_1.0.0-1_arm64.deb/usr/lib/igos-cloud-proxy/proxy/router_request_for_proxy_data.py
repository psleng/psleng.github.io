import json

from .proxy_data import HeaderPair, HttpTransferData
from .proxy_constants import ProxyConstants
from utils import Logger


class RouterRequestForProxyData:

    def __init__(self, request_id, proxy_id):
        self.request_id = request_id
        self.proxy_id = proxy_id
        self.status_code = 0
        self.reason_phrase = None
        self.do_handle_compression = False
        self.payload = HttpTransferData()

    def copy_response_headers(self, proxy_response):
        for header, value in proxy_response.headers.items():
            self.copy_response_header(header, value)

    def copy_response_header(self, header_name, header_value):
        if header_name in ProxyConstants.hop_by_hop_headers:
            return
        self.payload.add_header(HeaderPair(header_name, header_value).to_dict())

    def get_status_code(self):
        return self.status_code

    def get_reason_phrase(self):
        return self.reason_phrase

    def get_request_id(self):
        return self.request_id

    def get_proxy_id(self):
        return self.proxy_id

    def get_headers(self):
        return self.payload.get_headers()

    def get_content_bytes(self):
        return self.payload.get_content_bytes()

    @classmethod
    def from_json(cls, json_str):
        json_data = json.loads(json_str)
        return cls(**json_data)

    def to_json(self):
        log = Logger()
        # content_bytes contains base64-encoded data; decode it as a string
        # for JSON serialization. Base64 uses only ASCII so decode should
        # always work, but decode defensively in case of corruption.
        content_bytes_str = None
        if self.payload.content_bytes:
            try:
                content_bytes_str = self.payload.content_bytes.decode("utf-8")
            except (UnicodeDecodeError, AttributeError) as e:
                log.debug(f"Failed to decode content_bytes for JSON: {e}")
                content_bytes_str = None

        json_data = {
            "requestId": self.request_id,
            "proxyId": self.proxy_id,
            "statusCode": self.status_code,
            "reasonPhrase": self.reason_phrase,
            # "doHandleCompression": self.do_handle_compression,
            "payload": {
                "headers": self.payload.headers,
                # "cookies": self.payload.cookies,  # You can add cookies if needed
                "contentBytes": content_bytes_str,
                # "hostName": self.payload.host_name,  # Fill in host name if needed
                # "port": self.payload.port,  # Fill in port if needed
                # "scheme": self.payload.scheme  # Fill in scheme if needed
            },
        }
        try:
            return json.dumps(json_data)
        except TypeError as e:
            log.debug(f"Error occurred while parsing json: {e}")

    def to_json_minimal(self):
        log = Logger()
        json_data = {"requestId": self.request_id, "proxyId": self.proxy_id}
        try:
            return json.dumps(json_data)
        except TypeError as e:
            log.debug(f"Error occurred while parsing minimal json: {e}")
