#!/usr/bin/python3

from __future__ import annotations

import json
import os
import signal
import sys
import traceback
from pathlib import Path
from types import FrameType

from dotenv import load_dotenv
from requests.exceptions import ConnectionError

from command import (
    EmptyCommandNew,
    UnregCommand,
)
from message import HttpMessageClient, Message, MessageType
from proxy import ProxyConnect, ProxyConnection, ProxyConnectResponse
from utils import (
    ConnectionUtils,
    JSONUtils,
    Logger,
    ProxyConfig,
)
from utils.auth import DeviceAuthorizationService, RegistrationError
from utils.constants import (
    CloudConnStatus,
    PerleCloudUris,
    PerleConstants,
)
from utils.error import Error, ErrorCode
from igos import IGOSRestService


class PerleCloudServices:

    def __init__(
        self,
        router_id: str,
        router_uri: str,
        cloud_uri: str,
        use_hard_coded_target_host: bool,
    ) -> None:
        self.log: Logger = Logger()
        self.proxy_config: ProxyConfig = ProxyConfig()

        # Load env.conf for secrets like VYOS_API_KEY
        env_path = Path(__file__).resolve().parent / "env.conf"
        load_dotenv(env_path)

        self.igos_rest_service: IGOSRestService = IGOSRestService(
            os.environ.get("VYOS_API_KEY", "mykey")
        )

        self.router_id: str = router_id
        self.router_uri: str = router_uri
        self.router_uri_proxy: str = (
            f"{router_uri}:{PerleConstants.DEFAULT_ROUTER_URI_PORT_PROXY}"
        )
        self.router_uri_rest: str = (
            f"{router_uri}:{PerleConstants.DEFAULT_ROUTER_URI_PORT_REST}"
        )
        self.cloud_uri: str = cloud_uri
        self.use_hard_coded_target_host: bool = use_hard_coded_target_host

        self.auth_manager: DeviceAuthorizationService = DeviceAuthorizationService(
            self.router_id, self.proxy_config.tmpDeviceRegistrationPIN
        )
        self.cloud_connection: HttpMessageClient = HttpMessageClient(
            cloud_uri + PerleCloudUris.routersFrontEndCommandPath, self.auth_manager
        )

        self.stop: bool = False
        self.proxy_connections: list[ProxyConnection] = []
        self.current_cloud_conn_status: int | None = None
        self.connect_fail_retry_time: int = PerleConstants.CONNECT_FAIL_RETRY_TIME
        self.register_retry_time: int = PerleConstants.REGISTER_RETRY_TIME
        self.connect_interval: int = PerleConstants.NEXT_POLL_DELAY
        self.connect_next_poll_interval: int = self.connect_interval
        self.next_cmd_timeout: int = PerleConstants.NEXT_COMMAND_TIMEOUT
        self.close_cloud_conn: bool = False
        self.connect_fail_backoff_retry_time: int | None = None
        self.idle_timeout: int = PerleConstants.DEFAULT_PROXY_IDLE_TIMEOUT

        self.proxy_config.load_cloud_settings()

    def start_proxy_connection(self, message: Message) -> Message:
        self.log.debug("PROXY_CONNECT command received ...")
        params = message.messageParams
        proxy_connect: ProxyConnect = JSONUtils.from_json(params, ProxyConnect)
        proxy_cookie = proxy_connect.proxy_cookie
        recommended_proxy_connections = proxy_connect.proxy_connections

        inactivity = proxy_connect.proxy_inactivityTimeout
        session = proxy_connect.proxy_sessionTimeout
        try:
            inactivity = int(inactivity) if inactivity is not None else None
        except (ValueError, TypeError):
            inactivity = None
        try:
            session = int(session) if session is not None else None
        except (ValueError, TypeError):
            session = None

        if inactivity is None:
            inactivity = self.idle_timeout

        response = Message(
            self.router_id,
            message.messageId,
            MessageType.PROXY_CONNECT_RESPONSE,
            False,
        )
        proxy_connect_response = ProxyConnectResponse(self.router_uri_proxy)
        response.messageParams = JSONUtils.to_json(proxy_connect_response)
        response.authToken = self.auth_manager.auth_token

        existing: ProxyConnection | None = None
        for conn in self.proxy_connections:
            if conn.proxy_cookie == proxy_cookie:
                existing = conn
                break

        if existing is not None:
            self.log.debug(
                f"Refreshing existing proxy connection {proxy_cookie}: "
                f"inactivity={inactivity}, session={session}"
            )
            existing.update_timeouts(inactivity, session)
            existing.reset_inactivity_timer()
            if existing.session_timeout and existing.session_timeout > 0:
                existing.reset_session_timer()
        else:
            self.log.debug(
                f"Creating new proxy connection {proxy_cookie}: "
                f"inactivity={inactivity}, session={session}"
            )
            self.proxy_connections.append(
                ProxyConnection(
                    self,
                    proxy_cookie,
                    recommended_proxy_connections,
                    proxy_connect.proxy_uri,
                    proxy_connect.proxy_id,
                    self.router_id,
                    self.router_uri,
                    self.use_hard_coded_target_host,
                    inactivity,
                    session,
                )
            )
        return response

    def update_cloud_conn_status(self, conn_status: CloudConnStatus) -> None:
        if conn_status.value == self.current_cloud_conn_status:
            return

        self.current_cloud_conn_status = conn_status.value
        self.log.debug(f"Cloud connection status updated to {conn_status.name}")

    def update_retry_interval(self, retry_interval: int) -> None:
        try:
            self.proxy_config.data.ConnectFailRetryTime = str(retry_interval)
            self.log.debug(f"Cloud connect_fail_retry_time updated to {retry_interval}")
        except Exception as ex:
            self.log.debug(f"Failed to update connect_fail_retry_time, error: {ex}")

    def update_cloud_config(self, next_poll_delay: int) -> None:
        if next_poll_delay == self.connect_interval:
            return

        self.connect_interval = next_poll_delay

        try:
            self.proxy_config.data._connectInterval = str(self.connect_interval)
            self.log.debug(f"Cloud connect_interval updated to {self.connect_interval}")
        except Exception as ex:
            self.log.debug(f"Failed to update cloud connect_interval, error: {ex}")

    def get_cloud_config(self) -> None:
        try:
            self.connect_fail_backoff_retry_time = int(
                self.proxy_config.data.ConnectFailBackoffRetryTime
            )
            self.log.info(
                f"ConnectFailBackoffRetryTime = {self.connect_fail_backoff_retry_time}"
            )
        except Exception as ex:
            self.log.debug(
                f"Failed to get config from CFGDB_RECORD_PERLE_CLOUD_SERVICES, error: {ex}"
            )

        try:
            http_port = int(self.proxy_config.data.http_port)
            self.router_uri_proxy = (
                f"{PerleConstants.DEFAULT_ROUTER_URI_PROTOCOL}://"
                f"{PerleConstants.DEFAULT_ROUTER_URI_IP}:{http_port}"
            )

            self.idle_timeout = int(self.proxy_config.data.idle_timeout)

            rest_port = int(self.proxy_config.data.local_port)
            self.router_uri_rest = (
                f"{PerleConstants.DEFAULT_ROUTER_URI_PROTOCOL}://"
                f"{PerleConstants.DEFAULT_ROUTER_URI_IP}:{rest_port}"
            )
            self.log.info(f"Updated router_uri_rest = {self.router_uri_rest}")
        except Exception as ex:
            self.log.debug(f"Failed to get ports and RESTful config, error: {ex}")

    def process_error_message(
        self, last_message_type: MessageType, error_message_params: str | None
    ) -> int:
        next_poll_interval = self.connect_interval

        self.log.debug(
            f"process_error_message(): last_message_type={last_message_type}, "
            f"error_message_params={error_message_params}"
        )

        error: Error = JSONUtils.from_json(error_message_params, Error)
        self.log.debug(
            f"{last_message_type.value} failed with error: "
            f"{error.error_code} - {error.error_message}"
        )

        if error.error_code == ErrorCode.AUTH_FAILED.value:
            if last_message_type == MessageType.REGISTER_ROUTER_REQUEST:
                return next_poll_interval

            self.unregister_device()
            self.log.warning(
                "Received authentication error from cloud, device is no longer registered"
            )
            next_poll_interval = self.register_retry_time
        else:
            self.log.debug("Unhandled error type received from cloud")

        return next_poll_interval

    def unregister_device(self) -> None:
        self.auth_manager.deregister_device()
        self.update_cloud_conn_status(CloudConnStatus.CLOUD_STATUS_DEVICE_UNREGISTERED)
        self.stop = True

    def process_unregister_command(self, message: Message) -> None:
        self.log.debug("UNREGISTER_ROUTER command received ...")
        params = message.messageParams
        reason_msg = None
        if params:
            unreg_command: UnregCommand = JSONUtils.from_json(params, UnregCommand)
            reason_msg = unreg_command.unreg_command_reason

        self.log.warning(f"Device has been unregistered by the cloud: {reason_msg}")
        self.unregister_device()

    def send_disconnect_warning(self) -> None:
        disc_command = Message(self.router_id, 0, MessageType.DISCONNECT, False)
        disc_command.authToken = self.auth_manager.auth_token

        try:
            self.cloud_connection.send_disconnect_command(disc_command)
        except Exception as ex:
            if self.stop:
                self.log.debug(
                    "Expected DISCONNECT read timeout due to cloud function being disabled"
                )
                return
            self.log.debug(f"Got Exception trying to send DISCONNECT to cloud: {ex}")
            if isinstance(ex, ConnectionError):
                self.log.debug(
                    "Sending DISCONNECT command to cloud failed: Connection error"
                )
                ConnectionUtils.safe_sleep(self.register_retry_time)

    def process_empty_command(self, message: Message) -> None:
        self.log.debug("EMPTY_COMMAND command received ...")

        params = message.messageParams
        if params:
            empty_command = JSONUtils.from_json_check_PARAMS(params, EmptyCommandNew)
            if not empty_command or not isinstance(empty_command, EmptyCommandNew):
                return

            next_poll_delay = empty_command.empty_command_nextPollDelay
            keep_alive = empty_command.empty_command_keepAlive
            min_retry_interval = empty_command.empty_command_minRetryInterval
            max_retry_interval = empty_command.empty_command_maxRetryInterval
            poll_timeout = empty_command.empty_command_pollTimeout

            if next_poll_delay is not None:
                self.update_cloud_config(next_poll_delay)
            if keep_alive is not None:
                self.cloud_connection.set_keep_alive(keep_alive)

            if (
                min_retry_interval
                and max_retry_interval
                and min_retry_interval <= max_retry_interval
            ):
                self.proxy_config.update_cloud_settings_param(
                    "minRetryInterval", min_retry_interval
                )
                self.proxy_config.update_cloud_settings_param(
                    "maxRetryInterval", max_retry_interval
                )
                ConnectionUtils.updateFailRetryTime(
                    min_retry_interval, max_retry_interval
                )
                self.update_retry_interval(min_retry_interval)
            else:
                self.log.debug(
                    f"Invalid minRetryInterval={min_retry_interval}, "
                    f"maxRetryInterval={max_retry_interval}"
                )

            if poll_timeout is not None:
                self.proxy_config.update_cloud_settings_param(
                    "pollTimeout", poll_timeout
                )
                ConnectionUtils.updatNextCommandTimeout(poll_timeout)
            else:
                self.log.debug(f"Invalid pollTimeout={poll_timeout}")

            self.log.debug(
                f"next_poll_delay={next_poll_delay}, keep_alive={keep_alive}, "
                f"poll_timeout={poll_timeout}, min_retry_interval={min_retry_interval}, "
                f"max_retry_interval={max_retry_interval}"
            )

        self.update_cloud_conn_status(CloudConnStatus.CLOUD_STATUS_CLOUD_IDLE)
        self.log.debug(
            f"Cloud sent empty command, starting connect interval timer "
            f"{self.connect_interval}s, close_cloud_conn={self.close_cloud_conn}"
        )

    def process_received_command(
        self, cloud_command_received: Message
    ) -> Message | None:
        """Dispatch an incoming cloud command and return a response Message or None."""
        cloud_command_response: Message | None = None

        if cloud_command_received.messageType == MessageType.EXECUTE_REST_COMMAND.value:
            rest_body = self.igos_rest_service.process_rest_command(
                cloud_command_received
            )
            payload = json.dumps({"statusCode": 200, "body": rest_body})
            cloud_command_response = Message(
                self.router_id,
                cloud_command_received.messageId,
                MessageType.EXECUTE_REST_COMMAND_RESPONSE,
                False,
            )
            cloud_command_response.authToken = self.auth_manager.auth_token
            cloud_command_response.messageParams = payload

        elif cloud_command_received.messageType == MessageType.UNREGISTER_ROUTER.value:
            self.process_unregister_command(cloud_command_received)
            self.connect_next_poll_interval = self.connect_interval

        elif cloud_command_received.messageType == MessageType.PROXY_CONNECT.value:
            cloud_command_response = self.start_proxy_connection(cloud_command_received)

        elif cloud_command_received.messageType == MessageType.EMPTY_COMMAND.value:
            self.process_empty_command(cloud_command_received)
            self.connect_next_poll_interval = self.connect_interval

        elif cloud_command_received.messageType == "ERROR":
            self.connect_next_poll_interval = self.process_error_message(
                MessageType.GET_NEXT_COMMAND, cloud_command_received.messageParams
            )

        else:
            self.log.debug(
                f"Unknown command received: "
                f"messageType={cloud_command_received.messageType}"
            )

        return cloud_command_response

    def run(self) -> None:
        self.auth_manager.register_device()

        signal.signal(signal.SIGINT, self._handle_sigint)
        self.get_cloud_config()

        while not self.stop:

            if self.close_cloud_conn:
                self.cloud_connection.shutdown()
                self.stop_proxy_connections()
                self.close_cloud_conn = False

            if (
                self.connect_fail_backoff_retry_time
                != PerleConstants.CONNECT_FAIL_RETRY_TIME
            ):
                ConnectionUtils.init_backoff_retry_time()
                self.connect_fail_backoff_retry_time = (
                    PerleConstants.CONNECT_FAIL_RETRY_TIME
                )

            self.log.debug(
                f"Poll server timer connect_next_poll_interval="
                f"{self.connect_next_poll_interval}"
            )
            ConnectionUtils.safe_sleep(self.connect_next_poll_interval)

            if self.stop:
                break

            cloud_command_request = Message(
                self.router_id, 0, MessageType.GET_NEXT_COMMAND, True
            )
            cloud_command_request.authToken = self.auth_manager.auth_token
            self.next_cmd_timeout = PerleConstants.NEXT_COMMAND_TIMEOUT

            cloud_command_received = self.cloud_connection.get_next_command(
                cloud_command_request,
                self.next_cmd_timeout,
            )

            if cloud_command_received is None:
                if not self.stop:
                    self.log.debug(
                        f"GET_NEXT_COMMAND returned None, continuing with "
                        f"connect_fail_retry_time={self.connect_fail_retry_time}"
                    )
                continue

            self.log.debug(
                f"cloud_command_received: "
                f"messageId={cloud_command_received.messageId}, "
                f"routerId={cloud_command_received.routerId}, "
                f"messageType={cloud_command_received.messageType}, "
                f"requiresResponse={cloud_command_received.requiresResponse}"
            )

            try:
                cloud_command_response = self.process_received_command(
                    cloud_command_received
                )
            except Exception as ex:
                self.log.error(
                    f"Exception processing command "
                    f"{cloud_command_received.messageType}: {ex}"
                )
                continue

            if cloud_command_response is not None:
                try:
                    self.cloud_connection.send_command_response(cloud_command_response)
                except Exception as ex:
                    self.log.debug(f"Exception sending command response: {ex}")
            else:
                self.log.debug("No response to send")

    def _handle_sigint(self, signum: int, frame: FrameType | None) -> None:
        """Handle SIGINT for a clean and fast shutdown."""
        self.log.info("SIGINT received, shutting down...")
        self.stop = True

    def shutdown(self) -> None:
        self.stop = True
        if (
            self.current_cloud_conn_status
            == CloudConnStatus.CLOUD_STATUS_CONNECTED.value
        ):
            self.send_disconnect_warning()
        self.cloud_connection.shutdown()
        self.stop_proxy_connections()

    def stop_proxy_connections(self) -> None:
        if self.proxy_connections:
            for proxy_connection in self.proxy_connections:
                proxy_connection.shutdown()
            self.proxy_connections = []


def main() -> None:
    log = Logger()
    proxy_config = ProxyConfig()

    log.enable_debugging()
    log.info("Cloud Services starting...")

    router_id: str = proxy_config.serial_number
    router_uri: str = PerleConstants.DEFAULT_ROUTER_URI
    cloud_uri: str = proxy_config.perleCloudURL

    log.debug(f"router_id={router_id}, router_uri={router_uri}, cloud_uri={cloud_uri}")

    if router_id and cloud_uri:
        log.debug(f"HTTPS_VERIFY_CERTIFICATE={PerleConstants.HTTPS_VERIFY_CERTIFICATE}")
        perle_cloud_services = PerleCloudServices(
            router_id, router_uri, cloud_uri, False
        )
        try:
            perle_cloud_services.run()
        except RegistrationError as ex:
            log.error(f"Device registration failed: {ex}")
        except Exception as ex:
            log.error("UNKNOWN EXCEPTION: " + "".join(traceback.format_exception(ex)))
            sys.exit(1)
        finally:
            perle_cloud_services.shutdown()


if __name__ == "__main__":
    import urllib3
    from urllib3.exceptions import InsecureRequestWarning

    urllib3.disable_warnings(InsecureRequestWarning)
    main()
