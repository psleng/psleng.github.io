class RegisterRouterResponse:
    def __init__(self, secret_password_router_encoded):
        self.secret_password_router_encoded = secret_password_router_encoded
