import json
from datetime import datetime

from igos.vyos_api import VyosRestCommands, VyosAPI
from igos.rest.common import get_cloud_iface, parse_interfaces
from utils import proxy_config
from message import Message


def _get_base_mac(interfaces: list[dict]) -> str:
    """Return the MAC of the cloud-connected interface, empty if cellular."""
    iface, _ = get_cloud_iface(interfaces)
    if iface and iface["mac"] and not iface["name"].startswith("wwan"):
        return iface["mac"].upper()
    return ""


def _get_version_feilds(version_data: str) -> dict:
    fields = {}
    for line in version_data.strip().splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            fields[key.strip()] = value.strip()
    return fields


def _get_formatted_build_date(version_fields: dict):
    raw_build_date = version_fields.get("Built on", "")
    try:
        dt = datetime.strptime(raw_build_date, "%a %d %b %Y %H:%M %Z")
        formatted_build_date = dt.strftime("%Y-%m-%d")
    except ValueError:
        formatted_build_date = raw_build_date
    return formatted_build_date


def get_system_info(message: Message, provider: VyosAPI) -> str:
    version_data: str = provider.call_action(VyosRestCommands.SHOW_VERSION).get(
        "data", ""
    )
    system_name: str = (
        provider.call_action(VyosRestCommands.SHOW_HOST_NAME).get("data", "").strip()
    )

    fields = _get_version_feilds(version_data)
    formatted_build_date = _get_formatted_build_date(fields)

    version = fields.get("Version", "")
    model = fields.get("Hardware model", "")

    ifaces_output = provider.call_action(VyosRestCommands.SHOW_INTERFACES).get(
        "data", ""
    )
    interfaces = parse_interfaces(ifaces_output)
    base_mac = _get_base_mac(interfaces)

    return json.dumps(
        {
            "sysInfo": {
                "systemDescription": "IGOS Router",
                "systemName": system_name,
                "systemLocation": "",
                "systemContact": "",
                "systemHardware": {
                    "model": model,
                    "description": "IGOS Router",
                    "serialNumber": proxy_config.serial_number,
                    "baseMacAddress": base_mac,
                },
                "systemVersions": {
                    "runningSoftwareRelease": version,
                    "runningSoftwareBuildDate": formatted_build_date,
                    "startupSoftwareRelease": version,
                    "startupSoftwareBuildDate": formatted_build_date,
                },
                "systemStatuses": {
                    "systemUpTime": {"systemUpTime": "Unknown"},
                    "systemDateAndTime": "",
                    "startupConfigurationState": "",
                },
            }
        }
    )
