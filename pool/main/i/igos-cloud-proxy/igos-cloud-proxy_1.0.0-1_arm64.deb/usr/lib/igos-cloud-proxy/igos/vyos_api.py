import time
import requests
import json
from typing import Any

from utils import Logger
from utils.constants import PerleConstants


class Action:
    def __init__(self, cmd: dict[str, Any], endpoint: str) -> None:
        self._cmd: str = json.dumps(cmd)
        self._endpoint: str = endpoint

    @property
    def endpoint(self) -> str:
        return self._endpoint

    @property
    def cmd(self) -> str:
        return self._cmd


class VyosRestCommands:
    SHOW_CONFIG = Action({"op": "show", "path": ["config"]}, "/show")
    SHOW_VERSION = Action({"op": "show", "path": ["version"]}, "/show")
    SHOW_MEMORY = Action({"op": "show", "path": ["system", "memory"]}, "/show")
    SHOW_STORAGE = Action({"op": "show", "path": ["system", "storage"]}, "/show")
    SHOW_LOG = Action({"op": "show", "path": ["log"]}, "/show")
    SHOW_HOST_NAME = Action({"op": "show", "path": ["host", "name"]}, "/show")
    SHOW_INTERFACES = Action({"op": "show", "path": ["interfaces"]}, "/show")
    SHOW_IP_ROUTE_DEFAULT = Action(
        {"op": "show", "path": ["ip", "route", "0.0.0.0/0"]}, "/show"
    )
    SHOW_SNMP_LOCATION = Action(
        {"op": "showConfig", "path": ["service", "snmp", "location"]}, "/retrieve"
    )
    SHOW_SNMP_CONTACT = Action(
        {"op": "showConfig", "path": ["service", "snmp", "contact"]}, "/retrieve"
    )


class VyosAPI:
    CACHE_TTL = 15  # seconds

    def __init__(self, api_key: str):
        self._api_key = api_key
        self._log = Logger()
        self._cache: dict[str, tuple[float, Any]] = {}
        self._session = requests.Session()

    def call(self, cmd: str, endpoint: str):
        cache_key = f"{endpoint}:{cmd}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            ts, result = cached
            if time.time() - ts < self.CACHE_TTL:
                self._log.debug(
                    f"<{self.__class__.__name__}>.call: cache hit for {endpoint}, "
                    f"age={time.time() - ts:.1f}s"
                )
                return result

        url = PerleConstants.DEFAULT_ROUTER_URI_REST + endpoint
        payload = {"data": cmd, "key": self._api_key}
        headers = {}

        self._log.debug(f"<{self.__class__.__name__}>.call: POST {url}, cmd={cmd}")
        start = time.time()
        try:
            res = self._session.post(
                url,
                data=payload,
                headers=headers,
                verify=PerleConstants.PROXY_VERIFY_CERTIFICATE,
            )
            elapsed_ms = (time.time() - start) * 1000
            self._log.debug(
                f"<{self.__class__.__name__}>.call: status={res.status_code}, "
                f"elapsed={elapsed_ms:.1f}ms, url={url}"
            )
            result = res.json()
            self._cache[cache_key] = (time.time(), result)
            return result
        except Exception as ex:
            elapsed_ms = (time.time() - start) * 1000
            self._log.debug(
                f"<{self.__class__.__name__}>.call FAILED: {type(ex).__name__}: {ex}, "
                f"elapsed={elapsed_ms:.1f}ms, url={url}"
            )
            raise

    def call_action(self, action: Action):
        return self.call(action.cmd, action.endpoint)
