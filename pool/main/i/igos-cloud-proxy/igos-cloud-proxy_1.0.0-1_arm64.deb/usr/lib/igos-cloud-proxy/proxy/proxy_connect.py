from command import Command


class ProxyConnect(Command):
    def __init__(
        self,
        proxyUri,
        proxyConnections,
        proxyCookie,
        proxyId,
        inactivityTimeout=None,
        sessionTimeout=None,
        **kwargs
    ):
        """Represents a PROXY_CONNECT request from GUI.

        The GUI now sends the timeout fields without the "proxy" prefix.  We still
        ignore any unexpected keys for forward compatibility.
        """
        super().__init__()
        self.proxy_connections = proxyConnections
        self.proxy_uri = proxyUri
        self.proxy_cookie = proxyCookie
        self.proxy_id = proxyId
        # use unprefixed fields; kwargs catch extras
        self.proxy_inactivityTimeout = inactivityTimeout
        self.proxy_sessionTimeout = sessionTimeout
