import base64

import requests

from .proxy_constants import ProxyConstants
from message import HttpHost


class HeaderPair:
    def __init__(self, name, value):
        self.name = name
        self.value = value

    def to_dict(self):
        return {"name": self.name, "value": self.value}


class HttpTransferData:
    @staticmethod
    def get_header_value(header_name, headers):
        for header in headers:
            if header["name"] == header_name:
                return header["value"]
        return None

    @staticmethod
    def get_content_length(header_value):
        try:
            return int(header_value)
        except (ValueError, TypeError):
            return None

    def __init__(self):
        self.content_bytes = b""
        self.headers = []
        self.cookies = []
        self.host_name = None
        self.port = 0
        self.scheme = None
        self.target_host = None

    def set_target_host(self, target_host):
        self.target_host = target_host

    def set_content_bytes(self, content):
        self.content_bytes = content

    def add_header(self, header_pair):
        self.headers.append(header_pair)

    def get_headers(self):
        return self.headers

    def get_content_bytes(self):
        return self.content_bytes

    @property
    def target_host(self):
        return HttpHost(self.host_name, self.port, self.scheme)

    @target_host.setter
    def target_host(self, value):
        self._target_host = value


def convert_headers_to_dict(headers):
    headers_dict = {}
    referer_index = -1
    for i, header in enumerate(headers):
        headers_dict[header["name"]] = header["value"]
        if header["name"] == "referer":
            referer_index = i
    return headers_dict, referer_index


class ProxyData:
    def __init__(self, proxy_request_uri, request_id, proxy_id):
        self.request_id = request_id
        self.proxy_id = proxy_id
        self.request_method = ""
        self.forward_header = ""
        self.proto_header = ""
        self.proxy_request_uri = proxy_request_uri
        self.error_message = ""
        self.payload = HttpTransferData()
        self.error_code = ""

    def new_proxy_request(self, session_id):
        headers = self.payload.get_headers()
        headers, referer_index = convert_headers_to_dict(headers)

        content_length_header = HttpTransferData.get_header_value(
            "content-length", self.payload.get_headers()
        )
        transfer_encoding_header = HttpTransferData.get_header_value(
            "transfer-encoding", self.payload.get_headers()
        )

        if content_length_header or transfer_encoding_header:
            content = self.payload.content_bytes
            if isinstance(content, str):
                content = content.encode("utf-8", errors="ignore")

            try:
                content_bytes = base64.b64decode(content)
            except Exception:
                content_bytes = b""

            if session_id:
                try:
                    text = content_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    # can't decode, leave payload alone
                    pass
                else:
                    text = text.replace("undefined", session_id)
                    content_bytes = text.encode("utf-8")

            proxy_request = requests.Request(
                method=self.request_method,
                url=self.proxy_request_uri,
                data=content_bytes,
                headers=headers,
            )
        else:
            proxy_request = requests.Request(
                method=self.request_method,
                url=self.proxy_request_uri,
                headers=headers,
            )
        return proxy_request

    def set_request_headers(self, proxy_request, do_handle_compression):
        for header_pair in self.payload.get_headers():
            self.copy_request_header(proxy_request, header_pair, do_handle_compression)

    @staticmethod
    def copy_request_header(proxy_request, header_pair, do_handle_compression):
        if header_pair.name.lower() == "content-length":
            return
        if header_pair.name.lower() in ProxyConstants.hop_by_hop_headers:
            return
        if do_handle_compression and header_pair.name.lower() == "accept-encoding":
            return

        header_value = header_pair.value
        proxy_request.headers[header_pair.name] = header_value

    def set_x_forwarded_for_header(self, proxy_request, forward_ip):
        if forward_ip:
            proxy_request.headers[ProxyConstants.for_header_name] = self.forward_header
            proxy_request.headers[ProxyConstants.proto_header_name] = self.proto_header

    def set_target_host(self, target_host):
        self.payload.set_target_host(target_host)

    def set_content_bytes(self, content):
        self.payload.set_content_bytes(content)

    def add_headers(self, header_pair):
        self.payload.add_header(header_pair)

    def set_error_message(self, error_message):
        self.error_message = error_message

    def get_proxy_id(self):
        return self.proxy_id

    def get_target_host(self):
        return self.payload.target_host

    def set_error_code(self, error_code):
        self.error_code = error_code
