import json


class RegisterRouterCommand:
    def __init__(self, device_secret_uid=None, code=None):
        self.deviceSecretUID = device_secret_uid
        self.code = code

    def to_json(self):
        return json.dumps({"deviceSecretUID": self.deviceSecretUID, "code": self.code})

    def __eq__(self, other):
        if not isinstance(other, RegisterRouterCommand):
            return False
        return self.deviceSecretUID == other.deviceSecretUID and self.code == other.code

    def __hash__(self):
        return hash((self.deviceSecretUID, self.code))
