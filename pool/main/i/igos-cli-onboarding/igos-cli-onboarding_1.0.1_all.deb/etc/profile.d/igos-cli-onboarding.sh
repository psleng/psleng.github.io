#!/bin/sh
ONBOARDING_DIR=/usr/libexec/igos-cli-onboarding
if [ -x "$ONBOARDING_DIR/igos-cli-onboarding.sh" ]; then
    (cd "$ONBOARDING_DIR" && ./igos-cli-onboarding.sh)
fi
