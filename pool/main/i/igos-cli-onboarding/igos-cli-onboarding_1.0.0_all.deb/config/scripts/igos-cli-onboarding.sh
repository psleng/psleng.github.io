#!/bin/vbash
# Initial setup wizard for iGOS.
# Prompts the user for timezone, optional date/time, and local login password
# whenever the active configuration does not contain system time-zone.

TIMEDATECTL="${TIMEDATECTL:-timedatectl}"
PYTHON="${PYTHON:-/usr/bin/python3}"
ONBOARDING_SCRIPTS_DIR="${ONBOARDING_SCRIPTS_DIR:-/usr/share/vyos-custom-queries/scripts}"
ONBOARDING_QUERY_SCRIPT="${ONBOARDING_QUERY_SCRIPT:-${ONBOARDING_SCRIPTS_DIR}/perle_igos_onboarding_query.py}"
ONBOARDING_MUTATION_SCRIPT="${ONBOARDING_MUTATION_SCRIPT:-${ONBOARDING_SCRIPTS_DIR}/perle_igos_onboarding_mutation.py}"
SETUP_DELAY="${SETUP_DELAY:-2}"

# Onboarding is mandatory until system time-zone has been configured. Ignore
# Ctrl-C so it cannot return the user to the CLI with setup incomplete.
trap '' INT

# The Python query is the source of truth for whether onboarding is required.
if [[ ! -r "$ONBOARDING_QUERY_SCRIPT" || ! -r "$ONBOARDING_MUTATION_SCRIPT" ]]; then
    echo "Error: iGOS onboarding Python scripts are not installed." >&2
    exit 1
fi

"$PYTHON" "$ONBOARDING_QUERY_SCRIPT" --cli-required
QUERY_STATUS=$?
case "$QUERY_STATUS" in
    0)
        ;;
    1)
        exit 0
        ;;
    *)
        echo "Error: unable to determine whether iGOS onboarding is required." >&2
        exit 1
        ;;
esac

# Wait for the console to settle before printing the prompt
sleep "$SETUP_DELAY"

echo
echo "========================================="
echo "  iGOS First-Time Setup"
echo "========================================="
echo "  This wizard will guide you through the"
echo "  initial device configuration."
echo "========================================="
echo

# Prompt for a non-negative integer with a default value.
prompt_int_default() {
    local prompt="$1"
    local default_val="$2"
    local input_val

    while true; do
        read -r -p "$prompt [$default_val]: " input_val
        if [ -z "$input_val" ]; then
            echo "$default_val"
            return
        fi

        if [[ "$input_val" =~ ^[0-9]+$ ]]; then
            echo "$input_val"
            return
        fi

        echo "  Please enter a valid non-negative integer." >&2
    done
}

list_timezones() {
    printf '%s\n' "$AVAILABLE_TIMEZONES"
}

timezone_is_valid() {
    grep -Fxq -- "$1" <<< "$AVAILABLE_TIMEZONES"
}

validate_enhanced_password() {
    local password="$1"
    local uppercase_chars="${password//[^A-Z]/}"
    local digit_chars="${password//[^0-9]/}"
    local special_chars="${password//[[:alnum:]]/}"
    local valid=true

    if (( ${#password} < MIN_LENGTH )); then
        echo "  Password must contain at least $MIN_LENGTH characters."
        valid=false
    fi
    if (( ${#uppercase_chars} < MIN_UPPERCASE )); then
        echo "  Password must contain at least $MIN_UPPERCASE uppercase character(s)."
        valid=false
    fi
    if (( ${#digit_chars} < MIN_DIGIT )); then
        echo "  Password must contain at least $MIN_DIGIT digit character(s)."
        valid=false
    fi
    if (( ${#special_chars} < MIN_SPECIAL )); then
        echo "  Password must contain at least $MIN_SPECIAL special character(s)."
        valid=false
    fi

    $valid
}

# ---------------------------------------------------------------------------
# Step 1: Timezone
# ---------------------------------------------------------------------------
echo "Step 1 of 4: Timezone"
echo "  Common examples:"
echo "    America/Toronto   America/New_York   America/Los_Angeles"
echo "    Europe/London     Europe/Paris       Asia/Tokyo"
echo "    UTC"
echo "  Enter ? to list all available timezones."
echo

if ! AVAILABLE_TIMEZONES=$("$TIMEDATECTL" list-timezones --no-pager); then
    echo "  Error: unable to retrieve the available timezones."
    exit 1
fi

while true; do
    read -r -p "  Enter timezone: " TIMEZONE

    if [ "$TIMEZONE" = "?" ]; then
        echo
        list_timezones
        echo
        continue
    fi

    if timezone_is_valid "$TIMEZONE"; then
        break
    fi

    echo "  Invalid timezone. Enter ? to list all available timezones."
done

# ---------------------------------------------------------------------------
# Step 2: Date and time (optional)
# ---------------------------------------------------------------------------
echo
echo "Step 2 of 4: Date and time (optional)"
echo "  You can skip this and set the time later via NTP or the system page."
echo

read -r -p "  Set system date/time now? [y/N]: " SET_TIME
if [[ "$SET_TIME" =~ ^[Yy]$ ]]; then
    while true; do
        read -r -p "  Enter date/time (YYYY-MM-DD HH:MM:SS): " DT
        if [ -n "$DT" ]; then
            break
        fi
        echo "  Date/time cannot be empty if you chose to set it."
    done
fi

# ---------------------------------------------------------------------------
# Step 3: Enhanced password policy (optional)
# ---------------------------------------------------------------------------
echo
echo "Step 3 of 4: Enhanced password policy (optional)"
echo "  Enable this to enforce stronger password requirements for local logins."
echo

ENHANCED_POLICY=false
MIN_LENGTH=9
MIN_UPPERCASE=1
MIN_DIGIT=1
MIN_SPECIAL=1

read -r -p "  Use enhanced password policy? [y/N]: " USE_ENHANCED
if [[ "$USE_ENHANCED" =~ ^[Yy]$ ]]; then
    ENHANCED_POLICY=true

    MIN_LENGTH=$(prompt_int_default "  Minimum password length" "9")
    MIN_UPPERCASE=$(prompt_int_default "  Minimum uppercase characters" "1")
    MIN_DIGIT=$(prompt_int_default "  Minimum digit characters" "1")
    MIN_SPECIAL=$(prompt_int_default "  Minimum special characters" "1")
fi

# ---------------------------------------------------------------------------
# Step 4: Local login password
# ---------------------------------------------------------------------------
echo
echo "Step 4 of 4: Local login password"
echo "  This will update the password for the current admin user (igos)."
echo

while true; do
    read -r -s -p "  Enter new password: " PASS1
    echo

    if [ -z "$PASS1" ]; then
        echo "  Password cannot be empty. Please try again."
        continue
    fi

    if [[ "$ENHANCED_POLICY" == true ]] && ! validate_enhanced_password "$PASS1"; then
        echo "  Password does not satisfy the enhanced policy. Please try again."
        continue
    fi

    read -r -s -p "  Confirm the new password: " PASS2
    echo

    if [ "$PASS1" != "$PASS2" ]; then
        echo "  Passwords do not match. Please try again."
        continue
    fi

    break
done

# ---------------------------------------------------------------------------
# Apply configuration through the shared Python onboarding mutation
# ---------------------------------------------------------------------------
echo
echo "  Applying initial configuration..."

MUTATION_ARGS=(
    "$PYTHON"
    "$ONBOARDING_MUTATION_SCRIPT"
    --cli
    --timezone "$TIMEZONE"
)

if [[ -n "${DT:-}" ]]; then
    MUTATION_ARGS+=(--date-time "$DT")
fi

if [[ "$ENHANCED_POLICY" == true ]]; then
    MUTATION_ARGS+=(
        --enhanced-policy
        --minimum-length "$MIN_LENGTH"
        --minimum-uppercase "$MIN_UPPERCASE"
        --minimum-digit "$MIN_DIGIT"
        --minimum-special "$MIN_SPECIAL"
    )
fi

if ! printf '%s' "$PASS1" | "${MUTATION_ARGS[@]}"; then
    echo "  Error: unable to complete iGOS onboarding."
    exit 1
fi

echo
echo "========================================="
echo "  Initial setup complete."
echo "  Timezone : $TIMEZONE"
echo "========================================="
echo
