#!/bin/sh
[ -f /config/scripts/igos-cli-onboarding.sh ] && /config/scripts/igos-cli-onboarding.sh
