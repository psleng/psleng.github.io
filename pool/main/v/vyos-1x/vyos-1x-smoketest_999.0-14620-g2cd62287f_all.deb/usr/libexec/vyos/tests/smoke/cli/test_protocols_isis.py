#!/usr/bin/env python3
#
# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import unittest

from base_vyostest_shim import VyOSUnitTestSHIM

from vyos.configsession import ConfigSessionError
from vyos.ifconfig import Section
from vyos.utils.process import process_named_running
from vyos.frrender import isis_daemon

base_path = ['protocols', 'isis']
domain = 'VyOS'
net = '49.0001.1921.6800.1002.00'

class TestProtocolsISIS(VyOSUnitTestSHIM.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._interfaces = Section.interfaces('ethernet')
        # call base-classes classmethod
        super(TestProtocolsISIS, cls).setUpClass()
        # Retrieve FRR daemon PID - it is not allowed to crash, thus PID must remain the same
        cls.daemon_pid = process_named_running(isis_daemon)
        # ensure we can also run this test on a live system - so lets clean
        # out the current configuration :)
        cls.cli_delete(cls, base_path)
        cls.cli_delete(cls, ['vrf'])

    def tearDown(self):
        # cleanup any possible VRF mess
        self.cli_delete(['vrf'])
        # always destrox the entire isisd configuration to make the processes
        # life as hard as possible
        self.cli_delete(base_path)
        self.cli_commit()

        # check process health and continuity
        self.assertEqual(self.daemon_pid, process_named_running(isis_daemon))
        # always forward to base class
        super().tearDown()

    def test_isis_01_redistribute(self):
        prefix_list = 'EXPORT-ISIS'
        route_map = 'EXPORT-ISIS'
        rule = '10'
        metric_style = 'transition'
        redistribute = ['babel', 'bgp', 'connected', 'kernel', 'nhrp', 'ospf', 'rip', 'static']
        self.cli_set(['policy', 'prefix-list', prefix_list, 'rule', rule, 'action', 'permit'])
        self.cli_set(['policy', 'prefix-list', prefix_list, 'rule', rule, 'prefix', '203.0.113.0/24'])
        self.cli_set(['policy', 'route-map', route_map, 'rule', rule, 'action', 'permit'])
        self.cli_set(['policy', 'route-map', route_map, 'rule', rule, 'match', 'ip', 'address', 'prefix-list', prefix_list])

        self.cli_set(base_path)

        # verify() - net id and interface are mandatory
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()

        self.cli_set(base_path + ['net', net])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface])

        self.cli_set(base_path + ['redistribute', 'ipv4', 'connected'])
        # verify() - Redistribute level-1 or level-2 should be specified
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()

        for proto in redistribute:
            self.cli_set(base_path + ['redistribute', 'ipv4', proto, 'level-2', 'route-map', route_map])

        self.cli_set(base_path + ['metric-style', metric_style])
        self.cli_set(base_path + ['log-adjacency-changes'])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' metric-style {metric_style}', tmp)
        self.assertIn(f' log-adjacency-changes', tmp)
        for proto in redistribute:
            self.assertIn(f' redistribute ipv4 {proto} level-2 route-map {route_map}', tmp)

        for interface in self._interfaces:
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f' ip router isis {domain}', tmp)
            self.assertIn(f' ipv6 router isis {domain}', tmp)

        self.cli_delete(['policy', 'route-map', route_map])
        self.cli_delete(['policy', 'prefix-list', prefix_list])

    def test_isis_02_vrfs(self):
        vrfs = ['red', 'green', 'blue']
        # It is safe to assume that when the basic VRF test works, all other
        # IS-IS related features work, as we entirely inherit the CLI templates
        # and Jinja2 FRR template.
        table = '1000'
        vrf = 'red'
        vrf_base = ['vrf', 'name', vrf]
        vrf_iface = 'eth1'
        self.cli_set(vrf_base + ['table', table])
        self.cli_set(vrf_base + ['protocols', 'isis', 'net', net])
        self.cli_set(vrf_base + ['protocols', 'isis', 'interface', vrf_iface])
        self.cli_set(vrf_base + ['protocols', 'isis', 'advertise-high-metrics'])
        self.cli_set(vrf_base + ['protocols', 'isis', 'advertise-passive-only'])
        self.cli_set(['interfaces', 'ethernet', vrf_iface, 'vrf', vrf])

        # Also set a default VRF IS-IS config
        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', 'eth0'])
        self.cli_commit()

        # Verify FRR isisd configuration
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f'router isis {domain}', tmp)
        self.assertIn(f' net {net}', tmp)

        tmp = self.getFRRconfig(f'router isis {domain} vrf {vrf}', stop_section='^exit')
        self.assertIn(f'router isis {domain} vrf {vrf}', tmp)
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' advertise-high-metrics', tmp)
        self.assertIn(f' advertise-passive-only', tmp)

        self.cli_delete(['vrf', 'name', vrf])
        self.cli_delete(['interfaces', 'ethernet', vrf_iface, 'vrf'])

    def test_isis_04_default_information(self):
        metric = '50'
        route_map = 'default-foo-'

        self.cli_set(base_path + ['net', net])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface])

        for afi in ['ipv4', 'ipv6']:
            for level in ['level-1', 'level-2']:
                self.cli_set(base_path + ['default-information', 'originate', afi, level, 'always'])
                self.cli_set(base_path + ['default-information', 'originate', afi, level, 'metric', metric])
                self.cli_set(base_path + ['default-information', 'originate', afi, level, 'route-map', route_map + level + afi])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)

        for afi in ['ipv4', 'ipv6']:
            for level in ['level-1', 'level-2']:
                route_map_name = route_map + level + afi
                self.assertIn(f' default-information originate {afi} {level} always route-map {route_map_name} metric {metric}', tmp)

    def test_isis_05_password(self):
        password = 'foo'
        md5_password = 'secret_md5_hash'

        self.cli_set(base_path + ['net', net])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface, 'password', 'plaintext-password', f'{password}-{interface}'])

        self.cli_set(base_path + ['area-password', 'plaintext-password', password])
        self.cli_set(base_path + ['area-password', 'md5', password])
        self.cli_set(base_path + ['domain-password', 'plaintext-password', password])
        self.cli_set(base_path + ['domain-password', 'md5', password])

        # verify() - can not use both md5 and plaintext-password for area-password
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()
        self.cli_delete(base_path + ['area-password', 'md5', password])

        # verify() - can not use both md5 and plaintext-password for domain-password
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()
        self.cli_delete(base_path + ['domain-password', 'md5', password])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' domain-password clear {password}', tmp)
        self.assertIn(f' area-password clear {password}', tmp)

        for interface in self._interfaces:
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f' isis password clear {password}-{interface}', tmp)

        # Switch to MD5 passwords - delete plaintext passwords first
        self.cli_delete(base_path + ['area-password', 'plaintext-password'])
        self.cli_delete(base_path + ['domain-password', 'plaintext-password'])
        for interface in self._interfaces:
            self.cli_delete(base_path + ['interface', interface, 'password', 'plaintext-password'])

        self.cli_set(base_path + ['domain-password', 'md5', md5_password])
        self.cli_set(base_path + ['area-password', 'md5', md5_password])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface, 'password', 'md5', md5_password])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='exit')
        self.assertIn(f' domain-password md5 {md5_password}', tmp)
        self.assertIn(f' area-password md5 {md5_password}', tmp)

        for interface in self._interfaces:
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f' isis password md5 {md5_password}', tmp)

    def test_isis_06_spf_delay_bfd(self):
        network = 'point-to-point'
        holddown = '10'
        init_delay = '50'
        long_delay = '200'
        short_delay = '100'
        time_to_learn = '75'
        bfd_profile = 'isis-bfd'

        self.cli_set(base_path + ['net', net])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface, 'network', network])
            self.cli_set(base_path + ['interface', interface, 'bfd', 'profile', bfd_profile])

        self.cli_set(base_path + ['spf-delay-ietf', 'holddown', holddown])
        # verify() - All types of spf-delay must be configured
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()

        self.cli_set(base_path + ['spf-delay-ietf', 'init-delay', init_delay])
        # verify() - All types of spf-delay must be configured
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()

        self.cli_set(base_path + ['spf-delay-ietf', 'long-delay', long_delay])
        # verify() - All types of spf-delay must be configured
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()

        self.cli_set(base_path + ['spf-delay-ietf', 'short-delay', short_delay])
        # verify() - All types of spf-delay must be configured
        with self.assertRaises(ConfigSessionError):
            self.cli_commit()
        self.cli_set(base_path + ['spf-delay-ietf', 'time-to-learn', time_to_learn])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' spf-delay-ietf init-delay {init_delay} short-delay {short_delay} long-delay {long_delay} holddown {holddown} time-to-learn {time_to_learn}', tmp)

        for interface in self._interfaces:
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f' ip router isis {domain}', tmp)
            self.assertIn(f' ipv6 router isis {domain}', tmp)
            self.assertIn(f' isis network {network}', tmp)
            self.assertIn(f' isis bfd', tmp)
            self.assertIn(f' isis bfd profile {bfd_profile}', tmp)

    def test_isis_07_segment_routing_configuration(self):
        global_block_low = "300"
        global_block_high = "399"
        local_block_low = "400"
        local_block_high = "499"
        maximum_stack_size = '5'
        prefix_one = '192.168.0.1/32'
        prefix_two = '192.168.0.2/32'
        prefix_three = '192.168.0.3/32'
        prefix_four = '192.168.0.4/32'
        prefix_one_value = '1'
        prefix_two_value = '2'
        prefix_three_value = '60000'
        prefix_four_value = '65000'

        self.cli_set(base_path + ['net', net])
        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface])

        self.cli_set(base_path + ['segment-routing', 'maximum-label-depth', maximum_stack_size])
        self.cli_set(base_path + ['segment-routing', 'global-block', 'low-label-value', global_block_low])
        self.cli_set(base_path + ['segment-routing', 'global-block', 'high-label-value', global_block_high])
        self.cli_set(base_path + ['segment-routing', 'local-block', 'low-label-value', local_block_low])
        self.cli_set(base_path + ['segment-routing', 'local-block', 'high-label-value', local_block_high])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_one, 'index', 'value', prefix_one_value])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_one, 'index', 'explicit-null'])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_two, 'index', 'value', prefix_two_value])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_two, 'index', 'no-php-flag'])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_three, 'absolute', 'value',  prefix_three_value])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_three, 'absolute', 'explicit-null'])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_four, 'absolute', 'value', prefix_four_value])
        self.cli_set(base_path + ['segment-routing', 'prefix', prefix_four, 'absolute', 'no-php-flag'])

        # Commit all changes
        self.cli_commit()

        # Verify all changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' segment-routing on', tmp)
        self.assertIn(f' segment-routing global-block {global_block_low} {global_block_high} local-block {local_block_low} {local_block_high}', tmp)
        self.assertIn(f' segment-routing node-msd {maximum_stack_size}', tmp)
        self.assertIn(f' segment-routing prefix {prefix_one} index {prefix_one_value} explicit-null', tmp)
        self.assertIn(f' segment-routing prefix {prefix_two} index {prefix_two_value} no-php-flag', tmp)
        self.assertIn(f' segment-routing prefix {prefix_three} absolute {prefix_three_value} explicit-null', tmp)
        self.assertIn(f' segment-routing prefix {prefix_four} absolute {prefix_four_value} no-php-flag', tmp)

    def test_isis_08_ldp_sync(self):
        holddown = "500"
        interface = 'lo'

        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        self.cli_set(base_path + ['ldp-sync', 'holddown', holddown])

        # Commit main ISIS changes
        self.cli_commit()

        # Verify main ISIS changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' mpls ldp-sync', tmp)
        self.assertIn(f' mpls ldp-sync holddown {holddown}', tmp)

        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface, 'ldp-sync', 'holddown', holddown])

        # Commit interface changes for holddown
        self.cli_commit()

        for interface in self._interfaces:
            # Verify interface changes for holddown
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f'interface {interface}', tmp)
            self.assertIn(f' ip router isis {domain}', tmp)
            self.assertIn(f' ipv6 router isis {domain}', tmp)
            self.assertIn(f' isis mpls ldp-sync holddown {holddown}', tmp)

        for interface in self._interfaces:
            self.cli_set(base_path + ['interface', interface, 'ldp-sync', 'disable'])

        # Commit interface changes for disable
        self.cli_commit()

        for interface in self._interfaces:
            # Verify interface changes for disable
            tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
            self.assertIn(f'interface {interface}', tmp)
            self.assertIn(f' ip router isis {domain}', tmp)
            self.assertIn(f' ipv6 router isis {domain}', tmp)
            self.assertIn(f' no isis mpls ldp-sync', tmp)

    def test_isis_09_lfa(self):
        prefix_list = 'lfa-prefix-list-test-1'
        prefix_list_address = '192.168.255.255/32'
        interface = 'lo'

        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        self.cli_set(['policy', 'prefix-list', prefix_list, 'rule', '1', 'action', 'permit'])
        self.cli_set(['policy', 'prefix-list', prefix_list, 'rule', '1', 'prefix', prefix_list_address])

        # Commit main ISIS changes
        self.cli_commit()

        # Add remote portion of LFA with prefix list with validation
        for level in ['level-1', 'level-2']:
            self.cli_set(base_path + ['fast-reroute', 'lfa', 'remote', 'prefix-list', prefix_list, level])
            self.cli_commit()
            tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
            self.assertIn(f' net {net}', tmp)
            self.assertIn(f' fast-reroute remote-lfa prefix-list {prefix_list} {level}', tmp)
            self.cli_delete(base_path + ['fast-reroute'])
            self.cli_commit()

        # Add local portion of LFA load-sharing portion with validation
        for level in ['level-1', 'level-2']:
            self.cli_set(base_path + ['fast-reroute', 'lfa', 'local', 'load-sharing', 'disable', level])
            self.cli_commit()
            tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
            self.assertIn(f' net {net}', tmp)
            self.assertIn(f' fast-reroute load-sharing disable {level}', tmp)
            self.cli_delete(base_path + ['fast-reroute'])
            self.cli_commit()

        # Add local portion of LFA priority-limit portion with validation
        for priority in ['critical', 'high', 'medium']:
            for level in ['level-1', 'level-2']:
                self.cli_set(base_path + ['fast-reroute', 'lfa', 'local', 'priority-limit', priority, level])
                self.cli_commit()
                tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
                self.assertIn(f' net {net}', tmp)
                self.assertIn(f' fast-reroute priority-limit {priority} {level}', tmp)
                self.cli_delete(base_path + ['fast-reroute'])
                self.cli_commit()

        # Add local portion of LFA tiebreaker portion with validation
        index = '100'
        for tiebreaker in ['downstream','lowest-backup-metric','node-protecting']:
            for level in ['level-1', 'level-2']:
                self.cli_set(base_path + ['fast-reroute', 'lfa', 'local', 'tiebreaker', tiebreaker, 'index', index, level])
                self.cli_commit()
                tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
                self.assertIn(f' net {net}', tmp)
                self.assertIn(f' fast-reroute lfa tiebreaker {tiebreaker} index {index} {level}', tmp)
                self.cli_delete(base_path + ['fast-reroute'])
                self.cli_commit()

        # Clean up and remove prefix list
        self.cli_delete(['policy', 'prefix-list', prefix_list])
        self.cli_commit()

    def test_isis_10_topology(self):
        topologies = ['ipv4-multicast', 'ipv4-mgmt', 'ipv6-unicast', 'ipv6-multicast', 'ipv6-mgmt']
        interface = 'lo'

        # Set a basic IS-IS config
        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        for topology in topologies:
            self.cli_set(base_path + ['topology', topology])
            self.cli_commit()
            tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
            self.assertIn(f' net {net}', tmp)
            self.assertIn(f' topology {topology}', tmp)

    def test_isis_11_srv6(self):
        locator = "TEST"
        interface = 'lo'
        srv6_iface = 'dum6'

        # The dummy interface used to install SRv6 SIDs in the Linux data plane
        self.cli_set(['interfaces', 'dummy', srv6_iface])

        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        self.cli_set(base_path + ['segment-routing', 'srv6', 'locator', locator])
        self.cli_set(base_path + ['segment-routing', 'srv6', 'interface', srv6_iface])

        # Commit main ISIS changes
        self.cli_commit()

        # Verify main ISIS changes
        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(f' net {net}', tmp)
        self.assertIn(f' segment-routing srv6', tmp)
        self.assertIn(f'  locator {locator}', tmp)

        # Commit for isis
        self.cli_commit()

    def test_isis_12_frr_interface_lfa_remotelfa(self):
        interface = 'eth0'
        rla_metric = '10'
        frr_interface_base_path = base_path + ['interface', interface, 'fast-reroute']
        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        self.cli_set(frr_interface_base_path + ['lfa', 'level-1', 'enable'])
        self.cli_set(frr_interface_base_path + ['lfa', 'level-1', 'exclude',
                                                'interface', interface])
        self.cli_set(frr_interface_base_path + ['remote-lfa', 'level-1',
                                                'maximum-metric', rla_metric])
        self.cli_set(frr_interface_base_path + ['remote-lfa', 'level-1',
                                                'tunnel', 'mpls-ldp'])

        # Commit main ISIS changes
        self.cli_commit()

        # Verify interface ISIS changes
        tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
        self.assertIn(f' isis fast-reroute lfa level-1', tmp)
        self.assertIn(f' isis fast-reroute lfa level-1 exclude interface {interface}', tmp)
        self.assertIn(f' isis fast-reroute remote-lfa maximum-metric {rla_metric} level-1', tmp)
        self.assertIn(f' isis fast-reroute remote-lfa tunnel mpls-ldp level-1', tmp)

    def test_isis_13_frr_interface_tilfa(self):
        interface = 'eth0'
        frr_interface_base_path = base_path + ['interface', interface, 'fast-reroute']
        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', interface])
        self.cli_set(frr_interface_base_path + ['ti-lfa', 'level-1', 'node-protection',
                                                'link-fallback'])

        # Commit main ISIS changes
        self.cli_commit()

        # Verify interface ISIS changes
        tmp = self.getFRRconfig(f'interface {interface}', stop_section='^exit')
        self.assertIn(f' isis fast-reroute ti-lfa level-1 node-protection link-fallback', tmp)

    def test_isis_14_segment_routing_srv6_advanced(self):
        # Configure system SRv6 locator and interface
        locator = 'TEST'
        sr_base = ['protocols', 'segment-routing']
        self.cli_set(sr_base + ['srv6', 'locator', 'TEST', 'prefix', '2001:db8::/64'])
        self.cli_set(sr_base + ['interface', 'lo'])

        # The dummy interface used to install SRv6 SIDs in the Linux data plane
        dum_iface = 'dum6'
        self.cli_set(['interfaces', 'dummy', dum_iface])

        # Set a basic IS-IS config
        self.cli_set(base_path + ['net', net])
        self.cli_set(base_path + ['interface', 'lo'])

        # Configure IS-IS SRv6
        srv6_base_path = base_path + ['segment-routing', 'srv6']
        self.cli_set(srv6_base_path + ['locator', locator])
        self.cli_set(srv6_base_path + ['interface', dum_iface])
        self.cli_commit()

        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn(' segment-routing srv6', tmp)
        self.assertIn(f'  locator {locator}', tmp)
        self.assertIn(f'  interface {dum_iface}', tmp)

        # Test node-msd configuration
        self.cli_set(srv6_base_path + ['node-msd', 'max-end-d', '40'])
        self.cli_set(srv6_base_path + ['node-msd', 'max-end-pop', '50'])
        self.cli_set(srv6_base_path + ['node-msd', 'max-h-encaps', '60'])
        self.cli_set(srv6_base_path + ['node-msd', 'max-segs-left', '70'])
        self.cli_commit()

        tmp = self.getFRRconfig(f'router isis {domain}', stop_section='^exit')
        self.assertIn('  node-msd', tmp)
        self.assertIn('   max-end-d 40', tmp)
        self.assertIn('   max-end-pop 50', tmp)
        self.assertIn('   max-h-encaps 60', tmp)
        self.assertIn('   max-segs-left 70', tmp)


if __name__ == '__main__':
    unittest.main(verbosity=2, failfast=VyOSUnitTestSHIM.TestCase.debug_on())
