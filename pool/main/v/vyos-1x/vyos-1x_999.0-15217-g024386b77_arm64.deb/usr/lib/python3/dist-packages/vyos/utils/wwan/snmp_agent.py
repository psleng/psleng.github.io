#!/usr/bin/env python3
# Copyright (C) 2024-2026 Perle Systems Limited
# SPDX-License-Identifier: GPL-2.0-or-later
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""SNMP pass-persist agent for IGOS-WWAN-MIB.

Implements the read-only object set defined in mibs/IGOS-WWAN-MIB.txt for the
VyOS enhanced WWAN subsystem.  Fetches live status from the WWAN FSM via
:class:`WWANClientSync` and serves SNMP GET/GETNEXT requests on stdin/stdout
using the net-snmp ``pass_persist`` protocol.

Wire-up in /etc/snmp/snmpd.conf::

    pass_persist .1.3.6.1.4.1.1966.30.1  /usr/bin/igos-wwan-snmp-agent

Tables implemented (read-only):

* igosWwanIfTable        (.1.3.6.1.4.1.1966.30.1.1.1.1)
* igosWwanSimTable       (.1.3.6.1.4.1.1966.30.1.1.2.1)
* igosWwanRadioTable     (.1.3.6.1.4.1.1966.30.1.1.3.1)
* igosWwanBearerTable    (.1.3.6.1.4.1.1966.30.1.1.4.1)
* igosWwanFailoverTable  (.1.3.6.1.4.1.1966.30.1.1.5.1)

The PD table is reserved (not yet populated).
"""

from __future__ import annotations

import bisect
import logging
import os
import socket
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

logger = logging.getLogger('vyos.wwan.snmp_agent')


# ── OID layout ──────────────────────────────────────────────────────────────
ROOT = (1, 3, 6, 1, 4, 1, 1966, 30, 1)         # igosWwanMIB ({ igos 1 })
OBJ  = ROOT + (1,)                              # igosWwanObjects

IF_ENTRY       = OBJ + (1, 1, 1)                # .interface.ifTable.entry
SIM_ENTRY      = OBJ + (2, 1, 1)
RADIO_ENTRY    = OBJ + (3, 1, 1)
BEARER_ENTRY   = OBJ + (4, 1, 1)
FAILOVER_ENTRY = OBJ + (5, 1, 1)

# Refresh cadence — guards against snmpwalk hammering D-Bus.
CACHE_TTL_SECONDS = float(os.environ.get('VYOS_WWAN_SNMP_CACHE_TTL', '5'))


# ── Type tags used by net-snmp pass_persist ────────────────────────────────
T_INT       = 'INTEGER'
T_GAUGE     = 'Gauge32'
T_COUNTER64 = 'Counter64'
T_TIMETICKS = 'TimeTicks'
T_STRING    = 'STRING'
T_IPADDR    = 'IPADDRESS'
T_OID       = 'OBJECTID'


# ── Enum mappings (mirror IGOS-WWAN-MIB textual conventions) ───────────────
FSM_STATE_MAP = {
    # MIB IgosWwanFsmState canonical names.
    'unknown': 0, 'disabled': 1, 'initializing': 2, 'sim_ready': 3,
    'registering': 4, 'registered': 5, 'connecting': 6, 'connected': 7,
    'disconnecting': 8, 'failed': 9, 'retry_backoff': 10, 'hardware_reset': 11,
    # Raw ModemState names the FSM publishes in get_status()['fsm_state'],
    # bucketed onto the coarser MIB enum above (shared with snmp_traps).
    'initial': 2, 'scanning': 2, 'modem_found': 2, 'waiting_for_config': 2,
    'configuring': 2, 'waiting_for_sim': 2,
    'registered_idle': 5, 'disconnected': 5,
    'usage_monitoring': 7, 'usage_threshold': 7, 'usage_resetting': 7,
    'sim_switching': 2, 'sim_disconnecting': 8, 'sim_disabling': 2,
    'sim_enabling': 2, 'sim_reconfiguring': 2,
}

RAT_MAP = {
    'unknown': 0, 'gsm': 1, 'gprs': 2, 'edge': 3, 'umts': 4,
    'hspa': 5, 'hspa+': 6, 'hspa_plus': 6, 'lte': 7, 'lte-a': 8,
    'lte_advanced': 8, '5gnr-nsa': 9, 'nr5g_nsa': 9, '5gnr': 10, 'nr5g_sa': 10,
}

REG_STATE_MAP = {
    'unknown': 0, 'idle': 1, 'not-registered': 1, 'searching': 2,
    'home': 3, 'registered': 3, 'roaming': 4, 'denied': 5,
    'emergency': 6,
}

# ModemManager MM_MODEM_3GPP_REGISTRATION_STATE integer -> IgosWwanRegState.
# get_status() publishes the raw MM integer, which the word-keyed REG_STATE_MAP
# above cannot resolve on its own.
MM_3GPP_REG_STATE_TO_MIB = {
    0: REG_STATE_MAP['idle'],       # idle (not registered)
    1: REG_STATE_MAP['home'],       # home
    2: REG_STATE_MAP['searching'],  # searching
    3: REG_STATE_MAP['denied'],     # denied
    4: REG_STATE_MAP['unknown'],    # unknown
    5: REG_STATE_MAP['roaming'],    # roaming
    6: REG_STATE_MAP['home'],       # home (SMS only)
    7: REG_STATE_MAP['roaming'],    # roaming (SMS only)
    8: REG_STATE_MAP['emergency'],  # emergency only
    9: REG_STATE_MAP['home'],       # home (CSFB not preferred)
    10: REG_STATE_MAP['roaming'],   # roaming (CSFB not preferred)
    11: REG_STATE_MAP['unknown'],   # attached RLOS
}

# MM registration states that count as roaming for igosWwanSimRoaming.
MM_3GPP_ROAMING_STATES = {5, 7, 10}

SIM_STATE_MAP = {
    'unknown': 0, 'absent': 1, 'pin-locked': 2, 'puk-locked': 3,
    'ready': 4, 'active': 5, 'disabled': 6, 'error': 7,
}

DATA_LIMIT_ACTION_MAP = {
    'none': 0, 'disable': 1, 'sim-failover': 2, 'sim-failover-sticky': 3,
}

CONNECTION_MODE_MAP = {
    'always-on': 1, 'connect-on-demand': 2, 'dial-on-demand': 3,
}

NETWORK_MODE_MAP = {
    # The MIB's igosWwanIfNetworkMode enumerates only nr5g(3); both the
    # combined '5g' (NSA+SA) and '5g-only' (SA) CLI modes collapse to it.
    'auto': 1,
    'lte': 2,
    '5g': 3,
    '5g-only': 3,
    '5g_only': 3,
    'nr5g': 3,
    '3g': 4,
    'umts': 4,
    '2g': 5,
    'gsm': 5,
}

AUTH_TYPE_MAP = {'none': 1, 'pap': 2, 'chap': 3, 'both': 4}
PDP_TYPE_MAP  = {'ipv4': 1, 'ipv6': 2, 'ipv4v6': 3}

# Failover reason string → code (mirrors IGOS-WWAN-MIB failover reason enum and
# snmp_traps.FAILOVER_REASON_MAP; also covers the FSM's own reason strings).
FAILOVER_REASON_MAP = {
    'none': 0, '': 0,
    'signal-loss': 1, 'signal_loss': 1,
    'registration-lost': 2, 'registration_lost': 2,
    'registration-flap': 3, 'registration_flap': 3,
    'connect-failure': 4, 'connect_failure': 4, 'connectivity_failure': 4,
    'data-limit-reached': 5, 'data_limit_reached': 5, 'usage_limit': 5,
    'data_limit_failover': 5,
    'hardware-error': 6, 'hardware_error': 6,
    'manual': 7, 'manual_switch': 7, 'runtime_slot_change': 7,
    'failback': 8, 'primary-recovered': 8, 'primary_recovered': 8,
    'primary_sim_available': 8, 'failback_to_primary': 8,
    'sim-absent': 9, 'sim_absent': 9, 'sim_missing': 9,
}


def _enum(value: Any, mapping: Dict[str, int], default: int = 0) -> int:
    if value is None:
        return default
    key = str(value).strip().lower().replace(' ', '-')
    return mapping.get(key, mapping.get(key.replace('-', '_'), default))


def _resolve_reg_state(value: Any) -> Tuple[int, bool]:
    """Map registration_state to (IgosWwanRegState, is_roaming).

    get_status() publishes registration_state as the raw ModemManager 3GPP
    integer; a word form ('home'/'roaming') is accepted as a fallback.
    """
    if value is None or value == '':
        return REG_STATE_MAP['unknown'], False
    mm_int: Optional[int] = None
    if isinstance(value, int) and not isinstance(value, bool):
        mm_int = value
    else:
        text = str(value).strip()
        if text.isdigit():
            mm_int = int(text)
    if mm_int is not None:
        return (MM_3GPP_REG_STATE_TO_MIB.get(mm_int, REG_STATE_MAP['unknown']),
                mm_int in MM_3GPP_ROAMING_STATES)
    mib = _enum(value, REG_STATE_MAP, 0)
    return mib, mib == REG_STATE_MAP['roaming']


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _str(value: Any, default: str = '') -> str:
    if value is None:
        return default
    return str(value)


def _bool_truthvalue(value: Any) -> int:
    """SNMPv2-TC TruthValue: true(1), false(2)."""
    return 1 if bool(value) else 2


# ── Interface discovery ────────────────────────────────────────────────────
def _discover_interfaces() -> List[Tuple[int, str, int]]:
    """Return list of (interface_number, ifname, ifIndex) tuples."""
    out: List[Tuple[int, str, int]] = []
    sys_net = Path('/sys/class/net')
    if not sys_net.is_dir():
        return out
    for entry in sorted(sys_net.iterdir()):
        name = entry.name
        if not name.startswith('wwan'):
            continue
        suffix = name[len('wwan'):]
        if not suffix.isdigit():
            continue
        try:
            if_index = socket.if_nametoindex(name)
        except OSError:
            continue
        out.append((int(suffix), name, if_index))
    return out


# ── Status collection ──────────────────────────────────────────────────────
class _StatusFetcher:
    """Fetches per-interface status dicts from the WWAN FSM over D-Bus.

    Result caching is owned one level up by ``PassPersistAgent._refresh_tree``
    (a single TTL gate), so this performs a fresh fetch on every call and keeps
    no snapshot of its own.
    """

    def __init__(self) -> None:
        self._client = None  # lazy

    def _get_client(self):
        if self._client is None:
            from vyos.utils.wwan.wwan_client import WWANClientSync
            self._client = WWANClientSync()
        return self._client

    def get(self) -> Dict[int, Dict[str, Any]]:
        snapshot: Dict[int, Dict[str, Any]] = {}
        try:
            client = self._get_client()
        except Exception as exc:
            # FSM/D-Bus unreachable — drop the client and return an empty
            # snapshot (no rows) so the next refresh reconnects cleanly.
            logger.debug('WWAN client init failed: %s', exc)
            self._client = None
            return snapshot
        for if_num, name, if_index in _discover_interfaces():
            try:
                status = client.get_status(if_num)
            except Exception as exc:
                logger.debug('get_status(%s) failed: %s', if_num, exc)
                # Drop the (possibly stale) client so the next refresh rebuilds
                # the D-Bus connection instead of serving empty tables forever.
                self._client = None
                status = {}
            status.setdefault('_ifname', name)
            status.setdefault('_ifindex', if_index)
            status.setdefault('_interface_number', if_num)
            snapshot[if_index] = status
        return snapshot


# ── OID tree builder ───────────────────────────────────────────────────────
def _now_ts_to_dateandtime(ts: Optional[float]) -> str:
    """Convert a UNIX epoch (or None) to an SNMPv2-TC DateAndTime string.

    pass_persist STRING values are simple ASCII; emit ISO-8601 which most NMS
    tools accept and parse without complaint.
    """
    if not ts:
        return ''
    try:
        return time.strftime('%Y-%m-%dT%H:%M:%S%z', time.localtime(float(ts)))
    except (TypeError, ValueError):
        return ''


def _build_if_row(if_index: int, st: Dict[str, Any]) -> Iterable[Tuple[Tuple[int, ...], str, str]]:
    base = IF_ENTRY
    primary = _int(st.get('configured_sim_slot'), 1)
    active  = _int(st.get('active_sim_slot'), primary)
    sticky  = bool(st.get('failback_suppressed_by_connection_failure', False))

    yield base + (1, if_index),  T_INT,    str(_enum(st.get('fsm_state'), FSM_STATE_MAP))
    yield base + (2, if_index),  T_STRING, _str(st.get('modem_manufacturer'))
    yield base + (3, if_index),  T_STRING, _str(st.get('modem_model'))
    yield base + (4, if_index),  T_STRING, _str(st.get('modem_firmware') or st.get('modem_firmware_revision'))
    yield base + (5, if_index),  T_STRING, _str(st.get('modem_hardware_revision'))
    yield base + (6, if_index),  T_STRING, _str(st.get('modem_imei'))
    yield base + (7, if_index),  T_INT,    str(primary or 1)
    yield base + (8, if_index),  T_INT,    str(active or primary or 1)
    yield base + (9, if_index),  T_INT,    str(_bool_truthvalue(sticky))
    yield base + (10, if_index), T_INT,    str(_enum(st.get('connection_mode'), CONNECTION_MODE_MAP, 1))
    yield base + (11, if_index), T_INT,    str(_enum(st.get('network_mode'), NETWORK_MODE_MAP, 1))
    yield base + (12, if_index), T_INT,    str(_int(st.get('mtu'), 1420))
    yield base + (13, if_index), T_TIMETICKS, str(_int(st.get('fsm_state_uptime_seconds'), 0) * 100)
    yield base + (14, if_index), T_STRING, _now_ts_to_dateandtime(st.get('last_event_time'))
    yield base + (15, if_index), T_STRING, _str(st.get('last_event_description'))


def _build_sim_rows(if_index: int, st: Dict[str, Any]) -> Iterable[Tuple[Tuple[int, ...], str, str]]:
    base = SIM_ENTRY
    active = _int(st.get('active_sim_slot'))
    for slot in (1, 2):
        present = bool(st.get(f'sim_slot_{slot}_present', False))
        is_active = (slot == active and active != 0)
        # Field 1 (slot) is the index — not emitted as a value.
        # State: prefer dedicated per-slot if present, else infer from active slot.
        slot_state_raw = st.get(f'sim_slot_{slot}_state')
        if slot_state_raw:
            sim_state = _enum(slot_state_raw, SIM_STATE_MAP, 0)
        elif not present:
            sim_state = SIM_STATE_MAP['absent']
        elif is_active:
            sim_state = SIM_STATE_MAP['active']
        else:
            sim_state = SIM_STATE_MAP['ready']

        if is_active:
            iccid = _str(st.get('sim_iccid')) or _str(st.get(f'sim_slot_{slot}_iccid'))
            imsi  = _str(st.get('sim_imsi'))  or _str(st.get(f'sim_slot_{slot}_imsi'))
            opname = _str(st.get('operator_name')) or _str(st.get(f'sim_slot_{slot}_operator'))
            opcode = _str(st.get('operator_code')) or _str(st.get(f'sim_slot_{slot}_mcc_mnc'))
            apn = _str(st.get('connected_apn'))
            reg_state, is_roaming = _resolve_reg_state(st.get('registration_state'))
            roaming = _bool_truthvalue(is_roaming)
        else:
            iccid = _str(st.get(f'sim_slot_{slot}_iccid'))
            imsi  = _str(st.get(f'sim_slot_{slot}_imsi'))
            opname = _str(st.get(f'sim_slot_{slot}_operator'))
            opcode = _str(st.get(f'sim_slot_{slot}_mcc_mnc'))
            apn = ''
            reg_state = REG_STATE_MAP['unknown']
            roaming = _bool_truthvalue(False)

        roaming_allowed = _bool_truthvalue(
            str(st.get(f'sim_slot_{slot}_roaming', 'enabled')).strip().lower() != 'disabled'
        )

        # Data-limit fields: live config exposes only the active slot;
        # inactive slot values fall back to per-slot config keys if present.
        if is_active:
            dl_size   = _int(st.get('data_limit_bytes'), 0)
            dl_action = _enum(st.get('data_limit_action'), DATA_LIMIT_ACTION_MAP, 0)
            dl_billing = _int(st.get('data_limit_billing_date'), 1)
            dl_used_cycle = _int(st.get('cumulative_bytes'), 0)
        else:
            dl_size   = _int(st.get(f'sim_slot_{slot}_data_limit_bytes'), 0)
            dl_action = _enum(st.get(f'sim_slot_{slot}_data_limit_action'), DATA_LIMIT_ACTION_MAP, 0)
            dl_billing = _int(st.get(f'sim_slot_{slot}_data_limit_billing_date'), 1)
            dl_used_cycle = _int(st.get(f'sim_slot_{slot}_cycle_bytes'), 0)
        dl_used_total = _int(st.get(f'sim_slot_{slot}_total_bytes'), dl_used_cycle if is_active else 0)
        if dl_size > 0:
            dl_pct = max(0, min(200, int(round(dl_used_cycle * 100.0 / dl_size))))
        else:
            dl_pct = 0

        idx = (if_index, slot)
        # Column numbers come from IGOS-WWAN-MIB SEQUENCE order (skipping col 1 = INDEX).
        yield base + (2, *idx),  T_INT,       str(sim_state)
        yield base + (3, *idx),  T_INT,       str(_bool_truthvalue(is_active))
        yield base + (4, *idx),  T_STRING,    iccid
        yield base + (5, *idx),  T_STRING,    imsi
        # col 6 (igosWwanSimMsisdn) removed from MIB
        yield base + (7, *idx),  T_STRING,    opcode
        yield base + (8, *idx),  T_STRING,    opname
        yield base + (9, *idx),  T_INT,       str(roaming)
        yield base + (10, *idx), T_INT,       str(roaming_allowed)
        yield base + (11, *idx), T_STRING,    apn
        # col 12 (igosWwanSimApnSource) removed from MIB
        yield base + (13, *idx), T_INT,       str(_enum(st.get(f'sim_slot_{slot}_auth_type'), AUTH_TYPE_MAP, 1))
        yield base + (14, *idx), T_INT,       str(_enum(st.get(f'sim_slot_{slot}_pdp_type'), PDP_TYPE_MAP, 3))
        yield base + (15, *idx), T_INT,       str(reg_state)
        # cols 16-19 (per-slot connect counters/timestamps) removed from MIB
        yield base + (20, *idx), T_STRING,    _str(st.get('last_disconnect_reason') if is_active else st.get(f'sim_slot_{slot}_last_disconnect_cause'))
        yield base + (21, *idx), T_COUNTER64, str(dl_size)
        yield base + (22, *idx), T_INT,       str(dl_action)
        yield base + (23, *idx), T_COUNTER64, str(dl_used_cycle)
        yield base + (24, *idx), T_COUNTER64, str(dl_used_total)
        yield base + (25, *idx), T_INT,       str(dl_billing)
        yield base + (26, *idx), T_INT,       str(dl_pct)


def _build_radio_row(if_index: int, st: Dict[str, Any]) -> Iterable[Tuple[Tuple[int, ...], str, str]]:
    base = RADIO_ENTRY
    bars_pct = _int(st.get('signal_percent'), 0)
    bars = max(0, min(5, int(round(bars_pct / 20.0)))) if bars_pct else 0
    # Serving-cell identity keys are published by the FSM under the
    # ``serving_*`` namespace (serving_cell_id / serving_tac / serving_earfcn /
    # serving_physical_ci).  The earlier short keys (cell_id/tac/earfcn/pci)
    # never existed in the status dict, so these columns silently reported 0.
    # NR-ARFCN shares ``serving_earfcn`` (populated for an NR serving cell);
    # gate it on the serving cell type so it only fills for 5G.
    cell_type = str(st.get('serving_cell_type') or '').lower()
    serving_chan = _int(st.get('serving_earfcn'), 0)
    nr_arfcn = serving_chan if cell_type in ('nr5g', '5gnr') else 0
    earfcn = serving_chan if cell_type not in ('nr5g', '5gnr') else 0
    yield base + (1, if_index), T_INT, str(
        _enum(st.get('access_technology_name') or st.get('signal_technology'), RAT_MAP)
    )
    yield base + (2, if_index), T_STRING, _str(
        st.get('serving_band') or st.get('current_bands') or st.get('active_band')
    )
    yield base + (3, if_index), T_INT, str(bars)
    yield base + (4, if_index), T_INT, str(
        _int(st.get('signal_rssi') or st.get('signal_dbm'), 0)
    )
    yield base + (5, if_index), T_INT, str(_int(st.get('signal_rsrp'), 0))
    yield base + (6, if_index), T_INT, str(_int(st.get('signal_rsrq'), 0))
    yield base + (7, if_index), T_INT, str(
        _int(st.get('signal_snr') or st.get('signal_sinr'), 0)
    )
    yield base + (8, if_index), T_INT, str(_int(st.get('signal_ecio'), 0))
    yield base + (9, if_index), T_GAUGE, str(_int(st.get('serving_cell_id'), 0))
    yield base + (10, if_index), T_INT, str(_int(st.get('serving_physical_ci'), 0))
    yield base + (11, if_index), T_INT, str(
        _int(st.get('serving_tac') or st.get('lac'), 0)
    )
    yield base + (12, if_index), T_INT, str(earfcn)
    yield base + (13, if_index), T_GAUGE, str(nr_arfcn)
    yield base + (14, if_index), T_INT, str(_int(st.get('signal_rscp'), 0))


def _build_bearer_row(if_index: int, st: Dict[str, Any]) -> Iterable[Tuple[Tuple[int, ...], str, str]]:
    base = BEARER_ENTRY
    connected = _enum(st.get('fsm_state'), FSM_STATE_MAP) == FSM_STATE_MAP['connected']
    v4 = _str(st.get('ipv4_address'))
    v6 = _str(st.get('ipv6_address'))
    v4_type = 1 if v4 else 0
    v6_type = 2 if v6 else 0
    # FSM publishes DNS as comma-joined strings (ipv4_dns / ipv6_dns); split
    # into primary/secondary for the two bearer DNS columns (v4 preferred).
    v4_dns = [d.strip() for d in _str(st.get('ipv4_dns')).split(',') if d.strip()]
    v6_dns = [d.strip() for d in _str(st.get('ipv6_dns')).split(',') if d.strip()]
    dns_list = v4_dns or v6_dns
    yield base + (1, if_index),  T_INT,       str(_bool_truthvalue(connected))
    yield base + (2, if_index),  T_INT,       str(v4_type)
    yield base + (3, if_index),  T_STRING,    v4
    yield base + (4, if_index),  T_STRING,    _str(st.get('ipv4_gateway'))
    yield base + (5, if_index),  T_INT,       str(v6_type)
    yield base + (6, if_index),  T_STRING,    v6
    yield base + (7, if_index),  T_INT,       str(_int(st.get('ipv6_prefix_length'), 128 if v6 else 0))
    yield base + (8, if_index),  T_STRING,    _str(st.get('ipv6_gateway'))
    yield base + (9, if_index),  T_STRING,    (dns_list[0] if len(dns_list) > 0 else '')
    yield base + (10, if_index), T_STRING,    (dns_list[1] if len(dns_list) > 1 else '')
    # FSM publishes session duration (seconds since connect), not an absolute
    # connect timestamp -- derive the connect wall-clock from it.
    connect_ts = st.get('last_connect_time')
    if not connect_ts:
        dur = _int(st.get('session_duration_seconds'), 0)
        if connected and dur > 0:
            connect_ts = time.time() - dur
    yield base + (11, if_index), T_STRING,    _now_ts_to_dateandtime(connect_ts)
    yield base + (12, if_index), T_TIMETICKS, str(_int(st.get('session_duration_seconds'), 0) * 100)
    yield base + (13, if_index), T_COUNTER64, str(_int(st.get('session_rx_bytes'), 0))
    yield base + (14, if_index), T_COUNTER64, str(_int(st.get('session_tx_bytes'), 0))


def _build_failover_row(if_index: int, st: Dict[str, Any]) -> Iterable[Tuple[Tuple[int, ...], str, str]]:
    base = FAILOVER_ENTRY
    yield base + (1, if_index),  T_INT,       str(_bool_truthvalue(st.get('sim_failover_enabled', True)))
    yield base + (2, if_index),  T_INT,       str(_bool_truthvalue(st.get('sim_failback_enabled', True)))
    yield base + (3, if_index),  T_INT,       str(_bool_truthvalue(st.get('failover_in_progress', False)))
    yield base + (4, if_index),  T_INT,       str(_int(st.get('last_failover_from_slot'), 0))
    yield base + (5, if_index),  T_INT,       str(_int(st.get('last_failover_to_slot'), 0))
    yield base + (6, if_index),  T_INT,       str(_enum(st.get('last_failover_reason'), FAILOVER_REASON_MAP, 0))
    yield base + (7, if_index),  T_STRING,    _now_ts_to_dateandtime(st.get('last_failover_time'))
    yield base + (8, if_index),  T_COUNTER64, str(_int(st.get('failover_count'), 0))
    yield base + (9, if_index),  T_COUNTER64, str(_int(st.get('failback_count'), 0))
    yield base + (10, if_index), T_INT,       str(_int(st.get('failover_cooldown_remain'), 0))
    yield base + (11, if_index), T_INT,       str(_int(st.get('registration_flap_events_in_window'), 0))
    yield base + (12, if_index), T_INT,       str(_int(st.get('registration_flap_window_configured'), 360))


def _build_oid_tree(snapshot: Dict[int, Dict[str, Any]]) -> List[Tuple[Tuple[int, ...], str, str]]:
    rows: List[Tuple[Tuple[int, ...], str, str]] = []
    for if_index in sorted(snapshot.keys()):
        st = snapshot[if_index]
        rows.extend(_build_if_row(if_index, st))
        rows.extend(_build_sim_rows(if_index, st))
        rows.extend(_build_radio_row(if_index, st))
        rows.extend(_build_bearer_row(if_index, st))
        rows.extend(_build_failover_row(if_index, st))
    rows.sort(key=lambda r: r[0])
    return rows


# ── pass_persist protocol ──────────────────────────────────────────────────
def _parse_oid(text: str) -> Optional[Tuple[int, ...]]:
    text = text.strip().lstrip('.')
    if not text:
        return None
    try:
        return tuple(int(p) for p in text.split('.'))
    except ValueError:
        return None


def _format_oid(oid: Tuple[int, ...]) -> str:
    return '.' + '.'.join(str(p) for p in oid)


class PassPersistAgent:
    """Implements net-snmp pass_persist for the WWAN MIB subtree."""

    def __init__(self) -> None:
        self.cache = _StatusFetcher()
        self._tree: List[Tuple[Tuple[int, ...], str, str]] = []
        self._keys: List[Tuple[int, ...]] = []
        self._tree_stamp: float = 0.0

    def _refresh_tree(self) -> None:
        now = time.monotonic()
        if (now - self._tree_stamp) < CACHE_TTL_SECONDS and self._tree:
            return
        try:
            snapshot = self.cache.get()
            self._tree = _build_oid_tree(snapshot)
        except Exception as exc:
            logger.warning('Failed to refresh OID tree: %s', exc)
            self._tree = []
        # Parallel sorted key list for O(log n) bisect lookups.
        self._keys = [entry[0] for entry in self._tree]
        self._tree_stamp = now

    def handle_get(self, oid: Tuple[int, ...]) -> Optional[Tuple[Tuple[int, ...], str, str]]:
        self._refresh_tree()
        idx = bisect.bisect_left(self._keys, oid)
        if idx < len(self._keys) and self._keys[idx] == oid:
            return self._tree[idx]
        return None

    def handle_getnext(self, oid: Tuple[int, ...]) -> Optional[Tuple[Tuple[int, ...], str, str]]:
        self._refresh_tree()
        idx = bisect.bisect_right(self._keys, oid)
        if idx < len(self._tree):
            return self._tree[idx]
        return None

    def run(self) -> None:
        in_stream  = sys.stdin
        out_stream = sys.stdout

        def emit(*lines: str) -> None:
            out_stream.write('\n'.join(lines) + '\n')
            out_stream.flush()

        while True:
            cmd = in_stream.readline()
            if not cmd:
                return
            cmd = cmd.strip()
            if cmd == 'PING':
                emit('PONG')
                continue
            if cmd in ('get', 'getnext'):
                oid_line = in_stream.readline()
                if not oid_line:
                    return
                oid = _parse_oid(oid_line)
                if oid is None or oid[:len(ROOT)] != ROOT:
                    emit('NONE')
                    continue
                try:
                    result = (self.handle_get(oid) if cmd == 'get'
                              else self.handle_getnext(oid))
                except Exception as exc:
                    logger.warning('agent error on %s: %s', cmd, exc)
                    result = None
                if result is None:
                    emit('NONE')
                else:
                    res_oid, res_type, res_value = result
                    emit(_format_oid(res_oid), res_type, res_value)
                continue
            if cmd == 'set':
                # net-snmp pass_persist sends exactly two follow-up lines for a
                # SET: the OID, then a "<type> <value>" line.  Drain both and
                # refuse — this MIB subtree is read-only.  (Draining a third
                # line here would swallow the next command and desync.)
                in_stream.readline()
                in_stream.readline()
                emit('not-writable')
                continue
            if cmd == '':
                continue
            # Unknown verb — terminate cleanly.
            return


def main() -> int:
    logging.basicConfig(
        level=os.environ.get('VYOS_WWAN_SNMP_LOG_LEVEL', 'WARNING'),
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
        stream=sys.stderr,
    )
    PassPersistAgent().run()
    return 0


if __name__ == '__main__':
    sys.exit(main())
