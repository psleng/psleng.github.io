#!/usr/bin/env python3
#
# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This file is part of VyOS.
#
# VyOS is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# VyOS is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# VyOS. If not, see <https://www.gnu.org/licenses/>.

from argparse import ArgumentParser
from argparse import Namespace
from pathlib import Path
from shutil import copy
from shutil import chown
from shutil import rmtree
from shutil import copytree
from shutil import disk_usage
from glob import glob
from tempfile import TemporaryDirectory
from sys import exit
from os import environ
from os import readlink
from os import getpid
from os import getppid
from os import sync

# PSL - access to additional routines
from shutil import move
# PSL - access to additional routines

from json import loads
from json import dumps
from typing import Union
from urllib.parse import urlparse
from passlib.hosts import linux_context
from errno import ENOSPC

from psutil import disk_partitions

from vyos.base import Warning
from vyos.configtree import ConfigTree
from vyos.config_mgmt import unsaved_commits
from vyos.defaults import base_dir
from vyos.defaults import directories
from vyos.defaults import activation_hint
from vyos.flavor import get_image_serial_console
from vyos.flavor import get_image_dm_verity
from vyos.flavor import get_image_secure_grub
from vyos.remote import download
from vyos.system import disk
from vyos.system import grub
from vyos.system import image
from vyos.system import compat
from vyos.system import raid
from vyos.system import SYSTEM_CFG_VER
from vyos.system import grub_util
from vyos.template import render
from vyos.utils.auth import DEFAULT_PASSWORD
from vyos.utils.auth import EPasswdStrength
from vyos.utils.auth import evaluate_strength
from vyos.utils.auth import get_local_users
from vyos.utils.auth import get_user_home_dir
from vyos.utils.dict import dict_search
from vyos.utils.io import ask_input
from vyos.utils.io import ask_yes_no
from vyos.utils.io import select_entry
from vyos.utils.file import chmod_2775
from vyos.utils.file import read_file
from vyos.utils.file import write_file
from vyos.utils.process import cmd
from vyos.utils.process import run
from vyos.utils.process import rc_cmd
from vyos.version import get_version_data

# define text messages
MSG_ERR_NOT_LIVE: str = 'The system is already installed. Please use "add system image" instead.'
MSG_ERR_LIVE: str = 'The system is in live-boot mode. Please use "install image" instead.'
MSG_ERR_NOT_ENOUGH_SPACE: str = 'Image upgrade requires at least 2GB of free drive space.'
MSG_ERR_UNSAVED_COMMITS: str = 'There are unsaved changes to the configuration. Either save or revert before upgrade.'
MSG_ERR_NO_DISK: str = 'No suitable disk was found. There must be at least one disk of 2GB or greater size.'
MSG_ERR_IMPROPER_IMAGE: str = 'Missing sha256sum.txt.\nEither this image is corrupted, or of era 1.2.x (md5sum) and would downgrade image tools;\ndisallowed in either case.'
MSG_ERR_INCOMPATIBLE_IMAGE: str = 'Image compatibility check failed, aborting installation.'
MSG_ERR_ARCHITECTURE_MISMATCH: str = 'The current architecture is "{0}", the new image is for "{1}". Upgrading to a different image architecture will break your system.'
MSG_ERR_FLAVOR_MISMATCH: str = 'The current image flavor is "{0}", the new image is "{1}". Upgrading to a non-matching flavor can have unpredictable consequences.'
MSG_ERR_MISSING_ARCHITECTURE: str = 'The new image version data does not specify architecture, cannot check compatibility (is it a legacy release image?)'
MSG_ERR_MISSING_FLAVOR: str = 'The new image version data does not specify flavor, cannot check compatibility (is it a legacy release image?)'
MSG_ERR_CORRUPT_CURRENT_IMAGE: str = 'Version data in the current image is malformed: missing flavor and/or architecture fields. Upgrade compatibility cannot be checked.'
MSG_ERR_UNSUPPORTED_SIGNATURE_TYPE: str = 'Unsupported signature type, signature cannot be verified.'
MSG_INFO_INSTALL_WELCOME: str = 'Welcome to iGOS installation!\nThis command will install iGOS to your permanent storage.'
MSG_INFO_INSTALL_EXIT: str = 'Exiting from iGOS installation'
MSG_INFO_INSTALL_SUCCESS: str = 'The image installed successfully; please reboot now.'
MSG_INFO_INSTALL_DISKS_LIST: str = 'The following disks were found:'
MSG_INFO_INSTALL_DISK_SELECT: str = 'Which one should be used for installation?'
MSG_INFO_INSTALL_RAID_CONFIGURE: str = 'Would you like to configure RAID-1 mirroring?'
MSG_INFO_INSTALL_RAID_FOUND_DISKS: str = 'Would you like to configure RAID-1 mirroring on them?'
MSG_INFO_INSTALL_RAID_CHOOSE_DISKS: str = 'Would you like to choose two disks for RAID-1 mirroring?'
MSG_INFO_INSTALL_DISK_CONFIRM: str = 'Installation will delete all data on the drive. Continue?'
MSG_INFO_INSTALL_RAID_CONFIRM: str = 'Installation will delete all data on both drives. Continue?'
MSG_INFO_INSTALL_PARTITONING: str = 'Creating partition table...'
MSG_INPUT_CONFIG_FOUND: str = 'An active configuration was found. Would you like to copy it to the new image?'
MSG_INPUT_CONFIG_CHOICE: str = 'The following config files are available for boot:'
MSG_INPUT_CONFIG_CHOOSE: str = 'Which file would you like as boot config?'
MSG_INPUT_UNSAVED_COMMITS: str = 'There are unsaved changes to the configuration. They will not be copied to the new image. Continue without saving?'
MSG_INPUT_IMAGE_NAME: str = 'What would you like to name this image?'
MSG_INPUT_IMAGE_NAME_TAKEN: str = 'There is already an installed image by that name; please choose again'
MSG_INPUT_IMAGE_DEFAULT: str = 'Would you like to set the new image as the default one for boot?'
# PSL - branding vyos -> igos
MSG_INPUT_PASSWORD: str = 'Please enter a password for the "igos" user:'
MSG_INPUT_PASSWORD_CONFIRM: str = 'Please confirm password for the "igos" user:'
MSG_INPUT_ROOT_SIZE_ALL: str = 'Would you like to use all the free space on the drive?'
MSG_INPUT_ROOT_SIZE_SET: str = 'Please specify the size (in GB) of the root partition (min is 1.5 GB)?'
MSG_INPUT_CONSOLE_TYPE: str = 'What console should be used by default? (K: KVM, S: Serial)?'
# PSL - add console number input
_valid_console_nums = ['0', '1', '2', '3', '4']
MSG_INPUT_CONSOLE_NUM: str = (
    f"What console number should be used by default? "
    f"(range: {_valid_console_nums[0]} -> {_valid_console_nums[-1]})?"
)

MSG_INPUT_COPY_DATA: str = 'Would you like to copy data to the new image?'
MSG_INPUT_CHOOSE_COPY_DATA: str = 'From which image would you like to save config information?'
MSG_INPUT_COPY_ENC_DATA: str = 'Would you like to copy the encrypted config to the new image?'
MSG_INPUT_CHOOSE_COPY_ENC_DATA: str = 'From which image would you like to copy the encrypted config?'
MSG_WARN_ISO_SIGN_INVALID: str = 'Signature is not valid. Do you want to continue with installation?'
MSG_WARN_ISO_SIGN_UNAVAL: str = 'Signature is not available. Do you want to continue with installation?'
MSG_WARN_ROOT_SIZE_TOOBIG: str = 'The size is too big. Try again.'
MSG_WARN_ROOT_SIZE_TOOSMALL: str = 'The size is too small. Try again'
MSG_WARN_IMAGE_NAME_WRONG: str = 'The suggested name is unsupported!\n'\
'It must be between 1 and 64 characters long and contains only the next characters: .+-_ a-z A-Z 0-9'

MSG_WARN_CHANGE_PASSWORD: str = 'Default password used. Consider changing ' \
    'it on next login.'
MSG_WARN_PASSWORD_CONFIRM: str = 'The entered values did not match. Try again'
'Installing a different image flavor may cause functionality degradation or break your system.\n' \
'Do you want to continue with installation?'
CONST_MIN_DISK_SIZE: int = 2147483648  # 2 GB
CONST_MIN_ROOT_SIZE: int = 1610612736  # 1.5 GB
# a reserved space: 2MB for header, 1 MB for BIOS partition, 256 MB for EFI
CONST_RESERVED_SPACE: int = (2 + 1 + 256) * 1024**2

# define directories and paths
DIR_CONFIG: str = directories['config']
DIR_TPM_REEFS: str = '/var/lib/tee'
DIR_DATA: str = directories['data']
DIR_INSTALLATION: str = '/mnt/installation'
DIR_ROOTFS_SRC: str = f'{DIR_INSTALLATION}/root_src'
DIR_ROOTFS_DST: str = f'{DIR_INSTALLATION}/root_dst'
DIR_ISO_MOUNT: str = f'{DIR_INSTALLATION}/iso_src'
DIR_DST_ROOT: str = f'{DIR_INSTALLATION}/disk_dst'
DIR_KERNEL_SRC: str = '/boot'
# The raw filesystem.squashfs (and its sibling baked initrd / kernel signature)
# lives on the real boot medium. On a normal live boot that medium is at
# /usr/lib/live/mount/medium. Under dm-verity, live-boot is told
# `root=/dev/mapper/verity-root`, so it mounts the VERITY DEVICE (the squashfs
# *contents*) at /usr/lib/live/mount/medium; the medium actually carrying the
# .squashfs file is mounted by the igos-verity-root initramfs hook at
# /run/verity-medium (kept mounted -- the verity loop device is backed by that
# file). Prefer that location when it holds the squashfs, else the live mount.
DIR_LIVE_MEDIUM: str = (
    '/run/verity-medium'
    if Path('/run/verity-medium/live/filesystem.squashfs').exists()
    else '/usr/lib/live/mount/medium'
)
FILE_ROOTFS_SRC: str = f'{DIR_LIVE_MEDIUM}/live/filesystem.squashfs'
# dm-verity: sibling of FILE_ROOTFS_SRC on the live medium; carries the root
# hash baked by 28-igos-dm-verity.binary (the squashfs-internal initrd does not).
FILE_INITRD_SRC: str = f'{DIR_LIVE_MEDIUM}/live/initrd.img'
# secure-boot: detached signature of the kernel on the live medium (sibling of
# the baked initrd), written by 29-igos-sign-boot.binary. Present only on signed
# builds; the initrd signature is FILE_INITRD_SRC + '.sig'.
FILE_KERNEL_SIG_SRC: str = f'{DIR_LIVE_MEDIUM}/live/vmlinuz.sig'
ISO_DOWNLOAD_PATH: str = ''

external_download_script: str = f'{base_dir}/simple-download.py'
external_latest_image_url_script: str = f'{base_dir}/latest-image-url.py'

(flavor_sercon_type, flavor_sercon_num, flavor_sercon_speed) = get_image_serial_console()

# default boot variables
# PSL - TEMP (dm-verity bring-up): show the GRUB menu for 10s so an older image
# can be selected if a verity image fails to boot. Restore timeout '0' and drop
# timeout_style (or set it 'hidden') to suppress the menu again after testing.
DEFAULT_BOOT_VARS: dict[str, str] = {
    'timeout': '10',
    'timeout_style': 'menu',
    'console_type': 'tty',
    'console_num': flavor_sercon_num,
    'console_speed': flavor_sercon_speed,
    'bootmode': 'normal'
}

def bytes_to_gb(size: int) -> float:
    """Convert Bytes to GBytes, rounded to 1 decimal number

    Args:
        size (int): input size in bytes

    Returns:
        float: size in GB
    """
    return round(size / 1024**3, 1)


def gb_to_bytes(size: float) -> int:
    """Convert GBytes to Bytes

    Args:
        size (float): input size in GBytes

    Returns:
        int: size in bytes
    """
    return int(size * 1024**3)


def find_disks() -> dict[str, int]:
    """Find a target disk for installation

    Returns:
        dict[str, int]: a list of available disks by name and size
    """
    # check for available disks
    print('Probing disks')
    disks_available: dict[str, int] = disk.disks_size()
    for disk_name, disk_size in disks_available.copy().items():
        if disk_size < CONST_MIN_DISK_SIZE:
            del disks_available[disk_name]
    if not disks_available:
        print(MSG_ERR_NO_DISK)
        exit(MSG_INFO_INSTALL_EXIT)

    num_disks: int = len(disks_available)
    print(f'{num_disks} disk(s) found')

    return disks_available


def ask_root_size(available_space: int) -> int:
    """Define a size of root partition

    Args:
        available_space (int): available space in bytes for a root partition

    Returns:
        int: defined size
    """
    if ask_yes_no(MSG_INPUT_ROOT_SIZE_ALL, default=True):
        return available_space

    while True:
        root_size_gb: str = ask_input(MSG_INPUT_ROOT_SIZE_SET)
        root_size_kbytes: int = (gb_to_bytes(float(root_size_gb))) // 1024

        if root_size_kbytes > available_space:
            print(MSG_WARN_ROOT_SIZE_TOOBIG)
            continue
        if root_size_kbytes < CONST_MIN_ROOT_SIZE / 1024:
            print(MSG_WARN_ROOT_SIZE_TOOSMALL)
            continue

        return root_size_kbytes

def create_partitions(target_disk: str, target_size: int,
                      prompt: bool = True) -> None:
    """Create partitions on a target disk

    Args:
        target_disk (str): a target disk
        target_size (int): size of disk in bytes
    """
    # define target rootfs size in KB (smallest unit acceptable by sgdisk)
    available_size: int = (target_size - CONST_RESERVED_SPACE) // 1024
    if prompt:
        rootfs_size: int = ask_root_size(available_size)
    else:
        rootfs_size: int = available_size

    print(MSG_INFO_INSTALL_PARTITONING)
    raid.clear()
    disk.disk_cleanup(target_disk)
    disk_details: disk.DiskDetails = disk.parttable_create(target_disk,
                                                           rootfs_size)

    return disk_details


def search_format_selection(image: tuple[str, str]) -> str:
    """Format a string for selection of image

    Args:
        image (tuple[str, str]): a tuple of image name and drive

    Returns:
        str: formatted string
    """
    return f'{image[0]} on {image[1]}'


def search_previous_installation(disks: list[str]) -> None:
    """Search disks for previous installation config and SSH keys

    Args:
        disks (list[str]): a list of available disks
    """
    mnt_config = '/mnt/config'
    mnt_encrypted_config = '/mnt/encrypted_config'
    mnt_ssh = '/mnt/ssh'
    mnt_tmp = '/mnt/tmp'
    rmtree(Path(mnt_config), ignore_errors=True)
    rmtree(Path(mnt_ssh), ignore_errors=True)
    Path(mnt_tmp).mkdir(exist_ok=True)
    Path(mnt_encrypted_config).unlink(missing_ok=True)

    print('Searching for data from previous installations')
    image_data = []
    encrypted_configs = []
    legacy_bind_mount = False
    for disk_name in disks:
        for partition in disk.partition_list(disk_name):
            if disk.partition_mount(partition, mnt_tmp):
                if Path(mnt_tmp + '/boot').exists():
                    for path in Path(mnt_tmp + '/boot').iterdir():
                        if path.joinpath('rw/config/.vyatta_config').exists():
                            legacy_bind_mount = True
                            image_data.append((path.name, partition))
                        elif path.joinpath(
                            'rw/opt/vyatta/etc/config/.vyatta_config'
                        ).exists():
                            image_data.append((path.name, partition))
                if Path(mnt_tmp + '/luks').exists():
                    for path in Path(mnt_tmp + '/luks').iterdir():
                        encrypted_configs.append((path.name, partition))

                disk.partition_umount(partition)

    image_name = None
    image_drive = None
    encrypted = False

    if len(image_data) > 0:
        if len(image_data) == 1:
            print('Found data from previous installation:')
            print(f'\t{" on ".join(image_data[0])}')
            if ask_yes_no(MSG_INPUT_COPY_DATA, default=True):
                image_name, image_drive = image_data[0]

        elif len(image_data) > 1:
            print('Found data from previous installations')
            if ask_yes_no(MSG_INPUT_COPY_DATA, default=True):
                image_name, image_drive = select_entry(image_data,
                                                       'Available versions:',
                                                       MSG_INPUT_CHOOSE_COPY_DATA,
                                                       search_format_selection)
    elif len(encrypted_configs) > 0:
        if len(encrypted_configs) == 1:
            print('Found encrypted config from previous installation:')
            print(f'\t{" on ".join(encrypted_configs[0])}')
            if ask_yes_no(MSG_INPUT_COPY_ENC_DATA, default=True):
                image_name, image_drive = encrypted_configs[0]
                encrypted = True

        elif len(encrypted_configs) > 1:
            print('Found encrypted configs from previous installations')
            if ask_yes_no(MSG_INPUT_COPY_ENC_DATA, default=True):
                image_name, image_drive = select_entry(encrypted_configs,
                                          'Available versions:',
                                          MSG_INPUT_CHOOSE_COPY_ENC_DATA,
                                          search_format_selection)
                encrypted = True

    else:
        print('No previous installation found')
        return

    if not image_name:
        return

    disk.partition_mount(image_drive, mnt_tmp)

    if not encrypted:
        if legacy_bind_mount:
            copytree(f'{mnt_tmp}/boot/{image_name}/rw/config', mnt_config)
        else:
            copytree(
                f'{mnt_tmp}/boot/{image_name}/rw/opt/vyatta/etc/config', mnt_config
            )
    else:
        copy(f'{mnt_tmp}/luks/{image_name}', mnt_encrypted_config)

    Path(mnt_ssh).mkdir()
    host_keys: list[str] = glob(f'{mnt_tmp}/boot/{image_name}/rw/etc/ssh/ssh_host*')
    for host_key in host_keys:
        copy(host_key, mnt_ssh)

    disk.partition_umount(image_drive)

def copy_preserve_owner(src: str, dst: str, *, follow_symlinks=True):
    if not Path(src).is_file():
        return
    if Path(dst).is_dir():
        dst = Path(dst).joinpath(Path(src).name)
    st = Path(src).stat()
    copy(src, dst, follow_symlinks=follow_symlinks)
    chown(dst, user=st.st_uid)


def copy_previous_installation_data(target_dir: str) -> None:
    if Path('/mnt/config').exists():
        copytree('/mnt/config', f'{target_dir}{DIR_CONFIG}',
                 dirs_exist_ok=True)
    if Path('/mnt/ssh').exists():
        copytree('/mnt/ssh', f'{target_dir}/etc/ssh',
                 dirs_exist_ok=True)


def copy_previous_encrypted_config(target_dir: str, image_name: str) -> None:
    if Path('/mnt/encrypted_config').exists():
        Path(target_dir).mkdir(exist_ok=True)
        copy('/mnt/encrypted_config', Path(target_dir).joinpath(image_name))


def ask_single_disk(disks_available: dict[str, int]) -> str:
    """Ask user to select a disk for installation

    Args:
        disks_available (dict[str, int]): a list of available disks
    """
    print(MSG_INFO_INSTALL_DISKS_LIST)
    default_disk: str = list(disks_available)[0]
    for disk_name, disk_size in disks_available.items():
        disk_size_human: str = bytes_to_gb(disk_size)
        print(f'Drive: {disk_name} ({disk_size_human} GB)')
    disk_selected: str = ask_input(MSG_INFO_INSTALL_DISK_SELECT,
                                   default=default_disk,
                                   valid_responses=list(disks_available))

    # create partitions
    if not ask_yes_no(MSG_INFO_INSTALL_DISK_CONFIRM):
        print(MSG_INFO_INSTALL_EXIT)
        exit()

    search_previous_installation(list(disks_available))

    disk_details: disk.DiskDetails = create_partitions(disk_selected,
                                                       disks_available[disk_selected])

    disk.filesystem_create(disk_details.partition['efi'], 'efi')
    disk.filesystem_create(disk_details.partition['root'], 'ext4')

    return disk_details


def check_raid_install(disks_available: dict[str, int]) -> Union[str, None]:
    """Ask user to select disks for RAID installation

    Args:
        disks_available (dict[str, int]): a list of available disks
    """
    if len(disks_available) < 2:
        return None

    if not ask_yes_no(MSG_INFO_INSTALL_RAID_CONFIGURE, default=True):
        return None

    def format_selection(disk_name: str) -> str:
        return f'{disk_name}\t({bytes_to_gb(disks_available[disk_name])} GB)'

    disk0, disk1 = list(disks_available)[0], list(disks_available)[1]
    disks_selected: dict[str, int] = { disk0: disks_available[disk0],
                                       disk1: disks_available[disk1] }

    target_size: int = min(disks_selected[disk0], disks_selected[disk1])

    print(MSG_INFO_INSTALL_DISKS_LIST)
    for disk_name, disk_size in disks_selected.items():
        disk_size_human: str = bytes_to_gb(disk_size)
        print(f'\t{disk_name} ({disk_size_human} GB)')
    if not ask_yes_no(MSG_INFO_INSTALL_RAID_FOUND_DISKS, default=True):
        if not ask_yes_no(MSG_INFO_INSTALL_RAID_CHOOSE_DISKS, default=True):
            return None
        else:
            disks_selected = {}
            disk0 = select_entry(list(disks_available), 'Disks available:',
                                 'Select first disk:', format_selection)

            disks_selected[disk0] = disks_available[disk0]
            del disks_available[disk0]
            disk1 = select_entry(list(disks_available), 'Remaining disks:',
                                 'Select second disk:', format_selection)
            disks_selected[disk1] = disks_available[disk1]

            target_size: int = min(disks_selected[disk0],
                                   disks_selected[disk1])

    # create partitions
    if not ask_yes_no(MSG_INFO_INSTALL_RAID_CONFIRM):
        print(MSG_INFO_INSTALL_EXIT)
        exit()

    search_previous_installation(list(disks_available))

    disks: list[disk.DiskDetails] = []
    for disk_selected in list(disks_selected):
        print(f'Creating partitions on {disk_selected}')
        disk_details = create_partitions(disk_selected, target_size,
                                         prompt=False)
        disk.filesystem_create(disk_details.partition['efi'], 'efi')

        disks.append(disk_details)

    print('Creating RAID array')
    members = [disk.partition['root'] for disk in disks]
    raid_details: raid.RaidDetails = raid.raid_create(members)
    # raid init stuff
    print('Updating initramfs')
    raid.update_initramfs()
    # end init
    print('Creating filesystem on RAID array')
    disk.filesystem_create(raid_details.name, 'ext4')

    return raid_details


def prepare_tmp_disr() -> None:
    """Create temporary directories for installation
    """
    print('Creating temporary directories')
    for dir in [DIR_ROOTFS_SRC, DIR_ROOTFS_DST, DIR_DST_ROOT]:
        dirpath = Path(dir)
        dirpath.mkdir(mode=0o755, parents=True)


def setup_grub(root_dir: str) -> None:
    """Install GRUB configurations

    Args:
        root_dir (str): a path to the root of target filesystem
    """
    print('Installing GRUB configuration files')
    grub_cfg_main = f'{root_dir}/{grub.GRUB_DIR_MAIN}/grub.cfg'
    grub_cfg_vars = f'{root_dir}/{grub.CFG_VYOS_VARS}'
    grub_cfg_modules = f'{root_dir}/{grub.CFG_VYOS_MODULES}'
    grub_cfg_menu = f'{root_dir}/{grub.CFG_VYOS_MENU}'
    grub_cfg_options = f'{root_dir}/{grub.CFG_VYOS_OPTIONS}'

    # create new files
    render(grub_cfg_main, grub.TMPL_GRUB_MAIN, {})
    grub.common_write(root_dir)
    grub.vars_write(grub_cfg_vars, DEFAULT_BOOT_VARS)
    grub.modules_write(grub_cfg_modules, [])
    grub.write_cfg_ver(1, root_dir)
    render(grub_cfg_menu, grub.TMPL_GRUB_MENU, {})
    render(grub_cfg_options, grub.TMPL_GRUB_OPTS, {})

def get_cli_kernel_options(config_file: str) -> list:
    config = ConfigTree(read_file(config_file))
    config_dict = loads(config.to_json())
    cmdline_options = []
    kernel_options = dict_search('system.option.kernel', config_dict)
    if kernel_options is None:
        return cmdline_options

    k_cpu_opts = kernel_options.get('cpu', {})
    k_memory_opts = kernel_options.get('memory', {})

    # XXX: This code path and if statements must be kept in sync with the Kernel
    # option handling in system_options.py:generate(). This occurrence is used
    # for having the appropriate options passed to GRUB after an image upgrade!
    if 'disable-mitigations' in kernel_options:
        cmdline_options.append('mitigations=off')
    if 'disable-power-saving' in kernel_options:
        cmdline_options.append('intel_idle.max_cstate=0 processor.max_cstate=1')
    if 'amd-pstate-driver' in kernel_options:
        mode = kernel_options['amd-pstate-driver']
        cmdline_options.append(
            f'initcall_blacklist=acpi_cpufreq_init amd_pstate={mode}')
    if 'quiet' in kernel_options:
        cmdline_options.append('quiet')

    # Early reboot on kernel panic via kernel cmdline (must match system_option.py)
    if dict_search('system.option.reboot-on-panic', config_dict) is not None:
        cmdline_options.append('panic=60')

    if 'disable-hpet' in kernel_options:
        cmdline_options.append('hpet=disable')

    if 'disable-mce' in kernel_options:
        cmdline_options.append('mce=off')

    if 'disable-softlockup' in kernel_options:
        cmdline_options.append('nosoftlockup')

    # CPU options
    isol_cpus = k_cpu_opts.get('isolate-cpus')
    if isol_cpus:
        cmdline_options.append(f'isolcpus={isol_cpus}')

    nohz_full = k_cpu_opts.get('nohz-full')
    if nohz_full:
        cmdline_options.append(f'nohz_full={nohz_full}')

    rcu_nocbs = k_cpu_opts.get('rcu-no-cbs')
    if rcu_nocbs:
        cmdline_options.append(f'rcu_nocbs={rcu_nocbs}')

    if 'disable-nmi-watchdog' in k_cpu_opts:
        cmdline_options.append('nmi_watchdog=0')

    # Memory options
    if 'disable-numa-balancing' in k_memory_opts:
        cmdline_options.append('numa_balancing=disable')

    default_hp_size = k_memory_opts.get('default-hugepage-size')
    if default_hp_size:
        cmdline_options.append(f'default_hugepagesz={default_hp_size}')

    hp_sizes = k_memory_opts.get('hugepage-size')
    if hp_sizes:
        for size, settings in hp_sizes.items():
            cmdline_options.append(f'hugepagesz={size}')
            count = settings.get('hugepage-count')
            if count:
                cmdline_options.append(f'hugepages={count}')

    return cmdline_options

def configure_authentication(config_file: str, password: str) -> None:
    """Write encrypted password to config file

    Args:
        config_file (str): path of target config file
        password (str): plaintext password

    N.B. this can not be deferred by simply setting the plaintext password
    and relying on the config mode script to process at boot, as the config
    will not automatically be saved in that case, thus leaving the
    plaintext exposed
    """
    encrypted_password = linux_context.hash(password)
    config_string = read_file(config_file)
    config = ConfigTree(config_string)
    config.set([
        'system', 'login', 'user', 'vyos', 'authentication',
        'encrypted-password'
    ],
               value=encrypted_password,
               replace=True)
    config.set_tag(['system', 'login', 'user'])

    with open(config_file, 'w') as f:
        f.write(config.to_string())

def configure_serial_console(config_file: str, console_type: str) -> None:
    """Apply serial console settings to config.boot from kernel cmdline.

    This overlaps with 05-serial_console.py activation logic, but that script
    only runs during live boot. During installation, the user may pick a
    different source config, so serial console settings must be written to
    the final target config explicitly.

    Behavior:
    - Reads the kernel serial console device/speed from the current boot cmdline.
    - If the detected device is a valid tty, writes:
        system console device <TTY> speed <rate>
    - If "console_type == 'S'", also writes:
        system console device <TTY> kernel

    Args:
        config_file (str): path of target config file
        console_type (str): 'K' (KVM/tty) or 'S' (serial)
    """
    from vyos.utils.serial import is_tty
    from vyos.utils.kernel import get_kernel_serial_console

    # Parse current kernel cmdline and continue only for valid serial console
    # data. Prevent writing incomplete/invalid console settings to config.boot.
    k_console_type, k_console_num, k_console_speed = get_kernel_serial_console()
    device = f'{k_console_type}{k_console_num}'
    if not is_tty(device) or not k_console_speed:
        return

    base = ['system', 'console', 'device']
    config_string = read_file(config_file)
    config = ConfigTree(config_string)
    config.set(base + [device, 'speed'], value=k_console_speed)
    config.set_tag(base)

    # Only mark this device as kernel boot console when console_type 'S' for
    # serial was defined by user.
    if console_type == 'S':
        config.set(base + [device, 'kernel'])

    with open(config_file, 'w') as f:
        f.write(config.to_string())

def validate_signature(file_path: str, sign_type: str) -> None:
    """Validate a file by signature and delete a signature file

    Args:
        file_path (str): a path to file
        sign_type (str): a signature type
    """
    print('Validating signature')
    signature_valid: bool = False
    if sign_type == 'minisig':
        pub_key_list = glob('/usr/share/vyos/keys/*.minisign.pub')
        for pubkey in pub_key_list:
            if run(f'minisign -V -q -p {pubkey} -m {file_path} -x {file_path}.minisig'
                  ) == 0:
                signature_valid = True
                break
        Path(f'{file_path}.minisig').unlink()
    else:
        exit(MSG_ERR_UNSUPPORTED_SIGNATURE_TYPE)

    # warn or pass
    if not signature_valid:
        if not ask_yes_no(MSG_WARN_ISO_SIGN_INVALID, default=False):
            exit(MSG_INFO_INSTALL_EXIT)
    else:
        print('Signature is valid')

def download_file(local_file: str, remote_path: str, vrf: str,
                  progressbar: bool = False, check_space: bool = False):
    # Server credentials are implicitly passed in environment variables
    # that are set by add_image
    if vrf is None:
        download(local_file, remote_path, progressbar=progressbar,
                 check_space=check_space, raise_error=True)
    else:
        vrf_cmd = f'ip vrf exec {vrf} {external_download_script} \
                    --local-file {local_file} --remote-path {remote_path}'
        cmd(vrf_cmd, env=environ)

def image_fetch(image_path: str, vrf: str = None,
                no_prompt: bool = False) -> Path:
    """Fetch an ISO image

    Args:
        image_path (str): a path, remote or local

    Returns:
        Path: a path to a local file
    """
    import os.path
    from uuid import uuid4

    global ISO_DOWNLOAD_PATH

    # Latest version gets url from configured "system update-check url"
    if image_path == 'latest':
        command = external_latest_image_url_script
        if vrf:
            command = f'ip vrf exec {vrf} {command}'
        code, output = rc_cmd(command, env=environ)
        if code:
            print(output)
            exit(MSG_INFO_INSTALL_EXIT)
        image_path = output if output else image_path

    try:
        # check a type of path
        if urlparse(image_path).scheme:
            # Download the image file
            ISO_DOWNLOAD_PATH = os.path.join(os.path.expanduser("~"), '{0}.iso'.format(uuid4()))
            download_file(ISO_DOWNLOAD_PATH, image_path, vrf,
                          progressbar=True, check_space=True)

            # Download the image signature
            # VyOS only supports minisign signatures at the moment,
            # but we keep the logic for multiple signatures
            # in case we add something new in the future
            sign_file = (False, '')
            for sign_type in ['minisig']:
                try:
                    download_file(f'{ISO_DOWNLOAD_PATH}.{sign_type}',
                                  f'{image_path}.{sign_type}', vrf)
                    sign_file = (True, sign_type)
                    break
                except Exception:
                    print(f'Could not download {sign_type} signature')
            # Validate the signature if it is available
            if sign_file[0]:
                validate_signature(ISO_DOWNLOAD_PATH, sign_file[1])
            else:
                if (not no_prompt and
                    not ask_yes_no(MSG_WARN_ISO_SIGN_UNAVAL, default=False)):
                    cleanup()
                    exit(MSG_INFO_INSTALL_EXIT)

            return Path(ISO_DOWNLOAD_PATH)
        else:
            local_path: Path = Path(image_path)
            if local_path.is_file():
                return local_path
            else:
                raise FileNotFoundError
    except Exception as e:
        print(f'The image cannot be fetched from: {image_path} {e}')
        exit(1)


def migrate_config() -> bool:
    """Check for active config and ask user for migration

    Returns:
        bool: user's decision
    """
    active_config_path: Path = Path(f'{DIR_CONFIG}/config.boot')
    if active_config_path.exists():
        if ask_yes_no(MSG_INPUT_CONFIG_FOUND, default=True):
            return True
    return False


def copy_ssh_host_keys() -> bool:
    """Ask user to copy SSH host keys

    Returns:
        bool: user's decision
    """
    if ask_yes_no('Would you like to copy SSH host keys?', default=True):
        return True
    return False


def copy_ssh_known_hosts() -> bool:
    """Ask user to copy SSH `known_hosts` files

    Returns:
        bool: user's decision
    """
    known_hosts_files = get_known_hosts_files()
    msg = (
        'Would you like to save the SSH known hosts (fingerprints) '
        'from your current configuration?'
    )
    return known_hosts_files and ask_yes_no(msg, default=True)


def console_hint() -> str:
    pid = getppid() if 'SUDO_USER' in environ else getpid()
    try:
        path = readlink(f'/proc/{pid}/fd/1')
    except OSError:
        path = '/dev/tty'

    name = Path(path).name
    if name.startswith(('ttyS', 'ttyAMA')):
        return 'S'
    else:
        return 'K'


# PSL - added to override default console number
def console_num_hint(valid: list[str]) -> str:
    """Get default console number, optionally overridden by a file."""

    path = '/usr/share/vyos/templates/default_console'

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = f.readline().strip()

        if data in valid:
            return data

    except OSError:
        pass

    return valid[0]


def cleanup(mounts: list[str] = [], remove_items: list[str] = []) -> None:
    """Clean up after installation

    Args:
        mounts (list[str], optional): List of mounts to unmount.
        Defaults to [].
        remove_items (list[str], optional): List of files or directories
        to remove. Defaults to [].
    """
    print('Cleaning up')
    # clean up installation directory by default
    mounts_all = disk_partitions(all=True)
    for mounted_device in mounts_all:
        if mounted_device.mountpoint.startswith(DIR_INSTALLATION) and not (
                mounted_device.device in mounts or
                mounted_device.mountpoint in mounts):
            mounts.append(mounted_device.mountpoint)
    # add installation dir to cleanup list
    if DIR_INSTALLATION not in remove_items:
        remove_items.append(DIR_INSTALLATION)
    # also delete an ISO file
    if Path(ISO_DOWNLOAD_PATH).exists(
    ) and ISO_DOWNLOAD_PATH not in remove_items:
        remove_items.append(ISO_DOWNLOAD_PATH)

    if mounts:
        print('Unmounting target filesystems')
        for mountpoint in mounts:
            disk.partition_umount(mountpoint)
        for mountpoint in mounts:
            disk.wait_for_umount(mountpoint)
    if remove_items:
        print('Removing temporary files')
        for remove_item in remove_items:
            if Path(remove_item).exists():
                if Path(remove_item).is_file():
                    Path(remove_item).unlink()
                if Path(remove_item).is_dir():
                    rmtree(remove_item, ignore_errors=True)


def cleanup_raid(details: raid.RaidDetails) -> None:
    efiparts = []
    for raid_disk in details.disks:
        efiparts.append(raid_disk.partition['efi'])
    cleanup([details.name, *efiparts],
            ['/mnt/installation'])


def is_raid_install(install_object: Union[disk.DiskDetails, raid.RaidDetails]) -> bool:
    """Check if installation target is a RAID array

    Args:
        install_object (Union[disk.DiskDetails, raid.RaidDetails]): a target disk

    Returns:
        bool: True if it is a RAID array
    """
    if isinstance(install_object, raid.RaidDetails):
        return True
    return False


def validate_compatibility(iso_path: str, force: bool = False) -> None:
    """Check architecture and flavor compatibility with the running image

    Args:
        iso_path (str): a path to the mounted ISO image
    """
    current_data = get_version_data()
    current_flavor = current_data.get('flavor')
    current_architecture = current_data.get('architecture') or cmd('dpkg --print-architecture')

    new_data = get_version_data(f'{iso_path}/version.json')
    new_flavor = new_data.get('flavor')
    new_architecture = new_data.get('architecture')

    if not current_flavor or not current_architecture:
        # This may only happen if someone modified the version file.
        # Unlikely but not impossible.
        print(MSG_ERR_CORRUPT_CURRENT_IMAGE)
        cleanup()
        exit(MSG_INFO_INSTALL_EXIT)

    success = True

    if current_architecture != new_architecture:
        success = False
        if not new_architecture:
            print(MSG_ERR_MISSING_ARCHITECTURE)
        else:
            print(MSG_ERR_ARCHITECTURE_MISMATCH.format(current_architecture, new_architecture))

    if current_flavor != new_flavor:
        if not force:
            success = False
        if not new_flavor:
            print(MSG_ERR_MISSING_FLAVOR)
        else:
            print(MSG_ERR_FLAVOR_MISMATCH.format(current_flavor, new_flavor))

    if not success:
        print(MSG_ERR_INCOMPATIBLE_IMAGE)
        cleanup()
        exit(MSG_INFO_INSTALL_EXIT)


def install_secure_grub_core(efi_mount: str) -> None:
    """secure_grub: CONSUME the prebuilt enforcing monolithic core carried in the
    running image (built by 25-igos-grub-core.chroot) -- copy it onto the ESP.
    The caller SKIPS grub-install for secure images (a monolithic core needs no
    on-disk module tree; /boot/grub config is generated separately). No-op on
    non-secure images; mirrors prod_image.py.
    """
    if not get_image_secure_grub():
        return
    core_src = Path('/usr/lib/grub/arm64-efi/monolithic/grubaa64.efi')
    core_dst = Path(f'{efi_mount}/EFI/VyOS/grubaa64.efi')
    if not core_src.is_file():
        exit(f'secure_grub image is missing the enforcing GRUB core at {core_src} '
             '-- refusing to install a non-enforcing bootloader')
    print('Installing enforcing GRUB core to ESP EFI/VyOS/grubaa64.efi')
    core_dst.parent.mkdir(parents=True, exist_ok=True)
    copy(core_src, core_dst)


def install_image() -> None:
    """Install an image to a disk
    """
    if not image.is_live_boot():
        exit(MSG_ERR_NOT_LIVE)

    print(MSG_INFO_INSTALL_WELCOME)
    if not ask_yes_no('Would you like to continue?'):
        print(MSG_INFO_INSTALL_EXIT)
        exit()

    # configure image name
    running_image_name: str = image.get_running_image()
    while True:
        image_name: str = ask_input(MSG_INPUT_IMAGE_NAME,
                                    running_image_name)
        if image.validate_name(image_name):
            break
        print(MSG_WARN_IMAGE_NAME_WRONG)

    failed_check_status = [EPasswdStrength.WEAK, EPasswdStrength.ERROR]
    # ask for password
    while True:
        user_password: str = ask_input(MSG_INPUT_PASSWORD, no_echo=True,
                                       non_empty=True)

        if user_password == DEFAULT_PASSWORD:
            Warning(MSG_WARN_CHANGE_PASSWORD)
        else:
            result = evaluate_strength(user_password)
            if result['strength'] in failed_check_status:
                Warning(result['error'])

        confirm: str = ask_input(MSG_INPUT_PASSWORD_CONFIRM, no_echo=True,
                                 non_empty=True)

        if user_password == confirm:
            break

        print(MSG_WARN_PASSWORD_CONFIRM)

    # ask for default console
    console_dict: dict[str, str] = {'K': 'tty', 'S': flavor_sercon_type}
    console_type: str = ask_input(MSG_INPUT_CONSOLE_TYPE,
                                  default=console_hint(),
                                  valid_responses=console_dict.keys())

    # PSL - added to override default console number
    console_num: str = ask_input(MSG_INPUT_CONSOLE_NUM,
                                 default=console_num_hint(_valid_console_nums),
                                 valid_responses=_valid_console_nums)

    DEFAULT_BOOT_VARS['console_num'] = console_num

    config_boot_list = [f'{DIR_CONFIG}/config.boot',
                        '/opt/vyatta/etc/config.boot.default']
    default_config = config_boot_list[0]

    disks: dict[str, int] = find_disks()

    install_target: Union[disk.DiskDetails, raid.RaidDetails, None] = None
    try:
        install_target = check_raid_install(disks)
        if install_target is None:
            install_target = ask_single_disk(disks)

        # if previous install was selected in search_previous_installation,
        # directory /mnt/config was prepared for copy below; if not, prompt:
        if not Path('/mnt/config').exists():
            default_config: str = select_entry(config_boot_list,
                                               MSG_INPUT_CONFIG_CHOICE,
                                               MSG_INPUT_CONFIG_CHOOSE,
                                               default_entry=1) # select_entry indexes from 1

        # create directories for installation media
        prepare_tmp_disr()

        # mount target filesystem and create required dirs inside
        print('Mounting new partitions')
        if is_raid_install(install_target):
            disk.partition_mount(install_target.name, DIR_DST_ROOT)
            Path(f'{DIR_DST_ROOT}/boot/efi').mkdir(parents=True)
        else:
            disk.partition_mount(install_target.partition['root'], DIR_DST_ROOT)
            Path(f'{DIR_DST_ROOT}/boot/efi').mkdir(parents=True)
            disk.partition_mount(install_target.partition['efi'], f'{DIR_DST_ROOT}/boot/efi')

        # a config dir. It is the deepest one, so the command will
        # create all the rest in a single step
        print('Creating a configuration file')
        target_config_dir: str = f'{DIR_DST_ROOT}/boot/{image_name}/rw{DIR_CONFIG}/'
        Path(target_config_dir).mkdir(parents=True)
        chown(target_config_dir, group='vyattacfg')
        chmod_2775(target_config_dir)
        # copy config
        copy(default_config, f'{target_config_dir}/config.boot')
        configure_authentication(f'{target_config_dir}/config.boot',
                                 user_password)
        configure_serial_console(f'{target_config_dir}/config.boot',
                                 console_type)
        Path(f'{target_config_dir}/.vyatta_config').touch()

        # create a persistence.conf
        Path(f'{DIR_DST_ROOT}/persistence.conf').write_text('/ union\n')

        # copy system image and kernel files
        print('Copying system image files')

        # PSL - copy all system files and symlinks, also rename the filesystem.squashfs
        # Note: DIR_KERNEL_SRC is /boot that within the RUNNING filesystem.squashfs and
        #       does NOT contain the filesystem.squashfs file itself but has the dtb and grub
        copytree(f"{DIR_KERNEL_SRC}/",
                 f"{DIR_DST_ROOT}/boot/{image_name}/",
                 dirs_exist_ok=True,
                 symlinks=True)

        # PSL - from previous copytree() the dtb and grub directories were copied to the
        #       installation directory, so we can leave the release specific DTBs but
        #       remove the grub directory so the installation looks EXACTLY like
        #       an iso installation using "add system image <iso_name>"
        tmppath = Path(f'{DIR_DST_ROOT}/boot/{image_name}/grub')
        if tmppath.exists():
            print(f"Pruning unused {image_name}/grub directory")
            rmtree(tmppath, ignore_errors=True)

        copy(FILE_ROOTFS_SRC,
             f'{DIR_DST_ROOT}/boot/{image_name}/{image_name}.squashfs')

        # dm-verity: re-source the version initrd from the live medium (baked
        # with the root hash by 28-igos-dm-verity.binary); the /boot copytree
        # above carries only the squashfs-internal initrd. No-op for non-verity.
        if get_image_dm_verity() and Path(FILE_INITRD_SRC).exists():
            print('Installing dm-verity baked initrd for image')
            copy(FILE_INITRD_SRC,
                 f'{DIR_DST_ROOT}/boot/{image_name}/initrd.img')

            # secure-boot: carry the detached signatures for kernel + initrd when
            # the image was signed by 29-igos-sign-boot.binary. Best-effort --
            # unsigned verity builds simply have no .sig files to copy.
            for _sig_src, _sig_dst in (
                (f'{FILE_INITRD_SRC}.sig',
                 f'{DIR_DST_ROOT}/boot/{image_name}/initrd.img.sig'),
                (FILE_KERNEL_SIG_SRC,
                 f'{DIR_DST_ROOT}/boot/{image_name}/vmlinuz.sig'),
            ):
                if Path(_sig_src).exists():
                    print(f'Installing boot signature {Path(_sig_dst).name}')
                    copy(_sig_src, _sig_dst)

        # PSL - no longer copy the whole DTB tree (any vendor subdir: ti/, perle/, ...) to global /boot/dtb
        # if Path(f"{DIR_KERNEL_SRC}/dtb").exists():
        #     print('Copying DTB files')
        #     copytree(
        #         f"{DIR_KERNEL_SRC}/dtb", f"{DIR_DST_ROOT}/boot/dtb", dirs_exist_ok=True
        #    )

        # copy saved config data and SSH keys
        # owner restored on copy of config data by chmod_2775, above
        copy_previous_installation_data(f'{DIR_DST_ROOT}/boot/{image_name}/rw')

        # copy saved encrypted config volume
        copy_previous_encrypted_config(f'{DIR_DST_ROOT}/luks', image_name)

        if is_raid_install(install_target):
            write_dir: str = f'{DIR_DST_ROOT}/boot/{image_name}/rw'
            raid.update_default(write_dir)

        # set activation hint
        target_data_dir: str = f'{DIR_DST_ROOT}/boot/{image_name}/rw{DIR_DATA}/'
        data_path = Path(target_data_dir)
        data_path.mkdir(parents=True)
        data_path.chmod(0o755)
        init_hint = data_path.joinpath(Path(activation_hint).name)
        init_hint.touch()

        setup_grub(DIR_DST_ROOT)
        # add information about version
        grub.create_structure()
        grub.version_add(image_name, DIR_DST_ROOT)
        # PSL - grub.set_default(image_name, DIR_DST_ROOT)
        grub.set_current_default(image_name, DIR_DST_ROOT)
        grub.set_console_type(console_dict[console_type], DIR_DST_ROOT)

        # PSL - START check if default-firmware exists, removes it,  and copy over all system files
        default_image_name: str = 'default-firmware'
        path = Path(f'{DIR_DST_ROOT}/boot/{default_image_name}')

        print(f"Default firmware path is: {path}, default image name is: {default_image_name}")
        if path.exists():
            print(f"Removing existing default-firmware rootfs at: {path}")
            rmtree(path)

        print("Creating factory default-firmware installation")
        copytree(f"{DIR_KERNEL_SRC}/",
            f"{DIR_DST_ROOT}/boot/{default_image_name}/",
            dirs_exist_ok=True,
            symlinks=True)

        # tmppath = Path(f'{DIR_DST_ROOT}/boot/{default_image_name}/dtb')
        # if tmppath.exists():
        #     print(f"Pruning unused {default_image_name}/dtb directory")
        #     rmtree(tmppath, ignore_errors=True)

        tmppath = Path(f'{DIR_DST_ROOT}/boot/{default_image_name}/grub')
        if tmppath.exists():
            print(f"Pruning unused {default_image_name}/grub directory")
            rmtree(tmppath, ignore_errors=True)

        copy(FILE_ROOTFS_SRC,
            f'{DIR_DST_ROOT}/boot/{default_image_name}/default-firmware.squashfs')

        # dm-verity: baked initrd for the factory default-firmware entry too.
        if get_image_dm_verity() and Path(FILE_INITRD_SRC).exists():
            print('Installing dm-verity baked initrd for default-firmware')
            copy(FILE_INITRD_SRC,
                 f'{DIR_DST_ROOT}/boot/{default_image_name}/initrd.img')

            # secure-boot: carry detached signatures for the default-firmware
            # kernel + initrd too (best-effort; unsigned builds have no .sig).
            for _sig_src, _sig_dst in (
                (f'{FILE_INITRD_SRC}.sig',
                 f'{DIR_DST_ROOT}/boot/{default_image_name}/initrd.img.sig'),
                (FILE_KERNEL_SIG_SRC,
                 f'{DIR_DST_ROOT}/boot/{default_image_name}/vmlinuz.sig'),
            ):
                if Path(_sig_src).exists():
                    print(f'Installing boot signature {Path(_sig_dst).name}')
                    copy(_sig_src, _sig_dst)

        grub.version_add(default_image_name, DIR_DST_ROOT)
        grub.set_factory_default(default_image_name, DIR_DST_ROOT)
        # PSL - END check if default-firmware exists and copy over all system files

        if is_raid_install(install_target):
            # add RAID specific modules
            grub.modules_write(f'{DIR_DST_ROOT}/{grub.CFG_VYOS_MODULES}',
                               ['part_msdos', 'part_gpt', 'diskfilter',
                                'ext2','mdraid1x'])
        # install GRUB
        if is_raid_install(install_target):
            print('Installing GRUB to the drives')
            disks = install_target.disks
            for disk_target in disks:
                disk.partition_mount(disk_target.partition['efi'], f'{DIR_DST_ROOT}/boot/efi')
                # secure builds consume the prebuilt core (below) -- skip grub-install
                if not get_image_secure_grub():
                    grub.install(disk_target.name, f'{DIR_DST_ROOT}/boot/',
                                 f'{DIR_DST_ROOT}/boot/efi')
                install_secure_grub_core(f'{DIR_DST_ROOT}/boot/efi')
                disk.partition_umount(disk_target.partition['efi'])
        else:
            print('Installing GRUB to the drive')
            # secure builds consume the prebuilt core (below) -- skip grub-install
            if not get_image_secure_grub():
                grub.install(install_target.name, f'{DIR_DST_ROOT}/boot/',
                             f'{DIR_DST_ROOT}/boot/efi')
            install_secure_grub_core(f'{DIR_DST_ROOT}/boot/efi')

        # sort inodes (to make GRUB read config files in alphabetical order)
        grub.sort_inodes(f'{DIR_DST_ROOT}/{grub.GRUB_DIR_VYOS}')
        grub.sort_inodes(f'{DIR_DST_ROOT}/{grub.GRUB_DIR_VYOS_VERS}')

        # umount filesystems and remove temporary files
        if is_raid_install(install_target):
            cleanup([install_target.name],
                    ['/mnt/installation'])
        else:
            cleanup([install_target.partition['efi'],
                     install_target.partition['root']],
                    ['/mnt/installation'])

        # we are done
        print(MSG_INFO_INSTALL_SUCCESS)
        exit()

    except Exception as err:
        print(f'Unable to install VyOS: {err}')
        # unmount filesystems and cleanup
        try:
            if install_target is not None:
                if is_raid_install(install_target):
                    cleanup_raid(install_target)
                else:
                    cleanup([install_target.partition['efi'],
                             install_target.partition['root']],
                            ['/mnt/installation'])
        except Exception as err:
            print(f'Cleanup failed: {err}')

        exit(1)


def get_known_hosts_files(for_root=True, for_users=True) -> list:
    """Collect all existing `known_hosts` files for root and/or users under /home"""

    files = []

    if for_root:
        base_files = ('/root/.ssh/known_hosts', '/etc/ssh/ssh_known_hosts')
        for file_path in base_files:
            root_known_hosts = Path(file_path)
            if root_known_hosts.exists():
                files.append(root_known_hosts)

    if for_users:  # for each non-system user
        for user in get_local_users():
            home_dir = Path(get_user_home_dir(user))
            if home_dir.exists():
                known_hosts = home_dir / '.ssh' / 'known_hosts'
                if known_hosts.exists():
                    files.append(known_hosts)

    return files


def migrate_known_hosts(target_dir: str):
    """Copy `known_hosts` for root and all users to the new image directory"""

    def _mkdir_and_copy_file(known_hosts_file, target_known_hosts):
        target_known_hosts.parent.mkdir(parents=True, exist_ok=True)
        copy(known_hosts_file, target_known_hosts)

    # Copy root only files using default path
    known_hosts_files = get_known_hosts_files(for_root=True, for_users=False)
    for known_hosts_file in known_hosts_files:
        target_known_hosts = Path(f'{target_dir}{known_hosts_file}')
        _mkdir_and_copy_file(known_hosts_file, target_known_hosts)

    # During image installation, backup critical user-specific files (e.g., known_hosts)
    # from each user's home directory into /var/.users_backups/{user}. This ensures that their
    # SSH configuration and trust relationships are preserved across system re-installations
    # or provisioning.
    # More details: https://github.com/vyos/vyos-1x/pull/4678#pullrequestreview-3169648265
    known_hosts_files = get_known_hosts_files(for_root=False, for_users=True)
    for known_hosts_file in known_hosts_files:
        username = known_hosts_file.parent.parent.name
        base_dir = Path(f'{target_dir}/var/.users_backups/{username}')
        target_known_hosts = base_dir / '.ssh' / 'known_hosts'
        _mkdir_and_copy_file(known_hosts_file, target_known_hosts)


def _image_dm_verity(squashfs_file: str) -> bool | None:
    """Read the dm-verity flavor flag from an image's own squashfs.

    The GRUB entry for a newly added image must reflect THAT image's dm-verity
    setting, not the running system's, so upgrades and downgrades between
    verity and non-verity images seal (or unseal) correctly. dm-verity is
    integrity protection, not encryption, so the squashfs mounts read-only and
    stays readable offline even for sealed images.

    Returns None if the flag cannot be determined, letting the caller fall back
    to the running image's flavor.
    """
    if not Path(squashfs_file).exists():
        print(f'WARNING: dm-verity: image squashfs {squashfs_file} not found; '
              'cannot read its verity flag (grub entry falls back to the '
              'running image flavor)')
        return None
    try:
        with TemporaryDirectory() as squashfs_mounted:
            if not disk.partition_mount(squashfs_file, squashfs_mounted, 'squashfs'):
                print(f'WARNING: dm-verity: could not mount {squashfs_file} to '
                      'read its verity flag (grub entry falls back to the '
                      'running image flavor)')
                return None
            try:
                flavor_json = f'{squashfs_mounted}/usr/share/vyos/flavor.json'
                return get_image_dm_verity(fname=flavor_json)
            finally:
                disk.partition_umount(squashfs_file)
    except Exception as e:
        print(f'WARNING: dm-verity: error reading verity flag from '
              f'{squashfs_file}: {e} (grub entry falls back to the running '
              'image flavor)')
        return None


@compat.grub_cfg_update
def add_image(image_path: str, vrf: str = None, username: str = '',
              password: str = '', no_prompt: bool = False, force: bool = False) -> None:
    """Add a new image

    Args:
        image_path (str): a path to an ISO image
    """
    if image.is_live_boot():
        exit(MSG_ERR_LIVE)

    # Trying to upgrade with insufficient space can break the system.
    # It's better to be on the safe side:
    # our images are a bit below 1G,
    # so one gigabyte to download the image plus one more to install it
    # sounds like a sensible estimate.
    if disk_usage('/').free < (2 * 1024**3):
        exit(MSG_ERR_NOT_ENOUGH_SPACE)

    if unsaved_commits():
        if not no_prompt:
            if not ask_yes_no(MSG_INPUT_UNSAVED_COMMITS, default=False):
                exit()
        else:
            exit(MSG_ERR_UNSAVED_COMMITS)

    environ['REMOTE_USERNAME'] = username
    environ['REMOTE_PASSWORD'] = password

    # fetch an image
    iso_path: Path = image_fetch(image_path, vrf, no_prompt)
    try:
        # mount an ISO
        Path(DIR_ISO_MOUNT).mkdir(mode=0o755, parents=True)
        disk.partition_mount(iso_path, DIR_ISO_MOUNT, 'iso9660')

        print('Validating image compatibility')
        validate_compatibility(DIR_ISO_MOUNT, force=force)

        # check sums
        print('Validating image checksums')
        if not Path(DIR_ISO_MOUNT).joinpath('sha256sum.txt').exists():
            cleanup()
            exit(MSG_ERR_IMPROPER_IMAGE)
        if run(f'cd {DIR_ISO_MOUNT} && sha256sum --status -c sha256sum.txt'):
            cleanup()
            exit('Image checksum verification failed.')

        # mount rootfs (to get a system version)
        Path(DIR_ROOTFS_SRC).mkdir(mode=0o755, parents=True)
        disk.partition_mount(f'{DIR_ISO_MOUNT}/live/filesystem.squashfs',
                             DIR_ROOTFS_SRC, 'squashfs')

        cfg_ver: str = image.get_image_tools_version(DIR_ROOTFS_SRC)
        version_name: str = image.get_image_version(DIR_ROOTFS_SRC)

        disk.partition_umount(f'{DIR_ISO_MOUNT}/live/filesystem.squashfs')

        if cfg_ver < SYSTEM_CFG_VER:
            raise compat.DowngradingImageTools(
                f'Adding image would downgrade image tools to v.{cfg_ver}; disallowed')

        if not no_prompt:
            versions = grub.version_list()
            while True:
                image_name: str = ask_input(MSG_INPUT_IMAGE_NAME, version_name)
                if image_name in versions:
                    print(MSG_INPUT_IMAGE_NAME_TAKEN)
                    continue
                if image.validate_name(image_name):
                    break
                print(MSG_WARN_IMAGE_NAME_WRONG)
            set_as_default: bool = ask_yes_no(MSG_INPUT_IMAGE_DEFAULT, default=True)
        else:
            image_name: str = version_name
            set_as_default: bool = True

        # find target directory
        root_dir: str = disk.find_persistence()

        cmdline_options = []

        # a config dir. It is the deepest one, so the command will
        # create all the rest in a single step
        target_config_dir: str = f'{root_dir}/boot/{image_name}/rw{DIR_CONFIG}/'
        target_tpm_dir: str = f'{root_dir}/boot/{image_name}/rw{DIR_TPM_REEFS}/'
        # copy config
        if no_prompt or migrate_config():
            if Path('/dev/mapper/vyos_config').exists():
                print('Copying encrypted configuration volume')

                # Record information from which image we upgraded to the new one.
                # This can be used for a future automatic rollback into the old image.
                #
                # For encrypted config, we need to copy, sync filesystems and remove from current image
                tmp = {'previous_image' : image.get_running_image()}
                write_file('/opt/vyatta/etc/config/first_boot', dumps(tmp))
                sync()

                # Copy encrypted volumes
                current_name = image.get_running_image()
                current_config_path = f'{root_dir}/luks/{current_name}'
                target_config_path = f'{root_dir}/luks/{image_name}'
                copy(current_config_path, target_config_path)

                # Now remove from current image
                Path('/opt/vyatta/etc/config/first_boot').unlink()
            else:
                print('Copying configuration directory')
                # copytree preserves perms but not ownership:
                Path(target_config_dir).mkdir(parents=True)
                chown(target_config_dir, group='vyattacfg')
                chmod_2775(target_config_dir)
                copytree(f'{DIR_CONFIG}/', target_config_dir, symlinks=True,
                        copy_function=copy_preserve_owner, dirs_exist_ok=True)

                # Record information from which image we upgraded to the new one.
                # This can be used for a future automatic rollback into the old image.
                tmp = {'previous_image' : image.get_running_image()}
                write_file(f'{target_config_dir}/first_boot', dumps(tmp))

                print('Migrating TPM REEFS storage...')
                # copytree preserves perms but not ownership:
                Path(target_tpm_dir).mkdir(parents=True)
                chown(target_tpm_dir, group='root')
                # chmod_2775(target_tpm_dir)
                copytree(f'{DIR_TPM_REEFS}/', target_tpm_dir, symlinks=True,
                        copy_function=copy_preserve_owner, dirs_exist_ok=True)
        else:
            Path(target_config_dir).mkdir(parents=True)
            chown(target_config_dir, group='vyattacfg')
            chmod_2775(target_config_dir)
            Path(f'{target_config_dir}/.vyatta_config').touch()

        target_ssh_dir: str = f'{root_dir}/boot/{image_name}/rw/etc/ssh/'
        if no_prompt or copy_ssh_host_keys():
            print('Copying SSH host keys')
            Path(target_ssh_dir).mkdir(parents=True)
            host_keys: list[str] = glob('/etc/ssh/ssh_host*')
            for host_key in host_keys:
                copy(host_key, target_ssh_dir)

        target_ssh_known_hosts_dir: str = f'{root_dir}/boot/{image_name}/rw'
        if no_prompt or copy_ssh_known_hosts():
            print('Copying SSH known_hosts files')
            migrate_known_hosts(target_ssh_known_hosts_dir)

        # copy system image and kernel files
        print('Copying system image files')
        # PSL - copy all system files and symlinks, also rename the filesystem.squashfs
        copytree(f"{DIR_ISO_MOUNT}/live/",
                 f"{root_dir}/boot/{image_name}/",
                 dirs_exist_ok=True,
                 symlinks=True)
        move(f'{root_dir}/boot/{image_name}/filesystem.squashfs',
             f'{root_dir}/boot/{image_name}/{image_name}.squashfs')

        # Copy the image's DTBs when present -- no arch guard so 32-bit ARM (armhf)
        # works too; a natural no-op on x86, which ships no /boot/dtb.
        if Path(f"{DIR_ISO_MOUNT}/boot/dtb").exists():
            print('Copying DTB files')
            copytree(f"{DIR_ISO_MOUNT}/boot/dtb", f"{root_dir}/boot/{image_name}/dtb",
                     dirs_exist_ok=True, symlinks=True)

        # unmount an ISO and cleanup
        cleanup([str(iso_path)])

        # add information about version
        #
        # dm-verity: seal/unseal the GRUB entry to match the IMAGE BEING ADDED,
        # not the running one, by reading dm_verity from the new image's own
        # flavor.json inside its just-copied squashfs. Falls back to the running
        # image's flavor (version_add default) if it cannot be read.
        target_dm_verity = _image_dm_verity(
            f'{root_dir}/boot/{image_name}/{image_name}.squashfs')
        grub.version_add(image_name, root_dir, dm_verity=target_dm_verity)
        if set_as_default:
            # PSL - grub.set_default(image_name, root_dir)
            grub.set_current_default(image_name, root_dir)

        if Path(f'{target_config_dir}/config.boot').exists():
            cmdline_options = get_cli_kernel_options(
                f'{target_config_dir}/config.boot')
            grub_util.update_kernel_cmdline_options(' '.join(cmdline_options),
                                                    root_dir=root_dir,
                                                    version=image_name)

    except OSError as e:
        # if no space error, remove image dir and cleanup
        if e.errno == ENOSPC:
            cleanup(mounts=[str(iso_path)],
                    remove_items=[f'{root_dir}/boot/{image_name}'])
        else:
            # unmount an ISO and cleanup
            cleanup([str(iso_path)])
        exit(f'Error: {e}')

    except Exception as err:
        # unmount an ISO and cleanup
        cleanup([str(iso_path)])
        exit(f'Error: {err}')


def parse_arguments() -> Namespace:
    """Parse arguments

    Returns:
        Namespace: a namespace with parsed arguments
    """
    parser: ArgumentParser = ArgumentParser(
        description='Install new system images')
    parser.add_argument('--action',
                        choices=['install', 'add'],
                        required=True,
                        help='action to perform with an image')
    parser.add_argument('--vrf',
                        help='vrf name for image download')
    parser.add_argument('--no-prompt', action='store_true',
                        help='perform action non-interactively')
    parser.add_argument('--username', default='',
                        help='username for image download')
    parser.add_argument('--password', default='',
                        help='password for image download')
    parser.add_argument('--image-path',
        help='a path (HTTP or local file) to an image that needs to be installed'
    )
    parser.add_argument('--force', action='store_true',
        help='Ignore flavor compatibility requirements.'
    )
    # parser.add_argument('--image_new_name', help='a new name for image')
    args: Namespace = parser.parse_args()
    # Validate arguments
    if args.action == 'add' and not args.image_path:
        exit('A path to image is required for add action')

    return args


if __name__ == '__main__':
    try:
        args: Namespace = parse_arguments()
        if args.action == 'install':
            install_image()
        if args.action == 'add':
            add_image(args.image_path, args.vrf,
                      args.username, args.password,
                      args.no_prompt, args.force)
        sync()
        exit()

    except KeyboardInterrupt:
        print('Stopped by Ctrl+C')
        cleanup()
        exit()

    except Exception as err:
        exit(f'{err}')
