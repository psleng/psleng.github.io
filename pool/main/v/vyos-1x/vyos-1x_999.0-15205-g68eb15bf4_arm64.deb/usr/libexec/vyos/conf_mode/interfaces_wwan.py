#!/usr/bin/env python3
# Copyright (C) 2024-2026 Perle Systems Limited
# SPDX-License-Identifier: GPL-2.0-or-later
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# interfaces_wwan.py — VyOS conf_mode script for enhanced WWAN interface.
#
# Reads the VyOS config tree (set interfaces wwan wwanN …) and translates it
# into the nested dict expected by the WWAN FSM D-Bus service, then pushes the
# config via D-Bus SetConfiguration.
#
# This script replaces the upstream VyOS interfaces_wwan.py.

import asyncio
import ipaddress
import os
import re
import sys
import time

from vyos.config import Config
from vyos.configdict import get_interface_dict
from vyos.configverify import verify_vrf
from vyos.configverify import verify_mirror_redirect
from vyos.configverify import verify_mtu_ipv6
from vyos.ifconfig import WWANIf
from vyos.utils.network import interface_exists
from vyos.utils.process import call
from vyos import ConfigError
from vyos import airbag
airbag.enable()

service_name = 'ModemManager.service'
manager_unit = 'igos-wwan-manager.service'


def _ensure_manager_running():
    """Idempotently start the WWAN manager service.

    The manager unit has NO [Install] section -- it is never started by
    systemd at boot.  conf_mode is the sole start path:
      - At boot, vyos-router.service replays the saved config, which
        runs this conf_mode, which starts the manager.
      - On a live `commit`, this same path starts it.
    `systemctl start` is a no-op if the unit is already active.

    NOTE: `systemctl start` returns as soon as the unit is *activating*,
    not when the python service has finished initialising and claimed
    its well-known D-Bus name (com.igos.IgosModemManager).  Callers
    therefore must tolerate the bus name not being on the bus yet --
    that retry is implemented in `_apply_via_dbus`.

    While at least one wwan interface is configured the manager owns its
    own lifecycle.  When the LAST wwan interface is deleted, conf_mode
    stops the manager (which in turn stops ModemManager) via
    `_stop_manager_and_modemmanager()`; see apply().  On a reboot with no
    wwan configured, conf_mode simply does not start the manager, so MM
    also stays down.
    """
    call(f'systemctl start {manager_unit}')


def _stop_manager_and_modemmanager():
    """Stop the WWAN manager service and ModemManager.

    Invoked when the last `interfaces wwan` node is deleted.  Stopping the
    manager unit delivers SIGTERM, which runs the manager's graceful
    shutdown -- disconnect any remaining bearers, deregister from the
    network, tear down downstream LAN state -- and, because the manager is
    the sole owner of ModemManager's lifecycle, stops ModemManager as its
    final step.

    Order matters: the manager MUST be stopped first.  Its crash monitor
    polls ModemManager every ~10s and restarts it if it disappears, so
    stopping ModemManager on its own would not stick.  ModemManager is then
    stopped again explicitly as a backstop -- if the manager had already
    crashed it never got the chance to stop MM, and MM left running keeps
    the modem attached.  `systemctl stop` on an inactive unit is a harmless
    no-op, so the redundant call is safe.
    """
    call(f'systemctl stop {manager_unit}')
    call(f'systemctl stop {service_name}')

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _leaf(cfg, key, default=None):
    """Return a leaf value from a VyOS config dict, or *default*."""
    return cfg.get(key, default)


def _leaf_int(cfg, key, default=0):
    """Return a leaf value as int."""
    v = cfg.get(key)
    if v is None:
        return default
    return int(v)


def _leaf_exists(cfg, key):
    """True when a valueless node is present."""
    return key in cfg


def _csv_to_list(value, cast=str):
    """Split a comma-separated string into a list, stripping whitespace."""
    if not value:
        return []
    return [cast(x.strip()) for x in str(value).split(',') if x.strip()]


def _detect_passthrough_conflicts(conf, pt_iface):
    """Detect services/topology conflicting with an IP-passthrough LAN port.

    bind-interfaces dnsmasq instances spawned by the FSM will silently
    lose to (or steal from) any other DHCP/RA service running on the same
    LAN port, and cannot serve a bridge/bond slave.  Returns a conflict
    dict for verify() to turn into a clean ConfigError; empty dict when
    there is nothing to flag (including when *pt_iface* is unset).
    """
    if not pt_iface:
        return {}
    # dhcp-server conflict: only flag when *this* LAN interface is
    # explicitly listed as a listen-interface for some subnet.  The
    # previous predicate also matched any subnet that simply had
    # `default-router` set (which is true on virtually every
    # dhcp-server config) and produced false positives.
    dhcp_conflict = False
    if conf.exists(['service', 'dhcp-server', 'shared-network-name']):
        for sn in (conf.list_nodes(
                ['service', 'dhcp-server', 'shared-network-name']) or []):
            for s in (conf.list_nodes(
                    ['service', 'dhcp-server', 'shared-network-name',
                     sn, 'subnet']) or []):
                listen = conf.return_values(
                    ['service', 'dhcp-server', 'shared-network-name',
                     sn, 'subnet', s, 'listen-interface']) or []
                if pt_iface in listen:
                    dhcp_conflict = True
                    break
            if dhcp_conflict:
                break
    # Bridge / bond membership conflict: a passthrough interface
    # MUST be a standalone wired LAN port — a bind-interfaces dnsmasq
    # cannot serve a slave of a bridge or bond.
    bridge_master = None
    for br in (conf.list_nodes(['interfaces', 'bridge']) or []):
        members = conf.list_nodes(
            ['interfaces', 'bridge', br, 'member', 'interface']) or []
        if pt_iface in members:
            bridge_master = br
            break
    bond_master = None
    for bn in (conf.list_nodes(['interfaces', 'bonding']) or []):
        members = conf.list_nodes(
            ['interfaces', 'bonding', bn, 'member', 'interface']) or []
        if pt_iface in members:
            bond_master = bn
            break
    return {
        'dhcp_server': dhcp_conflict,
        'dhcpv6_server': conf.exists(
            ['service', 'dhcpv6-server', 'shared-network-name']
        ),
        'router_advert': conf.exists(
            ['service', 'router-advert', 'interface', pt_iface]
        ),
        'bridge_master': bridge_master,
        'bond_master': bond_master,
    }


def _detect_ipv6_bridging_conflicts(conf, brg_iface):
    """Detect bridge/bond enslavement of an ipv6-bridging target interface.

    If the user points ipv6-bridging at a physical interface that is
    itself enslaved in a bridge or bond, the address would be added to a
    slave that does not carry L3 — SLAAC clients on the actual master
    would see nothing useful.  Returns a conflict dict for verify();
    empty dict when there is nothing to flag (including when *brg_iface*
    is unset).
    """
    if not brg_iface:
        return {}
    brg_bridge_master = None
    for br in (conf.list_nodes(['interfaces', 'bridge']) or []):
        if br == brg_iface:
            continue  # targeting the bridge itself is fine
        members = conf.list_nodes(
            ['interfaces', 'bridge', br, 'member', 'interface']) or []
        if brg_iface in members:
            brg_bridge_master = br
            break
    brg_bond_master = None
    for bn in (conf.list_nodes(['interfaces', 'bonding']) or []):
        if bn == brg_iface:
            continue  # targeting the bond itself is fine
        members = conf.list_nodes(
            ['interfaces', 'bonding', bn, 'member', 'interface']) or []
        if brg_iface in members:
            brg_bond_master = bn
            break
    return {
        'bridge_master': brg_bridge_master,
        'bond_master': brg_bond_master,
    }


def _passthrough_user_eth_addresses(conf, pt_iface):
    """Return user-set `interfaces ethernet <pt_iface> address` values.

    Drives IP-passthrough Policy B: when the user has assigned explicit
    addresses to the passthrough port, the FSM must NOT auto-provision a
    management address (user wins).  Returns [] when none are set.
    """
    if not pt_iface:
        return []
    eth_path = ['interfaces', 'ethernet', pt_iface, 'address']
    if conf.exists(eth_path):
        return conf.return_values(eth_path) or []
    return []


# ---------------------------------------------------------------------------
# get_config  — read the VyOS tree and return raw dict
# ---------------------------------------------------------------------------

def get_config(config=None):
    if config:
        conf = config
    else:
        conf = Config()

    base = ['interfaces', 'wwan']

    # get_interface_dict() handles VYOS_TAGNODE_VALUE, deleted detection,
    # key_mangling, defaults, and populates change-tracking keys needed by
    # Interface.update(): address_old, eui64_old, mac_old, is_bridge_member,
    # is_bond_member, is_mirror_intf, qos, etc.
    ifname, wwan = get_interface_dict(conf, base)

    # Configd-compatible scripts must create their sole Config instance in
    # get_config().  Capture whether a deleted interface was the final WWAN
    # node while that proposed config tree is still available, then carry the
    # result to apply() instead of opening a second configuration session.
    wwan['_last_wwan'] = (
        'deleted' in wwan and not conf.exists(base)
    )

    # `disable` is implemented as a delete-style teardown (see apply()).  Work
    # out here — while the proposed config tree is live — whether disabling
    # THIS interface leaves no enabled wwan interface remaining, so apply()
    # can stop ModemManager exactly as deleting the last interface does.
    _this_iface_disabled = conf.exists(base + [ifname, 'disable'])
    _all_wwan = conf.list_nodes(base) if conf.exists(base) else []
    _any_enabled_remaining = any(
        not conf.exists(base + [n, 'disable']) for n in _all_wwan
    )
    wwan['_disable_last_active'] = (
        _this_iface_disabled and not _any_enabled_remaining
    )

    # ── Live-tree intent flags ───────────────────────────────────────
    # get_interface_dict() merges XML <defaultValue> tags into the parsed
    # dict regardless of whether the user actually configured the parent
    # node.  For optional features (e.g. ip-passthrough), defaulted sub-leaves
    # would otherwise look indistinguishable from user-configured values.
    # We therefore stash explicit "the user touched this" flags here, sourced
    # from the live config tree, so verify() can reason about user intent
    # without being fooled by phantom defaults.
    iface_base = base + [ifname]
    wwan['_user_set'] = {
        'ip_passthrough': conf.exists(iface_base + ['ip-passthrough']),
        'ip_passthrough_interface': conf.exists(
            iface_base + ['ip-passthrough', 'interface']
        ),
        'ipv6_bridging_interface': conf.exists(
            iface_base + ['ipv6-bridging', 'interface']
        ),
        # IPv6 management-address — opt-in feature.  Presence of the
        # `management-address` node enables stamping; otherwise the FSM
        # leaves wwanN address-only.  `disable-default-https` is a
        # node-level flag that suppresses the auto-permit for TCP 443.
        'ipv6_mgmt_addr_configured': conf.exists(
            iface_base + ['ipv6', 'management-address']
        ),
        'ipv6_mgmt_addr_disable_default_https': conf.exists(
            iface_base + ['ipv6', 'management-address', 'disable-default-https']
        ),
        # DHCPv6 prefix delegation — when set, the FSM-installed egress
        # hygiene chain must permit DHCPv6 client traffic (UDP/546) so
        # dhcp6c can solicit an IA_PD from the carrier.  Otherwise the
        # chain drops it as forbidden upstream chatter.
        'dhcpv6_pd': conf.exists(iface_base + ['dhcpv6-options', 'pd']),
        # IPv4 routing parameters that fight DOCSIS-style ip-passthrough.
        # Passthrough forwards inbound carrier-IP packets that arrive on
        # wwanN out the LAN port (asymmetric path) and so REQUIRES IPv4
        # forwarding on, and must NOT have strict reverse-path filtering on
        # wwanN.  `ip disable-forwarding` and `ip source-validation strict`
        # silently break it — verify() refuses the combination.
        'ip_disable_forwarding': conf.exists(
            iface_base + ['ip', 'disable-forwarding']
        ),
        'ip_source_validation': (
            conf.return_value(iface_base + ['ip', 'source-validation'])
            if conf.exists(iface_base + ['ip', 'source-validation'])
            else None
        ),
        # VRF assignment of wwanN.  Both ip-passthrough and ipv6-bridging
        # splice the cellular bearer to a separate LAN interface that lives
        # in the default VRF; confining wwanN to a non-default VRF table
        # breaks that cross-interface path — verify() refuses the combo.
        'vrf': (
            conf.return_value(iface_base + ['vrf'])
            if conf.exists(iface_base + ['vrf'])
            else None
        ),
    }

    # Per-SIM data-limit live-tree presence flags.
    #
    # get_interface_dict() merges XML defaults, so absent per-SIM leaves can
    # appear as if configured (e.g. size=0/action=none). That breaks intended
    # global data-usage fallback semantics because those default-injected
    # values would override globals. Capture explicit user-set presence from
    # the live tree and use it in build_fsm_config() to decide overrides.
    sim_dl_flags = {}
    for slot_num in (1, 2):
        slot = str(slot_num)
        dl_path = iface_base + ['sim', 'slot', slot, 'data-limit']
        sim_dl_flags[slot] = {
            'node': conf.exists(dl_path),
            'size': conf.exists(dl_path + ['size']),
            'action': conf.exists(dl_path + ['action']),
            'billing_date': conf.exists(dl_path + ['billing-date']),
            'warning': conf.exists(dl_path + ['warning']),
        }
    wwan['_sim_data_limit_user_set'] = sim_dl_flags

    # ── Conflict guards (computed here while the Config object is live) ───
    # IP-passthrough: bind-interfaces dnsmasq cannot coexist with another
    # DHCP/RA service on, or bridge/bond enslavement of, the same LAN port.
    # Resolved to a clean ConfigError in verify().
    pt_iface_lookup = None
    if wwan['_user_set']['ip_passthrough_interface']:
        pt_iface_lookup = conf.return_value(
            iface_base + ['ip-passthrough', 'interface']
        )
    wwan['_passthrough_conflicts'] = _detect_passthrough_conflicts(
        conf, pt_iface_lookup
    )

    # ipv6-bridging: target must be the L3-owning interface, not a
    # bridge/bond slave.
    brg_iface_lookup = None
    if wwan['_user_set']['ipv6_bridging_interface']:
        brg_iface_lookup = conf.return_value(
            iface_base + ['ipv6-bridging', 'interface']
        )
    wwan['_ipv6_bridging_conflicts'] = _detect_ipv6_bridging_conflicts(
        conf, brg_iface_lookup
    )

    # ── IP Passthrough — Policy B coexistence check ──────────────────────
    # If the user designated a passthrough interface AND has set an explicit
    # 'interfaces ethernet <if> address ...', the FSM must NOT auto-provision
    # a management address (user wins).  Stamp the result into the dict so
    # build_fsm_config() can emit the correct policy decision.
    ipt = wwan.get('ip_passthrough', {}) or {}
    pt_iface = ipt.get('interface') if isinstance(ipt, dict) else None
    if pt_iface and wwan['_user_set']['ip_passthrough_interface']:
        wwan.setdefault('ip_passthrough', {})['_user_eth_addresses'] = \
            _passthrough_user_eth_addresses(conf, pt_iface)

    return wwan


# ---------------------------------------------------------------------------
# build_fsm_config  — translate VyOS dict → FSM nested dict
# ---------------------------------------------------------------------------

def _build_ipv6_bridging(wwan):
    """Build the FSM ipv6_bridging sub-dict (carrier /64 to one LAN)."""
    brg = wwan.get('ipv6_bridging', {}) or {}
    brg_iface = brg.get('interface') if isinstance(brg, dict) else None
    # RFC 4861 Router Advertisement timers (operator-tunable renumber speed).
    ra = (brg.get('router_advert', {}) or {}) if isinstance(brg, dict) else {}
    return {
        'enabled': bool(brg_iface) and wwan['_user_set']['ipv6_bridging_interface'],
        'interface': brg_iface or '',
        'reconciliation_interval': _leaf_int(brg, 'reconciliation_interval', 10),
        'translate_prefix': _leaf(brg, 'translate_prefix', '') or '',
        'ra_min_interval': _leaf_int(ra, 'min_interval', 3),
        'ra_max_interval': _leaf_int(ra, 'max_interval', 10),
        'ra_preferred_lifetime': _leaf_int(ra, 'preferred_lifetime', 1800),
        'ra_valid_lifetime': _leaf_int(ra, 'valid_lifetime', 3600),
    }


def _build_ipv6_management_address(wwan):
    """Build the FSM ipv6_management_address sub-dict.

    Opt-in: enabled only when the user creates the `management-address`
    node.  When enabled the FSM stamps <prefix>::host-id on wwanN and
    installs an ip6tables chain that permits ICMPv6, ESTABLISHED/RELATED,
    and (unless `disable-default-https` is set) TCP 443.  Additional
    ports are opened via permit-tcp / permit-udp; permit-source narrows
    every permit (including the default-443) to listed source prefixes.
    Mutually exclusive with `ip-passthrough` (verify() refuses both).
    """
    ipv6_mgmt_node = (wwan.get('ipv6', {}) or {}).get('management_address', {}) or {}

    def _as_list(v):
        if not v:
            return []
        return v if isinstance(v, list) else [v]

    mgmt_configured = wwan['_user_set'].get('ipv6_mgmt_addr_configured', False)
    return {
        'enabled': mgmt_configured and (not wwan['_user_set'].get('ip_passthrough')),
        'host_id': _leaf(ipv6_mgmt_node, 'host_id', '::1'),
        'disable_default_https': wwan['_user_set'].get(
            'ipv6_mgmt_addr_disable_default_https', False),
        'permit_tcp': [int(p) for p in _as_list(ipv6_mgmt_node.get('permit_tcp'))],
        'permit_udp': [int(p) for p in _as_list(ipv6_mgmt_node.get('permit_udp'))],
        'permit_source': _as_list(ipv6_mgmt_node.get('permit_source')),
    }


def _build_ip_passthrough(wwan):
    """Build the FSM ip_passthrough sub-dict (DOCSIS-modem-style).

    Returns ``{'enabled': False}`` when no passthrough interface is set.
    """
    ipt = wwan.get('ip_passthrough', {}) or {}
    pt_iface = ipt.get('interface') if isinstance(ipt, dict) else None
    if not pt_iface:
        return {'enabled': False}

    # RFC 4861 RA tuning sub-node (dnsmasq ra-param + SLAAC/DHCPv6 lifetime).
    ra = (ipt.get('router_advert', {}) or {}) if isinstance(ipt, dict) else {}

    # Policy B: only emit a default mgmt address when the user has NOT
    # set 'interfaces ethernet <if> address ...' on the passthrough port.
    user_eth_addrs = ipt.get('_user_eth_addresses') or []
    user_owns_eth = bool(user_eth_addrs)
    mgmt_v4_cidr = (
        '' if user_owns_eth else (
            _leaf(
                ipt,
                'passthrough_management_address',
                _leaf(ipt, 'management_address', '192.168.200.1/24')
            )
        )
    )
    mgmt_v6_cidr = (
        '' if user_owns_eth else (
            _leaf(
                ipt,
                'passthrough_management_address_ipv6',
                _leaf(ipt, 'management_address_ipv6', 'fd00:6c61:6e30::1/64')
            )
        )
    )

    # Pre-resolve bare-IP forms (no /CIDR) for use as DHCPv4 option 3
    # router and DHCPv6 advertised gateway.  RFC-strict clients (Windows)
    # reject leases with router=0.0.0.0, so we always supply a real IP
    # when one is available — either FSM-owned default or the user's
    # first ethernet address under Policy B.
    def _bare_ip(cidr: str, want_v6: bool = False) -> str:
        if not cidr:
            return ''
        try:
            ip = ipaddress.ip_interface(cidr).ip
        except (ValueError, TypeError):
            return ''
        if want_v6 and ip.version != 6:
            return ''
        if not want_v6 and ip.version != 4:
            return ''
        return str(ip)

    if user_owns_eth:
        mgmt_v4_ip = next(
            (_bare_ip(a) for a in user_eth_addrs if _bare_ip(a)), '')
        mgmt_v6_ip = next(
            (_bare_ip(a, want_v6=True) for a in user_eth_addrs
             if _bare_ip(a, want_v6=True)), '')
    else:
        mgmt_v4_ip = _bare_ip(mgmt_v4_cidr)
        mgmt_v6_ip = _bare_ip(mgmt_v6_cidr, want_v6=True)

    return {
        'enabled': True,
        'interface': pt_iface,
        'mac': _leaf(ipt, 'mac', '') or '',
        'lease_time': _leaf_int(ipt, 'lease_time', 60),
        'management_address': mgmt_v4_cidr,
        'management_address_ipv6': mgmt_v6_cidr,
        'mgmt_owned_by_user': user_owns_eth,
        'mgmt_v4_ip': mgmt_v4_ip,
        'mgmt_v6_ip': mgmt_v6_ip,
        # TCP MSS clamping on WWAN egress — ON by default,
        # industry-standard for cellular CPE passthrough.
        # Transparently fixes non-compliant downstream
        # clients that ignore DHCP option 26 / RA MTU.  Disable only for
        # PMTUD debugging.
        'mss_clamp_enabled': not _leaf_exists(ipt, 'disable_mss_clamp'),
        # Legacy DHCPv4 compatibility mode (OFF by default): advertise a
        # same-subnet router/netmask and suppress classless static route
        # option 121 for older clients that ignore RFC 3442.
        'legacy_dhcpv4_compat': _leaf_exists(ipt, 'legacy_dhcpv4_compat'),
        # Optional user-supplied DNS override (multi-value). When set,
        # these resolvers are advertised to the downstream device in
        # place of carrier-supplied DNS.
        'dns_servers': (
            ipt.get('dns_server')
            if isinstance(ipt.get('dns_server'), list)
            else ([ipt.get('dns_server')] if ipt.get('dns_server') else [])
        ),
        # RFC 4861 RA tuning (dnsmasq ra-param + SLAAC/DHCPv6 prefix lifetime).
        # prefix_lifetime 0 = fall back to the DHCP lease-time (current behaviour).
        'ra_interval': _leaf_int(ra, 'interval', 60),
        'ra_router_lifetime': _leaf_int(ra, 'router_lifetime', 1800),
        'ra_prefix_lifetime': _leaf_int(ra, 'prefix_lifetime', 0),
    }


def build_fsm_config(wwan):
    """Produce the config dict expected by the FSM D-Bus SetConfiguration."""

    # ── SIM slots ────────────────────────────────────────────────────────
    sim_cfg = wwan.get('sim', {})
    slot_cfgs = sim_cfg.get('slot', {})
    sim_dl_user_set = wwan.get('_sim_data_limit_user_set', {}) or {}

    # Global data-usage fallback values
    du = wwan.get('data_usage', {})
    global_data_limit_size = _leaf_int(du, 'size', 0)
    global_data_limit_action = _leaf(du, 'action', 'none')
    global_data_limit_billing = _leaf_int(du, 'billing_date', 1)
    global_data_limit_warning = _csv_to_list(du.get('warning', ''), int)

    # Both SIM slots are present and enabled by default. The CLI only
    # overrides per-slot settings; presence (or absence) of `slot N` in
    # the config tree does NOT determine enablement — only the explicit
    # `slot N disable` leaf disables a slot.
    sim_slots = []
    for slot_num in (1, 2):
        s = slot_cfgs.get(str(slot_num), {})
        dl = s.get('data_limit', {})
        dl_user = sim_dl_user_set.get(str(slot_num), {}) or {}
        sim_slots.append({
            'slot': slot_num,
            'enabled': not _leaf_exists(s, 'disable'),
            'apn': _leaf(s, 'apn', ''),
            'username': _leaf(s, 'username', ''),
            'password': _leaf(s, 'password', ''),
            'auth_type': _leaf(s, 'auth_type', 'none'),
            'pdp_type': _leaf(s, 'pdp_type', 'ipv4v6'),
            # Roaming is enabled by default; CLI 'disable-roaming' leaf turns it off.
            # Many aggregator/MVNO SIMs (e.g. roaming-style Rogers-on-Bell) only
            # connect when roaming is permitted, so 'enabled' is the safe default.
            'roaming': 'disabled' if _leaf_exists(s, 'disable_roaming') else 'enabled',
            'pin': _leaf(s, 'pin', ''),
            'puk': _leaf(s, 'puk', ''),
            'iccid': _leaf(s, 'iccid', ''),
            'supported_bands': _csv_to_list(
                _leaf(s, 'supported_bands', 'all')
            ),
            'preferred_carrier': _leaf(s, 'preferred_carrier', ''),
            'enable_network_scan': _leaf_exists(s, 'enable_network_scan'),
            'mtu': _leaf_int(s, 'mtu', 0),
            # Per-SIM data limits, falling back to global
            # IMPORTANT: use live-tree presence flags so XML default-injected
            # per-SIM values do not mask global data-usage settings.
            'data_limit_size': (
                _leaf_int(dl, 'size', global_data_limit_size)
                if dl_user.get('size') else global_data_limit_size
            ),
            'data_limit_action': (
                _leaf(dl, 'action', global_data_limit_action)
                if dl_user.get('action') else global_data_limit_action
            ),
            'data_limit_billing_date': (
                _leaf_int(dl, 'billing_date', global_data_limit_billing)
                if dl_user.get('billing_date') else global_data_limit_billing
            ),
            'data_limit_warning': (
                _csv_to_list(dl.get('warning', ''), int)
                if dl_user.get('warning') and dl.get('warning')
                else global_data_limit_warning
            ),
        })

    # ── Connectivity monitoring ──────────────────────────────────────────
    cm = wwan.get('connectivity_monitoring', {})
    connectivity_monitoring = {
        'enabled': not _leaf_exists(cm, 'disable'),
        'interval': _leaf_int(cm, 'interval', 60),
        'timeout': _leaf_int(cm, 'timeout', 10),
        'retry_count': _leaf_int(cm, 'retry_count', 3),
        'failure_threshold': _leaf_int(cm, 'failure_threshold', 2),
        'test_ipv4': not _leaf_exists(cm, 'disable_test_ipv4'),
        'test_ipv6': _leaf_exists(cm, 'test_ipv6'),
        'require_both': _leaf_exists(cm, 'require_both'),
        'ipv4_targets': _csv_to_list(
            _leaf(cm, 'ipv4_targets', '8.8.8.8,1.1.1.1')
        ),
        'ipv6_targets': _csv_to_list(
            _leaf(cm, 'ipv6_targets',
                  '2001:4860:4860::8888,2606:4700:4700::1111')
        ),
    }

    # ── Interface management ─────────────────────────────────────────────
    im = wwan.get('interface_management', {})
    interface_management = {
        'enabled': not _leaf_exists(im, 'disable'),
        'bearer_disconnect_delay': _leaf_int(im, 'bearer_disconnect_delay', 15),
        'registration_recovery_delay': _leaf_int(
            im, 'registration_recovery_delay', 20
        ),
        'registration_flap_count': _leaf_int(im, 'registration_flap_count', 5),
        'registration_flap_window': _leaf_int(
            im, 'registration_flap_window', 360
        ),
        'ip_change_delay': _leaf_int(im, 'ip_change_delay', 500),
        'ensure_link_up_on_connect': not _leaf_exists(
            im, 'disable_ensure_link_up_on_connect'
        ),
        'monitor_bearer_state': not _leaf_exists(
            im, 'disable_monitor_bearer_state'
        ),
        'monitor_ip_changes': not _leaf_exists(
            im, 'disable_monitor_ip_changes'
        ),
        'interface_up_timeout': _leaf_int(im, 'interface_up_timeout', 10),
    }

    # ── Enhanced reconnection ────────────────────────────────────────────
    rc = wwan.get('reconnection', {})
    ri = rc.get('retry_interval', {})
    rc_st = rc.get('signal_threshold', {})
    enhanced_reconnection = {
        'enabled': not _leaf_exists(rc, 'disable_enhanced'),
        'signal_threshold_rssi': _leaf_int(rc_st, 'rssi', -85),
        'signal_threshold_rsrp': _leaf_int(rc_st, 'rsrp', -105),
        'retry_interval_good_signal': _leaf_int(ri, 'good_signal', 30),
        'retry_interval_poor_signal': _leaf_int(ri, 'poor_signal', 120),
        'max_wait_for_signal': _leaf_int(rc, 'max_wait_for_signal', 120),
        'signal_check_interval': _leaf_int(rc, 'signal_check_interval', 10),
        'signal_strength_buffer': _leaf_int(rc, 'signal_strength_buffer', 5),
    }

    # ── Failed-state retry ───────────────────────────────────────────────
    fr = wwan.get('failed_retry', {})
    failed_retry = {
        'enabled': not _leaf_exists(fr, 'disable'),
        'intervals': _csv_to_list(
            _leaf(fr, 'intervals', '30,60,120,300,600,1800,3600'), int
        ),
        'max_interval': _leaf_int(fr, 'max_interval', 7200),
        'escalation_threshold': _leaf_int(fr, 'escalation_threshold', 3),
    }

    # ── SIM failover ─────────────────────────────────────────────────────
    sf = sim_cfg.get('sim_failover', {})
    fb = sim_cfg.get('sim_failback', {})

    # ── IPv6 bridging (carrier /64 to one downstream LAN) ────────────────
    ipv6_bridging = _build_ipv6_bridging(wwan)

    # ── IPv6 management-address (FSM-stamped <prefix>::host-id on wwanN) ─
    ipv6_management_address = _build_ipv6_management_address(wwan)

    # ── Timeouts ─────────────────────────────────────────────────────────
    to = wwan.get('timeouts', {})

    # ── Logging ──────────────────────────────────────────────────────────
    lg = wwan.get('logging', {})

    # ── IP Passthrough (DOCSIS-modem-style) ──────────────────────────────
    ip_passthrough = _build_ip_passthrough(wwan)

    # ── Assemble the complete config dict ────────────────────────────────
    config = {
        # Basic interface settings
        'primary_sim_slot': _leaf_int(sim_cfg, 'primary_slot', 1),
        'connection_mode': _leaf(wwan, 'connection_mode', 'always-on'),

        # MTU
        'mtu': _leaf_int(wwan, 'mtu', 1420),

        # Default route metric — metric for the carrier-assigned default
        # route(s) the FSM installs on wwanN.  Default 220 keeps cellular
        # below a wired primary (failover/static metric 1, DHCP 210), so the
        # modem is a backup, not the preferred path.  0 = always-preferred.
        'default_route_metric': _leaf_int(wwan, 'default_route_metric', 220),

        # Enhanced reconnection
        'enhanced_reconnection': enhanced_reconnection,

        # APN discovery
        'android_apn_discovery': (
            'disabled' if _leaf_exists(
                wwan.get('apn_discovery', {}), 'disable'
            ) else 'enabled'
        ),

        # SIM failover (global enable + policy)
        'sim_failover': (
            'disabled' if _leaf_exists(sf, 'disable') else 'enabled'
        ),
        'sim_failover_connect_retries': _leaf_int(
            sf, 'connect_retries', 3
        ),
        'sim_failover_signal_loss_timer': _leaf_int(
            sf, 'signal_loss_timer', 60
        ),
        'sim_failover_signal_threshold_rssi': _leaf_int(
            sf.get('signal_threshold', {}), 'rssi', -93
        ),
        'sim_failover_signal_threshold_rsrp': _leaf_int(
            sf.get('signal_threshold', {}), 'rsrp', -113
        ),

        # SIM failback
        'sim_failback_enabled': not _leaf_exists(fb, 'disable'),
        'sim_failback_stability_time': _leaf_int(fb, 'stability_time', 300),
        'sim_failback_check_interval': _leaf_int(
            fb, 'check_interval', 600
        ),

        # Data usage (global monitoring interval)
        'data_usage_monitoring_interval': _leaf_int(
            du, 'monitoring_interval', 30
        ),

        # Hardware reset
        'hardware_reset_enabled': not _leaf_exists(
            wwan.get('hardware_reset', {}), 'disable'
        ),
        'max_hardware_resets': _leaf_int(
            wwan.get('hardware_reset', {}), 'max_attempts', 3
        ),
        'hardware_reset_cooldown': _leaf_int(
            wwan.get('hardware_reset', {}), 'cooldown', 300
        ),

        # Connection and timeout settings
        'connection_timeout': _leaf_int(to, 'connection', 120),
        'registration_timeout': _leaf_int(to, 'registration', 180),
        'network_scan_timeout': _leaf_int(
            wwan.get('network_scan', {}), 'timeout', 180
        ),
        'network_mode': _leaf(wwan, 'network_mode', 'auto'),

        # Network time (NITZ) — opt-in: set the system clock from cellular
        # network time at registration (guarded so it never overrides NTP).
        'network_time_enabled': _leaf_exists(wwan, 'network_time'),
        # Re-sync cadence for drift correction (NAS signaling, no data traffic).
        'network_time_update_interval': _leaf_int(
            wwan.get('network_time', {}) or {}, 'update_interval', 3600
        ),

        # Monitoring intervals
        'normal_monitoring_interval': _leaf_int(
            to, 'normal_monitoring_interval', 30
        ),

        # Logging
        'verbose_logging': not _leaf_exists(lg, 'disable_verbose'),
        'log_level': _leaf(lg, 'level', 'info'),
        'log_sink': _leaf(lg, 'sink', 'both'),

        # Collections
        'sim_slots': sim_slots,
        'connectivity_monitoring': connectivity_monitoring,
        'interface_management': interface_management,
        'failed_retry': failed_retry,

        # IPv6 bridging (carrier /64 -> one downstream LAN; mutually exclusive
        # with ip-passthrough — see verify())
        'ipv6_bridging': ipv6_bridging,

        # IPv6 management-address (FSM-stamped <prefix>::host-id on wwanN;
        # mutually exclusive with ip-passthrough — see verify())
        'ipv6_management_address': ipv6_management_address,

        # IP Passthrough (mutually exclusive with ipv6-bridging — see verify())
        'ip_passthrough': ip_passthrough,

        # DHCPv6 PD configured — gates the egress-hygiene chain so DHCPv6
        # client traffic (UDP/546) is allowed upstream.  Derived from the
        # live-tree existence of `dhcpv6-options pd` (see _user_set).
        'dhcpv6_pd_enabled': bool(wwan['_user_set'].get('dhcpv6_pd')),
    }

    return config


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

def verify(wwan):
    if 'deleted' in wwan:
        return None

    verify_vrf(wwan)
    verify_mtu_ipv6(wwan)
    verify_mirror_redirect(wwan)

    user_set = wwan.get('_user_set', {})

    # ── Bearer IPv6-prefix consumers are mutually exclusive ──────────────
    # ip-passthrough, ipv6-bridging, ipv6 management-address and DHCPv6 PD
    # (dhcpv6-options pd) each lay claim to the carrier-assigned IPv6 prefix,
    # so at most one may be active.  The first three all read the bearer's
    # ModemManager Ip6Config prefix directly; DHCPv6 PD runs dhcp6c, which
    # in practice is delegated the same carrier /64 by most cellular
    # networks — so we enforce a single-consumer policy rather than gamble
    # on carrier-specific prefix sizing.  Centralised here (rather than as
    # pairwise checks) so the invariant is declarative and a fifth consumer
    # is a one-line addition.  Keyed on the live-tree intent flags: a
    # passthrough node without an `interface` is inert (and is reported by
    # the dedicated check below), so it does not count as a consumer here —
    # this preserves the historical behaviour where exclusivity errors only
    # surfaced once passthrough had an interface.
    prefix_consumers = {
        'ip-passthrough': user_set.get('ip_passthrough_interface'),
        'ipv6-bridging': user_set.get('ipv6_bridging_interface'),
        'ipv6 management-address': user_set.get('ipv6_mgmt_addr_configured'),
        'dhcpv6-options pd': user_set.get('dhcpv6_pd'),
    }
    active_consumers = [name for name, on in prefix_consumers.items() if on]
    if len(active_consumers) > 1:
        raise ConfigError(
            f"{', '.join(active_consumers)} are mutually exclusive — each "
            f"consumes the bearer's carrier-assigned IPv6 prefix.  "
            f"Configure only one."
        )

    # ── ip-passthrough is incompatible with dial-on-demand ───────────────
    # Passthrough leases the carrier-assigned IP straight through to a
    # downstream device (DOCSIS-modem style); the downstream NIC owns that
    # public address.  dial-on-demand hands an external app a D-Bus
    # disconnect_bearer() lever that can tear the bearer down at any time —
    # which would yank the carrier IP out from under the downstream device,
    # leaving it with a stale lease and a black-holed default route until
    # its next renewal, and race the passthrough dnsmasq/policy-routing
    # teardown against the operator's connect/disconnect calls.  Passthrough
    # assumes an always-up bearer, so only always-on is permitted.  Reject
    # the combination at commit time.
    if (wwan.get('connection_mode') == 'dial-on-demand'
            and user_set.get('ip_passthrough_interface')):
        raise ConfigError(
            "ip-passthrough cannot be used with connection-mode "
            "dial-on-demand — passthrough leases the carrier IP to a "
            "downstream device and assumes an always-up bearer, but "
            "dial-on-demand allows the bearer to be torn down on demand, "
            "stranding the downstream device with a stale lease.  Use "
            "connection-mode always-on with ip-passthrough."
        )

    # ── VRF is incompatible with prefix-to-LAN stitching features ────────
    # ip-passthrough and ipv6-bridging both splice the cellular bearer onto
    # a separate LAN interface (passthrough policy-routes inbound carrier-IP
    # packets out the LAN port; bridging lands the carrier /64 on the LAN
    # L3 interface).  That stitching lives in the default VRF.  Placing
    # wwanN into a non-default VRF confines its routes and forwarding to
    # that VRF's table, severing the cross-interface path so the feature
    # comes up but never passes traffic.  Reject the combination at commit
    # time rather than ship a config that looks valid but silently fails.
    if user_set.get('vrf'):
        vrf_blockers = [
            name for name, on in (
                ('ip-passthrough', user_set.get('ip_passthrough_interface')),
                ('ipv6-bridging', user_set.get('ipv6_bridging_interface')),
            ) if on
        ]
        if vrf_blockers:
            raise ConfigError(
                f"{' and '.join(vrf_blockers)} cannot be used while the "
                f"WWAN interface is assigned to VRF "
                f"'{user_set['vrf']}' — these features bridge the bearer to "
                f"a LAN interface in the default VRF, and a non-default VRF "
                f"confines wwanN's routing so the path never completes.  "
                f"Remove the 'vrf' assignment or disable the feature."
            )

    # ── IP Passthrough verification ──────────────────────────────────────
    # Reason about user intent via live-tree flags stashed by get_config(),
    # not the defaults-merged dict (XML <defaultValue> tags would otherwise
    # make unconfigured sub-leaves indistinguishable from user-set ones).
    if user_set.get('ip_passthrough'):
        if not user_set.get('ip_passthrough_interface'):
            raise ConfigError(
                "ip-passthrough sub-options require 'ip-passthrough "
                "interface <eth>' to be set first."
            )
        # Conflict guard: bind-interfaces dnsmasq cannot coexist with
        # another service trying to serve DHCP / RA on the same LAN port.
        conflicts = wwan.get('_passthrough_conflicts', {}) or {}
        if conflicts.get('dhcp_server'):
            raise ConfigError(
                "ip-passthrough conflicts with 'service dhcp-server' "
                "on the same LAN interface — both would try to bind "
                "UDP/67.  Disable one or the other."
            )
        if conflicts.get('dhcpv6_server'):
            raise ConfigError(
                "ip-passthrough conflicts with 'service dhcpv6-server' "
                "— both would try to bind DHCPv6 on UDP/547.  Disable "
                "one or the other."
            )
        if conflicts.get('router_advert'):
            raise ConfigError(
                "ip-passthrough conflicts with 'service router-advert' "
                "on the same LAN interface — both would emit RAs.  "
                "Disable one or the other."
            )
        if conflicts.get('bridge_master'):
            raise ConfigError(
                f"ip-passthrough interface is a member of bridge "
                f"'{conflicts['bridge_master']}' — the designated LAN "
                f"port must be a standalone wired interface."
            )
        if conflicts.get('bond_master'):
            raise ConfigError(
                f"ip-passthrough interface is a member of bond "
                f"'{conflicts['bond_master']}' — the designated LAN "
                f"port must be a standalone wired interface."
            )
        # IPv4 routing parameters on wwanN that break passthrough.
        # Passthrough policy-routes inbound carrier-IP packets (which
        # arrive on wwanN) out the LAN port — an asymmetric path that
        # REQUIRES IPv4 forwarding enabled and reverse-path filtering no
        # stricter than loose on wwanN.  These two settings silently drop
        # that inbound traffic, so reject the combination at commit time
        # rather than ship a passthrough that looks up but never works.
        if user_set.get('ip_disable_forwarding'):
            raise ConfigError(
                "ip-passthrough requires IPv4 forwarding on the WWAN "
                "interface, but 'ip disable-forwarding' is set — inbound "
                "traffic to the passed-through device would be dropped.  "
                "Remove 'ip disable-forwarding'."
            )
        if user_set.get('ip_source_validation') == 'strict':
            raise ConfigError(
                "ip-passthrough is incompatible with 'ip source-validation "
                "strict' on the WWAN interface — strict reverse-path "
                "filtering drops the asymmetrically-routed inbound traffic "
                "destined for the passed-through device.  Use 'loose' or "
                "'disable' instead."
            )

    # ── ipv6-bridging guard ── must target the L3-owning interface ────────
    brg_conflicts = wwan.get('_ipv6_bridging_conflicts', {}) or {}
    if brg_conflicts.get('bridge_master'):
        raise ConfigError(
            f"ipv6-bridging interface is a member of bridge "
            f"'{brg_conflicts['bridge_master']}' — point ipv6-bridging "
            f"at '{brg_conflicts['bridge_master']}' instead so the "
            f"carrier prefix lands on the L3-owning interface."
        )
    if brg_conflicts.get('bond_master'):
        raise ConfigError(
            f"ipv6-bridging interface is a member of bond "
            f"'{brg_conflicts['bond_master']}' — point ipv6-bridging "
            f"at '{brg_conflicts['bond_master']}' instead so the "
            f"carrier prefix lands on the L3-owning interface."
        )

    # translate-prefix is meaningless without a bridged LAN interface.
    if (wwan.get('ipv6_bridging', {}) or {}).get('translate_prefix') \
            and not user_set.get('ipv6_bridging_interface'):
        raise ConfigError(
            "ipv6-bridging translate-prefix requires 'ipv6-bridging interface "
            "<lan>' to be set."
        )

    # ── ipv6-bridging RA timer sanity (RFC 4861 / radvd hard requirements) ──
    # radvd refuses to start unless MinRtrAdvInterval <= 0.75 * MaxRtrAdvInterval
    # and AdvPreferredLifetime <= AdvValidLifetime.  Catch it here with a clean
    # message instead of a silent radvd start failure at runtime.
    if user_set.get('ipv6_bridging_interface'):
        ra = (wwan.get('ipv6_bridging', {}) or {}).get('router_advert', {}) or {}
        ra_min = int(ra.get('min_interval', 3))
        ra_max = int(ra.get('max_interval', 10))
        if ra_min > 0.75 * ra_max:
            raise ConfigError(
                f"ipv6-bridging router-advert min-interval ({ra_min}s) must be "
                f"<= 0.75 x max-interval ({int(0.75 * ra_max)}s for the configured "
                f"max-interval of {ra_max}s) — RFC 4861 / radvd reject this combination."
            )
        ra_pref = int(ra.get('preferred_lifetime', 1800))
        ra_valid = int(ra.get('valid_lifetime', 3600))
        if ra_pref > ra_valid:
            raise ConfigError(
                f"ipv6-bridging router-advert preferred-lifetime ({ra_pref}s) must "
                f"not exceed valid-lifetime ({ra_valid}s) — RFC 4861."
            )

        # NPTv6 translate-prefix must be a valid IPv6 /64 (cellular carriers
        # assign a /64; the 1:1 prefix map only substitutes the /64 bits).
        translate_prefix = (wwan.get('ipv6_bridging', {}) or {}).get('translate_prefix')
        if translate_prefix:
            try:
                _net = ipaddress.IPv6Network(translate_prefix, strict=False)
            except (ipaddress.AddressValueError,
                    ipaddress.NetmaskValueError, ValueError):
                raise ConfigError(
                    f"ipv6-bridging translate-prefix '{translate_prefix}' is not a "
                    f"valid IPv6 prefix."
                )
            if _net.prefixlen != 64:
                raise ConfigError(
                    f"ipv6-bridging translate-prefix must be a /64 (cellular carriers "
                    f"assign a /64); got /{_net.prefixlen}."
                )

    # ── ip-passthrough RA timer sanity (dnsmasq ra-param) ──────────────
    # A router-lifetime shorter than the RA interval leaves the downstream
    # device without a default route between advertisements (RFC 4861).
    if user_set.get('ip_passthrough_interface'):
        pra = (wwan.get('ip_passthrough', {}) or {}).get('router_advert', {}) or {}
        pra_int = int(pra.get('interval', 60))
        pra_life = int(pra.get('router_lifetime', 1800))
        if pra_life != 0 and pra_life < pra_int:
            raise ConfigError(
                f"ip-passthrough router-advert router-lifetime ({pra_life}s) must "
                f"be 0 or >= interval ({pra_int}s) — a shorter lifetime leaves the "
                f"downstream device without a default route between RAs (RFC 4861)."
            )

    return None


# ---------------------------------------------------------------------------
# generate  — nothing to render
# ---------------------------------------------------------------------------

def generate(wwan):
    return None


# ---------------------------------------------------------------------------
# apply  — push config to FSM via D-Bus
# ---------------------------------------------------------------------------

def apply(wwan):
    ifname = wwan.get('ifname', 'wwan0')
    # Extract numeric interface index from wwanN
    match = re.search(r'(\d+)$', ifname)
    interface_number = int(match.group(1)) if match else 0

    if 'deleted' in wwan:
        # Interface node is gone from the CLI tree.  get_config() already
        # checked the session/proposed tree using this script's sole Config
        # instance, before any services were touched.
        last_wwan = wwan.get('_last_wwan', False)

        # Fully tear down THIS interface on the FSM side: shut the state
        # machine down (drops the bearer, deregisters from the network,
        # tears down downstream LAN state), unexport its D-Bus object, and
        # delete the persisted config cache so a later service start will
        # NOT replay a stale configuration.
        #
        # Ensure the manager is available so RemoveInterface can succeed even
        # if this commit path is the first WWAN action after a service crash.
        _ensure_manager_running()
        removed = asyncio.run(_remove_via_dbus(interface_number))
        if not removed:
            # Manager unreachable (crashed / not yet up): the D-Bus
            # RemoveInterface handler -- which is what purges this interface's
            # persisted state (config cache AND data-usage counters) -- never
            # ran.  Clean both up locally so a later recreate starts clean.
            # When RemoveInterface DID run, the manager already removed these
            # itself, so we skip the redundant local delete.
            _remove_local_wwan_cache(interface_number)
            _remove_persisted_usage(interface_number)

        if interface_exists(ifname):
            w = WWANIf(ifname)
            w.remove()

        # If that was the last wwan interface, bring cellular fully down:
        # stop the WWAN manager service, which runs its own graceful
        # teardown and then stops ModemManager.  This is what guarantees the
        # network connection actually drops and no ModemManager is left
        # running once the last interface is gone.
        if last_wwan:
            _stop_manager_and_modemmanager()

        return None

    if _leaf_exists(wwan, 'disable'):
        # Admin-disable is a FULL teardown, identical to `delete` except the
        # config node stays in the CLI tree.  Rationale: once the modem is
        # torn down we have no visibility into SIM/carrier changes, so
        # replaying stale history (data-usage counters, last-connected APN)
        # on re-enable could be wrong -- a clean slate is correct.
        # RemoveInterface drops the bearer, deregisters, tears down the
        # downstream LAN state, unexports the D-Bus object and PURGES the
        # persisted config cache + data-usage counters.  Removing `disable`
        # later recreates the interface from scratch via the normal apply
        # path below.
        disable_last_active = wwan.get('_disable_last_active', False)
        _ensure_manager_running()
        removed = asyncio.run(_remove_via_dbus(interface_number))
        if not removed:
            # Manager unreachable: purge persisted state locally so a later
            # re-enable still starts clean (mirrors the delete fallback).
            _remove_local_wwan_cache(interface_number)
            _remove_persisted_usage(interface_number)

        if interface_exists(ifname):
            w = WWANIf(ifname)
            w.remove()

        # If no enabled wwan interface remains, bring cellular fully down:
        # stop the WWAN manager (which stops ModemManager) so nothing runs,
        # exactly as deleting the last interface does.
        if disable_last_active:
            _stop_manager_and_modemmanager()

        return None

    config = build_fsm_config(wwan)

    # Ensure the WWAN manager service is running -- it owns the D-Bus
    # endpoint we are about to call and is responsible for starting
    # ModemManager.  The unit has no [Install] section, so conf_mode is
    # the only thing that ever starts it.  Idempotent: a no-op if
    # already active.
    _ensure_manager_running()

    # Send config via D-Bus
    asyncio.run(_apply_via_dbus(interface_number, config))

    # Apply VyOS infrastructure settings to the kernel interface:
    # VRF, mirror/redirect, ip/ipv6 options, MTU, description, etc.
    if interface_exists(ifname):
        w = WWANIf(ifname)
        # Link bring-up is owned by the WWAN state machine when interface
        # management + ensure-link-up-on-connect are active: it raises wwanN
        # only AFTER ModemManager has set the qmi_wwan data-format (raw_ip),
        # a change the kernel rejects while the netdev is running.  Defer the
        # generic admin-UP so this commit does not race MM's raw_ip write on
        # (re)connect ("qmi_wwan ... Cannot change a running device").  When
        # the FSM will not raise the link, keep the historical bring-up here.
        im = config['interface_management']
        defer_admin_up = bool(im['enabled'] and im['ensure_link_up_on_connect'])
        w.update(wwan, defer_admin_up=defer_admin_up)

    return None


def _is_transient_dbus_error(exc):
    """True when a WWAN D-Bus error means the service has not yet claimed its
    bus name (started but still booting), as opposed to a real method error.

    Used only for method-level errors raised AFTER a successful connect (the
    whole connect/introspect phase is handled structurally in
    `_apply_via_dbus` by retrying every `WWANConnectionError`).  If the
    manager drops off the bus mid-operation, the in-flight method call surfaces
    one of these name-acquisition strings; retry those until the deadline.
    """
    msg = str(exc)
    return (
        'was not provided by any .service files' in msg
        or 'NameHasNoOwner' in msg
        or 'ServiceUnknown' in msg
    )


async def _apply_via_dbus(interface_number, config, connect_timeout=20.0):
    """Push configuration to the FSM D-Bus service.

    Retries the initial connect for up to *connect_timeout* seconds.
    The manager service is started just before this call by
    `_ensure_manager_running()`, but `systemctl start` returns while the
    python process is still booting and has not yet claimed its D-Bus
    well-known name (`com.igos.IgosModemManager`).  Without a retry the
    very first `commit` after a fresh boot fails with
    "name was not provided by any .service files".
    """
    # Import here to avoid hard dependency at module level
    from vyos.utils.wwan.wwan_client import (
        WWANClient,
        WWANError,
        WWANConnectionError,
    )

    deadline = time.monotonic() + connect_timeout
    while True:
        try:
            async with WWANClient() as client:
                await client.add_interface(interface_number)
                await asyncio.sleep(0.5)
                result = await client.set_configuration(
                    interface_number, config)
                print(f'WWAN interface {interface_number}: {result}')
            return
        except WWANConnectionError as exc:
            # CONNECT / INTROSPECT phase failure.  `_ensure_manager_running()`
            # only guarantees `systemctl start` has returned -- the manager may
            # still be coming up, and EVERY way the connect can lose that race
            # is transient and self-clears within a fraction of a second:
            #   * the well-known name is not on the bus yet (ServiceUnknown /
            #     name "was not provided by any .service files" / NameHasNoOwner);
            #   * the name is claimed but the object path is not registered yet
            #     (UnknownObject / "No such object");
            #   * the object is introspectable but the Control interface is not
            #     exported yet ("interface not found on this object" -- the
            #     ~tens-of-ms race actually hit at boot);
            #   * transport-level races while the bus connection settles.
            # Retry the WHOLE connect until the deadline rather than trying to
            # enumerate every possible dbus-next message.
            if time.monotonic() < deadline:
                await asyncio.sleep(0.5)
                continue
            raise ConfigError(
                f'WWAN D-Bus configuration failed (service not ready): {exc}'
            ) from exc
        except WWANError as exc:
            # A method-level error AFTER a successful connect (e.g.
            # WWANConfigError = SetConfiguration rejected).  Only the known
            # name-acquisition-race strings are transient; any other WWANError
            # is a genuine configuration failure and must surface immediately.
            if _is_transient_dbus_error(exc) and time.monotonic() < deadline:
                await asyncio.sleep(0.5)
                continue
            raise ConfigError(
                f'WWAN D-Bus configuration failed: {exc}') from exc
        except Exception as exc:
            if time.monotonic() < deadline:
                # Treat unexpected connect-time errors as transient
                # until the timeout expires (covers DBus transport-level
                # races during service start).
                await asyncio.sleep(0.5)
                continue
            raise ConfigError(
                f'Failed to communicate with WWAN service: {exc}'
            ) from exc


async def _remove_via_dbus(interface_number):
    """Tell the FSM service to fully remove an interface.

    Calls ``RemoveInterface`` on the WWAN D-Bus service which shuts the
    FSM down, unexports the per-interface D-Bus object, and deletes the
    persisted JSON config cache.  Without this step a subsequent service
    restart would replay the last-known configuration even though the
    user has removed the interface from the VyOS CLI tree.

    Failures are surfaced as warnings rather than ConfigError so that a
    transient D-Bus issue does not block a `commit` that is otherwise
    deleting state (the on-disk cache will be cleaned up on next start).
    """
    from vyos.utils.wwan.wwan_client import WWANClient, WWANError

    deadline = time.monotonic() + 20.0
    while True:
        try:
            async with WWANClient() as client:
                result = await client.remove_interface(interface_number)
                print(f'WWAN interface {interface_number}: {result}')
                return True
        except WWANError as exc:
            if _is_transient_dbus_error(exc) and time.monotonic() < deadline:
                await asyncio.sleep(0.5)
                continue
            print(f'Warning: WWAN RemoveInterface failed: {exc}')
            return False
        except Exception as exc:
            if time.monotonic() < deadline:
                await asyncio.sleep(0.5)
                continue
            print(f'Warning: failed to communicate with WWAN service: {exc}')
            return False


def _remove_local_wwan_cache(interface_number):
    """Best-effort cleanup for per-interface runtime cache files.

    This is a fallback when D-Bus RemoveInterface cannot be reached.
    Prevents deleted interfaces from replaying stale state when recreated.
    """
    base = f'/run/wwan/interface{interface_number}.conf'
    for path in (base, base + '.bad'):
        try:
            os.unlink(path)
            print(f'WWAN interface {interface_number}: removed stale cache {path}')
        except FileNotFoundError:
            pass
        except Exception as exc:
            print(f'Warning: failed to remove WWAN cache {path}: {exc}')


def _remove_persisted_usage(interface_number):
    """Fallback cleanup of persisted per-SIM data-usage counters.

    The PRIMARY purge happens inside the manager's `remove_interface` (the
    D-Bus RemoveInterface handler), right beside the config-cache removal, so
    it is co-located with the FSM teardown.  This local delete is only used
    when that D-Bus call could NOT be reached (manager crashed / not yet up),
    mirroring how `_remove_local_wwan_cache` backstops the /run config cache.

    Only ever runs on an explicit `delete interfaces wwan wwanN` (never on a
    reboot/upgrade, which replay the config), so billing counters still
    survive restarts while an operator-initiated removal starts clean.  The
    file lives under /config (WWAN_PERSIST_DIR in
    interfaces_wwan_state_machine.py).  Best-effort: a missing file is fine and
    any error is a warning so it never blocks the commit.
    """
    base = f'/config/wwan/wwan{interface_number}_usage.json'
    for path in (base, base + '.tmp'):
        try:
            os.unlink(path)
            print(f'WWAN interface {interface_number}: cleared data-usage {path}')
        except FileNotFoundError:
            pass
        except Exception as exc:
            print(f'Warning: failed to clear WWAN data-usage {path}: {exc}')


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    try:
        c = get_config()
        verify(c)
        generate(c)
        apply(c)
    except ConfigError as e:
        print(e)
        sys.exit(1)
