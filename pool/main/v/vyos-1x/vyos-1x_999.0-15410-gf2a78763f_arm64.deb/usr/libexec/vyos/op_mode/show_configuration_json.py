#!/usr/bin/env python3
#
# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import argparse
import json

from vyos.configquery import ConfigTreeQuery


parser = argparse.ArgumentParser()
parser.add_argument("-p", "--pretty", action="store_true", help="Show pretty configuration in JSON format")
parser.add_argument("-d", "--with-defaults", action="store_true", help="Include default values in the JSON output")


if __name__ == '__main__':
    args = parser.parse_args()

    config = ConfigTreeQuery()
    c = config.get_config_dict(with_recursive_defaults=args.with_defaults)

    if args.pretty:
        print(json.dumps(c, indent=4))
    else:
        print(json.dumps(c))
