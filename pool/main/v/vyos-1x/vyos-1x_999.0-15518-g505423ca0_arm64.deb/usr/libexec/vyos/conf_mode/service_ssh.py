#!/usr/bin/env python3
#
# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os

from sys import exit
from syslog import syslog
from syslog import LOG_INFO
from time import monotonic
from time import sleep

from vyos.config import Config
from vyos.configdep import set_dependents
from vyos.configdep import call_dependents
from vyos.configdict import is_node_changed
from vyos.configverify import verify_vrf
from vyos.configverify import verify_pki_openssh_key
from vyos.defaults import config_files
from vyos import fips
from vyos.utils.process import call
from vyos.utils.process import cmd
from vyos.utils.process import rc_cmd
from vyos.template import render
from vyos import ConfigError
from vyos import airbag
from vyos.pki import encode_public_key
from vyos.pki import load_openssh_public_key
from vyos.utils.dict import dict_search_recursive
from vyos.utils.file import write_file
from vyos.utils.serial import serial_ssh_server_configured
from vyos.tpm import tpm_enabled

airbag.enable()

config_file = r'/run/sshd/sshd_config'

sshguard_config_file = '/etc/sshguard/sshguard.conf'
sshguard_whitelist = '/etc/sshguard/whitelist'

key_rsa = '/etc/ssh/ssh_host_rsa_key'
key_ed25519 = '/etc/ssh/ssh_host_ed25519_key'
# PERLE added tpm backed keys
key_ecdsa = '/etc/ssh/ssh_host_ecdsa_key'
tpm_key_rsa = '/etc/ssh/ssh_tpm_host_rsa_key.tpm'
tpm_key_ecdsa = '/etc/ssh/ssh_tpm_host_ecdsa_key.tpm'
tpm_agent_cfile_name = '/etc/ssh/sshd_config.d/10-ssh-tpm-agent'
tpm_device = '/dev/tpmrm0'
tpm_ready_timeout = 30

trusted_user_ca = config_files['sshd_user_ca']


def get_config(config=None):
    if config:
        conf = config
    else:
        conf = Config()
    base = ['service', 'ssh']
    if not conf.exists(base):
        # service ssh is being removed - a serial SSH server relies on it, so
        # refuse the deletion while such a server is still configured.
        if serial_ssh_server_configured(conf):
            return {'serial_ssh_dependent': True}
        return None
    ssh = conf.get_config_dict(base, key_mangling=('-', '_'),
                               get_first_key=True, with_pki=True)

    tmp = is_node_changed(conf, base + ['vrf'])
    if tmp:
        ssh.update({'restart_required': {}})

    tmp = is_node_changed(conf, base)
    if tmp:
        # Set dependency to restart serial ports running ssh server when ssh config changes
        # Not when ssh is called as dependency
        set_dependents('serial', conf)

    # We have gathered the dict representation of the CLI, but there are default
    # options which we need to update into the dictionary retrieved.
    ssh = conf.merge_defaults(ssh, recursive=True)

    # Ignore default XML values if config doesn't exists
    # Delete key from dict
    if not conf.exists(base + ['dynamic-protection']):
        del ssh['dynamic_protection']

    # See if any user has specified a list of principal names that are accepted
    # for certificate authentication.
    tmp = conf.get_config_dict(['system', 'login', 'user'],
                                key_mangling=('-', '_'),
                                no_tag_node_value_mangle=True,
                                get_first_key=True)

    for value, _ in dict_search_recursive(tmp, 'principal'):
        # Only enable principal handling if SSH trusted-user-ca is set
        if 'trusted_user_ca' in ssh:
            ssh['has_principals'] = {}
        # We do only need to execute this code path once as we need to know
        # if any one of the local users has a principal set or not - this
        # accounts for the entire system.
        break

    # FIPS 140-3: flag FIPS mode so the template selects approved host keys and
    # verify() rejects explicitly-set non-approved values. Emit the approved
    # algorithm defaults from the policy (single source of truth) for the leaves
    # the operator left unset -- otherwise OpenSSH would fall back to its own
    # non-approved compiled defaults. Explicit values are left for verify() to
    # reject. Uses the single Config instance (configd-safe).
    if fips.fips_enabled(conf):
        ssh['fips'] = {}
        fips.apply_fips_defaults(ssh, {
            'cipher': 'service ssh cipher',
            'mac': 'service ssh mac',
            'key_exchange': 'service ssh key-exchange',
            'hostkey_algorithm': 'service ssh hostkey-algorithm',
            'pubkey_accepted_algorithm': 'service ssh pubkey-accepted-algorithm',
        })

    return ssh


def verify(ssh):
    if not ssh:
        return None

    if 'serial_ssh_dependent' in ssh:
        raise ConfigError('Cannot delete "service ssh" while a serial SSH server is configured, please remove the serial SSH server first!')

    if 'rekey' in ssh and 'data' not in ssh['rekey']:
        raise ConfigError('Rekey data is required!')

    if 'fips' in ssh:
        ssh_fips_leaf_map = {
            'cipher': 'service ssh cipher',
            'mac': 'service ssh mac',
            'key_exchange': 'service ssh key-exchange',
            'hostkey_algorithm': 'service ssh hostkey-algorithm',
            'pubkey_accepted_algorithm': 'service ssh pubkey-accepted-algorithm',
        }
        messages = fips.reject_unapproved(ssh, ssh_fips_leaf_map)
        if messages:
            raise ConfigError('\n'.join(messages))

    if 'trusted_user_ca' in ssh:
        verify_pki_openssh_key(ssh, ssh['trusted_user_ca'])

    verify_vrf(ssh)
    return None


def prepare_tpm_host_keys():
    deadline = monotonic() + tpm_ready_timeout
    while not os.path.exists(tpm_device):
        remaining = deadline - monotonic()
        if remaining <= 0:
            raise ConfigError(f'TPM-backed SSH is enabled but {tpm_device} did not appear '
                              f'within {tpm_ready_timeout} seconds')
        sleep(min(0.25, remaining))

    key_files = tuple(path for key in (tpm_key_rsa, tpm_key_ecdsa)
                      for path in (key, f'{key.removesuffix(".tpm")}.pub'))
    if not all(os.path.isfile(path) for path in key_files):
        cmd('ssh-tpm-keygen -A', raising=ConfigError,
            message='Could not generate TPM-backed SSH host keys')
        missing = [path for path in key_files if not os.path.isfile(path)]
        if missing:
            raise ConfigError(f'TPM-backed SSH host key files missing: {", ".join(missing)}')

    if os.path.isfile(f'{tpm_agent_cfile_name}.tpm'):
        os.replace(f'{tpm_agent_cfile_name}.tpm', f'{tpm_agent_cfile_name}.conf')
    elif not os.path.isfile(f'{tpm_agent_cfile_name}.conf'):
        cmd('ssh-tpm-hostkeys --install-sshd-config', raising=ConfigError,
            message='Could not configure the TPM-backed SSH host keys')


def generate(ssh):
    if not ssh:
        if os.path.isfile(config_file):
            os.unlink(config_file)

        return None

    ssh['tpm_host_keys'] = 'fips' not in ssh and tpm_enabled()
    if not ssh['tpm_host_keys'] and os.path.isfile(f'{tpm_agent_cfile_name}.conf'):
        os.replace(f'{tpm_agent_cfile_name}.conf', f'{tpm_agent_cfile_name}.tpm')

    if 'fips' in ssh:
        # FIPS 140-3: the (uncertified fTPM) TPM host-key path is not approved,
        # so disable the TPM agent drop-in and present approved RSA + ECDSA text
        # host keys. ed25519/DSA are not FIPS-approvable and are not referenced
        # by the FIPS sshd_config, so they are not (re)generated here -- their
        # keygen would also fail under the active FIPS provider.
        if not os.path.isfile(key_rsa):
            syslog(LOG_INFO, 'FIPS: generating approved SSH RSA host key!')
            call(f'ssh-keygen -q -N "" -t rsa -b 3072 -f {key_rsa}')
        if not os.path.isfile(key_ecdsa):
            syslog(LOG_INFO, 'FIPS: generating approved SSH ECDSA host key!')
            call(f'ssh-keygen -q -N "" -t ecdsa -b 384 -f {key_ecdsa}')
    elif not ssh['tpm_host_keys']:
        # This usually happens only once on a fresh system, SSH keys need to be
        # freshly generated, one per every system!
        if not os.path.isfile(key_rsa):
            syslog(LOG_INFO, 'SSH RSA host key not found, generating new key!')
            call(f'ssh-keygen -q -N "" -t rsa -f {key_rsa}')
    else:
        prepare_tpm_host_keys()

    if 'fips' not in ssh:
        if not os.path.isfile(key_ed25519):
            syslog(LOG_INFO, 'SSH ed25519 host key not found, generating new key!')
            call(f'ssh-keygen -q -N "" -t ed25519 -f {key_ed25519}')

    if 'trusted_user_ca' in ssh:
        key_name = ssh['trusted_user_ca']
        openssh_cert = ssh['pki']['openssh'][key_name]
        loaded_ca_cert = load_openssh_public_key(openssh_cert['public']['key'],
                                                 openssh_cert['public']['type'])
        tmp = encode_public_key(loaded_ca_cert, encoding='OpenSSH',
                                key_format='OpenSSH')
        write_file(trusted_user_ca, tmp, trailing_newline=True)
    else:
        if os.path.exists(trusted_user_ca):
            os.unlink(trusted_user_ca)

    render(config_file, 'ssh/sshd_config.j2', ssh)

    if 'dynamic_protection' in ssh:
        render(sshguard_config_file, 'ssh/sshguard_config.j2', ssh)
        render(sshguard_whitelist, 'ssh/sshguard_whitelist.j2', ssh)

    return None


def apply(ssh):
    systemd_service_sshguard = 'sshguard.service'
    if not ssh:
        # SSH access is removed in the commit
        call('systemctl stop ssh@*.service')
        call(f'systemctl stop {systemd_service_sshguard}')
        cmd('systemctl stop ssh-tpm-agent.socket ssh-tpm-agent.service', raising=ConfigError)
        return None

    # Verify generated sshd configuration is correct
    rc, out = rc_cmd(f'/usr/sbin/sshd -t -f {config_file}')
    if rc:
        raise ConfigError(f'Unexpected error with SSH configuration! {out}')

    if 'dynamic_protection' not in ssh:
        call(f'systemctl stop {systemd_service_sshguard}')
    else:
        call(f'systemctl reload-or-restart {systemd_service_sshguard}')

    # we need to restart the service if e.g. the VRF name changed
    systemd_action = 'reload-or-restart'
    if 'restart_required' in ssh:
        # this is only true if something for the VRFs changed, thus we
        # stop all VRF services and only restart then new ones
        call('systemctl stop ssh@*.service')
        systemd_action = 'restart'

    if ssh['tpm_host_keys']:
        cmd(f'systemctl {systemd_action} ssh-tpm-agent.service', raising=ConfigError,
            message='Could not start the SSH TPM agent')
    else:
        cmd('systemctl stop ssh-tpm-agent.socket ssh-tpm-agent.service', raising=ConfigError)

    for vrf in ssh['vrf']:
        call(f'systemctl {systemd_action} ssh@{vrf}.service')

    # Call dependents (e.g., serial ports running ssh server)
    call_dependents()
    return None


if __name__ == '__main__':
    try:
        c = get_config()
        verify(c)
        generate(c)
        apply(c)
    except ConfigError as e:
        print(e)
        exit(1)
