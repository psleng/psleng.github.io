# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this library.  If not, see <http://www.gnu.org/licenses/>.

from typing import Optional, Union, TYPE_CHECKING
from typing import Callable
from typing import Any
from vyos.xml_ref import definition
from vyos.xml_ref import op_definition

if TYPE_CHECKING:
    from vyos.config import ConfigDict

def load_reference(cache=[]):
    if cache:
        return cache[0]

    xml = definition.Xml()

    try:
        from vyos.xml_ref.cache import reference
    except Exception:
        raise ImportError('no xml reference cache !!')

    if not reference:
        raise ValueError('empty xml reference cache !!')

    xml.define(reference)
    cache.append(xml)

    return xml

def is_tag(path: list) -> bool:
    return load_reference().is_tag(path)

def is_tag_value(path: list) -> bool:
    return load_reference().is_tag_value(path)

def is_multi(path: list) -> bool:
    return load_reference().is_multi(path)

def is_valueless(path: list) -> bool:
    return load_reference().is_valueless(path)

def is_leaf(path: list) -> bool:
    return load_reference().is_leaf(path)

def owner(path: list, with_tag=False) -> str:
    return load_reference().owner(path, with_tag=with_tag)

def priority(path: list) -> str:
    return load_reference().priority(path)

def cli_defined(path: list, node: str, non_local=False) -> bool:
    return load_reference().cli_defined(path, node, non_local=non_local)

def component_version() -> dict:
    return load_reference().component_version()

def default_value(path: list) -> Optional[Union[str, list]]:
    return load_reference().default_value(path)

def multi_to_list(rpath: list, conf: dict) -> dict:
    return load_reference().multi_to_list(rpath, conf)

def get_defaults(path: list, get_first_key=False, recursive=False) -> dict:
    return load_reference().get_defaults(path, get_first_key=get_first_key,
                                         recursive=recursive)

def relative_defaults(rpath: list, conf: dict, get_first_key=False,
                      recursive=False) -> dict:

    return load_reference().relative_defaults(rpath, conf,
                                              get_first_key=get_first_key,
                                              recursive=recursive)

def from_source(d: dict, path: list) -> bool:
    return definition.from_source(d, path)

def ext_dict_merge(source: dict, destination: Union[dict, 'ConfigDict']):
    return definition.ext_dict_merge(source, destination)


def load_op_reference(op_cache=[]):
    if op_cache:
        return op_cache[0]

    op_xml = op_definition.OpXml()

    try:
        from vyos.xml_ref.op_cache import op_reference
    except Exception:
        raise ImportError('no xml op reference cache !!')

    if not op_reference:
        raise ValueError('empty xml op reference cache !!')

    op_xml.define(op_reference)
    op_cache.append(op_xml)

    return op_xml


def walk_op_data(func: Callable[[tuple, dict], Any]):
    return load_op_reference().walk(func)


def walk_op_node_data():
    return load_op_reference().walk_node_data()


def lookup_op_data(
    path: list, tag_values: bool = False, last_node_type: str = ''
) -> (dict, list[str]):
    return load_op_reference().lookup(
        path, tag_values=tag_values, last_node_type=last_node_type
    )


def lookup_op_node_data(
    path: list, tag_values: bool = False, last_node_type: str = ''
) -> list[op_definition.NodeData]:
    return load_op_reference().lookup_node_data(
        path, tag_values=tag_values, last_node_type=last_node_type
    )
