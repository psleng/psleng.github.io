#!/usr/bin/env python3
#
# Copyright VyOS maintainers and contributors <maintainers@vyos.io>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os

from copy import deepcopy
from sys import exit
from syslog import syslog
from syslog import LOG_INFO

from vyos.base import DeprecationWarning
from vyos.config import Config
from vyos.configdict import is_node_changed
from vyos.configverify import verify_vrf
from vyos.configverify import verify_pki_openssh_key
from vyos.defaults import config_files
from vyos.defaults import SSH_DSA_DEPRECATION_WARNING
from vyos.utils.process import call
from vyos.utils.process import rc_cmd
from vyos.template import render
from vyos import ConfigError
from vyos import airbag
from vyos.pki import encode_public_key
from vyos.pki import load_openssh_public_key
from vyos.utils.dict import dict_search_recursive
from vyos.utils.file import write_file
# PERLE - access tpm allowed checking
from vyos.tpm import tpm_allowed

airbag.enable()

config_file = r'/run/sshd/sshd_config'

sshguard_config_file = '/etc/sshguard/sshguard.conf'
sshguard_whitelist = '/etc/sshguard/whitelist'

key_rsa = '/etc/ssh/ssh_host_rsa_key'
key_dsa = '/etc/ssh/ssh_host_dsa_key'
key_ed25519 = '/etc/ssh/ssh_host_ed25519_key'
# PERLE added tpm backed keys
key_ecdsa = '/etc/ssh/ssh_host_ecdsa_key'
tpm_key_rsa = '/etc/ssh/ssh_tpm_host_rsa_key.tpm'
tpm_key_ecdsa = '/etc/ssh/ssh_tpm_host_ecdsa_key.tpm'
tpm_agent_cfile_name = '/etc/ssh/sshd_config.d/10-ssh-tpm-agent'

trusted_user_ca = config_files['sshd_user_ca']

login_motd_dsa_warning = r'/run/motd.d/91-vyos-ssh-dsa-deprecation-warning'

# As of OpenSSH 9.8p1 in Debian trixie, DSA keys are no longer supported
deprecated_algos = ['ssh-dss', 'ssh-dss-cert-v01@openssh.com']
SSH_DSA_DEPRECATION_WARNING: str = f'{SSH_DSA_DEPRECATION_WARNING} '\
'The following hostkey-algorithms are in use:'

def get_config(config=None):
    if config:
        conf = config
    else:
        conf = Config()
    base = ['service', 'ssh']
    if not conf.exists(base):
        return None
    ssh = conf.get_config_dict(base, key_mangling=('-', '_'),
                               get_first_key=True, with_pki=True)

    tmp = is_node_changed(conf, base + ['vrf'])
    if tmp:
        ssh.update({'restart_required': {}})

    # We have gathered the dict representation of the CLI, but there are default
    # options which we need to update into the dictionary retrived.
    ssh = conf.merge_defaults(ssh, recursive=True)

    # Ignore default XML values if config doesn't exists
    # Delete key from dict
    if not conf.exists(base + ['dynamic-protection']):
        del ssh['dynamic_protection']

    # See if any user has specified a list of principal names that are accepted
    # for certificate authentication.
    tmp = conf.get_config_dict(['system', 'login', 'user'],
                                key_mangling=('-', '_'),
                                no_tag_node_value_mangle=True,
                                get_first_key=True)

    for value, _ in dict_search_recursive(tmp, 'principal'):
        # Only enable principal handling if SSH trusted-user-ca is set
        if 'trusted_user_ca' in ssh:
            ssh['has_principals'] = {}
        # We do only need to execute this code path once as we need to know
        # if any one of the local users has a principal set or not - this
        # accounts for the entire system.
        break

    return ssh


def verify(ssh):
    if not ssh:
        return None

    if 'rekey' in ssh and 'data' not in ssh['rekey']:
        raise ConfigError('Rekey data is required!')

    if 'trusted_user_ca' in ssh:
        verify_pki_openssh_key(ssh, ssh['trusted_user_ca'])

    if 'hostkey_algorithm' in ssh:
        tmp = [algo for algo in ssh['hostkey_algorithm'] if algo in deprecated_algos]
        if tmp: DeprecationWarning(f'{SSH_DSA_DEPRECATION_WARNING} {", ".join(tmp)}')

    verify_vrf(ssh)
    return None


def generate(ssh):
    if not ssh:
        if os.path.isfile(config_file):
            os.unlink(config_file)

        return None

    # This usually happens only once on a fresh system, SSH keys need to be
    # freshly generted, one per every system!
    # PERLE check if tpm allowed before generating RSA server host key text files
    # PERLE for some reason vyos is not generating ECDSA server host key text files
    # PERLE else if tpm is allowed, remove old rsa/ecdsa files, then create tpm backed rsa  ecdsa keys
    if not tpm_allowed():
        if not os.path.isfile(key_rsa):
            syslog(LOG_INFO, 'SSH RSA host key not found, generating new key!')
            call(f'ssh-keygen -q -N "" -t rsa -f {key_rsa}')
        # move the config file that loads tpm socket and tpm back rsa/ecdsa host key
        call(f'sudo mv {tpm_agent_cfile_name}.conf {tpm_agent_cfile_name}.tpm')
    else:
        if os.path.isfile(key_rsa):
            syslog(LOG_INFO, 'SSH RSA host key found, removing text key file')
            call(f'sudo rm {key_rsa}*')
        if os.path.isfile(key_ecdsa):
            syslog(LOG_INFO, 'SSH ECDSA host key found, removing text key file!')
            call(f'sudo rm {key_ecdsa}*')
        if not os.path.isfile(tpm_key_rsa):
            syslog(LOG_INFO, 'Generating missing SSH tpm backed RSA host key!')
            call(f'ssh-tpm-keygen -A')
            call(f'ssh-tpm-hostkeys --install-system-units')
        if not os.path.isfile(tpm_key_ecdsa):
            syslog(LOG_INFO, 'Generating missing SSH tpm backed ECDSA host key!')
            call(f'ssh-tpm-keygen -A')
            call(f'ssh-tpm-hostkeys --install-system-units')
        # restore the config file that loads tpm socket and tpm back rsa/ecdsa host key
        call(f'sudo mv {tpm_agent_cfile_name}.tpm {tpm_agent_cfile_name}.conf')

    if not os.path.isfile(key_dsa):
        syslog(LOG_INFO, 'SSH DSA host key not found, generating new key!')
        call(f'ssh-keygen -q -N "" -t dsa -f {key_dsa}')
    if not os.path.isfile(key_ed25519):
        syslog(LOG_INFO, 'SSH ed25519 host key not found, generating new key!')
        call(f'ssh-keygen -q -N "" -t ed25519 -f {key_ed25519}')

    if 'trusted_user_ca' in ssh:
        key_name = ssh['trusted_user_ca']
        openssh_cert = ssh['pki']['openssh'][key_name]
        loaded_ca_cert = load_openssh_public_key(openssh_cert['public']['key'],
                                                 openssh_cert['public']['type'])
        tmp = encode_public_key(loaded_ca_cert, encoding='OpenSSH',
                                key_format='OpenSSH')
        write_file(trusted_user_ca, tmp, trailing_newline=True)
    else:
        if os.path.exists(trusted_user_ca):
            os.unlink(trusted_user_ca)

    render(config_file, 'ssh/sshd_config.j2', ssh)

    # Generate MOTD informing the user(s) for possible deprecated SSH hostkey-algorithm
    tmp = deepcopy(ssh)
    tmp['ssh_dsa_deprecation_warning'] = f'DEPRECATION WARNING: {SSH_DSA_DEPRECATION_WARNING}'
    tmp['deprecated_algos'] = deprecated_algos
    render(login_motd_dsa_warning, 'ssh/motd_ssh_dsa_warning.j2', tmp,
        permission=0o644, user='root', group='root')

    if 'dynamic_protection' in ssh:
        render(sshguard_config_file, 'ssh/sshguard_config.j2', ssh)
        render(sshguard_whitelist, 'ssh/sshguard_whitelist.j2', ssh)

    return None


def apply(ssh):
    systemd_service_sshguard = 'sshguard.service'
    if not ssh:
        # SSH access is removed in the commit
        call('systemctl stop ssh@*.service')
        call(f'systemctl stop {systemd_service_sshguard}')
        # PERLE add check to restart ssh-tpm-agent
        if tpm_allowed():
            call(f'systemctl stop ssh-tpm-service')
            call(f'systemctl stop ssh-tpm-service.socket')
        return None

    # Verify generated sshd configuration is correct
    rc, out = rc_cmd(f'/usr/sbin/sshd -t -f {config_file}')
    if rc:
        raise ConfigError(f'Unexpected error with SSH configuration! {out}')

    if 'dynamic_protection' not in ssh:
        call(f'systemctl stop {systemd_service_sshguard}')
    else:
        call(f'systemctl reload-or-restart {systemd_service_sshguard}')

    # we need to restart the service if e.g. the VRF name changed
    systemd_action = 'reload-or-restart'
    if 'restart_required' in ssh:
        # this is only true if something for the VRFs changed, thus we
        # stop all VRF services and only restart then new ones
        call('systemctl stop ssh@*.service')
        systemd_action = 'restart'

    # PERLE add check to restart ssh-tpm-agent
    if tpm_allowed():
        # call(f'systemctl enable --now ssh-tpm-agent.socket')
        call(f'systemctl {systemd_action} ssh-tpm-agent')
        call(f'systemctl {systemd_action} ssh-tpm-agent.socket')

    for vrf in ssh['vrf']:
        call(f'systemctl {systemd_action} ssh@{vrf}.service')
    return None


if __name__ == '__main__':
    try:
        c = get_config()
        verify(c)
        generate(c)
        apply(c)
    except ConfigError as e:
        print(e)
        exit(1)
