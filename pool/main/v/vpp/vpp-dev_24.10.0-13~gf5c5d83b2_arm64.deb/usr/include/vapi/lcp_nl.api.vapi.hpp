#ifndef __included_hpp_lcp_nl_api_json
#define __included_hpp_lcp_nl_api_json

#include <vapi/vapi.hpp>
#include <vapi/lcp_nl.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_lcp_nl_resync>(vapi_msg_lcp_nl_resync *msg)
{
  vapi_msg_lcp_nl_resync_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_lcp_nl_resync>(vapi_msg_lcp_nl_resync *msg)
{
  vapi_msg_lcp_nl_resync_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_lcp_nl_resync>()
{
  return ::vapi_msg_id_lcp_nl_resync; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_lcp_nl_resync>>()
{
  return ::vapi_msg_id_lcp_nl_resync; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_lcp_nl_resync()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_lcp_nl_resync>(vapi_msg_id_lcp_nl_resync);
}

template <> inline vapi_msg_lcp_nl_resync* vapi_alloc<vapi_msg_lcp_nl_resync>(Connection &con)
{
  vapi_msg_lcp_nl_resync* result = vapi_alloc_lcp_nl_resync(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_lcp_nl_resync>;

template class Request<vapi_msg_lcp_nl_resync, vapi_msg_lcp_nl_resync_reply>;

using Lcp_nl_resync = Request<vapi_msg_lcp_nl_resync, vapi_msg_lcp_nl_resync_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_lcp_nl_resync_reply>(vapi_msg_lcp_nl_resync_reply *msg)
{
  vapi_msg_lcp_nl_resync_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_lcp_nl_resync_reply>(vapi_msg_lcp_nl_resync_reply *msg)
{
  vapi_msg_lcp_nl_resync_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_lcp_nl_resync_reply>()
{
  return ::vapi_msg_id_lcp_nl_resync_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_lcp_nl_resync_reply>>()
{
  return ::vapi_msg_id_lcp_nl_resync_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_lcp_nl_resync_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_lcp_nl_resync_reply>(vapi_msg_id_lcp_nl_resync_reply);
}

template class Msg<vapi_msg_lcp_nl_resync_reply>;

using Lcp_nl_resync_reply = Msg<vapi_msg_lcp_nl_resync_reply>;
}
#endif
