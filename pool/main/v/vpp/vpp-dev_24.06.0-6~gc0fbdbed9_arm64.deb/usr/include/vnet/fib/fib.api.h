/*
 * VLIB API definitions 2025-03-04 07:17:11
 * Input file: fib.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple) || defined(vl_calcsizefun)
/* ok, something was selected */
#else
#warning no content included from fib.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))

/*
 * Note: VL_API_MAX_ARRAY_SIZE is set to an arbitrarily large limit.
 *
 * However, any message with a ~2 billion element array is likely to break the
 * api handling long before this limit causes array element endian issues.
 *
 * Applications should be written to create reasonable api messages.
 */
#define VL_API_MAX_ARRAY_SIZE 0x7fffffff

/* Imported API files */
#ifndef vl_api_version
#include <vnet/fib/fib_types.api.h>
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_FIB_SOURCE_ADD, vl_api_fib_source_add_t_handler)
vl_msg_id(VL_API_FIB_SOURCE_ADD_REPLY, vl_api_fib_source_add_reply_t_handler)
vl_msg_id(VL_API_FIB_SOURCE_DUMP, vl_api_fib_source_dump_t_handler)
vl_msg_id(VL_API_FIB_SOURCE_DETAILS, vl_api_fib_source_details_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_fib_source_add_t, 1)
vl_msg_name(vl_api_fib_source_add_reply_t, 1)
vl_msg_name(vl_api_fib_source_dump_t, 1)
vl_msg_name(vl_api_fib_source_details_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_fib \
_(VL_API_FIB_SOURCE_ADD, fib_source_add, b3ac2aec) \
_(VL_API_FIB_SOURCE_ADD_REPLY, fib_source_add_reply, 604fd6f1) \
_(VL_API_FIB_SOURCE_DUMP, fib_source_dump, 51077d14) \
_(VL_API_FIB_SOURCE_DETAILS, fib_source_details, 8668acdb) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "fib.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_fib_printfun_types
#define included_fib_printfun_types

static inline u8 *format_vl_api_fib_source_t (u8 *s, va_list * args)
{
    vl_api_fib_source_t *a = va_arg (*args, vl_api_fib_source_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Upriority: %u", format_white_space, indent, a->priority);
    s = format(s, "\n%Uid: %u", format_white_space, indent, a->id);
    s = format(s, "\n%Uname: %s", format_white_space, indent, a->name);
    return s;
}


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_fib_printfun
#define included_fib_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

#include "fib.api_tojson.h"
#include "fib.api_fromjson.h"

static inline u8 *vl_api_fib_source_add_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_fib_source_add_t *a = va_arg (*args, vl_api_fib_source_add_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_fib_source_add_t: */
    s = format(s, "vl_api_fib_source_add_t:");
    s = format(s, "\n%Usrc: %U", format_white_space, indent, format_vl_api_fib_source_t, &a->src, indent);
    return s;
}

static inline u8 *vl_api_fib_source_add_reply_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_fib_source_add_reply_t *a = va_arg (*args, vl_api_fib_source_add_reply_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_fib_source_add_reply_t: */
    s = format(s, "vl_api_fib_source_add_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    s = format(s, "\n%Uid: %u", format_white_space, indent, a->id);
    return s;
}

static inline u8 *vl_api_fib_source_dump_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_fib_source_dump_t *a = va_arg (*args, vl_api_fib_source_dump_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_fib_source_dump_t: */
    s = format(s, "vl_api_fib_source_dump_t:");
    return s;
}

static inline u8 *vl_api_fib_source_details_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_fib_source_details_t *a = va_arg (*args, vl_api_fib_source_details_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_fib_source_details_t: */
    s = format(s, "vl_api_fib_source_details_t:");
    s = format(s, "\n%Usrc: %U", format_white_space, indent, format_vl_api_fib_source_t, &a->src, indent);
    return s;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_fib_endianfun
#define included_fib_endianfun

#undef clib_net_to_host_uword
#undef clib_host_to_net_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#define clib_host_to_net_uword clib_host_to_net_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#define clib_host_to_net_uword clib_host_to_net_u32
#endif

static inline void vl_api_fib_source_t_endian (vl_api_fib_source_t *a, bool to_net)
{
    int i __attribute__((unused));
    /* a->priority = a->priority (no-op) */
    /* a->id = a->id (no-op) */
    /* a->name = a->name (no-op) */
}

static inline void vl_api_fib_source_add_t_endian (vl_api_fib_source_add_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    vl_api_fib_source_t_endian(&a->src, to_net);
}

static inline void vl_api_fib_source_add_reply_t_endian (vl_api_fib_source_add_reply_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
    /* a->id = a->id (no-op) */
}

static inline void vl_api_fib_source_dump_t_endian (vl_api_fib_source_dump_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_fib_source_details_t_endian (vl_api_fib_source_details_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    vl_api_fib_source_t_endian(&a->src, to_net);
}


#endif
#endif /* vl_endianfun */


/****** Calculate size functions *****/
#ifdef vl_calcsizefun
#ifndef included_fib_calcsizefun
#define included_fib_calcsizefun

/* calculate message size of message in network byte order */
static inline uword vl_api_fib_source_t_calc_size (vl_api_fib_source_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_fib_source_add_t_calc_size (vl_api_fib_source_add_t *a)
{
      return sizeof(*a) - sizeof(a->src) + vl_api_fib_source_t_calc_size(&a->src);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_fib_source_add_reply_t_calc_size (vl_api_fib_source_add_reply_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_fib_source_dump_t_calc_size (vl_api_fib_source_dump_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_fib_source_details_t_calc_size (vl_api_fib_source_details_t *a)
{
      return sizeof(*a) - sizeof(a->src) + vl_api_fib_source_t_calc_size(&a->src);
}


#endif
#endif /* vl_calcsizefun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple

vl_api_version_tuple(fib.api, 1, 0, 0)

#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(fib.api, 0xd97c97e5)

#endif

