#ifndef included_tapv2_api_enum_h
#define included_tapv2_api_enum_h
typedef enum {
   VL_API_TAP_CREATE_V3,
   VL_API_TAP_CREATE_V3_REPLY,
   VL_API_TAP_CREATE_V2,
   VL_API_TAP_CREATE_V2_REPLY,
   VL_API_TAP_DELETE_V2,
   VL_API_TAP_DELETE_V2_REPLY,
   VL_API_SW_INTERFACE_TAP_V2_DUMP,
   VL_API_SW_INTERFACE_TAP_V2_DETAILS,
   VL_MSG_TAPV2_LAST
} vl_api_tapv2_enum_t;
#endif
