/*
 * VLIB API definitions 2026-03-02 03:49:06
 * Input file: arp.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple) || defined(vl_calcsizefun)
/* ok, something was selected */
#else
#warning no content included from arp.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))

/*
 * Note: VL_API_MAX_ARRAY_SIZE is set to an arbitrarily large limit.
 *
 * However, any message with a ~2 billion element array is likely to break the
 * api handling long before this limit causes array element endian issues.
 *
 * Applications should be written to create reasonable api messages.
 */
#define VL_API_MAX_ARRAY_SIZE 0x7fffffff

/* Imported API files */
#ifndef vl_api_version
#include <vnet/ip/ip_types.api.h>
#include <vnet/ethernet/ethernet_types.api.h>
#include <vnet/interface_types.api.h>
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_PROXY_ARP_ADD_DEL, vl_api_proxy_arp_add_del_t_handler)
vl_msg_id(VL_API_PROXY_ARP_ADD_DEL_REPLY, vl_api_proxy_arp_add_del_reply_t_handler)
vl_msg_id(VL_API_PROXY_ARP_DUMP, vl_api_proxy_arp_dump_t_handler)
vl_msg_id(VL_API_PROXY_ARP_DETAILS, vl_api_proxy_arp_details_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE, vl_api_proxy_arp_intfc_enable_disable_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE_REPLY, vl_api_proxy_arp_intfc_enable_disable_reply_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_DUMP, vl_api_proxy_arp_intfc_dump_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_DETAILS, vl_api_proxy_arp_intfc_details_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_proxy_arp_add_del_t, 1)
vl_msg_name(vl_api_proxy_arp_add_del_reply_t, 1)
vl_msg_name(vl_api_proxy_arp_dump_t, 1)
vl_msg_name(vl_api_proxy_arp_details_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_enable_disable_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_enable_disable_reply_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_dump_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_details_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_arp \
_(VL_API_PROXY_ARP_ADD_DEL, proxy_arp_add_del, 1823c3e7) \
_(VL_API_PROXY_ARP_ADD_DEL_REPLY, proxy_arp_add_del_reply, e8d4e804) \
_(VL_API_PROXY_ARP_DUMP, proxy_arp_dump, 51077d14) \
_(VL_API_PROXY_ARP_DETAILS, proxy_arp_details, 5b948673) \
_(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE, proxy_arp_intfc_enable_disable, ae6cfcfb) \
_(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE_REPLY, proxy_arp_intfc_enable_disable_reply, e8d4e804) \
_(VL_API_PROXY_ARP_INTFC_DUMP, proxy_arp_intfc_dump, 51077d14) \
_(VL_API_PROXY_ARP_INTFC_DETAILS, proxy_arp_intfc_details, f6458e5f) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "arp.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_arp_printfun_types
#define included_arp_printfun_types

static inline u8 *format_vl_api_proxy_arp_t (u8 *s, va_list * args)
{
    vl_api_proxy_arp_t *a = va_arg (*args, vl_api_proxy_arp_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    s = format(s, "\n%Utable_id: %u", format_white_space, indent, a->table_id);
    s = format(s, "\n%Ulow: %U", format_white_space, indent, format_vl_api_ip4_address_t, &a->low, indent);
    s = format(s, "\n%Uhi: %U", format_white_space, indent, format_vl_api_ip4_address_t, &a->hi, indent);
    return s;
}


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_arp_printfun
#define included_arp_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

#include "arp.api_tojson.h"
#include "arp.api_fromjson.h"

static inline u8 *vl_api_proxy_arp_add_del_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_add_del_t *a = va_arg (*args, vl_api_proxy_arp_add_del_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_add_del_t: */
    s = format(s, "vl_api_proxy_arp_add_del_t:");
    s = format(s, "\n%Uis_add: %u", format_white_space, indent, a->is_add);
    s = format(s, "\n%Uproxy: %U", format_white_space, indent, format_vl_api_proxy_arp_t, &a->proxy, indent);
    return s;
}

static inline u8 *vl_api_proxy_arp_add_del_reply_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_add_del_reply_t *a = va_arg (*args, vl_api_proxy_arp_add_del_reply_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_add_del_reply_t: */
    s = format(s, "vl_api_proxy_arp_add_del_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    return s;
}

static inline u8 *vl_api_proxy_arp_dump_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_dump_t *a = va_arg (*args, vl_api_proxy_arp_dump_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_dump_t: */
    s = format(s, "vl_api_proxy_arp_dump_t:");
    return s;
}

static inline u8 *vl_api_proxy_arp_details_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_details_t *a = va_arg (*args, vl_api_proxy_arp_details_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_details_t: */
    s = format(s, "vl_api_proxy_arp_details_t:");
    s = format(s, "\n%Uproxy: %U", format_white_space, indent, format_vl_api_proxy_arp_t, &a->proxy, indent);
    return s;
}

static inline u8 *vl_api_proxy_arp_intfc_enable_disable_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_intfc_enable_disable_t *a = va_arg (*args, vl_api_proxy_arp_intfc_enable_disable_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_intfc_enable_disable_t: */
    s = format(s, "vl_api_proxy_arp_intfc_enable_disable_t:");
    s = format(s, "\n%Usw_if_index: %U", format_white_space, indent, format_vl_api_interface_index_t, &a->sw_if_index, indent);
    s = format(s, "\n%Uenable: %u", format_white_space, indent, a->enable);
    return s;
}

static inline u8 *vl_api_proxy_arp_intfc_enable_disable_reply_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_intfc_enable_disable_reply_t *a = va_arg (*args, vl_api_proxy_arp_intfc_enable_disable_reply_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_intfc_enable_disable_reply_t: */
    s = format(s, "vl_api_proxy_arp_intfc_enable_disable_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    return s;
}

static inline u8 *vl_api_proxy_arp_intfc_dump_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_intfc_dump_t *a = va_arg (*args, vl_api_proxy_arp_intfc_dump_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_intfc_dump_t: */
    s = format(s, "vl_api_proxy_arp_intfc_dump_t:");
    return s;
}

static inline u8 *vl_api_proxy_arp_intfc_details_t_format (u8 *s,  va_list *args)
{
    __attribute__((unused)) vl_api_proxy_arp_intfc_details_t *a = va_arg (*args, vl_api_proxy_arp_intfc_details_t *);
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_proxy_arp_intfc_details_t: */
    s = format(s, "vl_api_proxy_arp_intfc_details_t:");
    s = format(s, "\n%Usw_if_index: %u", format_white_space, indent, a->sw_if_index);
    return s;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_arp_endianfun
#define included_arp_endianfun

#undef clib_net_to_host_uword
#undef clib_host_to_net_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#define clib_host_to_net_uword clib_host_to_net_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#define clib_host_to_net_uword clib_host_to_net_u32
#endif

static inline void vl_api_proxy_arp_t_endian (vl_api_proxy_arp_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->table_id = clib_net_to_host_u32(a->table_id);
    vl_api_ip4_address_t_endian(&a->low, to_net);
    vl_api_ip4_address_t_endian(&a->hi, to_net);
}

static inline void vl_api_proxy_arp_add_del_t_endian (vl_api_proxy_arp_add_del_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    vl_api_proxy_arp_t_endian(&a->proxy, to_net);
}

static inline void vl_api_proxy_arp_add_del_reply_t_endian (vl_api_proxy_arp_add_del_reply_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}

static inline void vl_api_proxy_arp_dump_t_endian (vl_api_proxy_arp_dump_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_proxy_arp_details_t_endian (vl_api_proxy_arp_details_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    vl_api_proxy_arp_t_endian(&a->proxy, to_net);
}

static inline void vl_api_proxy_arp_intfc_enable_disable_t_endian (vl_api_proxy_arp_intfc_enable_disable_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    vl_api_interface_index_t_endian(&a->sw_if_index, to_net);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_proxy_arp_intfc_enable_disable_reply_t_endian (vl_api_proxy_arp_intfc_enable_disable_reply_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}

static inline void vl_api_proxy_arp_intfc_dump_t_endian (vl_api_proxy_arp_intfc_dump_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_proxy_arp_intfc_details_t_endian (vl_api_proxy_arp_intfc_details_t *a, bool to_net)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}


#endif
#endif /* vl_endianfun */


/****** Calculate size functions *****/
#ifdef vl_calcsizefun
#ifndef included_arp_calcsizefun
#define included_arp_calcsizefun

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_t_calc_size (vl_api_proxy_arp_t *a)
{
      return sizeof(*a) - sizeof(a->low) + vl_api_ip4_address_t_calc_size(&a->low) - sizeof(a->hi) + vl_api_ip4_address_t_calc_size(&a->hi);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_add_del_t_calc_size (vl_api_proxy_arp_add_del_t *a)
{
      return sizeof(*a) - sizeof(a->proxy) + vl_api_proxy_arp_t_calc_size(&a->proxy);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_add_del_reply_t_calc_size (vl_api_proxy_arp_add_del_reply_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_dump_t_calc_size (vl_api_proxy_arp_dump_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_details_t_calc_size (vl_api_proxy_arp_details_t *a)
{
      return sizeof(*a) - sizeof(a->proxy) + vl_api_proxy_arp_t_calc_size(&a->proxy);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_intfc_enable_disable_t_calc_size (vl_api_proxy_arp_intfc_enable_disable_t *a)
{
      return sizeof(*a) - sizeof(a->sw_if_index) + vl_api_interface_index_t_calc_size(&a->sw_if_index);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_intfc_enable_disable_reply_t_calc_size (vl_api_proxy_arp_intfc_enable_disable_reply_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_intfc_dump_t_calc_size (vl_api_proxy_arp_intfc_dump_t *a)
{
      return sizeof(*a);
}

/* calculate message size of message in network byte order */
static inline uword vl_api_proxy_arp_intfc_details_t_calc_size (vl_api_proxy_arp_intfc_details_t *a)
{
      return sizeof(*a);
}


#endif
#endif /* vl_calcsizefun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple

vl_api_version_tuple(arp.api, 1, 0, 0)

#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(arp.api, 0xcfdf7292)

#endif

