#ifndef __included_hpp_sflow_api_json
#define __included_hpp_sflow_api_json

#include <vapi/vapi.hpp>
#include <vapi/sflow.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sflow_enable_disable>(vapi_msg_sflow_enable_disable *msg)
{
  vapi_msg_sflow_enable_disable_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_enable_disable>(vapi_msg_sflow_enable_disable *msg)
{
  vapi_msg_sflow_enable_disable_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_enable_disable>()
{
  return ::vapi_msg_id_sflow_enable_disable; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_enable_disable>>()
{
  return ::vapi_msg_id_sflow_enable_disable; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_enable_disable()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_enable_disable>(vapi_msg_id_sflow_enable_disable);
}

template <> inline vapi_msg_sflow_enable_disable* vapi_alloc<vapi_msg_sflow_enable_disable>(Connection &con)
{
  vapi_msg_sflow_enable_disable* result = vapi_alloc_sflow_enable_disable(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sflow_enable_disable>;

template class Request<vapi_msg_sflow_enable_disable, vapi_msg_sflow_enable_disable_reply>;

using Sflow_enable_disable = Request<vapi_msg_sflow_enable_disable, vapi_msg_sflow_enable_disable_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sflow_enable_disable_reply>(vapi_msg_sflow_enable_disable_reply *msg)
{
  vapi_msg_sflow_enable_disable_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_enable_disable_reply>(vapi_msg_sflow_enable_disable_reply *msg)
{
  vapi_msg_sflow_enable_disable_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_enable_disable_reply>()
{
  return ::vapi_msg_id_sflow_enable_disable_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_enable_disable_reply>>()
{
  return ::vapi_msg_id_sflow_enable_disable_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_enable_disable_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_enable_disable_reply>(vapi_msg_id_sflow_enable_disable_reply);
}

template class Msg<vapi_msg_sflow_enable_disable_reply>;

using Sflow_enable_disable_reply = Msg<vapi_msg_sflow_enable_disable_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sflow_sampling_rate>(vapi_msg_sflow_sampling_rate *msg)
{
  vapi_msg_sflow_sampling_rate_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_sampling_rate>(vapi_msg_sflow_sampling_rate *msg)
{
  vapi_msg_sflow_sampling_rate_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_sampling_rate>()
{
  return ::vapi_msg_id_sflow_sampling_rate; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_sampling_rate>>()
{
  return ::vapi_msg_id_sflow_sampling_rate; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_sampling_rate()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_sampling_rate>(vapi_msg_id_sflow_sampling_rate);
}

template <> inline vapi_msg_sflow_sampling_rate* vapi_alloc<vapi_msg_sflow_sampling_rate>(Connection &con)
{
  vapi_msg_sflow_sampling_rate* result = vapi_alloc_sflow_sampling_rate(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sflow_sampling_rate>;

template class Request<vapi_msg_sflow_sampling_rate, vapi_msg_sflow_sampling_rate_reply>;

using Sflow_sampling_rate = Request<vapi_msg_sflow_sampling_rate, vapi_msg_sflow_sampling_rate_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sflow_sampling_rate_reply>(vapi_msg_sflow_sampling_rate_reply *msg)
{
  vapi_msg_sflow_sampling_rate_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_sampling_rate_reply>(vapi_msg_sflow_sampling_rate_reply *msg)
{
  vapi_msg_sflow_sampling_rate_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_sampling_rate_reply>()
{
  return ::vapi_msg_id_sflow_sampling_rate_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_sampling_rate_reply>>()
{
  return ::vapi_msg_id_sflow_sampling_rate_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_sampling_rate_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_sampling_rate_reply>(vapi_msg_id_sflow_sampling_rate_reply);
}

template class Msg<vapi_msg_sflow_sampling_rate_reply>;

using Sflow_sampling_rate_reply = Msg<vapi_msg_sflow_sampling_rate_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sflow_polling_interval>(vapi_msg_sflow_polling_interval *msg)
{
  vapi_msg_sflow_polling_interval_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_polling_interval>(vapi_msg_sflow_polling_interval *msg)
{
  vapi_msg_sflow_polling_interval_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_polling_interval>()
{
  return ::vapi_msg_id_sflow_polling_interval; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_polling_interval>>()
{
  return ::vapi_msg_id_sflow_polling_interval; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_polling_interval()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_polling_interval>(vapi_msg_id_sflow_polling_interval);
}

template <> inline vapi_msg_sflow_polling_interval* vapi_alloc<vapi_msg_sflow_polling_interval>(Connection &con)
{
  vapi_msg_sflow_polling_interval* result = vapi_alloc_sflow_polling_interval(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sflow_polling_interval>;

template class Request<vapi_msg_sflow_polling_interval, vapi_msg_sflow_polling_interval_reply>;

using Sflow_polling_interval = Request<vapi_msg_sflow_polling_interval, vapi_msg_sflow_polling_interval_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sflow_polling_interval_reply>(vapi_msg_sflow_polling_interval_reply *msg)
{
  vapi_msg_sflow_polling_interval_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_polling_interval_reply>(vapi_msg_sflow_polling_interval_reply *msg)
{
  vapi_msg_sflow_polling_interval_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_polling_interval_reply>()
{
  return ::vapi_msg_id_sflow_polling_interval_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_polling_interval_reply>>()
{
  return ::vapi_msg_id_sflow_polling_interval_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_polling_interval_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_polling_interval_reply>(vapi_msg_id_sflow_polling_interval_reply);
}

template class Msg<vapi_msg_sflow_polling_interval_reply>;

using Sflow_polling_interval_reply = Msg<vapi_msg_sflow_polling_interval_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sflow_header_bytes>(vapi_msg_sflow_header_bytes *msg)
{
  vapi_msg_sflow_header_bytes_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_header_bytes>(vapi_msg_sflow_header_bytes *msg)
{
  vapi_msg_sflow_header_bytes_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_header_bytes>()
{
  return ::vapi_msg_id_sflow_header_bytes; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_header_bytes>>()
{
  return ::vapi_msg_id_sflow_header_bytes; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_header_bytes()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_header_bytes>(vapi_msg_id_sflow_header_bytes);
}

template <> inline vapi_msg_sflow_header_bytes* vapi_alloc<vapi_msg_sflow_header_bytes>(Connection &con)
{
  vapi_msg_sflow_header_bytes* result = vapi_alloc_sflow_header_bytes(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sflow_header_bytes>;

template class Request<vapi_msg_sflow_header_bytes, vapi_msg_sflow_header_bytes_reply>;

using Sflow_header_bytes = Request<vapi_msg_sflow_header_bytes, vapi_msg_sflow_header_bytes_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sflow_header_bytes_reply>(vapi_msg_sflow_header_bytes_reply *msg)
{
  vapi_msg_sflow_header_bytes_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sflow_header_bytes_reply>(vapi_msg_sflow_header_bytes_reply *msg)
{
  vapi_msg_sflow_header_bytes_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sflow_header_bytes_reply>()
{
  return ::vapi_msg_id_sflow_header_bytes_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sflow_header_bytes_reply>>()
{
  return ::vapi_msg_id_sflow_header_bytes_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sflow_header_bytes_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sflow_header_bytes_reply>(vapi_msg_id_sflow_header_bytes_reply);
}

template class Msg<vapi_msg_sflow_header_bytes_reply>;

using Sflow_header_bytes_reply = Msg<vapi_msg_sflow_header_bytes_reply>;
}
#endif
