#!/usr/bin/env python3
#
# Copyright (C) 2021-2023 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


#This script has not been tested with VyOS WWAN setup.

import argparse

from sys import exit
from vyos.configquery import ConfigTreeQuery
from vyos.utils.process import cmd



def qmi_cmd(device, command, silent=False):
    try:
        tmp = cmd(f'qmicli --device={device} --device-open-proxy {command}')
        tmp = tmp.replace(f'[{cdc}] ', '')
        if not silent:
            # skip first line as this only holds the info headline
            for line in tmp.splitlines()[1:]:
                print(line.lstrip())
        return tmp
    except:
        print('Command not supported by Modem')
        exit(1)

def parse_qmi_output(output: str) -> dict:
    """Convert any QMI hierarchical output to a dictionary structure"""
    result = {}
    stack = [result]
    prev_indent = 0
    
    for line in output.splitlines():
        if not line.strip():
            continue
        
        # Calculate indentation level
        curr_indent = len(line) - len(line.lstrip())
        line = line.strip()
        
        # Handle indentation changes
        if curr_indent > prev_indent:
            # We've gone deeper
            pass
        elif curr_indent < prev_indent:
            # We've come back up
            levels_up = (prev_indent - curr_indent) // 4  # Assuming 4-space indentation
            stack = stack[:-(levels_up)]
        
        # Process the line
        if ':' in line:
            key, value = [part.strip() for part in line.split(':', 1)]
            
            # Handle special cases like Card [0]:, Application [0]:
            if '[' in key and ']' in key and key.endswith(']:'):
                base_key = key.split('[')[0].strip()
                index = key.split('[')[1].split(']')[0]
                new_key = f"{base_key}_{index}"
                
                if base_key not in stack[-1]:
                    stack[-1][base_key] = {}
                
                stack[-1][base_key][new_key] = {}
                stack.append(stack[-1][base_key][new_key])
            else:
                # Process value
                if "'" in value:
                    value = value.strip("'")
                elif value.isdigit():
                    value = int(value)
                elif value.replace('.', '', 1).isdigit() and value.count('.') == 1:
                    value = float(value)
                    
                stack[-1][key] = value
        
        prev_indent = curr_indent
    
    return result


def show_all(raw: bool = True):
    """Return structured data for all WWAN interfaces
    
    Args:
        raw: Flag to indicate if this is for raw data/GraphQL use (default: True)
        
    Returns:
        If raw=True: List of dictionaries containing WWAN interface information
        If raw=False: Formatted string output (same as CLI command)
    """
    import io
    from contextlib import redirect_stdout
    
    try:
        # Try to import from the current directory or from vyos.op_mode
        try:
            from interfaces import _get_raw_data, _format_show_data
        except ImportError:
            try:
                from vyos.op_mode.interfaces import _get_raw_data, _format_show_data
            except ImportError:
                raise ImportError("Could not import required functions")
        
        # Get raw data for all WWAN interfaces
        data = _get_raw_data(ifname=None, iftype='wwan', vif=False, vrrp=False)
        
        if raw:
            # Transform the raw data to include all attributes from the command output
            result = []
            for intf in data:
                interface_data = {
                    'name': intf['ifname'],
                    'state': intf.get('operstate', 'UNKNOWN').upper(),
                    'mtu': intf.get('mtu', 0)
                }
                
                # Add flags, qdisc, group and qlen
                if 'flags' in intf:
                    interface_data['flags'] = intf['flags']
                if 'qdisc' in intf:
                    interface_data['qdisc'] = intf['qdisc']
                else:
                    interface_data['qdisc'] = 'fq_codel'  # Default value
                
                interface_data['group'] = intf.get('group', 'default')
                interface_data['qlen'] = intf.get('qlen', 1000)
                
                # Add link type
                interface_data['link_type'] = intf.get('link_type', 'none')
                
                # Add addresses with all attributes
                if 'addr_info' in intf:
                    interface_data['addresses'] = []
                    for addr in intf['addr_info']:
                        addr_obj = {
                            'address': f"{addr['local']}/{addr['prefixlen']}",
                            'family': addr.get('family', ''),
                            'scope': addr.get('scope', '')
                        }
                        
                        # Add broadcast address if present
                        if 'broadcast' in addr:
                            addr_obj['broadcast'] = addr['broadcast']
                        
                        # Add flags/attributes (dynamic, mngtmpaddr, etc.)
                        flags = []
                        if addr.get('dynamic', False):
                            flags.append('dynamic')
                        if addr.get('mngtmpaddr', False):
                            flags.append('mngtmpaddr')
                        if addr.get('noprefixroute', False):
                            flags.append('noprefixroute')
                        if addr.get('secondary', False):
                            flags.append('secondary')
                        if addr.get('tentative', False):
                            flags.append('tentative')
                        if addr.get('deprecated', False):
                            flags.append('deprecated')
                        if addr.get('dadfailed', False):
                            flags.append('dadfailed')
                        if addr.get('temporary', False):
                            flags.append('temporary')
                        if addr.get('stable-privacy', False) or 'stable-privacy' in str(addr):
                            flags.append('stable-privacy')
                            
                        addr_obj['flags'] = flags
                        
                        # Add valid and preferred lifetimes if present
                        if 'valid_life_time' in addr:
                            if addr['valid_life_time'] == 4294967295:
                                addr_obj['valid_lft'] = 'forever'
                            else:
                                addr_obj['valid_lft'] = f"{addr['valid_life_time']}sec"
                                
                        if 'preferred_life_time' in addr:
                            if addr['preferred_life_time'] == 4294967295:
                                addr_obj['preferred_lft'] = 'forever'
                            else:
                                addr_obj['preferred_lft'] = f"{addr['preferred_life_time']}sec"
                        
                        # Add protocol information
                        if 'proto' in addr:
                            addr_obj['proto'] = addr['proto']
                        elif 'kernel_ra' in str(addr) or 'SLAAC' in str(addr):
                            addr_obj['proto'] = 'kernel_ra'
                        elif 'kernel_ll' in str(addr):
                            addr_obj['proto'] = 'kernel_ll'
                            
                        interface_data['addresses'].append(addr_obj)
                
                # Add MAC address if present
                if 'address' in intf:
                    interface_data['mac'] = intf['address']
                
                # Add description if present
                if 'description' in intf and intf['description']:
                    interface_data['description'] = intf['description']
                
                # Add statistics
                if 'stats' in intf:
                    interface_data['statistics'] = {
                        'rx': {
                            'bytes': intf['stats'].get('rx_bytes', 0),
                            'packets': intf['stats'].get('rx_packets', 0),
                            'errors': intf['stats'].get('rx_errors', 0),
                            'dropped': intf['stats'].get('rx_dropped', 0),
                            'overrun': intf['stats'].get('rx_over_errors', 0),
                            'mcast': intf['stats'].get('multicast', 0)
                        },
                        'tx': {
                            'bytes': intf['stats'].get('tx_bytes', 0),
                            'packets': intf['stats'].get('tx_packets', 0),
                            'errors': intf['stats'].get('tx_errors', 0),
                            'dropped': intf['stats'].get('tx_dropped', 0),
                            'carrier': intf['stats'].get('tx_carrier_errors', 0),
                            'collisions': intf['stats'].get('collisions', 0)
                        }
                    }
                
                # Add timestamps for counters
                if 'counters_last_clear' in intf:
                    interface_data['counters_last_clear'] = intf['counters_last_clear']
                
                result.append(interface_data)
            
            return result
        else:
            # For raw=False, capture the formatted output from _format_show_data
            output_buffer = io.StringIO()
            with redirect_stdout(output_buffer):
                _format_show_data(data)
            return output_buffer.getvalue()
            
    except ImportError as e:
        # Fallback implementation if all imports fail
        from vyos.configquery import ConfigTreeQuery
        from vyos.utils.process import cmd
        import json
        import re
        
        # Get interfaces from config
        config = ConfigTreeQuery()
        interfaces = []
        
        if config.exists(['interfaces', 'wwan']):
            wwan_interfaces = config.list_nodes(['interfaces', 'wwan'])
            for intf in wwan_interfaces:
                interfaces.append(intf)
        
        # If no interfaces found, return empty result
        if not interfaces:
            if not raw:
                return "No WWAN interfaces configured"
            return []
        
        # Get information for each interface
        result = []
        
        for intf in interfaces:
            # Get detailed interface information using ip addr show with full details
            try:
                ip_output = cmd(f'ip -j addr show dev {intf}')
                intf_data = json.loads(ip_output)[0]
                
                # Format the data for GraphQL output
                interface_data = {
                    'name': intf,
                    'state': intf_data.get('operstate', 'UNKNOWN').upper(),
                    'mtu': intf_data.get('mtu', 0)
                }
                
                # Add flags, qdisc, group and qlen
                if 'flags' in intf_data:
                    interface_data['flags'] = intf_data['flags']
                if 'qdisc' in intf_data:
                    interface_data['qdisc'] = intf_data['qdisc']
                else:
                    interface_data['qdisc'] = 'fq_codel'  # Default value
                
                interface_data['group'] = intf_data.get('group', 'default')
                interface_data['qlen'] = intf_data.get('qlen', 1000)
                
                # Add link type
                interface_data['link_type'] = intf_data.get('link_type', 'none')
                
                # Add addresses with all attributes
                if 'addr_info' in intf_data:
                    interface_data['addresses'] = []
                    for addr in intf_data['addr_info']:
                        addr_obj = {
                            'address': f"{addr['local']}/{addr['prefixlen']}",
                            'family': addr.get('family', ''),
                            'scope': addr.get('scope', '')
                        }
                        
                        # Add broadcast address if present
                        if 'broadcast' in addr:
                            addr_obj['broadcast'] = addr['broadcast']
                        
                        # Add valid and preferred lifetimes if present
                        if 'valid_life_time' in addr:
                            if addr['valid_life_time'] == 4294967295:
                                addr_obj['valid_lft'] = 'forever'
                            else:
                                addr_obj['valid_lft'] = f"{addr['valid_life_time']}sec"
                                
                        if 'preferred_life_time' in addr:
                            if addr['preferred_life_time'] == 4294967295:
                                addr_obj['preferred_lft'] = 'forever'
                            else:
                                addr_obj['preferred_lft'] = f"{addr['preferred_life_time']}sec"
                                
                        # Extract other flags from label (dynamic, etc.)
                        if 'label' in addr:
                            label = addr['label']
                            flags = []
                            
                            if 'dynamic' in label:
                                flags.append('dynamic')
                            if 'mngtmpaddr' in label:
                                flags.append('mngtmpaddr')
                            if 'stable-privacy' in label:
                                flags.append('stable-privacy')
                                
                            addr_obj['flags'] = flags
                            
                        interface_data['addresses'].append(addr_obj)
                
                # Add MAC address if present
                if 'address' in intf_data:
                    interface_data['mac'] = intf_data['address']
                
                # Get statistics
                try:
                    stats = {
                        'rx': {
                            'bytes': int(cmd(f'cat /sys/class/net/{intf}/statistics/rx_bytes').strip()),
                            'packets': int(cmd(f'cat /sys/class/net/{intf}/statistics/rx_packets').strip()),
                            'errors': int(cmd(f'cat /sys/class/net/{intf}/statistics/rx_errors').strip()),
                            'dropped': int(cmd(f'cat /sys/class/net/{intf}/statistics/rx_dropped').strip()),
                            'overrun': int(cmd(f'cat /sys/class/net/{intf}/statistics/rx_over_errors').strip()),
                            'mcast': int(cmd(f'cat /sys/class/net/{intf}/statistics/multicast').strip())
                        },
                        'tx': {
                            'bytes': int(cmd(f'cat /sys/class/net/{intf}/statistics/tx_bytes').strip()),
                            'packets': int(cmd(f'cat /sys/class/net/{intf}/statistics/tx_packets').strip()),
                            'errors': int(cmd(f'cat /sys/class/net/{intf}/statistics/tx_errors').strip()),
                            'dropped': int(cmd(f'cat /sys/class/net/{intf}/statistics/tx_dropped').strip()),
                            'carrier': int(cmd(f'cat /sys/class/net/{intf}/statistics/tx_carrier_errors').strip()),
                            'collisions': int(cmd(f'cat /sys/class/net/{intf}/statistics/collisions').strip())
                        }
                    }
                    interface_data['statistics'] = stats
                except:
                    pass
                
                # Get interface description
                try:
                    description = cmd(f'cat /sys/class/net/{intf}/ifalias').strip()
                    if description:
                        interface_data['description'] = description
                except:
                    pass
                
                result.append(interface_data)
            except:
                # If we can't get detailed info, add basic entry
                result.append({'name': intf, 'state': 'UNKNOWN'})
        
        if raw:
            return result
        else:
            # Format the output similar to 'ip addr show'
            output_lines = []
            
            for intf_data in result:
                # Format flags
                flags = ','.join(intf_data.get('flags', ['POINTOPOINT', 'MULTICAST', 'NOARP']))
                
                # Basic interface line
                output_lines.append(f"{intf_data['name']}: <{flags}{',UP,LOWER_UP' if intf_data.get('state') == 'UP' else ''}> mtu {intf_data.get('mtu', 'unknown')} qdisc {intf_data.get('qdisc', 'fq_codel')} state {intf_data.get('state', 'UNKNOWN')} group {intf_data.get('group', 'default')} qlen {intf_data.get('qlen', 1000)}")
                
                # Link line
                if 'mac' in intf_data:
                    output_lines.append(f"    link/ether {intf_data['mac']}")
                else:
                    output_lines.append(f"    link/{intf_data.get('link_type', 'none')} ")
                
                # Address lines with all attributes
                if 'addresses' in intf_data:
                    for addr in intf_data['addresses']:
                        # Determine if IPv4 or IPv6
                        is_ipv6 = ':' in addr['address']
                        prefix = 'inet6 ' if is_ipv6 else 'inet '
                        
                        # Format attributes
                        attrs = []
                        
                        # Add broadcast if present (IPv4 only)
                        brd = f" brd {addr['broadcast']}" if 'broadcast' in addr and not is_ipv6 else ""
                        
                        # Add scope
                        scope = f" scope {addr['scope']}" if 'scope' in addr else ""
                        
                        # Add flags
                        if 'flags' in addr:
                            attrs.extend(addr['flags'])
                        
                        # Format the full address line
                        addr_line = f"    {prefix}{addr['address']}{brd}{scope}"
                        
                        # Add attributes if any
                        if attrs:
                            addr_line += " " + " ".join(attrs)
                        
                        output_lines.append(addr_line)
                        
                        # Add lifetimes on the next line, indented
                        lifetimes = []
                        if 'valid_lft' in addr:
                            lifetimes.append(f"valid_lft {addr['valid_lft']}")
                        if 'preferred_lft' in addr:
                            lifetimes.append(f"preferred_lft {addr['preferred_lft']}")
                        
                        if lifetimes:
                            output_lines.append(f"       {' '.join(lifetimes)}")
                
                # Add description if present
                if 'description' in intf_data:
                    output_lines.append(f"    Description: {intf_data['description']}")
                
                # Add statistics
                if 'statistics' in intf_data:
                    stats = intf_data['statistics']
                    output_lines.append("")
                    output_lines.append("    RX:  bytes  packets  errors  dropped  overrun       mcast")
                    output_lines.append(f"         {stats['rx']['bytes']}  {stats['rx']['packets']}  {stats['rx']['errors']}  {stats['rx']['dropped']}  {stats['rx']['overrun']}  {stats['rx']['mcast']}")
                    output_lines.append("    TX:  bytes  packets  errors  dropped  carrier  collisions")
                    output_lines.append(f"         {stats['tx']['bytes']}  {stats['tx']['packets']}  {stats['tx']['errors']}  {stats['tx']['dropped']}  {stats['tx']['carrier']}  {stats['tx']['collisions']}")
            
            return "\n".join(output_lines)
        
def show_capability(raw: bool = True, intf_name: str = None):
    """Return structured data for WWAN interface capabilities
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing WWAN capabilities information
        If raw=False: Formatted string output (same as CLI command)
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    import json
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return [] if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return [] if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan', '')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get capabilities
        capabilities_output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-capabilities')
        band_capabilities_output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-band-capabilities')
        
        # Remove device prefix from output
        capabilities_output = capabilities_output.replace(f'[{cdc}] ', '')
        band_capabilities_output = band_capabilities_output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            result = {}
            capabilities_data = {}
            
            # Parse capabilities output
            lines = capabilities_output.splitlines()[1:]  # Skip header line
            current_section = "capabilities"
            capabilities_data = {}
            
            for line in lines:
                line = line.lstrip()
                if not line:
                    continue
                    
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Fix the specific field names we need to change
                    if key == 'Max T-xchannelrate':
                        key = 'max_tx_channel_rate'
                    elif key == 'Max R-xchannelrate':
                        key = 'max_rx_channel_rate'
                    else:
                        # Convert other keys to lowercase with underscores
                        key = key.lower().replace(' ', '_').replace('-', '_')
                    
                    capabilities_data[key] = value
            
            # Parse band capabilities output
            band_data = {}
            lines = band_capabilities_output.splitlines()[1:]  # Skip header line
            
            for line in lines:
                line = line.lstrip()
                if not line:
                    continue
                    
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Convert keys to lowercase with underscores
                    key = key.lower().replace(' ', '_').replace('-', '_')
                    
                    band_data[key] = value
            
            # Combine both outputs
            result = {
                'capabilities': capabilities_data,
                'band_capabilities': band_data
            }
            
            return result
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in capabilities_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            # Skip header line and format output
            for line in band_capabilities_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': str(e)} if raw else None
    
def show_detail(raw: bool = True, intf_name: str = None):
    """Return modem information for a WWAN interface using ModemManager
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing modem information
        If raw=False: Formatted string output (same as CLI command)
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    import re
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Extract modem number from wwan interface name (wwan0 -> 0)
    modem_num = intf_name.replace('wwan', '')
    
    try:
        # Run mmcli command to get modem information
        output = cmd(f'mmcli --modem {modem_num}')
        
        if raw:
            # Initialize result with interface name and all sections
            result = {
                'interface': intf_name,
                'general': {},
                'hardware': {},
                'system': {},
                'numbers': {},
                'status': {},
                'modes': {'supported': [], 'current': []},
                'bands': {'supported': [], 'current': []},
                'ip': {},
                'threegpp': {},
                'threegpp_eps': {},
                'sim': {},
                'bearer': {}
            }
            
            # Split the output into sections by the divider lines
            sections = []
            current_section = []
            in_section = False
            
            lines = output.splitlines()
            for line in lines:
                if re.match(r'^\s*-+\s*$', line):
                    # This is a section divider
                    if in_section and current_section:
                        sections.append(current_section)
                        current_section = []
                    in_section = True
                elif in_section:
                    current_section.append(line)
            
            # Add the last section if there is one
            if current_section:
                sections.append(current_section)
            
            # Process each section
            for section in sections:
                if not section:
                    continue
                
                # First line of the section contains the section name
                header_line = section[0].strip()
                if '|' not in header_line:
                    continue
                
                # Extract section name
                section_name = header_line.split('|')[0].strip().lower().replace(' ', '_')
                
                # Handle section names that start with numbers
                if section_name == '3gpp':
                    section_name = 'threegpp'
                elif section_name == '3gpp_eps':
                    section_name = 'threegpp_eps'
                
                # Process the content lines in this section
                for i in range(1, len(section)):
                    line = section[i].strip()
                    if not line or '|' not in line:
                        continue
                    
                    parts = line.split('|', 1)
                    prefix = parts[0].strip()
                    content = parts[1].strip()
                    
                    # If prefix is non-empty, this is a new key-value pair
                    if prefix:
                        continue  # Skip header lines
                    
                    # Process content for key-value pairs
                    if ':' in content:
                        # This is likely a key-value pair
                        key_value = content.split(':', 1)
                        key = key_value[0].strip().lower().replace(' ', '_')
                        value = key_value[1].strip()
                        
                        # Remove ANSI color codes
                        value = re.sub(r'\x1b\[[0-9;]*m', '', value)
                        
                        # Store in the appropriate section
                        if section_name == 'modes':
                            if key == 'supported':
                                result['modes']['supported'].append(value)
                            elif key == 'current':
                                result['modes']['current'].append(value)
                            else:
                                result['modes'][key] = value
                        elif section_name == 'bands':
                            if key in ['supported', 'current']:
                                # Process bands as an array
                                bands = []
                                for band in value.split(','):
                                    band = band.strip()
                                    if band:
                                        bands.append(band)
                                if result['bands'][key]:
                                    result['bands'][key].extend(bands)
                                else:
                                    result['bands'][key] = bands
                            else:
                                result['bands'][key] = value
                        else:
                            # For all other sections, just store the key-value pair
                            if section_name in result:
                                result[section_name][key] = value
                    elif section_name == 'modes':
                        # This is likely a continuation of modes
                        # Check which one it's continuing (supported or current)
                        if 'supported: ' in section[i-1].lower():
                            result['modes']['supported'].append(content)
                        elif 'current: ' in section[i-1].lower():
                            result['modes']['current'].append(content)
                        # Otherwise, try to determine based on indentation and previous content
                        elif i > 1 and not section[i-1].strip().split('|')[0].strip():
                            # This is a continuation of a continuation
                            if result['modes']['supported'] and not result['modes']['current']:
                                result['modes']['supported'].append(content)
                            elif result['modes']['current']:
                                result['modes']['current'].append(content)
                    elif section_name == 'bands':
                        # This is likely a continuation of bands
                        # Process bands as an array
                        bands = []
                        for band in content.split(','):
                            band = band.strip()
                            if band:
                                bands.append(band)
                        
                        # Check which one it's continuing (supported or current)
                        if 'supported: ' in section[i-1].lower():
                            result['bands']['supported'].extend(bands)
                        elif 'current: ' in section[i-1].lower():
                            result['bands']['current'].extend(bands)
                        # Otherwise, try to determine based on last populated field
                        elif result['bands']['supported'] and not result['bands']['current']:
                            result['bands']['supported'].extend(bands)
                        elif result['bands']['current']:
                            result['bands']['current'].extend(bands)
            
            # Now manually add any missing fields based on specific patterns
            # This ensures we capture all fields even if the section-based parsing missed them
            
            # Extract all key-value pairs from the raw output
            for line in lines:
                line = line.strip()
                if '|' in line:
                    content = line.split('|', 1)[1].strip()
                    
                    # Look for specific missing fields
                    if 'path:' in content:
                        match = re.search(r'path:\s*(/[^\s]+)', content)
                        if match and 'path' not in result['general']:
                            result['general']['path'] = match.group(1)
                    
                    elif 'manufacturer:' in content:
                        match = re.search(r'manufacturer:\s*(\S+)', content)
                        if match and 'manufacturer' not in result['hardware']:
                            result['hardware']['manufacturer'] = match.group(1)
                    
                    elif 'device:' in content and 'system' in result:
                        match = re.search(r'device:\s*(/[^\s]+)', content)
                        if match and 'device' not in result['system']:
                            result['system']['device'] = match.group(1)
                    
                    elif 'own:' in content:
                        match = re.search(r'own:\s*(\S+)', content)
                        if match and 'own' not in result['numbers']:
                            result['numbers']['own'] = match.group(1)
                    
                    elif 'lock:' in content:
                        match = re.search(r'lock:\s*(\S+)', content)
                        if match and 'lock' not in result['status']:
                            result['status']['lock'] = match.group(1)
                    
                    elif 'supported:' in content and 'ip:' in line.lower():
                        match = re.search(r'supported:\s*(.+)$', content)
                        if match and 'supported' not in result['ip']:
                            result['ip']['supported'] = match.group(1)
                    
                    elif 'imei:' in content:
                        match = re.search(r'imei:\s*(\S+)', content)
                        if match and 'imei' not in result['threegpp']:
                            result['threegpp']['imei'] = match.group(1)
                    
                    elif 'ue mode of operation:' in content.lower():
                        match = re.search(r'ue\s+mode\s+of\s+operation:\s*(\S+)', content, re.IGNORECASE)
                        if match and 'ue_mode_of_operation' not in result['threegpp_eps']:
                            result['threegpp_eps']['ue_mode_of_operation'] = match.group(1)
                    
                    elif 'primary sim path:' in content.lower():
                        match = re.search(r'primary\s+sim\s+path:\s*(/\S+)', content, re.IGNORECASE)
                        if match and 'primary_sim_path' not in result['sim']:
                            result['sim']['primary_sim_path'] = match.group(1)
                    
                    elif 'paths:' in content and 'bearer' in line.lower():
                        match = re.search(r'paths:\s*(/\S+)', content)
                        if match and 'paths' not in result['bearer']:
                            result['bearer']['paths'] = match.group(1)
            
            # Fix slot 2 in SIM section to match format
            if 'slot_2' in result['sim'] and 'sim_slot_paths' in result['sim']:
                # Append slot 2 to sim_slot_paths
                slot2_value = result['sim']['slot_2']
                result['sim']['sim_slot_paths'] += ', slot 2: ' + slot2_value
                # Remove the separate slot_2 field
                del result['sim']['slot_2']
            
            # FIX 1: Fix truncated ports value in System section
            # Use a simpler string-based approach instead of regex
            system_section_lines = []
            in_system_section = False
            for line in lines:
                if "System" in line and "|" in line:
                    in_system_section = True
                    system_section_lines.append(line)
                elif in_system_section and "--" in line:  # End of section
                    in_system_section = False
                elif in_system_section:
                    system_section_lines.append(line)
            
            # Find the ports entry and its continuation lines
            ports_start_index = -1
            for i, line in enumerate(system_section_lines):
                if "ports:" in line:
                    ports_start_index = i
                    break
            
            if ports_start_index >= 0:
                # Extract the initial ports value
                ports_line = system_section_lines[ports_start_index]
                parts = ports_line.split('ports:', 1)
                if len(parts) > 1:
                    ports_value = parts[1].strip()
                    
                    # Look for continuation lines
                    i = ports_start_index + 1
                    while i < len(system_section_lines):
                        line = system_section_lines[i].strip()
                        # Check if this is a continuation line (empty prefix before pipe)
                        if '|' in line:
                            prefix = line.split('|', 1)[0].strip()
                            if not prefix:
                                # This is a continuation line - extract content after pipe
                                content = line.split('|', 1)[1].strip()
                                # Add to ports value if not a new key-value pair
                                if ':' not in content or content.startswith('tty') or content.startswith('wwan'):
                                    ports_value += ' ' + content
                                else:
                                    # This is a new key-value pair, not a continuation
                                    break
                            else:
                                # Not a continuation line
                                break
                        i += 1
                    
                    # Update the result with the complete ports value
                    result['system']['ports'] = ports_value
            
            # FIX 2: Fix supported modes in Modes section and remove "current" from supported list
            # Process the raw output to find all supported modes
            modes_section = ""
            in_modes_section = False
            for line in lines:
                if "Modes" in line and "|" in line:
                    in_modes_section = True
                    modes_section = line + "\n"
                elif in_modes_section and "--" in line:  # End of section
                    in_modes_section = False
                    break
                elif in_modes_section:
                    modes_section += line + "\n"
            
            # Reset modes arrays to ensure clean processing
            result['modes']['supported'] = []
            result['modes']['current'] = []
            
            # Process the modes section
            in_supported = False
            in_current = False
            
            for line in modes_section.splitlines():
                if "supported:" in line.lower() and "|" in line:
                    in_supported = True
                    in_current = False
                    # Extract the value after "supported:"
                    content = line.split("|", 1)[1].strip()
                    value = content.split(":", 1)[1].strip()
                    result['modes']['supported'].append(value)
                elif "current:" in line.lower() and "|" in line:
                    in_supported = False
                    in_current = True
                    # Extract the value after "current:"
                    content = line.split("|", 1)[1].strip()
                    value = content.split(":", 1)[1].strip()
                    result['modes']['current'].append(value)
                elif "|" in line and not line.split("|")[0].strip():
                    # This is a continuation line
                    content = line.split("|", 1)[1].strip()
                    if in_supported:
                        result['modes']['supported'].append(content)
                    elif in_current:
                        result['modes']['current'].append(content)
            
            # Remove the 'allowed' field from modes if it exists
            if 'allowed' in result['modes']:
                del result['modes']['allowed']
            
            # Fix IP section to include supported IP types
            ip_section = ""
            in_ip_section = False
            for line in lines:
                if "IP" in line and "|" in line:
                    in_ip_section = True
                    ip_section = line + "\n"
                elif in_ip_section and "--" in line:  # End of section
                    in_ip_section = False
                    break
                elif in_ip_section:
                    ip_section += line + "\n"
            
            # Extract supported IP types
            for line in ip_section.splitlines():
                if "supported:" in line.lower() and "|" in line:
                    content = line.split("|", 1)[1].strip()
                    if ":" in content:
                        value = content.split(":", 1)[1].strip()
                        result['ip']['supported'] = value
            
            return result
        else:
            # Return formatted output for CLI display
            return output
            
    except Exception as e:
        if not raw:
            print(f'Error getting modem information: {str(e)}')
        return {'error': str(e), 'interface': intf_name} if raw else None
    
    
def show_log(raw: bool = True, intf_name: str = None):
    """Return log entries for a specific WWAN interface from the system journal
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: List of dictionaries containing log entries
        If raw=False: Formatted string output
    """
    from vyos.utils.process import cmd
    import json
    from datetime import datetime
    import re
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return [] if raw else None
    
    try:
        # Query the journal for logs related to this interface
        journal_cmd = f'journalctl --no-hostname --boot --unit vyos-network-event-logger.service --grep "\\b{intf_name}\\b"'
        output = cmd(journal_cmd)
        
        if not output:
            return [] if raw else "No log entries found for this interface"
        
        if raw:
            # Parse the journal output into structured data
            log_entries = []
            
            # Example log line: May 26 10:15:23 vyos-network-event-logger[1234]: wwan0: state changed to connected
            log_pattern = re.compile(r'(\w+\s+\d+\s+\d+:\d+:\d+)\s+([^:]+):\s+(.*)')
            
            for line in output.splitlines():
                match = log_pattern.match(line)
                if match:
                    timestamp_str, process, message = match.groups()
                    
                    # Try to parse the timestamp
                    try:
                        # Add current year since journal output doesn't include it
                        current_year = datetime.now().year
                        timestamp_with_year = f"{timestamp_str} {current_year}"
                        timestamp = datetime.strptime(timestamp_with_year, "%b %d %H:%M:%S %Y")
                    except:
                        # If parsing fails, just use the original string
                        timestamp = timestamp_str
                    
                    # Extract more structured info from the message
                    interface_match = re.search(r'(\w+\d+):', message)
                    interface = interface_match.group(1) if interface_match else intf_name
                    
                    # Create the log entry
                    entry = {
                        'timestamp': timestamp.isoformat() if isinstance(timestamp, datetime) else timestamp,
                        'process': process,
                        'interface': interface,
                        'message': message,
                        'raw_log': line
                    }
                    
                    # Try to categorize the message
                    if 'state changed' in message:
                        state_match = re.search(r'state changed to (\w+)', message)
                        if state_match:
                            entry['event_type'] = 'state_change'
                            entry['new_state'] = state_match.group(1)
                    elif 'connected' in message:
                        entry['event_type'] = 'connection'
                    elif 'disconnected' in message:
                        entry['event_type'] = 'disconnection'
                    elif 'error' in message.lower():
                        entry['event_type'] = 'error'
                    else:
                        entry['event_type'] = 'other'
                    
                    log_entries.append(entry)
                else:
                    # If the line doesn't match the expected format, add it as-is
                    log_entries.append({
                        'raw_log': line,
                        'interface': intf_name,
                        'event_type': 'unknown'
                    })
            
            return log_entries
        else:
            # For CLI output, just return the raw journal output
            return output
            
    except Exception as e:
        if not raw:
            print(f'Error retrieving logs: {str(e)}')
        return {'error': str(e)} if raw else f"Error: {str(e)}"
    
def show_firmware(raw: bool = True, intf_name: str = None):
    """Return firmware information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing firmware information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # First get the manufacturer
        manufacturer_output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-manufacturer')
        manufacturer_output = manufacturer_output.replace(f'[{cdc}] ', '')
        
        # Select the firmware command based on manufacturer
        if 'Sierra Wireless' in manufacturer_output:
            firmware_cmd = f'qmicli --device={cdc} --device-open-proxy --dms-swi-get-current-firmware'
        else:
            firmware_cmd = f'qmicli --device={cdc} --device-open-proxy --dms-get-software-version'
        
        # Get firmware information
        firmware_output = cmd(firmware_cmd)
        firmware_output = firmware_output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            firmware_data = {'interface': intf_name}
            
            # Process manufacturer output (skip header line)
            for line in manufacturer_output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip().lower().replace(' ', '_')
                    value = value.strip()
                    firmware_data[key] = value
            
            # Process firmware output (skip header line)
            for line in firmware_output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip().lower().replace(' ', '_')
                    value = value.strip()
                    firmware_data[key] = value
            
            return firmware_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in manufacturer_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            # Skip header line and format output
            for line in firmware_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    

def show_imei(raw: bool = True, intf_name: str = None):
    """Return IMEI/ESN/MEID information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing device identifier information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    import re
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan', '')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Run qmicli command to get device IDs
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-ids')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            ids_data = {}
            
            # Skip the header line
            for line in output.splitlines()[1:]:
                line = line.strip()
                if not line:
                    continue
                
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip()
                    value = parts[1].strip() if len(parts) > 1 else ""
                    
                    # Clean up key
                    key = key.lower().replace(' ', '_')
                    
                    # Handle IMEI specially
                    if 'imei' in key:
                        # Extract just the IMEI number without check digit info
                        imei_match = re.search(r'\'(\d+)\'', value)
                        if imei_match:
                            ids_data['imei'] = imei_match.group(1)
                        # Keep the original value with details
                        ids_data[f'{key}_full'] = value
                    else:
                        # For other IDs, clean up the value
                        if "'" in value:
                            value = re.search(r"'([^']*)'", value)
                            if value:
                                value = value.group(1)
                        
                        ids_data[key] = value
            
            # Add interface info
            ids_data['interface'] = intf_name
            
            return ids_data
        else:
            # Format output for CLI display
            formatted_output = []
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': str(e)} if raw else None
    
def show_imsi(raw: bool = True, intf_name: str = None):
    """Return IMSI information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing IMSI information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get IMSI information
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-uim-get-imsi')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            imsi_data = {'interface': intf_name}
            
            # Process output (skip header line)
            for line in output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().lower().replace(' ', '_')
                    value = parts[1].strip()
                    
                    # Clean up value (remove quotes)
                    if value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]
                        
                    imsi_data[key] = value
            
            return imsi_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    
def show_model(raw: bool = True, intf_name: str = None):
    """Return model information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing model information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get model information
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-model')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            model_data = {'interface': intf_name}
            
            # Process output (skip header line)
            for line in output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().lower().replace(' ', '_')
                    value = parts[1].strip()
                    model_data[key] = value
            
            return model_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    
def show_msisdn(raw: bool = True, intf_name: str = None):
    """Return MSISDN (phone number) information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing MSISDN information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get MSISDN information
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-msisdn')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            msisdn_data = {'interface': intf_name}
            
            # Process output (skip header line)
            for line in output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().lower().replace(' ', '_')
                    value = parts[1].strip()
                    
                    # Clean up value (remove quotes)
                    if value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]
                        
                    msisdn_data[key] = value
            
            return msisdn_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    
def show_revision(raw: bool = True, intf_name: str = None):
    """Return revision information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing revision information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get revision information
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --dms-get-revision')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            revision_data = {'interface': intf_name}
            
            # Process output (skip header line)
            for line in output.splitlines()[1:]:
                line = line.strip()
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip().lower().replace(' ', '_')
                    value = parts[1].strip()
                    
                    # Clean up value (remove quotes)
                    if value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]
                        
                    revision_data[key] = value
            
            return revision_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    
def show_signal(raw: bool = True, intf_name: str = None):
    """Return signal information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing signal information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get signal information
        signal_output = cmd(f'qmicli --device={cdc} --device-open-proxy --nas-get-signal-info')
        signal_output = signal_output.replace(f'[{cdc}] ', '')
        
        # Get RF band information
        band_output = cmd(f'qmicli --device={cdc} --device-open-proxy --nas-get-rf-band-info')
        band_output = band_output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            signal_data = {'interface': intf_name}
            
            # Process signal output (skip header line)
            current_section = 'signal_info'
            signal_data[current_section] = {}
            
            for line in signal_output.splitlines()[1:]:
                line = line.strip()
                if not line:
                    continue
                    
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip()
                    value = parts[1].strip() if len(parts) > 1 else ""
                    
                    # If value is empty, this might be a section header
                    if not value and ':' in line:
                        current_section = key.lower().replace(' ', '_')
                        if current_section not in signal_data:
                            signal_data[current_section] = {}
                    else:
                        # Clean up key
                        key = key.lower().replace(' ', '_')
                        
                        # Try to convert numeric values
                        if value.isdigit():
                            value = int(value)
                        elif value.replace('.', '', 1).isdigit() and value.count('.') == 1:
                            value = float(value)
                        elif value.lower() == 'yes':
                            value = True
                        elif value.lower() == 'no':
                            value = False
                        
                        # Add to current section
                        if current_section not in signal_data:
                            signal_data[current_section] = {}
                        signal_data[current_section][key] = value
            
            # Process band output (skip header line)
            current_section = 'rf_band_info'
            signal_data[current_section] = {}
            
            for line in band_output.splitlines()[1:]:
                line = line.strip()
                if not line:
                    continue
                    
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip()
                    value = parts[1].strip() if len(parts) > 1 else ""
                    
                    # If value is empty, this might be a section header
                    if not value and ':' in line:
                        current_section = key.lower().replace(' ', '_')
                        if current_section not in signal_data:
                            signal_data[current_section] = {}
                    else:
                        # Clean up key
                        key = key.lower().replace(' ', '_')
                        
                        # Try to convert numeric values
                        if value.isdigit():
                            value = int(value)
                        elif value.replace('.', '', 1).isdigit() and value.count('.') == 1:
                            value = float(value)
                        elif value.lower() == 'yes':
                            value = True
                        elif value.lower() == 'no':
                            value = False
                        
                        # Add to current section
                        if current_section not in signal_data:
                            signal_data[current_section] = {}
                        signal_data[current_section][key] = value
            
            return signal_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output for signal info
            for line in signal_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            # Skip header line and format output for band info
            for line in band_output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
    
def show_sim(raw: bool = True, intf_name: str = None):
    """Return SIM card status information for a WWAN interface
    
    Args:
        raw: Flag to indicate if this is for GraphQL use (default: True)
        intf_name: WWAN interface name (e.g. 'wwan0')
        
    Returns:
        If raw=True: Dictionary containing SIM card status information
        If raw=False: Formatted string output
    """
    from vyos.configquery import ConfigTreeQuery
    from vyos.utils.process import cmd
    
    if not intf_name:
        if not raw:
            print("WWAN interface name is required")
        return {} if raw else None
    
    # Check if interface exists in configuration
    config = ConfigTreeQuery()
    if not config.exists(['interfaces', 'wwan', intf_name]):
        if not raw:
            print(f'Interface "{intf_name}" unconfigured!')
        return {} if raw else None
    
    # Get CDC device path
    if_num = intf_name.replace('wwan','')
    cdc = f'/dev/cdc-wdm{if_num}'
    
    try:
        # Get SIM card status information
        output = cmd(f'qmicli --device={cdc} --device-open-proxy --uim-get-card-status')
        output = output.replace(f'[{cdc}] ', '')
        
        if raw:
            # Parse output into structured data
            sim_data = {'interface': intf_name}
            
            # Process output (skip header line)
            current_section = 'card_status'
            sim_data[current_section] = {}
            
            for line in output.splitlines()[1:]:
                line = line.strip()
                if not line:
                    continue
                    
                if ':' in line:
                    parts = line.split(':', 1)
                    key = parts[0].strip()
                    value = parts[1].strip() if len(parts) > 1 else ""
                    
                    # If value is empty, this might be a section header
                    if not value and ':' in line:
                        current_section = key.lower().replace(' ', '_')
                        if current_section not in sim_data:
                            sim_data[current_section] = {}
                    else:
                        # Clean up key
                        key = key.lower().replace(' ', '_')
                        
                        # Try to convert numeric values
                        if value.isdigit():
                            value = int(value)
                        elif value.replace('.', '', 1).isdigit() and value.count('.') == 1:
                            value = float(value)
                        elif value.lower() == 'yes':
                            value = True
                        elif value.lower() == 'no':
                            value = False
                        elif value.startswith("'") and value.endswith("'"):
                            # Remove quotes from string values
                            value = value[1:-1]
                        
                        # Add to current section
                        if current_section not in sim_data:
                            sim_data[current_section] = {}
                        sim_data[current_section][key] = value
            
            return sim_data
        else:
            # Format output exactly like the CLI command
            formatted_output = []
            
            # Skip header line and format output
            for line in output.splitlines()[1:]:
                formatted_output.append(line.lstrip())
            
            return '\n'.join(formatted_output)
            
    except Exception as e:
        if not raw:
            print('Command not supported by Modem')
        return {'error': 'Command not supported by Modem', 'interface': intf_name} if raw else None
if __name__ == '__main__':
    exit(1)