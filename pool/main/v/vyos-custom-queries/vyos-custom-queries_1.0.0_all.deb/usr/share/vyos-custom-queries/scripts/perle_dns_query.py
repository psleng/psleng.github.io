#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL-friendly query for DNS nameserver configuration.

Reads /etc/resolv.conf and related config files to return:
  - Nameserver IP/IPv6 addresses
  - Source notes (e.g., eth0-dhcp, system, static)
"""

import sys
import os
import re
import ipaddress
import vyos.opmode
from vyos.utils.process import rc_cmd


RESOLV_CONF_PATHS = [
    '/etc/resolv.conf',
    '/run/resolv.conf',
    '/run/systemd/resolve/resolv.conf',
    '/run/resolvconf/resolv.conf',
]
RESOLV_CONF_D_DIRS = [
    '/etc/resolv.conf.d',
    '/run/resolv.conf.d',
]


def _parse_source_from_path(filepath: str) -> str:
    """Determine source label from file path."""
    basename = os.path.basename(filepath).lower()
    
    if 'base' in basename:
        return 'system'
    if 'dhcp' in basename:
        # Try to extract interface name (e.g., eth0-dhcp)
        match = re.search(r'([a-z0-9\-]+)-dhcp', basename)
        return match.group(1) + '-dhcp' if match else 'dhcp'
    if 'static' in basename:
        return 'static'
    if basename == 'resolv.conf':
        return 'system'
    return basename or 'system'


def _parse_resolv_conf(filepath: str, prefer_source: str = None) -> list:
    """
    Parse a single resolv.conf file and return list of (server, source) tuples.

    Source resolution priority:
      1) Section comments inside the file (e.g. "# eth0-dhcp", "# system")
      2) prefer_source argument
      3) Source inferred from file path
    """
    servers = []
    if not os.path.exists(filepath):
        return servers
    
    try:
        default_source = prefer_source or _parse_source_from_path(filepath)
        current_source = default_source

        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()

                if not line:
                    continue

                # Parse section header comments used by VyOS resolv.conf generator.
                # Examples:
                #   # system
                #   # eth0-dhcp
                if line.startswith('#'):
                    comment = line.lstrip('#').strip().lower()
                    if re.match(r'^[a-z0-9_.:-]+$', comment):
                        current_source = comment
                    continue

                # Look for nameserver entries
                match = re.match(r'^nameserver\s+(\S+)', line)
                if match:
                    server = match.group(1)
                    try:
                        # Normalize and validate IPv4/IPv6 addresses.
                        ip_obj = ipaddress.ip_address(server)
                        servers.append((str(ip_obj), current_source or default_source))
                    except ValueError:
                        continue
    except Exception:
        # Silently skip files we can't read
        pass
    
    return servers


def _parse_system_name_server_cli() -> list:
    """Fallback parser for `show system name-server` output."""
    servers = []
    rc, output = rc_cmd('/opt/vyatta/bin/vyatta-op-cmd-wrapper show system name-server')
    if rc != 0 or not output:
        return servers

    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or stripped.lower().startswith('name-server'):
            continue

        # Accept plain IP lines and table/verbose lines containing address tokens
        for token in re.findall(r'[A-Fa-f0-9:.]+', stripped):
            try:
                ip_obj = ipaddress.ip_address(token)
            except ValueError:
                continue

            servers.append((str(ip_obj), 'system-config'))
            break

    return servers


def _collect_nameservers() -> dict:
    """
    Collect nameservers primarily from /etc/resolv.conf.

    Fallback behavior:
      - If /etc/resolv.conf provides no nameservers, try other known resolv.conf
        locations and resolv.conf.d directories.
      - If still empty, use `show system name-server`.
    """
    nameservers_dict = {}  # key: server IP, value: source

    primary_resolv = '/etc/resolv.conf'

    # Primary: /etc/resolv.conf and its symlink target
    if os.path.exists(primary_resolv):
        for server, source in _parse_resolv_conf(primary_resolv):
            if server not in nameservers_dict:
                nameservers_dict[server] = source

        try:
            real_path = os.path.realpath(primary_resolv)
            if real_path and real_path != primary_resolv and os.path.exists(real_path):
                for server, source in _parse_resolv_conf(
                    real_path,
                    prefer_source=_parse_source_from_path(real_path),
                ):
                    if server not in nameservers_dict:
                        nameservers_dict[server] = source
        except Exception:
            pass

    # Fallback: other known resolv.conf paths only when primary provided nothing
    if not nameservers_dict:
        for resolv_path in RESOLV_CONF_PATHS:
            if resolv_path == primary_resolv:
                continue
            if os.path.exists(resolv_path):
                servers = _parse_resolv_conf(resolv_path)
                for server, source in servers:
                    if server not in nameservers_dict:
                        nameservers_dict[server] = source

                # Also parse symlink target, if different
                try:
                    real_path = os.path.realpath(resolv_path)
                    if real_path and real_path != resolv_path and os.path.exists(real_path):
                        real_servers = _parse_resolv_conf(
                            real_path,
                            prefer_source=_parse_source_from_path(real_path),
                        )
                        for server, source in real_servers:
                            if server not in nameservers_dict:
                                nameservers_dict[server] = source
                except Exception:
                    pass

    # Fallback: resolv.conf.d directories when still empty
    if not nameservers_dict:
        for resolv_d_dir in RESOLV_CONF_D_DIRS:
            if os.path.isdir(resolv_d_dir):
                try:
                    for filename in sorted(os.listdir(resolv_d_dir)):
                        filepath = os.path.join(resolv_d_dir, filename)
                        if os.path.isfile(filepath) and not filename.startswith('.'):
                            source = _parse_source_from_path(filepath)
                            servers = _parse_resolv_conf(filepath, prefer_source=source)
                            for server, parsed_source in servers:
                                if server not in nameservers_dict:
                                    nameservers_dict[server] = parsed_source
                except Exception:
                    pass

    # Fallback: read configured name-servers from VyOS operational command
    if not nameservers_dict:
        try:
            for server, source in _parse_system_name_server_cli():
                if server not in nameservers_dict:
                    nameservers_dict[server] = source
        except Exception:
            pass
    
    return nameservers_dict


def show_dns_nameservers(raw: bool = True):
    """Show all configured DNS nameservers with their sources."""
    try:
        nameservers_dict = _collect_nameservers()
        
        if not nameservers_dict:
            return []
        
        # Convert to list of dicts for GraphQL
        # Keep insertion order from parsing (primarily /etc/resolv.conf order).
        result = [
            {
                'server': server,
                'source': source,
            }
            for server, source in nameservers_dict.items()
        ]
        return result
    except Exception as e:
        raise vyos.opmode.Error(f'Failed to query DNS nameservers: {str(e)}')


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
