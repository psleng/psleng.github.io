#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL mutations for IPv4/IPv6 neighbor table resets.

This script executes the same op-mode backend used by VyOS:
    /usr/libexec/vyos/op_mode/neighbor.py reset --family inet
    /usr/libexec/vyos/op_mode/neighbor.py reset --family inet --address <ipv4>
    /usr/libexec/vyos/op_mode/neighbor.py reset --family inet6 --address <ipv6>
"""

import ipaddress
import sys
import subprocess
import typing

import vyos.opmode


NEIGHBOR_SCRIPT_PATH = '/usr/libexec/vyos/op_mode/neighbor.py'


def _run_neighbor_reset(
    family: str,
    args: typing.List[str],
    result: str,
    command: str,
) -> dict:
    """Run the shared neighbor reset backend and return a structured result."""
    cmd = [
        'sudo',
        NEIGHBOR_SCRIPT_PATH,
        'reset',
        '--family',
        family,
        *args,
    ]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise vyos.opmode.Error(f'Failed to execute neighbor reset backend: {str(exc)}') from exc

    combined = '\n'.join(
        part
        for part in [
            (proc.stdout or '').strip(),
            (proc.stderr or '').strip(),
        ]
        if part
    )

    if proc.returncode != 0:
        message = combined or f'Failed to run neighbor reset (exit code {proc.returncode}).'
        raise vyos.opmode.Error(message)

    response = {
        'success': True,
        'result': result,
        'command': command,
        'family': family,
        'return_code': proc.returncode,
        'cli_output': combined,
    }

    return response


def reset_ip_arp_table(raw: bool = True) -> dict:
    """Flush the IPv4 ARP table, equivalent to `reset ip arp table`."""
    result = _run_neighbor_reset('inet', [], 'ARP table reset completed.', 'reset ip arp table')

    if not raw:
        print(result)

    return result


def reset_ip_arp_address(address: str, raw: bool = True) -> dict:
    """Flush a single IPv4 ARP entry, equivalent to `reset ip arp address <address>`."""
    try:
        normalized_address = str(ipaddress.IPv4Address(address))
    except (ipaddress.AddressValueError, ValueError) as exc:
        raise ValueError(f'Invalid IPv4 address "{address}".') from exc

    result = _run_neighbor_reset(
        'inet',
        ['--address', normalized_address],
        f'ARP entry for {normalized_address} reset completed.',
        f'reset ip arp address {normalized_address}',
    )

    result['address'] = normalized_address

    if not raw:
        print(result)

    return result


def reset_ip_arp_interface(interface: str, raw: bool = True) -> dict:
    """Flush all IPv4 ARP entries on an interface, equivalent to `reset ip arp interface <intf-name>`."""
    normalized_interface = str(interface).strip()
    if not normalized_interface:
        raise ValueError('Interface name is required for IPv4 ARP reset.')

    result = _run_neighbor_reset(
        'inet',
        ['--interface', normalized_interface],
        f'ARP entries on interface {normalized_interface} reset completed.',
        f'reset ip arp interface {normalized_interface}',
    )

    result['interface'] = normalized_interface

    if not raw:
        print(result)

    return result


def reset_ipvsix_neighbors_address(address: str, raw: bool = True) -> dict:
    """Flush a single IPv6 neighbor entry, equivalent to `reset ipv6 neighbors address <address>`."""
    try:
        normalized_address = str(ipaddress.IPv6Address(address))
    except (ipaddress.AddressValueError, ValueError) as exc:
        raise ValueError(f'Invalid IPv6 address "{address}".') from exc

    result = _run_neighbor_reset(
        'inet6',
        ['--address', normalized_address],
        f'IPv6 neighbor entry for {normalized_address} reset completed.',
        f'reset ipv6 neighbors address {normalized_address}',
    )

    result['address'] = normalized_address

    if not raw:
        print(result)

    return result


def reset_ipvsix_neighbors_interface(interface: str, raw: bool = True) -> dict:
    """Flush all IPv6 neighbor entries on an interface, equivalent to `reset ipv6 neighbors interface <intf-name>`."""
    normalized_interface = str(interface).strip()
    if not normalized_interface:
        raise ValueError('Interface name is required for IPv6 neighbor reset.')

    result = _run_neighbor_reset(
        'inet6',
        ['--interface', normalized_interface],
        f'IPv6 neighbor entries on interface {normalized_interface} reset completed.',
        f'reset ipv6 neighbors interface {normalized_interface}',
    )

    result['interface'] = normalized_interface

    if not raw:
        print(result)

    return result


def reset_ipv_6_neighbors_address(address: str, raw: bool = True) -> dict:
    """Compatibility alias for schema generators that split ipv6 as ipv_6."""
    return reset_ipvsix_neighbors_address(address=address, raw=raw)


def reset_ipv_6_neighbors_interface(interface: str, raw: bool = True) -> dict:
    """Compatibility alias for schema generators that split ipv6 as ipv_6."""
    return reset_ipvsix_neighbors_interface(interface=interface, raw=raw)


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
