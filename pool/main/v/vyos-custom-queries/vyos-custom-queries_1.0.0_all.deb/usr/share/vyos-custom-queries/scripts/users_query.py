#!/usr/bin/env python3
# filepath: /Users/zdiao/git/vyos-1x/src/op_mode/show_users.py
#
# Copyright (C) 2023-2025 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import os
import sys
import pwd
import time
import socket
import struct
import argparse
import re
import subprocess
from datetime import datetime
from tabulate import tabulate



def main():
    """Main function to parse arguments and display output"""
    parser = argparse.ArgumentParser(description='Show currently logged in users')
    parser.add_argument('--raw', action='store_true', help='Return raw JSON data')
    args = parser.parse_args()
    
    result = show(raw=args.raw)
    
    if args.raw:
        # If raw output is requested, convert to JSON
        import json
        print(json.dumps(result))
    else:
        # Otherwise print the formatted table
        print(result)

def show(raw: bool = False):
    """
    Alternative implementation using the subprocess module to call 'who -H'
    
    Args:
        raw: If True, parse who output to dictionary. If False, return formatted output.
        
    Returns:
        If raw=True: List of dictionaries with user information
        If raw=False: Formatted string from 'who -H' output
    """
    import subprocess
    try:
        result = subprocess.run(['who', '-H'], capture_output=True, text=True, check=True)
        
        if raw:
            # Parse the who output into a list of dictionaries
            users = []
            lines = result.stdout.strip().split('\n')
            
            # Skip the header line
            for line in lines[1:]:
                if not line.strip():
                    continue
                    
                # Parse the line (format varies, but typically: username tty login_time [host])
                parts = line.split()
                username = parts[0]
                tty = parts[1]
                
                # Handle the date and time parts (might be 2 or 3 fields depending on format)
                time_parts = []
                i = 2
                while i < len(parts) and not parts[i].startswith('('):
                    time_parts.append(parts[i])
                    i += 1
                    
                login_time = ' '.join(time_parts)
                
                # Extract the host if present (enclosed in parentheses)
                host = ''
                if i < len(parts) and parts[i].startswith('('):
                    # Remove the parentheses
                    host = parts[i][1:].rstrip(')')
                
                users.append({
                    'username': username,
                    'line': tty,
                    'time': login_time,
                    'commant': host
                })
                
            return users
        else:
            return result.stdout.strip()
            
    except subprocess.CalledProcessError as e:
        error_msg = f"Error executing 'who' command: {e}"
        return [] if raw else error_msg
    except FileNotFoundError:
        error_msg = "Error: 'who' command not found"
        return [] if raw else error_msg



def show_recent(raw: bool = False, count: int = 10):
    """
    Show recently logged in users, mimicking 'last -aF -n {count}' command output.
    
    Args:
        raw: If True, return a list of dictionaries. If False, return formatted output.
        count: Number of recent logins to show (default: 10)
        
    Returns:
        If raw=True: List of dictionaries with recent login information
        If raw=False: Formatted string that mimics 'last -aF -n {count}' output
    """
    # Run 'last' command to get recent login history
    try:
        result = subprocess.run(
            ['last', '-a', '-n', str(count)], 
            capture_output=True, 
            text=True, 
            check=True
        )
        output = result.stdout
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        error_msg = f"Error executing 'last' command: {e}"
        return [] if raw else error_msg
    
    # For raw output, parse the data into a structured format
    if raw:
        logins = []
        lines = output.strip().split('\n')
        
        for line in lines:
            if "wtmp begins" in line:
                continue
                
            # Split the line into fields, preserving whitespace in the date/time fields
            parts = line.split()
            if len(parts) < 3:  # Skip lines that don't have enough fields
                continue
                
            username = parts[0]
            tty = parts[1]
            
            # Find the remote host (comes after the 'from' keyword or at the end)
            from_index = -1
            for i, part in enumerate(parts):
                if part == 'from':
                    from_index = i
                    break
            
            remote_host = parts[from_index + 1] if from_index >= 0 else parts[-1]
            
            # Parse login time, logout time and duration
            date_parts = []
            i = 2
            while i < len(parts):
                if parts[i] in ['still', '-', 'crash']:
                    break
                date_parts.append(parts[i])
                i += 1
                
            login_time = ' '.join(date_parts)
            
            # Find logout information
            logout_info = ""
            duration = ""
            if i < len(parts):
                if parts[i] == 'still':
                    logout_info = "still logged in"
                    if "running" in line:
                        logout_info = "still running"
                elif parts[i] == '-':
                    # After the '-' we have the logout time
                    i += 1
                    logout_parts = []
                    while i < len(parts):
                        if parts[i].startswith('('):
                            break
                        logout_parts.append(parts[i])
                        i += 1
                    logout_info = ' '.join(logout_parts)
                    
                    # Duration typically appears in parentheses like (00:01)
                    if i < len(parts) and parts[i].startswith('('):
                        duration = parts[i]
                elif parts[i] == 'crash':
                    logout_info = "crash"
                    
                    # Duration after crash
                    if i + 1 < len(parts) and parts[i+1].startswith('('):
                        duration = parts[i+1]
            
            # Create entry dictionary
            entry = {
                'username': username,
                'line': tty,
                'login_time': login_time,
                'logout_info': logout_info,
                'duration': duration.strip('()'),
                'remote_host': remote_host
            }
            logins.append(entry)
            
        return logins
    else:
        # For formatted output, just replace the "wtmp begins" line as specified
        modified_output = re.sub(
            r'^wtmp begins',
            'Displaying logins since',
            output,
            flags=re.MULTILINE
        )
        return modified_output

if __name__ == '__main__':
    # Use the pure Python implementation
    main()