#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL-friendly query for neighbor (ARP/NDP) table.

Reads the output of:
    ip --json neigh list
"""

import json
import sys

import vyos.opmode
from vyos.utils.process import rc_cmd


def _load_neigh_entries(family: str = 'all') -> list:
    """Return parsed JSON entries from ip neigh list.

    family can be one of: all, ipv4, ipv6.
    """
    if family == 'ipv4':
        commands = [
            '/usr/sbin/ip -4 --json neigh show',
            '/sbin/ip -4 --json neigh show',
            'ip -4 --json neigh show',
        ]
    elif family == 'ipv6':
        commands = [
            '/usr/sbin/ip -6 --json neigh show',
            '/sbin/ip -6 --json neigh show',
            'ip -6 --json neigh show',
        ]
    else:
        commands = [
            '/usr/sbin/ip --json neigh list',
            '/sbin/ip --json neigh list',
            'ip --json neigh list',
        ]

    output = ''
    for cmd in commands:
        rc, out = rc_cmd(cmd)
        if rc == 0 and out:
            output = out
            break

    if not output:
        return []

    try:
        data = json.loads(output)
    except json.JSONDecodeError as e:
        raise vyos.opmode.Error(f'Failed to parse neighbor JSON output: {str(e)}')

    if isinstance(data, list):
        return data

    return []


def show_arp_neighbors(raw: bool = True):
    """Show neighbor entries from `ip --json neigh list`."""
    entries = _load_neigh_entries()

    result = []
    for entry in entries:
        state_value = entry.get('state', [])
        if isinstance(state_value, list):
            state_text = ','.join(state_value)
        else:
            state_text = str(state_value)

        result.append(
            {
                'dst': str(entry.get('dst', '')),
                'dev': str(entry.get('dev', '')),
                'lladdr': str(entry.get('lladdr', '')),
                'state': state_text,
                'router': bool(entry.get('router', False)),
            }
        )

    return result


def show_arp_neighbors_raw(raw: bool = True, ipv4: bool = False, ipv6: bool = False):
    """Show raw neighbor entries from ip neigh JSON output.

    If ipv4 is True, return `ip -4 --json neigh show` output.
    If ipv6 is True, return `ip -6 --json neigh show` output.
    """
    if ipv4 and ipv6:
        raise vyos.opmode.Error('Only one of ipv4 or ipv6 can be specified')

    if ipv4:
        return _load_neigh_entries('ipv4')

    if ipv6:
        return _load_neigh_entries('ipv6')

    return _load_neigh_entries('all')


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
