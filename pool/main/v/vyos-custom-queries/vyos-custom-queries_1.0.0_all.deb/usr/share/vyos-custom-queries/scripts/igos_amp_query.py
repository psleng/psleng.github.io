#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.

"""GraphQL-friendly OWAMP and TWAMP operational queries.

Equivalent VyOS operational-mode commands:
    execute owping <IPv4/IPv6/hostname>[:<port>]
    execute twping <IPv4/IPv6/hostname>[:<port>]
"""

from ipaddress import ip_address
import re
import subprocess
import sys

import vyos.opmode


OP_COMMAND_WRAPPER = '/opt/vyatta/bin/vyatta-op-cmd-wrapper'
COMMAND_TIMEOUT_SECONDS = 60
HOSTNAME_LABEL_PATTERN = re.compile(r'^(?!-)[A-Za-z0-9-]{1,63}(?<!-)$')


def _normalize_target(target: str) -> str:
    """Validate an AMP host with an optional port and normalize its syntax."""
    value = str(target or '').strip()
    if not value or any(character.isspace() for character in value):
        raise vyos.opmode.Error(
            'AMP target must be an IPv4 address, IPv6 address, or hostname, '
            'optionally followed by a port.'
        )

    bracketed = value.startswith('[')
    if bracketed:
        closing_bracket = value.find(']')
        if closing_bracket < 0:
            raise vyos.opmode.Error(
                'Invalid AMP target. A bracketed IPv6 address must end with ].'
            )
        host = value[1:closing_bracket]
        suffix = value[closing_bracket + 1 :]
        if suffix and not suffix.startswith(':'):
            raise vyos.opmode.Error(
                'Invalid AMP target. Use [IPv6]:port when specifying an IPv6 port.'
            )
        port_text = suffix[1:] if suffix else None
    else:
        try:
            address = ip_address(value)
        except ValueError:
            host, separator, candidate_port = value.rpartition(':')
            if separator:
                port_text = candidate_port
            else:
                host = value
                port_text = None
        else:
            host = value
            port_text = None

    if port_text is not None:
        if (
            not port_text
            or not port_text.isascii()
            or not port_text.isdecimal()
            or not 1 <= int(port_text) <= 65535
        ):
            raise vyos.opmode.Error('AMP target port must be between 1 and 65535.')

    if not host or '%' in host:
        raise vyos.opmode.Error('Invalid AMP target host.')

    try:
        address = ip_address(host)
    except ValueError:
        if bracketed or ':' in host:
            raise vyos.opmode.Error('Invalid AMP IP address.')

        hostname = host[:-1] if host.endswith('.') else host
        if (
            not hostname
            or len(hostname) > 253
            or any(
                not HOSTNAME_LABEL_PATTERN.fullmatch(label)
                for label in hostname.split('.')
            )
        ):
            raise vyos.opmode.Error('Invalid AMP hostname.')
        normalized_host = hostname.lower()
    else:
        if bracketed and address.version != 6:
            raise vyos.opmode.Error('Only IPv6 addresses may use brackets.')
        normalized_host = (
            f'[{address.compressed}]' if address.version == 6 else address.compressed
        )

    if port_text is None:
        return normalized_host.strip('[]')
    return f'{normalized_host}:{int(port_text)}'


def _run_amp_query(tool: str, target: str, raw: bool = True) -> dict:
    normalized_target = _normalize_target(target)
    command = [OP_COMMAND_WRAPPER, 'execute', tool, normalized_target]

    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ''
        if isinstance(output, bytes):
            output = output.decode(errors='replace')
        result = {
            'success': False,
            'tool': tool,
            'target': normalized_target,
            'command': f'execute {tool} {normalized_target}',
            'return_code': None,
            'output': output.strip(),
            'error': (
                f'{tool} timed out after {COMMAND_TIMEOUT_SECONDS} seconds.'
            ),
        }
    except OSError as exc:
        raise vyos.opmode.Error(
            f'Failed to execute {tool} through the VyOS operational CLI: {exc}'
        ) from exc
    else:
        output = (completed.stdout or '').strip()
        result = {
            'success': completed.returncode == 0,
            'tool': tool,
            'target': normalized_target,
            'command': f'execute {tool} {normalized_target}',
            'return_code': completed.returncode,
            'output': output,
            'error': (
                ''
                if completed.returncode == 0
                else f'{tool} exited with status {completed.returncode}.'
            ),
        }

    if not raw:
        print(result)
    return result


def show_owping(raw: bool = True, target: str = '') -> dict:
    """Return the result of ``execute owping <target>``."""
    return _run_amp_query('owping', target, raw)


def show_twping(raw: bool = True, target: str = '') -> dict:
    """Return the result of ``execute twping <target>``."""
    return _run_amp_query('twping', target, raw)


if __name__ == '__main__':
    try:
        response = vyos.opmode.run(sys.modules[__name__])
        if response:
            print(response)
    except (ValueError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(1)
