#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL mutation for `rename system image <old> to <new>`."""

import json
import re
import subprocess
import sys
import typing

import vyos.opmode


IMAGE_MANAGER_PATH = '/usr/libexec/vyos/op_mode/image_manager.py'
SHOW_SYSTEM_IMAGES_COMMAND = [
    '/opt/vyatta/bin/vyatta-op-cmd-wrapper',
    'show',
    'system',
    'image',
]
RUNNING_IMAGE_RENAME_ERROR = 'Currently running image cannot be renamed'


def _get_installed_image_names() -> typing.Set[str]:
    """Return the names listed by `show system image`."""
    proc = subprocess.run(
        SHOW_SYSTEM_IMAGES_COMMAND,
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        output = '\n'.join(
            part
            for part in [(proc.stdout or '').strip(), (proc.stderr or '').strip()]
            if part
        )
        message = output or f'Unable to list system images (exit code {proc.returncode}).'
        raise vyos.opmode.Error(message)

    lines = [line.rstrip() for line in (proc.stdout or '').splitlines() if line.strip()]
    separator_index = next(
        (index for index, line in enumerate(lines) if re.fullmatch(r'[\s\-]+', line)),
        None,
    )
    if separator_index is None:
        return set()

    image_names = set()
    for line in lines[separator_index + 1:]:
        columns = [
            column.strip()
            for column in re.split(r'\s{2,}', line.strip())
            if column.strip()
        ]
        if columns:
            image_names.add(columns[0])

    return image_names


def _raise_graphql_rename_error(
    message: str,
    error_type: str,
    old_name: str,
    new_name: str,
) -> typing.NoReturn:
    """Raise a structured error that is preserved in GraphQL's errors field."""
    payload = {
        'success': False,
        'result': message,
        'message': message,
        'error_type': error_type,
        'error_message': message,
        'exception': f'{error_type}: {message}',
        'image_name': old_name,
        'image_new_name': new_name,
    }
    # ValueError is intentionally used because the GraphQL wrapper preserves
    # its message, while vyos.opmode.Error may be reduced to a generic error.
    raise ValueError(json.dumps(payload, ensure_ascii=False))


def set_system_image(
    image_name: str,
    image_new_name: str,
    raw: bool = True,
) -> dict:
    """Rename an installed system image via image_manager --action rename."""
    old_name = str(image_name).strip() if image_name is not None else ''
    new_name = str(image_new_name).strip() if image_new_name is not None else ''

    if not old_name:
        raise vyos.opmode.Error('Parameter "image_name" is required.')
    if not new_name:
        raise vyos.opmode.Error('Parameter "image_new_name" is required.')

    installed_image_names = _get_installed_image_names()
    if old_name not in installed_image_names:
        message = f'System image "{old_name}" was not found.'
        _raise_graphql_rename_error(
            message,
            'ImageNotFound',
            old_name,
            new_name,
        )

    installed_image_names_lower = {
        installed_name.lower() for installed_name in installed_image_names
    }
    if new_name.lower() in installed_image_names_lower:
        message = f'System image "{new_name}" already exists.'
        _raise_graphql_rename_error(
            message,
            'DuplicateImageName',
            old_name,
            new_name,
        )

    cmd = [
        'sudo',
        IMAGE_MANAGER_PATH,
        '--action',
        'rename',
        '--image-name',
        old_name,
        '--image-new-name',
        new_name,
    ]

    proc = subprocess.run(
        cmd,
        input='y\n',
        capture_output=True,
        text=True,
        check=False,
    )

    combined = '\n'.join(
        part for part in [(proc.stdout or '').strip(), (proc.stderr or '').strip()] if part
    )
    if proc.returncode != 0:
        if RUNNING_IMAGE_RENAME_ERROR.lower() in combined.lower():
            _raise_graphql_rename_error(
                RUNNING_IMAGE_RENAME_ERROR,
                'RunningImageRenameNotAllowed',
                old_name,
                new_name,
            )

        message = combined if combined else f'Rename command failed with exit code {proc.returncode}.'
        raise vyos.opmode.Error(message)

    result = {
        'success': True,
        'result': f'System image "{old_name}" was renamed to "{new_name}".',
        'image_name': old_name,
        'image_new_name': new_name,
        'return_code': proc.returncode,
        'cli_output': combined,
    }

    if not raw:
        print(result)

    return result


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
