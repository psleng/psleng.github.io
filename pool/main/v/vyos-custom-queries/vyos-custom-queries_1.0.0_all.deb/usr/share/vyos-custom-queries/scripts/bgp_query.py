import json

from vyos.utils.process import cmd


def _run_bgp_json_command(command_variants):
    """Try direct vtysh first, then VyOS wrappers, returning the first non-empty output."""
    command_attempts = []
    wrappers = [
        "/usr/libexec/vyos/op_mode/vyos-op-cmd-wrapper.sh",
        "/opt/vyatta/bin/vyatta-op-cmd-wrapper"
    ]

    for command_text in command_variants:
        command_attempts.append(f'/usr/bin/vtysh -c "{command_text}"')
        for wrapper in wrappers:
            command_attempts.append(f"{wrapper} {command_text}")

    errors = []
    for command_line in command_attempts:
        try:
            output = cmd(command_line, expect=[0, 1], timeout=15)
            if output and output.strip():
                return output
        except Exception as exc:
            errors.append(f"{command_line}: {exc}")

    return None, errors


def _load_bgp_json(command_variants, label, raw):
    output = _run_bgp_json_command(command_variants)

    if isinstance(output, tuple):
        _, errors = output
        result = {"error": f"Failed to execute '{label}' command"}
        if errors:
            result["details"] = errors
        return result

    if not raw:
        return output

    try:
        return json.loads(output)
    except json.JSONDecodeError:
        return {
            "error": "Command output is not valid JSON",
            "command": label,
            "cli_output": output
        }

def show_bgp(raw=True):
    """
    Get BGP information using VyOS native command
    
    Args:
        raw: Boolean flag to determine return format
    
    Returns:
        Structured BGP data or formatted text
    """
    # Try both available wrappers for VyOS operational commands
    wrappers = [
        "/usr/libexec/vyos/op_mode/vyos-op-cmd-wrapper.sh",
        "/opt/vyatta/bin/vyatta-op-cmd-wrapper"
    ]
    
    output = None
    for wrapper in wrappers:
        try:
            # Execute the VyOS command through the wrapper
            # Use expect=[0,1] to handle cases where command succeeds but returns non-zero
            output = cmd(f"{wrapper} show ip bgp", 
                         expect=[0, 1], 
                         timeout=15)
            if output:
                break
        except Exception as e:
            continue
    
    if not output:
        return {"error": "Failed to execute 'show ip bgp' command"}
    
    if raw:
        # Parse the output to create structured data
        import re
        
        result = {
            "routes": {},
            "router_id": "",
            "local_as": "",
            "table_version": 0,
            "total_routes": 0,
            "total_paths": 0,
            "query_method": "vyos-op-cmd"
        }
        
        # Extract router ID and ASN
        router_id_match = re.search(r"local router ID is ([0-9.]+)", output)
        if router_id_match:
            result["router_id"] = router_id_match.group(1)
        
        local_as_match = re.search(r"local AS (\d+)", output)
        if local_as_match:
            result["local_as"] = local_as_match.group(1)
        
        # Extract table version
        version_match = re.search(r"BGP table version is (\d+)", output)
        if version_match:
            result["table_version"] = int(version_match.group(1))
        
        # Extract routes
        in_routes_section = False
        routes = {}
        
        for line in output.splitlines():
            if "Network" in line and "Next Hop" in line:
                in_routes_section = True
                continue
            
            if in_routes_section and line.strip():
                # Skip lines that don't look like route entries
                if not re.match(r'^[*>= ]', line):
                    continue
                
                parts = line.split()
                if len(parts) >= 3:  # Status, network, next-hop minimum
                    status = parts[0]
                    network = parts[1]
                    next_hop = parts[2]
                    
                    # Parse status flags
                    valid = '*' in status
                    best = '>' in status
                    
                    # Create route entry
                    route_data = {
                        "valid": valid,
                        "bestpath": best,
                        "nexthops": [{"ip": next_hop}]
                    }
                    
                    # Add metric if available
                    if len(parts) > 3:
                        try:
                            route_data["metric"] = int(parts[3])
                        except ValueError:
                            pass
                    
                    if network not in routes:
                        routes[network] = []
                    
                    routes[network].append(route_data)
        
        # Add routes to result
        result["routes"] = routes
        result["total_routes"] = len(routes)
        
        # Count total paths
        total_paths = sum(len(paths) for paths in routes.values())
        result["total_paths"] = total_paths
        
        return result
    else:
        # Return raw output as text
        return output


def show_bgp_summary(raw=True):
    """
    Get BGP summary JSON using VyOS native command

    Args:
        raw: Boolean flag to determine return format

    Returns:
        JSON object from `show ip bgp summary json` or raw text
    """
    return _load_bgp_json(
        ["show ip bgp summary json", "show bgp summary json"],
        "show ip bgp summary json",
        raw,
    )


def show_bgp_neighbors(raw=True):
    """
    Get BGP neighbors JSON using VyOS native command

    Args:
        raw: Boolean flag to determine return format

    Returns:
        JSON object from `show ip bgp neighbors json` or raw text
    """
    return _load_bgp_json(
        ["show ip bgp neighbors json", "show bgp neighbors json"],
        "show ip bgp neighbors json",
        raw,
    )


def show_bgp_statistics(raw=True):
    """
    Get BGP statistics JSON using VyOS native command

    Args:
        raw: Boolean flag to determine return format

    Returns:
        JSON object from `show ip bgp statistics json` or raw text
    """
    return _load_bgp_json(
        ["show ip bgp statistics json", "show bgp statistics json"],
        "show ip bgp statistics json",
        raw,
    )


def show_bgp_detail(raw=True):
    """
    Get BGP detail JSON using VyOS native command

    Args:
        raw: Boolean flag to determine return format

    Returns:
        JSON object from `show ip bgp detail json` or raw text
    """
    return _load_bgp_json(
        ["show ip bgp detail json", "show bgp detail json"],
        "show ip bgp detail json",
        raw,
    )

# Example usage
if __name__ == "__main__":
    result = show_bgp()
    print(f"BGP Router ID: {result.get('router_id')}")
    print(f"Local AS: {result.get('local_as')}")
    print(f"Total Routes: {result.get('total_routes')}")