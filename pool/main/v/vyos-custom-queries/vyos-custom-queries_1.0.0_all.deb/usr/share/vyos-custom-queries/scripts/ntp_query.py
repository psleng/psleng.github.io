#!/usr/bin/env python3
#
# Copyright (C) 2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import csv
import sys
from itertools import chain

import vyos.opmode
from vyos.configquery import ConfigTreeQuery
from vyos.utils.process import cmd

MODE_MAPPING = {
    "^": "server",
    "=": "peer",
    "#": "local clock"
}

STATE_MAPPING ={
    "*": "current best",
    "+": "combined",
    "-": "not combined",
    "x": "may be in error",
    "~": "too variable",
    "?": "unusable"
}

def _get_keys(command: str) -> list:
    # Returns the appropriate keys for the given chronyc command
    match command:
        case "activity":
            return [
                'sources_online',
                'sources_offline',
                'sources_doing_burst_return_online',
                'sources_doing_burst_return_offline',
                'sources_with_unknown_address'
            ]
        case "sources":
            return [
                'mode', 'state', 'name_ip_address', 'stratum', 'poll', 'reach',
                'last_rx', 'last_sample_adj_offset', 'last_sample_mes_offset',
                'last_sample_est_error'
            ]
        case "sourcestats":
            return [
                'name_ip_address', 'np', 'nr', 'span', 'frequency', 'freq_skew',
                'offset', 'std_dev'
            ]
        case "tracking":
            return [
                'ref_id', 'ref_id_name', 'stratum', 'ref_time', 'system_time',
                'last_offset', 'rms_offset', 'frequency', 'residual_freq',
                'skew', 'root_delay', 'root_dispersion', 'update_interval',
                'leap_status'
            ]
        case _:
            raise ValueError(f"Raw mode: of {command} is not implemented")

"""def _get_raw_data(command: str) -> list:
    # Returns chronyc output as a list of dictionaries
    keys = _get_keys(command.split()[-1])
    output = cmd(command).splitlines()
    values = list(csv.reader(output))

    # Convert each row into a dictionary
    return [dict(zip(keys, row)) for row in values]
    """

def _chunk_list(in_list, n):
    # Yields successive n-sized chunks from in_list
    for i in range(0, len(in_list), len(n)):
        yield in_list[i:i + len(n)]

def _is_configured():
    # Check if ntp is configured
    config = ConfigTreeQuery()
    if not config.exists("service ntp"):
        raise vyos.opmode.UnconfiguredSubsystem("NTP service is not enabled.")

def _extend_command_vrf():
    config = ConfigTreeQuery()
    if config.exists('service ntp vrf'):
        vrf = config.value('service ntp vrf')
        return f'ip vrf exec {vrf} '
    return ''
# Add this function after _extend_command_vrf()
def _get_verbose_names():
    """
    Get the verbose names from 'chronyc sources -v' output.
    Returns a list of server names in the same order as the raw output.
    """
    vrf_prefix = _extend_command_vrf()
    command = f"{vrf_prefix}chronyc sources -v"
    output = cmd(command)
    
    # Parse the verbose output to extract server names
    names = []
    lines = output.strip().splitlines()
    
    # Find where the data starts (after the separator line with "===")
    data_start = 0
    for i, line in enumerate(lines):
        if "===" in line:
            data_start = i + 1
            break
    
    # Extract server names
    for line in lines[data_start:]:
        if not line.strip():
            continue
        
        parts = line.strip().split()
        if len(parts) >= 2:
            # The second column contains the server name
            names.append(parts[1])
    
    return names

# Modify the _get_raw_data function to incorporate verbose names
def _get_raw_data(command: str) -> list:
    """
    Returns chronyc output as a list of dictionaries,
    with name_ip_address replaced by verbose names where applicable.
    """
    # Get the command type (e.g., "sources", "tracking")
    command_type = command.split()[-1]
    keys = _get_keys(command_type)
    
    # Get raw data
    output = cmd(command).splitlines()
    values = list(csv.reader(output))
    result = [dict(zip(keys, row)) for row in values]
    
    # If this is "sources" command, replace IP addresses with verbose names
    if command_type == "sources" and 'name_ip_address' in keys:
        verbose_names = _get_verbose_names()
        
        # Check if we have the same number of entries
        if len(result) == len(verbose_names):
            # Replace each name_ip_address with its verbose counterpart
            for i, entry in enumerate(result):
                if i < len(verbose_names):
                    entry['name_ip_address'] = verbose_names[i]
        for item in result:
            # Replace the mode and state with their verbose names
            item['mode'] = MODE_MAPPING.get(item['mode'])   
            item['state'] = STATE_MAPPING.get(item['state'])
    
    # Similarly for sourcestats which also uses name_ip_address
    elif command_type == "sourcestats" and 'name_ip_address' in keys:
        verbose_names = _get_verbose_names()
        
        # Create a mapping of index positions for matching
        # This is needed because sourcestats might not have all sources
        # First, get all raw addresses from sources command
        sources_command = command.replace("sourcestats", "sources")
        sources_output = cmd(sources_command).splitlines()
        sources_values = list(csv.reader(sources_output))
        sources_keys = _get_keys("sources")
        
        # Create lists of raw addresses and their indices
        raw_addresses = []
        for row in sources_values:
            source_dict = dict(zip(sources_keys, row))
            addr_idx = sources_keys.index('name_ip_address')
            if addr_idx < len(row):
                raw_addresses.append(row[addr_idx])
        
        # For each sourcestats entry, find the corresponding verbose name
        for entry in result:
            raw_addr = entry.get('name_ip_address', '')
            if raw_addr in raw_addresses:
                idx = raw_addresses.index(raw_addr)
                if idx < len(verbose_names):
                    entry['name_ip_address'] = verbose_names[idx]
    
    return result
def _build_command(base: str, subcommand: str, raw: bool) -> str:
    # Constructs the chronyc command
    if raw:
        return f"{base} -c {subcommand}"
    print("This function is implemented for GraphQL raw output only!")
    return ""

def show_activity(raw: bool):
    _is_configured()
    command = _build_command('chronyc', 'activity', raw)
    return _get_raw_data(command) if command else []

def show_sources(raw: bool):
    _is_configured()
    command = _build_command('chronyc', 'sources', raw)
    return _get_raw_data(command) if command else []

def show_system(raw: bool):
    _is_configured()
    command = _build_command('chronyc', 'tracking', raw)
    return _get_raw_data(command) if command else []

def show_sourcestats(raw: bool):
    _is_configured()
    command = _build_command('chronyc', 'sourcestats', raw)
    return _get_raw_data(command) if command else []

if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)