#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.

"""GraphQL query for the generic iGOS onboarding requirement."""

import sys

import vyos.opmode

from vyos.config import Config


TIMEZONE_PATH = ['system', 'time-zone']


def show_igos_onboarding(raw: bool = True) -> dict:
    """Return whether iGOS onboarding is required and an explanatory message."""
    onboarding_required = not Config().exists_effective(TIMEZONE_PATH)
    result = {
        'required': onboarding_required,
        'message': (
            'iGOS onboarding is required.'
            if onboarding_required
            else 'iGOS onboarding is not required.'
        ),
    }

    if not raw:
        print(result)
    return result


def _cli_required_exit_code() -> int:
    """Return 0 when onboarding is required and 1 when it is complete."""
    return 0 if show_igos_onboarding()['required'] else 1


if __name__ == '__main__':
    try:
        if sys.argv[1:] == ['--cli-required']:
            sys.exit(_cli_required_exit_code())
        response = vyos.opmode.run(sys.modules[__name__])
        if response:
            print(response)
    except (ValueError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(2 if sys.argv[1:] == ['--cli-required'] else 1)
