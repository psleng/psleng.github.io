#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL-friendly OSPFv3 query via vtysh JSON commands.

Supported commands:
    show ipv6 ospf6 json
    show ipv6 ospf6 database json
    show ipv6 ospf6 interface json
    show ipv6 ospf6 neighbor json
    show ipv6 ospf6 summary-address json
"""

import json
import sys
import typing

import vyos.opmode
from vyos.utils.process import rc_cmd


OSPFV3_KEYWORD_TO_COMMAND = {
    'overview': 'show ipv6 ospf6 json',
    'database': 'show ipv6 ospf6 database json',
    'interface': 'show ipv6 ospf6 interface json',
    'neighbor': 'show ipv6 ospf6 neighbor json',
    'summary-address': 'show ipv6 ospf6 summary-address json',
}


def _run_vtysh_ospfv3_json(command_keyword: str):
    keyword = (command_keyword or 'overview').strip().lower()
    if keyword not in OSPFV3_KEYWORD_TO_COMMAND:
        valid = ', '.join(sorted(OSPFV3_KEYWORD_TO_COMMAND.keys()))
        raise vyos.opmode.Error(f'Invalid OSPFv3 keyword: {command_keyword}. Valid values: {valid}')

    ospfv3_command = OSPFV3_KEYWORD_TO_COMMAND[keyword]
    commands = [
        f"/usr/bin/vtysh -c '{ospfv3_command}'",
        f"/usr/sbin/vtysh -c '{ospfv3_command}'",
        f"vtysh -c '{ospfv3_command}'",
    ]

    output = None
    errors = []
    for cmd in commands:
        rc, out = rc_cmd(cmd)
        if rc == 0:
            output = (out or '').strip()
            # Some FRR/VyOS builds return empty output when OSPFv3 has no data.
            # Treat that as an empty JSON object instead of an execution failure.
            if not output:
                return {}
            break
        if out:
            errors.append(out.strip())

    if output is None:
        detail = f" Details: {' | '.join(errors)}" if errors else ''
        raise vyos.opmode.Error(f'Failed to query OSPFv3 data from vtysh.{detail}')

    try:
        return json.loads(output)
    except json.JSONDecodeError as e:
        raise vyos.opmode.Error(f'Failed to parse OSPFv3 JSON output: {str(e)}')


def show_ospfv_3(raw: bool = True, keyword: typing.Optional[str] = None):
    """Show OSPFv3 JSON data.

    keyword is the token after "show ipv6 ospf6".
    Examples:
        - None / omitted -> show ipv6 ospf6 json
        - interface      -> show ipv6 ospf6 interface json
        - neighbor       -> show ipv6 ospf6 neighbor json
    """
    return _run_vtysh_ospfv3_json(keyword or 'overview')


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
