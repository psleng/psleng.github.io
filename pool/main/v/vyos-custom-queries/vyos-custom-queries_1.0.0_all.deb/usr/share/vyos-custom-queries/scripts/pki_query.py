#!/usr/bin/env python3
#
# Copyright (C) 2023-2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import typing
from cryptography.x509.oid import ExtendedKeyUsageOID

from vyos.config import Config
from vyos.pki import encode_certificate
from vyos.pki import get_certificate_fingerprint
from vyos.pki import load_certificate
from vyos.pki import load_crl
from vyos.pki import verify_certificate


# Helper Functions
conf = Config()


def _verify(target):
    """Decorator checks if config for PKI exists"""
    from functools import wraps

    if target not in ['ca', 'certificate']:
        raise ValueError('Invalid PKI')

    def _verify_target(func):
        @wraps(func)
        def _wrapper(*args, **kwargs):
            name = kwargs.get('name')
            unconf_message = f'PKI {target} "{name}" does not exist!'
            if name:
                if not conf.exists(['pki', target, name]):
                    raise Exception(unconf_message)
            return func(*args, **kwargs)

        return _wrapper

    return _verify_target


def get_config_ca_certificate(name=None):
    """Get certificate authority configuration from VyOS config"""
    # Fetch ca certificates from config
    base = ['pki', 'ca']
    if not conf.exists(base):
        return False

    if name:
        base = base + [name]
        if not conf.exists(base + ['private', 'key']) or not conf.exists(
            base + ['certificate']
        ):
            return False

    return conf.get_config_dict(
        base, key_mangling=('-', '_'), get_first_key=True, no_tag_node_value_mangle=True
    )


def get_config_certificate(name=None):
    """Get certificates configuration from VyOS config"""
    # Get certificates from config
    base = ['pki', 'certificate']
    if not conf.exists(base):
        return False

    if name:
        base = base + [name]
        if not conf.exists(base + ['private', 'key']) or not conf.exists(
            base + ['certificate']
        ):
            return False

    return conf.get_config_dict(
        base, key_mangling=('-', '_'), get_first_key=True, no_tag_node_value_mangle=True
    )


def get_revoked_by_serial_numbers(serial_numbers=[]):
    """Return certificate names with matching serial numbers"""
    certs_out = []
    certs = get_config_certificate()
    ca_certs = get_config_ca_certificate()
    if certs:
        for cert_name, cert_dict in certs.items():
            if 'certificate' not in cert_dict:
                continue

            cert = load_certificate(cert_dict['certificate'])
            if cert.serial_number in serial_numbers:
                certs_out.append(cert_name)
    if ca_certs:
        for cert_name, cert_dict in ca_certs.items():
            if 'certificate' not in cert_dict:
                continue

            cert = load_certificate(cert_dict['certificate'])
            if cert.serial_number in serial_numbers:
                certs_out.append(cert_name)
    return certs_out


def get_certificate_ca(cert, ca_certs):
    """Find CA certificate for given certificate"""
    if not ca_certs:
        return None

    for ca_name, ca_dict in ca_certs.items():
        if 'certificate' not in ca_dict:
            continue

        ca_cert = load_certificate(ca_dict['certificate'])

        if not ca_cert:
            continue

        if verify_certificate(cert, ca_cert):
            return ca_name
    return None


@_verify('ca')
def show_authority(raw: bool = True):
    """Return structured data for all certificate authorities
    
    Args:
        raw: Flag to indicate if this is for GraphQL use
        
    Returns:
        list: List of dictionaries containing CA information
    """
    if not raw:
        print("This function is for GraphQL use only!")
        return []
    
    result = []
    certs = get_config_ca_certificate()
    
    if not certs:
        return result
        
    for cert_name, cert_dict in certs.items():
        if 'certificate' not in cert_dict:
            continue

        cert = load_certificate(cert_dict['certificate'])
        if not cert:
            continue

        parent_ca_name = get_certificate_ca(cert, certs)
        cert_issuer_cn = cert.issuer.rfc4514_string().split(',')[0]

        if not parent_ca_name or parent_ca_name == cert_name:
            parent_ca_name = None  # Use None instead of "N/A" for structured data
            
        have_private = 'private' in cert_dict and 'key' in cert_dict['private']
        
        ca_data = {
            'name': cert_name,
            'subject': cert.subject.rfc4514_string(),
            'issuer_cn': cert_issuer_cn,
            'valid_from': cert.not_valid_before.isoformat(),
            'valid_to': cert.not_valid_after.isoformat(),
            'has_private_key': have_private,
            'parent': parent_ca_name,
        }
        result.append(ca_data)

    return result


@_verify('certificate')
def show_certificate(raw: bool = True):
    """Return structured data for all certificates
    
    Args:
        raw: Flag to indicate if this is for GraphQL use
        
    Returns:
        list: List of dictionaries containing certificate information
    """
    if not raw:
        print("This function is for GraphQL use only!")
        return []
    
    result = []
    certs = get_config_certificate()
    
    if not certs:
        return result
        
    ca_certs = get_config_ca_certificate()

    for cert_name, cert_dict in certs.items():
        if 'certificate' not in cert_dict:
            continue

        cert = load_certificate(cert_dict['certificate'])
        if not cert:
            continue

        ca_name = get_certificate_ca(cert, ca_certs)
        cert_subject_cn = cert.subject.rfc4514_string().split(',')[0]
        cert_issuer_cn = cert.issuer.rfc4514_string().split(',')[0]
        cert_type = 'unknown'

        # Determine certificate type
        try:
            ext = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage)
            if ext and ExtendedKeyUsageOID.SERVER_AUTH in ext.value:
                cert_type = 'server'
            elif ext and ExtendedKeyUsageOID.CLIENT_AUTH in ext.value:
                cert_type = 'client'
        except Exception:
            pass

        revoked = 'revoke' in cert_dict
        have_private = 'private' in cert_dict and 'key' in cert_dict['private']
        
        cert_data = {
            'name': cert_name,
            'type': cert_type,
            'subject_cn': cert_subject_cn,
            'issuer_cn': cert_issuer_cn,
            'valid_from': cert.not_valid_before.isoformat(),
            'valid_to': cert.not_valid_after.isoformat(),
            'revoked': revoked,
            'has_private_key': have_private,
            'ca_name': ca_name,
        }
        result.append(cert_data)

    return result


def show_crl(raw: bool = True):
    """Return structured data for all Certificate Revocation Lists
    
    Args:
        raw: Flag to indicate if this is for GraphQL use
        
    Returns:
        list: List of dictionaries containing CRL information
    """
    if not raw:
        print("This function is for GraphQL use only!")
        return []
    
    result = []
    certs = get_config_ca_certificate()
    
    if not certs:
        return result
        
    for cert_name, cert_dict in certs.items():
        if 'crl' not in cert_dict:
            continue

        crls = cert_dict['crl']
        if isinstance(crls, str):
            crls = [crls]

        for crl_data in cert_dict['crl']:
            crl = load_crl(crl_data)
            if not crl:
                continue

            revoked_certs = get_revoked_by_serial_numbers(
                [revoked.serial_number for revoked in crl]
            )
            
            crl_entry = {
                'ca_name': cert_name,
                'last_update': crl.last_update.isoformat(),
                'revoked_certificates': revoked_certs,
            }
            result.append(crl_entry)

    return result




def show_all():
    """Return structured data for all PKI components
    
    Returns:
        dict: Dictionary containing all PKI information
    """
    return {
        'certificate_authorities': show_authority(),
        'certificates': show_certificate(),
        'crls': show_crl()
    }


if __name__ == '__main__':
    # Example usage
    import json
    
    # Get all PKI data as structured data
    all_data = show_all()
    print(json.dumps(all_data, indent=2))
    
    # Get single CA with PEM output
    # print(show_certificate_authority_structured(name="my-ca", pem=True))
    
    # Get certificate fingerprint
    # print(show_certificate_structured(name="my-cert", fingerprint="sha256"))