#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL-friendly query for L2TP remote-access sessions/statistics.

Important: module name uses `l_2_tp` because resolver mangles `L2Tp`
back into `l_2_tp` when resolving op-mode script names.
"""

import sys
import re

import vyos.accel_ppp
import vyos.opmode

from vyos.configquery import ConfigTreeQuery
from vyos.utils.process import rc_cmd


L2TP_PORT = 2004
L2TP_SHOW_SESSIONS_FIELDS = (
    'ifname,username,ip,ip6,ip6-dp,calling-sid,rate-limit,state,uptime,'
    'rx-bytes,tx-bytes'
)

SESSION_FIELDS = [
    'ifname', 'username', 'ip', 'ip6', 'ip6_dp', 'calling_sid',
    'rate_limit', 'state', 'uptime', 'rx_bytes', 'tx_bytes',
]


def _run_accel_query(port: int, command: str, error_prefix: str, prefer_rc_cmd: bool = True) -> str:
    def _rc_runner() -> str:
        rc, output = rc_cmd(f'/usr/bin/accel-cmd -p {port} {command}')
        if rc != 0:
            raise RuntimeError(output.strip() or f'accel-cmd exited with code {rc}')
        return output

    def _api_runner() -> str:
        output = vyos.accel_ppp.accel_cmd(port, command)
        if output is None:
            return ''
        return output if isinstance(output, str) else str(output)

    runners = (_rc_runner, _api_runner) if prefer_rc_cmd else (_api_runner, _rc_runner)
    errors = []

    for runner in runners:
        try:
            return runner()
        except Exception as e:
            errors.append(str(e))

    raise vyos.opmode.Error(
        f'{error_prefix}. Service is temporarily unavailable. '
        'Please verify accel-ppp is running and try again.'
    )


def _parse_sessions(output: str) -> list:
    """Parse session table; handle various formats and separators."""
    sessions = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or all(c in '-+| \t' for c in stripped):
            continue
        # Try pipe separator first, then whitespace
        if '|' in stripped:
            parts = [v.strip() for v in stripped.split('|')]
        else:
            parts = stripped.split()
        if not parts or parts[0].lower() == 'ifname':
            continue
        # Accept sessions with expected field count or more (extra fields ignored)
        if len(parts) >= len(SESSION_FIELDS):
            try:
                session_dict = dict(zip(SESSION_FIELDS, parts[:len(SESSION_FIELDS)]))
                sessions.append(session_dict)
            except Exception:
                # Skip malformed lines silently
                continue
    return sessions


def _normalize_key(key: str) -> str:
    return key.strip().lower().replace('-', '_').replace('/', '_').replace('(', '').replace(')', '')


def _coerce_value(value: str):
    value = value.strip()
    if value.isdigit():
        return int(value)
    return value


def _parse_statistics(output: str) -> dict:
    """Parse statistics; handle various formats robustly."""
    # Accept indented keys in multiline accel-cmd output so sections tokenize correctly.
    tokens = re.findall(
        r'([A-Za-z_][A-Za-z0-9_()/\-]*?)\s*:\s*(.+?)(?=\n\s*[A-Za-z_][A-Za-z0-9_()/\-]*?\s*:|$)',
        output,
        flags=re.S | re.M,
    )

    section_headers = {'core', 'sessions', 'pptp', 'pppoe', 'l2tp', 'sstp', 'ipoe'}
    stats = {}
    current_section = None

    for raw_key, raw_value in tokens:
        try:
            key = _normalize_key(raw_key)
            value = raw_value.strip()

            if key in section_headers:
                stats.setdefault(key, {})
                current_section = key
                if value:
                    # Try to parse nested inline metrics
                    inline_tokens = re.findall(
                        r'([A-Za-z_][A-Za-z0-9_()/\-]*)\s*:\s*([^:\n]+)',
                        value,
                    )
                    if inline_tokens:
                        for inline_key, inline_value in inline_tokens:
                            stats[key][_normalize_key(inline_key)] = _coerce_value(inline_value.strip())
                    else:
                        stats[key]['value'] = _coerce_value(value)
                continue

            if current_section and key:  # Only add if we have a key
                stats[current_section][key] = _coerce_value(value)
                continue

            if key:  # Top-level metric
                stats[key] = _coerce_value(value)
        except Exception:
            # Skip unparseable tokens
            continue

    return stats


def _verify_l2tp_configured(func):
    from functools import wraps

    @wraps(func)
    def _wrapper(*args, **kwargs):
        conf = ConfigTreeQuery()
        if not conf.exists(['vpn', 'l2tp', 'remote-access']):
            raise vyos.opmode.UnconfiguredObject(
                'L2TP remote-access server is not configured!'
            )
        return func(*args, **kwargs)

    return _wrapper


@_verify_l2tp_configured
def _show_l2tp_server_sessions(raw: bool = True):
    command = f'show sessions {L2TP_SHOW_SESSIONS_FIELDS}'

    output = _run_accel_query(
        L2TP_PORT,
        command,
        'Failed to query L2TP sessions',
        prefer_rc_cmd=True,
    )

    if raw:
        return _parse_sessions(output)

    return _run_accel_query(
        L2TP_PORT,
        command,
        'Failed to query L2TP sessions',
        prefer_rc_cmd=False,
    )


@_verify_l2tp_configured
def _show_l2tp_server_statistics(raw: bool = True):
    command = 'show stat'

    if raw:
        output = _run_accel_query(
            L2TP_PORT,
            command,
            'Failed to query L2TP statistics',
            prefer_rc_cmd=True,
        )
        return _parse_statistics(output)

    return _run_accel_query(
        L2TP_PORT,
        command,
        'Failed to query L2TP statistics',
        prefer_rc_cmd=False,
    )


def show_layer_two_tp_server_sessions(raw: bool = True):
    return _show_l2tp_server_sessions(raw=raw)


def show_layer_two_tp_server_statistics(raw: bool = True):
    return _show_l2tp_server_statistics(raw=raw)


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
