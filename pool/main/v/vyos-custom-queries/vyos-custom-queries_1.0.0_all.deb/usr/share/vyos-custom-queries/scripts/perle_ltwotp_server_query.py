#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL-friendly query for L2TP remote-access sessions/statistics.

Implements the same backend behavior as:
    show l2tp-server sessions
    show l2tp-server statistics
"""

import sys
import re

import vyos.accel_ppp
import vyos.opmode

from vyos.configquery import ConfigTreeQuery
from vyos.utils.process import rc_cmd


L2TP_PORT = 2004
L2TP_SHOW_SESSIONS_FIELDS = (
    'ifname,username,ip,ip6,ip6-dp,calling-sid,rate-limit,state,uptime,'
    'rx-bytes,tx-bytes'
)

# Column names matching the accel-cmd session fields above
SESSION_FIELDS = [
    'ifname', 'username', 'ip', 'ip6', 'ip6_dp', 'calling_sid',
    'rate_limit', 'state', 'uptime', 'rx_bytes', 'tx_bytes',
]


def _parse_sessions(output: str) -> list:
    """Parse accel-cmd pipe-separated table output into a list of dicts."""
    sessions = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped or all(c in '-+| ' for c in stripped):
            continue
        parts = [v.strip() for v in stripped.split('|')]
        if parts and parts[0].lower() == 'ifname':
            continue
        if len(parts) == len(SESSION_FIELDS):
            sessions.append(dict(zip(SESSION_FIELDS, parts)))
    return sessions


def _normalize_key(key: str) -> str:
    """Normalize accel statistic keys to GraphQL/JSON-friendly snake_case."""
    return key.strip().lower().replace('-', '_').replace('/', '_').replace('(', '').replace(')', '')


def _coerce_value(value: str):
    """Convert simple numeric strings to int; keep all other values as-is."""
    value = value.strip()
    if value.isdigit():
        return int(value)
    return value


def _parse_statistics(output: str) -> dict:
    """Parse `accel-cmd show stat` output into a structured dict."""
    tokens = re.findall(
        r'\s*([A-Za-z_][A-Za-z0-9_()\-/]*)\s*:\s*(.*?)\s*(?=\s+[A-Za-z_][A-Za-z0-9_()\-/]*\s*:|$)',
        output,
        flags=re.S,
    )

    section_headers = {'core', 'sessions', 'pptp', 'pppoe', 'l2tp', 'sstp', 'ipoe'}

    stats = {}
    current_section = None

    for raw_key, raw_value in tokens:
        key = _normalize_key(raw_key)
        value = raw_value.strip()

        if key in section_headers:
            stats.setdefault(key, {})
            current_section = key
            if value:
                inline_tokens = re.findall(
                    r'\s*([A-Za-z_][A-Za-z0-9_()\-/]*)\s*:\s*(.*?)\s*(?=\s+[A-Za-z_][A-Za-z0-9_()\-/]*\s*:|$)',
                    value,
                    flags=re.S,
                )
                if inline_tokens:
                    for inline_key, inline_value in inline_tokens:
                        stats[key][_normalize_key(inline_key)] = _coerce_value(inline_value)
                else:
                    stats[key]['value'] = _coerce_value(value)
            continue

        if current_section:
            stats[current_section][key] = _coerce_value(value)
            continue

        stats[key] = _coerce_value(value)

    return stats


def _verify_l2tp_configured(func):
    """Ensure L2TP remote-access server is configured before querying."""
    from functools import wraps

    @wraps(func)
    def _wrapper(*args, **kwargs):
        conf = ConfigTreeQuery()
        if not conf.exists(['vpn', 'l2tp', 'remote-access']):
            raise vyos.opmode.UnconfiguredObject(
                'L2TP remote-access server is not configured!'
            )
        return func(*args, **kwargs)

    return _wrapper


@_verify_l2tp_configured
def _show_l2tp_server_sessions(raw: bool = True):
    """Show L2TP remote-access sessions (same data as `show l2tp-server sessions`)."""
    command = f'show sessions {L2TP_SHOW_SESSIONS_FIELDS}'

    rc, output = rc_cmd(f'/usr/bin/accel-cmd -p {L2TP_PORT} {command}')
    if rc != 0:
        raise vyos.opmode.Error(output.strip() or 'Failed to query L2TP sessions')

    if raw:
        return _parse_sessions(output)

    return vyos.accel_ppp.accel_cmd(L2TP_PORT, command)


@_verify_l2tp_configured
def _show_l2tp_server_statistics(raw: bool = True):
    """Show L2TP server statistics (same data as `show l2tp-server statistics`)."""
    command = 'show stat'

    if raw:
        rc, output = rc_cmd(f'/usr/bin/accel-cmd -p {L2TP_PORT} {command}')
        if rc != 0:
            raise vyos.opmode.Error(output.strip() or 'Failed to query L2TP statistics')
        return _parse_statistics(output)

    return vyos.accel_ppp.accel_cmd(L2TP_PORT, command)


def show_layer_two_tp_server_sessions(raw: bool = True):
    """GraphQL-safe alias for L2TP sessions.

    Uses a letter-only function name to avoid resolver mangling (L2Tp -> l_2_tp).
    """
    return _show_l2tp_server_sessions(raw=raw)


def show_layer_two_tp_server_statistics(raw: bool = True):
    """GraphQL-safe alias for L2TP statistics.

    Uses a letter-only function name to avoid resolver mangling (L2Tp -> l_2_tp).
    """
    return _show_l2tp_server_statistics(raw=raw)


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
