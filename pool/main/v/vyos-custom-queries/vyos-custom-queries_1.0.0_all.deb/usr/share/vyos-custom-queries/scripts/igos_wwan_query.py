#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.

"""GraphQL-friendly access to ``show interfaces wwan <interface>``.

Supported keywords and their equivalent operational-mode commands:
    status               -> show interfaces wwan <interface> status
    detail               -> show interfaces wwan <interface> detail
    hardware             -> show interfaces wwan <interface> hardware
    signal               -> show interfaces wwan <interface> signal
    sim                  -> show interfaces wwan <interface> sim
    event-log            -> show interfaces wwan <interface> event-log
    monitor-alerts       -> show interfaces wwan <interface> monitor-alerts
    wait-failover-alert  -> show interfaces wwan <interface> wait-failover-alert
    bearer-leases        -> show interfaces wwan <interface> bearer-leases
    sms                  -> show interfaces wwan <interface> sms

Omitting ``keyword`` selects ``status``, which is the behavior of the WWAN
interface command without a subcommand. Structured operations are delegated
to the same public functions used by the VyOS command templates in
``show_wwan.py``. Commands implemented by other op-mode scripts are invoked
through VyOS's operational-command wrapper.
"""

import importlib.util
from pathlib import Path
import re
import subprocess
import sys
import typing

import vyos.opmode


SHOW_WWAN_PATH = Path('/usr/libexec/vyos/op_mode/show_wwan.py')
OP_COMMAND_WRAPPER = Path('/opt/vyatta/bin/vyatta-op-cmd-wrapper')
INTERFACE_PATTERN = re.compile(r'^wwan[0-9]+$')

DIRECT_KEYWORDS = {
    'status',
    'detail',
    'hardware',
    'signal',
    'sim',
    'event-log',
    'monitor-alerts',
    'wait-failover-alert',
}
CLI_KEYWORDS = {'bearer-leases', 'sms'}
VALID_KEYWORDS = DIRECT_KEYWORDS | CLI_KEYWORDS

_show_wwan_module = None


def _load_show_wwan_module():
    """Load the installed VyOS WWAN op-mode implementation once."""
    global _show_wwan_module
    if _show_wwan_module is not None:
        return _show_wwan_module

    if not SHOW_WWAN_PATH.is_file():
        raise vyos.opmode.Error(
            f'WWAN op-mode implementation not found: {SHOW_WWAN_PATH}'
        )

    spec = importlib.util.spec_from_file_location(
        '_igos_wwan_op_mode_backend', SHOW_WWAN_PATH
    )
    if spec is None or spec.loader is None:
        raise vyos.opmode.Error(
            f'Unable to load WWAN op-mode implementation: {SHOW_WWAN_PATH}'
        )

    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        raise vyos.opmode.Error(
            f'Unable to load WWAN op-mode implementation: {exc}'
        ) from exc

    _show_wwan_module = module
    return module


def _normalize_inputs(interface: str, keyword: typing.Optional[str]) -> tuple[str, str]:
    normalized_interface = str(interface or '').strip()
    if not INTERFACE_PATTERN.fullmatch(normalized_interface):
        raise vyos.opmode.Error(
            f'Invalid WWAN interface: {interface}. Expected wwan followed by a number.'
        )

    normalized_keyword = (keyword or 'status').strip().lower().replace('_', '-')
    if normalized_keyword not in VALID_KEYWORDS:
        valid = ', '.join(sorted(VALID_KEYWORDS))
        raise vyos.opmode.Error(
            f'Invalid WWAN keyword: {keyword}. Valid values: {valid}'
        )

    return normalized_interface, normalized_keyword


def _reject_unsupported_options(keyword: str, **options) -> None:
    supplied = [
        name
        for name, value in options.items()
        if value is not None and value != '' and value is not False
    ]
    if supplied:
        raise vyos.opmode.Error(
            f'{", ".join(supplied)} is not valid for the {keyword} WWAN query.'
        )


def _run_cli_query(interface: str, keyword: str):
    """Run a whitelisted WWAN CLI branch implemented outside show_wwan.py."""
    if not OP_COMMAND_WRAPPER.is_file():
        raise vyos.opmode.Error(
            f'VyOS operational-command wrapper not found: {OP_COMMAND_WRAPPER}'
        )

    command = [
        str(OP_COMMAND_WRAPPER),
        'show',
        'interfaces',
        'wwan',
        interface,
        keyword,
    ]
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise vyos.opmode.Error(
            f'Failed to execute WWAN {keyword} query: {exc}'
        ) from exc

    output = (completed.stdout or '').strip()
    error = (completed.stderr or '').strip()
    if completed.returncode != 0:
        detail = error or output or f'exit status {completed.returncode}'
        raise vyos.opmode.Error(f'Failed to execute WWAN {keyword} query: {detail}')

    return output


def _run_direct_query(
    raw: bool,
    interface: str,
    keyword: str,
    timeout: typing.Optional[int],
    poll_interval: typing.Optional[int],
    include_existing: bool,
    limit: typing.Optional[int],
    severity: typing.Optional[str],
    category: typing.Optional[str],
):
    backend = _load_show_wwan_module()

    simple_handlers = {
        'status': 'show_status',
        'detail': 'show_detail',
        'hardware': 'show_hardware',
        'signal': 'show_signal',
        'sim': 'show_sim',
    }
    if keyword in simple_handlers:
        _reject_unsupported_options(
            keyword,
            timeout=timeout,
            poll_interval=poll_interval,
            include_existing=include_existing,
            limit=limit,
            severity=severity,
            category=category,
        )
        handler = getattr(backend, simple_handlers[keyword])
        return handler(raw=raw, interface=interface)

    if keyword == 'event-log':
        _reject_unsupported_options(
            keyword,
            timeout=timeout,
            poll_interval=poll_interval,
            include_existing=include_existing,
        )
        return backend.show_event_log(
            raw=raw,
            interface=interface,
            limit=limit,
            severity=severity or '',
            category=category or '',
        )

    if keyword == 'monitor-alerts':
        _reject_unsupported_options(
            keyword,
            poll_interval=poll_interval,
            include_existing=include_existing,
            limit=limit,
        )
        return backend.show_monitor_alerts(
            raw=raw,
            interface=interface,
            timeout=timeout,
            severity=severity or '',
            category=category or '',
        )

    if keyword == 'wait-failover-alert':
        _reject_unsupported_options(
            keyword,
            limit=limit,
            severity=severity,
            category=category,
        )
        return backend.show_wait_failover(
            raw=raw,
            interface=interface,
            timeout=timeout,
            poll_interval=poll_interval,
            include_existing=include_existing,
        )

    raise vyos.opmode.Error(f'No WWAN handler is available for {keyword}.')


def show_wwan(
    raw: bool,
    interface: str,
    keyword: typing.Optional[str] = None,
    timeout: typing.Optional[int] = None,
    poll_interval: typing.Optional[int] = None,
    include_existing: bool = False,
    limit: typing.Optional[int] = None,
    severity: typing.Optional[str] = None,
    category: typing.Optional[str] = None,
):
    """Return the requested WWAN operational data for GraphQL.

    ``interface`` must be a configured-style name such as ``wwan0``. Omitting
    ``keyword`` returns status. Optional arguments correspond to the event-log,
    monitor-alerts, and wait-failover-alert command branches.
    """
    normalized_interface, normalized_keyword = _normalize_inputs(interface, keyword)

    if normalized_keyword in CLI_KEYWORDS:
        _reject_unsupported_options(
            normalized_keyword,
            timeout=timeout,
            poll_interval=poll_interval,
            include_existing=include_existing,
            limit=limit,
            severity=severity,
            category=category,
        )
        return _run_cli_query(normalized_interface, normalized_keyword)

    return _run_direct_query(
        raw=raw,
        interface=normalized_interface,
        keyword=normalized_keyword,
        timeout=timeout,
        poll_interval=poll_interval,
        include_existing=include_existing,
        limit=limit,
        severity=severity,
        category=category,
    )


if __name__ == '__main__':
    try:
        result = vyos.opmode.run(sys.modules[__name__])
        if result:
            print(result)
    except (ValueError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(1)
