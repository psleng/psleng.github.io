#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL-friendly OSPF query via vtysh JSON commands.

Supported commands:
    show ip ospf json
    show ip ospf border-routers json
    show ip ospf database json
    show ip ospf interface json
    show ip ospf neighbor json
    show ip ospf summary-address json
"""

import json
import sys
import typing

import vyos.opmode
from vyos.utils.process import rc_cmd


OSPF_KEYWORD_TO_COMMAND = {
    'overview': 'show ip ospf json',
    'border-routers': 'show ip ospf border-routers json',
    'database': 'show ip ospf database json',
    'interface': 'show ip ospf interface json',
    'neighbor': 'show ip ospf neighbor json',
    'summary-address': 'show ip ospf summary-address json',
}


def _run_vtysh_ospf_json(command_keyword: str):
    keyword = (command_keyword or 'overview').strip().lower()
    if keyword not in OSPF_KEYWORD_TO_COMMAND:
        valid = ', '.join(sorted(OSPF_KEYWORD_TO_COMMAND.keys()))
        raise vyos.opmode.Error(f'Invalid OSPF keyword: {command_keyword}. Valid values: {valid}')

    ospf_command = OSPF_KEYWORD_TO_COMMAND[keyword]
    commands = [
        f"/usr/bin/vtysh -c '{ospf_command}'",
        f"/usr/sbin/vtysh -c '{ospf_command}'",
        f"vtysh -c '{ospf_command}'",
    ]

    output = ''
    errors = []
    for cmd in commands:
        rc, out = rc_cmd(cmd)
        if rc == 0 and out:
            output = out
            break
        if out:
            errors.append(out.strip())

    if not output:
        detail = f" Details: {' | '.join(errors)}" if errors else ''
        raise vyos.opmode.Error(f'Failed to query OSPF data from vtysh.{detail}')

    try:
        return json.loads(output)
    except json.JSONDecodeError as e:
        raise vyos.opmode.Error(f'Failed to parse OSPF JSON output: {str(e)}')


def show_ospf(raw: bool = True, keyword: typing.Optional[str] = None):
    """Show OSPF JSON data.

    keyword is the token after "show ip ospf".
    Examples:
      - None / omitted -> show ip ospf json
      - interface      -> show ip ospf interface json
      - neighbor       -> show ip ospf neighbor json
    """
    return _run_vtysh_ospf_json(keyword or 'overview')


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
