#!/usr/bin/env python3
#
# Copyright (C) 2022 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import json
import re
import sys
import typing

from jinja2 import Template

from vyos.utils.process import rc_cmd

import vyos.opmode

journalctl_command_template = Template("""
--no-hostname
--quiet

{% if boot %}
  --boot
{% endif %}

{% if count %}
  --lines={{ count }}
{% endif %}

{% if reverse %}
  --reverse
{% endif %}

{% if since %}
  --since={{ since }}
{% endif %}

{% if unit %}
  --unit={{ unit }}
{% endif %}

{% if utc %}
  --utc
{% endif %}

{% if raw %}
{# By default show 100 only lines for raw option if count does not set #}
{# Protection from parsing the full log by default #}
{%    if not boot %}
  --lines={{ '' ~ count if count else '100' }}
{%    endif %}
  --no-pager
  --output=json
{% endif %}
""")


def show(raw: bool,
         boot: typing.Optional[bool],
         count: typing.Optional[int],
         facility: typing.Optional[str],
         reverse: typing.Optional[bool],
         utc: typing.Optional[bool],
         unit: typing.Optional[str]):
    kwargs = dict(locals())

    journalctl_options = journalctl_command_template.render(kwargs)
    journalctl_options = re.sub(r'\s+', ' ', journalctl_options)
    rc, output = rc_cmd(f'journalctl {journalctl_options}')
    if raw:
        # Each 'journalctl --output json' line is a separate JSON object
        # So we should return list of dict
        return [json.loads(line) for line in output.split('\n')]
    return output


import time
from datetime import datetime

def show_time(raw: bool,
              minutes: int,
              keyword: typing.Optional[str] = None,
              unit: typing.Optional[str] = None,
              facility: typing.Optional[str] = None,
              syslog_identifier: typing.Optional[str] = None,
              priority: typing.Optional[int] = None):
    """
    Show logs from the past X minutes, ordered from newest to oldest.
    
    Args:
        raw: Return structured JSON data if True, text output if False
        minutes: Number of minutes in the past to fetch logs from
        keyword: Filter logs to only include entries containing this keyword
        unit: Filter logs by systemd unit
        facility: Filter logs by syslog facility
        syslog_identifier: Filter logs by syslog identifier (e.g., "kernel", "systemd")
        priority: Filter logs by priority level (0-7, where 0=emerg, 7=debug)
    
    Returns:
        If raw=True: List of dictionary objects (parsed JSON logs)
        If raw=False: String with formatted log output
    """
    try:
        minutes = int(minutes)
        if minutes < 0:
            return "Error: Minutes must be a non-negative integer"
    except (ValueError, TypeError):
        return "Error: Invalid minutes value"
    
    # Validate priority if provided
    if priority is not None:
        try:
            priority_val = int(priority)
            if priority_val < 0 or priority_val > 7:
                return "Error: Priority must be between 0 and 7"
        except (ValueError, TypeError):
            return "Error: Invalid priority value"
    
    # Build command with appropriate output format
    if raw:
        cmd = ['journalctl', '--no-pager', '--output=json']
    else:
        cmd = ['journalctl', '--no-hostname', '--quiet']
    
    # Add time filter
    if minutes > 0:
        cmd.append(f'--since="{minutes}min ago"')
    cmd.append('--reverse')
    
    # Add identifier filter if provided
    if syslog_identifier:
        cmd.append(f'--identifier="{syslog_identifier}"')
    
    # Add priority filter if provided
    if priority is not None:
        cmd.append(f'--priority={priority}')
    
    # Add unit and facility filters if provided
    if unit:
        cmd.append(f'--unit={unit}')
    
    if facility:
        cmd.append(f'--facility={facility}')
    
    # Add keyword filter if provided
    if keyword:
        # Use grep-like pattern matching for the keyword
        cmd.append(f'--grep="{keyword}"')
    
    # Convert command list to string
    cmd_str = ' '.join(cmd)
    
    # Execute the command
    import subprocess
    result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True)
    
    if result.returncode != 0 and result.returncode != 1:  # journalctl returns 1 if no entries match
        return f"Error executing journalctl: {result.stderr}"
    
    output = result.stdout
    
    if raw:
        # For raw output, parse JSON lines
        valid_lines = [line for line in output.split('\n') if line.strip()]
        try:
            return [json.loads(line) for line in valid_lines if line]
        except json.JSONDecodeError as e:
            return f"Failed to parse JSON: {str(e)}"
    
    return output

if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
