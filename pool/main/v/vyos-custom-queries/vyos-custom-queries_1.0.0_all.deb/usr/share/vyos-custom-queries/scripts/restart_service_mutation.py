#!/usr/bin/env python3
#
# Copyright (C) 2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL mutation for restarting VyOS services.

This mutation provides functionality equivalent to the VyOS op-mode command:
    /usr/libexec/vyos/op_mode/restart.py restart_service --name <service>

Usage via GraphQL:
    mutation {
        RestartService(data: {key: "...", name: "dhcp"}) {
            success
            data {
                result
            }
            errors
        }
    }

Supported services:
    - dhcp_server: DHCP server (kea-dhcp4-server)
    - dhcpv6_server: DHCPv6 server (kea-dhcp6-server)
    - dns_dynamic: Dynamic DNS (ddclient)
    - dns_forwarding: DNS forwarding (pdns-recursor)
    - haproxy: HAProxy load balancer
    - igmp_proxy: IGMP proxy
    - ipsec: IPsec VPN (strongswan)
    - load_balancing_wan: WAN load balancing
    - mdns_repeater: mDNS repeater (avahi-daemon)
    - router_advert: Router advertisement (radvd)
    - snmp: SNMP daemon
    - ssh: SSH server
    - suricata: Suricata IDS/IPS
    - vrrp: VRRP (keepalived)
    - webproxy: Web proxy (squid)
"""

import sys
import typing
import json

import vyos.opmode
from vyos.utils.process import cmd


# VyOS restart script path
VYOS_RESTART_SCRIPT = '/usr/libexec/vyos/op_mode/restart.py'

# Valid services supported by VyOS restart.py
SERVICE_MAP = {
    'dhcp_server': {
        'restart_name': 'dhcp',
        'systemd_service': 'kea-dhcp4-server',
        'path': ['service', 'dhcp-server'],
        'human_name': 'DHCP server'
    },
    'dhcpv6_server': {
        'restart_name': 'dhcpv6',
        'systemd_service': 'kea-dhcp6-server',
        'path': ['service', 'dhcpv6-server'],
        'human_name': 'DHCPv6 server'
    },
    'dns_dynamic': {
        'systemd_service': 'ddclient',
        'path': ['service', 'dns', 'dynamic'],
        'human_name': 'DNS dynamic'
    },
    'dns_forwarding': {
        'systemd_service': 'pdns-recursor',
        'path': ['service', 'dns', 'forwarding'],
        'human_name': 'DNS forwarding'
    },
    'haproxy': {
        'systemd_service': 'haproxy',
        'path': ['load-balancing', 'haproxy'],
        'human_name': 'HAProxy'
    },
    'igmp_proxy': {
        'systemd_service': 'igmpproxy',
        'path': ['protocols', 'igmp-proxy'],
        'human_name': 'IGMP proxy'
    },
    'ipsec': {
        'systemd_service': 'strongswan',
        'path': ['vpn', 'ipsec'],
        'human_name': 'IPsec'
    },
    'load_balancing_wan': {
        'systemd_service': 'vyos-wan-load-balance',
        'path': ['load-balancing', 'wan'],
        'human_name': 'WAN load-balancing'
    },
    'mdns_repeater': {
        'systemd_service': 'avahi-daemon',
        'path': ['service', 'mdns', 'repeater'],
        'human_name': 'mDNS repeater'
    },
    'router_advert': {
        'systemd_service': 'radvd',
        'path': ['service', 'router-advert'],
        'human_name': 'Router advertisement'
    },
    'snmp': {
        'systemd_service': 'snmpd',
        'path': ['service', 'snmp'],
        'human_name': 'SNMP'
    },
    'ssh': {
        'systemd_service': 'ssh',
        'path': ['service', 'ssh'],
        'human_name': 'SSH'
    },
    'suricata': {
        'systemd_service': 'suricata',
        'path': ['service', 'suricata'],
        'human_name': 'Suricata'
    },
    'vrrp': {
        'systemd_service': 'keepalived',
        'path': ['high-availability', 'vrrp'],
        'human_name': 'VRRP'
    },
    'webproxy': {
        'systemd_service': 'squid',
        'path': ['service', 'webproxy'],
        'human_name': 'Web proxy'
    },
}


def list_services() -> dict:
    """
    List all available services that can be restarted.
    
    Returns:
        dict: List of available services with details
    """
    services = []
    for name, info in sorted(SERVICE_MAP.items()):
        services.append({
            'name': name,
            'human_name': info['human_name'],
            'systemd_service': info['systemd_service'],
            'config_path': '/'.join(info.get('path', ['service', name]))
        })
    return {
        'success': True,
        'services': services,
        'count': len(services)
    }


def restart_service(
    name: str,
    vrf: typing.Optional[str] = None
) -> dict:
    """
    Restart a VyOS service by calling the native VyOS restart script.
    
    This function calls:
        /usr/libexec/vyos/op_mode/restart.py restart_service --name <service>
    
    Args:
        name (str): Service name key from SERVICE_MAP.
               Valid values: dhcp_server, dhcpv6_server, dns_dynamic, dns_forwarding,
                   haproxy, igmp_proxy, ipsec, load_balancing_wan, mdns_repeater,
                   router_advert, snmp, ssh, suricata, vrrp, webproxy
        vrf (str, optional): VRF name if service should be restarted in specific 
                            VRF context. Defaults to None.
    
    Returns:
        dict: Structured response with success status and details
    
    Example GraphQL mutation:
        mutation {
            RestartServiceRestartServiceMutation(data: {
                key: "your-api-key",
                name: "dhcp_server",
                vrf: null
            }) {
                success
                data { result }
                errors
            }
        }
    """
    try:
        # Validate service name
        if name not in SERVICE_MAP:
            valid_services = ', '.join(sorted(SERVICE_MAP.keys()))
            return {
                'success': False,
                'error': f'Invalid service "{name}". Valid services: {valid_services}',
                'service': name,
                'valid_services': list(sorted(SERVICE_MAP.keys()))
            }
        
        service_info = SERVICE_MAP[name]
        human_name = service_info.get('human_name', name.replace('_', '-'))
        
        # Build command to call VyOS restart script
        restart_name = service_info.get('restart_name', name)
        command = f'{VYOS_RESTART_SCRIPT} restart_service --raw --name {restart_name}'
        if vrf:
            command += f' --vrf {vrf}'
        
        # Execute the VyOS restart script
        try:
            output = cmd(command)
            # Parse JSON output from the script
            result = json.loads(output)
            return {
                'success': True,
                'message': f'Successfully restarted {human_name}',
                'service': name,
                'human_name': human_name,
                'vrf': vrf,
                'script_output': result
            }
        except json.JSONDecodeError:
            # Script returned non-JSON output (success message)
            return {
                'success': True,
                'message': f'Successfully restarted {human_name}',
                'service': name,
                'human_name': human_name,
                'vrf': vrf,
                'script_output': output.strip() if output else None
            }
        except Exception as e:
            error_msg = str(e)
            return {
                'success': False,
                'error': f'Failed to restart {human_name}: {error_msg}',
                'service': name,
                'human_name': human_name,
                'vrf': vrf
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': f'Error restarting {name} service: {str(e)}',
            'service': name
        }


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
