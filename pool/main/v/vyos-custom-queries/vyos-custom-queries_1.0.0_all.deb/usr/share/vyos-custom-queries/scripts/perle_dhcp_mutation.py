#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL mutations for DHCP client lease renew/release.

Equivalent op-mode behaviors:
    - renew_client_lease(): restart dhclient/dhcp6c for an interface
    - release_client_lease(): stop dhclient/dhcp6c for an interface

Fixes the upstream renew_client_lease/release_client_lease GraphQL error:
  "missing 1 required positional argument: 'raw'"
by making ``raw`` optional (default=True) and placing it after the schema
input fields, so GraphQL can call these functions with only family+interface.

Note: str is used for ``family`` instead of typing.Literal so that the VyOS
schema generator does not produce an empty .graphql file.
"""

import sys

import vyos.opmode

from vyos.configquery import ConfigTreeQuery
from vyos.ifconfig import Section
from vyos.utils.process import call


VALID_FAMILIES = ('inet', 'inet6')


def _verify_client(func):
    """Decorator checks if interface is configured as DHCP client."""
    from functools import wraps

    @wraps(func)
    def _wrapper(*args, **kwargs):
        config = ConfigTreeQuery()
        family = kwargs.get('family')
        if family not in VALID_FAMILIES:
            raise vyos.opmode.IncorrectValue(
                f'Invalid family "{family}". Valid values: inet, inet6.'
            )
        v = 'v6' if family == 'inet6' else ''
        interface = kwargs.get('interface')

        interface_path = Section.get_config_path(interface)
        path_elems = interface_path.split()
        base_path = ['interfaces'] + path_elems

        unconf_message = f'DHCP{v} client not configured on interface {interface}!'

        iface_conf = config.get_config_dict(
            base_path, key_mangling=('-', '_'), get_first_key=True
        )

        if family == 'inet6':
            addrs = iface_conf.get('address', [])
            has_dhcpv6_addr = 'dhcpv6' in addrs

            dhcpv6_opts = iface_conf.get('dhcpv6_options', {})
            has_parameters_only = 'parameters_only' in dhcpv6_opts
            has_pd = 'pd' in dhcpv6_opts

            config_exists = has_dhcpv6_addr or has_parameters_only or has_pd
        else:
            addrs = iface_conf.get('address', [])
            config_exists = 'dhcp' in addrs

        if not config_exists:
            raise vyos.opmode.UnconfiguredObject(unconf_message)

        return func(*args, **kwargs)

    return _wrapper


@_verify_client
def renew_client_lease(
    family: str,
    interface: str,
    raw: bool = True,
) -> dict:
    """Renew DHCP client lease on an interface."""
    if not raw:
        v = 'v6' if family == 'inet6' else ''
        print(f'Restarting DHCP{v} client on interface {interface}...')

    if family == 'inet6':
        rc = call(f'systemctl restart dhcp6c@{interface}.service')
    else:
        rc = call(f'systemctl restart dhclient@{interface}.service')

    return {
        'success': rc == 0,
        'result': f'Renewed DHCP{"v6" if family == "inet6" else ""} client lease on {interface}',
        'family': family,
        'interface': interface,
    }


@_verify_client
def release_client_lease(
    family: str,
    interface: str,
    raw: bool = True,
) -> dict:
    """Release DHCP client lease on an interface."""
    if not raw:
        v = 'v6' if family == 'inet6' else ''
        print(f'Release DHCP{v} client on interface {interface}...')

    if family == 'inet6':
        rc = call(f'systemctl stop dhcp6c@{interface}.service')
    else:
        rc = call(f'systemctl stop dhclient@{interface}.service')

    return {
        'success': rc == 0,
        'result': f'Released DHCP{"v6" if family == "inet6" else ""} client lease on {interface}',
        'family': family,
        'interface': interface,
    }


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
