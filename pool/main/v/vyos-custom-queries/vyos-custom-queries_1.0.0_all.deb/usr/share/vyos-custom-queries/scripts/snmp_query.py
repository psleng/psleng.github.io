#!/usr/bin/env python3
#
# Copyright (C) 2018-2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import json
import re
import argparse
import netifaces
import jinja2

from vyos.config import Config
from vyos.utils.process import call, cmd, popen
import vyos.opmode

# Constants
CONFIG_FILE_DAEMON = r'/etc/snmp/snmpd.conf'

# Templates for SNMP v3 output
GROUP_OUTP_TMPL_SRC = """
SNMPv3 Groups:

    Group               View                 Security
    -----               ----                 --------
    {% if group %}{% for g in group %}
    {{ "%-20s" | format(g.name) }}{{ "%-20s" | format(g.view + "(" + g.mode + ")") }}{{ g.seclevel }}
    {% endfor %}{% endif %}
"""

TRAPTGT_OUTP_TMPL_SRC = """
SNMPv3 Trap-targets:

    Trap-target                  Port   Protocol Auth Priv Type   EngineID                         User
    -----------                  ----   -------- ---- ---- ----   --------                         ----
    {% if trap %}{% for t in trap %}
    {{ "%-20s" | format(t.name) }}          {{ t.port }}    {{ t.proto }}      {{ t.auth }}  {{ t.priv }}  {{ t.type }}   {{ "%-32s" | format(t.engID) }} {{ t.user }}
    {% endfor %}{% endif %}
"""

USER_OUTP_TMPL_SRC = """
SNMPv3 Users:

    User                Auth Priv Mode Group
    ----                ---- ---- ---- -----
    {% if user %}{% for u in user %}
    {{ "%-20s" | format(u.name) }}{{ u.auth }}  {{ u.priv }}  {{ u.mode }}   {{ u.group }}
    {% endfor %}{% endif %}
"""

VIEW_OUTP_TMPL_SRC = """
SNMPv3 Views:
    {% if view %}{% for v in view %}
    View : {{ v.name }}
    OIDs : .{{ v.oids | join("\n           .")}}
    {% endfor %}{% endif %}
"""

# Global configuration
config = {
    'communities': [],
}


def read_config():
    """Read and parse SNMP configuration file to extract communities"""
    with open(CONFIG_FILE_DAEMON, 'r') as f:
        for line in f:
            # Only get configured SNMP communities
            if line.startswith('rocommunity') or line.startswith('rwcommunity'):
                string = line.split(' ')
                # append community to the output list only once
                c = string[1]
                if c not in config['communities']:
                    config['communities'].append(c)


def show_all():
    """Display all available SNMP communities"""
    if len(config['communities']) > 0:
        print(' '.join(config['communities']))


def show_community(community, host="localhost", raw=True):
    """
    Display information about a specific SNMP community on a host
    
    Args:
        community (str): The SNMP community string
        host (str): The hostname or IP address to query
        raw (bool): Whether to return structured data for GraphQL
    
    Returns:
        dict: If raw is True, returns structured data about the SNMP status
        None: If raw is False, prints to stdout
    """
    if raw:
        try:
            output = cmd(f'/usr/bin/snmpstatus -t1 -v1 -c {community} {host}')
            
            # Extract system information and uptime
            system_info_match = re.search(r'\[(.*?)\] Up: (.*?)$', output, re.MULTILINE)
            system_info = system_info_match.group(1) if system_info_match else ""
            uptime = system_info_match.group(2) if system_info_match else ""
            
            # Extract interface and packet information
            interface_match = re.search(r'Interfaces: (\d+), Recv/Trans packets: (\d+)/(\d+)', output)
            interfaces = int(interface_match.group(1)) if interface_match else 0
            recv_packets = int(interface_match.group(2)) if interface_match else 0
            trans_packets = int(interface_match.group(3)) if interface_match else 0
            
            # Extract IP packet information
            ip_match = re.search(r'IP: (\d+)/(\d+)', output)
            ip_in_pkt = int(ip_match.group(1)) if ip_match else 0
            ip_out_pkt = int(ip_match.group(2)) if ip_match else 0
            
            # Extract down interfaces information - if present
            down_interfaces_match = re.search(r'(\d+) interfaces are down!', output)
            intf_down = int(down_interfaces_match.group(1)) if down_interfaces_match else 0
            
            # Split into connection details and entity description
            parts = system_info.split("=>")
            if len(parts) >= 2:
                ip_conn = parts[0]
                # Remove the leading "[" from the entity description
                entity_desc = "".join(parts[1:])
                if entity_desc.startswith("["):
                    entity_desc = entity_desc[1:]
                # Remove the trailing "]" if it exists
                if entity_desc.endswith("]"):
                    entity_desc = entity_desc[:-1]
            else:
                ip_conn = ""
                entity_desc = system_info
            
            return {
                'host': host,
                'community': community,
                'ip_connection': ip_conn,
                'entity_description': entity_desc,
                'uptime': uptime,
                'interfaces': interfaces,
                'interfaces_down': intf_down,
                'received_packets': recv_packets,
                'transmitted_packets': trans_packets,
                'ip_in_packets': ip_in_pkt,
                'ip_out_packets': ip_out_pkt,
                'status': 'up' if output else 'down'
            }
        except Exception as e:
            return {
                'host': host,
                'community': community,
                'error': str(e),
                'status': 'error'
            }
    else:
        print(f'Status of SNMP community {community} on {host}', flush=True)
        call(f'/usr/bin/snmpstatus -t1 -v1 -c {community} {host}')
        return None


def show_communities(raw=False):
    """
    Show all available SNMP communities
    
    Args:
        raw (bool): Whether to return structured data for GraphQL
    
    Returns:
        list: If raw is True, returns list of communities with their information
        None: If raw is False, prints to stdout
    """
    read_config()
    result = []
    
    if raw:
        communities = config['communities']
        for community in communities:
            result.append(show_community(community))
        return result
    else:
        show_all()
        return None


# SNMP ifmib section

def _show_ifindex(intf):
    """Get interface index"""
    out, err = popen(f'/bin/ip link show {intf}', decode='utf-8')
    index = 'ifIndex = ' + out.split(':')[0]
    return index.replace('\n', '')


def _show_ifalias(intf):
    """Get interface alias"""
    out, err = popen(f'/bin/ip link show {intf}', decode='utf-8')
    alias = out.split('alias')[1].lstrip() if 'alias' in out else intf
    return 'ifAlias = ' + alias.replace('\n', '')


def _show_ifdescr(i):
    """Get interface description"""
    ven_id = ''
    dev_id = ''

    try:
        with open(r'/sys/class/net/' + i + '/device/vendor', 'r') as f:
            ven_id = f.read().replace('\n', '')
    except FileNotFoundError:
        pass

    try:
        with open(r'/sys/class/net/' + i + '/device/device', 'r') as f:
            dev_id = f.read().replace('\n', '')
    except FileNotFoundError:
         pass

    if ven_id == '' and dev_id == '':
        ret = 'ifDescr = {0}'.format(i)
        return ret

    device = str(ven_id) + ':' + str(dev_id)
    out, err = popen(f'/usr/bin/lspci -mm -d {device}', decode='utf-8')

    vendor = ""
    device = ""

    # convert output to string
    string = out.split('"')
    if len(string) > 3:
        vendor = string[3]

    if len(string) > 5:
        device = string[5]

    ret = 'ifDescr = {0} {1}'.format(vendor, device)
    return ret.replace('\n', '')


def show_ifmib(raw=True):
    """
    Get SNMP interface MIB information for all interfaces
    
    Args:
        raw: If True, return raw string values. Otherwise, strip the labels.
        
    Returns:
        List of dictionaries containing interface MIB information
    """
    result = []
    
    for i in netifaces.interfaces():
        ifindex = _show_ifindex(i)
        ifalias = _show_ifalias(i)
        ifdescr = _show_ifdescr(i)
        
        if not raw:
            # Strip the labels if raw=False
            ifindex = ifindex.split('= ')[1] if '= ' in ifindex else ifindex
            ifalias = ifalias.split('= ')[1] if '= ' in ifalias else ifalias
            ifdescr = ifdescr.split('= ')[1] if '= ' in ifdescr else ifdescr
        
        info = {
            'interface': i,
            'if_index': ifindex,
            'if_alias': ifalias,
            'if_descr': ifdescr
        }
        result.append(info)
    
    return result


# SNMP V3 section

def get_snmp_v3_data():
    """
    Get SNMP v3 configuration data as structured data
    
    Returns:
        Dictionary containing all SNMP v3 data including groups, users, views, and trap targets
    """
    # Do nothing if service is not configured
    c = Config()
    if not c.exists_effective('service snmp v3'):
        return {"error": "SNMP v3 is not configured"}

    data = {
        'group': [],
        'trap': [],
        'user': [],
        'view': []
    }

    if c.exists_effective('service snmp v3 group'):
        for g in c.list_effective_nodes('service snmp v3 group'):
            group = {
                'name': g,
                'mode': '',
                'view': '',
                'seclevel': ''
            }
            group['mode'] = c.return_effective_value(f'service snmp v3 group {g} mode') or ''
            group['view'] = c.return_effective_value(f'service snmp v3 group {g} view') or ''
            group['seclevel'] = c.return_effective_value(f'service snmp v3 group {g} seclevel') or ''

            data['group'].append(group)

    if c.exists_effective('service snmp v3 user'):
        for u in c.list_effective_nodes('service snmp v3 user'):
            user = {
                'name': u,
                'mode': '',
                'auth': '',
                'priv': '',
                'group': ''
            }
            user['mode'] = c.return_effective_value(f'service snmp v3 user {u} mode') or ''
            user['auth'] = c.return_effective_value(f'service snmp v3 user {u} auth type') or ''
            user['priv'] = c.return_effective_value(f'service snmp v3 user {u} privacy type') or ''
            user['group'] = c.return_effective_value(f'service snmp v3 user {u} group') or ''

            data['user'].append(user)

    if c.exists_effective('service snmp v3 view'):
        for v in c.list_effective_nodes('service snmp v3 view'):
            view = {
                'name': v,
                'oids': []
            }
            view['oids'] = c.list_effective_nodes(f'service snmp v3 view {v} oid')

            data['view'].append(view)

    if c.exists_effective('service snmp v3 trap-target'):
        for t in c.list_effective_nodes('service snmp v3 trap-target'):
            trap = {
                'name': t,
                'port': '',
                'proto': '',
                'auth': '',
                'priv': '',
                'type': '',
                'eng_id': '',
                'user': ''
            }
            trap['port'] = c.return_effective_value(f'service snmp v3 trap-target {t} port') or ''
            trap['proto'] = c.return_effective_value(f'service snmp v3 trap-target {t} protocol') or ''
            trap['auth'] = c.return_effective_value(f'service snmp v3 trap-target {t} auth type') or ''
            trap['priv'] = c.return_effective_value(f'service snmp v3 trap-target {t} privacy type') or ''
            trap['type'] = c.return_effective_value(f'service snmp v3 trap-target {t} type') or ''
            trap['eng_id'] = c.return_effective_value(f'service snmp v3 trap-target {t} engineid') or ''
            trap['user'] = c.return_effective_value(f'service snmp v3 trap-target {t} user') or ''

            data['trap'].append(trap)
            
    # Add engineID if configured
    if c.exists_effective('service snmp v3 engineid'):
        data['engineid'] = c.return_effective_value('service snmp v3 engineid')
    
    return data


def show_snmp_v_3(raw=False):
    """
    Get complete SNMP v3 information for GraphQL API
    
    Args:
        raw (bool): If True, return raw data dictionary; False returns formatted text
    
    Returns:
        Dictionary or formatted string containing SNMP v3 data
    """
    data = get_snmp_v3_data()
    
    if isinstance(data, dict) and "error" in data:
        return data["error"] if not raw else data
    
    if raw:
        return {
            'group': data.get('group', []),
            'trap': data.get('trap', []),
            'user': data.get('user', []),
            'view': data.get('view', []),
            'engineid': data.get('engineid', '')
        }
    
    # Format and return all sections
    output = []
    
    tmpl = jinja2.Template(GROUP_OUTP_TMPL_SRC)
    output.append(tmpl.render(data))
    
    tmpl = jinja2.Template(TRAPTGT_OUTP_TMPL_SRC)
    output.append(tmpl.render(data))
    
    tmpl = jinja2.Template(USER_OUTP_TMPL_SRC)
    output.append(tmpl.render(data))
    
    tmpl = jinja2.Template(VIEW_OUTP_TMPL_SRC)
    output.append(tmpl.render(data))
        
    return "\n".join(output)


if __name__ == '__main__':
    # Setup argument parser
    parser = argparse.ArgumentParser(description='Retrieve information from running SNMP daemon')
    parser.add_argument('--allowed', action="store_true", help='Show available SNMP communities')
    parser.add_argument('--community', action="store", help='Show status of given SNMP community', type=str)
    parser.add_argument('--host', action="store", help='SNMP host to connect to', type=str, default='localhost')
    args = parser.parse_args()

    try:
        # Do nothing if service is not configured
        c = Config()
        if not c.exists_effective('service snmp'):
            print("SNMP service is not configured")
            sys.exit(0)

        read_config()

        if args.allowed:
            show_all()
            sys.exit(0)
        elif args.community:
            show_community(args.community, args.host, raw=False)
            sys.exit(0)
        else:
            parser.print_help()
            sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)