#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.

"""GraphQL mutation for generic iGOS first-time onboarding."""

import argparse
import os
import subprocess
import sys
import typing

import vyos.opmode

from vyos.config import Config
from vyos.configsession import ConfigSessionError


TIMEZONE_PATH = ['system', 'time-zone']
IGOS_PASSWORD_PATH = [
    'system',
    'login',
    'user',
    'igos',
    'authentication',
    'plaintext-password',
]
ENHANCED_POLICY_ROOT_PATH = [
    'system',
    'login',
    'enhanced-policy',
]
ENHANCED_POLICY_PATH = ENHANCED_POLICY_ROOT_PATH + [
    'password',
]
DEFAULT_MINIMUM_LENGTH = 9
DEFAULT_MINIMUM_UPPERCASE = 1
DEFAULT_MINIMUM_DIGIT = 1
DEFAULT_MINIMUM_SPECIAL = 1
CONFIG_BOOT_PATH = '/config/config.boot'


def _get_config_session():
    """Return the config session owned by the running VyOS API service."""
    from api.session import SessionState

    session = SessionState().session
    if session is None:
        raise ValueError('The VyOS API configuration session is unavailable.')
    return session


def _get_cli_config_session():
    """Create a configuration session for standalone CLI onboarding."""
    from vyos.configsession import ConfigSession

    return ConfigSession(os.getpid())


def _get_available_timezones() -> typing.Set[str]:
    """Return the timezones accepted during onboarding."""
    try:
        proc = subprocess.run(
            ['timedatectl', 'list-timezones', '--no-pager'],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise ValueError('Unable to retrieve the available timezones.') from exc

    if proc.returncode != 0:
        raise ValueError('Unable to retrieve the available timezones.')

    return {line.strip() for line in proc.stdout.splitlines() if line.strip()}


def _set_datetime(date_time: str) -> typing.Optional[str]:
    """Set the clock while keeping failures non-fatal for onboarding."""
    try:
        proc = subprocess.run(
            ['date', '-s', date_time],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except OSError:
        return 'Could not set the system clock.'

    if proc.returncode != 0:
        return 'Could not set the system clock.'
    return None


def _policy_value(value: typing.Optional[int], default: int, field_name: str) -> int:
    normalized = default if value is None else value
    if normalized < 0:
        raise ValueError(f'{field_name} must be a non-negative integer.')
    return normalized


def _validate_password(
    password: str,
    minimum_length: int,
    minimum_uppercase: int,
    minimum_digit: int,
    minimum_special: int,
) -> None:
    if not password:
        raise ValueError('Password cannot be empty.')

    failures = []
    if len(password) < minimum_length:
        failures.append(f'at least {minimum_length} characters')
    if sum('A' <= character <= 'Z' for character in password) < minimum_uppercase:
        failures.append(f'at least {minimum_uppercase} uppercase character(s)')
    if sum('0' <= character <= '9' for character in password) < minimum_digit:
        failures.append(f'at least {minimum_digit} digit character(s)')
    if sum(not character.isalnum() for character in password) < minimum_special:
        failures.append(f'at least {minimum_special} special character(s)')

    if failures:
        raise ValueError(
            'Password does not satisfy the enhanced policy: ' + ', '.join(failures) + '.'
        )


def _set_igos_onboarding(
    password: str,
    timezone: str,
    date_time: typing.Optional[str] = None,
    enhanced_policy: bool = False,
    minimum_length: typing.Optional[int] = None,
    minimum_uppercase: typing.Optional[int] = None,
    minimum_digit: typing.Optional[int] = None,
    minimum_special: typing.Optional[int] = None,
    raw: bool = True,
    session: typing.Any = None,
) -> dict:
    """Implement onboarding using an API-owned or standalone session."""
    config = Config()
    if config.exists_effective(TIMEZONE_PATH):
        current_timezone = config.return_effective_value(TIMEZONE_PATH)
        return {
            'success': True,
            'result': 'iGOS onboarding was already completed.',
            'already_completed': True,
            'saved': False,
            'username': 'igos',
            'timezone': current_timezone,
            'enhanced_policy': False,
            'clock_set': False,
            'warning': '',
        }

    normalized_timezone = str(timezone).strip() if timezone is not None else ''
    if not normalized_timezone or normalized_timezone not in _get_available_timezones():
        raise ValueError(f'Invalid timezone "{normalized_timezone}".')

    if not password:
        raise ValueError('Password cannot be empty.')

    policy = {}
    if enhanced_policy:
        policy = {
            'minimum-length': _policy_value(
                minimum_length, DEFAULT_MINIMUM_LENGTH, 'minimum_length'
            ),
            'minimum-uppercase': _policy_value(
                minimum_uppercase, DEFAULT_MINIMUM_UPPERCASE, 'minimum_uppercase'
            ),
            'minimum-digit': _policy_value(
                minimum_digit, DEFAULT_MINIMUM_DIGIT, 'minimum_digit'
            ),
            'minimum-special': _policy_value(
                minimum_special, DEFAULT_MINIMUM_SPECIAL, 'minimum_special'
            ),
        }
        _validate_password(
            password,
            policy['minimum-length'],
            policy['minimum-uppercase'],
            policy['minimum-digit'],
            policy['minimum-special'],
        )

    normalized_date_time = str(date_time).strip() if date_time is not None else ''
    warnings = []
    clock_set = False

    if session is None:
        session = _get_config_session()
    committed = False
    saved = False
    try:
        if not enhanced_policy and config.exists_effective(ENHANCED_POLICY_ROOT_PATH):
            session.delete(ENHANCED_POLICY_ROOT_PATH)
        session.set(TIMEZONE_PATH, normalized_timezone)
        if enhanced_policy:
            for setting, value in policy.items():
                session.set(ENHANCED_POLICY_PATH + [setting], str(value))
        session.set(IGOS_PASSWORD_PATH, password)
        session.commit()
        committed = True
        if normalized_date_time:
            clock_warning = _set_datetime(normalized_date_time)
            if clock_warning:
                warnings.append(clock_warning)
            else:
                clock_set = True
        session.save_config(CONFIG_BOOT_PATH)
        saved = True
    except ConfigSessionError as exc:
        if not committed:
            try:
                session.discard()
            except ConfigSessionError:
                pass
            raise ValueError(
                f'Unable to complete iGOS onboarding: {str(exc).strip()}'
            ) from exc
        warnings.append(
            'The onboarding configuration is active but could not be saved to '
            f'{CONFIG_BOOT_PATH}: {str(exc).strip()}'
        )

    result = {
        'success': True,
        'result': 'iGOS initial setup completed.',
        'already_completed': False,
        'saved': saved,
        'username': 'igos',
        'timezone': normalized_timezone,
        'enhanced_policy': enhanced_policy,
        'clock_set': clock_set,
        'warning': ' '.join(warnings),
    }

    if not raw:
        print(result)
    return result


def set_igos_onboarding(
    password: str,
    timezone: str,
    date_time: typing.Optional[str] = None,
    enhanced_policy: bool = False,
    minimum_length: typing.Optional[int] = None,
    minimum_uppercase: typing.Optional[int] = None,
    minimum_digit: typing.Optional[int] = None,
    minimum_special: typing.Optional[int] = None,
    raw: bool = True,
) -> dict:
    """Complete iGOS onboarding through the running VyOS API session."""
    return _set_igos_onboarding(
        password=password,
        timezone=timezone,
        date_time=date_time,
        enhanced_policy=enhanced_policy,
        minimum_length=minimum_length,
        minimum_uppercase=minimum_uppercase,
        minimum_digit=minimum_digit,
        minimum_special=minimum_special,
        raw=raw,
    )


def _run_cli_onboarding(
    arguments: typing.Optional[typing.Sequence[str]] = None,
    password_stream: typing.Optional[typing.TextIO] = None,
) -> dict:
    """Run onboarding for the login wizard using a standalone session."""
    parser = argparse.ArgumentParser(description='Apply iGOS CLI onboarding.')
    parser.add_argument('--timezone', required=True)
    parser.add_argument('--date-time')
    parser.add_argument('--enhanced-policy', action='store_true')
    parser.add_argument('--minimum-length', type=int)
    parser.add_argument('--minimum-uppercase', type=int)
    parser.add_argument('--minimum-digit', type=int)
    parser.add_argument('--minimum-special', type=int)
    parsed = parser.parse_args(arguments)

    stream = password_stream if password_stream is not None else sys.stdin
    password = stream.read()

    previous_umask = os.umask(0o002)
    try:
        session = _get_cli_config_session()
        try:
            result = _set_igos_onboarding(
                password=password,
                timezone=parsed.timezone,
                date_time=parsed.date_time,
                enhanced_policy=parsed.enhanced_policy,
                minimum_length=parsed.minimum_length,
                minimum_uppercase=parsed.minimum_uppercase,
                minimum_digit=parsed.minimum_digit,
                minimum_special=parsed.minimum_special,
                session=session,
            )
        finally:
            del session
    finally:
        os.umask(previous_umask)

    if result['warning']:
        print(f"  Warning: {result['warning']}")
    return result


if __name__ == '__main__':
    try:
        if sys.argv[1:2] == ['--cli']:
            _run_cli_onboarding(sys.argv[2:])
        else:
            response = vyos.opmode.run(sys.modules[__name__])
            if response:
                print(response)
    except (ValueError, ConfigSessionError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(1)
