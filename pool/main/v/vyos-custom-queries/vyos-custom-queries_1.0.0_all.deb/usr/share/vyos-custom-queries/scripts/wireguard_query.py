#!/usr/bin/env python3
#
# Copyright (C) 2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import json
import typing
from datetime import datetime

from vyos.ifconfig import WireGuardIf
from vyos.ifconfig import Section
from vyos.ifconfig import Interface
from vyos.configquery import ConfigTreeQuery
from vyos.utils.process import cmd
from vyos.opmode import Error, UnconfiguredSubsystem

import re

def parse_wireguard_show_interface(output):
    result = {}
    peers = []
    current_peer = None

    for line in output.splitlines():
        line = line.rstrip()
        # Top-level keys
        m = re.match(r'^interface: (.+)', line)
        if m:
            result['interface'] = m.group(1)
            continue
        m = re.match(r'^\s+description: (.+)', line)
        if m:
            result['description'] = m.group(1)
            continue
        m = re.match(r'^\s+address: (.+)', line)
        if m:
            result['address'] = m.group(1)
            continue
        m = re.match(r'^\s+public key: (.+)', line)
        if m:
            result['public_key'] = m.group(1)
            continue
        m = re.match(r'^\s+private key: (.+)', line)
        if m:
            result['private_key'] = m.group(1)
            continue
        m = re.match(r'^\s+listening port: (.+)', line)
        if m:
            result['listening_port'] = m.group(1)
            continue

        # Peer block
        m = re.match(r'^\s+peer: (.+)', line)
        if m:
            if current_peer:
                peers.append(current_peer)
            current_peer = {'peer': m.group(1)}
            continue
        if current_peer:
            m = re.match(r'^\s+public key: (.+)', line)
            if m:
                current_peer['public_key'] = m.group(1)
                continue
            m = re.match(r'^\s+latest handshake: (.+)', line)
            if m:
                current_peer['latest_handshake'] = m.group(1)
                continue
            m = re.match(r'^\s+status: (.+)', line)
            if m:
                current_peer['status'] = m.group(1)
                continue
            m = re.match(r'^\s+endpoint: (.+)', line)
            if m:
                current_peer['endpoint'] = m.group(1)
                continue
            m = re.match(r'^\s+allowed ips: (.+)', line)
            if m:
                current_peer['allowed_ips'] = [ip.strip() for ip in m.group(1).split(',')]
                continue
            m = re.match(r'^\s+transfer: (.+) received, (.+) sent', line)
            if m:
                current_peer['transfer_rx'] = m.group(1)
                current_peer['transfer_tx'] = m.group(2)
                continue
            m = re.match(r'^\s+persistent keepalive: every (.+) seconds', line)
            if m:
                current_peer['persistent_keepalive'] = m.group(1)
                continue

    if current_peer:
        peers.append(current_peer)
    if peers:
        result['peers'] = peers

    return result


def _verify_wireguard(func):
    """Decorator checks if WireGuard interface config exists"""
    from functools import wraps

    @wraps(func)
    def _wrapper(*args, **kwargs):
        config = ConfigTreeQuery()
        interface = kwargs.get('intf_name')
        if interface and not config.exists(['interfaces', 'wireguard', interface]):
            unconf_message = f'WireGuard interface {interface} is not configured'
            raise UnconfiguredSubsystem(unconf_message)
        return func(*args, **kwargs)

    return _wrapper


def _get_counter_val(prev, now):
    """
    attempt to correct a counter if it wrapped, copied from perl

    prev: previous counter
    now:  the current counter
    """
    # This function has to deal with both 32 and 64 bit counters
    if prev == 0:
        return now

    # device is using 64 bit values assume they never wrap
    value = now - prev
    if (now >> 32) != 0:
        return value

    # The counter has rolled.  If the counter has rolled
    # multiple times since the prev value, then this math
    # is meaningless.
    if value < 0:
        value = (4294967296 - prev) + now

    return value


def filtered_wireguard_interfaces(ifname=None):
    """
    Get all WireGuard interfaces or a specific one
    
    Args:
        ifname: Optional specific interface name
        
    Returns:
        Generator yielding Interface objects
    """
    for interface in Section.interfaces("wireguard"):
        if ifname and interface != ifname:
            continue
        yield Interface(interface, create=False, debug=False)


def get_wireguard_peer_data(intf_name: str):
    """
    Get peer information for a specific WireGuard interface
    
    Args:
        intf_name: WireGuard interface name
        
    Returns:
        List of peer data dictionaries
    """
    wg_if = WireGuardIf(intf_name, create=False, debug=False)
    return wg_if.operational.show_interface()


@_verify_wireguard
def show_wireguard_summary(raw: bool = True ,intf_name: typing.Optional[str] = None):
    """
    Get summary of WireGuard interface(s)
    
    Args:
        intf_name: Optional specific interface name
        
    Returns:
        Dictionary with interface information including peers
    """
    result = {}
    if raw: 
    
        if intf_name:
            # Get data for specific interface
            wg_if = WireGuardIf(intf_name, create=False, debug=False)
            result[intf_name] = wg_if.operational.show_interface()
        else:
            # Get data for all wireguard interfaces
            for interface in Section.interfaces("wireguard"):
                try:
                    wg_if = WireGuardIf(interface, create=False, debug=False)
                    result[interface] = wg_if.operational.show_interface()
                except Exception as e:
                    result[interface] = {"error": str(e)}
                
        return result


def show_wireguard_interfaces(raw: bool = True ,intf_name: typing.Optional[str] = None):
    """
    Get detailed interface information for WireGuard interface(s)
    
    Args:
        intf_name: Optional specific interface name
        
    Returns:
        List of interface information dictionaries
    """
    result = []
    if raw: 
    
        # Use specific interface if provided, otherwise all wireguard interfaces
        interfaces = [intf_name] if intf_name else None
    
        for interface in filtered_wireguard_interfaces(interfaces):
            intf_data = {}
            cache = interface.operational.load_counters()
        
            # Get detailed interface information using ip command
            out = cmd(f'ip -json addr show {interface.ifname}')
            ip_data = json.loads(out)[0]
        
            # Copy relevant information
            intf_data.update(ip_data)
        
            # Add timestamp of last counter clear
            intf_data['counters_last_clear'] = int(cache.get('timestamp', 0))
        
            # Add interface description/alias
            intf_data['description'] = interface.get_alias()
        
            # Add statistics with counter correction
            stats = interface.operational.get_stats()
            for k in list(stats):
                stats[k] = _get_counter_val(cache.get(k, 0), stats[k])
        
            intf_data['stats'] = stats
        
            # Add WireGuard specific information
            try:
                wg_if = WireGuardIf(interface.ifname, create=False, debug=False)
                output = wg_if.operational.show_interface()
                parsed = parse_wireguard_show_interface(output)
                intf_data['wireguard'] = parsed
            except Exception as e:
                intf_data['wireguard'] = {"error": str(e)}
        
            result.append(intf_data)
        
        return result


if __name__ == '__main__':
    try:
        import argparse
        
        parser = argparse.ArgumentParser(description='WireGuard interface utility')
        subparsers = parser.add_subparsers(dest='action')
        
        # Show summary subcommand
        summary_parser = subparsers.add_parser('summary', help='Show WireGuard summary')
        summary_parser.add_argument('--interface', type=str, help='Interface name')
        
        # Show details subcommand
        details_parser = subparsers.add_parser('details', help='Show WireGuard interface details')
        details_parser.add_argument('--interface', type=str, help='Interface name')
        
        args = parser.parse_args()
        
        if args.action == 'summary':
            result = show_wireguard_summary(args.interface)
            print(json.dumps(result, indent=2))
        elif args.action == 'details':
            result = show_wireguard_interfaces(args.interface)
            print(json.dumps(result, indent=2))
        else:
            parser.print_help()
            
    except Error as e:
        print(e)
        sys.exit(1)