#!/usr/bin/env python3
#
# Copyright (C) 2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
GraphQL mutation for restarting FRR routing daemons.

This mutation provides functionality equivalent to:
    echo y | sudo /usr/libexec/vyos/op_mode/restart_frr.py --action restart --daemon ospfd
    echo y | sudo /usr/libexec/vyos/op_mode/restart_frr.py --action restart --daemon ospf6d
    echo y | sudo /usr/libexec/vyos/op_mode/restart_frr.py --action restart --daemon ripd
    echo y | sudo /usr/libexec/vyos/op_mode/restart_frr.py --action restart --daemon ripngd
"""

import os
import sys
import logging

import psutil
import vyos.opmode

from logging.handlers import SysLogHandler
from shutil import rmtree
from vyos.base import Warning
from vyos.utils.file import makedir
from vyos.utils.process import call
from vyos.utils.process import process_named_running


SUPPORTED_DAEMONS = ('ospfd', 'ospf6d', 'ripd', 'ripngd')
WATCHFRR = '/usr/lib/frr/watchfrr.sh'
VTYSH = '/usr/bin/vtysh'
FRRCONFIG_TMP = '/tmp/frr_restart'


logger = logging.getLogger(__name__)
logs_handler = SysLogHandler('/dev/log')
logs_handler.setFormatter(logging.Formatter('%(filename)s: %(message)s'))
logger.addHandler(logs_handler)
logger.setLevel(logging.INFO)


def _check_safety() -> tuple[bool, list[str]]:
    """Run the same safety checks as restart_frr.py, auto-confirming all prompts."""
    warnings = []

    try:
        warnings.append(
            'WARNING: This is a potentially unsafe function! '
            'You may lose the connection to the router or active configuration after running this command.'
        )

        restart_processes = [
            process
            for process in psutil.process_iter(attrs=['pid', 'name', 'cmdline'])
            if process.info.get('name')
            and 'python' in process.info['name']
            and process.info.get('cmdline')
            and len(process.info['cmdline']) > 1
            and 'restart_frr.py' in process.info['cmdline'][1]
        ]
        if len(restart_processes) > 1:
            message = 'Another restart_frr.py process is already running! Proceeding anyway.'
            logger.warning(message)
            warnings.append(message)

        tmp = os.path.basename(WATCHFRR)
        if process_named_running(tmp):
            message = f'Another {tmp} process is already running. Proceeding anyway.'
            logger.warning(message)
            warnings.append(message)

        if process_named_running('vtysh'):
            message = 'vtysh process is executed by another task. Proceeding anyway.'
            logger.warning(message)
            warnings.append(message)

        if os.path.exists(FRRCONFIG_TMP):
            message = f'Temporary directory "{FRRCONFIG_TMP}" already exists. Proceeding anyway.'
            logger.warning(message)
            warnings.append(message)

    except Exception:
        logger.error('Something goes wrong in _check_safety()')
        return False, ['Something goes wrong in _check_safety()']

    return True, warnings


def _write_config() -> bool:
    makedir(FRRCONFIG_TMP)
    command = f'{VTYSH} -n -w --config_dir {FRRCONFIG_TMP} 2> /dev/null'
    return_code = call(command)
    if return_code != 0:
        logger.error(f'Failed to save active config: "{command}" returned exit code: {return_code}')
        return False
    logger.info(f'Active config saved to {FRRCONFIG_TMP}')
    return True


def _cleanup() -> None:
    if os.path.isdir(FRRCONFIG_TMP):
        rmtree(FRRCONFIG_TMP)


def _daemon_restart(daemon: str) -> bool:
    command = f'{WATCHFRR} restart {daemon}'
    return_code = call(command)
    if return_code != 0:
        logger.error(f'Failed to restart daemon "{daemon}"!')
        return False
    logger.info(f'Daemon "{daemon}" restarted!')
    return True


def _reload_config(daemon: str) -> bool:
    if daemon:
        command = f'{VTYSH} -n -b --config_dir {FRRCONFIG_TMP} -d {daemon}'
    else:
        command = f'{VTYSH} -n -b --config_dir {FRRCONFIG_TMP}'

    return_code = call(command)
    if return_code != 0:
        logger.error(f'Failed to re-install configuration for daemon "{daemon}": command "{command}" returned exit code {return_code}')
        return False

    logger.info(f'Configuration re-installed successfully for daemon "{daemon}"!')
    return True


def restart_frr(daemon: str) -> dict:
    """
    Restart an FRR daemon with non-interactive confirmation.

    Args:
        daemon (str): Supported values: ospfd, ospf6d, ripd, ripngd.

    Returns:
        dict: Structured result with success/error information.
    """
    if daemon not in SUPPORTED_DAEMONS:
        return {
            'success': False,
            'error': f'Invalid daemon "{daemon}". Valid daemons: {", ".join(SUPPORTED_DAEMONS)}',
            'daemon': daemon,
            'valid_daemons': list(SUPPORTED_DAEMONS),
        }

    safety_ok, warnings = _check_safety()
    if not safety_ok:
        return {
            'success': False,
            'daemon': daemon,
            'error': 'One of the safety checks failed.',
            'warnings': warnings,
        }

    try:
        if not _write_config():
            return {
                'success': False,
                'daemon': daemon,
                'error': 'Failed to save active config',
                'warnings': warnings,
            }

        if not process_named_running(daemon):
            Warning('some of listed daemons are not running!')
            warnings.append(f'Daemon "{daemon}" was not running before restart.')

        if not _daemon_restart(daemon):
            return {
                'success': False,
                'daemon': daemon,
                'error': f'Failed to restart daemon: {daemon}',
                'warnings': warnings,
            }

        reload_ok = _reload_config(daemon)

        result = {
            'success': reload_ok,
            'daemon': daemon,
            'result': f'Restarted daemon: {daemon}',
            'config_reloaded': reload_ok,
            'warnings': warnings,
        }

        if not reload_ok:
            result['error'] = 'Failed to re-install configuration!'

        return result
    finally:
        _cleanup()


def restart_frr_ospfd() -> dict:
    """Equivalent to: echo y | sudo ... --daemon ospfd"""
    return restart_frr('ospfd')


def restart_frr_ospf_6_d() -> dict:
    """Equivalent to: echo y | sudo ... --daemon ospf6d"""
    return restart_frr('ospf6d')


def restart_frr_ripd() -> dict:
    """Equivalent to: echo y | sudo ... --daemon ripd"""
    return restart_frr('ripd')


def restart_frr_ripngd() -> dict:
    """Equivalent to: echo y | sudo ... --daemon ripngd"""
    return restart_frr('ripngd')


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
