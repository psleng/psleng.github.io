#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.

"""GraphQL-friendly IPv6 routing-table queries via vtysh JSON commands.

Supported keywords and commands:
    all        -> show ipv6 route json
    bgp        -> show ipv6 route bgp json
    connected  -> show ipv6 route connected json
    kernel     -> show ipv6 route kernel json
    ospf6      -> show ipv6 route ospf6 json
    ripng      -> show ipv6 route ripng json
    static     -> show ipv6 route static json
    summary    -> show ipv6 route summary json
    table-all  -> show ipv6 route table all json
    vrf        -> show ipv6 route vrf <vrf-name> json
"""

import json
import re
import sys
import typing

import vyos.opmode
from vyos.utils.process import rc_cmd


ROUTING_KEYWORD_TO_COMMAND = {
    'all': 'show ipv6 route json',
    'bgp': 'show ipv6 route bgp json',
    'connected': 'show ipv6 route connected json',
    'kernel': 'show ipv6 route kernel json',
    'ospf6': 'show ipv6 route ospf6 json',
    'ripng': 'show ipv6 route ripng json',
    'static': 'show ipv6 route static json',
    'summary': 'show ipv6 route summary json',
    'table-all': 'show ipv6 route table all json',
}
VRF_NAME_PATTERN = re.compile(r'^[A-Za-z0-9_.:-]+$')


def _build_routing_command(
    command_keyword: typing.Optional[str],
    vrf_name: typing.Optional[str] = None,
) -> str:
    normalized_vrf = str(vrf_name).strip() if vrf_name is not None else ''
    default_keyword = 'vrf' if normalized_vrf else 'all'
    keyword = (command_keyword or default_keyword).strip().lower().replace('_', '-')

    if keyword == 'vrf':
        if not normalized_vrf:
            raise vyos.opmode.Error('vrf_name is required for the vrf routing query.')
        if not VRF_NAME_PATTERN.fullmatch(normalized_vrf):
            raise vyos.opmode.Error(f'Invalid VRF name: {vrf_name}.')
        return f'show ipv6 route vrf {normalized_vrf} json'

    if normalized_vrf:
        raise vyos.opmode.Error('vrf_name is only valid for the vrf routing query.')

    if keyword not in ROUTING_KEYWORD_TO_COMMAND:
        valid = ', '.join(sorted([*ROUTING_KEYWORD_TO_COMMAND, 'vrf']))
        raise vyos.opmode.Error(
            f'Invalid IPv6 routing-table keyword: {command_keyword}. '
            f'Valid values: {valid}'
        )

    return ROUTING_KEYWORD_TO_COMMAND[keyword]


def _run_vtysh_routing_json(
    command_keyword: typing.Optional[str] = None,
    vrf_name: typing.Optional[str] = None,
):
    routing_command = _build_routing_command(command_keyword, vrf_name)
    command_attempts = [
        f"/usr/bin/vtysh -c '{routing_command}'",
        f"/usr/sbin/vtysh -c '{routing_command}'",
        f"vtysh -c '{routing_command}'",
    ]

    output = None
    errors = []
    for command_line in command_attempts:
        rc, command_output = rc_cmd(command_line)
        if rc == 0:
            output = (command_output or '').strip()
            if not output:
                return {}
            break
        if command_output:
            errors.append(command_output.strip())

    if output is None:
        detail = f" Details: {' | '.join(errors)}" if errors else ''
        raise vyos.opmode.Error(
            f'Failed to query IPv6 routing-table data from vtysh.{detail}'
        )

    try:
        return json.loads(output)
    except json.JSONDecodeError as exc:
        raise vyos.opmode.Error(
            f'Failed to parse IPv6 routing-table JSON output: {str(exc)}'
        ) from exc


def show_routing_table(
    raw: bool = True,
    keyword: typing.Optional[str] = None,
    vrf_name: typing.Optional[str] = None,
):
    """Return the selected IPv6 vtysh routing-table JSON result directly.

    Omitting keyword returns ``show ipv6 route json``. Supplying only vrf_name
    automatically selects the VRF query.
    """
    return _run_vtysh_routing_json(keyword, vrf_name)


if __name__ == '__main__':
    try:
        result = vyos.opmode.run(sys.modules[__name__])
        if result:
            print(result)
    except (ValueError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(1)
