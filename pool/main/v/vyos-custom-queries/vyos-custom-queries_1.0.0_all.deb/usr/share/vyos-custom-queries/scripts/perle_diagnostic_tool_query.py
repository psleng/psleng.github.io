#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL query helpers for diagnostic tools."""

import subprocess
import sys
import typing

import vyos.opmode


def _normalize_ping_family(ping_type: str) -> str:
    """Map GraphQL ping type input to ping command family flag."""
    value = str(ping_type).strip().lower()

    if value in {'ipv4', 'ip4', '4', '-4', 'inet'}:
        return '-4'

    if value in {'ipv6', 'ip6', '6', '-6', 'inet6'}:
        return '-6'

    raise ValueError(
        'Invalid ping type. Use one of: IPv4, IPv6, 4, 6, inet, inet6.'
    )


def _normalize_ping_count(number_of_ping: typing.Union[int, str]) -> int:
    """Validate and normalize ping count."""
    try:
        count = int(number_of_ping)
    except (TypeError, ValueError) as exc:
        raise ValueError('Ping count must be an integer value.') from exc

    if count < 1 or count > 100:
        raise ValueError('Ping count must be between 1 and 100.')

    return count


def _normalize_traceroute_command(traceroute_type: str) -> str:
    """Map GraphQL traceroute type input to the correct Linux command."""
    value = str(traceroute_type).strip().lower()

    if value in {'ipv4', 'ip4', '4', '-4', 'inet'}:
        return 'traceroute'

    if value in {'ipv6', 'ip6', '6', '-6', 'inet6'}:
        return 'traceroute6'

    raise ValueError(
        'Invalid traceroute type. Use one of: IPv4, IPv6, 4, 6, inet, inet6.'
    )


def show_ping(
    raw: bool,
    ping_type: str,
    number_of_ping: typing.Union[int, str],
    target: str,
) -> dict:
    """Run Linux ping with IPv4/IPv6 family and return command output.

    Equivalent command:
        ping <-4|-6> -i 0.1 -c <number-of-ping> <target>
    """
    normalized_target = str(target).strip()
    if not normalized_target:
        raise ValueError('Target hostname or IP address is required.')

    family_flag = _normalize_ping_family(ping_type)
    count = _normalize_ping_count(number_of_ping)

    cmd = [
        'ping',
        family_flag,
        '-i',
        '0.1',
        '-c',
        str(count),
        normalized_target,
    ]

    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)

    cli_output = '\n'.join(
        part
        for part in [
            (proc.stdout or '').strip(),
            (proc.stderr or '').strip(),
        ]
        if part
    )

    result = {
        'success': proc.returncode == 0,
        'result': 'Ping completed successfully.' if proc.returncode == 0 else 'Ping command failed.',
        'command': ' '.join(cmd),
        'ping_type': 'IPv4' if family_flag == '-4' else 'IPv6',
        'number_of_ping': count,
        'target': normalized_target,
        'return_code': proc.returncode,
        'cli_output': cli_output,
    }

    if not raw:
        print(result)

    return result


def show_traceroute(
    raw: bool,
    traceroute_type: str,
    target: str,
) -> dict:
    """Run Linux traceroute/traceroute6 and return command output.

    Equivalent commands:
        traceroute <ipv4-address-or-hostname>
        traceroute6 <ipv6-address-or-hostname>
    """
    normalized_target = str(target).strip()
    if not normalized_target:
        raise ValueError('Target hostname or IP address is required.')

    traceroute_command = _normalize_traceroute_command(traceroute_type)
    cmd = [traceroute_command, normalized_target]

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except OSError as exc:
        raise vyos.opmode.Error(f'Failed to execute traceroute command: {str(exc)}') from exc

    cli_output = '\n'.join(
        part
        for part in [
            (proc.stdout or '').strip(),
            (proc.stderr or '').strip(),
        ]
        if part
    )

    result = {
        'success': proc.returncode == 0,
        'result': 'Traceroute completed successfully.' if proc.returncode == 0 else 'Traceroute command failed.',
        'command': ' '.join(cmd),
        'traceroute_type': 'IPv4' if traceroute_command == 'traceroute' else 'IPv6',
        'target': normalized_target,
        'return_code': proc.returncode,
        'cli_output': cli_output,
    }

    if not raw:
        print(result)

    return result


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as exc:
        print(exc)
        sys.exit(1)
