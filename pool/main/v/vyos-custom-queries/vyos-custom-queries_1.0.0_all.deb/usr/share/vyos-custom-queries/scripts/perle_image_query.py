#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL-friendly query for VyOS system images.

Supported commands:
  - show system image
  - show system image details
"""

import re
import sys
import typing

import vyos.opmode
from vyos.utils.process import rc_cmd


_IMAGE_COMMAND = 'show system image'
_IMAGE_DETAILS_COMMAND = 'show system image details'


def _to_snake_case(header: str) -> str:
    key = header.strip().lower()
    key = re.sub(r'[^a-z0-9]+', '_', key)
    return key.strip('_')


def _parse_table(output: str) -> typing.List[typing.Dict[str, str]]:
    lines = [line.rstrip() for line in output.splitlines() if line.strip()]
    if len(lines) < 2:
        return []

    separator_idx = None
    for idx, line in enumerate(lines):
        if re.fullmatch(r'[\s\-]+', line):
            separator_idx = idx
            break

    if separator_idx is None or separator_idx == 0:
        return []

    header_line = lines[separator_idx - 1]
    data_lines = lines[separator_idx + 1 :]
    headers = [h.strip() for h in re.split(r'\s{2,}', header_line.strip()) if h.strip()]
    if not headers:
        return []

    normalized_headers = [_to_snake_case(h) for h in headers]

    rows: typing.List[typing.Dict[str, str]] = []
    for line in data_lines:
        parts = [p.strip() for p in re.split(r'\s{2,}', line.strip())]
        if len(parts) < len(normalized_headers):
            parts.extend([''] * (len(normalized_headers) - len(parts)))
        elif len(parts) > len(normalized_headers):
            parts = parts[: len(normalized_headers)]

        row = {
            normalized_headers[i]: parts[i]
            for i in range(len(normalized_headers))
        }
        rows.append(row)

    return rows


def _run_show_command(command: str) -> typing.List[typing.Dict[str, str]]:
    cmd = f'/opt/vyatta/bin/vyatta-op-cmd-wrapper {command}'
    rc, output = rc_cmd(cmd)
    if rc != 0:
        raise vyos.opmode.Error(f'Failed to run command: {command}')

    if not output:
        return []

    return _parse_table(output)


def _decorate_summary_rows(rows: typing.List[typing.Dict[str, str]]) -> typing.List[typing.Dict[str, typing.Any]]:
    result: typing.List[typing.Dict[str, typing.Any]] = []
    for row in rows:
        default_boot = row.get('default_boot', '')
        running = row.get('running', '')
        result.append(
            {
                'name': row.get('name', ''),
                'default_boot': default_boot,
                'running': running,
                'is_default_boot': default_boot.lower() == 'yes',
                'is_running': running.lower() == 'yes',
            }
        )
    return result


def show_system_image(raw: bool = True, details: bool = False):
    """Show system image information.

    When details is False, runs `show system image`.
    When details is True, runs `show system image details`.
    """
    command = _IMAGE_DETAILS_COMMAND if details else _IMAGE_COMMAND
    rows = _run_show_command(command)

    if details:
        return rows

    return _decorate_summary_rows(rows)


def show_system_image_details(raw: bool = True):
    """Show detailed system image information."""
    return show_system_image(raw=raw, details=True)


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
