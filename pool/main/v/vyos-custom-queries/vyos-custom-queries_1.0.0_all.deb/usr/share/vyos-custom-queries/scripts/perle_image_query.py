#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL-friendly query for VyOS system images.

Supported commands:
  - show system image
  - show system image details
"""

import importlib.util
import sys

import vyos.opmode


IMAGE_INFO_PATH = '/usr/libexec/vyos/op_mode/image_info.py'


def _load_image_info_module():
    spec = importlib.util.spec_from_file_location('vyos_image_info', IMAGE_INFO_PATH)
    if spec is None or spec.loader is None:
        raise vyos.opmode.Error(f'Unable to load image info module: {IMAGE_INFO_PATH}')

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def show_system_image(raw: bool = True, details: bool = False):
    """Show system image information.

    Returns `images_summary` from image_info.show_images_summary(raw=True)
    or `images_details` from image_info.show_images_details(raw=True).
    """
    _ = raw
    image_info = _load_image_info_module()

    if details:
        if not hasattr(image_info, 'show_images_details'):
            raise vyos.opmode.Error('show_images_details not found in image_info module')
        image_details = image_info.show_images_details(raw=True)
        return image_details

    if not hasattr(image_info, 'show_images_summary'):
        raise vyos.opmode.Error('show_images_summary not found in image_info module')
    image_summary = image_info.show_images_summary(raw=True)
    return image_summary


def show_system_image_details(raw: bool = True):
    """Return `images_details` from image_info.show_images_details(raw=True)."""
    _ = raw
    image_info = _load_image_info_module()
    if not hasattr(image_info, 'show_images_details'):
        raise vyos.opmode.Error('show_images_details not found in image_info module')
    image_details = image_info.show_images_details(raw=True)
    return image_details


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
