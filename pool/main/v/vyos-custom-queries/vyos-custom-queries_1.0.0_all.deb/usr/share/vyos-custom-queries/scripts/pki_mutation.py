import os
import typing
from vyos.pki import (
    encode_certificate,
    encode_private_key,
    create_certificate,
    create_certificate_request,
    create_private_key,
    load_certificate,
    load_private_key,
    create_certificate_revocation_list,
    create_dh_parameters,
    encode_dh_parameters,
    encode_public_key,
)
from vyos.config import Config
from vyos.utils.misc import install_into_config

auth_dir = '/config/auth'
conf = Config()

# Utility functions
def write_file(filename, contents):
    full_path = os.path.join(auth_dir, filename)
    directory = os.path.dirname(full_path)
    if not os.path.exists(directory):
        print('Failed to write file: directory does not exist')
        return False
    with open(full_path, 'w') as f:
        f.write(contents)
    print(f'File written to {full_path}')

# Install functions
def install_certificate(
    name, cert='', private_key=None, key_type=None, key_passphrase=None, is_ca=False
):
    prefix = 'ca' if is_ca else 'certificate'
    base = f'pki {prefix} {name}'
    config_paths = []
    if cert:
        cert_pem = encode_certificate(cert).replace('\n', '')
        config_paths.append(f"{base} certificate '{cert_pem}'")
    if private_key:
        key_pem = encode_private_key(private_key, passphrase=key_passphrase).replace('\n', '')
        config_paths.append(f"{base} private key '{key_pem}'")
        if key_passphrase:
            config_paths.append(f"{base} private password-protected")
    install_into_config(conf, config_paths)
    
def install_crl(ca_name, crl):
    crl_pem = ''.join(encode_certificate(crl).strip().split('\n')[1:-1])
    install_into_config(conf, [f"pki ca {ca_name} crl '{crl_pem}'"])

def install_dh_parameters(name, params):
    dh_pem = ''.join(encode_dh_parameters(params).strip().split('\n')[1:-1])
    install_into_config(conf, [f"pki dh {name} parameters '{dh_pem}'"])

# Config fetch functions
def get_config_ca_certificate(name=None):
    base = ['pki', 'ca']
    if not conf.exists(base):
        return False
    if name:
        base = base + [name]
        if not conf.exists(base + ['private', 'key']) or not conf.exists(
            base + ['certificate']
        ):
            return False
    return conf.get_config_dict(
        base, key_mangling=('-', '_'), get_first_key=True, no_tag_node_value_mangle=True
    )

def get_config_revoked_certificates():
    ca_base = ['pki', 'ca']
    cert_base = ['pki', 'certificate']
    certs = []
    if conf.exists(ca_base):
        ca_certificates = conf.get_config_dict(
            ca_base,
            key_mangling=('-', '_'),
            get_first_key=True,
            no_tag_node_value_mangle=True,
        )
        certs.extend(ca_certificates.values())
    if conf.exists(cert_base):
        certificates = conf.get_config_dict(
            cert_base,
            key_mangling=('-', '_'),
            get_first_key=True,
            no_tag_node_value_mangle=True,
        )
        certs.extend(certificates.values())
    return [cert_dict for cert_dict in certs if 'revoke' in cert_dict]

def generate_pki_ca(
    key_type: str,
    key_bit: int,
    country_code: str,
    state: str,
    locality: str,
    org_name: str,
    com_name: str,
    valid_days: int,
    passphrase: str = None,
    name: str = None,
    install: bool = False,
    file: bool = False,
    encrypt_key: bool = False,
):
    private_key = create_private_key(key_type, key_bit)
    subject = {
        'country': country_code,
        'state': state,
        'locality': locality,
        'organization': org_name,
        'common_name': com_name,
    }
    cert_req = create_certificate_request(subject, private_key, subject_alt_names=None)
    cert = create_certificate(
        cert_req, cert_req, private_key, valid_days, cert_type=None, is_ca=True, is_sub_ca=False
    )
    key_pass = passphrase if encrypt_key else None
    cert_pem = encode_certificate(cert)
    key_pem = encode_private_key(private_key, passphrase=key_pass)
    if not install and not file:
        # Remove newlines before returning
        return cert_pem.replace('\n', ''), key_pem.replace('\n', '')
    if install:
        if not name:
            raise ValueError("Name is required for install")
        install_certificate(
            name, cert, private_key, key_type, key_passphrase=key_pass, is_ca=True
        )
    if file:
        if not name:
            raise ValueError("Name is required for file output")
        write_file(f'{name}.pem', cert_pem)
        write_file(f'{name}.key', key_pem)
    # Remove newlines before returning
    return cert_pem.replace('\n', ''), key_pem.replace('\n', '')

def generate_pki_certificate(
    key_type: str,
    key_bit: int,
    country_code: str,
    state: str,
    locality: str,
    org_name: str,
    com_name: str,
    valid_days: int,
    passphrase: str = None,
    subject_alt_names: typing.Optional[list] = None,
    name: str = None,
    install: bool = False,
    file: bool = False,
    self_sign: bool = False,
    ca_name: str = None,
    encrypt_key: bool = False,
):
    private_key = create_private_key(key_type, key_bit)
    subject = {
        'country': country_code,
        'state': state,
        'locality': locality,
        'organization': org_name,
        'common_name': com_name,
    }
    cert_req = create_certificate_request(subject, private_key, subject_alt_names)
    if self_sign:
        cert = create_certificate(
            cert_req, cert_req, private_key, valid_days, cert_type=None, is_ca=False, is_sub_ca=False
        )
    elif ca_name:
        ca_dict = get_config_ca_certificate(ca_name)
        if not ca_dict or 'certificate' not in ca_dict or 'private' not in ca_dict:
            raise ValueError(f"CA certificate or private key for '{ca_name}' not found")
        ca_cert = load_certificate(ca_dict['certificate'])
        ca_private = ca_dict['private']
        ca_private_passphrase = None
        if 'password_protected' in ca_private:
            ca_private_passphrase = passphrase  # Or pass as argument if needed
        ca_private_key = load_private_key(
            ca_private['key'], passphrase=ca_private_passphrase
        )
        cert = create_certificate(
            cert_req, ca_cert, ca_private_key, valid_days, cert_type=None, is_ca=False, is_sub_ca=False
        )
    else:
        cert = None
    key_pass = passphrase if encrypt_key else None
    cert_pem = encode_certificate(cert) if cert else None
    key_pem = encode_private_key(private_key, passphrase=key_pass)
    if not install and not file:
        # Remove newlines before returning
        cert_result = cert_pem.replace('\n', '') if cert_pem else None
        return cert_result, key_pem.replace('\n', '')
    if install:
        if not name:
            raise ValueError("Name is required for install")
        install_certificate(
            name, cert, private_key, key_type, key_passphrase=key_pass, is_ca=False
        )
    if file:
        if not name:
            raise ValueError("Name is required for file output")
        if cert:
            write_file(f'{name}.pem', cert_pem)
        write_file(f'{name}.key', key_pem)
    # Remove newlines before returning
    cert_result = cert_pem.replace('\n', '') if cert_pem else None
    return cert_result, key_pem.replace('\n', '')

def generate_pki_crl(
    ca_name: str,
    install: bool = False,
    file: bool = False,
):
    ca_dict = get_config_ca_certificate(ca_name)
    if not ca_dict or 'certificate' not in ca_dict or 'private' not in ca_dict:
        raise ValueError(f"CA certificate or private key for '{ca_name}' not found")
    ca_cert = load_certificate(ca_dict['certificate'])
    ca_private = ca_dict['private']
    ca_private_passphrase = None
    if 'password_protected' in ca_private:
        ca_private_passphrase = None  # Set passphrase if needed
    ca_private_key = load_private_key(
        ca_private['key'], passphrase=ca_private_passphrase
    )
    revoked_certs = get_config_revoked_certificates()
    to_revoke = []
    for cert_dict in revoked_certs:
        if 'certificate' not in cert_dict:
            continue
        cert_data = cert_dict['certificate']
        try:
            cert = load_certificate(cert_data)
            if cert.issuer == ca_cert.subject:
                to_revoke.append(cert.serial_number)
        except ValueError:
            continue
    if not to_revoke:
        print('No revoked certificates to add to the CRL')
        return None
    crl = create_certificate_revocation_list(ca_cert, ca_private_key, to_revoke)
    if not crl:
        print('Failed to create CRL')
        return None
    crl_pem = encode_certificate(crl)
    if not install and not file:
        # Remove newlines before returning
        return crl_pem.replace('\n', '')
    if install:
        install_crl(ca_name, crl)
    if file:
        write_file(f'{ca_name}.crl', crl_pem)
    # Remove newlines before returning
    return crl_pem.replace('\n', '')

def generate_pki_dh(
    key_bit: int,
    name: str = None,
    install: bool = False,
    file: bool = False,
):
    dh_params = create_dh_parameters(key_bit)
    if not dh_params:
        print('Failed to create DH parameters')
        return None

    dh_pem = encode_dh_parameters(dh_params)
    if not install and not file:
        # Remove newlines before returning
        return dh_pem.replace('\n', '')

    if install:
        if not name:
            raise ValueError("Name is required for install")
        install_dh_parameters(name, dh_params)

    if file:
        if not name:
            raise ValueError("Name is required for file output")
        write_file(f'{name}.pem', dh_pem)

    # Remove newlines before returning
    return dh_pem.replace('\n', '')

def generate_pki_key_pair(
    key_type: str,
    key_bit: int,
    name: str = None,
    passphrase: str = None,
    install: bool = False,
    file: bool = False,
    encrypt_key: bool = False,
):
    private_key = create_private_key(key_type, key_bit)
    public_key = private_key.public_key()

    key_pass = passphrase if encrypt_key else None
    public_key_pem = encode_public_key(public_key)
    private_key_pem = encode_private_key(private_key, passphrase=key_pass)

    if not install and not file:
        # Remove newlines before returning
        return {
            "public_key": public_key_pem.replace('\n', ''),
            "private_key": private_key_pem.replace('\n', '')
        }

    if install:
        if not name:
            raise ValueError("Name is required for install")
        install_into_config(
            conf,
            [
                f"pki key-pair {name} public key '{''.join(public_key_pem.strip().splitlines()[1:-1])}'",
                f"pki key-pair {name} private key '{''.join(private_key_pem.strip().splitlines()[1:-1])}'"
                + (f"\npki key-pair {name} private password-protected" if key_pass else "")
            ]
        )

    if file:
        if not name:
            raise ValueError("Name is required for file output")
        write_file(f'{name}.pem', public_key_pem)
        write_file(f'{name}.key', private_key_pem)

    # Remove newlines before returning
    return {
        "public_key": public_key_pem.replace('\n', ''),
        "private_key": private_key_pem.replace('\n', '')
    }