#!/usr/bin/env python3
#
# Copyright (C) 2026 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""GraphQL mutation for `add system image <url or local path>`.

This mutation routes to the same backend logic as the CLI add-image command by
loading and calling the VyOS image installer module. Interactive prompts can be
controlled via optional GraphQL parameters.
"""

import importlib.util
import io
from contextlib import redirect_stderr, redirect_stdout
import json
import re
import subprocess
import sys
import typing
import traceback

import vyos.opmode


IMAGE_INSTALLER_PATH = '/usr/libexec/vyos/op_mode/image_installer.py'


def _normalize_optional_string(value: typing.Any) -> typing.Optional[str]:
    """Treat missing/blank GraphQL string values as None."""
    if value is None:
        return None
    text = str(value).strip()
    return text if text else None


def _normalize_optional_bool(value: typing.Any) -> typing.Optional[bool]:
    """Treat missing/blank GraphQL boolean values as None."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text == '':
        return None
    if text in {'true', '1', 'yes', 'y'}:
        return True
    if text in {'false', '0', 'no', 'n'}:
        return False
    return bool(value)


def _normalize_required_bool(value: typing.Any, field_name: str) -> bool:
    """Require explicit GraphQL boolean values for interactive controls."""
    normalized = _normalize_optional_bool(value)
    if normalized is None:
        raise ValueError(f'Parameter "{field_name}" is required and must be true or false.')
    return bool(normalized)


def _build_failure_message(reason: str, context: dict, exc: typing.Optional[BaseException] = None) -> str:
    """Build a detailed, GraphQL-friendly error message.

    Keep context focused on non-sensitive fields only.
    """
    details = [reason]
    details.append(
        'context='
        + ', '.join(f'{key}={value!r}' for key, value in context.items())
    )

    if exc is not None:
        details.append(f'error_type={exc.__class__.__name__}')
        details.append(f'error_message={exc}')
        tb = ''.join(traceback.format_exception_only(type(exc), exc)).strip()
        if tb:
            details.append(f'exception={tb}')

    return '; '.join(details)


def _build_error_payload(
    reason: str,
    exc: BaseException,
    location: str,
    no_prompt: bool,
    context: dict,
    error_message: typing.Optional[str] = None,
    exception_text: typing.Optional[str] = None,
) -> dict:
    """Build a detailed error payload for GraphQL response.
    
    Returns a dict with success=false and detailed error information including
    error type, message, and full context.
    """
    error_type = exc.__class__.__name__ if exc else 'Unknown'
    resolved_error_message = error_message if error_message is not None else (str(exc) if exc else reason)
    tb = exception_text if exception_text is not None else (
        ''.join(traceback.format_exception_only(type(exc), exc)).strip() if exc else ''
    )
    
    return {
        'success': False,
        'result': reason,
        'error_type': error_type,
        'error_message': resolved_error_message,
        'exception': tb if tb else resolved_error_message,
        'location': location,
        'no_prompt': bool(no_prompt),
        'context': context,
    }


def _extract_cli_error_message(output: str, fallback: str) -> str:
    """Extract the most user-friendly CLI error message from command output."""
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if not lines:
        return fallback

    for line in reversed(lines):
        line_lower = line.lower()
        if 'already an installed image by that name' in line_lower:
            return line

    for line in reversed(lines):
        if line.startswith('Error:'):
            return line

    return lines[-1] if lines[-1] else fallback


def _raise_graphql_payload_error(payload: dict) -> typing.NoReturn:
    """Raise a resolver error with serialized payload for GraphQL errors field."""
    # In some GraphQL wrappers, ValueError message is propagated to `errors`
    # while vyos.opmode.Error is reduced to a generic failure.
    raise ValueError(json.dumps(payload, ensure_ascii=False))


def _load_image_installer_module():
    spec = importlib.util.spec_from_file_location('vyos_image_installer', IMAGE_INSTALLER_PATH)
    if spec is None or spec.loader is None:
        raise vyos.opmode.Error(f'Unable to load image installer: {IMAGE_INSTALLER_PATH}')

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _get_installed_image_names() -> typing.Set[str]:
    """Return installed system image names from `show system image`."""
    cmd = ['/opt/vyatta/bin/vyatta-op-cmd-wrapper', 'show', 'system', 'image']
    try:
        proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    except Exception:
        return set()

    if proc.returncode != 0 or not proc.stdout:
        return set()

    lines = [line.rstrip() for line in proc.stdout.splitlines() if line.strip()]
    # Expected table format:
    # Name    Default boot    Running
    # ----    ------------    -------
    # <rows>
    separator_idx = None
    for idx, line in enumerate(lines):
        if re.fullmatch(r'[\s\-]+', line):
            separator_idx = idx
            break

    if separator_idx is None:
        return set()

    data_lines = lines[separator_idx + 1 :]
    names = set()
    for line in data_lines:
        parts = [p.strip() for p in re.split(r'\s{2,}', line.strip()) if p.strip()]
        if parts:
            names.add(parts[0])

    return names


def add_system_image(
    location: str,
    vrf: typing.Optional[str] = None,
    username: str = '',
    password: str = '',
    no_prompt: bool = False,
    force: bool = False,
    image_name: typing.Optional[str] = None,
    *,
    set_as_default: bool,
    proceed_unsaved_commits: bool,
    proceed_without_signature: bool,
    copy_config: bool,
    copy_ssh_host_keys: bool,
    copy_ssh_known_hosts: bool,
    raw: bool = True,
) -> dict:
    """Add a new system image via the same backend as CLI add-image.

    Parameters map to image installer prompts where possible.
    """
    if not location or not location.strip():
        payload = {
            'success': False,
            'result': 'Error: Image location is required.',
            'error_type': 'ValueError',
            'error_message': 'Parameter "location" is required.',
            'exception': 'ValueError: Parameter "location" is required.',
            'location': location,
            'no_prompt': bool(no_prompt),
        }
        _raise_graphql_payload_error(payload)

    normalized_vrf = _normalize_optional_string(vrf)
    normalized_username = _normalize_optional_string(username) or ''
    normalized_password = _normalize_optional_string(password) or ''
    normalized_image_name = _normalize_optional_string(image_name)
    try:
        normalized_set_as_default = _normalize_required_bool(set_as_default, 'set_as_default')
        normalized_proceed_unsaved_commits = _normalize_required_bool(
            proceed_unsaved_commits, 'proceed_unsaved_commits'
        )
        normalized_proceed_without_signature = _normalize_required_bool(
            proceed_without_signature, 'proceed_without_signature'
        )
        normalized_copy_config = _normalize_required_bool(copy_config, 'copy_config')
        normalized_copy_ssh_host_keys = _normalize_required_bool(
            copy_ssh_host_keys, 'copy_ssh_host_keys'
        )
        normalized_copy_ssh_known_hosts = _normalize_required_bool(
            copy_ssh_known_hosts, 'copy_ssh_known_hosts'
        )
    except ValueError as e:
        payload = {
            'success': False,
            'result': str(e),
            'error_type': 'ValueError',
            'error_message': str(e),
            'exception': f'ValueError: {e}',
            'location': location,
            'no_prompt': bool(no_prompt),
        }
        _raise_graphql_payload_error(payload)

    # Enforce duplicate name failure deterministically instead of relying only on
    # interactive prompt re-tries (which can vary by installer version/prompts).
    if normalized_image_name:
        requested_name = normalized_image_name
        installed_names = _get_installed_image_names()
        installed_names_lower = {name.lower() for name in installed_names}
        if requested_name in installed_names or requested_name.lower() in installed_names_lower:
            payload = {
                'success': False,
                'result': f'Error: Provided image_name "{requested_name}" is already installed. Please provide a unique image_name.',
                'error_type': 'DuplicateImageName',
                'error_message': f'Provided image_name "{requested_name}" is already installed. Please provide a unique image_name.',
                'exception': f'DuplicateImageName: Provided image_name "{requested_name}" is already installed. Please provide a unique image_name.',
                'location': location,
                'no_prompt': bool(no_prompt),
                'context': {
                    'location': location,
                    'vrf': normalized_vrf,
                    'username': normalized_username,
                    'no_prompt': bool(no_prompt),
                    'force': bool(force),
                    'image_name': requested_name,
                },
            }
            _raise_graphql_payload_error(payload)

    installer = _load_image_installer_module()

    old_ask_yes_no = getattr(installer, 'ask_yes_no', None)
    old_ask_input = getattr(installer, 'ask_input', None)
    image_name_attempts = 0
    selected_image_name: typing.Optional[str] = None

    def _patched_ask_yes_no(message, default=False):
        msg = str(message)
        msg_lower = msg.lower()

        # Exact prompt: "Signature is not available. Do you want to continue with installation? [y/N]"
        if (
            msg.startswith('Signature is not available.')
            and 'continue with installation' in msg_lower
        ):
            return normalized_proceed_without_signature

        if msg == getattr(installer, 'MSG_INPUT_UNSAVED_COMMITS', ''):
            return normalized_proceed_unsaved_commits

        # Exact prompt: "Would you like to set the new image as the default one for boot? [Y/n]"
        if (
            'set the new image as the default one for boot' in msg_lower
        ):
            return normalized_set_as_default

        if msg == getattr(installer, 'MSG_INPUT_IMAGE_DEFAULT', ''):
            return normalized_set_as_default

        # Exact prompt: "An active configuration was found. Would you like to copy it to the new image? [Y/n]"
        if (
            'active configuration was found' in msg_lower
            and 'copy it to the new image' in msg_lower
        ):
            return normalized_copy_config

        if msg == getattr(installer, 'MSG_INPUT_CONFIG_FOUND', ''):
            return normalized_copy_config

        # Exact prompt: "Would you like to copy SSH host keys? [Y/n]"
        if 'ssh host keys' in msg_lower:
            return normalized_copy_ssh_host_keys

        # Exact prompt: "Would you like to copy SSH known_hosts? [Y/n]"
        if 'known_hosts' in msg_lower:
            return normalized_copy_ssh_known_hosts

        return default

    def _patched_ask_input(message, default=''):
        nonlocal image_name_attempts, selected_image_name
        msg = str(message)
        msg_lower = msg.lower()

        # Be resilient to installer prompt wording changes by matching common
        # image-name prompt patterns in addition to exact constants/text.
        is_image_name_prompt = (
            msg.startswith('What would you like to name this image?')
            or msg == getattr(installer, 'MSG_INPUT_IMAGE_NAME', '')
            or ('image' in msg_lower and 'name' in msg_lower)
        )

        # Exact prompt prefix: "What would you like to name this image?"
        if is_image_name_prompt and normalized_image_name:
            if image_name_attempts > 0:
                raise vyos.opmode.Error(
                    f'Provided image_name "{normalized_image_name}" is already installed. '
                    'Please provide a unique image_name.'
                )
            image_name_attempts += 1
            selected_image_name = normalized_image_name
            return selected_image_name

        # If no explicit image_name is provided, mirror CLI behavior by
        # accepting installer's computed default image name.
        if is_image_name_prompt and not normalized_image_name:
            if image_name_attempts > 0:
                default_name = selected_image_name or str(default)
                raise vyos.opmode.Error(
                    f'Default image name "{default_name}" is already installed. '
                    'Please provide image_name explicitly with a unique value.'
                )
            image_name_attempts += 1
            selected_image_name = str(default)
            return selected_image_name

        return default

    if old_ask_yes_no is not None:
        installer.ask_yes_no = _patched_ask_yes_no
    if old_ask_input is not None:
        installer.ask_input = _patched_ask_input

    safe_context = {
        'location': location,
        'vrf': normalized_vrf,
        'username': normalized_username,
        'no_prompt': bool(no_prompt),
        'force': bool(force),
        'image_name': normalized_image_name,
        'selected_image_name': selected_image_name,
    }

    captured_stdout = io.StringIO()
    captured_stderr = io.StringIO()

    try:
        with redirect_stdout(captured_stdout), redirect_stderr(captured_stderr):
            installer.add_image(
                image_path=location,
                vrf=normalized_vrf,
                username=normalized_username,
                password=normalized_password,
                no_prompt=no_prompt,
                force=force,
            )

        result = {
            'success': True,
            'result': 'System image add command completed successfully.',
            'location': location,
            'no_prompt': bool(no_prompt),
            'image_name': selected_image_name or normalized_image_name,
        }
    except SystemExit as e:
        if e.code in (None, 0):
            result = {
                'success': True,
                'result': 'System image add command completed successfully.',
                'location': location,
                'no_prompt': bool(no_prompt),
                'image_name': selected_image_name or normalized_image_name,
            }
        else:
            cli_output = '\n'.join(
                part for part in [captured_stdout.getvalue().strip(), captured_stderr.getvalue().strip()] if part
            )

            duplicate_name_conflict = (
                'already an installed image by that name' in cli_output.lower()
            )
            cli_message = _extract_cli_error_message(
                cli_output,
                fallback=f'SystemExit: {e.code}',
            )
            if duplicate_name_conflict:
                if normalized_image_name:
                    cli_message = (
                        f'Provided image_name "{normalized_image_name}" is already installed. '
                        'Please provide a unique image_name.'
                    )
                else:
                    cli_message = (
                        'Default/generated image name is already installed. '
                        'Please provide image_name explicitly with a unique value.'
                    )
            cli_exception = f'SystemExit: {cli_message}' if cli_message else f'SystemExit: {e.code}'
            result = _build_error_payload(
                reason=cli_message,
                exc=e,
                location=location,
                no_prompt=bool(no_prompt),
                context=safe_context,
                error_message=cli_message,
                exception_text=cli_exception,
            )
            result['cli_output'] = cli_output
            _raise_graphql_payload_error(result)
    except vyos.opmode.Error as e:
        cli_output = '\n'.join(
            part for part in [captured_stdout.getvalue().strip(), captured_stderr.getvalue().strip()] if part
        )
        result = _build_error_payload(
            reason=str(e),
            exc=e,
            location=location,
            no_prompt=bool(no_prompt),
            context=safe_context,
            error_message=str(e),
            exception_text=f'{e.__class__.__name__}: {e}',
        )
        if cli_output:
            result['cli_output'] = cli_output
        _raise_graphql_payload_error(result)
    except Exception as e:
        cli_output = '\n'.join(
            part for part in [captured_stdout.getvalue().strip(), captured_stderr.getvalue().strip()] if part
        )
        result = _build_error_payload(
            reason='Unexpected error during system image installation.',
            exc=e,
            location=location,
            no_prompt=bool(no_prompt),
            context=safe_context,
            error_message=str(e),
            exception_text=f'{e.__class__.__name__}: {e}',
        )
        if cli_output:
            result['cli_output'] = cli_output
        _raise_graphql_payload_error(result)
    finally:
        if old_ask_yes_no is not None:
            installer.ask_yes_no = old_ask_yes_no
        if old_ask_input is not None:
            installer.ask_input = old_ask_input

    if not raw:
        print(result)

    return result


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
