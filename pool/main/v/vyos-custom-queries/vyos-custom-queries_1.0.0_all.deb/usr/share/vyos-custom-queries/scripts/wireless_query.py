#!/usr/bin/env python3
#
# Copyright (C) 2023-2024 VyOS maintainers and contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2 or later as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import re
import sys
import vyos.opmode

from copy import deepcopy
from tabulate import tabulate
from vyos.utils.process import popen
from vyos.configquery import ConfigTreeQuery

def _verify(func):
    """Decorator checks if Wireless LAN config exists"""
    from functools import wraps

    @wraps(func)
    def _wrapper(*args, **kwargs):
        config = ConfigTreeQuery()
        if not config.exists(['interfaces', 'wireless']):
            unconf_message = 'No Wireless interfaces configured'
            raise vyos.opmode.UnconfiguredSubsystem(unconf_message)
        return func(*args, **kwargs)
    return _wrapper

def _get_raw_info_data():
    output_data = []

    config = ConfigTreeQuery()
    raw = config.get_config_dict(['interfaces', 'wireless'], effective=True,
                                 get_first_key=True, key_mangling=('-', '_'))
    for interface, interface_config in raw.items():
        tmp = {'name' : interface}

        if 'type' in interface_config:
            tmp.update({'type' : interface_config['type']})
        else:
            tmp.update({'type' : '-'})

        if 'ssid' in interface_config:
            tmp.update({'ssid' : interface_config['ssid']})
        else:
            tmp.update({'ssid' : '-'})

        if 'channel' in interface_config:
            tmp.update({'channel' : interface_config['channel']})
        else:
            tmp.update({'channel' : '-'})

        output_data.append(tmp)

    return output_data

def _get_formatted_info_output(raw_data):
    output=[]
    for ssid in raw_data:
        output.append([ssid['name'], ssid['type'], ssid['ssid'], ssid['channel']])

    headers = ["Interface", "Type", "SSID", "Channel"]
    print(tabulate(output, headers, numalign="left"))

def _get_raw_scan_data(intf_name):
    # XXX: This ignores errors
    tmp, _ = popen(f'iw dev {intf_name} scan ap-force')
    networks = []
    data = {
        'ssid': '',
        'mac': '',
        'channel': '',
        'signal': ''
    }
    re_mac = re.compile(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})')
    for line in tmp.splitlines():
        if line.startswith('BSS '):
            ssid = deepcopy(data)
            ssid['mac'] = re.search(re_mac, line).group()

        elif line.lstrip().startswith('SSID: '):
            # SSID can be "    SSID: WLAN-57 6405", thus strip all leading whitespaces
            ssid['ssid'] = line.lstrip().split(':')[-1].lstrip()

        elif line.lstrip().startswith('signal: '):
            # Siganl can be "   signal: -67.00 dBm", thus strip all leading whitespaces
            ssid['signal'] = line.lstrip().split(':')[-1].split()[0]

        elif line.lstrip().startswith('DS Parameter set: channel'):
            # Channel can be "        DS Parameter set: channel 6" , thus
            # strip all leading whitespaces
            ssid['channel'] = line.lstrip().split(':')[-1].split()[-1]
            networks.append(ssid)
            continue

    return networks

def _format_scan_data(raw_data):
    output=[]
    for ssid in raw_data:
        output.append([ssid['mac'], ssid['ssid'], ssid['channel'], ssid['signal']])
    headers = ["Address", "SSID", "Channel", "Signal (dbm)"]
    return tabulate(output, headers, numalign="left")

def _get_raw_station_data(intf_name):
    # XXX: This ignores errors
    tmp, _ = popen(f'iw dev {intf_name} station dump')
    clients = []
    data = {
        'mac': '',
        'signal': '',
        'rx_bytes': '',
        'rx_packets': '',
        'tx_bytes': '',
        'tx_packets': ''
    }
    re_mac = re.compile(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})')
    for line in tmp.splitlines():
        if line.startswith('Station'):
            client = deepcopy(data)
            client['mac'] = re.search(re_mac, line).group()

        elif line.lstrip().startswith('signal avg:'):
            client['signal'] = line.lstrip().split(':')[-1].lstrip().split()[0]

        elif line.lstrip().startswith('rx bytes:'):
            client['rx_bytes'] = line.lstrip().split(':')[-1].lstrip()

        elif line.lstrip().startswith('rx packets:'):
            client['rx_packets'] = line.lstrip().split(':')[-1].lstrip()

        elif line.lstrip().startswith('tx bytes:'):
            client['tx_bytes'] = line.lstrip().split(':')[-1].lstrip()

        elif line.lstrip().startswith('tx packets:'):
            client['tx_packets'] = line.lstrip().split(':')[-1].lstrip()
            clients.append(client)
            continue

    return clients

def _format_station_data(raw_data):
    output=[]
    for ssid in raw_data:
        output.append([ssid['mac'], ssid['signal'], ssid['rx_bytes'], ssid['rx_packets'], ssid['tx_bytes'], ssid['tx_packets']])
    headers = ["Station", "Signal", "RX bytes", "RX packets", "TX bytes", "TX packets"]
    return tabulate(output, headers, numalign="left")

def _get_raw_channel_info(intf_name):
    """
    Get complete information for a wireless interface using 'iw dev <intf_name> info'
    
    Args:
        intf_name: Name of the wireless interface (e.g., 'wlan0')
        
    Returns:
        Dictionary containing all available interface information:
        {
            'ifindex': interface index,
            'ifname': interface name,
            'wdev': wireless device ID,
            'addr': MAC address,
            'ssid': SSID (if available),
            'type': interface type (e.g., 'managed', 'AP', 'monitor'),
            'wiphy': physical device index,
            'channel': channel number,
            'frequency': primary frequency,
            'width': channel width,
            'center1': center frequency 1,
            'center2': center frequency 2 (for 80+80 MHz),
            'txpower': transmit power,
            'beacon_int': beacon interval (if AP mode),
            'dtim_period': DTIM period (if AP mode),
            'mesh_id': mesh ID (if mesh mode),
            'multicast_filtering': multicast filtering state,
            'antenna': antenna settings (if available)
        }
    """
    # Initialize default values
    data = {
        'ifindex': '',
        'ifname': intf_name,
        'wdev': '',
        'addr': '',
        'ssid': '',
        'type': '',
        'wiphy': '',
        'channel': '',
        'frequency': '',
        'width': '',
        'center1': '',
        'center2': '',
        'txpower': '',
        'beacon_int': '',
        'dtim_period': '',
        'mesh_id': '',
        'multicast_filtering': '',
        'antenna': {}
    }
    
    try:
        # Get raw output from iw command
        tmp, _ = popen(f'iw dev {intf_name} info')
        
        # Process each line of the output
        for line in tmp.splitlines():
            line = line.strip()
            
            # Extract interface name
            if line.startswith('Interface'):
                data['ifname'] = line.split()[1]
            
            # Extract ifindex
            elif 'ifindex' in line:
                data['ifindex'] = line.split()[1]
            
            # Extract wireless device ID
            elif 'wdev' in line:
                data['wdev'] = line.split()[1]
            
            # Extract MAC address
            elif 'addr' in line:
                data['addr'] = line.split()[1]
            
            # Extract interface type
            elif 'type' in line and not ('link' in line or 'key' in line):
                data['type'] = line.split()[1]
            
            # Extract wiphy index
            elif 'wiphy' in line:
                data['wiphy'] = line.split()[1]
            
            # Extract channel information
            elif 'channel' in line and 'MHz' in line:
                # Parse: "channel 100 (5500 MHz), width: 80 MHz, center1: 5530 MHz"
                channel_match = re.search(r'channel (\d+)', line)
                if channel_match:
                    data['channel'] = channel_match.group(1)
                
                # Extract frequency
                freq_match = re.search(r'\((\d+) MHz\)', line)
                if freq_match:
                    data['frequency'] = f"{freq_match.group(1)} MHz"
                
                # Extract channel width
                width_match = re.search(r'width: ([^ ,]+)', line)
                if width_match:
                    data['width'] = width_match.group(1)
                
                # Extract center1 frequency
                center1_match = re.search(r'center1: (\d+) MHz', line)
                if center1_match:
                    data['center1'] = f"{center1_match.group(1)} MHz"
                
                # Extract center2 frequency (if present - for 80+80 MHz)
                center2_match = re.search(r'center2: (\d+) MHz', line)
                if center2_match:
                    data['center2'] = f"{center2_match.group(1)} MHz"
            
            # Extract txpower information
            elif 'txpower' in line:
                txpower_match = re.search(r'txpower ([^ ]+)', line)
                if txpower_match:
                    data['txpower'] = txpower_match.group(1)
            
            # Extract SSID information (if available)
            elif 'ssid' in line.lower():
                data['ssid'] = line.split(None, 1)[1] if len(line.split(None, 1)) > 1 else ''
            
            # Extract beacon interval
            elif 'beacon interval' in line:
                beacon_match = re.search(r'beacon interval: (\d+)', line)
                if beacon_match:
                    data['beacon_int'] = beacon_match.group(1)
            
            # Extract DTIM period
            elif 'dtim period' in line:
                dtim_match = re.search(r'dtim period: (\d+)', line)
                if dtim_match:
                    data['dtim_period'] = dtim_match.group(1)
            
            # Extract mesh ID if present
            elif 'mesh id' in line:
                data['mesh_id'] = line.split(':', 1)[1].strip()
            
            # Extract multicast filtering state
            elif 'multicast filtering' in line:
                data['multicast_filtering'] = 'enabled' if 'enabled' in line else 'disabled'
            
            # Extract antenna information
            elif 'antenna' in line:
                # Parse antenna information like "antenna 1: 0, antenna 2: 3"
                antenna_match = re.findall(r'antenna (\d+): (-?\d+)', line)
                for ant_num, ant_val in antenna_match:
                    data['antenna'][ant_num] = ant_val
    
    except Exception as e:
        # Log error or handle gracefully
        print(f"Error getting interface info for {intf_name}: {str(e)}", file=sys.stderr)
    
    return data

def _format_channel_info(raw_data):
    """Format channel information for display"""
    # Create a comprehensive table with all information
    output = [[
        raw_data['ifname'],
        raw_data['addr'],
        raw_data['type'],
        raw_data['channel'],
        raw_data['frequency'],
        raw_data['width'],
        raw_data['center1'] if raw_data['center1'] else 'N/A',
        raw_data['txpower'] if raw_data['txpower'] else 'N/A'
    ]]
    
    headers = ["Interface", "MAC Address", "Type", "Channel", "Frequency", "Width", "Center1", "TX Power"]
    return tabulate(output, headers, numalign="left")

def _get_all_wireless_interfaces():
    """Get a list of all configured wireless interfaces"""
    interfaces = []
    
    config = ConfigTreeQuery()
    if config.exists(['interfaces', 'wireless']):
        raw = config.get_config_dict(['interfaces', 'wireless'], 
                                    effective=True, 
                                    get_first_key=True, 
                                    key_mangling=('-', '_'))
        interfaces = list(raw.keys())
    
    return interfaces

def _get_all_interfaces_info():
    """Get information for all wireless interfaces"""
    interfaces = _get_all_wireless_interfaces()
    all_info = {}
    
    for intf in interfaces:
        all_info[intf] = _get_raw_channel_info(intf)
    
    return all_info

def _format_all_interfaces_info(raw_data):
    """Format information for all interfaces"""
    output = []
    
    for intf, data in raw_data.items():
        output.append([
            data['ifname'],
            data['addr'],
            data['type'],
            data['channel'],
            data['frequency'],
            data['width'],
            data['center1'] if data['center1'] else 'N/A',
            data['txpower'] if data['txpower'] else 'N/A'
        ])
    
    headers = ["Interface", "MAC Address", "Type", "Channel", "Frequency", "Width", "Center1", "TX Power"]
    return tabulate(output, headers, numalign="left")

@_verify
def show_channel(raw: bool):
    """
    Show wireless interface information
    
    Args:
        raw: If True, return Python data structure. If False, return formatted table.
        intf_name: Name of the specific wireless interface, or None to show all interfaces
        
    Returns:
        Interface information either as raw data or formatted table
    """
 
        # Get info for all interfaces
    data = _get_all_interfaces_info()
    if raw:
        return data
    return _format_all_interfaces_info(data)

@_verify
def show_info(raw: bool):
    info_data = _get_raw_info_data()
    if raw:
        return info_data
    return _get_formatted_info_output(info_data)

def show_scan(raw: bool, intf_name: str):
    data = _get_raw_scan_data(intf_name)
    if raw:
        return data
    return _format_scan_data(data)

@_verify
def show_stations(raw: bool, intf_name: str):
    data = _get_raw_station_data(intf_name)
    if raw:
        return data
    return _format_station_data(data)


if __name__ == '__main__':
    try:
        res = vyos.opmode.run(sys.modules[__name__])
        if res:
            print(res)
    except (ValueError, vyos.opmode.Error) as e:
        print(e)
        sys.exit(1)
