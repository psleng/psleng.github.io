from typing import Optional
from pydantic import AnyHttpUrl, BaseModel, EmailStr, StrictStr
from datetime import datetime
from enum import StrEnum

class AuthStatus(StrEnum):
    NO_RESPONSE = "NO_RESPONSE"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"

class AuthLevel(StrEnum):
    ADMIN = "ADMIN"
    OPERATOR = "OPERATOR"
    NONE = "NONE"

class TokenRequestModel(BaseModel):
    email: Optional[EmailStr] = None
    RelayState: Optional[AnyHttpUrl] = None

class AuthRequestModel(BaseModel):
    session: StrictStr

class User(BaseModel):
    email: Optional[EmailStr] = None
    url: AnyHttpUrl # Real sso url
    token: StrictStr # Identifier token
    session: StrictStr # Session token
    settings: dict # User settings
    auth_status: AuthStatus
    auth_level: AuthLevel
    created_at: datetime

