from fastapi import FastAPI
from contextlib import asynccontextmanager

from .routes import router
from .utils.config import config
from .utils.logger import logger
from .utils.logger import LogLevel

@asynccontextmanager
async def lifespan(app: FastAPI):
    if config.force_cache():
        logger.log("Force cache ran")
    else:
        logger.log("Force cache failed to run", level=LogLevel.ERROR)
    yield
    logger.log("App quit")

def create_app() -> FastAPI:
    app = FastAPI(lifespan=lifespan)
    app.include_router(router)
    return app
