import redis
import json
import secrets
from datetime import datetime
from typing import Optional
from api.models import *

def gen_user_from_dict(data: dict) -> User:
    user = User(
        email=data.get("email", None),
        url=data.get("url", None),
        token=data.get("token", None),
        session=data.get("session", None),
        settings=data.get("settings", {}),
        auth_status= AuthStatus.NO_RESPONSE if not data.get("auth_status", None) else AuthStatus(data.get("auth_status")),
        auth_level = AuthLevel.NONE if not data.get("auth_level", None) else AuthLevel(data.get("auth_level")),
        created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.utcnow()
    )
    return user

class RedisManager:
    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0):
        self.redis_client = redis.Redis(host=host, port=port, db=db, decode_responses=True)
    
    def generate_token(self, length: int = 8) -> str:
        """Generate a secure random token"""
        return secrets.token_urlsafe(length)
    
    def register_user(self, token: str, session: str, url: str, settings: dict, email: str = None) -> User:
        # Check if user already has a token, to delete old token mapping
        old_token = self.redis_client.get(f"email:{email}")
        pipeline = self.redis_client.pipeline()

        if old_token:
            # Delete old token mapping to avoid stale data
            pipeline.delete(f"token:{old_token}")

        # Prepare new user data
        user_data = {
            "email": email,
            "url": url,
            "token": token,
            "session": session,
            "settings": settings,
            "auth_status": AuthStatus.NO_RESPONSE,
            "auth_level": AuthLevel.NONE,
            "created_at": datetime.utcnow().isoformat()
        }

        # Set new mappings
        pipeline.set(f"token:{token}", json.dumps(user_data))
        pipeline.set(f"session:{session}", token)

        # Set expiration for both keys (10 minutes)
        pipeline.expire(f"token:{token}", 10 * 60)
        pipeline.expire(f"session:{session}", 10 * 60)

        pipeline.execute()

        return gen_user_from_dict(user_data)
    
    def set_user_auth_status(self, token: str, auth_status: AuthStatus) -> Optional[User]:
        user_data = self.redis_client.get(f"token:{token}")
        ttl = self.redis_client.ttl(f"token:{token}")
        if not user_data:
            return None

        data = json.loads(user_data)
        data.update({'auth_status': auth_status})

        self.redis_client.set(f"token:{token}", json.dumps(data), ex=ttl)

        return gen_user_from_dict(data)

    def set_user_auth_level(self, token: str, auth_level: AuthLevel) -> Optional[User]:
        user_data = self.redis_client.get(f"token:{token}")
        ttl = self.redis_client.ttl(f"token:{token}")
        if not user_data:
            return None
        
        data = json.loads(user_data)
        data.update({'auth_level': auth_level})

        self.redis_client.set(f"token:{token}", json.dumps(data), ex=ttl)

        return gen_user_from_dict(data)
    
    def set_user_email(self, token: str, email: str) -> Optional[User]:
        user_data = self.redis_client.get(f"token:{token}")
        ttl = self.redis_client.ttl(f"token:{token}")
        if not user_data:
            return None
        
        data = json.loads(user_data)
        data.update({'email': email})

        self.redis_client.set(f"token:{token}", json.dumps(data), ex=ttl)

        return gen_user_from_dict(data)
    
    def get_user_by_token(self, token: str) -> Optional[User]:
        """Get user data by token"""
        user_data = self.redis_client.get(f"token:{token}")
        if not user_data:
            return None
        
        data = json.loads(user_data)
        return gen_user_from_dict(data)
    
    def get_user_by_session(self, session: str) -> Optional[User]:
        """Get user token by email"""
        token = self.redis_client.get(f"session:{session}")
        if not token:
            return None
        
        user_data = self.redis_client.get(f"token:{token}")
        if not user_data:
            return None
        
        data = json.loads(user_data)
        return gen_user_from_dict(data)
    
    def delete_user(self, token: str) -> bool:
        """Delete a user by token"""
        user_data = self.redis_client.get(f"token:{token}")
        if not user_data:
            return False
        
        data = json.loads(user_data)
        email = data.get("email", None)
        
        pipeline = self.redis_client.pipeline()
        pipeline.delete(f"token:{token}")
        pipeline.delete(f"email:{email}")
        pipeline.execute()
        
        return True
    
    def list_all_users(self) -> list[User]:
        """List all registered users (for admin purposes)"""
        users = []
        for key in self.redis_client.scan_iter(match="token:*"):
            user_data = self.redis_client.get(key)
            if user_data:
                data = json.loads(user_data)
                users.append(gen_user_from_dict(data))
        return users

# Global Redis manager instance
redisDB = RedisManager()
