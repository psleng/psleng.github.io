from api.models import *
from api.redis import redisDB
from api.utils.logger import logger
from api.utils.config import config
from api.utils.utils import gen_request
from api.utils.utils import get_outbound_ip
from api.utils.utils import get_provider_icon

import hashlib
from typing import Optional
from urllib.parse import urlencode, urlunparse, urlparse, parse_qs

from pydantic import AnyHttpUrl, StrictStr

from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import RedirectResponse

from onelogin.saml2.settings import OneLogin_Saml2_Settings
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from onelogin.saml2.response import OneLogin_Saml2_Response

router = APIRouter(prefix="/saml")


@router.post("/gen_signon_url")
async def gen_signon_url(request: Request, data: Optional[TokenRequestModel] = None):
    logger.log(f"Received signon request:")
    logger.log(f"RelayState: {str(data.RelayState) if data and data.RelayState else 'None'}")
    logger.log(f"Email: {str(data.email) if data and data.email else 'None'}")
    logger.log(f"Request Scheme: {request.url.scheme}")
    logger.log(f"Request Path: {request.url.path}")
        

    ipaddr = get_outbound_ip()
    if ipaddr is None:
        raise HTTPException(status_code=400, detail="Network unreachable")

    metadata = config.get_metadata()
    if not metadata:
        raise HTTPException(status_code=500, detail="Could not get metadata")
    
    entityID = config.get_entityID()
    if not entityID:
        raise HTTPException(status_code=500, detail="Could not get entityID")
    
    settings = {
        'strict': True,
        'debug': True,
        'sp': {
            'entityId': entityID,
            'assertionConsumerService': {
                'url': f'{request.url.scheme}://{ipaddr}/saml/acs',
                'binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST'
            },
            'NameIDFormat': 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
            'x509cert': '', # We do not sign request so no cert/private key is needed
            'privateKey': ''
        },
        'idp': metadata.get('idp', {}), # Get IDP settings from metadata

        'security': {
            'authnRequestsSigned': False,        # SP does not sign requests
            'wantAssertionsSigned': True,        # SP expects signed assertions (prevents fake responses)
            'wantMessagesSigned': False,         # SP does not need messages additionally signed
            'wantNameId': True,                  # SP wants NameID in response
            'wantNameIdEncrypted': False,        # SP does not want NameID encrypted
            'wantAssertionsEncrypted': False,    # SP does not want assertions encrypted
            'allowUnsollicitedResponses': False, # SP does not allow login flow to start at IDP
            'signatureAlgorithm': 'rsa-sha256',  # SP expects RSA-SHA256 for signatures
            'digestAlgorithm': 'sha256',         # SP expects SHA256 for digests

            'wantAttributeStatement': False      # Attributes will be handled by router
        }
    }

    # Generate AUTHN request
    req = await gen_request(request)
    auth = OneLogin_Saml2_Auth(req, old_settings=settings)

    # Store relay data
    token = redisDB.generate_token(length=6)
    if data.RelayState:
        relay_state_string = str(data.RelayState)
        parsed = urlparse(relay_state_string)
        if parsed.scheme and parsed.netloc:
            query_params = parse_qs(parsed.query)
            query_params['token'] = [token]
            new_query = urlencode(query=query_params, doseq=True)
            relay = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
        else:
            relay = token
    else:
        relay = token

    # Return to user
    sso_url = auth.login(return_to=relay)
    mask_url = f'https://{ipaddr}/saml/u/{token}'

    session = redisDB.generate_token(length=32)
    session_hash = hashlib.sha256(session.encode("utf-8")).hexdigest()

    redisDB.register_user(token, session_hash, sso_url, settings, data.email if data.email else None)

    return {
        'status': 'ok',
        'token': token,
        'session': session,
        'sso_url': sso_url,
        "mask_url": mask_url
    }


@router.get("/u/{token}")
async def urlmask(request: Request, token: str):
    logger.log(f"Received mask request:")
    logger.log(f"Token: {token}")
    logger.log(f"Request Scheme: {request.url.scheme}")
    logger.log(f"Request Path: {request.url.path}")

    user = redisDB.get_user_by_token(token)
    if not user:
        raise HTTPException(status_code=404, detail="Invalid token")

    sso_url = user.url
    return RedirectResponse(url=sso_url)


@router.post("/acs")
async def sso(request: Request, SAMLResponse: str = Form(...), RelayState: str = Form(...)):
    logger.log(f"Received acs request:")
    logger.log(f"RelayState: {RelayState}")
    logger.log(f"Request Scheme: {request.url.scheme}")
    logger.log(f"Request Path: {request.url.path}")

    def auth_reponse(user_token: StrictStr, level: AuthLevel, status: AuthStatus, relay_url: AnyHttpUrl | None):
        """Set user authentication level/status in Redis and return the proper response."""
        redisDB.set_user_auth_level(user_token, level)
        redisDB.set_user_auth_status(user_token, status)
        if relay_url:
            return RedirectResponse(url=relay_url, status_code=303)
        return {'status': 'ok', 'message': 'SAML response received'}

    # Parse relay
    parsed = urlparse(RelayState)
    if parsed.scheme and parsed.netloc:
        query_params = parse_qs(parsed.query)
        token = query_params.pop("token", [None])[0]

        new_query = urlencode(query_params, doseq=True)
        relay_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
    else:
        relay_url = None
        token = RelayState

    # Vaidate response
    user = redisDB.get_user_by_token(token)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    settings = OneLogin_Saml2_Settings(user.settings)
    response = OneLogin_Saml2_Response(settings, SAMLResponse)
    req = await gen_request(request)
    if not response.is_valid(req):
        raise HTTPException(status_code=400, detail=f"Invalid SAML response: {response.get_error()}")

    auth_status, auth_level = config.verify_user(user, response)
    return auth_reponse(user.token, auth_level, auth_status, relay_url)


@router.post("/validate")
async def is_auth(request: Request, auth_req: AuthRequestModel):
    logger.log(f"Received auth check request:")
    logger.log(f"Session: {auth_req.session}")
    logger.log(f"Request Scheme: {request.url.scheme}")
    logger.log(f"Request Path: {request.url.path}")

    session_hash = hashlib.sha256(auth_req.session.encode("utf-8")).hexdigest()
    user = redisDB.get_user_by_session(session=session_hash)
    if not user:
        raise HTTPException(status_code=404, detail="Invalid token")
    
    if user.auth_status == AuthStatus.SUCCESS:
        redisDB.delete_user(user.token)

    return {'status': 'ok', 'auth_status': user.auth_status, 'auth_level': user.auth_level, "user_id": user.email}


@router.get("/info")
async def info(request: Request):
    logger.log(f"Received info request:")
    logger.log(f"Request Scheme: {request.url.scheme}")
    logger.log(f"Request Path: {request.url.path}")
    
    name = config.get_name()
    icon = config.get_icon()

    return {'status': 'ok', 'name': name, 'icon': icon}
