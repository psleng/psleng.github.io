import json
import os
from typing import Tuple, Optional

from onelogin.saml2.response import OneLogin_Saml2_Response
from onelogin.saml2.idp_metadata_parser import OneLogin_Saml2_IdPMetadataParser

from api.utils.logger import logger
from api.utils.logger import LogLevel
from api.models import AuthLevel, AuthStatus, User
from api.redis import redisDB

from api.utils.utils import get_provider_icon


class ConfigManager:
    def __init__(self, config_file: str = "saml.conf", config_dir: str = None, cache_file: str = "saml.cache", cache_dir= None):
        if config_dir:
            self._config_dir = config_dir
        else:
            SAML_CONFIG_DIR = os.getenv("SAML_CONFIG_DIR")
            self._config_dir = SAML_CONFIG_DIR
        self._config_file = config_file
        self._config_loc = f"{self._config_dir}/{self._config_file}"

        if cache_dir:
            self._cache_dir = cache_dir
        else:
            SAML_CACHE_DIR = os.getenv("SAML_CACHE_DIR")
            self._cache_dir = SAML_CACHE_DIR
        self._cache_file = cache_file
        self._cache_loc = f"{self._cache_dir}/{self._cache_file}"

        self._config = {}
        self._metadata = {}
        self._provider_icon = ""

        logger.log(f"Initializing ConfigManager with config at '{self._config_loc}' and cache at '{self._cache_loc}'")
        self._load_config()

    def use_default_level(self) -> bool:
        for level in AuthLevel:
            if level == AuthLevel.NONE:
                continue

            level_config = self._config.get(level.lower(), {})
            if not level_config:
                continue

            if (
                "user" in level_config
                or "req" in level_config
                or "suff" in level_config
            ):
                return False

        return True

    def verify_user(self, user: User, response: OneLogin_Saml2_Response) -> Tuple[AuthStatus, AuthLevel]:
        logger.log(f"Verifying user '{user.token}' with SAML response.")
        if user.email and user.email != response.get_nameid():
            return (AuthStatus.FAILED, AuthLevel.NONE)
        if not user.email:
            user.email = response.get_nameid()
            redisDB.set_user_email(user.token, user.email)

        if self.use_default_level():
            return (AuthStatus.SUCCESS, self.get_default_level())

        for perm_level in AuthLevel:
            if perm_level == AuthLevel.NONE:
                continue
            
            perm_config = self._config.get(perm_level.lower(), {})

            config_user = perm_config.get("user", [])
            username = response.get_nameid()
            if username in config_user:
                return (AuthStatus.SUCCESS, AuthLevel(perm_level))
            
            user_attrs = response.get_attributes()
            for attr, cfg in perm_config.get('suff', {}).items():
                if any(value in user_attrs.get(attr, []) for value in cfg.get('value', [])):
                    return (AuthStatus.SUCCESS, AuthLevel(perm_level))

            req = perm_config.get('req', {})
            if all(set(cfg.get('value', [])) <= set(user_attrs.get(attr, [])) for attr, cfg in req.items()):
                return (AuthStatus.SUCCESS, AuthLevel(perm_level))
        
        return (AuthStatus.FAILED, AuthLevel.NONE)
    
    def get_name(self) -> Optional[str] | None:
        config_name = self._config.get("name")
        if not config_name:
            return None
        
        return config_name
    
    def get_icon(self) -> Optional[str] | None:
        return self._provider_icon

    def get_default_level(self) -> AuthLevel:
        config_level = self._config.get("default_sso_level")
        if not config_level:
            return AuthLevel.OPERATOR
        
        return AuthLevel(config_level.upper())

    def get_metadata(self) -> dict:
        return self._metadata.copy() or {}

    def get_entityID(self) -> Optional[str] | None:
        entityID = self._config.get("entityID")
        if not entityID:
            return None
        
        return entityID

    def get_config_dict(self) -> dict:
        return self._config.copy() or {}

    def force_cache(self) -> bool:
        metadata_url = self._config.get("metadata_url")
        if metadata_url:
            logger.log(f"Forcing cache update from URL '{metadata_url}'")
            self._store_cache(url=metadata_url)
            return True
        else:
            logger.log("Could not force cache update (no metadata URL available).", level=LogLevel.WARNING)
            return False

    def _load_config(self):
        try:
            with open(self._config_loc) as config:
                self._config = json.load(config)
            logger.log(f"Loaded configuration from '{self._config_loc}'")

            metadata_url = self._config.get("metadata_url")
            if metadata_url:
                logger.log(f"Found metadata URL '{metadata_url}', attempting to load metadata.")
                self._load_metadata(metadata_url)
            else:
                logger.log("No metadata URL found in config, loading from cache instead.", level=LogLevel.WARNING)
                self._load_cache()

        except Exception as e:
            logger.log(f"Failed to load configuration from '{self._config_loc}': {str(e)}", level=LogLevel.ERROR)
            self._load_cache()

    def _load_metadata(self, url):
        if self._metadata:
            logger.log("Metadata already loaded, skipping remote fetch.")
            return
        try:
            parser = OneLogin_Saml2_IdPMetadataParser()
            self._metadata = parser.parse_remote(url)
            self._provider_icon = get_provider_icon(self._metadata)
            logger.log(f"Successfully loaded metadata from '{url}', caching it.")
            self._store_cache(metadata=self._metadata)
        except Exception as e:
            logger.log(f"Failed to load metadata from '{url}': {str(e)}. Falling back to cache.", level=LogLevel.WARNING)
            self._load_cache()

    def _load_cache(self):
        try:
            with open(self._cache_loc) as cache:
                cache_data = json.load(cache)
                if len(cache_data) != 2:
                    raise Exception("Malformed Cache")
                self._metadata = cache_data[0]
                self._provider_icon = cache_data[1]
            logger.log(f"Loaded metadata from cache at '{self._cache_loc}'")
        except Exception as e:
            logger.log(f"Failed to load cache from '{self._cache_loc}': {str(e)}", level=LogLevel.ERROR)

    def _store_cache(self, metadata: dict = None, url: str = None):
        try:
            if not url and not metadata:
                logger.log("Cannot store cache: neither metadata nor URL provided.", level=LogLevel.ERROR)
                return

            if not metadata:
                parser = OneLogin_Saml2_IdPMetadataParser()
                metadata = parser.parse_remote(url)
                logger.log(f"Fetched metadata from '{url}' for caching.")

            if not os.path.exists(self._cache_dir):
                os.makedirs(self._cache_dir, exist_ok=True)
                logger.log(f"Created cache directory '{self._cache_dir}'")
            
            provider_icon = get_provider_icon(metadata)

            cache_data = [metadata, provider_icon]

            with open(self._cache_loc, "w") as cache:
                json.dump(cache_data, cache, indent=4)

            logger.log(f"Stored metadata cache at '{self._cache_loc}'")
        except Exception as e:
            logger.log(f"Failed to store cache at '{self._cache_loc}': {str(e)}", level=LogLevel.ERROR)

config = ConfigManager()
