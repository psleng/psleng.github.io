#!/usr/bin/env python3
from api import create_app
import uvicorn

app = create_app()

def main():
    uvicorn.run(app, host="0.0.0.0", port=9000)

if __name__ == "__main__":
    main()