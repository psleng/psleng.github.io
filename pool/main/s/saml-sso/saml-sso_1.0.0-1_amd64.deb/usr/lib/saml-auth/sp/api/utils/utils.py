import socket
from typing import Optional

from fastapi import Request

import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

from .logger import logger, LogLevel

def get_outbound_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        return s.getsockname()[0]
    except Exception:
        return None
    finally:
        s.close()

async def gen_request(request: Request) -> dict:
    form = await request.form()
    return {
        'https': 'on' if request.url.scheme == 'https' else 'off',
        'http_host': request.headers.get('host', ''),
        'server_port': str(request.url.port or (443 if request.url.scheme == 'https' else 80)),
        'script_name': request.url.path,
        'get_data': dict(request.query_params),
        'post_data': dict(form)
    }

def get_provider_icon(metadata: dict = {}) -> Optional[str] | None:
    try:
        if not metadata:
            return None
        
        entity_id = metadata.get("idp", {}).get("entityId")
        if not entity_id:
            return None

        resp = requests.get(entity_id, timeout=5)

        base_url = resp.url
        soup = BeautifulSoup(resp.text, "lxml")

        candidate = []

        for link in soup.find_all('link', attrs={'rel': re.compile(r'^(shortcut icon|icon)$', re.I)}):
            href = link.get('href')
            if not href:
                continue

            sizes = link.get('sizes')
            size_val = 0
            if sizes:
                sizes_list = sizes.split()
                first_size = sizes_list[0]
                match = re.match(r"(\d+)x(\d+)", first_size)
                if match:
                    width, height = int(match.group(1)), int(match.group(2))
                    size_val = max(width, height)

            abs_href = urljoin(base_url, href)
            candidate.append((size_val, abs_href))
        
        if not candidate:
            return None
        
        largest = max(candidate, key=lambda x: x[0])
        return largest[1]
    
    except requests.exceptions.Timeout:
        logger.log("Entity ID timedout", LogLevel.ERROR)
        return None
    except Exception as e:
        logger.log(f"Unknow Error: {str(e)}", LogLevel.ERROR)
        return None