import os
import logging
from enum import StrEnum

log_to_journal = os.getenv("LOG_TO_JOURNAL", "0").lower() in ("1", "true", "yes")

class LogLevel(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class Logger:
    def __init__(self):
        self.enabled = log_to_journal
        self.logger = logging.getLogger("saml-sp")
        if self.enabled and not self.logger.hasHandlers():
            self.logger.setLevel(logging.INFO)
            journal_handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            journal_handler.setFormatter(formatter)
            self.logger.addHandler(journal_handler)
            
    def log(self, message: str, level: LogLevel = LogLevel.INFO):
        if not self.enabled:
            return

        if level == LogLevel.INFO:
            self.logger.info(message)
        elif level == LogLevel.WARNING:
            self.logger.warning(message)
        elif level == LogLevel.ERROR:
            self.logger.error(message)
        elif level == LogLevel.CRITICAL:
            self.logger.critical(message)
        else:
            self.logger.debug(message)

logger = Logger()