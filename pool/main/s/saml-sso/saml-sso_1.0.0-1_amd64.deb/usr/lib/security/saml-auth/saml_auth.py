import re
import requests
import subprocess
import signal
import contextlib
import time

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

SCHEME = r'https'
NETLOC = r'127.0.0.1'

SIGN_ON_PATH = r'saml/gen_signon_url'
AUTH_PATH = r'saml/validate'

SIGN_ON_URL = f'{SCHEME}://{NETLOC}/{SIGN_ON_PATH}'
AUTH_URL = f'{SCHEME}://{NETLOC}/{AUTH_PATH}'

EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

class AuthTimeout(Exception):
    pass

def _alarm_handler(signum, frame):
    raise AuthTimeout()

@contextlib.contextmanager
def pam_timeout_override(seconds=180):
    """
    Temporarily override SIGALRM to raise AuthTimeout after `seconds`.
    Safely restores only if the original handler was valid.
    """
    # Capture current handler and timer
    orig_handler = signal.getsignal(signal.SIGALRM)
    orig_timer   = signal.getitimer(signal.ITIMER_REAL)

    # Install our alarm
    signal.signal(signal.SIGALRM, _alarm_handler)
    signal.setitimer(signal.ITIMER_REAL, seconds, 0)

    try:
        yield
    finally:
        # Restore the handler if it’s valid, otherwise default to DFL
        try:
            if callable(orig_handler) or orig_handler in (signal.SIG_IGN, signal.SIG_DFL):
                signal.signal(signal.SIGALRM, orig_handler)
            else:
                signal.signal(signal.SIGALRM, signal.SIG_DFL)
        except (ValueError, TypeError):
            signal.signal(signal.SIGALRM, signal.SIG_DFL)

        # Restore the original timer
        signal.setitimer(
            signal.ITIMER_REAL,
            orig_timer[0],
            orig_timer[1]
        )

def get_user(pamh):
    try:
        user = pamh.get_user(None)
        if user is None:
            raise ValueError("SSO: No user found")
        return user
    except ValueError as e:
        pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: User not found"))
        return None

def is_service_running(service: str) -> bool:
    command = ['systemctl', 'is-active', '--quiet', service]
    try:
        res = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return res.returncode == 0
    except Exception:
        return False

def pam_sm_authenticate(pamh, flags, argv):
    try:
        user = get_user(pamh)
        if user is None:
            return pamh.PAM_USER_UNKNOWN

        if not re.match(EMAIL_REGEX, user):
            return pamh.PAM_AUTH_ERR

        if not is_service_running('saml-sp'):
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: saml-sp service is not running"))
            return pamh.PAM_SERVICE_ERR

        signon_payload = {
            'email': user,
        }

        try:
            signon_req = requests.post(url=SIGN_ON_URL, json=signon_payload, timeout=10, verify=False)
            signon_req.raise_for_status()
        except requests.exceptions.Timeout as e:
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO (saml-sp): Token request timed out"))
            return pamh.PAM_SERVICE_ERR
        except requests.exceptions.HTTPError as e:
            try:
                error_detail = e.response.json().get('detail')
            except Exception as e:
                error_detail = "Unknown HTTPError, Check if saml-sp is running"
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, f"SSO (saml-sp): {error_detail}"))
            return pamh.PAM_SERVICE_ERR
        except Exception as e:
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, f"SSO (saml-sp): Unknow error {str(e)}"))
            return pamh.PAM_SERVICE_ERR

        signon_resp = signon_req.json()
        mask_url = signon_resp.get('mask_url')
        session_token = signon_resp.get('session')

        if not mask_url:
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO (saml-sp): could not get URL"))
            return pamh.PAM_SERVICE_ERR

        if not session_token:
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO (saml-sp): could not get session"))
            return pamh.PAM_SERVICE_ERR

        try:
            with pam_timeout_override():
                pamh.conversation([
                    pamh.Message(pamh.PAM_TEXT_INFO, "SSO Sign on attempt detected"),
                    pamh.Message(pamh.PAM_TEXT_INFO, "Open your browser and go to:"),
                    pamh.Message(pamh.PAM_TEXT_INFO, f"{mask_url}"),
                    pamh.Message(pamh.PAM_PROMPT_ECHO_ON, "Press Enter when done to continue: ")
                ])

                auth_payload = {
                    'session': session_token
                }
                auth_level = None
                while True:
                    try:
                        auth_req = requests.post(url=AUTH_URL, json=auth_payload, timeout=10, verify=False)
                        auth_req.raise_for_status()

                        auth_resp = auth_req.json()
                        if auth_resp.get('auth_status') == 'SUCCESS':
                            auth_level = auth_resp.get('auth_level')
                            break
                        elif auth_resp.get('auth_status') == 'FAILED':
                            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: User not allowed"))
                            return pamh.PAM_PERM_DENIED
                    except requests.exceptions.HTTPError:
                        pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: Token timed out"))
                        return pamh.PAM_SERVICE_ERR
                    except Exception as e:
                        pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, f"SSO (saml-sp): Unknow error {str(e)}"))
                        return pamh.PAM_SERVICE_ERR
                    time.sleep(1)

                if auth_level == 'ADMIN':
                    return pamh.PAM_SUCCESS
                else:
                    pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: Operators do not have CLI access"))
                    return pamh.PAM_PERM_DENIED

        except AuthTimeout:
            pamh.conversation(pamh.Message(pamh.PAM_ERROR_MSG, "SSO: Timed out"))
            return pamh.PAM_PERM_DENIED
    except Exception as e:
        print(e)
        return pamh.PAM_AUTH_ERR

# libpam-python stubs (no implementation)
def pam_sm_open_session(pamh, flags, argv):
    return pamh.PAM_SUCCESS

def pam_sm_close_session(pamh, flags, argv):
    return pamh.PAM_SUCCESS

def pam_sm_setcred(pamh, flags, argv):
    return pamh.PAM_SUCCESS

def pam_sm_acct_mgmt(pamh, flags, argv):
    return pamh.PAM_SUCCESS

def pam_sm_chauthtok(pamh, flags, argv):
    return pamh.PAM_SUCCESS
