# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

import hashlib
import json
import secrets
from contextlib import contextmanager
from typing import Iterator, Literal, Optional

from redis import Redis

from fastapi import Request

from ..errors import ApiError

from .models import Session


class SessionLockTimeout(ApiError):
    """Raised when a session lock cannot be acquired within the timeout."""

    status_code = 503
    message = "Session is temporarily unavailable, please retry"


class SessionNotFound(ApiError):
    """Raised when no session exists for the requested key."""

    status_code = 404
    message = "Session not found"


class SessionExists(ApiError):
    """Raised when attempting to create a session that already exists."""

    status_code = 500
    message = "Could not create session, please retry"


class SessionMissingError(ApiError):
    """No session/claim information was provided by the client."""

    status_code = 401
    message = "No session found"


class SessionInvalidError(ApiError):
    """A session exists but is in an unusable state (claimed/invalid claim)."""

    status_code = 401
    message = "Invalid session"


class SessionManager:
    def __init__(self) -> None:
        self.app_prefix = "saml-sp:"
        self.redis_client = Redis(db=2, decode_responses=True)

    def _session_key(self, session_key: str) -> str:
        return f"{self.app_prefix}session:{session_key}"

    def _lock_key(self, session_key: str) -> str:
        return f"{self.app_prefix}lock:{session_key}"

    def create_session(
        self,
        flow: Literal["cli", "web"],
        relay: str = "",
        *,
        ttl: Optional[int] = 15 * 60,
        ip_addr: str = "",
    ) -> tuple[str, str]:
        """Create a new session and store it in Redis.

        A cryptographically random ``session_key`` is generated to address the
        session, and a separate ``application_secret`` is generated, hashed, and
        stored. The plaintext secret is returned to the caller and never
        persisted. Returns the ``(session_key, application_secret)`` tuple.

        :param ttl: optional expiry in seconds for the stored session.
        :raises SessionExists: if a generated key already exists (extremely rare).
        """
        session_key = secrets.token_urlsafe(8)
        application_secret = secrets.token_urlsafe(32)
        application_secret_hash = hashlib.sha256(
            application_secret.encode()
        ).hexdigest()
        session = Session(application_secret_hash, flow, relay, ip_addr)

        created = self.redis_client.set(
            self._session_key(session_key),
            json.dumps(session.to_dict()),
            nx=True,
            ex=ttl,
        )

        if not created:
            raise SessionExists(session_key)

        return session_key, application_secret

    def delete_session(self, session_key: str) -> None:
        """Delete a session and its lock by key.

        Acquires the session lock first so an in-flight holder finishes before
        the session is removed.

        :raises SessionNotFound: if no session exists for ``session_key``.
        """
        lock = self.redis_client.lock(self._lock_key(session_key), timeout=30)
        lock.acquire(blocking=True)
        try:
            deleted = self.redis_client.delete(self._session_key(session_key))
            if not deleted:
                raise SessionNotFound(session_key)
        finally:
            try:
                lock.release()
            except Exception:
                pass

    def read_session(self, session_key: str) -> Session:
        """Return a read-only snapshot of a session without taking the lock.

        Intended for high-frequency, read-only consumers such as the validate
        polling route. A single Redis ``GET`` is atomic, so the returned
        ``Session`` is always internally consistent and never reflects a
        partially written value. The snapshot is **not** written back, so this
        path can never corrupt session state and never contends with writers
        holding the lock (no ``SessionLockTimeout`` from polling).

        Do not mutate-and-persist the returned object; use :meth:`session` for
        any read-modify-write operation.

        :raises SessionNotFound: if no session exists for ``session_key``.
        """
        raw = self.redis_client.get(self._session_key(session_key))
        if raw is None:
            raise SessionNotFound(session_key)

        return Session.load_from_json(
            raw if isinstance(raw, str) else bytes(raw).decode()
        )

    @contextmanager
    def session(
        self,
        session_key: str,
        *,
        lock_timeout: int = 30,
        blocking_timeout: Optional[float] = None,
    ) -> Iterator[Session]:
        """Acquire exclusive access to a session by its key.

        Use as a context manager::

            with manager.session("abc123") as session:
                session.claim(token)

        Any other thread or process attempting to enter this context for the
        same ``session_key`` blocks until the current holder exits. Mutations to
        the yielded ``Session`` are persisted back to Redis on a clean exit.

        :param lock_timeout: seconds before the lock auto-expires (deadlock guard).
        :param blocking_timeout: max seconds to wait for the lock; ``None`` waits
            indefinitely.
        :raises SessionLockTimeout: if the lock cannot be acquired in time.
        :raises SessionNotFound: if no session exists for ``session_key``.
        """
        lock = self.redis_client.lock(
            self._lock_key(session_key),
            timeout=lock_timeout,
            blocking=True,
            blocking_timeout=blocking_timeout,
        )

        if not lock.acquire():
            raise SessionLockTimeout(
                f"Could not acquire lock for session {session_key!r}", raw=False
            )

        try:
            raw = self.redis_client.get(self._session_key(session_key))
            if raw is None:
                raise SessionNotFound(session_key, raw=False)

            session = Session.load_from_json(
                raw if isinstance(raw, str) else bytes(raw).decode()
            )
            try:
                yield session
            finally:
                # Persist mutations even when the with-body raises. Handlers
                # (e.g. the ACS flow) update the session to a terminal state
                # such as FAILED and then raise an ApiError to redirect the
                # browser; that state must still be written back so pollers of
                # /validate observe the outcome instead of the stale state.
                self.redis_client.set(
                    self._session_key(session_key),
                    json.dumps(session.to_dict()),
                )
        finally:
            try:
                lock.release()
            except Exception:
                # Lock may have already expired; nothing to release.
                pass


def get_session_manager(request: Request) -> SessionManager:
    return request.app.state.session
