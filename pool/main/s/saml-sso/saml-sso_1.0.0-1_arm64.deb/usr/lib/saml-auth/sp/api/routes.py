# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

import hashlib
import secrets
from urllib.parse import urlencode

from fastapi import APIRouter, BackgroundTasks, Depends, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.concurrency import run_in_threadpool

from api.models import *
from api.core.utils import (
    LogLevel,
    logger,
    generate_request_dict,
    format_origin,
    Constants,
)
from api.core.config import SamlConfig, get_config
from api.core.session import (
    AuthLevel,
    AuthStatus,
    SessionManager,
    SessionMissingError,
    SessionInvalidError,
    UserAuthenticationDTO,
    get_session_manager,
)
from api.vyos import VyosAPI, get_vyos_api
from api.saml import generate_settings_dict

from .authenticator import AuthenticationError, authenticate_user

router = APIRouter(prefix="/sso/saml/v2")


def success(data: dict):
    return {"success": True, "data": data}


def static_success(message: str) -> RedirectResponse:
    """Redirect a browser client to the static success page.

    The display message is passed via the query string; the page renders it as
    text. 303 forces a GET of the static page even when the originating request
    was a POST (e.g. the ACS endpoint).
    """
    return RedirectResponse(
        url=f"{Constants.STATIC_SUCCESS_PAGE}?{urlencode({'message': message})}",
        status_code=303,
    )


@router.post("/login/cli")
async def login_cli(
    request: Request,
    body: CliLoginRequestDTO,
    config: SamlConfig = Depends(get_config),
    session_manager: SessionManager = Depends(get_session_manager),
):
    logger.log(f"Received CLI login request")

    request_scheme = request.url.scheme
    hostname = body.hostname or config.serial_address or "<device-ip>"

    public_token, cli_secret = session_manager.create_session("cli", ip_addr=hostname)
    with session_manager.session(public_token) as session:
        session.user_authentication = UserAuthenticationDTO(
            local_name=body.expected_user,
            saml_id="",
            auth_status=AuthStatus.NO_RESPONSE,
            auth_level=AuthLevel.NONE,
        )
    link_host = format_origin(request_scheme, hostname)
    login_url = f"{link_host}/sso/saml/v2/login/s/{public_token}"

    return_data = {"url": login_url, "secret": cli_secret}
    return success(return_data)


@router.post("/login/web")
async def login_web(
    request: Request,
    body: WebLoginRequestDTO,
    session_manager: SessionManager = Depends(get_session_manager),
):
    logger.log(f"Recived Web login request")

    request_scheme = request.url.scheme
    hostname = body.hostname
    relay_state = body.relay_state

    public_token, web_secret = session_manager.create_session(
        "web", ip_addr=hostname, relay=relay_state
    )

    link_host = format_origin(request_scheme, hostname)
    login_url = f"{link_host}/sso/saml/v2/login/s/{public_token}"

    return_data = {"url": login_url, "secret": web_secret}

    return success(return_data)


@router.get("/login/s/{session_key}")
async def login_session(
    request: Request,
    session_key: str,
    session_manager: SessionManager = Depends(get_session_manager),
):
    with session_manager.session(session_key) as session:
        if session.is_claimed():
            raise SessionInvalidError(raw=False)

        settings = await generate_settings_dict(request, session)

        from onelogin.saml2.auth import OneLogin_Saml2_Auth

        login_request = await generate_request_dict(request)
        onelogin_auth = OneLogin_Saml2_Auth(login_request, old_settings=settings)
        sso_url = onelogin_auth.login(return_to=session.relay or "")

        response = RedirectResponse(url=sso_url, status_code=303)
        response.set_cookie(
            path="/",
            key="saml:session",
            value=session_key,
            httponly=True,
            secure=True,
            samesite="none",
        )

        claim_token = secrets.token_urlsafe(32)
        session.claim(claim_token)
        response.set_cookie(
            path="/sso/saml/v2",
            key="saml:session:claim",
            value=claim_token,
            httponly=True,
            secure=True,
            samesite="none",
        )

        return response


@router.post("/acs")
async def acs(
    request: Request,
    background_tasks: BackgroundTasks,
    SAMLResponse: str = Form(...),
    RelayState: str = Form(""),
    session_manager: SessionManager = Depends(get_session_manager),
):
    session_key = str(request.cookies.get("saml:session", ""))
    session_claim = str(request.cookies.get("saml:session:claim", ""))

    if not session_key or not session_claim:
        raise SessionMissingError(raw=False)

    with session_manager.session(session_key) as session:
        if not session.validate_claim(session_claim):
            raise SessionInvalidError(raw=False)

        settings = await generate_settings_dict(request, session)

        from onelogin.saml2.settings import OneLogin_Saml2_Settings
        from onelogin.saml2.response import OneLogin_Saml2_Response

        logger.log(f"Recived SAMLResponse: {SAMLResponse}")
        onelogin_settings = await run_in_threadpool(OneLogin_Saml2_Settings, settings)
        onelogin_response = await run_in_threadpool(
            OneLogin_Saml2_Response, onelogin_settings, SAMLResponse
        )

        try:
            await authenticate_user(
                session, request, onelogin_response, background_tasks
            )
        except AuthenticationError as e:
            if session.flow == "web" and RelayState:
                level = LogLevel.ERROR if e.status_code >= 500 else LogLevel.WARNING
                logger.log(f"{type(e).__name__}: {e.detail}", level)
                sep = "&" if "?" in RelayState else "?"
                error_url = f"{RelayState}{sep}{urlencode({'error': e.message})}"
                return RedirectResponse(url=error_url, status_code=303)
            raise

        if session.flow == "web" and RelayState:
            return RedirectResponse(url=RelayState, status_code=303)
        return static_success(
            "You have signed in successfully. You may return to your terminal."
        )


@router.post("/validate")
async def validate(
    validation: ValidationRequestDTO,
    session_manager: SessionManager = Depends(get_session_manager),
):
    session_key = validation.session
    secret = validation.secrete

    ro_session = session_manager.read_session(session_key)

    if hashlib.sha256(secret.encode()).hexdigest() != ro_session.hash:
        raise SessionInvalidError()

    user_authentication = ro_session.user_authentication
    if not user_authentication:
        return success(
            {"status": AuthStatus.NO_RESPONSE, "name": "", "level": AuthLevel.NONE}
        )

    payload = {
        "status": user_authentication.auth_status,
        "name": user_authentication.saml_id,
        "local_name": user_authentication.local_name,
        "level": user_authentication.auth_level,
    }
    if payload["status"] != AuthStatus.NO_RESPONSE:
        session_manager.delete_session(session_key)
    return success(payload)
