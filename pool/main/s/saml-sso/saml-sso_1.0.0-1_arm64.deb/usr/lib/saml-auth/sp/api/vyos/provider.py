# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Literal, Optional
import json

import aiohttp

from api.core.utils import Constants, logger, LogLevel
from api.core.errors import ApiError


class ApiException(ApiError):
    """Raised when an upstream VyOS API call fails."""

    status_code = 502
    message = "Upstream service error"


class ProviderOp(StrEnum):
    SET = "set"
    DELETE = "delete"
    READ = "showConfig"


class ProviderRoute(StrEnum):
    CONFIGURE = "configure"
    RETRIEVE = "retrieve"
    CONFIG_FILE = "config-file"


class Provider(ABC):
    def __init__(self) -> None: ...

    @abstractmethod
    async def call(
        self,
        op: ProviderOp,
        route: ProviderRoute,
        path: list[str],
        method: Literal["GET", "POST"] = "POST",
    ) -> dict: ...

    @abstractmethod
    async def call_batch(
        self,
        route: ProviderRoute,
        commands: list[tuple[ProviderOp, list[str]]],
        method: Literal["GET", "POST"] = "POST",
    ) -> dict: ...

    @abstractmethod
    async def save_config(self) -> dict: ...


class ApiProvider(Provider):
    def __init__(self, api_key: str) -> None:
        self._api_key = api_key
        self._base_url = (
            f"{Constants.API_DEFAULT_SCHEME}://"
            f"{Constants.API_DEFAULT_URL}:{Constants.API_DEFAULT_PORT}"
        )
        # aiohttp requires an SSL context; VERIFY_HTTP_API=False maps to
        # "skip TLS verification" for the loopback vyos-http-api endpoint.
        self._ssl = None if Constants.VERIFY_HTTP_API else False
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None

    async def _post_form(self, route: ProviderRoute, data_field: str) -> dict:
        session = await self._get_session()
        url = f"{self._base_url}/{route}"
        form = aiohttp.FormData()
        form.add_field("data", data_field)
        form.add_field("key", self._api_key)
        async with session.post(url, data=form, ssl=self._ssl) as resp:
            return await resp.json(content_type=None)

    async def call(
        self,
        op: ProviderOp,
        route: ProviderRoute,
        path: list[str],
        method: Literal["GET", "POST"] = "POST",
    ) -> dict:
        try:
            return await self._post_form(route, json.dumps({"op": op, "path": path}))
        except Exception as e:
            logger.log(f"API Call Failed: {str(e)}", LogLevel.ERROR)
            return {}

    async def call_batch(
        self,
        route: ProviderRoute,
        commands: list[tuple[ProviderOp, list[str]]],
        method: Literal["GET", "POST"] = "POST",
    ) -> dict:
        # The VyOS HTTPS API applies a JSON list of {op, path} objects in a
        # single atomic commit, avoiding partial-provisioning states between
        # per-command commits.
        try:
            batch = [{"op": op, "path": path} for op, path in commands]
            return await self._post_form(route, json.dumps(batch))
        except Exception as e:
            logger.log(f"API Batch Call Failed: {str(e)}", LogLevel.ERROR)
            return {}

    async def save_config(self) -> dict:
        # Persist the running configuration to /config/config.boot so that
        # JIT-provisioned users survive a reboot. commit (via /configure) only
        # applies to the volatile running config; the save is a separate step.
        try:
            return await self._post_form(
                ProviderRoute.CONFIG_FILE, json.dumps({"op": "save"})
            )
        except Exception as e:
            logger.log(f"API Save Config Failed: {str(e)}", LogLevel.ERROR)
            return {}
