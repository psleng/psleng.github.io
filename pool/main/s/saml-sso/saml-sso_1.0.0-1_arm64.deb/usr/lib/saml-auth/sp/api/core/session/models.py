# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from enum import StrEnum
import json
from typing import Literal, Optional
from pydantic import BaseModel, StrictStr


class AuthStatus(StrEnum):
    NO_RESPONSE = "NO_RESPONSE"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class AuthLevel(StrEnum):
    ADMIN = "ADMIN"
    OPERATOR = "OPERATOR"
    SUPER_OPERATOR = "SUPER_OPERATOR"
    NONE = "NONE"


class UserAuthenticationDTO(BaseModel):
    local_name: StrictStr
    saml_id: StrictStr
    auth_status: AuthStatus
    auth_level: AuthLevel


class Session:
    def __init__(
        self,
        application_secret_hash: str,
        flow: Literal["cli", "web"],
        relay: StrictStr = "",
        ip_addr: StrictStr = "",
    ) -> None:
        self._application_secret_hash: StrictStr = application_secret_hash
        self._flow: Literal["cli", "web"] = flow
        self._relay: StrictStr = relay
        self._ip_addr: StrictStr = ip_addr
        self._claimed: bool = False
        self._claim_token: StrictStr = ""
        self._user_authentication: Optional[UserAuthenticationDTO] = None

    @property
    def flow(self) -> Literal["cli", "web"]:
        return self._flow

    @property
    def ip_addr(self) -> str:
        return self._ip_addr

    @property
    def relay(self):
        return self._relay

    @property
    def user_authentication(self) -> Optional[UserAuthenticationDTO]:
        return self._user_authentication

    @user_authentication.setter
    def user_authentication(self, value: Optional[UserAuthenticationDTO]) -> None:
        self._user_authentication = value

    @property
    def hash(self) -> str:
        return self._application_secret_hash

    def claim(self, token: str):
        if not self._claimed:
            self._claimed = True
            self._claim_token = token

    def is_claimed(self) -> bool:
        return self._claimed

    def validate_claim(self, token: str) -> bool:
        if token == self._claim_token and self._claim_token:
            return True
        return False

    @classmethod
    def load_from_json(cls, json_str: str) -> "Session":
        session_dict = json.loads(json_str)

        flow = str(session_dict.get("flow", ""))
        application_secret_hash = str(session_dict.get("application_secret_hash", ""))
        relay = str(session_dict.get("relay", ""))
        ip_addr = str(session_dict.get("ip_addr", ""))

        session = cls(
            application_secret_hash,
            "cli" if flow == "cli" else "web",
            relay,
            ip_addr,
        )
        session._claimed = bool(session_dict.get("claimed", False))
        session._claim_token = str(session_dict.get("claim_token", ""))

        user_authentication = session_dict.get("user_authentication")
        if user_authentication is not None:
            session._user_authentication = UserAuthenticationDTO(**user_authentication)

        return session

    def to_dict(self) -> dict:
        return {
            "flow": self._flow,
            "application_secret_hash": self._application_secret_hash,
            "relay": self._relay,
            "ip_addr": self._ip_addr,
            "claimed": self._claimed,
            "claim_token": self._claim_token,
            "user_authentication": (
                self._user_authentication.model_dump()
                if self._user_authentication is not None
                else None
            ),
        }
