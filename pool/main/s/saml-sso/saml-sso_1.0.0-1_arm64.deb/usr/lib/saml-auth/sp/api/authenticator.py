# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from fastapi import BackgroundTasks, Request
from pydantic import StrictStr

from api.core.config import SamlConfig, get_config
from api.core.session import Session, UserAuthenticationDTO, AuthLevel, AuthStatus
from api.core.utils import logger, LogLevel
from api.core.errors import ApiError
from api.vyos import VyosAPI, ApiAction, ApiTarget, get_vyos_api
from api.saml import validate_saml_request

if TYPE_CHECKING:
    from onelogin.saml2.response import OneLogin_Saml2_Response


class AuthenticationError(ApiError):
    """User authentication could not be completed."""

    status_code = 403
    message = "Authentication failed"


class UserNotFoundError(AuthenticationError):
    """User could not be found"""


class UserMismatchError(AuthenticationError):
    """User does not match expected"""


def _match_jit_role(
    jit: dict, attributes: dict[str, list[str]]
) -> tuple[str, str | None] | None:
    role_map: list[tuple[str, str | None]] = [
        ("admin", None),
        ("super-operator", "super-operator"),
        ("operator", "default"),
    ]

    for role_key, group in role_map:
        role_rules = jit.get(role_key, {})
        if not role_rules:
            continue

        all_match = True
        for attr_name, required_values in role_rules.items():
            user_values = attributes.get(attr_name, [])
            if not all(v in user_values for v in required_values):
                all_match = False
                break

        if all_match:
            return role_key, group

    return None


def _current_operator_group(user_data: dict) -> Optional[str]:
    if "operator" in user_data:
        return str(user_data["operator"].get("group", "")) or None
    return None


def _schedule_user_commit(
    request: Request,
    background_tasks: BackgroundTasks,
    commands: list[dict],
    log_label: str,
) -> None:
    vyos_api: VyosAPI = get_vyos_api(request)

    async def _commit() -> None:
        try:
            await vyos_api.call(
                ApiAction.CONFIGURE, ApiTarget.USER, {"commands": commands}
            )
            logger.log(f"JIT commit succeeded ({log_label})", LogLevel.INFO)
        except Exception as e:
            logger.log(
                f"JIT background commit failed ({log_label}): {e}; "
                f"change will be re-attempted on next login",
                LogLevel.ERROR,
            )

    background_tasks.add_task(_commit)


def _try_jit_provision(
    request: Request,
    response: OneLogin_Saml2_Response,
    background_tasks: BackgroundTasks,
) -> tuple[str, dict]:
    config: SamlConfig = get_config(request)
    if not config.jit_enabled:
        return "", {}

    saml_id: str = str(response.get_nameid())
    local_name: str = saml_id.split("@")[0] if "@" in saml_id else saml_id
    local_name = local_name.replace(".", "_")

    attributes: dict[str, list[str]] = response.get_attributes()
    match = _match_jit_role(config.jit_config, attributes)
    if match is None:
        return "", {}

    _, matched_group = match

    commands: list[dict] = [
        {
            "op": "set",
            "path": [
                "system",
                "login",
                "user",
                local_name,
                "authentication",
                "saml",
                saml_id,
            ],
        },
        {
            "op": "set",
            "path": [
                "system",
                "login",
                "user",
                local_name,
                "authentication",
                "saml-jit",
            ],
        },
    ]
    if matched_group:
        commands.append(
            {
                "op": "set",
                "path": [
                    "system",
                    "login",
                    "user",
                    local_name,
                    "operator",
                    "group",
                    matched_group,
                ],
            }
        )

    synthesised: dict = {"authentication": {"saml": saml_id}}
    if matched_group:
        synthesised["operator"] = {"group": matched_group}

    _schedule_user_commit(
        request, background_tasks, commands, f"provision '{local_name}'"
    )

    return local_name, synthesised


def _reevaluate_jit_user(
    session: Session,
    request: Request,
    response: OneLogin_Saml2_Response,
    local_user_name: str,
    local_user_data: dict,
    background_tasks: BackgroundTasks,
) -> tuple[str, dict]:
    config: SamlConfig = get_config(request)
    if not config.jit_enabled:
        raise UserNotFoundError(
            "SAML JIT is not configured; JIT-provisioned users cannot log in",
            raw=False,
        )

    attributes: dict[str, list[str]] = response.get_attributes()
    match = _match_jit_role(config.jit_config, attributes)

    current_group = _current_operator_group(local_user_data)
    new_group = None if match is None else match[1]

    if match is None:
        logger.log(
            f"JIT re-eval: user '{local_user_name}' no longer matches any role, denying",
            LogLevel.WARNING,
        )
        raise UserNotFoundError(
            "SAML attributes no longer entitle this user to access", raw=False
        )

    if current_group == new_group:
        return local_user_name, local_user_data

    if session.flow != "web":
        logger.log(
            f"JIT re-eval: user '{local_user_name}' permission change detected on "
            f"non-web flow; denying login",
            LogLevel.WARNING,
        )
        raise UserNotFoundError(
            "SAML attributes have changed; re-authenticate via web login",
            raw=False,
        )

    commands: list[dict] = [
        {
            "op": "delete",
            "path": ["system", "login", "user", local_user_name, "operator"],
        }
    ]
    if new_group is not None:
        commands.append(
            {
                "op": "set",
                "path": [
                    "system",
                    "login",
                    "user",
                    local_user_name,
                    "operator",
                    "group",
                    new_group,
                ],
            }
        )

    _schedule_user_commit(
        request,
        background_tasks,
        commands,
        f"re-eval '{local_user_name}': {current_group} -> {new_group}",
    )

    updated = dict(local_user_data)
    if new_group is None:
        updated.pop("operator", None)
    else:
        updated["operator"] = {"group": new_group}
    return local_user_name, updated


async def _get_local_user(
    session: Session,
    request: Request,
    response: OneLogin_Saml2_Response,
    background_tasks: BackgroundTasks,
) -> tuple[str, dict]:
    vyos_api: VyosAPI = get_vyos_api(request)

    try:
        vyos_user_data: dict[str, dict] = await vyos_api.call(
            ApiAction.READ, ApiTarget.USERS
        )
        request_saml_id: StrictStr = str(response.get_nameid())
    except Exception as e:
        logger.log(f"Failed to resolve user for authentication: {e}", LogLevel.ERROR)
        raise UserNotFoundError(raw=False) from e

    local_user_name: StrictStr = ""
    local_user_data: dict = {}
    for user, user_data in vyos_user_data.items():
        local_user_authentication: dict = dict(user_data.get("authentication", {}))
        local_saml_id: str = str(local_user_authentication.get("saml", ""))

        if local_saml_id == request_saml_id:
            local_user_name = user
            local_user_data = user_data
            break

    if (not local_user_name or not local_user_data) and session.flow == "web":
        local_user_name, local_user_data = _try_jit_provision(
            request, response, background_tasks
        )

    if not local_user_name or not local_user_data:
        raise UserNotFoundError("User Not Found", raw=False)

    if "saml-jit" in local_user_data.get("authentication", {}):
        if session.flow != "web":
            logger.log(
                f"JIT user '{local_user_name}' attempted SAML login on "
                f"non-web flow ({session.flow}); denying",
                LogLevel.WARNING,
            )
            raise UserNotFoundError(
                "JIT-provisioned users can only sign in through the web flow; "
                "use a local password or SSH key for CLI access",
                raw=False,
            )

        local_user_name, local_user_data = _reevaluate_jit_user(
            session,
            request,
            response,
            local_user_name,
            local_user_data,
            background_tasks,
        )

    return local_user_name, local_user_data


def _determin_auth_level(local_user_data: dict) -> AuthLevel:
    if "operator" in local_user_data:
        operator_group: StrictStr = str(local_user_data["operator"].get("group", ""))
        match (operator_group):
            case "default":
                return AuthLevel.OPERATOR
            case "super-operator":
                return AuthLevel.SUPER_OPERATOR
            case _:
                raise AuthenticationError("Unknown operator group", raw=False)
    else:
        return AuthLevel.ADMIN


async def authenticate_user(
    session: Session,
    request: Request,
    response: OneLogin_Saml2_Response,
    background_tasks: BackgroundTasks,
):
    try:
        await validate_saml_request(session, request, response)

        request_saml_id: StrictStr = str(response.get_nameid())
        local_user_name, local_user_data = await _get_local_user(
            session, request, response, background_tasks
        )

        if (
            session.user_authentication
            and session.user_authentication.local_name != request_saml_id
        ):
            raise UserMismatchError("User name-id does not match expected", raw=False)

        auth_level = _determin_auth_level(local_user_data)

        session.user_authentication = UserAuthenticationDTO(
            local_name=local_user_name,
            saml_id=request_saml_id,
            auth_status=AuthStatus.SUCCESS,
            auth_level=auth_level,
        )
    except ApiError as e:
        session.user_authentication = UserAuthenticationDTO(
            local_name="",
            saml_id="",
            auth_status=AuthStatus.FAILED,
            auth_level=AuthLevel.NONE,
        )
        raise AuthenticationError(e.detail, message=e.message, raw=False) from e
    except Exception as e:
        session.user_authentication = UserAuthenticationDTO(
            local_name="",
            saml_id="",
            auth_status=AuthStatus.FAILED,
            auth_level=AuthLevel.NONE,
        )
        raise AuthenticationError(str(e), message=str(e), raw=False) from e
