# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from .errors import ApiError, register_error_handlers

__all__ = ["ApiError", "register_error_handlers"]
