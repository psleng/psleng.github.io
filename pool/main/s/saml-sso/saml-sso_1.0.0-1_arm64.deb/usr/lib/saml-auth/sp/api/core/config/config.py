# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

import ipaddress
import json
import os
import time
from pathlib import Path
from typing import Any

from fastapi import Request


from ..utils.logger import logger, LogLevel
from ..utils.constants import Constants

CONFIG_DIR = os.getenv("SAML_CONFIG_DIR", r"/etc/saml-sp")
CONFIG_FILE = r"saml.conf"

CACHE_DIR = os.getenv("SAML_CACHE_DIR", r"/var/lib/saml-sp")
CACHE_FILE = r".saml.cache"

METADATA_FETCH_TIMEOUT = 15

SIG_ALG_RSA_SHA256 = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"
SIG_ALG_DSA_SHA1 = "http://www.w3.org/2000/09/xmldsig#dsa-sha1"


def _default_serial_address() -> str:
    """Compute a default serial login address at runtime.

    Picks the lowest physical port (eth*/en*), resolving to its bridge master
    if the port is enslaved to one, and returns the lowest IPv4 address on it.
    Computed live so it always reflects the current interface addressing.
    """
    import netifaces as ni

    candidates = sorted(
        iface for iface in ni.interfaces() if iface.startswith(("eth", "en"))
    )
    for iface in candidates:
        target = iface
        master_link = f"/sys/class/net/{iface}/master"
        if os.path.islink(master_link):
            target = os.path.basename(os.readlink(master_link))
        addr_info = ni.ifaddresses(target).get(ni.AF_INET, [])
        ips = [a["addr"] for a in addr_info if a.get("addr")]
        if ips:
            ips.sort(key=lambda s: int(ipaddress.ip_address(s)))
            return ips[0]
    return ""


class EncryptionDTO:
    def __init__(self, encrypt_assertions: bool, encrypt_name_id: bool) -> None:
        self._assertions = encrypt_assertions
        self._name_id = encrypt_name_id

    @property
    def assertions(self) -> bool:
        return self._assertions

    @property
    def name_id(self) -> bool:
        return self._name_id


class SamlConfig:
    def __init__(self) -> None:
        cfg_dict: dict[str, Any] = {}
        try:
            with open(Path(CONFIG_DIR) / Path(CONFIG_FILE), "r") as cfg_file:
                cfg_dict = json.load(cfg_file)
        except:
            logger.log(
                f"Could not open config file at: {str(Path(CONFIG_DIR) / Path(CONFIG_FILE))}",
                level=LogLevel.ERROR,
            )
            return

        self._provider: str = cfg_dict.get("provider", "")
        self._metadata_url: str = cfg_dict.get("metadata-url", "")
        self._entity_id: str = cfg_dict.get("entity-id", "")
        self._acs_hostname: str = cfg_dict.get("acs-hostname", "")
        self._serial_address: str = cfg_dict.get("serial-address", "")
        self._jit_config: dict[str, Any] = cfg_dict.get("jit", {})
        self.cert: str = cfg_dict.get("cert", "")

        # SP signing/decryption credentials. Populated from the PEM files
        # written by the VyOS conf-mode script when a certificate is configured.
        self._sp_cert: str = ""
        self._sp_key: str = ""
        self._signature_algorithm: str = SIG_ALG_RSA_SHA256
        if self.cert:
            self._load_sp_credentials()

        cert_valid: bool = bool(self._sp_cert and self._sp_key)
        encryption_params: list[str] = cfg_dict.get("encrypt", [])
        self._encrypt = EncryptionDTO(
            ("assertions" in encryption_params) and cert_valid,
            ("name-id" in encryption_params) and cert_valid,
        )

        sign_params: list[str] = cfg_dict.get("sign", [])
        self._sign_messages = ("messages" in sign_params) and cert_valid

        cfg_params = (
            self._provider,
            self._metadata_url,
            self._entity_id,
        )
        for param in cfg_params:
            if not param:
                logger.log(f"Could not load cfg params", level=LogLevel.ERROR)

        self._metadata: dict = {}
        self._cache_path = Path(CACHE_DIR) / Path(CACHE_FILE)

    @property
    def provider(self) -> str:
        return self._provider

    @property
    def metadata_url(self) -> str:
        return self._metadata_url

    @property
    def entity_id(self) -> str:
        return self._entity_id

    @property
    def acs_hostname(self) -> str:
        return self._acs_hostname

    @property
    def serial_address(self) -> str:
        if self._serial_address:
            return self._serial_address
        return _default_serial_address()

    def _load_sp_credentials(self) -> None:
        """Load SP certificate/private key PEM material from disk.

        The VyOS conf-mode script writes the referenced PKI certificate to
        ``{CONFIG_DIR}/certs/{cert}_cert.pem`` and the matching private key to
        ``{cert}_key.pem``. The signature algorithm is then derived from the
        private key type (RSA or DSA).
        """
        cert_dir = Path(CONFIG_DIR) / "certs"
        cert_path = cert_dir / f"{self.cert}_cert.pem"
        key_path = cert_dir / f"{self.cert}_key.pem"
        try:
            self._sp_cert = cert_path.read_text()
            self._sp_key = key_path.read_text()
        except Exception as e:
            logger.log(
                f"Could not load SP certificate material for '{self.cert}': {e}",
                level=LogLevel.ERROR,
            )
            self._sp_cert = ""
            self._sp_key = ""
            return

        self._signature_algorithm = self._detect_signature_algorithm(self._sp_key)

    @staticmethod
    def _detect_signature_algorithm(key_pem: str) -> str:
        """Return the xmldsig signature algorithm URI matching the key type."""
        from cryptography.hazmat.primitives.serialization import (
            load_pem_private_key,
        )
        from cryptography.hazmat.primitives.asymmetric import dsa

        try:
            key = load_pem_private_key(key_pem.encode(), password=None)
        except Exception as e:
            logger.log(
                f"Could not parse SP private key, defaulting to RSA-SHA256: {e}",
                level=LogLevel.ERROR,
            )
            return SIG_ALG_RSA_SHA256

        if isinstance(key, dsa.DSAPrivateKey):
            return SIG_ALG_DSA_SHA1
        # RSA (and any other supported type) use RSA-SHA256
        return SIG_ALG_RSA_SHA256

    @property
    def has_signing_cert(self) -> bool:
        """True when a usable SP certificate and private key are loaded."""
        return bool(self._sp_cert and self._sp_key)

    @property
    def sp_cert(self) -> str:
        return self._sp_cert

    @property
    def sp_key(self) -> str:
        return self._sp_key

    @property
    def signature_algorithm(self) -> str:
        return self._signature_algorithm

    @property
    def encrypt(self) -> EncryptionDTO:
        return self._encrypt

    @property
    def sign_message(self) -> bool:
        return self._sign_messages

    @property
    def jit_config(self) -> dict:
        return self._jit_config

    @property
    def jit_enabled(self) -> bool:
        if not self._jit_config:
            return False
        return True

    @property
    def metadata(self) -> dict:
        if not self._metadata:
            for attempt in range(10):
                try:
                    from onelogin.saml2.idp_metadata_parser import (
                        OneLogin_Saml2_IdPMetadataParser,
                    )

                    parser = OneLogin_Saml2_IdPMetadataParser()
                    self._metadata = parser.parse_remote(
                        self._metadata_url,
                        timeout=METADATA_FETCH_TIMEOUT,
                        validate_cert=Constants.VERIFY_IDP,
                    )
                    logger.log(f"Loaded metadata from: {self._metadata_url}")
                    self._store_cache()
                    break
                except:
                    backoff = (attempt / 9) * 5.0
                    logger.log(
                        f"Attempt {attempt + 1}/10 failed to load metadata from: {self._metadata_url}. "
                        f"Retrying in {backoff:.1f}s...",
                        LogLevel.WARNING,
                    )
                    if attempt < 9:
                        time.sleep(backoff)
            else:
                logger.log(
                    f"All 10 attempts to load metadata from: {self._metadata_url} failed.",
                    LogLevel.ERROR,
                )
                self._load_cache()
        return self._metadata

    def _store_cache(self):
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            with open(self._cache_path, "w") as f:
                json.dump(self._metadata, f)
            logger.log(f"Cached metadata to: {self._cache_path}")
        except Exception as e:
            logger.log(f"Failed to cache metadata: {e}", LogLevel.ERROR)

    def _load_cache(self):
        try:
            with open(self._cache_path, "r") as f:
                self._metadata = json.load(f)
            logger.log(f"Loaded metadata from cache: {self._cache_path}")
        except Exception as e:
            logger.log(f"Failed to load metadata from cache: {e}", LogLevel.ERROR)


def get_config(request: Request) -> SamlConfig:
    return request.app.state.config
