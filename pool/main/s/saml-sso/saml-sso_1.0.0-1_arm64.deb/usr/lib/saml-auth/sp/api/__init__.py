# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from contextlib import asynccontextmanager

from .routes import router
from .core.errors import register_error_handlers

from .core.config import SamlConfig
from .core.session import SessionManager
from .core.utils import Constants

from .vyos import VyosAPI

# Directory holding the browser-facing result pages (sp/static), resolved
# relative to this package so it works regardless of the working directory.
STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.config = SamlConfig()
    app.state.session = SessionManager()
    app.state.api = VyosAPI("mykey")
    try:
        yield
    finally:
        await app.state.api.close()


def create_app() -> FastAPI:
    # Swagger/ReDoc/OpenAPI are disabled: this is an auth SP with no public API
    # surface, so the schema machinery is unnecessary import/runtime overhead and
    # an avoidable unauthenticated endpoint.
    app = FastAPI(
        lifespan=lifespan,
        openapi_url=None,
        docs_url=None,
        redoc_url=None,
    )
    app.include_router(router)
    app.mount(
        Constants.STATIC_URL_PREFIX,
        StaticFiles(directory=STATIC_DIR),
        name="static",
    )
    register_error_handlers(app)
    return app
