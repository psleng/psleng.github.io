# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from typing import Optional
from urllib.parse import urlencode

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse

from ..utils.logger import logger, LogLevel
from ..utils.constants import Constants


class ApiError(Exception):
    """Base class for every error surfaced to API clients.

    Concrete errors are defined alongside the domain they belong to (see the
    session and vyos modules) and inherit from this class, setting:

    - ``status_code``: the HTTP status returned to the client.
    - ``message``: a client-safe message returned in the response body.
    - ``raw``: when ``True`` (the default) the error is returned as a JSON
      envelope for programmatic clients. When ``False`` the client is a browser
      (e.g. the SAML ACS redirect flow) and is redirected to the static
      ``error.html`` page with the message carried in the query string.

    ``detail`` carries optional internal context for logging only and is never
    returned to the client. This module intentionally imports nothing from
    downstream packages so it can be moved without creating import cycles.
    """

    status_code: int = 500
    message: str = "Internal server error"
    raw: bool = True

    def __init__(
        self,
        detail: Optional[str] = None,
        *,
        message: Optional[str] = None,
        status_code: Optional[int] = None,
        raw: Optional[bool] = None,
    ) -> None:
        if message is not None:
            self.message = message
        if status_code is not None:
            self.status_code = status_code
        if raw is not None:
            self.raw = raw
        self.detail = detail or self.message
        super().__init__(self.detail)


def _envelope(message: str) -> dict:
    """Build the standard error response body used across the API."""
    return {"success": False, "data": {"error": message}}


def _static_error_redirect(message: str, status_code: int) -> RedirectResponse:
    """Redirect a browser client to the static error page.

    The display message and status are passed via the query string; the page
    renders them as text. 303 forces a GET of the static page even when the
    originating request was a POST (e.g. the ACS endpoint).
    """
    query = urlencode({"message": message, "status": status_code})
    return RedirectResponse(
        url=f"{Constants.STATIC_ERROR_PAGE}?{query}", status_code=303
    )


def register_error_handlers(app: FastAPI) -> None:
    """Install the single global error boundary for the application.

    Every ``ApiError`` (including domain errors that subclass it) is rendered
    with its own status code and client-safe message. Any other unexpected
    exception is logged and returned as a generic 500 so internal detail never
    leaks to clients.
    """

    @app.exception_handler(ApiError)
    async def _handle_api_error(request: Request, exc: ApiError):
        level = LogLevel.ERROR if exc.status_code >= 500 else LogLevel.WARNING
        logger.log(f"{type(exc).__name__}: {exc.detail}", level)
        if not exc.raw:
            return _static_error_redirect(exc.message, exc.status_code)
        return JSONResponse(status_code=exc.status_code, content=_envelope(exc.message))

    @app.exception_handler(Exception)
    async def _handle_unexpected(request: Request, exc: Exception) -> JSONResponse:
        logger.log(f"Unhandled error: {exc!r}", LogLevel.ERROR)
        return JSONResponse(status_code=500, content=_envelope("Internal server error"))
