# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

from api.core.config import get_config
from api.core.session import Session
from api.core.utils import generate_request_dict, get_ipaddr, format_origin
from api.core.errors import ApiError

if TYPE_CHECKING:
    from onelogin.saml2.response import OneLogin_Saml2_Response


class SamlValidationError(ApiError):
    """The SAML response could not be validated."""

    status_code = 401
    message = "Invalid login attempt"


async def generate_settings_dict(request: Request, session: Session) -> dict:
    config = get_config(request)
    acs_host = config.acs_hostname or get_ipaddr(session)

    # When a certificate is configured, the SP can sign its AuthnRequests and
    # decrypt encrypted assertions/NameIDs. The signature algorithm follows the
    # key type (RSA or DSA).

    settings = {
        "strict": True,
        "debug": True,
        "sp": {
            "entityId": config.entity_id,
            "assertionConsumerService": {
                "url": f"{format_origin(request.url.scheme, acs_host)}/sso/saml/v2/acs",
                "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
            },
            "NameIDFormat": "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress",
            "x509cert": config.sp_cert if config.has_signing_cert else "",
            "privateKey": config.sp_key if config.has_signing_cert else "",
        },
        "idp": config.metadata.get("idp", {}),  # Get IDP settings from metadata
        "security": {
            "authnRequestsSigned": config.has_signing_cert,  # Sign AuthnRequests when a cert is configured
            "wantAssertionsSigned": True,  # SP expects signed assertions (prevents fake responses)
            "wantMessagesSigned": config.sign_message,  # SP does not need messages additionally signed
            "wantNameId": True,  # SP wants NameID in response
            "wantNameIdEncrypted": config.encrypt.name_id,  # Require encrypted NameID when a cert is configured
            "wantAssertionsEncrypted": config.encrypt.assertions,  # Require encrypted assertions when a cert is configured
            "signatureAlgorithm": config.signature_algorithm,  # Derived from SP key type (RSA/DSA)
            "digestAlgorithm": "sha256",  # SP expects SHA256 for digests
            "rejectDeprecatedAlgorithm": True,  # Refuse inbound SHA1/MD5/DSA-SHA1 signatures
            "allowUnsolicitedResponses": False,  # SP does not allow login flow to start at IDP
            "allowRepeatAttributeName": True,  # Allow duplicate attribute names (KeyCloak sends these)
            "wantAttributeStatement": False,  # Attributes will be handled by router
        },
    }

    return settings


async def validate_saml_request(
    session: Session, request: Request, response: OneLogin_Saml2_Response
):
    login_request = await generate_request_dict(request)
    if not response.is_valid(login_request):
        raise SamlValidationError(
            f"Invalid login attempt: {response.get_error()}",
            message=f"Invalid login attempt: {response.get_error()}",
            raw=False,
        )
    if (
        session.user_authentication
        and session.user_authentication.local_name != response.get_nameid()
    ):
        raise SamlValidationError(f"Account missmatch error", raw=False)
