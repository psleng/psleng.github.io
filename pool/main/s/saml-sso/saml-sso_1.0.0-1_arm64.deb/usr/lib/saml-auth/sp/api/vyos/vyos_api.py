# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from enum import StrEnum
from typing import Awaitable, Callable

from fastapi import Request

from api.core.utils import logger, LogLevel

from .provider import ApiProvider, Provider
from .service.users import read_users, configure_user


class ApiAction(StrEnum):
    READ = "READ"
    CONFIGURE = "CONFIGURE"


class ApiTarget(StrEnum):
    USERS = "USERS"
    USER = "USER"


actions: dict[str, dict[str, Callable[[Provider, dict], Awaitable[dict]]]] = {
    ApiAction.READ: {ApiTarget.USERS: read_users},
    ApiAction.CONFIGURE: {ApiTarget.USER: configure_user},
}


class VyosAPI:
    def __init__(self, api_key: str) -> None:
        self._provider = ApiProvider(api_key)

    async def call(self, action: ApiAction, target: ApiTarget, data: dict = {}) -> dict:
        try:
            return await actions[action][target](self._provider, data)
        except Exception as e:
            logger.log(f"Error Calling VyosAPI: {str(e)}", LogLevel.ERROR)
            return {}

    async def close(self) -> None:
        # Called from the FastAPI lifespan shutdown to release the underlying
        # aiohttp ClientSession's connector cleanly.
        await self._provider.close()


def get_vyos_api(request: Request) -> VyosAPI:
    return request.app.state.api
