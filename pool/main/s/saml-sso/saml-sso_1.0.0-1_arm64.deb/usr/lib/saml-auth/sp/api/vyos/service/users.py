# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from ..provider import Provider, ProviderOp, ProviderRoute, ApiException


async def read_users(provider: Provider, data: dict) -> dict:
    api_reponse = await provider.call(
        ProviderOp.READ, ProviderRoute.RETRIEVE, ["system", "login", "user"]
    )
    success: bool = bool(api_reponse.get("success", False))
    if not success:
        error = str(api_reponse.get("error", ""))
        raise ApiException(
            f"Failed To Retrive User Data: {error if error else 'Unknown Error'}"
        )

    return dict(api_reponse.get("data", {}).get("user", {}))


async def configure_user(provider: Provider, data: dict) -> dict:
    """Configure a user via VyOS configure API.

    data should contain:
        - commands: list of {op, path} dicts (op is 'set' or 'delete')
            e.g. [{"op": "set", "path": ["system", "login", "user", "joe", ...]},
                  {"op": "delete", "path": ["system", "login", "user", "joe", "operator"]}]

    All commands are submitted in a single batched request so VyOS applies
    them atomically in one commit — avoids partially-provisioned users.
    """
    raw_commands = data.get("commands", [])
    if not raw_commands:
        return {"success": True}

    batch: list[tuple[ProviderOp, list[str]]] = []
    for cmd in raw_commands:
        op_str = cmd.get("op", "set")
        op = ProviderOp.DELETE if op_str == "delete" else ProviderOp.SET
        path = cmd.get("path", [])
        batch.append((op, path))

    api_response = await provider.call_batch(ProviderRoute.CONFIGURE, batch)
    success: bool = bool(api_response.get("success", False))
    if not success:
        error = str(api_response.get("error", ""))
        raise ApiException(
            f"Failed to configure user: {error if error else 'Unknown Error'}"
        )

    # /configure only applies to the volatile running config. Persist to
    # config.boot so JIT-provisioned users survive a reboot.
    save_response = await provider.save_config()
    if not bool(save_response.get("success", False)):
        error = str(save_response.get("error", ""))
        raise ApiException(
            f"Failed to save configuration: {error if error else 'Unknown Error'}"
        )

    return {"success": True}
