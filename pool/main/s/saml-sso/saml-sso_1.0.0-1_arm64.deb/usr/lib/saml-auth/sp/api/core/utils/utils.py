# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from fastapi import Request

import ipaddress

from ..session import Session


def format_host(host: str) -> str:
    """Bracket an IPv6 literal for safe use in a URL; pass through otherwise."""
    if not host or host.startswith("["):
        return host
    try:
        ipaddress.IPv6Address(host)
    except ValueError:
        return host
    return f"[{host}]"


def format_origin(scheme: str, host: str) -> str:
    """Build scheme://host[:port], omitting :443 for https and :80 for http."""
    from .constants import Constants

    formatted = format_host(host)
    port = Constants.API_DEFAULT_PORT
    if (scheme == "https" and port == 443) or (scheme == "http" and port == 80):
        return f"{scheme}://{formatted}"
    return f"{scheme}://{formatted}:{port}"


def get_ipaddr(session: Session) -> str:
    return session.ip_addr


async def generate_request_dict(request: Request) -> dict:
    form = await request.form()
    return {
        "https": "on" if request.url.scheme == "https" else "off",
        "http_host": request.headers.get("host", ""),
        "server_port": str(
            request.url.port or (443 if request.url.scheme == "https" else 80)
        ),
        "script_name": request.url.path,
        "get_data": dict(request.query_params),
        "post_data": dict(form),
    }
