# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

from pydantic import BaseModel, StrictStr


class CliLoginRequestDTO(BaseModel):
    hostname: StrictStr = ""
    expected_user: StrictStr


class WebLoginRequestDTO(BaseModel):
    hostname: StrictStr
    relay_state: StrictStr


class ValidationRequestDTO(BaseModel):
    session: StrictStr
    secrete: StrictStr
