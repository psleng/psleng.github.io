# Copyright (c) 2025-2026 Perle Systems Limited. All Rights Reserved.
# Proprietary and confidential. Unauthorized copying, distribution,
# or use of this file, via any medium, is strictly prohibited.

import re

NGINX_CONFIG_PATH = "/etc/nginx/sites-enabled/default"


def _get_https_port() -> int:
    """Read the HTTPS port from the nginx config. Falls back to 443."""
    try:
        with open(NGINX_CONFIG_PATH, "r") as f:
            for line in f:
                if "listen" in line and "ssl" in line:
                    m = re.search(r"(\d+)\s+ssl", line)
                    if m:
                        return int(m.group(1))
    except Exception:
        pass
    return 443


class Constants:
    VERIFY_HTTP_API = False
    VERIFY_IDP = True

    API_DEFAULT_PORT = _get_https_port()
    API_DEFAULT_SCHEME = "https"
    API_DEFAULT_URL = "127.0.0.1"

    # Static, browser-facing result pages (served from sp/static). The message
    # to display is passed to each page via the ``message`` query parameter.
    STATIC_URL_PREFIX = "/sso/saml/v2/static"
    STATIC_ERROR_PAGE = f"{STATIC_URL_PREFIX}/error.html"
    STATIC_SUCCESS_PAGE = f"{STATIC_URL_PREFIX}/success.html"
