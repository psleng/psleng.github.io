#ifndef _COMPAT_NET_IPV6_STUBS_H
#define _COMPAT_NET_IPV6_STUBS_H

#include "../../compat/config.h"

#ifdef HAVE_IPV6_STUBS_H
#include_next <net/ipv6_stubs.h>
#endif

#endif /* _COMPAT_NET_IPV6_STUBS_H */
