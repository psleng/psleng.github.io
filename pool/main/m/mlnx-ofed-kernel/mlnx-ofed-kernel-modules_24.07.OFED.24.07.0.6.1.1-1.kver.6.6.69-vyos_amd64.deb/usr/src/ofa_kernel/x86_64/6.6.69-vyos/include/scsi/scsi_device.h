#ifndef _COMPAT_SCSI_SCSI_DEVICE_H
#define _COMPAT_SCSI_SCSI_DEVICE_H

#include "../../compat/config.h"

#include_next <scsi/scsi_device.h>

#endif /* _COMPAT_SCSI_SCSI_DEVICE_H */
