/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* access_ok has 3 parameters */
/* #undef HAVE_ACCESS_OK_HAS_3_PARAMS */

/* acpi_storage_d3 exist */
#define HAVE_ACPI_STORAGE_D3 1

/* adjfine is defined */
#define HAVE_ADJUST_BY_SCALED_PPM 1

/* mm.h has assert_fault_locked */
#define HAVE_ASSERT_FAULT_LOCKED 1

/* __assign_str has one param */
/* #undef HAVE_ASSIGN_STR_1_PARAM */

/* atomic_fetch_add_unless is defined */
#define HAVE_ATOMIC_FETCH_ADD_UNLESS 1

/* atomic_pinned_vm is defined */
#define HAVE_ATOMIC_PINNED_VM 1

/* __auto_type exists */
#define HAVE_AUTO_TYPE 1

/* linux/blkdev.h has bdev_discard_granularity */
#define HAVE_BDEV_DISCARD_GRANULARITY 1

/* linux/blkdev.h has bdev_file_open_by_path */
/* #undef HAVE_BDEV_FILE_OPEN_BY_PATH */

/* bdev_is_partition is defined */
#define HAVE_BDEV_IS_PARTITION 1

/* blkdev.h has bdev_max_zone_append_sectors */
#define HAVE_BDEV_MAX_ZONE_APPEND_SECTORS 1

/* bdev_nr_bytes exist */
#define HAVE_BDEV_NR_BYTES 1

/* genhd.h has bdev_nr_sectors */
#define HAVE_BDEV_NR_SECTORS 1

/* blkdev.h has bdev_nr_zones */
#define HAVE_BDEV_NR_ZONES 1

/* bdev_release has holder param */
#define HAVE_BDEV_RELEASE 1

/* bdev_start_io_acct is defined */
/* #undef HAVE_BDEV_START_IO_ACCT */

/* bdev_start_io_acct is defined */
#define HAVE_BDEV_START_IO_ACCT_3_PARAM 1

/* linux/blkdev.h has bdev_write_cache */
#define HAVE_BDEV_WRITE_CACHE 1

/* genhd.h has bd_set_nr_sectors */
/* #undef HAVE_BD_SET_NR_SECTORS */

/* genhd.h has bd_set_size */
/* #undef HAVE_BD_SET_SIZE */

/* bio.h has bio_add_zone_append_page */
#define HAVE_BIO_ADD_ZONE_APPEND_PAGE 1

/* struct bio has member bi_bdev */
#define HAVE_BIO_BI_BDEV 1

/* struct bio has member bi_cookie */
#define HAVE_BIO_BI_COOKIE 1

/* struct bio has member bi_disk */
/* #undef HAVE_BIO_BI_DISK */

/* bio_for_each_bvec is defined in bio.h */
#define HAVE_BIO_FOR_EACH_BVEC 1

/* bio.h bio_init has 3 parameters */
/* #undef HAVE_BIO_INIT_3_PARAMS */

/* bio.h bio_init has 5 parameters */
#define HAVE_BIO_INIT_5_PARAMS 1

/* bio.h has bio_integrity_map_user */
/* #undef HAVE_BIO_INTEGRITY_MAP_USER */

/* if bio.h has bio_max_segs */
#define HAVE_BIO_MAX_SEGS 1

/* if bio.h has BIO_MAX_VECS */
#define HAVE_BIO_MAX_VECS 1

/* blkdev.h has bio_split_to_limits */
#define HAVE_BIO_SPLIT_TO_LIMITS 1

/* bdev_start_io_acct is defined */
/* #undef HAVE_BIO_START_IO_ACCT */

/* bitmap_zalloc_node is defined */
#define HAVE_BITMAP_ZALLOC_NODE 1

/* include/linux/bits.h exists */
#define HAVE_BITS_H 1

/* blkcg_get_fc_appid is defined */
#define HAVE_BLKCG_GET_FC_APPID 1

/* linux/blkdev.h has bio_integrity_bytes */
/* #undef HAVE_BLKDEV_BIO_INTEGRITY_BYTES */

/* blkdev_compat_ptr_ioctl is defined */
#define HAVE_BLKDEV_COMPAT_PTR_IOCTL 1

/* dma_map_bvec exist */
#define HAVE_BLKDEV_DMA_MAP_BVEC 1

/* blkdev_issue_flush has 1 params */
#define HAVE_BLKDEV_ISSUE_FLUSH_1_PARAM 1

/* blkdev_issue_flush has 2 params */
/* #undef HAVE_BLKDEV_ISSUE_FLUSH_2_PARAM */

/* blkdev_put has holder param */
#define HAVE_BLKDEV_PUT_HOLDER 1

/* linux/blkdev.h has req_bvec */
#define HAVE_BLKDEV_REQ_BVEC 1

/* linux/blkdev.h has blkdev_zone_mgmt with 5 params */
/* #undef HAVE_BLKDEV_ZONE_MGMT_5_PARAMS */

/* genhd.h has blk_alloc_disk */
#define HAVE_BLK_ALLOC_DISK_1_PARAM 1

/* genhd.h has blk_alloc_disk */
/* #undef HAVE_BLK_ALLOC_DISK_2_PARAMS */

/* blk_alloc_queue_node has 3 args */
/* #undef HAVE_BLK_ALLOC_QUEUE_NODE_3_ARGS */

/* linux/blkdev.h has blk_alloc_queue_rh */
/* #undef HAVE_BLK_ALLOC_QUEUE_RH */

/* blk_cleanup_disk() is defined */
/* #undef HAVE_BLK_CLEANUP_DISK */

/* blk_execute_rq has 2 params */
#define HAVE_BLK_EXECUTE_RQ_2_PARAM 1

/* blk_execute_rq has 3 params */
/* #undef HAVE_BLK_EXECUTE_RQ_3_PARAM */

/* blk_execute_rq has 4 params */
/* #undef HAVE_BLK_EXECUTE_RQ_4_PARAM */

/* blk_execute_rq_nowait has 2 params */
#define HAVE_BLK_EXECUTE_RQ_NOWAIT_2_PARAM 1

/* blk_execute_rq_nowait has 3 params */
/* #undef HAVE_BLK_EXECUTE_RQ_NOWAIT_3_PARAM */

/* blk_execute_rq_nowait has 5 params */
/* #undef HAVE_BLK_EXECUTE_RQ_NOWAIT_5_PARAM */

/* linux/blk-mq.h has struct blk_holder_ops */
#define HAVE_BLK_HOLDER_OPS 1

/* BLK_INTEGRITY_DEVICE_CAPABLE is defined */
/* #undef HAVE_BLK_INTEGRITY_DEVICE_CAPABLE */

/* linux/blk-integrity.h exists */
#define HAVE_BLK_INTEGRITY_H 1

/* struct blk_integrity has pi_offset */
/* #undef HAVE_BLK_INTEGRITY_PI_OFFSET */

/* blk_mark_disk_dead exist */
#define HAVE_BLK_MARK_DISK_DEAD 1

/* BLK_MAX_WRITE_HINTS is defined */
/* #undef HAVE_BLK_MAX_WRITE_HINTS */

/* blk_mq_alloc_disk is defined */
#define HAVE_BLK_MQ_ALLOC_DISK_2_PARAMS 1

/* blk_mq_alloc_disk has 3 param */
/* #undef HAVE_BLK_MQ_ALLOC_DISK_3_PARAMS */

/* blk_mq_alloc_queue is defined */
/* #undef HAVE_BLK_MQ_ALLOC_QUEUE */

/* blk_types.h has BLK_STS_ZONE_ACTIVE_RESOURCE */
#define HAVE_BLK_MQ_BLK_STS_ZONE_ACTIVE_RESOURCE 1

/* linux/blk-mq.h has busy_tag_iter_fn return bool */
#define HAVE_BLK_MQ_BUSY_TAG_ITER_FN_BOOL_2_PARAMS 1

/* linux/blk-mq.h has busy_tag_iter_fn return bool */
/* #undef HAVE_BLK_MQ_BUSY_TAG_ITER_FN_BOOL_3_PARAMS */

/* linux/blk-mq.h has blk_mq_complete_request_remote */
#define HAVE_BLK_MQ_COMPLETE_REQUEST_REMOTE 1

/* blk-mq.h has blk_mq_complete_request_sync */
/* #undef HAVE_BLK_MQ_COMPLETE_REQUEST_SYNC */

/* blk_mq_destroy_queue is defined */
#define HAVE_BLK_MQ_DESTROY_QUEUE 1

/* blk-mq.h has blk_mq_hctx_set_fq_lock_class */
#define HAVE_BLK_MQ_HCTX_SET_FQ_LOCK_CLASS 1

/* blk-mq.h has enum hctx_type */
#define HAVE_BLK_MQ_HCTX_TYPE 1

/* struct blk_mq_ops has commit_rqs */
#define HAVE_BLK_MQ_OPS_COMMIT_RQS 1

/* function map_queues returns int */
/* #undef HAVE_BLK_MQ_OPS_MAP_QUEUES_RETURN_INT */

/* struct blk_mq_ops has poll 1 arg */
/* #undef HAVE_BLK_MQ_OPS_POLL_1_ARG */

/* struct blk_mq_ops has poll 2 args */
#define HAVE_BLK_MQ_OPS_POLL_2_ARG 1

/* struct blk_mq_ops has queue_rqs */
#define HAVE_BLK_MQ_OPS_QUEUE_RQS 1

/* timeout from struct blk_mq_ops has 1 param */
#define HAVE_BLK_MQ_OPS_TIMEOUT_1_PARAM 1

/* blk_mq_quiesce_tagset is defined */
#define HAVE_BLK_MQ_QUEIESCE_TAGSET 1

/* linux/blk-mq.h has struct blk_mq_queue_map */
#define HAVE_BLK_MQ_QUEUE_MAP 1

/* linux/blk-mq.h has blk_mq_request_completed */
#define HAVE_BLK_MQ_REQUEST_COMPLETED 1

/* blk_mq_rq_state is defined */
#define HAVE_BLK_MQ_RQ_STATE 1

/* linux/blk-mq.h has blk_mq_set_request_complete */
#define HAVE_BLK_MQ_SET_REQUEST_COMPLETE 1

/* linux/blk-mq.h has blk_mq_tagset_wait_completed_request */
#define HAVE_BLK_MQ_TAGSET_WAIT_COMPLETED_REQUEST 1

/* blk_mq_tag_set has member map */
#define HAVE_BLK_MQ_TAG_SET_HAS_MAP 1

/* blk_mq_tag_set has member nr_maps */
#define HAVE_BLK_MQ_TAG_SET_HAS_NR_MAP 1

/* blk_mq_wait_quiesce_done is defined */
#define HAVE_BLK_MQ_WAIT_QUIESCE_DONE 1

/* blk_mq_wait_quiesce_done with tagset param is defined */
#define HAVE_BLK_MQ_WAIT_QUIESCE_DONE_TAGSET 1

/* bio.h blk_next_bio has 3 parameters */
/* #undef HAVE_BLK_NEXT_BIO_3_PARAMS */

/* blk_opf_t is defined */
#define HAVE_BLK_OPF_T 1

/* linux/blkdev.h has blk_op_str */
#define HAVE_BLK_OP_STR 1

/* blk_queue_make_request existing */
/* #undef HAVE_BLK_QUEUE_MAKE_REQUEST */

/* blk_queue_max_active_zones exist */
/* #undef HAVE_BLK_QUEUE_MAX_ACTIVE_ZONES */

/* blk_queue_split has 1 param */
/* #undef HAVE_BLK_QUEUE_SPLIT_1_PARAM */

/* blkdev.h has blk_queue_zone_sectors */
/* #undef HAVE_BLK_QUEUE_ZONE_SECTORS */

/* if blk-mq.h has blk_rq_bio_prep */
#define HAVE_BLK_RQ_BIO_PREP 1

/* blk_rq_map_user_iv is defined */
#define HAVE_BLK_RQ_MAP_USER_IO 1

/* linux/blk-mq.h has blk_should_fake_timeout */
#define HAVE_BLK_SHOULD_FAKE_TIMEOUT 1

/* blk_types.h has BLK_STS_RESV_CONFLICT */
#define HAVE_BLK_STS_RESV_CONFLICT 1

/* PAGE_SECTORS_SHIFT is defined */
#define HAVE_BLK_TYPES_PAGE_SECTORS_SHIFT 1

/* REQ_HIPRI is defined */
/* #undef HAVE_BLK_TYPES_REQ_HIPRI */

/* enum req_opf is defined */
/* #undef HAVE_BLK_TYPES_REQ_OPF */

/* linux/blkdev.h has bdev_zone_no */
#define HAVE_BLK_ZONE_NO 1

/* struct block_device_operations has submit_bio */
#define HAVE_BLOCK_DEVICE_OPERATIONS_SUBMIT_BIO 1

/* bpf_prog_add\bfs_prog_inc functions return struct */
/* #undef HAVE_BPF_PROG_ADD_RET_STRUCT */

/* filter.h has bpf_warn_invalid_xdp_action get 3 params */
#define HAVE_BPF_WARN_IVALID_XDP_ACTION_GET_3_PARAMS 1

/* bus_find_device get const */
#define HAVE_BUS_FIND_DEVICE_GET_CONST 1

/* bus_type remove function return void */
#define HAVE_BUS_TYPE_REMOVE_RETURN_VOID 1

/* linux/bvec.h has bvec_set_page */
#define HAVE_BVEC_SET_PAGE 1

/* bvec_set_virt is defined */
#define HAVE_BVEC_SET_VIRT 1

/* linux/bvec.h has bvec_virt */
#define HAVE_BVEC_VIRT 1

/* cancel_work is exported by the kernel */
#define HAVE_CANCEL_WORK_EXPORTED 1

/* __free anotation for kvfree could be used */
/* #undef HAVE_CAN_USE_KVFREE_CLEANUP_NO_WRAPPER */

/* __cgroup_bpf_run_filter_sysctl have 7 parameters */
#define HAVE_CGROUP_BPF_RUN_FILTER_SYSCTL_7_PARAMETERS 1

/* vxlan_build_gbp_hdr is defined */
#define HAVE_CHECK_VXLAN_BUILD_GBP_HDR 1

/* VXLAN_GBP_MASK is defined */
#define HAVE_CHECK_VXLAN_GBP_MASK 1

/* access_ok has check_zeroed_user */
#define HAVE_CHECK_ZEROED_USER 1

/* class_create get 1 param */
#define HAVE_CLASS_CREATE_GET_1_PARAM 1

/* dev_uevent get const struct device */
#define HAVE_CLASS_DEV_UEVENT_CONST_DEV 1

/* class_register get const */
#define HAVE_CLASS_REGISTER_GET_CONST 1

/* include/linux/cleanup.h exists */
#define HAVE_CLEANUP_H 1

/* compat_ptr_ioctl is exported by the kernel */
#define HAVE_COMPAT_PTR_IOCTL_EXPORTED 1

/* linux/compat.h has compat_uptr_t */
#define HAVE_COMPAT_UPTR_T 1

/* bus_type enty of struct device is const */
#define HAVE_CONST_BUS_TYPE_FOR_STRUCT_DEVICE 1

/* const __read_once_size exist */
/* #undef HAVE_CONST_READ_ONCE_SIZE */

/* include/linux/container_of.h exists */
#define HAVE_CONTAINER_OF_H 1

/* kernel supports v6.10-rc1: convert __be16 tunnel flags to bitmaps */
/* #undef HAVE_CONVERT_BE16_TUNNEL_FLAGS_TO_BITMAPS */

/* struct ctl_table have "child" field */
/* #undef HAVE_CTL_TABLE_CHILD */

/* DEFINE_SEQ_ATTRIBUTE is defined */
#define HAVE_DEFINE_SEQ_ATTRIBUTE 1

/* struct vfio_device_ops has detach_ioas */
#define HAVE_DETACH_IOAS_NDO 1

/* genhd.h has device_add_disk */
/* #undef HAVE_DEVICE_ADD_DISK */

/* genhd.h has device_add_disk 3 args and must_check */
#define HAVE_DEVICE_ADD_DISK_3_ARGS_AND_RETURN 1

/* genhd.h has device_add_disk */
#define HAVE_DEVICE_ADD_DISK_3_ARGS_NO_RETURN 1

/* genhd.h has device_add_disk retrun */
#define HAVE_DEVICE_ADD_DISK_RETURN 1

/* devlink.h has devlink_alloc get 3 params */
#define HAVE_DEVLINK_ALLOC_GET_3_PARAMS 1

/* include/net/devlink.h devlink_alloc_ns defined */
#define HAVE_DEVLINK_ALLOC_NS 1

/* devlink_param_driverinit_value_get exist */
/* #undef HAVE_DEVLINK_DRIVERINIT_VAL */

/* struct devlink_ops.eswitch_mode_set has extack */
#define HAVE_DEVLINK_ESWITCH_MODE_SET_EXTACK 1

/* devlink_flash_update_end_notify */
/* #undef HAVE_DEVLINK_FLASH_UPDATE_END_NOTIFY */

/* devlink_flash_update_params has struct firmware fw */
#define HAVE_DEVLINK_FLASH_UPDATE_PARAMS_HAS_STRUCT_FW 1

/* devlink_flash_update_status_notify */
#define HAVE_DEVLINK_FLASH_UPDATE_STATUS_NOTIFY 1

/* devlink.h has devlink_fmsg_binary_pair_nest_start is defined */
#define HAVE_DEVLINK_FMSG_BINARY_PAIR_NEST_START 1

/* devlink_fmsg_binary_pair_put exists */
#define HAVE_DEVLINK_FMSG_BINARY_PAIR_PUT_ARG_U32_RETURN_INT 1

/* devlink_fmsg_binary_pair_put exists */
/* #undef HAVE_DEVLINK_FMSG_BINARY_PAIR_PUT_ARG_U32_RETURN_VOID */

/* devlink_fmsg_binary_put exists */
#define HAVE_DEVLINK_FMSG_BINARY_PUT 1

/* eswitch_encap_mode_set/get is defined with enum */
#define HAVE_DEVLINK_HAS_ESWITCH_ENCAP_MODE_SET_GET_WITH_ENUM 1

/* flash_update is defined */
#define HAVE_DEVLINK_HAS_FLASH_UPDATE 1

/* info_get is defined */
#define HAVE_DEVLINK_HAS_INFO_GET 1

/* port_function_roce/mig_get/set is defined */
/* #undef HAVE_DEVLINK_HAS_PORT_FN_ROCE_MIG */

/* port_function_hw_addr_get/set is defined */
/* #undef HAVE_DEVLINK_HAS_PORT_FUNCTION_HW_ADDR_GET */

/* port_function_state_get/set is defined */
/* #undef HAVE_DEVLINK_HAS_PORT_FUNCTION_STATE_GET */

/* rate functions are defined */
#define HAVE_DEVLINK_HAS_RATE_FUNCTIONS 1

/* reload is defined */
/* #undef HAVE_DEVLINK_HAS_RELOAD */

/* reload_up/down is defined */
#define HAVE_DEVLINK_HAS_RELOAD_UP_DOWN 1

/* devlink_health_reporter_create has 4 args */
#define HAVE_DEVLINK_HEALTH_REPORTER_CREATE_4_ARGS 1

/* devlink_health_reporter_create has 5 args */
/* #undef HAVE_DEVLINK_HEALTH_REPORTER_CREATE_5_ARGS */

/* devlink_health_reporter_state_update exist */
#define HAVE_DEVLINK_HEALTH_REPORTER_STATE_UPDATE 1

/* structs devlink_health_reporter & devlink_fmsg exist */
#define HAVE_DEVLINK_HEALTH_REPORT_BASE_SUPPORT 1

/* devlink.h has devlink_info_driver_name_put */
/* #undef HAVE_DEVLINK_INFO_DRIVER_NAME_PUT */

/* devlink_info_version_fixed_put exist */
#define HAVE_DEVLINK_INFO_VERSION_FIXED_PUT 1

/* kernel supports v6.7 devlink instances relationships exposure */
/* #undef HAVE_DEVLINK_INSTANCES_RELATIONSHIPS_EXPOSURE */

/* port_fn_ipsec_crypto_get is defined */
#define HAVE_DEVLINK_IPSEC_CRYPTO 1

/* port_fn_ipsec_packet_get is defined */
#define HAVE_DEVLINK_IPSEC_PACKET 1

/* devlink_net exist */
#define HAVE_DEVLINK_NET 1

/* devlink_params_publish is exported by the kernel */
/* #undef HAVE_DEVLINK_PARAMS_PUBLISHED */

/* devlink enum has HAVE_DEVLINK_PARAM_GENERIC_ID_ENABLE_ETH */
#define HAVE_DEVLINK_PARAM_GENERIC_ID_ENABLE_ETH 1

/* enum DEVLINK_PARAM_GENERIC_ID_ENABLE_REMOTE_DEV_RESET exist */
#define HAVE_DEVLINK_PARAM_GENERIC_ID_ENABLE_REMOTE_DEV_RESET 1

/* struct devlink_param exist */
#define HAVE_DEVLINK_PARAM_GENERIC_ID_ENABLE_ROCE 1

/* devlink enum has DEVLINK_PARAM_GENERIC_ID_IO_EQ_SIZE */
#define HAVE_DEVLINK_PARAM_GENERIC_ID_IO_EQ_SIZE 1

/* devlink_param_publish is exported by the kernel */
/* #undef HAVE_DEVLINK_PARAM_PUBLISH */

/* devlink.h devlink_param_register defined */
/* #undef HAVE_DEVLINK_PARAM_REGISTER */

/* struct devlink_param set function pointer has extack parameter */
/* #undef HAVE_DEVLINK_PARAM_SET_FUNCTION_POINTER_HAS_EXTACK */

/* devlink_port_attrs_set has 2 parameters */
#define HAVE_DEVLINK_PORT_ATRRS_SET_GET_2_PARAMS 1

/* devlink_port_attrs_set has 5 parameters */
/* #undef HAVE_DEVLINK_PORT_ATRRS_SET_GET_5_PARAMS */

/* devlink_port_attrs_set has 7 parameters */
/* #undef HAVE_DEVLINK_PORT_ATRRS_SET_GET_7_PARAMS */

/* devlink_port_attrs_pci_pf_set has 2 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_PF_SET_2_PARAMS */

/* devlink_port_attrs_pci_pf_set has 4 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_PF_SET_4_PARAMS */

/* devlink_port_attrs_pci_pf_set has 4 params and controller num */
#define HAVE_DEVLINK_PORT_ATTRS_PCI_PF_SET_CONTROLLER_NUM 1

/* devlink.h devlink_port_attrs_pci_pf_set get 2 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_PF_SET_GET_2_PARAMS */

/* devlink.h has devlink_port_attrs_pci_sf_set get 4 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_SF_SET_GET_4_PARAMS */

/* devlink.h has devlink_port_attrs_pci_sf_set get 5 params */
#define HAVE_DEVLINK_PORT_ATTRS_PCI_SF_SET_GET_5_PARAMS 1

/* devlink.h devlink_port_attrs_pci_vf_set get 3 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_VF_SET_GET_3_PARAMS */

/* devlink_port_attrs_pci_vf_set has 5 params */
/* #undef HAVE_DEVLINK_PORT_ATTRS_PCI_VF_SET_GET_5_PARAMS */

/* devlink_port_attrs_pci_vf_set has 5 params and controller num */
#define HAVE_DEVLINK_PORT_ATTRS_PCI_VF_SET_GET_CONTROLLER_NUM 1

/* enum DEVLINK_PORT_FLAVOUR_PCI_SF is defined */
#define HAVE_DEVLINK_PORT_FLAVOUR_PCI_SF 1

/* enum DEVLINK_PORT_FLAVOUR_VIRTUAL is defined */
#define HAVE_DEVLINK_PORT_FLAVOUR_VIRTUAL 1

/* enum devlink_port_fn_opstate exist */
#define HAVE_DEVLINK_PORT_FN_OPSTATE 1

/* enum devlink_port_fn_state exist */
#define HAVE_DEVLINK_PORT_FN_STATE 1

/* struct devlink_port has attrs.switch_id */
#define HAVE_DEVLINK_PORT_HAS_SWITCH_ID 1

/* struct devlink_port has attrs.switch_port */
/* #undef HAVE_DEVLINK_PORT_HAS_SWITCH_PORT */

/* devlink_health_reporter_create is defined */
#define HAVE_DEVLINK_PORT_HEALTH_REPORTER_CREATE 1

/* devlink_port_health_reporter_destroy is defined */
/* #undef HAVE_DEVLINK_PORT_HEALTH_REPORTER_DESTROY */

/* struct devlink_port_ops has max_io_eqs */
/* #undef HAVE_DEVLINK_PORT_MAX_IO_EQS */

/* devlink struct devlink_port_new_attrs exist */
#define HAVE_DEVLINK_PORT_NEW_ATTRS_STRUCT 1

/* struct devlink_port_ops exists */
#define HAVE_DEVLINK_PORT_OPS 1

/* devlink_port_type_eth_set get 1 param */
#define HAVE_DEVLINK_PORT_TYPE_ETH_SET_GET_1_PARAM 1

/* devlink_port_type_eth_set exist */
/* #undef HAVE_DEVLINK_PORT_TYPE_ETH_SET_GET_2_PARAM */

/* devlink.h has devlink_register get 1 params */
#define HAVE_DEVLINK_REGISTER_GET_1_PARAMS 1

/* devlink_reload_disable exist */
/* #undef HAVE_DEVLINK_RELOAD_DISABLE */

/* reload_down has 3 params */
/* #undef HAVE_DEVLINK_RELOAD_DOWN_HAS_3_PARAMS */

/* reload_down has 5 params */
#define HAVE_DEVLINK_RELOAD_DOWN_SUPPORT_RELOAD_ACTION 1

/* devlink_reload_enable exist */
/* #undef HAVE_DEVLINK_RELOAD_ENABLE */

/* devlink.h has devlink_resources_unregister 1 params */
#define HAVE_DEVLINK_RESOURCES_UNREGISTER_1_PARAMS 1

/* devlink.h has devlink_resources_unregister 2 params */
/* #undef HAVE_DEVLINK_RESOURCES_UNREGISTER_2_PARAMS */

/* devlink.h has devlink_set_features */
/* #undef HAVE_DEVLINK_SET_FEATURES */

/* devlink.h has devlink_to_dev */
#define HAVE_DEVLINK_TO_DEV 1

/* devlink_ops.trap_action_set has 4 args */
#define HAVE_DEVLINK_TRAP_ACTION_SET_4_ARGS 1

/* devlink has DEVLINK_TRAP_GENERIC_ID_DMAC_FILTER */
#define HAVE_DEVLINK_TRAP_DMAC_FILTER 1

/* devlink has devlink_trap_groups_register */
#define HAVE_DEVLINK_TRAP_GROUPS_REGISTER 1

/* devlink has DEVLINK_TRAP_GROUP_GENERIC with 2 args */
#define HAVE_DEVLINK_TRAP_GROUP_GENERIC_2_ARGS 1

/* devlink_trap_report has 5 args */
#define HAVE_DEVLINK_TRAP_REPORT_5_ARGS 1

/* devlink struct devlink_trap exists */
#define HAVE_DEVLINK_TRAP_SUPPORT 1

/* devlink.h has devl_health_reporter_create */
#define HAVE_DEVL_HEALTH_REPORTER_CREATE 1

/* devlink.h has devl_param_driverinit_value_get */
#define HAVE_DEVL_PARAM_DRIVERINIT_VALUE_GET 1

/* devlink.h has devl_port_health_reporter_create */
#define HAVE_DEVL_PORT_HEALTH_REPORTER_CREATE 1

/* devlink.h devl_port_register defined */
#define HAVE_DEVL_PORT_REGISTER 1

/* devl_rate_leaf_create 3 param */
#define HAVE_DEVL_RATE_LEAF_CREATE_GET_3_PARAMS 1

/* devlink.h has devl_register */
#define HAVE_DEVL_REGISTER 1

/* devlink.h has devl_resources_unregister */
#define HAVE_DEVL_RESOURCES_UNREGISTER 1

/* devlink.h has devl_resource_register */
#define HAVE_DEVL_RESOURCE_REGISTER 1

/* devlink.h devl_trap_groups_register defined */
#define HAVE_DEVL_TRAP_GROUPS_REGISTER 1

/* devnode get const struct device */
#define HAVE_DEVNODE_GET_CONST_DEVICE 1

/* function dev_addr_mod exists */
#define HAVE_DEV_ADDR_MOD 1

/* dev_change_flags has 3 parameters */
#define HAVE_DEV_CHANGE_FLAGS_HAS_3_PARAMS 1

/* function dev_get_port_parent_id exists */
#define HAVE_DEV_GET_PORT_PARENT_ID 1

/* dev_page_is_reusable is defined */
#define HAVE_DEV_PAGE_IS_REUSABLE 1

/* dev_xdp_prog_id is defined */
#define HAVE_DEV_XDP_PROG_ID 1

/* disk_set_zoned is defined */
#define HAVE_DISK_SET_ZONED 1

/* disk_uevent exist */
#define HAVE_DISK_UEVENT 1

/* disk_update_readahead exists */
#define HAVE_DISK_UPDATE_READAHEAD 1

/* struct dma_buf_attach_ops has allow_peer2peer */
#define HAVE_DMA_BUF_ATTACH_OPS_ALLOW_PEER2PEER 1

/* dma_buf_dynamic_attach get 4 params */
#define HAVE_DMA_BUF_DYNAMIC_ATTACH_GET_4_PARAMS 1

/* linux/dma-map-ops.h has DMA_F_PCI_P2PDMA_SUPPORTED */
#define HAVE_DMA_F_PCI_P2PDMA_SUPPORTED 1

/* dma-mapping.h has dma_map_sgtable */
#define HAVE_DMA_MAP_SGTABLE 1

/* linux/dma-mapping.h has dma_max_mapping_size */
#define HAVE_DMA_MAX_MAPPING_SIZE 1

/* dma_opt_mapping_size is defined */
#define HAVE_DMA_OPT_MAPPING_SIZE 1

/* linux/dma-mapping.h has dma_pci_p2pdma_supported */
#define HAVE_DMA_PCI_P2PDMA_SUPPORTED 1

/* linux/dma-resv.h has dma_resv_excl_fence */
/* #undef HAVE_DMA_RESV_EXCL_FENCE */

/* linux/dma-resv.h exists */
#define HAVE_DMA_RESV_H 1

/* linux/dma-resv.h has DMA_RESV_USAGE_KERNEL */
#define HAVE_DMA_RESV_USAGE_KERNEL 1

/* linux/dma-resv.h has dma_resv_wait_timeout */
#define HAVE_DMA_RESV_WAIT_TIMEOUT 1

/* dma_set_min_align_mask is defined in dma-mapping */
#define HAVE_DMA_SET_MIN_ALIGN_MASK 1

/* dma-mapping.h has dma_zalloc_coherent function */
/* #undef HAVE_DMA_ZALLOC_COHERENT */

/* dpll.h has dpll_netdev_pin_set */
/* #undef HAVE_DPLL_NETDEV_PIN_SET */

/* struct dpll_pin_ops has ffo_get */
/* #undef HAVE_DPLL_PIN_OPS_HAS_FFO_GET */

/* have struct dpll_pin_ops */
/* #undef HAVE_DPLL_STRUCTS */

/* struct enum has member BIO_REMAPPED */
#define HAVE_ENUM_BIO_REMAPPED 1

/* enum flow_block_binder_type exists */
#define HAVE_ENUM_FLOW_BLOCK_BINDER_TYPE 1

/* enum tc_htb_command is defined */
#define HAVE_ENUM_TC_HTB_COMMAND 1

/* esp_output_fill_trailer is defined */
#define HAVE_ESP_OUTPUT_FILL_TRAILER 1

/* ethtool supprts 50G-pre-lane link modes */
#define HAVE_ETHTOOL_50G_PER_LANE_LINK_MODES 1

/* get/set_settings is defined */
/* #undef HAVE_ETHTOOL_GET_SET_SETTINGS */

/* ethtool_link_ksettings has lanes */
#define HAVE_ETHTOOL_LINK_KSETTINGS_HAS_LANES 1

/* linux/ethtool_netlink.h exists */
#define HAVE_ETHTOOL_NETLINK_H 1

/* ethtool_pause_stats is defined */
#define HAVE_ETHTOOL_PAUSE_STATS 1

/* ethtool_rmon_hist_range is defined */
#define HAVE_ETHTOOL_RMON_HIST_RANGE 1

/* eth_get_headlen is defined with 2 params */
/* #undef HAVE_ETH_GET_HEADLEN_2_PARAMS */

/* eth_get_headlen is defined with 3 params */
#define HAVE_ETH_GET_HEADLEN_3_PARAMS 1

/* linux/eventfd.h has eventfd_signal with 1 param */
/* #undef HAVE_EVENTFD_SIGNAL_GET_1_PARAM */

/* ext_pi_ref_tag is defined */
#define HAVE_EXT_PI_REF_TAG 1

/* FC_APPID_LEN is defined */
#define HAVE_FC_APPID_LEN 1

/* function fib6_info_nh_dev exists */
#define HAVE_FIB6_INFO_NH_DEV 1

/* function fib_info_nh exists */
#define HAVE_FIB_INFO_NH 1

/* fib_lookup is exported by the kernel */
/* #undef HAVE_FIB_LOOKUP_EXPORTED */

/* fib_nh has fib_nh_dev */
#define HAVE_FIB_NH_DEV 1

/* sruct file has f_iocb_flags */
#define HAVE_FILE_F_IOCB_FLAGS 1

/* uring_cmd is defined in file_operations */
#define HAVE_FILE_OPERATIONS_URING_CMD 1

/* uring_cmd_iopoll is defined in file_operations */
#define HAVE_FILE_OPERATIONS_URING_CMD_IOPOLL 1

/* struct devlink_ops flash_update get 3 params */
#define HAVE_FLASH_UPDATE_GET_3_PARAMS 1

/* FLOW_ACTION_CONTINUE exists */
#define HAVE_FLOW_ACTION_CONTINUE 1

/* FLOW_ACTION_CT exists */
#define HAVE_FLOW_ACTION_CT 1

/* struct flow_action_entry has ct_metadata.orig_dir */
#define HAVE_FLOW_ACTION_CT_METADATA_ORIG_DIR 1

/* net/flow_offload.h struct flow_action_entry has cookie */
#define HAVE_FLOW_ACTION_ENTRY_COOKIE 1

/* net/flow_offload.h struct flow_action_entry has hw_index */
#define HAVE_FLOW_ACTION_ENTRY_HW_INDEX 1

/* net/flow_offload.h struct flow_action_entry has miss_cookie */
#define HAVE_FLOW_ACTION_ENTRY_MISS_COOKIE 1

/* struct flow_action_entry has hw_index */
#define HAVE_FLOW_ACTION_HW_INDEX 1

/* flow_action_hw_stats_check exists */
#define HAVE_FLOW_ACTION_HW_STATS_CHECK 1

/* FLOW_ACTION_JUMP and PIPE exists */
#define HAVE_FLOW_ACTION_JUMP_AND_PIPE 1

/* struct flow_action_entry has mpls */
#define HAVE_FLOW_ACTION_MPLS 1

/* FLOW_ACTION_POLICE exists */
#define HAVE_FLOW_ACTION_POLICE 1

/* struct flow_action_entry has police.exceed */
#define HAVE_FLOW_ACTION_POLICE_EXCEED 1

/* struct flow_action_entry has police.index */
/* #undef HAVE_FLOW_ACTION_POLICE_INDEX */

/* struct flow_action_entry has police.rate_pkt_ps */
#define HAVE_FLOW_ACTION_POLICE_RATE_PKT_PS 1

/* FLOW_ACTION_PRIORITY exists */
#define HAVE_FLOW_ACTION_PRIORITY 1

/* struct flow_action_entry has ptype */
#define HAVE_FLOW_ACTION_PTYPE 1

/* FLOW_ACTION_REDIRECT_INGRESS exists */
#define HAVE_FLOW_ACTION_REDIRECT_INGRESS 1

/* FLOW_ACTION_VLAN_PUSH_ETH exists */
#define HAVE_FLOW_ACTION_VLAN_PUSH_ETH 1

/* struct flow_block_cb exist */
#define HAVE_FLOW_BLOCK_CB 1

/* flow_block_cb_alloc is defined */
#define HAVE_FLOW_BLOCK_CB_ALLOC 1

/* flow_block_cb_setup_simple is defined */
#define HAVE_FLOW_BLOCK_CB_SETUP_SIMPLE 1

/* struct flow_block_offload exists */
#define HAVE_FLOW_BLOCK_OFFLOAD 1

/* struct flow_cls_offload exists */
#define HAVE_FLOW_CLS_OFFLOAD 1

/* flow_cls_offload_flow_rule is defined */
#define HAVE_FLOW_CLS_OFFLOAD_FLOW_RULE 1

/* FLOW_DISSECTOR_F_STOP_BEFORE_ENCAP is defined */
#define HAVE_FLOW_DISSECTOR_F_STOP_BEFORE_ENCAP 1

/* FLOW_DISSECTOR_KEY_META is defined */
#define HAVE_FLOW_DISSECTOR_KEY_META 1

/* struct flow_dissector_key_vlan has vlan_eth_type */
#define HAVE_FLOW_DISSECTOR_KEY_VLAN_ETH_TYPE 1

/* flow_dissector.h has struct flow_dissector_mpls_lse */
#define HAVE_FLOW_DISSECTOR_MPLS_LSE 1

/* flow_indr_block_bind_cb_t has 4 parameters */
/* #undef HAVE_FLOW_INDR_BLOCK_BIND_CB_T_4_PARAMS */

/* flow_indr_block_bind_cb_t has 7 parameters */
#define HAVE_FLOW_INDR_BLOCK_BIND_CB_T_7_PARAMS 1

/* flow_indr_block_cb_alloc exist */
#define HAVE_FLOW_INDR_BLOCK_CB_ALLOC 1

/* flow_indr_dev_register exists */
#define HAVE_FLOW_INDR_DEV_REGISTER 1

/* flow_indr_dev_unregister receive flow_setup_cb_t parameter */
/* #undef HAVE_FLOW_INDR_DEV_UNREGISTER_FLOW_SETUP_CB_T */

/* HAVE_FLOW_OFFLOAD_ACTION exists */
#define HAVE_FLOW_OFFLOAD_ACTION 1

/* flow_offload_has_one_action exists */
#define HAVE_FLOW_OFFLOAD_HAS_ONE_ACTION 1

/* flow_rule_match_cvlan is exported by the kernel */
#define HAVE_FLOW_RULE_MATCH_CVLAN 1

/* flow_rule_match_meta exists */
#define HAVE_FLOW_RULE_MATCH_META 1

/* flow_setup_cb_t is defined */
#define HAVE_FLOW_SETUP_CB_T 1

/* flow_stats_update has 5 parameters */
/* #undef HAVE_FLOW_STATS_UPDATE_5_PARAMS */

/* flow_stats_update has 6 parameters */
#define HAVE_FLOW_STATS_UPDATE_6_PARAMS 1

/* FOLL_LONGTERM is defined */
#define HAVE_FOLL_LONGTERM 1

/* for_ifa defined */
/* #undef HAVE_FOR_IFA */

/* linux/fs.h has struct kiocb ki_complete 2 args */
#define HAVE_FS_KIOCB_KI_COMPLETE_2_ARG 1

/* net/macsec.c has function macsec_get_real_dev */
#define HAVE_FUNC_MACSEC_GET_REAL_DEV 1

/* net/macsec.c has function macsec_netdev_is_offloaded */
#define HAVE_FUNC_MACSEC_NETDEV_IS_OFFLOADED 1

/* net/macsec.h has function macsec_netdev_priv */
#define HAVE_FUNC_MACSEC_NETDEV_PRIV 1

/* struct gendisk has conv_zones_bitmap */
/* #undef HAVE_GENDISK_CONV_ZONES_BITMAP */

/* struct gendisk has open_mode */
#define HAVE_GENDISK_OPEN_MODE 1

/* genhd.h has GENHD_FL_EXT_DEVT */
/* #undef HAVE_GENHD_FL_EXT_DEVT */

/* genhd.h has GENHD_FL_UP */
/* #undef HAVE_GENHD_FL_UP */

/* struct genl_family has member policy */
#define HAVE_GENL_FAMILY_POLICY 1

/* struct genl_family has member resv_start_op */
#define HAVE_GENL_FAMILY_RESV_START_OP 1

/* struct genl_ops has member validate */
#define HAVE_GENL_OPS_VALIDATE 1

/* gettimex64 is defined */
#define HAVE_GETTIMEX64 1

/* .get_link_ext_state is defined */
#define HAVE_GET_LINK_EXT_STATE 1

/* ethtool_ops has get_module_eeprom_by_page */
#define HAVE_GET_MODULE_EEPROM_BY_PAGE 1

/* get_pause_stats is defined */
#define HAVE_GET_PAUSE_STATS 1

/* get_pid_task is exported by the kernel */
#define HAVE_GET_PID_TASK_EXPORTED 1

/* get_random_u32_inclusive defined */
#define HAVE_GET_RANDOM_U32_INCLUSIVE 1

/* get_random_u8 defined */
#define HAVE_GET_RANDOM_U8 1

/* ndo_get_ringparam get 4 parameters */
#define HAVE_GET_RINGPARAM_GET_4_PARAMS 1

/* get/set_rxfh_context is defined */
#define HAVE_GET_RXFH_CONTEXT 1

/* get_task_pid is exported by the kernel */
#define HAVE_GET_TASK_PID_EXPORTED 1

/* get_user_pages has 4 params */
#define HAVE_GET_USER_PAGES_4_PARAMS 1

/* get_user_pages has 5 params */
/* #undef HAVE_GET_USER_PAGES_5_PARAMS */

/* get_user_pages has 7 params */
/* #undef HAVE_GET_USER_PAGES_7_PARAMS */

/* get_user_pages_longterm is defined */
/* #undef HAVE_GET_USER_PAGES_LONGTERM */

/* get_user_pages_remote is defined with 7 parameters and parameter 2 is
   integer */
/* #undef HAVE_GET_USER_PAGES_REMOTE_7_PARAMS_AND_SECOND_INT */

/* get_user_pages_remote is defined with 8 parameters */
/* #undef HAVE_GET_USER_PAGES_REMOTE_8_PARAMS */

/* get_user_pages_remote is defined with 8 parameters with locked */
/* #undef HAVE_GET_USER_PAGES_REMOTE_8_PARAMS_W_LOCKED */

/* GRO_LEGACY_MAX_SIZE defined */
#define HAVE_GRO_LEGACY_MAX_SIZE 1

/* GRO_MAX_SIZE defined */
#define HAVE_GRO_MAX_SIZE 1

/* devlink_health_reporter_ops.recover has extack */
#define HAVE_HEALTH_REPORTER_RECOVER_HAS_EXTACK 1

/* have hmm_pfn_to_map_order */
#define HAVE_HMM_PFN_TO_MAP_ORDER 1

/* hmm_range_fault has one param */
#define HAVE_HMM_RANGE_FAULT_HAS_ONE_PARAM 1

/* hmm_range has hmm_pfns */
#define HAVE_HMM_RANGE_HAS_HMM_PFNS 1

/* hwmon_chip_info get const nvme_hwmon_ops */
#define HAVE_HWMON_CHIP_INFO_CONST_INFO 1

/* rdma/ib_umem.h ib_umem_dmabuf_get_pinned defined */
#define HAVE_IB_UMEM_DMABUF_GET_PINNED 1

/* ida_alloc is defined */
#define HAVE_IDA_ALLOC 1

/* ida_alloc_max is defined */
#define HAVE_IDA_ALLOC_MAX 1

/* idr.h has ida_alloc_range */
#define HAVE_IDA_ALLOC_RANGE 1

/* idr.h has ida_free */
#define HAVE_IDA_FREE 1

/* inet_confirm_addr is exported by the kernel */
#define HAVE_INET_CONFIRM_ADDR_EXPORTED 1

/* interval_tree functions exported by the kernel */
#define HAVE_INTERVAL_TREE_EXPORTED 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* devlink_fmsg_u8_pair_put returns int */
#define HAVE_INT_DEVLINK_FMSG_U8_PAIR 1

/* int_pow defined */
#define HAVE_INT_POW 1

/* linux/compat.h has in_compat_syscall */
#define HAVE_IN_COMPAT_SYSCALL 1

/* iov_iter_is_bvec is defined */
#define HAVE_IOV_ITER_IS_BVEC_SET 1

/* linux/io_uring/cmd.h exists */
/* #undef HAVE_IO_URING_CMD_H */

/* ip6_dst_hoplimit is exported by the kernel */
#define HAVE_IP6_DST_HOPLIMIT 1

/* netns_ipv4 tcp_death_row memebr is not pointer */
#define HAVE_IPV4_NOT_POINTER_TCP_DEATH_ROW 1

/* if ipv6_stub has ipv6_dst_lookup_flow */
#define HAVE_IPV6_DST_LOOKUP_FLOW 1

/* if ipv6_stub has ipv6_dst_lookup_flow in addrconf.h */
/* #undef HAVE_IPV6_DST_LOOKUP_FLOW_ADDR_CONF */

/* ipv6_dst_lookup takes net */
/* #undef HAVE_IPV6_DST_LOOKUP_TAKES_NET */

/* net/ipv6_stubs.h exists */
#define HAVE_IPV6_STUBS_H 1

/* net/ip.h has ip_sock_set_tos */
#define HAVE_IP_SOCK_SET_TOS 1

/* irq_affinity_desc is defined */
#define HAVE_IRQ_AFFINITY_DESC 1

/* struct irq_affinity has priv */
#define HAVE_IRQ_AFFINITY_PRIV 1

/* cpu_rmap.h has irq_cpu_rmap_remove */
#define HAVE_IRQ_CPU_RMAP_REMOVE 1

/* irq_get_effective_affinity_mask is defined */
#define HAVE_IRQ_GET_EFFECTIVE_AFFINITY_MASK 1

/* irq_set_affinity_and_hint is defined */
#define HAVE_IRQ_UPDATE_AFFINITY_HINT 1

/* iscsi_target_core.h has struct iscsit_cmd */
#define HAVE_ISCSIT_CMD 1

/* iscsi_target_core.h has struct iscsit_conn */
#define HAVE_ISCSIT_CONN 1

/* iscsit_conn has members local_sockaddr */
#define HAVE_ISCSIT_CONN_LOCAL_SOCKADDR 1

/* iscsit_conn has member login_sockaddr */
#define HAVE_ISCSIT_CONN_LOGIN_SOCKADDR 1

/* iscsit_set_unsolicited_dataout is defined */
#define HAVE_ISCSIT_SET_UNSOLICITED_DATAOUT 1

/* libiscsi.h has struct iscsi_cmd */
#define HAVE_ISCSI_CMD 1

/* iscsi_conn has members local_sockaddr */
/* #undef HAVE_ISCSI_CONN_LOCAL_SOCKADDR */

/* iscsi_conn has member login_sockaddr */
/* #undef HAVE_ISCSI_CONN_LOGIN_SOCKADDR */

/* iscsi_conn_unbind is defined */
#define HAVE_ISCSI_CONN_UNBIND 1

/* iscsi_eh_cmd_timed_out is defined */
/* #undef HAVE_ISCSI_EH_CMD_TIMED_OUT */

/* libiscsi.h iscsi_host_remove has 2 parameters */
#define HAVE_ISCSI_HOST_REMOVE_2_PARAMS 1

/* iscsi_put_endpoint is defined */
#define HAVE_ISCSI_PUT_ENDPOINT 1

/* is_cow_mapping is defined */
#define HAVE_IS_COW_MAPPING 1

/* is_pci_p2pdma_page is defined */
#define HAVE_IS_PCI_P2PDMA_PAGE_IN_MEMREMAP_H 1

/* is_pci_p2pdma_page is defined */
#define HAVE_IS_PCI_P2PDMA_PAGE_IN_MM_H 1

/* is_tcf_police is defined */
#define HAVE_IS_TCF_POLICE 1

/* ITER_DEST is defined */
#define HAVE_ITER_DEST 1

/* ethtool.h kernel_ethtool_ringparam has tcp_data_split member */
#define HAVE_KERNEL_RINGPARAM_TCP_DATA_SPLIT 1

/* function kfree_rcu_mightsleep is defined */
#define HAVE_KFREE_RCU_MIGHTSLEEP 1

/* linux/kobject.h kobj_type has default_groups member */
#define HAVE_KOBJ_TYPE_DEFAULT_GROUPS 1

/* kstrtox.h exist */
#define HAVE_KSTRTOX_H 1

/* ktls related structs exists */
#define HAVE_KTLS_STRUCTS 1

/* function kvfree_call_rcu is defined */
#define HAVE_KVFREE_CALL_RCU 1

/* kvfree prototype is in slab.h */
#define HAVE_KVFREE_IN_SLAB_H 1

/* linux/device/bus.h exists */
#define HAVE_LINUX_DEVICE_BUS_H 1

/* uapi/linux/mei_uuid.h is exists */
#define HAVE_LINUX_MEI_UUID_H 1

/* linux/sed-opal.h exists */
/* #undef HAVE_LINUX_SED_OPAL_H */

/* list_is_first is defined */
#define HAVE_LIST_IS_FIRST 1

/* linux/lockdep.h has lockdep_unregister_key */
#define HAVE_LOCKDEP_UNREGISTER_KEY 1

/* linux/lockdep.h has lockdep_assert_held_exclusive */
/* #undef HAVE_LOCKUP_ASSERT_HELD_EXCLUSIVE */

/* linux/lockdep.h has lockdep_assert_held_write */
#define HAVE_LOCKUP_ASSERT_HELD_WRITE 1

/* net/macsec.h exists */
#define HAVE_MACSEC_H 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* map_lock has mmap_read_lock */
#define HAVE_MMAP_READ_LOCK 1

/* mmput_async is exported by the kernel */
#define HAVE_MMPUT_ASYNC_EXPORTED 1

/* mmu interval notifier defined */
#define HAVE_MMU_INTERVAL_NOTIFIER 1

/* mmu_notifier_call_srcu defined */
/* #undef HAVE_MMU_NOTIFIER_CALL_SRCU */

/* struct mmu_notifier_ops has alloc/free_notifier */
#define HAVE_MMU_NOTIFIER_OPS_HAS_FREE_NOTIFIER 1

/* mmu_notifier_range_blockable defined */
#define HAVE_MMU_NOTIFIER_RANGE_BLOCKABLE 1

/* ib_umem_notifier_invalidate_range_start get struct mmu_notifier_range */
#define HAVE_MMU_NOTIFIER_RANGE_STRUCT 1

/* mmu_notifier_synchronize defined */
#define HAVE_MMU_NOTIFIER_SYNCHRONIZE 1

/* mmu_notifier_unregister_no_release defined */
/* #undef HAVE_MMU_NOTIFIER_UNREGISTER_NO_RELEASE */

/* mm.h has gup_must_unshare get 3 params */
/* #undef HAVE_MM_GUP_MUST_UNSHARE_GET_3_PARAMS */

/* mm_kobj is exported by the kernel */
/* #undef HAVE_MM_KOBJ_EXPORTED */

/* msi_map exists */
#define HAVE_MSI_MAP_TMP 1

/* linux/skbuff.h napi_build_skb is defined */
#define HAVE_NAPI_BUILD_SKB 1

/* napi_reschedule exists */
#define HAVE_NAPI_RESCHEDULE 1

/* ndo_bridge_setlink is defined */
/* #undef HAVE_NDO_BRIDGE_SETLINK */

/* ndo_bridge_setlink is defined */
#define HAVE_NDO_BRIDGE_SETLINK_EXTACK 1

/* net_device_ops has ndo_eth_ioctl is defined */
#define HAVE_NDO_ETH_IOCTL 1

/* eth_phy_stats is defined */
#define HAVE_NDO_ETH_PHY_STATS 1

/* ndo_get_coalesce get 4 parameters */
#define HAVE_NDO_GET_COALESCE_GET_4_PARAMS 1

/* ndo_get_devlink_port is defined */
/* #undef HAVE_NDO_GET_DEVLINK_PORT */

/* get_fec_stats is defined */
#define HAVE_NDO_GET_FEC_STATS 1

/* HAVE_NDO_GET_PORT_PARENT_ID is defined */
#define HAVE_NDO_GET_PORT_PARENT_ID 1

/* ndo_get_vf_guid is defined */
#define HAVE_NDO_GET_VF_GUID 1

/* get_link_ext_stats is defined */
#define HAVE_NDO_LINK_EXT_STATS 1

/* dpll_pin_ops.lock_status_get has status_error */
/* #undef HAVE_NDO_LOCK_STATUS_GET_GET_ERROR_STATUS */

/* struct ndevlink_port_ops has devlink_port as member */
#define HAVE_NDO_PORT_DEL_IN_DEVLINK_PORT 1

/* ndo_select_queue has 3 params with no fallback */
#define HAVE_NDO_SELECT_QUEUE_HAS_3_PARMS_NO_FALLBACK 1

/* ndo_tx_timeout get 2 params */
#define HAVE_NDO_TX_TIMEOUT_GET_2_PARAMS 1

/* ndo_add_vxlan_port is defined */
/* #undef HAVE_NDO_UDP_TUNNEL_ADD */

/* ndo_xsk_wakeup is defined */
#define HAVE_NDO_XSK_WAKEUP 1

/* netdev_bpf struct has pool member */
#define HAVE_NETDEV_BPF_XSK_BUFF_POOL 1

/* struct net_device has devlink_port as member */
#define HAVE_NETDEV_DEVLINK_PORT 1

/* netdevice.h has netdev_dpll_pin_set */
/* #undef HAVE_NETDEV_DPLL_PIN_SET */

/* function netdev_get_xmit_slave exists */
#define HAVE_NETDEV_GET_XMIT_SLAVE 1

/* linux/netdevice.h has netdev_hold */
#define HAVE_NETDEV_HOLD 1

/* netdev_lag_hash has NETDEV_LAG_HASH_VLAN_SRCMAC */
#define HAVE_NETDEV_LAG_HASH_VLAN_SRCMAC 1

/* netdevice.h has struct netdev_nested_priv */
#define HAVE_NETDEV_NESTED_PRIV_STRUCT 1

/* struct netdev_net_notifier is defined */
#define HAVE_NETDEV_NET_NOTIFIER 1

/* netdev_port_same_parent_id is defined */
#define HAVE_NETDEV_PORT_SAME_PARENT_ID 1

/* netdev_put is defined */
#define HAVE_NETDEV_PUT 1

/* netdev_xmit_more is defined */
#define HAVE_NETDEV_XMIT_MORE 1

/* netif_carrier_event exists */
#define HAVE_NETIF_CARRIER_EVENT 1

/* netif_device_present get const */
#define HAVE_NETIF_DEVICE_PRESENT_GET_CONST 1

/* NETIF_F_HW_TLS_RX is defined in netdev_features.h */
#define HAVE_NETIF_F_HW_TLS_RX 1

/* netif_is_bareudp is defined */
#define HAVE_NETIF_IS_BAREDUDP 1

/* netif_is_bareudp is defined */
#define HAVE_NETIF_IS_BAREUDP 1

/* netif_is_geneve is defined */
#define HAVE_NETIF_IS_GENEVE 1

/* netif_is_gretap is defined */
#define HAVE_NETIF_IS_GRETAP 1

/* netif_is_vxlan is defined */
#define HAVE_NETIF_IS_VXLAN 1

/* netif_napi_add get 3 params */
#define HAVE_NETIF_NAPI_ADD_GET_3_PARAMS 1

/* netdevice.h has netif_napi_add_weight */
#define HAVE_NETIF_NAPI_ADD_WEIGHT 1

/* struct netlink_callback has member extack */
#define HAVE_NETLINK_CALLBACK_EXTACK 1

/* netpoll_poll_dev is exported by the kernel */
#define HAVE_NETPOLL_POLL_DEV_EXPORTED 1

/* net/bareudp.h is exists */
#define HAVE_NET_BAREUDP_H 1

/* struct net_device has devlink_port member */
#define HAVE_NET_DEVICE_DEVLINK_PORT 1

/* struct net_device has devlink_port */
#define HAVE_NET_DEVICE_HAS_DEVLINK_PORT 1

/* struct net_device has lower_level */
#define HAVE_NET_DEVICE_LOWER_LEVEL 1

/* net/gro.h is defined */
#define HAVE_NET_GRO_H 1

/* net/lag.h exists */
#define HAVE_NET_LAG_H 1

/* net/lag.h exists */
#define HAVE_NET_LAG_PORT_DEV_TXABLE 1

/* net_namespace get const struct device */
#define HAVE_NET_NAMESPACE_GET_CONST_DEVICE 1

/* net/nexthop.h is defined */
#define HAVE_NET_NEXTHOP_H 1

/* net/page_pool.h is defined */
/* #undef HAVE_NET_PAGE_POOL_OLD_H */

/* net/page_pool/types.h is defined */
#define HAVE_NET_PAGE_POOL_TYPES_H 1

/* net_prefetch is defined */
#define HAVE_NET_PREFETCH 1

/* net/tc_act/tc_mpls.h exists */
#define HAVE_NET_TC_ACT_TC_MPLS_H 1

/* nla_nest_start_noflag exist */
#define HAVE_NLA_NEST_START_NOFLAG 1

/* nla_parse_deprecated exist */
#define HAVE_NLA_PARSE_DEPRECATED 1

/* nla_policy has validation_type */
#define HAVE_NLA_POLICY_HAS_VALIDATION_TYPE 1

/* nla_strscpy exist */
#define HAVE_NLA_STRSCPY 1

/* nlmsg_parse_deprecated exist */
#define HAVE_NLMSG_PARSE_DEPRECATED 1

/* nlmsg_validate_deprecated exist */
#define HAVE_NLMSG_VALIDATE_DEPRECATED 1

/* NL_SET_ERR_MSG_WEAK_MOD exists */
#define HAVE_NL_SET_ERR_MSG_WEAK_MOD 1

/* nvme_auth_transform_key returns struct nvme_dhchap_key * */
/* #undef HAVE_NVME_AUTH_TRANSFORM_KEY_DHCHAP */

/* NVME_IOCTL_IO64_CMD_VEC is defined */
#define HAVE_NVME_IOCTL_IO64_CMD_VEC 1

/* struct page has dma_addr */
#define HAVE_PAGE_DMA_ADDR 1

/* struct page has dma_addr array member */
/* #undef HAVE_PAGE_DMA_ADDR_ARRAY */

/* linux/gfp.h has page_frag_cache_drain */
/* #undef HAVE_PAGE_FRAG_CACHE_DRAIN */

/* net/page_pool/helpers.h has page_pool_nid_changed */
#define HAVE_PAGE_POLL_NID_CHANGED_HELPERS 1

/* net/page_pool.h has page_pool_nid_changed */
/* #undef HAVE_PAGE_POLL_NID_CHANGED_OLD */

/* net/page_pool/types.h has page_pool_put_defragged_page */
/* #undef HAVE_PAGE_POOL_DEFRAG_PAGE_IN_PAGE_POOL_H */

/* net/page_pool/types.h has page_pool_put_defragged_page */
#define HAVE_PAGE_POOL_DEFRAG_PAGE_IN_PAGE_POOL_TYPES_H 1

/* net/page_pool.h page_pool_get_dma_addr defined */
#define HAVE_PAGE_POOL_GET_DMA_ADDR_HELPER 1

/* net/page_pool.h page_pool_get_dma_addr defined */
/* #undef HAVE_PAGE_POOL_GET_DMA_ADDR_OLD */

/* net/page_pool/types.h struct page_pool_params has netdev as member */
/* #undef HAVE_PAGE_POOL_PARAMS_HAS_NETDEV */

/* net/page_pool.h struct page_pool_params has napi as member */
/* #undef HAVE_PAGE_POOL_PARAMS_NAPI_OLD */

/* net/page_pool/types.h struct page_pool_params has napi as member */
#define HAVE_PAGE_POOL_PARAMS_NAPI_TYPES_H 1

/* net/page_pool/types.h has page_pool_put_unrefed_page */
/* #undef HAVE_PAGE_POOL_PUT_UNREFED_PAGE */

/* net/page_pool.h has page_pool_release_page */
/* #undef HAVE_PAGE_POOL_RELEASE_PAGE_IN_PAGE_POOL_H */

/* net/page_pool/types.h has page_pool_release_page */
/* #undef HAVE_PAGE_POOL_RELEASE_PAGE_IN_TYPES_H */

/* include/linux/panic.h exists */
#define HAVE_PANIC_H 1

/* linux/moduleparam.h has param_set_uint_minmax */
#define HAVE_PARAM_SET_UINT_MINMAX 1

/* part_stat.h exists */
#define HAVE_PART_STAT_H 1

/* linux/pci.h has pcie_aspm_enabled */
#define HAVE_PCIE_ASPM_ENABLED 1

/* pci.h has pcie_capability_clear_and_set_word_locked */
#define HAVE_PCIE_CAPABILITY_CLEAR_AND_SET_WORD_LOCKED 1

/* pci_dev has link_active_reporting */
#define HAVE_PCI_DEV_LINK_ACTIVE_REPORTING 1

/* struct pci_driver has member driver_managed_dma */
#define HAVE_PCI_DRIVER_MANAGED_DMA 1

/* linux/aer.h has pci_enable_pcie_error_reporting */
/* #undef HAVE_PCI_ENABLE_PCIE_ERROR_REPORTING */

/* pci_iov_get_pf_drvdata is defined */
#define HAVE_PCI_IOV_GET_PF_DRVDATA 1

/* pci_iov_vf_id is defined */
#define HAVE_PCI_IOV_VF_ID 1

/* pci_irq_get_node is defined */
/* #undef HAVE_PCI_IRQ_GET_NODE */

/* pci.h has pci_msix_can_alloc_dyn */
#define HAVE_PCI_MSIX_CAN_ALLOC_DYN 1

/* linux/pci-p2pdma.h exists */
#define HAVE_PCI_P2PDMA_H 1

/* pci_p2pdma_map_sg_attrs defined */
/* #undef HAVE_PCI_P2PDMA_MAP_SG_ATTRS */

/* pci_p2pdma_unmap_sg defined */
/* #undef HAVE_PCI_P2PDMA_UNMAP_SG */

/* pci_pool_zalloc is defined */
/* #undef HAVE_PCI_POOL_ZALLOC */

/* PCI_VENDOR_ID_REDHAT is defined */
#define HAVE_PCI_VENDOR_ID_REDHAT 1

/* linux/proc_fs.h has pde_data */
#define HAVE_PDE_DATA 1

/* pinned_vm is defined */
/* #undef HAVE_PINNED_VM */

/* dev_pm_qos_update_user_latency_tolerance is exported by the kernel */
#define HAVE_PM_QOS_UPDATE_USER_LATENCY_TOLERANCE_EXPORTED 1

/* pnv-pci.h has pnv_pci_set_p2p */
/* #undef HAVE_PNV_PCI_SET_P2P */

/* port_function_hw_addr_get has 4 params */
/* #undef HAVE_PORT_FUNCTION_HW_ADDR_GET_GET_4_PARAM */

/* port_function_state_get has 4 params */
/* #undef HAVE_PORT_FUNCTION_STATE_GET_4_PARAM */

/* struct proc_ops is defined */
#define HAVE_PROC_OPS_STRUCT 1

/* net.h struct proto_ops has sendpage */
/* #undef HAVE_PROTO_OPS_SENDPAGE */

/* linux/pr.h has struct pr_keys */
#define HAVE_PR_KEYS 1

/* enum pr_status is defined */
#define HAVE_PR_STATUS 1

/* adjphase is defined */
#define HAVE_PTP_CLOCK_INFO_ADJPHASE 1

/* adjfreq is defined */
/* #undef HAVE_PTP_CLOCK_INFO_NDO_ADJFREQ */

/* struct ptp_clock_info has getmaxphase */
#define HAVE_PTP_CLOCK_INFO_NDO_GETMAXPHASE 1

/* ptp_find_pin_unlocked is defined */
#define HAVE_PTP_FIND_PIN_UNLOCK 1

/* PTP_PEROUT_DUTY_CYCLE is defined */
#define HAVE_PTP_PEROUT_DUTY_CYCLE 1

/* __put_task_struct is exported by the kernel */
#define HAVE_PUT_TASK_STRUCT_EXPORTED 1

/* put_unaligned_le24 existing */
/* #undef HAVE_PUT_UNALIGNED_LE24 */

/* put_unaligned_le24 existing in asm-generic/unaligned.h */
#define HAVE_PUT_UNALIGNED_LE24_ASM_GENERIC 1

/* put_user_pages_dirty_lock has 2 parameters */
/* #undef HAVE_PUT_USER_PAGES_DIRTY_LOCK_2_PARAMS */

/* put_user_pages_dirty_lock has 3 parameters */
/* #undef HAVE_PUT_USER_PAGES_DIRTY_LOCK_3_PARAMS */

/* kernel supports queue and napi association */
/* #undef HAVE_QUEUE_AND_NAPI_ASSOCIATION */

/* QUEUE_FLAG_DISCARD is defined */
/* #undef HAVE_QUEUE_FLAG_DISCARD */

/* QUEUE_FLAG_PCI_P2PDMA is defined */
#define HAVE_QUEUE_FLAG_PCI_P2PDMA 1

/* QUEUE_FLAG_STABLE_WRITES is defined */
#define HAVE_QUEUE_FLAG_STABLE_WRITES 1

/* blkdev.h has queue_limits_commit_update */
/* #undef HAVE_QUEUE_LIMITS_COMMIT_UPDATE */

/* linux/ratelimit_types.h exists */
#define HAVE_RATELIMIT_TYPES_H 1

/* linux/security.h has register_blocking_lsm_notifier */
#define HAVE_REGISTER_BLOCKING_LSM_NOTIFIER 1

/* register_fib_notifier has 4 params */
#define HAVE_REGISTER_FIB_NOTIFIER_HAS_4_PARAMS 1

/* linux/security.h has register_lsm_notifier */
/* #undef HAVE_REGISTER_LSM_NOTIFIER */

/* register_netdevice_notifier_dev_net is defined */
#define HAVE_REGISTER_NETDEVICE_NOTIFIER_DEV_NET 1

/* mm.h has release_pages */
#define HAVE_RELEASE_PAGES_IN_MM_H 1

/* v6.6 remove sentinel from ctl_table array is supported */
#define HAVE_REMOVE_SENTINEL_FROM_CTL_TABLE 1

/* blkdev.h struct request has block_device */
#define HAVE_REQUEST_BDEV 1

/* blkdev.h struct request has deadline */
#define HAVE_REQUEST_HAS_DEADLINE 1

/* blkdev.h struct request has mq_hctx */
#define HAVE_REQUEST_MQ_HCTX 1

/* struct request_queue has backing_dev_info */
/* #undef HAVE_REQUEST_QUEUE_BACKING_DEV_INFO */

/* if linux/blkdev.h struct request_queue has member disk */
#define HAVE_REQUEST_QUEUE_DISK 1

/* linux/blk-mq.h has request_to_qc_t */
/* #undef HAVE_REQUEST_TO_QC_T */

/* blkdev.h struct request has rq_disk */
/* #undef HAVE_REQ_RQ_DISK */

/* genhd.h has revalidate_disk_size */
/* #undef HAVE_REVALIDATE_DISK_SIZE */

/* rpc_task_gfp_mask is exported by the kernel */
#define HAVE_RPC_TASK_GPF_MASK_EXPORTED 1

/* struct rpc_xprt_ops has 'bc_num_slots' field */
#define HAVE_RPC_XPRT_OPS_BC_NUM_SLOTS 1

/* struct rpc_xprt_ops has 'bc_up' field */
/* #undef HAVE_RPC_XPRT_OPS_BC_UP */

/* struct rpc_xprt_ops has 'set_retrans_timeout' field */
/* #undef HAVE_RPC_XPRT_OPS_SET_RETRANS_TIMEOUT */

/* struct rpc_xprt_ops has 'wait_for_reply_request' field */
#define HAVE_RPC_XPRT_OPS_WAIT_FOR_REPLY_REQUEST 1

/* struct rpc_xprt has 'recv_lock' field */
/* #undef HAVE_RPC_XPRT_RECV_LOCK */

/* struct rpc_xprt has 'xprt_class' field */
#define HAVE_RPC_XPRT_XPRT_CLASS 1

/* net/rps.h exists */
/* #undef HAVE_RPS_H */

/* RQF_MQ_INFLIGHT is defined */
#define HAVE_RQF_MQ_INFLIGHT 1

/* if file rq_end_io_ret exists */
#define HAVE_RQ_END_IO_RET 1

/* rt_gw_family is defined */
#define HAVE_RT_GW_FAMILY 1

/* rt_uses_gateway is defined */
#define HAVE_RT_USES_GATEWAY 1

/* macsec_ops has boolean field rx_uses_md_dst */
#define HAVE_RX_USES_MD_DST_IN_MACSEC_OPS 1

/* scsi_block_targets is defined */
#define HAVE_SCSI_BLOCK_TARGETS 1

/* scsi_cmd_to_rq is defined */
#define HAVE_SCSI_CMD_TO_RQ 1

/* scsi_device.h struct scsi_device has member budget_map */
#define HAVE_SCSI_DEVICE_BUDGET_MAP 1

/* scsi_done is defined */
#define HAVE_SCSI_DONE 1

/* scsi_get_sector is defined */
#define HAVE_SCSI_GET_SECTOR 1

/* scsi_host_alloc get const struct scsi_host_template */
#define HAVE_SCSI_HOST_ALLOC_GET_CONST_SHT 1

/* scsi_host.h scsi_host_busy_iter fn has 2 args */
#define HAVE_SCSI_HOST_BUSY_ITER_FN_2_ARGS 1

/* Scsi_Host has members max_segment_size */
#define HAVE_SCSI_HOST_MAX_SEGMENT_SIZE 1

/* scsi_host_template has member init_cmd_priv */
#define HAVE_SCSI_HOST_TEMPLATE_INIT_CMD_PRIV 1

/* scsi_host_template has members shost_groups */
#define HAVE_SCSI_HOST_TEMPLATE_SHOST_GROUPS 1

/* Scsi_Host has members virt_boundary_mask */
#define HAVE_SCSI_HOST_VIRT_BOUNDARY_MASK 1

/* QUEUE_FULL is defined */
/* #undef HAVE_SCSI_QUEUE_FULL */

/* scsi_host.h has enum scsi_timeout_action */
#define HAVE_SCSI_TIMEOUT_ACTION 1

/* scsi/scsi_transport_fc.h has FC_PORT_ROLE_NVME_TARGET */
#define HAVE_SCSI_TRANSPORT_FC_FC_PORT_ROLE_NVME_TARGET 1

/* if secpath_set returns struct sec_path * */
#define HAVE_SECPATH_SET_RETURN_POINTER 1

/* ndo_select_queue has a second net_device parameter */
/* #undef HAVE_SELECT_QUEUE_NET_DEVICE */

/* linux/net.h has sendpage_ok */
#define HAVE_SENDPAGE_OK 1

/* genhd.h has set_capacity_revalidate_and_notify */
/* #undef HAVE_SET_CAPACITY_REVALIDATE_AND_NOTIFY */

/* struct se_cmd has member sense_info */
#define HAVE_SE_CMD_HAS_SENSE_INFO 1

/* sg_alloc_table_chained has nents_first_chunk parameter */
#define HAVE_SG_ALLOC_TABLE_CHAINED_NENTS_FIRST_CHUNK_PARAM 1

/* __sg_alloc_table_from_pages has 9 params */
/* #undef HAVE_SG_ALLOC_TABLE_FROM_PAGES_GET_9_PARAMS */

/* linux/scatterlist.h has sg_append_table */
#define HAVE_SG_APPEND_TABLE 1

/* show_class_attr_string get const */
#define HAVE_SHOW_CLASS_ATTR_STRING_GET_CONST 1

/* linux/overflow.h has size_add size_mul size_sub */
#define HAVE_SIZE_MUL_SUB_ADD 1

/* linux/skbuff.h skb_frag_fill_page_desc is defined */
#define HAVE_SKB_FRAG_FILL_PAGE_DESC 1

/* skb_frag_off is defined */
#define HAVE_SKB_FRAG_OFF 1

/* linux/skbuff.h skb_frag_off_add is defined */
#define HAVE_SKB_FRAG_OFF_ADD 1

/* linux/skbuff.h skb_frag_off_set is defined */
#define HAVE_SKB_FRAG_OFF_SET 1

/* linux/skbuff.h has skb_queue_empty_lockless */
#define HAVE_SKB_QUEUE_EMPTY_LOCKLESS 1

/* skb_set_redirected is defined */
#define HAVE_SKB_SET_REDIRECTED 1

/* linux/tcp.h has skb_tcp_all_headers */
#define HAVE_SKB_TCP_ALL_HEADERS 1

/* kernel supports v6.10-rc1, skip calling no-op sync ops when possible */
/* #undef HAVE_SKIP_CALLING_NOP_SYNC_OPS */

/* xmit_more is defined */
/* #undef HAVE_SK_BUFF_XMIT_MORE */

/* struct sock has sk_use_task_frag */
#define HAVE_SK_USE_TASK_FRAG 1

/* net/sock.h has sock_no_linger */
#define HAVE_SOCK_NO_LINGER 1

/* net/sock.h has sock_setsockopt sockptr_t */
#define HAVE_SOCK_SETOPTVAL_SOCKPTR_T 1

/* net/sock.h has sock_set_priority */
#define HAVE_SOCK_SET_PRIORITY 1

/* net/sock.h has sock_set_reuseaddr */
#define HAVE_SOCK_SET_REUSEADDR 1

/* split_page is exported by the kernel */
#define HAVE_SPLIT_PAGE_EXPORTED 1

/* struct pci_driver has member
   sriov_get_vf_total_msix/sriov_set_msix_vec_count */
#define HAVE_SRIOV_GET_SET_MSIX_VEC_COUNT 1

/* build_bug.h has static_assert */
#define HAVE_STATIC_ASSERT 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* fs.h has stream_open */
#define HAVE_STREAM_OPEN 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* strscpy_pad is defined */
#define HAVE_STRSCPY_PAD 1

/* net/ipv6.h has struct hop_jumbo_hdr */
#define HAVE_STRUCT_HOP_JUMBO_HDR 1

/* ethtool.h has struct kernel_ethtool_ringparam */
#define HAVE_STRUCT_KERNEL_ETHTOOL_RINGPARAM 1

/* struct rtnl_link_ops has netns_refund */
#define HAVE_STRUCT_LINK_OPS_IPOIB_LINK_OPS_HAS_NETNS_REFUND 1

/* struct macsec_context has update_pn */
#define HAVE_STRUCT_MACSEC_CONTEXT_UPDATE_PN 1

/* net/dst_metadata.h has struct macsec_info */
#define HAVE_STRUCT_MACSEC_INFO_METADATA 1

/* net/psample.h has struct psample_metadata */
#define HAVE_STRUCT_PSAMPLE_METADATA 1

/* linux/overflow.h has struct_size_t */
#define HAVE_STRUCT_SIZE_T 1

/* struct switchdev_brport_flags exist */
#define HAVE_STRUCT_SWITCHDEV_BRPORT_FLAGS 1

/* struct switchdev_obj_port_vlan has vid */
#define HAVE_STRUCT_SWITCHDEV_OBJ_PORT_VLAN_VID 1

/* struct vdpa_config_ops has .get_vq_desc_group and .compat_reset defined */
/* #undef HAVE_STRUCT_VDPA_CONFIG_OPS_HAS_COMAPT_RESET_AND_VQ_DESC_GROUP */

/* submit_bio_noacct exist */
#define HAVE_SUBMIT_BIO_NOACCT 1

/* supported_coalesce_params is defined */
#define HAVE_SUPPORTED_COALESCE_PARAM 1

/* struct vfio_device_ops has iommufd support */
#define HAVE_SUPPORT_IOMMUFD_VFIO_PHYS_DEVICES 1

/* struct svcxprt_rdma has 'sc_pending_recvs' field */
#define HAVE_SVCXPRT_RDMA_SC_PENDING_RECVS 1

/* svc_pool_wake_idle_thread is exported by the kernel */
/* #undef HAVE_SVC_POOL_WAKE_IDLE_THREAD */

/* struct svc_rdma_pcl exists */
#define HAVE_SVC_RDMA_PCL 1

/* struct svc_rdma_recv_ctxt has 'rc_stream' field */
#define HAVE_SVC_RDMA_RECV_CTXT_RC_STREAM 1

/* svc_rdma_release_rqst has externed */
/* #undef HAVE_SVC_RDMA_RELEASE_RQST */

/* struct svc_rqst has rq_xprt_hlen */
/* #undef HAVE_SVC_RQST_RQ_XPRT_HLEN */

/* struct svc_serv has sv_cb_list */
/* #undef HAVE_SVC_SERV_SV_CB_LIST_LIST_HEAD */

/* struct svc_serv has sv_cb_list */
/* #undef HAVE_SVC_SERV_SV_CB_LIST_LWQ */

/* svc_xprt_close is exported by the sunrpc core */
#define HAVE_SVC_XPRT_CLOSE 1

/* svc_xprt_deferred_close is exported by the sunrpc core */
#define HAVE_SVC_XPRT_DEFERRED_CLOSE 1

/* svc_xprt_is_dead has defined */
#define HAVE_SVC_XPRT_IS_DEAD 1

/* svc_xprt_received is exported by the sunrpc core */
#define HAVE_SVC_XPRT_RECEIVED 1

/* struct svc_xprt_ops 'xpo_prep_reply_hdr' field */
/* #undef HAVE_SVC_XPRT_XPO_PREP_REPLY_HDR */

/* struct svc_xprt_ops 'xpo_secure_port' field */
/* #undef HAVE_SVC_XPRT_XPO_SECURE_PORT */

/* enum switchdev_attr_id has SWITCHDEV_ATTR_ID_BRIDGE_VLAN_PROTOCOL */
#define HAVE_SWITCHDEV_ATTR_ID_BRIDGE_VLAN_PROTOCOL 1

/* HAVE_SWITCHDEV_OPS is defined */
/* #undef HAVE_SWITCHDEV_OPS */

/* switchdev_port_same_parent_id is defined */
/* #undef HAVE_SWITCHDEV_PORT_SAME_PARENT_ID */

/* linux/sysctl.h has SYSCTL_ZERO defined */
#define HAVE_SYSCTL_ZERO_ENABLED 1

/* sysfs_emit is defined */
#define HAVE_SYSFS_EMIT 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* t10_pi_prepare is defined */
/* #undef HAVE_T10_PI_PREPARE */

/* target_stop_cmd_counter is defined */
#define HAVE_TARGET_STOP_CMD_COUNTER 1

/* target_stop_session is defined */
#define HAVE_TARGET_STOP_SESSION 1

/* interrupt.h has tasklet_setup */
#define HAVE_TASKLET_SETUP 1

/* tc_action_stats_update is defined */
/* #undef HAVE_TCF_ACTION_STATS_UPDATE */

/* tc_action_stats_update is defined and has 5 params */
/* #undef HAVE_TCF_ACTION_STATS_UPDATE_5_PARAMS */

/* tcf_exts_num_actions is exported by the kernel */
#define HAVE_TCF_EXTS_NUM_ACTIONS 1

/* tcf_exts_stats_update is defined */
/* #undef HAVE_TCF_EXTS_STATS_UPDATE */

/* struct tcf_pedit_parms has member tcfp_keys_ex */
#define HAVE_TCF_PEDIT_PARMS_TCFP_KEYS_EX 1

/* struct tcf_pedit has member tcfp_keys_ex */
/* #undef HAVE_TCF_PEDIT_TCFP_KEYS_EX_FIX */

/* linux/tcp.h has tcp_sock_set_nodelay */
#define HAVE_TCP_SOCK_SET_NODELAY 1

/* linux/tcp.h has tcp_sock_set_syncnt */
#define HAVE_TCP_SOCK_SET_SYNCNT 1

/* struct tc_action_ops has id */
#define HAVE_TC_ACTION_OPS_HAS_ID 1

/* struct tc_block_offload is defined */
/* #undef HAVE_TC_BLOCK_OFFLOAD */

/* struct tc_block_offload has extack */
/* #undef HAVE_TC_BLOCK_OFFLOAD_EXTACK */

/* pkt_cls.h enum enum tc_fl_command has TC_CLSFLOWER_STATS */
/* #undef HAVE_TC_CLSFLOWER_STATS_FIX */

/* TC_CLSMATCHALL_STATS is defined */
#define HAVE_TC_CLSMATCHALL_STATS 1

/* struct tc_cls_flower_offload has common */
/* #undef HAVE_TC_CLS_FLOWER_OFFLOAD_COMMON_FIX */

/* struct tc_cls_flower_offload has stats field */
/* #undef HAVE_TC_CLS_FLOWER_OFFLOAD_HAS_STATS_FIELD_FIX */

/* struct tc_cls_common_offload has extack */
/* #undef HAVE_TC_CLS_OFFLOAD_EXTACK_FIX */

/* struct tc_cls_flower_offload is defined */
/* #undef HAVE_TC_FLOWER_OFFLOAD */

/* struct tc_htb_command has moved_qid */
/* #undef HAVE_TC_HTB_COMMAND_HAS_MOVED_QID */

/* tc_htb_qopt_offload has prio */
#define HAVE_TC_HTB_OPT_PRIO 1

/* tc_htb_qopt_offload has quantum */
#define HAVE_TC_HTB_OPT_QUANTUM 1

/* tc_setup_cb_egdev_register is defined */
/* #undef HAVE_TC_SETUP_CB_EGDEV_REGISTER */

/* tc_setup_flow_action is defined */
/* #undef HAVE_TC_SETUP_FLOW_ACTION_FUNC */

/* tc_setup_flow_action has rtnl_held */
/* #undef HAVE_TC_SETUP_FLOW_ACTION_WITH_RTNL_HELD */

/* TC_TC_SETUP_FT is defined */
#define HAVE_TC_SETUP_FT 1

/* tc_setup_offload_action is defined */
/* #undef HAVE_TC_SETUP_OFFLOAD_ACTION_FUNC */

/* tc_setup_offload_action is defined and get 3 param */
#define HAVE_TC_SETUP_OFFLOAD_ACTION_FUNC_HAS_3_PARAM 1

/* linux/skbuff.h struct tc_skb_ext has act-miss */
/* #undef HAVE_TC_SKB_EXT_ACT_MISS */

/* tc_skb_ext_alloc is defined */
/* #undef HAVE_TC_SKB_EXT_ALLOC */

/* struct tlsdev_ops has tls_dev_resync */
#define HAVE_TLSDEV_OPS_HAS_TLS_DEV_RESYNC 1

/* net/tls.h has tls_driver_ctx */
#define HAVE_TLS_DRIVER_CTX 1

/* net/tls.h has tls_is_skb_tx_device_offloaded */
#define HAVE_TLS_IS_SKB_TX_DEVICE_OFFLOADED 1

/* tls_offload_context_tx has destruct_work as member */
#define HAVE_TLS_OFFLOAD_DESTRUCT_WORK 1

/* net/tls.h has struct tls_offload_resync_async is defined */
#define HAVE_TLS_OFFLOAD_RESYNC_ASYNC_STRUCT 1

/* net/tls.h has tls_offload_rx_force_resync_request */
/* #undef HAVE_TLS_OFFLOAD_RX_FORCE_RESYNC_REQUEST */

/* net/tls.h has tls_offload_rx_resync_async_request_start */
#define HAVE_TLS_OFFLOAD_RX_RESYNC_ASYNC_REQUEST_START 1

/* trace_block_bio_complete has 2 param */
#define HAVE_TRACE_BLOCK_BIO_COMPLETE_2_PARAM 1

/* trace_block_bio_remap has 4 param */
/* #undef HAVE_TRACE_BLOCK_BIO_REMAP_4_PARAM */

/* trace/events/rdma_core.h exists */
#define HAVE_TRACE_EVENTS_RDMA_CORE_HEADER 1

/* trace/events/sock.h has trace_sk_data_ready */
#define HAVE_TRACE_EVENTS_TRACE_SK_DATA_READY 1

/* rpcrdma.h exists */
#define HAVE_TRACE_RPCRDMA_H 1

/* linux/atomic/atomic-instrumented.h has try_cmpxchg */
#define HAVE_TRY_CMPXCHG 1

/* uapi/linux/nvme_ioctl.h has NVME_URING_CMD_ADMIN */
#define HAVE_UAPI_LINUX_NVME_NVME_URING_CMD_ADMIN 1

/* uapi/linux/nvme_ioctl.h has struct nvme_passthru_cmd64 */
#define HAVE_UAPI_LINUX_NVME_PASSTHRU_CMD64 1

/* udp_tunnel.h has struct udp_tunnel_nic_info is defined */
#define HAVE_UDP_TUNNEL_NIC_INFO 1

/* udp_tunnel.h has enum UDP_TUNNEL_NIC_INFO_STATIC_IANA_VXLAN */
#define HAVE_UDP_TUNNEL_NIC_INFO_STATIC_IANA_VXLAN 1

/* ib_umem_notifier_invalidate_range_start has parameter blockable */
/* #undef HAVE_UMEM_NOTIFIER_PARAM_BLOCKABLE */

/* net/xdp.h has __xdp_rxq_info_reg */
#define HAVE_UNDERSCORE_XDP_RXQ_INFO_REG 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* include/linux/units.h exists */
#define HAVE_UNITS_H 1

/* struct flow_block_offload has unlocked_driver_cb */
#define HAVE_UNLOCKED_DRIVER_CB 1

/* unpin_user_pages_dirty_lock is exported by the kernel */
#define HAVE_UNPIN_USER_PAGES_DIRTY_LOCK_EXPORTED 1

/* unpin_user_page_range_dirty_lock is exported by the kernel */
#define HAVE_UNPIN_USER_PAGE_RANGE_DIRTY_LOCK_EXPORTED 1

/* unregister_netdevice_notifier_net is defined */
#define HAVE_UNREGISTER_NETDEVICE_NOTIFIER_NET 1

/* user_access_begin has 2 parameters */
#define HAVE_USER_ACCESS_BEGIN_2_PARAMS 1

/* user_access_begin has 3 parameters */
/* #undef HAVE_USER_ACCESS_BEGIN_3_PARAMS */

/* flow_cls_offload has use_act_stats */
#define HAVE_USE_ACT_STATS 1

/* struct vdpa_config_ops has get_backend_features */
#define HAVE_VDPA_CONFIG_OPS_GET_BACKEND_FEATURES 1

/* struct vdpa_config_ops has get_backend_features */
#define HAVE_VDPA_CONFIG_OPS_GET_VQ_DMA_DEV 1

/* struct vdpa_config_ops has resume */
#define HAVE_VDPA_CONFIG_OPS_HAS_RESUME 1

/* sturct vdpa_dev_set_config has device_features */
#define HAVE_VDPA_SET_CONFIG_HAS_DEVICE_FEATURES 1

/* has vfio_combine_iova_ranges exists */
#define HAVE_VFIO_COMBINE_IOVA_RANGES 1

/* linux/vfio_pci_core.h exists */
#define HAVE_VFIO_PCI_CORE_H 1

/* vfio_pci_core_init_dev exists */
#define HAVE_VFIO_PCI_CORE_INIT 1

/* sturct vfio_precopy_info exists */
#define HAVE_VFIO_PRECOPY_INFO 1

/* struct vlan_ethhdr has addrs member */
#define HAVE_VLAN_ETHHDR_HAS_ADDRS 1

/* vlan_get_encap_level is defined */
/* #undef HAVE_VLAN_GET_ENCAP_LEVEL */

/* linux/vmalloc.h has __vmalloc 3 params */
/* #undef HAVE_VMALLOC_3_PARAM */

/* vm_flags_clear exists */
#define HAVE_VM_FLAGS_CLEAR 1

/* want_init_on_alloc is defined */
#define HAVE_WANT_INIT_ON_ALLOC 1

/* xa_array is defined */
#define HAVE_XARRAY 1

/* xa_for_each_range is defined */
#define HAVE_XA_FOR_EACH_RANGE 1

/* struct xfrmdev_ops has member xdo_dev_policy_add */
#define HAVE_XDO_DEV_POLICY_ADD 1

/* struct xfrmdev_ops has member xdo_dev_policy_add get extack */
#define HAVE_XDO_DEV_POLICY_ADD_GET_EXTACK 1

/* struct xfrmdev_ops has member xdo_dev_state_update_curlft */
#define HAVE_XDO_DEV_STATE_UPDATE_CURLFT 1

/* struct xfrmdev_ops has member xdo_dev_state_update_stats */
/* #undef HAVE_XDO_DEV_STATE_UPDATE_STATS */

/* struct xfrmdev_ops has member xdo_dev_state_add get extack */
#define HAVE_XDO_XFRM_ADD_STATE_GET_EXTACK 1

/* xdp_buff has flags as member */
#define HAVE_XDP_BUFF_HAS_FLAGS 1

/* xdp_buff has frame_sz as member */
#define HAVE_XDP_BUFF_HAS_FRAME_SZ 1

/* net/xdp.h has xdp_convert_buff_to_frame */
#define HAVE_XDP_CONVERT_BUFF_TO_FRAME 1

/* net/xdp.h has convert_to_xdp_frame */
/* #undef HAVE_XDP_CONVERT_TO_XDP_FRAME_IN_NET_XDP */

/* net/xdp.h has convert_to_xdp_frame workaround for
   5.4.17-2011.1.2.el8uek.x86_64 */
/* #undef HAVE_XDP_CONVERT_TO_XDP_FRAME_IN_UEK_KABI */

/* filter.h has xdp_do_flush_map */
#define HAVE_XDP_DO_FLUSH_MAP 1

/* net/xdp.h struct xdp_frame_bulk exists */
#define HAVE_XDP_FRAME_BULK 1

/* xdp_update_skb_shared_info is defined */
#define HAVE_XDP_GET_SHARED_INFO_FROM_BUFF 1

/* struct bpf_prog_aux has xdp_has_frags as member */
#define HAVE_XDP_HAS_FRAGS 1

/* net/xdp.h has xdp_init_buff */
#define HAVE_XDP_INIT_BUFF 1

/* struct net_device has struct net_device has xdp_metadata_ops member */
#define HAVE_XDP_METADATA_OPS 1

/* xdp_metadata_ops has xmo_rx_vlan_tag */
/* #undef HAVE_XDP_METADATA_OPS_HAS_VLAN_TAG */

/* net/xdp.h has xdp_rxq_info_reg get 4 params */
#define HAVE_XDP_RXQ_INFO_REG_4_PARAMS 1

/* xdp_set_features_flag defined */
#define HAVE_XDP_SET_FEATURES_FLAG 1

/* net/xdp_sock_drv.h exists */
#define HAVE_XDP_SOCK_DRV_H 1

/* chunk_size is defined */
#define HAVE_XDP_UMEM_CHUNK_SIZE 1

/* flags is defined */
#define HAVE_XDP_UMEM_FLAGS 1

/* xdp_update_skb_shared_info is defined */
#define HAVE_XDP_UPDATE_SKB_SHARED_INFO 1

/* XDRBUF_SPARSE_PAGES has defined in linux/sunrpc/xdr.h */
#define HAVE_XDRBUF_SPARSE_PAGES 1

/* xdr_buf_subsegment get const */
#define HAVE_XDR_BUF_SUBSEGMENT_CONST 1

/* xdr_decode_rdma_segment has defined */
#define HAVE_XDR_DECODE_RDMA_SEGMENT 1

/* xdr_encode_rdma_segment has defined */
#define HAVE_XDR_ENCODE_RDMA_SEGMENT 1

/* xdr_init_decode has rqst as a parameter */
#define HAVE_XDR_INIT_DECODE_RQST_ARG 1

/* xdr_init_encode has rqst as a parameter */
#define HAVE_XDR_INIT_ENCODE_RQST_ARG 1

/* xdr_item_is_absent has defined */
#define HAVE_XDR_ITEM_IS_ABSENT 1

/* xdr_stream_encode_item_absent has defined */
#define HAVE_XDR_STREAM_ENCODE_ITEM_ABSENT 1

/* xfrm_dev_offload has dir as member */
#define HAVE_XFRM_DEV_DIR 1

/* xfrm_dev_offload has flags */
#define HAVE_XFRM_DEV_OFFLOAD_FLAG_ACQ 1

/* xfrm_dev_offload has real_dev as member */
#define HAVE_XFRM_DEV_REAL_DEV 1

/* xfrm_dev_offload has type as member */
#define HAVE_XFRM_DEV_TYPE 1

/* struct xfrm_offload has inner_ipproto */
#define HAVE_XFRM_OFFLOAD_INNER_IPPROTO 1

/* XFRM_OFFLOAD_PACKET is defined */
#define HAVE_XFRM_OFFLOAD_PACKET 1

/* xfrm_dev_offload has state as member */
/* #undef HAVE_XFRM_STATE_DIR */

/* xfrm_state_offload has real_dev as member */
/* #undef HAVE_XFRM_STATE_REAL_DEV */

/* struct svc_xprt_ops has 'xpo_read_payload' field */
/* #undef HAVE_XPO_READ_PAYLOAD */

/* struct svc_xprt_ops has 'xpo_release_ctxt' field */
#define HAVE_XPO_RELEASE_CTXT 1

/* struct svc_xprt_ops has 'xpo_result_payload' field */
#define HAVE_XPO_RESULT_PAYLOAD 1

/* xpo_secure_port is defined and returns void */
/* #undef HAVE_XPO_SECURE_PORT_NO_RETURN */

/* xprt_add_backlog is exported by the sunrpc core */
#define HAVE_XPRT_ADD_BACKLOG 1

/* struct xprt_class has 'netid' field */
#define HAVE_XPRT_CLASS_NETID 1

/* xprt_lock_connect is exported by the sunrpc core */
#define HAVE_XPRT_LOCK_CONNECT 1

/* *send_request has 'struct rpc_rqst *req' as a param */
#define HAVE_XPRT_OPS_SEND_REQUEST_RQST_ARG 1

/* struct rpc_xprt has 'queue_lock' field */
#define HAVE_XPRT_QUEUE_LOCK 1

/* xprt_reconnect_delay is exported by the kernel */
#define HAVE_XPRT_RECONNECT_DELAY 1

/* get cong request */
#define HAVE_XPRT_REQUEST_GET_CONG 1

/* xprt_wait_for_buffer_space has xprt as a parameter */
#define HAVE_XPRT_WAIT_FOR_BUFFER_SPACE_RQST_ARG 1

/* xsk_buff_alloc is defined */
#define HAVE_XSK_BUFF_ALLOC 1

/* xsk_buff_alloc_batch is defined */
#define HAVE_XSK_BUFF_ALLOC_BATCH 1

/* xsk_buff_dma_sync_for_cpu get 2 params */
#define HAVE_XSK_BUFF_DMA_SYNC_FOR_CPU_2_PARAMS 1

/* xsk_buff_xdp_get_frame_dma is defined */
#define HAVE_XSK_BUFF_GET_FRAME_DMA 1

/* xsk_buff_set_size is defined */
#define HAVE_XSK_BUFF_SET_SIZE 1

/* struct xsk_tx_metadata_ops is defined */
/* #undef HAVE_XSK_TX_METADATA_OPS */

/* xsk_umem_adjust_offset is defined */
/* #undef HAVE_XSK_UMEM_ADJUST_OFFSET */

/* net/xdp_sock.h has xsk_umem_consume_tx get 2 params */
/* #undef HAVE_XSK_UMEM_CONSUME_TX_GET_2_PARAMS_IN_SOCK */

/* net/xdp_soc_drv.h has xsk_umem_consume_tx get 2 params */
/* #undef HAVE_XSK_UMEM_CONSUME_TX_GET_2_PARAMS_IN_SOCK_DRV */

/* xsk_umem_release_addr_rq is defined */
/* #undef HAVE_XSK_UMEM_RELEASE_ADDR_RQ */

/* __atomic_add_unless is defined */
/* #undef HAVE___ATOMIC_ADD_UNLESS */

/* __blkdev_issue_discard is defined */
/* #undef HAVE___BLKDEV_ISSUE_DISCARD */

/* __blkdev_issue_discard has 5 params */
#define HAVE___BLKDEV_ISSUE_DISCARD_5_PARAM 1

/* __flow_indr_block_cb_register is defined */
/* #undef HAVE___FLOW_INDR_BLOCK_CB_REGISTER */

/* HAVE___IP_DEV_FIND is exported by the kernel */
#define HAVE___IP_DEV_FIND 1

/* netdevice.h has __netdev_tx_sent_queue */
#define HAVE___NETDEV_TX_SENT_QUEUE 1

/* __tc_indr_block_cb_register is defined */
/* #undef HAVE___TC_INDR_BLOCK_CB_REGISTER */

/* Name of package */

/* Define to the address where bug reports for this package should be sent. */

/* Define to the full name of this package. */

/* Define to the full name and version of this package. */

/* Define to the one symbol short name of this package. */

/* Define to the home page for this package. */

/* Define to the version of this package. */

/* The size of `unsigned long long', as computed by sizeof. */
#define SIZEOF_UNSIGNED_LONG_LONG 8

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */

/* Make sure LINUX_BACKPORT macro is defined for all external users */
#ifndef LINUX_BACKPORT
#define LINUX_BACKPORT(__sym) backport_ ##__sym
#endif

/* Defines in this section calculated in ofed_scripts/configure 
 * based on defines prior this section
 *  _________________________________________________________ */
#define REBASE_STAGE_BACKPORTS 1
#define HAVE_BASECODE_EXTRAS 1
#define HAVE_TC_SETUP_FLOW_ACTION 1
#define HAVE_HMM_RANGE_FAULT_SUPPORT 1
#define HAVE_DEVLINK_HEALTH_REPORT_SUPPORT 1
#define HAVE_KTLS_RX_SUPPORT 1
#define HAVE_DEVLINK_PORT_ATRRS_SET_GET_SUPPORT 1
#define HAVE_DEVLINK_PORT_ATTRS_PCI_PF_SET 1
/* #undef HAVE_XSK_UMEM_CONSUME_TX_GET_2_PARAMS */
#define HAVE_GET_USER_PAGES_GUP_FLAGS 1
#define HAVE_XDP_SUPPORT 1
#define HAVE_VFIO_SUPPORT 1
#define HAVE_XSK_ZERO_COPY_SUPPORT 1
/* #undef HAVE_XDP_CONVERT_TO_XDP_FRAME */
#define HAVE_KERNEL_WITH_VXLAN_SUPPORT_ON 1
#define HAVE_UDP_TUNNEL_NIC_INFO_FULL 1
#define HAVE_IS_PCI_P2PDMA_PAGE 1
#define HAVE_BLK_MQ_BUSY_TAG_ITER_FN_BOOL 1
#define HAVE_BLK_MQ_ALLOC_DISK 1
#define HAVE_BLK_ALLOC_DISK 1
#define HAVE_DEVLINK_PORT_TYPE_ETH_SET 1
#define HAVE_DEVLINK_PER_AUXDEV 1
#define HAVE_TC_CLS_OFFLOAD_EXTACK 1
#define HAVE_TC_CLSFLOWER_STATS 1
#define HAVE_TC_CLS_FLOWER_OFFLOAD_HAS_STATS_FIELD 1
#define HAVE_TC_CLS_FLOWER_OFFLOAD_COMMON 1
#define HAVE_PRIO_CHAIN_SUPPORT 1
#define HAVE_TC_INDR_API 1
#define HAVE_DEVICE_ADD_DISK_3_ARGS 1
/* #undef HAVE_TCF_PEDIT_TCFP_KEYS_EX */
#define HAVE_VDPA_SUPPORT 1
#define HAVE_NET_PAGE_POOL_H 1
#define HAVE_SHAMPO_SUPPORT 1
#define HAVE_PAGE_POOL_GET_DMA_ADDR 1
#define HAVE_PAGE_POLL_NID_CHANGED 1
#define HAVE_GUP_MUST_UNSHARE_GET_3_PARAMS 1
#define HAVE_PAGE_POOL_PARAM_HAS_NAPI 1
#define HAVE_PAGE_POOL_DEFRAG_PAGE 1
/* #undef HAVE_PAGE_POOL_RELEASE_PAGE */
#define HAVE_DEVLINK_FMSG_BINARY_PAIR_PUT_ARG_U32 1
#define HAVE_LIGHT_SFS 1
/* #undef HAVE_DPLL_SUPPORT */
