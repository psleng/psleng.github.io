#ifndef _COMPAT_LINUX_SCHED_SIGNAL_H
#define _COMPAT_LINUX_SCHED_SIGNAL_H

#include "../../../compat/config.h"

#include_next <linux/sched/signal.h>

#endif /* _COMPAT_LINUX_SCHED_SIGNAL_H */
