#ifndef _COMPAT_NET_ADDRCONF_H
#define _COMPAT_NET_ADDRCONF_H

#include "../../compat/config.h"

#include_next <net/addrconf.h>

#endif /* _COMPAT_NET_ADDRCONF_H */
