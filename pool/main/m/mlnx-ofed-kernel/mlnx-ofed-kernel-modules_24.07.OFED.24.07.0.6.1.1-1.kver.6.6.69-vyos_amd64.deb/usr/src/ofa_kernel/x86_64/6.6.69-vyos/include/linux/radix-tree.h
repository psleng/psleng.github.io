#ifndef _COMPAT_LINUX_RADIX_TREE_H
#define _COMPAT_LINUX_RADIX_TREE_H

#include "../../compat/config.h"

#include_next <linux/radix-tree.h>

#endif /* _COMPAT_LINUX_RADIX_TREE_H */
