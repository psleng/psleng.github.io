#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(mlx_backport_dependency_symbol, "_gpl", "");
KSYMTAB_FUNC(backport_pcie_get_minimum_link, "", "");
KSYMTAB_FUNC(backport_mmu_notifier_call_srcu, "_gpl", "");
KSYMTAB_FUNC(backport_rdma_dim, "", "");
KSYMTAB_FUNC(backport_dim_on_top, "", "");
KSYMTAB_FUNC(backport_dim_turn, "", "");
KSYMTAB_FUNC(backport_dim_park_on_top, "", "");
KSYMTAB_FUNC(backport_dim_park_tired, "", "");
KSYMTAB_FUNC(backport_dim_calc_stats, "", "");
KSYMTAB_FUNC(backport_net_dim_get_rx_moderation, "", "");
KSYMTAB_FUNC(backport_net_dim_get_def_rx_moderation, "", "");
KSYMTAB_FUNC(backport_net_dim_get_tx_moderation, "", "");
KSYMTAB_FUNC(backport_net_dim_get_def_tx_moderation, "", "");
KSYMTAB_FUNC(backport_net_dim, "", "");

SYMBOL_CRC(mlx_backport_dependency_symbol, 0x1f057e46, "_gpl");
SYMBOL_CRC(backport_pcie_get_minimum_link, 0x08dd2992, "");
SYMBOL_CRC(backport_mmu_notifier_call_srcu, 0x2bba2f27, "_gpl");
SYMBOL_CRC(backport_rdma_dim, 0x3bd32712, "");
SYMBOL_CRC(backport_dim_on_top, 0x6d8a2eb5, "");
SYMBOL_CRC(backport_dim_turn, 0xaefe9e6c, "");
SYMBOL_CRC(backport_dim_park_on_top, 0x996c424e, "");
SYMBOL_CRC(backport_dim_park_tired, 0xe02c0ed7, "");
SYMBOL_CRC(backport_dim_calc_stats, 0xf3694eb8, "");
SYMBOL_CRC(backport_net_dim_get_rx_moderation, 0x60fb42e3, "");
SYMBOL_CRC(backport_net_dim_get_def_rx_moderation, 0x6c562101, "");
SYMBOL_CRC(backport_net_dim_get_tx_moderation, 0xdca21f24, "");
SYMBOL_CRC(backport_net_dim_get_def_tx_moderation, 0x9a6b24c7, "");
SYMBOL_CRC(backport_net_dim, 0xc13ab62b, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3ebf1316, "pcie_capability_read_word" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x59eee5c, "call_srcu" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x843251a5, "param_ops_charp" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xb43f9365, "ktime_get" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xb8e5f5dc, "module_layout" },
};

MODULE_INFO(depends, "");

