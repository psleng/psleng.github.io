#ifndef _COMPAT_LINUX_SCHED_H
#define _COMPAT_LINUX_SCHED_H

#include "../../compat/config.h"

#include_next <linux/sched.h>

#endif /* _COMPAT_LINUX_SCHED_H */
