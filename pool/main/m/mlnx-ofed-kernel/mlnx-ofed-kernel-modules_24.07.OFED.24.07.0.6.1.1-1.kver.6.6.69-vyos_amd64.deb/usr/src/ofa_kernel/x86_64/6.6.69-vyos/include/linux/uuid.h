#ifndef _COMPAT_LINUX_UUID_H
#define _COMPAT_LINUX_UUID_H

#include "../../compat/config.h"

#include_next <linux/uuid.h>

#endif /* _COMPAT_LINUX_UUID_H */
