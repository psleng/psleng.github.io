#ifndef _COMPAT_LINUX_REFCOUNT_H
#define _COMPAT_LINUX_REFCOUNT_H

#include "../../compat/config.h"

#include_next <linux/refcount.h>

#endif /* _COMPAT_LINUX_REFCOUNT_H */
