#ifndef _COMPAT_LINUX_BITMAP_H
#define _COMPAT_LINUX_BITMAP_H

#include "../../compat/config.h"

#include_next <linux/bitmap.h>


#endif /* _COMPAT_LINUX_BITMAP_H */
