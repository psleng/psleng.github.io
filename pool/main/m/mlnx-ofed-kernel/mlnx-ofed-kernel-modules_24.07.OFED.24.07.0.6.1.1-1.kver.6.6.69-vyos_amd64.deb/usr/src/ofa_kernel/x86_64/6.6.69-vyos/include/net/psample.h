#ifndef _COMPAT_NET_PSAMPLE_H
#define _COMPAT_NET_PSAMPLE_H 1

#include "../../compat/config.h"

#include_next <net/psample.h>

#endif /* _COMPAT_NET_PSAMPLE_H */
