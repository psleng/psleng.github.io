#ifndef _COMPAT_LINUX_TIMEKEEPING_H
#define _COMPAT_LINUX_TIMEKEEPING_H

#include "../../compat/config.h"

#include_next <linux/timekeeping.h>

#endif /* _COMPAT_LINUX_TIMEKEEPING_H */
