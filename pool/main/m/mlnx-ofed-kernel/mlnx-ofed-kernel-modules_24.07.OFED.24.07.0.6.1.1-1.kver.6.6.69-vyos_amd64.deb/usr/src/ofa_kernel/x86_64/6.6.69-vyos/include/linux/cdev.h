#ifndef _COMPAT_LINUX_CDEV_H
#define _COMPAT_LINUX_CDEV_H

#include "../../compat/config.h"

#include_next <linux/cdev.h>

#endif /* _COMPAT_LINUX_CDEV_H */
