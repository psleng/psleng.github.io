#ifndef _COMPAT_NET_DST_H
#define _COMPAT_NET_DST_H 1

#include "../../compat/config.h"

#include_next <net/dst.h>

#endif	/* _COMPAT_NET_DST_H */
