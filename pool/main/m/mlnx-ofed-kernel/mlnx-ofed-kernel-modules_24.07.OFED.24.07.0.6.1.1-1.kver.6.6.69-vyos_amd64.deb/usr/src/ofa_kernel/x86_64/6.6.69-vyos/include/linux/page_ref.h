#ifndef _COMPAT_LINUX_PAGE_REF_H
#define _COMPAT_LINUX_PAGE_REF_H

#include "../../compat/config.h"

#include_next <linux/page_ref.h>

#endif /* _COMPAT_LINUX_PAGE_REF_H */
