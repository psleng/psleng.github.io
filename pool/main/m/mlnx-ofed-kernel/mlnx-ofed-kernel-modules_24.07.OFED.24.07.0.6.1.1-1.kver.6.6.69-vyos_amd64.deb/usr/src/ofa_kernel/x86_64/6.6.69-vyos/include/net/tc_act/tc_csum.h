#ifndef _COMPAT_NET_TC_ACT_TC_CSUM_H
#define _COMPAT_NET_TC_ACT_TC_CSUM_H 1

#include "../../../compat/config.h"

#include <linux/tc_act/tc_csum.h>
#include_next <net/tc_act/tc_csum.h>

#endif /* _COMPAT_NET_TC_ACT_TC_CSUM_H */
