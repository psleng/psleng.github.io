#ifndef _COMPAT_LINUX_IRQ_POLL_H
#define _COMPAT_LINUX_IRQ_POLL_H 1

#include "../../compat/config.h"

#include_next <linux/irq_poll.h>

#endif	/* _COMPAT_LINUX_IRQ_POLL_H */
