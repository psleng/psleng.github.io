#ifndef _COMPAT_LINUX_IF_LINK_H
#define _COMPAT_LINUX_IF_LINK_H

#include "../../compat/config.h"

#include_next <linux/if_link.h>

#endif /* _COMPAT_LINUX_IF_LINK_H */
