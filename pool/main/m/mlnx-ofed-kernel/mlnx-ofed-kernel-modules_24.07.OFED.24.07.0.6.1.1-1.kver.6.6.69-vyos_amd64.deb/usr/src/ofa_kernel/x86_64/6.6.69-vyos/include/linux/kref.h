#ifndef _COMPAT_LINUX_KREF_H
#define _COMPAT_LINUX_KREF_H

#include "../../compat/config.h"

#include_next <linux/kref.h>

#endif /* _COMPAT_LINUX_KREF_H */
