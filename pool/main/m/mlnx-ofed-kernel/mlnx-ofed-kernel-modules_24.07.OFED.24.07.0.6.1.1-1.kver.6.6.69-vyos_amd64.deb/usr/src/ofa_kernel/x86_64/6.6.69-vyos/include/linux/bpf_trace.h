#ifndef _COMPAT_LINUX_BPF_TRACE_H
#define _COMPAT_LINUX_BPF_TRACE_H

#include "../../compat/config.h"

#include <linux/bpf.h>
#include_next <linux/bpf_trace.h>

#endif /* _COMPAT_LINUX_BPF_TRACE_H */
