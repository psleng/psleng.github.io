#ifndef _COMPAT_LINUX_CGROUP_RDMA_H
#define _COMPAT_LINUX_CGROUP_RDMA_H

#include "../../compat/config.h"

#include_next <linux/cgroup_rdma.h>

#endif /* _COMPAT_LINUX_CGROUP_RDMA_H */
