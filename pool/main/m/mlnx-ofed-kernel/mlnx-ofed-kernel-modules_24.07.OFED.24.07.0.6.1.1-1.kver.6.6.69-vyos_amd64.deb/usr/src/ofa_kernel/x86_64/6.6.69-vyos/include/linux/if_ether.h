#ifndef _COMPAT_LINUX_IF_ETHER_H
#define _COMPAT_LINUX_IF_ETHER_H

#include "../../compat/config.h"

#include_next <linux/if_ether.h>

#endif /* _COMPAT_LINUX_IF_ETHER_H */
