#ifndef _COMPAT_NET_IP_TUNNELS_H
#define _COMPAT_NET_IP_TUNNELS_H

#include "../../compat/config.h"

#include_next <net/ip_tunnels.h>

#endif /* _COMPAT_NET_IP_TUNNELS_H */
