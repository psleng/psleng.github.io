#ifndef _COMPAT_LINUX_COMPILER_INTEL_H
#define _COMPAT_LINUX_COMPILER_INTEL_H

#include "../../compat/config.h"

#include_next <linux/compiler-intel.h>

#endif /* _COMPAT_LINUX_COMPILER_INTEL_H */
