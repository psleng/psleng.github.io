#ifndef _COMPAT_LINUX_KERN_LEVELS_H
#define _COMPAT_LINUX_KERN_LEVELS_H 1

#include "../../compat/config.h"

#include_next <linux/kern_levels.h>

#endif	/*  _COMPAT_LINUX_KERN_LEVELS_H */
