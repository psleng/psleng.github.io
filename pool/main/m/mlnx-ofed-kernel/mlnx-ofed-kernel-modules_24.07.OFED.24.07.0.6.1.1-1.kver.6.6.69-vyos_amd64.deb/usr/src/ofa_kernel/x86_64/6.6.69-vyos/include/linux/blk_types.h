#ifndef _COMPAT_LINUX_BLK_TYPES_H
#define _COMPAT_LINUX_BLK_TYPES_H

#include "../../compat/config.h"

#include_next <linux/blk_types.h>

#endif /* _COMPAT_LINUX_BLK_TYPES_H */
