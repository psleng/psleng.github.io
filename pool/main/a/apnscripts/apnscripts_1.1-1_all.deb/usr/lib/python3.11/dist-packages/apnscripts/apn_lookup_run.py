from apnscripts.service_provider_parser import check_parse_conditions
from apnscripts.read_carrier_ids import read_aosp_carriers


def find_apn_list(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn):
    apnList = []
    aosp_list = read_aosp_carriers(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn)
    check_parse_conditions(mccmnc, apnList)
    final_list = aosp_list + apnList
    return final_list
