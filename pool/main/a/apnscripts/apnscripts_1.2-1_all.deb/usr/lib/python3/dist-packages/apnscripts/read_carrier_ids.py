from lxml import etree
import collections
from enum import IntEnum

SCORE_MCCMNC = 1 << 8
SCORE_IMSI_PREFIX = 1 << 7
SCORE_ICCID_PREFIX = 1 << 6
SCORE_GID1 = 1 << 5
SCORE_GID2 = 1 << 4
SCORE_SPN = 1 << 1
SCORE_APN = 1 << 0


class CarrierState(IntEnum):
    """
    An enum class that denotes what state the AsyncServiceProviderParser is at.
    """
    LIST = 0
    ID = 1
    ATTRIBUTE = 2
    MCCMNC = 3
    ERROR = 4


class CarrierIdParser:
    def __init__(self, match_score, carrierList):
        self.match_score = match_score
        self.current_score = None
        self.mccmnc = ""
        self.carrierList = carrierList
        self.state = CarrierState.LIST
        self.canonical_id = None
        self.carrier_name = ""
        self.imsi_prefix = ""
        self.iccid_prefix = ""
        self.gid1 = ""
        self.gid2 = ""
        self.plmn = ""
        self.spn = ""
        self.matched_mccmnc = False
        self.text = None
        self.max_score = 0

    def start_list(self, tag, attrib):
        if tag.lower() == 'carrier_list':
            return
        elif tag.lower() == 'carrier_id':
            for key, value in attrib.items():
                if key.lower() == 'canonical_id':
                    self.canonical_id = value
                elif key.lower() == 'carrier_name':
                    self.carrier_name = value
            self.max_score = 0
            self.state = CarrierState.ID

    def start_id(self, tag, attrib):
        if tag.lower() == 'carrier_attribute':
            self.current_score = None
            self.state = CarrierState.ATTRIBUTE

    def start_attribute(self, tag, attrib):
        return

    def start(self, tag, attrib):
        match self.state:
            case CarrierState.LIST:
                self.start_list(tag, attrib)
            case CarrierState.ID:
                self.start_id(tag, attrib)
            case CarrierState.ATTRIBUTE:
                self.start_attribute(tag, attrib)

    def data(self, data):
        self.text = data

    def end_attribute(self, tag):
        if tag.lower() == 'mccmnc_tuple':
            if self.text == self.match_score.mccmnc:
                self.matched_mccmnc = True
                self.mccmnc = self.text
        elif tag.lower() == 'gid1':
            if self.match_score.gid1 == self.text:
                self.gid1 = self.text
        elif tag.lower() == 'gid2':
            if self.match_score.gid2 == self.text:
                self.gid2 = self.text
        elif tag.lower() == 'spn':
            if self.match_score.spn == self.text:
                self.spn = self.text
        elif tag.lower() == 'imsi_prefix_xpattern':
            if self.match_score.imsi == self.text:
                self.imsi_prefix = self.text
        elif tag.lower() == 'iccid_prefix':
            if self.match_score.iccid == self.text:
                self.iccid_prefix = self.text
        elif tag.lower() == 'carrier_attribute':
            score = MatchingScore(self.mccmnc, self.imsi_prefix, self.iccid_prefix, self.gid1, self.gid2, "", self.spn)
            score.compare_score(self.match_score)
            if score.score > self.max_score:
                self.max_score = score.score
            self.current_score = score
            self.imsi_prefix = ""
            self.iccid_prefix = ""
            self.gid1 = ""
            self.gid2 = ""
            self.plmn = ""
            self.spn = ""
            self.state = CarrierState.ID

    def end_id(self, tag):
        if tag.lower() == 'carrier_id':
            if self.matched_mccmnc:
                string = self.current_score.mccmnc
                string = string + ('GID1=' + self.current_score.gid1.upper() if self.current_score.gid1 else "")
                string = string + ('IMSI=' + self.current_score.imsi.upper() if self.current_score.imsi else "")
                string = string + ('SPN=' + self.current_score.spn.upper() if self.current_score.spn else "")
                self.carrierList[self.canonical_id] = {'carrier_string': string, 'score': self.max_score}
                # print(self.carrierList)

            self.matched_mccmnc = False
            self.state = CarrierState.LIST
            self.canonical_id = -1
            self.carrier_name = ""

    def end(self, tag):
        match self.state:
            case CarrierState.LIST:
                return
            case CarrierState.ID:
                self.end_id(tag)
            case CarrierState.ATTRIBUTE:
                self.end_attribute(tag)

    def close(self):
        # print(self.carrierList)
        return


def read_carrier_xml(match_score):
    # parse the carrier ids xml created from convert_pb_to_xml.py
    carrierList = {}
    target = CarrierIdParser(match_score, carrierList)
    state_parser = etree.XMLPullParser(events=('start', 'end'), target=target, recover=True)
    with open("/etc/igos/lte/carrier_ids.xml", "r") as carrier_file:
        state_parser.read_events()
        while True:
            line = carrier_file.read(4096)
            if not line:
                break
            state_parser.feed(line)
        carrier_file.close()
    state_parser.close()
    return carrierList


APN_TYPE_MAP = {
    '*': 'ALL',
    'default': 'DEFAULT',
    'internet': 'DEFAULT',
    'vzw800': 'DEFAULT',
    'mms': 'MMS',
    'sup': 'SUPL',
    'supl': 'SUPL',
    'agps': 'SUPL',
    'pam': 'DUN',
    'dun': 'DUN',
    'hipri': 'HIPRI',
    'ota': 'FOTA',
    'fota': 'FOTA',
    'admin': 'FOTA',
    'ims': 'IMS',
    'cbs': 'CBS',
    'ia': 'IA',
    'emergency': 'EMERGENCY',
    'mcx': 'EMERGENCY',
    'xcap': 'XCAP',
    'ut': 'UT',
    'rcs': 'RCS',
}

APN_STRING_KEYS = [
    'server', 'proxy', 'port', 'user', 'password', 'mmsc',
    'mmsc_proxy', 'mmsc_proxy_port'
]

APN_REMAP_KEYS = {
    'mmsproxy': 'mmsc_proxy',
    'mmsport': 'mmsc_proxy_port'
}

APN_INT_KEYS = [
    'authtype', 'mtu', 'max_conns', 'wait_time', 'max_conns_time'
]

AUTH_MAP = {'0': 'none', '1': 'pap', '2': 'chap', '3': 'paporchap'}


APN_BOOL_KEYS = [
    'modem_cognitive', 'user_visible', 'user_editable'
]

BOOL_MAP = {'true': True, 'false': False, '1': True, '0': False}


class MatchingScore():
    def __init__(self, mccmnc, imsi, iccid, gid1, gid2, plmn, spn):
        self.mccmnc = mccmnc
        self.imsi = imsi
        self.iccid = iccid
        self.gid1 = gid1
        self.gid2 = gid2
        self.spn = spn
        self.score = 0
        self.plmn = plmn

    def compare_score(self, score):
        if self.mccmnc == score.mccmnc:
            self.score += SCORE_MCCMNC
        if score.gid1 and self.gid1 and self.gid1.upper() == score.gid1.upper():
            self.score += SCORE_GID1
        if score.imsi and self.imsi and self.imsi.upper() == score.imsi.upper():
            self.score += SCORE_IMSI_PREFIX
        if score.spn and self.spn and self.spn.upper() == score.spn.upper():
            self.score += SCORE_SPN


class ApnItem():
    def __init__(self, name, apn, score):
        self.name = name
        self.apn = apn
        self.type = []
        self.server = None
        self.proxy = None
        self.username = None
        self.password = None
        self.authtype = None
        self.protocol = None
        self.roaming = None
        self.mmsc = None
        self.mmsc_proxy = None
        self.mmsc_proxy_port = None
        self.score = score


class CarrierId():
    def __init__(self, mcc_mnc, imsi, gid1, spn):
        self.mcc_mnc = mcc_mnc
        self.spn = spn
        self.imsi = imsi
        self.gid1 = gid1


# function to convert a carrier id to a name
# name should be format of MCCMNC(GID1=...[SPN=...{IMSI=...}])
# where everything in () is optional
def to_string(cid):
    ret = cid.mcc_mnc
    if cid.spn:
        ret += 'SPN=' + cid.spn.upper()
    if cid.imsi:
        ret += 'IMSI=' + cid.imsi.upper()
    if cid.gid1:
        ret += 'GID1=' + cid.gid1.upper()
    return ret


"""
def process_by_carrier_id(apn_node, carrier_list, apn_list, match_score):
    #mccmnc must be of valid length
    mccmnc_match = match_score.mccmnc
    score_list = []
    cname_list = []
    cname_map = {}
    if len(mccmnc_match) > 0:
        apn_carrier_id = apn_node.get('carrier_id') #if apn_node.get('carrier_id') else None
        #there are carriers in the carrier list
        for carriers in carrier_list.carrier_id:
            aosp_canonical_id = carriers.canonical_id
            #if the <apn></apn> tag in apns.xml has the same carrier id as in the carrier id list
            if apn_carrier_id != None and apn_carrier_id == str(aosp_canonical_id):
                #there are attributes in each carrier which can hold different mccmnc, spn, gid, etc
                for attribute in carriers.carrier_attribute:
                    #there can be multiple mccmncs for each carrier
                    for mccmnc in attribute.mccmnc_tuple:
                        if mccmnc == mccmnc_match:
                            cname = mccmnc_match
                            gid1_list = attribute.gid1 if len(attribute.gid1) else [""]
                            for gid1 in gid1_list:
                                cname_gid1 = cname + ("GID1=" + gid1.upper() if gid1 else "")
                                spn_list = attribute.spn if len(attribute.spn) else [""]
                                for spn in spn_list:
                                    cname_spn = cname_gid1 + ("SPN=" + spn.upper() if spn else "")
                                    imsi_list = attribute.imsi_prefix_xpattern if len(attribute.imsi_prefix_xpattern) else [""]
                                    for imsi in imsi_list:
                                        cname_imsi = cname_spn + ("IMSI=" + imsi.upper() if imsi else "")
                                        score = MatchingScore(mccmnc, imsi, "", gid1, "", "", spn)
                                        score.compare_score(match_score)
                                        cname_list.append(cname_imsi)
                                        apnitem = gen_apnitem(apn_node, score.score)
                                        #if this is a new apn item, then add it
                                        if apnitem not in apn_list[cname_imsi]:
                                            apn_list[cname_imsi].append(gen_apnitem(apn_node, score.score))
                            break
    print('done carrier')
"""


def gen_apnitem(node, score):
    item = {}
    item['score'] = score
    item['name'] = node.get('carrier')
    if node.get('apn'):
        item['apn'] = node.get('apn')
    if node.get('type'):
        # split the types into a list
        item['type'] = [types.strip().lower() for types in node.get('type').split(',')]

    for key in ['protocol', 'roaming_protocol']:
        if node.get(key):
            item[key] = node.get(key).lower()
    for key, value in node.items():
        if key in APN_STRING_KEYS:
            item[key] = node.get(key)
            continue
        if key in APN_REMAP_KEYS:
            # rename the keys
            item[APN_REMAP_KEYS[key]] = node.get(key)
            continue
        if key in APN_INT_KEYS:
            if key == 'authtype':
                item[key] = AUTH_MAP[node.get(key).lower()]
            else:
                item[key] = int(node.get(key))
            continue
        if key in APN_BOOL_KEYS:
            item[key] = BOOL_MAP[node.get(key).lower()]
            continue
    return item


def gen_cid(node):
    mcc_mnc = None
    # if there's a mccmnc, we should record it
    if node.get('mcc') and node.get('mnc'):
        mcc_mnc = node.get('mcc') + node.get('mnc')
    mvno_type = None
    mvno_data = None
    spn = None
    gid1 = None
    imsi = None
    if node.get('mvno_type'):
        mvno_type = node.get('mvno_type')
    if node.get('mvno_match_data'):
        mvno_data = node.get('mvno_match_data')
    if mvno_type is not None:
        if mvno_type.lower() == 'spn':
            spn = mvno_data
        if mvno_type.lower() == 'imsi':
            imsi = mvno_data
        if mvno_type.lower() == 'gid':
            gid1 = mvno_data
    ret = CarrierId(mcc_mnc, imsi, gid1, spn)
    return ret


def process_by_mccmnc(node, carrier_id, apn_list, match_score):
    # the score that we compare all the apns to
    score = MatchingScore(carrier_id.mcc_mnc, carrier_id.imsi, "", carrier_id.gid1, "", "", carrier_id.spn)
    score.compare_score(match_score)
    apnitem = gen_apnitem(node, score.score)
    # if the apn is unique, add it
    if apnitem not in apn_list[to_string(carrier_id)]:
        apn_list[to_string(carrier_id)].append(gen_apnitem(node, score.score))


def process_by_carrier_id_v2(apn_node, carrier_list, apn_list, match_score):
    apn_carrier_id = apn_node.get('carrier_id')
    if apn_carrier_id is not None and apn_carrier_id in carrier_list.keys():
        apnitem = gen_apnitem(apn_node, carrier_list[apn_carrier_id]['score'])
        if apnitem not in apn_list[carrier_list[apn_carrier_id]['carrier_string']]:
            apn_list[carrier_list[apn_carrier_id]['carrier_string']].append(apnitem)


def read_aosp_carriers(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn):
    # the score that we compare all the apns to
    match_score = MatchingScore(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn)
    apn_list = collections.defaultdict(list)

    carrier_list = read_carrier_xml(match_score)
    # pull parser
    parser = etree.XMLPullParser(events=('start', 'end'), recover=True)

    # read from the apns.xml file
    with open("/etc/igos/lte/apns.xml", "r") as apns_file:
        parser.read_events()
        while True:
            line = apns_file.read(4096)
            if not line:
                break
            parser.feed(line)
            # apns.xml is filled with <apn/> tags
            for action, elem in parser.read_events():
                if action == 'start' and elem.tag == 'apn':
                    apn_node = elem.attrib
                    carrier_id = gen_cid(apn_node)
                    if apn_node.get('type'):
                        # if the list of types has only one length and it's not default or dun, then it's not
                        # an internet apn. exclude that apn_node
                        type_list = [types.strip().lower() for types in apn_node.get('type').split(',')]
                        if len(type_list) == 1 and ('default' not in type_list or 'dun' in type_list):
                            continue
                    if carrier_id.mcc_mnc and carrier_id.mcc_mnc == mccmnc:
                        # either process by mccmnc
                        process_by_mccmnc(apn_node, carrier_id, apn_list, match_score)
                    elif not carrier_id.mcc_mnc:
                        # or by carrier id if there's no mccmnc
                        process_by_carrier_id_v2(apn_node, carrier_list, apn_list, match_score)
        apns_file.close()
    parser.close()
    # flatten list, the keys previously used aren't really usable for sorting
    values = [x for v in apn_list.values() for x in v]
    values.sort(key=lambda value: value['score'], reverse=True)
    # print(len(values))
    return values
