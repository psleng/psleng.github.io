from lxml import etree
from enum import IntEnum


class ParseState(IntEnum):
    """
    An enum class that denotes what state the AsyncServiceProviderParser is at.
    """
    TOPLEVEL = 0
    COUNTRY = 1
    PROVIDER = 2
    GSM = 3
    GSM_APN = 4
    CDMA = 5
    DONE = 6
    ERROR = 7


# a list should be passed into this function
def is_parser_necessary(apnList):
    if len(apnList) == 0:
        return True
    else:
        return False


def check_parse_conditions(mncmcc, apnList):
    if is_parser_necessary(apnList) is True and len(mncmcc) > 0:
        target = ServiceProviderParser(mncmcc, apnList)
        state_parser = etree.XMLPullParser(events=('start', 'end'), target=target, recover=True)
        with open('/usr/share/mobile-broadband-provider-info/serviceproviders.xml', mode='r', encoding='utf-8') as file:
            state_parser.read_events()
            while True:
                line = file.read(4096)
                if not line:
                    break
                state_parser.feed(line)
        file.close()
        state_parser.close()


class ServiceProviderParser:
    def __init__(self, mncmcc, apnList):
        self.apnList = apnList
        self.mncmcc = mncmcc
        self.matched_mncmcc = False
        self.internet_apn = False
        self.state = ParseState.TOPLEVEL
        self.apn = None
        self.username = None
        self.password = None
        self.auth_method = None
        self.gateway = None
        self.name = None
        self.dns = []
        self.text = None

    def start_toplevel(self, tag, attrib):
        if tag.lower() == 'serviceproviders':
            for key, value in attrib.items():
                # if format is not 2.0, then we're using wrong xml
                if key.lower() == 'format' and value.lower() != '2.0':
                    self.state = ParseState.ERROR
        elif tag.lower() == 'country':
            self.state = ParseState.COUNTRY

    def start_country(self, tag, attrib):
        if tag.lower() == 'provider':
            self.state = ParseState.PROVIDER

    def start_provider(self, tag, attrib):
        if tag.lower() == 'gsm':
            self.state = ParseState.GSM

    def start_gsm(self, tag, attrib):
        if tag.lower() == 'network-id':
            mnc = None
            mcc = None
            for key, value in attrib.items():
                if key.lower() == 'mnc':
                    mnc = value
                elif key.lower() == 'mcc':
                    mcc = value
                # if mcc and mnc are both available
                if mcc is not None and mnc is not None:
                    mncmcc = "%s%s" % (mcc, mnc)
                    if self.mncmcc == mncmcc:
                        self.matched_mncmcc = True
                    break
        elif tag.lower() == 'apn':
            self.apn = None
            self.username = None
            self.password = None
            self.auth_method = None
            self.dns = []
            for key, value in attrib.items():
                if key.lower() == 'value':
                    self.state = ParseState.GSM_APN
                    self.apn = value
                    break

    def start_gsm_apn(self, tag, attrib):
        if tag.lower() == 'usage':
            for key, value in attrib.items():
                if key.lower() == 'type' and value.lower() == 'internet':
                    self.internet_apn = True
                    break
        elif tag.lower() == 'authentication':
            for key, value in attrib.items():
                if key.lower() == 'method':
                    self.auth_method = value
                    break

    def start(self, tag, attrib):
        match self.state:
            case ParseState.TOPLEVEL:
                self.start_toplevel(tag, attrib)
            case ParseState.COUNTRY:
                self.start_country(tag, attrib)
            case ParseState.PROVIDER:
                self.start_provider(tag, attrib)
            case ParseState.GSM:
                self.start_gsm(tag, attrib)
            case ParseState.GSM_APN:
                self.start_gsm_apn(tag, attrib)
            case ParseState.ERROR:
                return

    def data(self, data):
        self.text = data

    def end_country(self, tag):
        if tag.lower() == 'country':
            self.state = ParseState.TOPLEVEL

    def end_provider(self, tag):
        if tag.lower() == 'provider':
            self.state = ParseState.COUNTRY
        if tag.lower() == 'name':
            self.name = self.text

    def end_gsm(self, tag):
        if tag.lower() == 'gsm':
            self.state = ParseState.PROVIDER
            self.matched_mncmcc = False

    def end_gsm_apn(self, tag):
        if tag.lower() == 'username':
            self.username = self.text
        elif tag.lower() == 'password':
            self.password = self.text
        elif tag.lower() == 'dns':
            self.dns.append(self.text)
        elif tag.lower() == 'gateway':
            self.gateway = self.text
        elif tag.lower() == 'name':
            self.name = self.text
        elif tag.lower() == 'apn':
            self.text = None
            if self.matched_mncmcc is True and self.internet_apn is True:
                item = {'score': 256, 'apn': self.apn, 'type': ['default']}
                if self.name is not None:
                    item['name'] = self.name
                if self.username is not None:
                    item['user'] = self.username
                if self.password is not None:
                    item['password'] = self.password
                if len(self.dns) != 0:
                    item['dns'] = self.dns
                if self.auth_method is not None:
                    item['authtype'] = self.auth_method
                # append apn to apn list
                self.apnList.append(item)
                self.internet_apn = False
            self.state = ParseState.GSM

    def end(self, tag):
        match self.state:
            case ParseState.TOPLEVEL:
                return
            case ParseState.COUNTRY:
                self.end_country(tag)
            case ParseState.PROVIDER:
                self.end_provider(tag)
            case ParseState.GSM:
                self.end_gsm(tag)
            case ParseState.GSM_APN:
                self.end_gsm_apn(tag)
            case ParseState.ERROR:
                return

    def close(self):
        return
