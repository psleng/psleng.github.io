from apnscripts.read_carrier_ids import read_aosp_carriers


def find_apn_list(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn):
    aosp_list = read_aosp_carriers(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn)
    final_list = aosp_list
    if len(final_list) == 0:
        raise Exception("No matching APN found")
    return final_list
