import carrierId_pb2
from lxml import etree


# for apns.xml, it's possible to have only carrier id and no mccmncs
# it's also possible to have no carrier id and only mccmnc
# the carrier_list.pb will not always have the mccmnc, but only matches the carrier_id

# update_apn.py from AOSP seems to only process by apns.xml as long as there's a mccmnc
# but this could miss some information held by carrier_list
# e.g. vodafone is in both apns.xml and the carrier_list.pb, but the carrier_list.pb has the spn and imsi_prefix matches
# whereas the apns.xml doesn't.

# so apns.xml nodes could have either carrier_id only or carrier_id and mccmnc or only mccmnc
# carrier_list.pb nodes have to have mccmncs but they don't always match with the apns.xml nodes
# for only mccmnc match, we shouldn't look at carrier_list.pb
# for mccmnc and carrier_id match, if we want to look at carrier_list.pb, we'd need to search for matching carrier_id
# for carrier_id only, we'd need to search for matching carrier_id
# however, we want the algorithm to only select the apn nodes with the matching mccmncs
# so for carrier_id only, we'd need to search for matching carrier_id and see if it also has the matching mccmncs

# if we search through carrier_list.pb first, and search by matching mccmnc, we'll potentially miss matching carrier_id but non-matching mccmncs
# if we go through apns.xml first and search by matching mccmnc, we may have some that have the wrong mccmnc but the carrier_id has the correct mccmnc
# what apns.xml does is they create a list of each mccmnc, gid, imsi, spn combination. e.g. 302720GID=YYIMSI=XXXXSPN=Z


# the way AOSP handles carrier matching is through SCORE, the higher score there is, the more likely that carrier_id is us
# so the carrier_id with the highest matching score should have higher priority
# so the apn for that carrier_id should have the highest priority

def convert_pb_to_xml():
    carrier_list = carrierId_pb2.CarrierList()
    # convert the carrier_list.pb into the items in carrierId.proto
    with open("carrier_list.pb", "rb") as file:
        carrier_list.ParseFromString(file.read())

    root = etree.Element('carrier_list')

    for carrier_id in carrier_list.carrier_id:
        # print(carrier_id)
        carrier_item = etree.SubElement(root, 'carrier_id', canonical_id=str(carrier_id.canonical_id),
                                        carrier_name=carrier_id.carrier_name)
        for attribute in carrier_id.carrier_attribute:
            carrier_attribute = etree.SubElement(carrier_item, 'carrier_attribute')
            for mccmnc in attribute.mccmnc_tuple:
                mccmnc_item = etree.SubElement(carrier_attribute, 'mccmnc_tuple')
                mccmnc_item.text = mccmnc
            gid1_list = attribute.gid1 if len(attribute.gid1) else [""]
            for gid1 in gid1_list:
                if gid1 != "":
                    gid1_item = etree.SubElement(carrier_attribute, 'gid1')
                    gid1_item.text = gid1
            gid2_list = attribute.gid2 if len(attribute.gid2) else [""]
            for gid2 in gid2_list:
                if gid2 != "":
                    gid2_item = etree.SubElement(carrier_attribute, 'gid2')
                    gid2_item.text = gid2
            spn_list = attribute.spn if len(attribute.spn) else [""]
            for spn in spn_list:
                if spn != "":
                    spn_item = etree.SubElement(carrier_attribute, 'spn')
                    spn_item.text = spn
            imsi_list = attribute.imsi_prefix_xpattern if len(attribute.imsi_prefix_xpattern) else [""]
            for imsi in imsi_list:
                if imsi != "":
                    imsi_item = etree.SubElement(carrier_attribute, 'imsi_prefix_xpattern')
                    imsi_item.text = imsi
            preferred_apn_list = attribute.preferred_apn if len(attribute.preferred_apn) else [""]
            for apn in preferred_apn_list:
                if apn != "":
                    apn_item = etree.SubElement(carrier_attribute, 'preferred_apn')
                    apn_item.text = apn

    tree = etree.ElementTree(root)
    tree.write('carrier_ids.xml')


if __name__ == "__main__":
    convert_pb_to_xml()
