from lxml import etree
import collections
from enum import IntEnum
from enum import Flag
import re

SCORE_MCCMNC = 1 << 8
SCORE_IMSI_PREFIX = 1 << 7
SCORE_ICCID_PREFIX = 1 << 6
SCORE_GID1 = 1 << 5
SCORE_GID2 = 1 << 4
SCORE_SPN = 1 << 1
SCORE_APN = 1 << 0


class CarrierState(IntEnum):
    """
    An enum class that denotes what state the AsyncServiceProviderParser is at.
    """
    LIST = 0
    ID = 1
    ATTRIBUTE = 2
    MCCMNC = 3
    ERROR = 4


class CarrierIdParser:
    def __init__(self, match_score, carrierList):
        self.match_score = match_score
        self.current_score = None
        self.mccmnc = ""
        self.carrierList = carrierList
        self.state = CarrierState.LIST
        self.canonical_id = None
        self.carrier_name = ""
        self.imsi_prefix = ""
        self.iccid_prefix = ""
        self.gid1 = ""
        self.gid2 = ""
        self.plmn = ""
        self.spn = ""
        self.matched_mccmnc = False
        self.text = None
        self.max_score = 0
        self.imsi_pattern = ""

    def start_list(self, tag, attrib):
        if tag.lower() == 'carrier_list':
            return
        elif tag.lower() == 'carrier_id':
            for key, value in attrib.items():
                if key.lower() == 'canonical_id':
                    self.canonical_id = value
                elif key.lower() == 'carrier_name':
                    self.carrier_name = value
            self.max_score = 0
            self.state = CarrierState.ID

    def start_id(self, tag, attrib):
        if tag.lower() == 'carrier_attribute':
            self.current_score = None
            self.state = CarrierState.ATTRIBUTE

    def start_attribute(self, tag, attrib):
        return

    def start(self, tag, attrib):
        if self.state is CarrierState.LIST:
            self.start_list(tag, attrib)
        elif self.state is CarrierState.ID:
            self.start_id(tag, attrib)
        elif self.state is CarrierState.ATTRIBUTE:
            self.start_attribute(tag, attrib)

    def data(self, data):
        self.text = data

    def end_attribute(self, tag):
        if tag.lower() == 'mccmnc_tuple':
            if self.text == self.match_score.mccmnc:
                self.matched_mccmnc = True
                self.mccmnc = self.text
        elif tag.lower() == 'gid1':
            if self.match_score.gid1 == self.text:
                self.gid1 = self.text
        elif tag.lower() == 'gid2':
            if self.match_score.gid2 == self.text:
                self.gid2 = self.text
        elif tag.lower() == 'spn':
            if self.match_score.spn == self.text:
                self.spn = self.text
        elif tag.lower() == 'imsi_prefix_xpattern':
            self.imsi_pattern = self.text
            if 'x' in self.imsi_pattern:
                self.imsi_pattern = "^" + self.imsi_pattern.replace("x", r"\d")
            if self.imsi_pattern and self.match_score.imsi and bool(re.match(self.imsi_pattern, self.match_score.imsi)):
                self.imsi_prefix = self.text
            else:
                self.imsi_pattern = ""
        elif tag.lower() == 'iccid_prefix':
            if self.match_score.iccid.startswith(self.text):
                self.iccid_prefix = self.text
        elif tag.lower() == 'carrier_attribute':
            score = MatchingScore(self.mccmnc, self.imsi_prefix, self.iccid_prefix, self.gid1, self.gid2, "", self.spn)
            score.compare_score(self.match_score)
            if score.score > self.max_score:
                self.max_score = score.score
            self.current_score = score
            self.imsi_prefix = ""
            self.iccid_prefix = ""
            self.gid1 = ""
            self.gid2 = ""
            self.plmn = ""
            self.spn = ""
            self.imsi_pattern = ""
            self.state = CarrierState.ID

    def end_id(self, tag):
        if tag.lower() == 'carrier_id':
            if self.matched_mccmnc:
                string = self.current_score.mccmnc
                string = string + ('GID1=' + self.current_score.gid1.upper() if self.current_score.gid1 else "")
                string = string + ('IMSI=' + self.current_score.imsi.upper() if self.current_score.imsi else "")
                string = string + ('SPN=' + self.current_score.spn.upper() if self.current_score.spn else "")
                string = string + ('ICCID=' + self.current_score.iccid.upper() if self.current_score.iccid else "")
                self.carrierList[self.canonical_id] = {'carrier_string': string, 'score': self.max_score}
                # print(self.carrierList)

            self.matched_mccmnc = False
            self.state = CarrierState.LIST
            self.canonical_id = -1
            self.carrier_name = ""

    def end(self, tag):
        if self.state is CarrierState.LIST:
            return
        elif self.state is CarrierState.ID:
            self.end_id(tag)
        elif self.state is CarrierState.ATTRIBUTE:
            self.end_attribute(tag)

    def close(self):
        # print(self.carrierList)
        return


def read_carrier_xml(match_score):
    # parse the carrier ids xml created from convert_pb_to_xml.py
    carrierList = {}
    target = CarrierIdParser(match_score, carrierList)
    state_parser = etree.XMLPullParser(events=('start', 'end'), target=target, recover=True)
    with open("/etc/igos/lte/carrier_ids.xml", "r", encoding="utf-8") as carrier_file:
        state_parser.read_events()
        while True:
            line = carrier_file.read(4096)
            if not line:
                break
            state_parser.feed(line)
        carrier_file.close()
    state_parser.close()
    return carrierList

class ApnTypes(Flag):
    NONE = 0
     # APN type for default data traffic
    DEFAULT = 1 << 0
     # APN type for MMS traffic
    MMS = 1 << 1
     # APN type for SUPL assisted GPS
    SUPL = 1 << 2
     # APN type for DUN traffic
    DUN = 1 << 3
     # APN type for HiPri traffic
    HIPRI = 1 << 4
     # APN type for FOTA
    FOTA = 1 << 5
     # APN type for IMS
    IMS = 1 << 6
     # APN type for CBS
    CBS = 1 << 7
     # APN type for IA Initial Attach APN
    IA = 1 << 8
     # APN type for Emergency PDN. This is not an IA apn, but is used for access to carrier services
     # in an emergency call situation.
    EMERGENCY = 1 << 9
     # APN type for Mission Critical Service
     # Reference: 3GPP TS 22.280 V15.3.0
    MCX = 1 << 10
     # APN type for XCAP
    XCAP = 1 << 11
     # APN type for VSIM.
    VSIM = 1 << 12
     # APN type for BIP.
    BIP = 1 << 13
     # APN type for ENTERPRISE
    ENTERPRISE = 1 << 14
     # APN type for RCS (Rich Communication Services)
    RCS = 1 << 15

TYPE_ALL = ApnTypes.DEFAULT | ApnTypes.HIPRI | ApnTypes.MMS | ApnTypes.SUPL | ApnTypes.DUN | ApnTypes.FOTA | ApnTypes.IMS | ApnTypes.CBS
TYPE_DEFAULT = ApnTypes.DEFAULT | ApnTypes.HIPRI
TYPE_MMS = ApnTypes.MMS
TYPE_SUPL = ApnTypes.SUPL
TYPE_DUN = ApnTypes.DUN
TYPE_HIPRI = ApnTypes.HIPRI
TYPE_FOTA = ApnTypes.FOTA
TYPE_IMS = ApnTypes.IMS
TYPE_CBS = ApnTypes.CBS
TYPE_IA = ApnTypes.IA
TYPE_EMERGENCY = ApnTypes.EMERGENCY
TYPE_MCX = ApnTypes.MCX
TYPE_XCAP = ApnTypes.XCAP
TYPE_VSIM = ApnTypes.VSIM
TYPE_BIP = ApnTypes.BIP
TYPE_ENTERPRISE = ApnTypes.ENTERPRISE
TYPE_RCS = ApnTypes.RCS

APN_TYPE_MAP = {
    '*': 'ALL',
    'default': 'DEFAULT',
    'internet': 'DEFAULT',
    'vzw800': 'DEFAULT',
    'mms': 'MMS',
    'sup': 'SUPL',
    'supl': 'SUPL',
    'agps': 'SUPL',
    'pam': 'DUN',
    'dun': 'DUN',
    'hipri': 'HIPRI',
    'ota': 'FOTA',
    'fota': 'FOTA',
    'admin': 'FOTA',
    'ims': 'IMS',
    'cbs': 'CBS',
    'ia': 'IA',
    'emergency': 'EMERGENCY',
    'mcx': 'MCX',
    'xcap': 'XCAP',
    'rcs': 'RCS',
}

APN_STRING_KEYS = [
    'server', 'proxy', 'port', 'user', 'password', 'mmsc',
    'mmsc_proxy', 'mmsc_proxy_port'
]

APN_REMAP_KEYS = {
    'mmsproxy': 'mmsc_proxy',
    'mmsport': 'mmsc_proxy_port'
}

APN_INT_KEYS = [
    'authtype', 'mtu', 'max_conns', 'wait_time', 'max_conns_time'
]

AUTH_MAP = {'0': 'none', '1': 'pap', '2': 'chap', '3': 'pap-chap'}


APN_BOOL_KEYS = [
    'modem_cognitive', 'user_visible', 'user_editable'
]

BOOL_MAP = {'true': True, 'false': False, '1': True, '0': False}


class MatchingScore():
    def __init__(self, mccmnc, imsi, iccid, gid1, gid2, plmn, spn):
        self.mccmnc = mccmnc
        self.imsi = imsi
        self.iccid = iccid
        self.gid1 = gid1
        self.gid2 = gid2
        self.spn = spn
        self.score = 0
        self.plmn = plmn

    def compare_score(self, score):
        if self.mccmnc == score.mccmnc:
            self.score += SCORE_MCCMNC
        if score.gid1 and self.gid1 and self.gid1.upper() == score.gid1.upper():
            self.score += SCORE_GID1
        if score.imsi and self.imsi:
            self_imsi_pattern = self.imsi
            score_imsi_pattern = score.imsi
            if 'x' in self.imsi:
                self_imsi_pattern = "^" + self_imsi_pattern.replace("x", r"\d")
            if 'x' in score.imsi:
                score_imsi_pattern = "^" + score_imsi_pattern.replace("x", r"\d")
            if bool(re.match(self_imsi_pattern, score_imsi_pattern)):
                self.score += SCORE_IMSI_PREFIX
        if score.spn and self.spn and self.spn.upper() == score.spn.upper():
            self.score += SCORE_SPN
        if score.gid2 and self.gid2 and self.gid2.upper() == score.gid2.upper():
            self.score += SCORE_GID2
        if self.iccidPrefixMatch(score.iccid, self.iccid):
            self.score += SCORE_ICCID_PREFIX
    
    def iccidPrefixMatch(self, iccid, prefix):
        if not iccid or not prefix:
            return False
        return iccid.startswith(prefix)


class ApnItem():
    def __init__(self, name, apn, score):
        self.name = name
        self.apn = apn
        self.type = []
        self.server = None
        self.proxy = None
        self.username = None
        self.password = None
        self.authtype = None
        self.protocol = None
        self.roaming = None
        self.mmsc = None
        self.mmsc_proxy = None
        self.mmsc_proxy_port = None
        self.score = score


class CarrierId():
    def __init__(self, mcc_mnc, imsi, iccid, gid1, gid2, spn):
        self.mcc_mnc = mcc_mnc
        self.spn = spn
        self.imsi = imsi
        self.gid1 = gid1
        self.gid2 = gid2
        self.iccid = iccid

def get_apn_bitmask(type_list):
    bitmask = 0
    if type_list is not None:
        for types in type_list:
            bitmask = bitmask | (TYPE_ALL.value if types.upper() == 'ALL' else ApnTypes[types.upper()].value)
    return bitmask

# function to convert a carrier id to a name
# name should be format of MCCMNC(GID1=...[SPN=...{IMSI=...}])
# where everything in () is optional
# UPDATED: add all items to just string mcc_mnc to easily check for dupes or not
def to_string(cid):
    ret = cid.mcc_mnc
    return ret


def gen_apnitem(node, score):
    item = {}
    item['score'] = score
    item['name'] = node.get('carrier')
    if node.get('apn'):
        item['apn'] = node.get('apn')
    if node.get('type'):
        # split the types into a list
        item['type'] = [types.strip().lower() for types in node.get('type').split(',')]
        item['type'] = list([APN_TYPE_MAP[t].lower() for t in item['type'] if t])

    for key in ['protocol', 'roaming_protocol']:
        if node.get(key):
            item[key] = node.get(key).lower()
    for key, value in node.items():
        if key in APN_STRING_KEYS:
            item[key] = node.get(key)
            continue
        if key in APN_REMAP_KEYS:
            # rename the keys
            item[APN_REMAP_KEYS[key]] = node.get(key)
            continue
        if key in APN_INT_KEYS:
            if key == 'authtype':
                item[key] = AUTH_MAP[node.get(key).lower()]
            else:
                item[key] = int(node.get(key))
            continue
        if key in APN_BOOL_KEYS:
            item[key] = BOOL_MAP[node.get(key).lower()]
            continue
    return item


def gen_cid(node):
    mcc_mnc = None
    # if there's a mccmnc, we should record it
    if node.get('mcc') and node.get('mnc'):
        mcc_mnc = node.get('mcc') + node.get('mnc')
    mvno_type = None
    mvno_data = None
    spn = None
    gid1 = None
    imsi = None
    iccid = None
    if node.get('mvno_type'):
        mvno_type = node.get('mvno_type')
    if node.get('mvno_match_data'):
        mvno_data = node.get('mvno_match_data')
    if mvno_type is not None:
        if mvno_type.lower() == 'spn':
            spn = mvno_data
        if mvno_type.lower() == 'imsi':
            imsi = mvno_data
        if mvno_type.lower() == 'gid':
            gid1 = mvno_data
        if mvno_type.lower() == 'iccid':
            iccid = mvno_data
    ret = CarrierId(mcc_mnc, imsi, iccid, gid1, None, spn)
    return ret

# A potential different way of processing apns, not in use
def process(apn_node, carrier_id, carrier_list, apn_list, match_score):
    apn_carrier_id = apn_node.get('carrier_id')
    if apn_carrier_id is not None and apn_carrier_id in carrier_list.keys():
        apnitem = gen_apnitem(apn_node, carrier_list[apn_carrier_id]['score'])
        print(apnitem)
        if apnitem not in apn_list[to_string(carrier_id)]:
            apn_list[to_string(carrier_id)].append(apnitem)

def process_by_mccmnc(node, carrier_id, apn_list, match_score):
    # the score that we compare all the apns to
    score = MatchingScore(carrier_id.mcc_mnc, carrier_id.imsi, carrier_id.iccid, carrier_id.gid1, "", "", carrier_id.spn)
    score.compare_score(match_score)
    apnitem = gen_apnitem(node, score.score)
    # if the apn is unique, add it
    #if apnitem not in apn_list[to_string(carrier_id)]:
    # now we just dedupe the list at the end
    apn_list[to_string(carrier_id)].append(apnitem)


def process_by_carrier_id_v2(apn_node, carrier_list, apn_list, match_score):
    apn_carrier_id = apn_node.get('carrier_id')
    if apn_carrier_id is not None and apn_carrier_id in carrier_list.keys():
        apnitem = gen_apnitem(apn_node, carrier_list[apn_carrier_id]['score'])
        #if apnitem not in apn_list[carrier_list[apn_carrier_id]['carrier_string']]:
        # we dedupe the list at the end
        apn_list[carrier_list[apn_carrier_id]['carrier_string']].append(apnitem)


def apn_type_satisfy(list):
    return_list = []
    for entry in list:
        # If the apn bitmask does not have a type of:
        # default, or dun, or emergency, or mission critical services
        # we should ignore it
        bitmask = get_apn_bitmask(entry.get('type')) if entry.get('type') else TYPE_DEFAULT.value
        if not ((bitmask & TYPE_DEFAULT.value) or (bitmask & TYPE_DUN.value) or \
                (bitmask & TYPE_MCX.value)):
            continue
        return_list.append(entry)
    return return_list

def dedupe(list):
    seen = set()
    unique_data = []
    for entry in list:
        user = entry.get('user')
        password = entry.get('password')
        apn = entry.get('apn')
        ip = entry.get('protocol')
        authtype = entry.get('authtype')
        #if there's no ip protocol, just believe that the ip protocol is ipv4v6 by default
        if ip is None:
            ip = 'ipv4v6'
            entry['protocol'] = ip
        key = (user, password, apn, ip, authtype)
        #should only add entries that have an apn
        if apn is not None:
            if key not in seen:
                seen.add(key)
                unique_data.append(entry)
    return unique_data

def read_aosp_carriers(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn):
    # the score that we compare all the apns to
    match_score = MatchingScore(mccmnc, imsi_prefix, iccid_prefix, gid1, gid2, plmn, spn)
    apn_list = collections.defaultdict(list)

    carrier_list = read_carrier_xml(match_score)
    # pull parser
    parser = etree.XMLPullParser(events=('start', 'end'), recover=True)

    # read from the apns.xml file
    with open("/etc/igos/lte/apns.xml", "r", encoding="utf-8") as apns_file:
        parser.read_events()
        while True:
            line = apns_file.read(4096)
            if not line:
                break
            parser.feed(line)
            # apns.xml is filled with <apn/> tags
            for action, elem in parser.read_events():
                if action == 'start' and elem.tag == 'apn':
                    apn_node = elem.attrib
                    carrier_id = gen_cid(apn_node)
                    #if not carrier_id.mcc_mnc or (carrier_id.mcc_mnc and carrier_id.mcc_mnc == mccmnc):
                    #process(apn_node, carrier_id, carrier_list, apn_list, None)
                    if carrier_id.mcc_mnc and carrier_id.mcc_mnc == mccmnc:
                        # either process by mccmnc
                        process_by_mccmnc(apn_node, carrier_id, apn_list, match_score)
                    elif not carrier_id.mcc_mnc:
                        # or by carrier id if there's no mccmnc
                        process_by_carrier_id_v2(apn_node, carrier_list, apn_list, match_score)
        apns_file.close()


    parser = etree.XMLPullParser(events=('start', 'end'), recover=True)
    #read the perle_apns.xml file
    with open("/etc/igos/lte/perle_apns.xml", "r", encoding="utf-8") as apns_file:
        parser.read_events()
        while True:
            line = apns_file.read(4096)
            if not line:
                break
            parser.feed(line)
            for action, elem in parser.read_events():
                if action == 'start' and elem.tag == 'apn':
                    apn_node = elem.attrib
                    carrier_id = gen_cid(apn_node)
                    if carrier_id.mcc_mnc and carrier_id.mcc_mnc == mccmnc:
                        # either process by mccmnc
                        process_by_mccmnc(apn_node, carrier_id, apn_list, match_score)
                    elif not carrier_id.mcc_mnc:
                        # or by carrier id if there's no mccmnc
                        process_by_carrier_id_v2(apn_node, carrier_list, apn_list, match_score)
        apns_file.close()
    parser.close()
    # flatten list, the keys previously used aren't really usable for sorting
    values = [x for v in apn_list.values() for x in v]
    values.sort(key=lambda value: value['score'], reverse=True)

    final_values = apn_type_satisfy(values)
    final_values = dedupe(final_values)
    # print(len(values))
    return final_values
