var indexSectionsWithContent =
{
  0: "ablprstu",
  1: "lprst",
  2: "lprt",
  3: "a",
  4: "prst",
  5: "lprt",
  6: "blprt",
  7: "prstu",
  8: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

