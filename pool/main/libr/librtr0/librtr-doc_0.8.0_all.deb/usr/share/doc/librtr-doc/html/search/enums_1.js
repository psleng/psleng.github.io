var searchData=
[
  ['pfx_5frtvals_0',['pfx_rtvals',['../group__mod__pfx__h.html#gacb1f5563c9a0bcfb6a7be631a0e8f15a',1,'pfx.h']]],
  ['pfxv_5fstate_1',['pfxv_state',['../group__mod__pfx__h.html#ga9f87b27f024a9db70884c3981e030aa0',1,'pfx.h']]]
];
